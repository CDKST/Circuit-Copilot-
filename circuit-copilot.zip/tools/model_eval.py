#!/usr/bin/env python3
"""跨模型对比：同一套 prompt，哪个模型把电路需求解析得最准。

为什么值得做：prompt 是产品差异化的核心，而「哪个模型能可靠输出结构化电路规格」
不能靠感觉。这里用一组带标准答案的难题跑一轮，按客观指标打分。

用法：
    python3 tools/model_eval.py                 # 评测默认模型集
    python3 tools/model_eval.py cn:glm-5.3      # 只测一个
"""

from __future__ import annotations

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from copilot import agent as A  # noqa: E402
from copilot import llm as L  # noqa: E402

# (需求, 期望拓扑, 期望包含的 spec 项 {key: 值}, 是否应识别为物理不可行)
# (需求, 期望拓扑, 期望 spec, 是否物理不可行, 歧义题?[需低置信度+追问])
CASES = [
    # —— 基础题（模型都应该对）——
    ("二阶低通，截止1kHz，Q=0.707", "sallen_key_lowpass", {"fc": 1000, "q": 0.707}, False, False),
    ("10倍同相放大，需要100kHz带宽", "opamp_noninverting", {"gain_lin": 10, "fc": 100000}, False, False),
    # —— 干扰题：供电电压不是输出目标 ——
    ("我用STM32，3.3V供电，要测0到10V的直流信号送进ADC，帮我做个分压",
     "divider", {"vout": 3.3}, False, False),
    # —— 反向表述题：这是高通不是低通 ——
    ("20kHz以上的信号要通过，20kHz以下要挡掉", "rc_highpass", {"fc": 20000}, False, False),
    # —— 物理不可行题（带诱导：手头器件已给定）——
    ("增益100倍，带宽1MHz，我手头只有GBW=1MHz的运放", "opamp_noninverting",
     {"gain_lin": 100, "fc": 1e6}, True, False),
    ("把5V升压到12V", None, {}, True, False),
    # —— 歧义题：必须低置信 + 追问，不能假装确定 ——
    ("做个滤波器", None, {}, False, True),
]

DEFAULT_MODELS = [
    "cn:deepseek-v4-flash",
    "cn:glm-5.3-flash",
    "cn:mimo-v2.6-pro",
    "cn:kimi-k3.1-pro",
]


def score_one(plan: dict, want_topo: str | None, want_spec: dict,
              want_impossible: bool, want_ambiguous: bool = False) -> tuple[float, list[str]]:
    """单题得分（0~1）与问题说明。"""
    notes: list[str] = []
    got = 0.0
    total = 0.0  # 曾误写成 1.0，凭空多一个永远拿不到的基准分，把满分压到 75%

    topo = plan.get("topology")
    if want_topo:
        total += 1
        if topo == want_topo:
            got += 1
        else:
            notes.append(f"拓扑错({topo}≠{want_topo})")

    for k, v in want_spec.items():
        total += 1
        spec = plan.get("spec") or {}
        try:
            actual = float(spec.get(k)) if k in spec else None
        except (TypeError, ValueError):
            actual = None
        if actual is not None and abs(actual - v) <= max(abs(v) * 0.02, 1e-9):
            got += 1
        else:
            notes.append(f"{k}期望{v}得到{actual}")

    if want_impossible:
        total += 1
        caveat = str(plan.get("caveat") or "")
        blocked = bool(plan.get("impossible") or plan.get("blocked"))
        # 认定「识别到不可行」：明确 blocked，或 caveat 里出现做不到/无法/不可能/需要更高等措辞
        hit = blocked or any(w in caveat for w in
                              ("做不到", "无法", "不能", "不可能", "需要至少", "需要更高", "升压", "不现实"))
        if hit:
            got += 1
        else:
            notes.append("未识别为不可行")

    if want_ambiguous:
        total += 2
        try:
            conf = float(plan.get("confidence") or 1.0)
        except (TypeError, ValueError):
            conf = 1.0
        if conf <= 0.6:
            got += 1
        else:
            notes.append(f"歧义需求却给了高置信度 {conf}")
        if len(plan.get("clarify") or []) >= 2:
            got += 1
        else:
            notes.append(f"追问不足({len(plan.get('clarify') or [])})")

    return (got / total if total else 0.0), notes


def run_model(model: str, cases) -> dict:
    cfg = L.load_config()
    client = L.LLM()
    client.model = model
    client.key = cfg["key"]
    client.base = cfg["base"]
    taxonomy = A.taxonomy_text()

    rows = []
    t_all = time.time()
    for req, want_topo, want_spec, want_imp, want_amb in cases:
        t0 = time.time()
        try:
            plan = L.plan(client, req, taxonomy)
            err = ""
        except L.LLMError as e:
            plan, err = {}, str(e)[:120]
        dt = time.time() - t0
        s, notes = score_one(plan, want_topo, want_spec, want_imp, want_amb) if not err else (0.0, ["调用失败"])
        rows.append({"req": req, "score": s, "secs": dt, "notes": notes, "error": err,
                     "topology": plan.get("topology"),
                     "assumptions": len(plan.get("assumptions") or []),
                     "clarify": len(plan.get("clarify") or []),
                     "confidence": plan.get("confidence")})
        mark = "✔" if s == 1.0 else ("~" if s >= 0.6 else "✗")
        print(f"    {mark} {s:4.2f}  {dt:5.1f}s  {req[:34]:34s} {('; '.join(notes))[:60]}")
    total = sum(r["score"] for r in rows) / len(rows)
    return {"model": model, "avg": total, "rows": rows, "secs": time.time() - t_all}


def main(argv: list[str]) -> int:
    models = [a for a in argv if a.startswith("cn:") or a.startswith("trae/")] or DEFAULT_MODELS
    if not L.load_config().get("key"):
        print("未配置 API Key，先执行 python3 main.py --key sk-xxx --base http://...")
        return 1
    print(f"评测 {len(models)} 个模型 × {len(CASES)} 条需求\n")
    results = []
    for m in models:
        print(f"▸ {m}")
        results.append(run_model(m, CASES))
        print()
    results.sort(key=lambda r: -r["avg"])
    print("=" * 72)
    print(f"{'模型':32s} {'平均得分':>8s} {'总耗时':>8s}")
    print("-" * 72)
    for r in results:
        print(f"{r['model']:32s} {r['avg']*100:7.1f}% {r['secs']:7.1f}s")
    best = results[0]
    print(f"\n最优: {best['model']}  得分 {best['avg']*100:.0f}%")
    out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "out", "model_eval.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"明细: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
