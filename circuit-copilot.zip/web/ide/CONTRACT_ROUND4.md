# CCL Studio — 第三轮优化方案（实测驱动）

> ⚠️ **历史文档**：本轮的视角是**手机 / 移动端**。项目定位已改为**桌面优先**
> （见 `CONTRACT_ROUND5_DESKTOP.md`）。本文保留原貌作为历史依据，
> 其中「移动优先」「横屏视口」等表述**不再代表当前定位**；
> 窄屏/触屏能力仍然是兼容目标，只是不再是主场景。

## 相关契约（别处）

本文件是 IDE ✕ 移动端视角的**第三轮**优化契约，只覆盖「实测出来的移动端缺陷」。同层还有三份，别混读：

| 文件 | 权威范围 |
|---|---|
| `web/ide/CONTRACT.md` | 第一/二轮骨架：文件所有权、布局网格、`editor.js` / `panels.js` / `main.js` 的模块签名 |
| **本文件（`CONTRACT_ROUND4.md`）** | 移动端（360×669 竖屏 / 640×360 横屏）实测缺陷清单与修法，**视口数据是实测的** |
| `web/ide/CONTRACT_ROUND5_DESKTOP.md` | 桌面浏览器版对标 VS Code；**它声明本文件的移动端视角作废**，视口/键位以它为准 |
| `web/ide/CONTRACT_SCHEMATIC.md` | 电路图渲染模块（`schematic.js`）的权威 |

后端 / CCL 层的口径在 `ccl/CONTRACT.md`；描述性文档（现状、踩坑）在 `docs/ARCHITECTURE.md` §6。

前提：第一、二轮契约（VS Code 风格骨架 / 编辑器增强 / 面板增强 / 命令面板 / 启动画面 / 插件）
已全部落地，`node --check` 通过，`/ide/` 可跑。本轮**不重写**，只修真实缺陷 + 补移动端编码刚需。

## 一、现状体检（实测数据，非猜测）

### 1.1 竖屏 360×669（本机真实视口，DPR 2）

| 元素 | 实测 | 判据 | 结论 |
|---|---|---|---|
| `#editor-toolbar` | clientWidth 312 / scrollWidth **656** | 应相等 | 溢出 344px，「直流扫描」之后的所有参数输入框在屏幕外 |
| `#editor-toolbar` 滚动条 | `::-webkit-scrollbar{height:0}` | — | 能滑但**没有任何可滑的视觉提示** |
| `#panel-tabs` | clientWidth 312 / scrollWidth **391** | 应相等 | 「报告」tab 右边界 > 360，完全在屏外 |
| `#sidebar`（竖屏展开） | `position: relative`，h=**446** | 应为 `fixed`，h=607 | 浮层高度只有内容高，底部露出编辑区 |
| `#splitter-h` | h=10（视觉 6 + 热区） | — | 正常 |
| `.act` 活动栏 | 44×44 | ≥44 | 正常 |
| `#segKind button` | 74×**32** | ≥40 | 高度偏低 |
| `.ptab` | 48×**36** | ≥40 | 偏低 |
| `#btnRun` | 53×**36** | ≥40 | 偏低 |

### 1.2 640×360 横屏（设计主目标）算术推演

```
360  - 28(标题栏) - 22(状态栏)            = 310   #main
310  - 140(面板) - 10(分隔条)             = 160   #editor-area
160  - 32(标签) - 32(工具条)              =  96   #editor-host   ← 只有 ~5 行代码
```
第二轮契约写「640×360 下编辑区仍有 ≥120px 高」——**未达标，差 24px**。

### 1.3 能力缺口（全仓 grep 0 命中）

| 类别 | 缺什么 | 影响 |
|---|---|---|
| 编辑器 | 查找 / 替换 | 手机上翻 200 行找 `1e6` 只能靠手滑 |
| 编辑器 | 自动换行开关（`ta.wrap='off'` 强制，无开关） | 竖屏长行必须横向拖动，单行 60 字就废 |
| 编辑器 | 符号条 | Python 的 `_ ( ) : " < >` 在手机输入法里藏在二级键盘，**这是移动端最大摩擦点** |
| 布局 | 面板最大化（只有电路图有 `bigschem` 浮层） | 波形 158px 高，读不出 3 个十倍频 |
| 布局 | 布局状态持久化（`--panel-h` / `--sidebar-w` / 两个 collapsed / 当前面板） | 每次刷新回到出厂值 |
| 布局 | `env(safe-area-*)` 全是 0 命中（但 `viewport-fit=cover` 已开） | 刘海屏 / 手势条会压住标题栏与状态栏 |
| 运行 | 按钮 busy 态、取消（AbortController）、失败自动跳错误行 | 慢仿真时连点会积压，失败只留一行字 |
| 文件 | `.py` 导入 / 导出（Ctrl+S 只清 dirty 点，不落盘） | 代码带不出 App |
| 无障碍 | `.act` 无 `aria-label`（只有 `title`）、tab 无 `role="tab"`/`aria-selected`、浮层无 Esc / 点外关闭 | 读屏器只会念 emoji |
| 性能 | 每次输入整篇 `highlight()` + `innerHTML` 重刷（rAF 合帧） | ~500 行还行，2000 行起明显掉帧 |

### 1.4 级联 Bug（本次唯一「硬 bug」，先修）

`style.css:556` 的 `#sidebar{position:relative}`（为拖宽热区加的）与
`style.css:457` 的 `@media (max-width:720px){ #sidebar{position:fixed; …} }`
**特异性相同，后出现者胜** —— 媒体查询不加特异性，所以窄屏浮层从来没真正 fixed 过。

## 二、优化原则

1. **手机竖屏是一等公民**（本机就是 360 宽），不再是「建议横屏」的遗留态。
2. 每个改动都要能用数字验收：`scrollWidth === clientWidth`、`height ≥ N`、触控 ≥40。
3. 只动自己名下的文件，签名只增不改。
4. 不加依赖、不加 CDN、不引框架（延续原契约）。

## 三、任务清单

### P0 —— 必修（真 bug / 硬指标）

**P0-1 侧栏浮层级联修复**（`style.css`）
```css
/* 基础段（原第 174 行 #sidebar{} 内）加 position:relative，并删除第 556 行的
   #sidebar{position:relative} 整条 —— 它是为热区加的，位置放错导致覆盖浮层 */
#sidebar{ position:relative; display:flex; flex-direction:column; … }
```
验收：竖屏展开侧栏，`getComputedStyle#sidebar.position === 'fixed'`，高度 == `innerHeight - titleH - statusH`。

**P0-2 工具栏溢出**（`style.css` + `main.js` 只加 class）
```css
@media (max-width:540px){
  #editor-toolbar{ flex-wrap:wrap; height:auto; row-gap:4px; padding:4px 6px }
  #segKind{ order:1 }
  #tbHint{ display:none }
  #tbParams{ order:3; width:100%; overflow-x:auto; padding-top:2px }
  #tbParams::-webkit-scrollbar{height:0}
  /* 第二行右侧渐隐，提示"还能滑" */
  #tbParams{ mask-image:linear-gradient(90deg,#000 82%,transparent) }
}
```
验收：竖屏 `#editor-toolbar.scrollWidth === clientWidth`，四个 `#segKind` 按钮与全部参数输入框**首屏可见**。

**P0-3 面板标签溢出**（`panels.js` + `style.css`）
- `.ptab` 加 `padding:0 7px`（≤400 宽）、`#panel-tabs` 右端渐隐。
- `setActive(id)` 内补 `tabEl.scrollIntoView({inline:'nearest', block:'nearest'})`，
  保证 `setActive('report')` 后该 tab 一定可见。
验收：竖屏 7 个 tab 全可见或可一键滚到；`报告` 不再永远在屏外。

**P0-4 横屏编辑区高度不达标**（`style.css`）
```css
@media (orientation:landscape) and (max-height:420px){
  :root{ --panel-h:104px }        /* 140 → 104，编辑区 96 → 132 */
}
```
并把 `#app` 顶部/底部改成安全区内缩（见 P2-4），确保净高不回退。
验收：640×360 下 `#editor-host` 高度 ≥ 120px（≈7 行代码）。

**P0-5 触控目标补齐**（`style.css`）
`.act` 横屏 30→34、`#segKind button` 高 32→36 且 `min-height:36`、`.ptab`/`#btnRun` 高 36→40。
允许横屏矮屏例外档只降 2px（契约已声明「唯一低于 32 的触控项」是 `.tb-btn`）。

### P1 —— 移动端编码刚需

**P1-1 符号条 symbar**（`editor.js` 暴露 + `main.js` 挂载）
```js
// editor.js 已有 insertText()，只需在 main.js 建条：
const SYMS = ['(',')','[',']','{','}','"',"'",':','=','.','_','#',',','<','>','+','-','*','/','→'];
bar.addEventListener('pointerdown', (e) => {   // pointerdown + preventDefault，别夺焦点
  const b = e.target.closest('button'); if (!b) return;
  e.preventDefault();
  if (b.dataset.k === '→') { editor.insertText('    '); return; }
  editor.insertText(b.dataset.k);
});
```
- 定位：`#editor-area` 底部、`position:sticky` 或用 `visualViewport` 把条贴在键盘上沿。
- 高度 34px，可长按连续输入。
验收：键盘弹起时条在键盘正上方不遮挡光标行；连点 `(` 得到 `()` 且光标居中（已有配对逻辑）。

**P1-2 查找 / 替换**（`editor.js` + `main.js`）
```js
// editor.js 新增（只增）
findAll(q, {caseSensitive=false, regex=false}) -> {hits:[{start,end,line}], index}
replaceAll(q, rep, opts) -> number
```
UI：`Ctrl/Cmd+F` 打开 `#findbar`（吸在编辑区顶部），输入即高亮全部命中、`Enter` 下一个、`Esc` 关闭。
验收：命中行数正确、替换后 `undo` 可撤销（走 `insertText` 保证）。

**P1-3 自动换行开关**（`editor.js` + `main.js`）
```js
editor.setWrap(true);   // ta.wrap='soft'; pre.style.whiteSpace='pre-wrap'; 重新 layout()
```
默认：竖屏开、横屏关；状态进 localStorage。命令面板加「切换自动换行」。
验收：打开后无横向滚动条，行号与折行内容不错位（gutter 高度需按 `scrollHeight` 而非行数算——**这里是坑**）。

**P1-4 布局状态持久化**（`main.js`）
`STORE_KEY` 升 v2，新增 `ui:{panelH, sidebarW, sbCollapsed, panelCollapsed, activePanel, panelMax, wrap}`；
`restore()` 里做 v1→v2 迁移（老数据没有 `ui` 就取默认）。
验收：拖高面板 + 收起侧栏 + 刷新，三项全部还原。

**P1-5 运行反馈与取消**（`main.js`）
- `#btnRun` busy 态：`disabled` + `⟳ 运行中`，结束恢复（已有 `S.busy`，只是没上到 UI）。
- `AbortController` + 8s 超时；中止后状态栏显示「已取消」。
- `applyResult(!ok)` 时若 `d.line` 存在 → `editor.goToLine(d.line)` 并 focus。
验收：连点 5 次只发 1 个请求；失败后光标落在错误行。

### P2 —— 打磨

**P2-1 面板最大化**（`style.css` + `main.js`）
双击 `.ptab` 或点 `#btnPanelMax` → `body.panel-max`：
```css
body.panel-max #main{ grid-template-rows:0 0 1fr }
body.panel-max #editor-area,body.panel-max #splitter-h{ display:none }
```
`Esc` 退出。把现有 `bigschem` 的浮层逻辑收敛成同一套（电路图放大 → 走 panel-max）。

**P2-2 无障碍**（`index.html` 只加属性 + `main.js`）
- `.act` 补 `aria-label`（中文动作名），`aria-pressed` 反映激活。
- `.tab` / `.ptab` 补 `role="tab"` + `aria-selected`；容器已有 `role="tablist"`。
- 浮层（侧栏 / 命令面板 / 面板最大化）统一：`Esc` 关闭、点遮罩关闭、打开时焦点进入。
验收：`Tab` 键遍历顺序合理，读屏念得出来。

**P2-3 编辑器高亮性能**（`editor.js`）
现状：每次输入 `preCode.innerHTML = highlight(整个文本)`。改法二选一：
- 简单版：文本 > 800 行时只高亮视口 ± 20 行，其余纯文本（滚动时增量补）。
- 或缓存按行切片的 token 结果，只重算变更行。
验收：2000 行文件，连续输入 3 秒不掉帧（`performance.now()` 采样 P95 < 16ms）。

**P2-4 安全区与键盘遮挡**（`style.css` + `main.js`）
```css
#titlebar{ padding-top:env(safe-area-inset-top) }
#activity{ padding-left:env(safe-area-inset-left) }
#statusbar{ padding-bottom:env(safe-area-inset-bottom) }
```
`main.js`：`visualViewport` 变化时把差值写 `--kb-h`，键盘弹起时暂时把 `--panel-h` 压到 `--tab-h`。
验收：刘海屏横屏不遮字；键盘弹起后编辑区仍显示 ≥3 行且光标行可见。

**P2-5 文件导入 / 导出 `.py`**（`main.js`）
`File > 导入 .py`（`<input type=file>`）→ 新标签；`导出 .py`（Blob 下载）。侧栏 `export` 活动项加两项。
验收：导出再导入，代码与分析参数一致。

**P2-6 快捷键速查**（`main.js` + `style.css`）
`?` 或命令面板首项 → 浮层列出：`Ctrl+Enter` 运行、`Ctrl+Shift+P` 命令面板、
`Ctrl+/` 注释、`Ctrl+F` 查找、`Ctrl+S` 保存、`Esc` 关闭浮层、`Tab/Shift+Tab` 缩进。

## 四、分工

| 谁 | 文件 | 任务 |
|---|---|---|
| ui-shell4 | `style.css` | P0-1~P0-5，P2-4 样式部分 |
| ui-editor4 | `editor.js` | P1-1 条挂载点、P1-2 查找 API、P1-3 `setWrap`、P2-3 高亮 |
| ui-panel4 | `panels.js` | P0-3 tab 滚动、P2-1 最大化与 bigschem 收敛 |
| Lead | `main.js` / `index.html` | P1-1 挂载、P1-4、P1-5、P2-2、P2-5、P2-6 |

## 五、总验收（Lead 卡）

1. 360×669 竖屏：`document.documentElement.scrollWidth === innerWidth`，无横向滚动。
2. 360×669 竖屏：工具条、7 个面板 tab **全部首屏可见或明确可滑**。
3. 640×360 横屏：`#editor-host` 高 ≥120px，编辑区 + 面板同时可见。
4. 侧栏浮层 `position:fixed`，高度填满，`Esc` / 点外可关。
5. 符号条随键盘上浮，不遮光标行。
6. 查找替换、自动换行、面板最大化、布局持久化各跑一遍，撤销不坏。
7. 全部触控目标 ≥40px（`.tb-btn` 横屏例外允许 28）。
8. 控制台 0 报错；四个 JS 文件 `node --check` 通过。
