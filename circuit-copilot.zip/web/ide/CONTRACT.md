# CCL Studio — 前端重构契约（VS Code 风格 · 桌面优先）

## 相关契约（别处）

`web/ide/CONTRACT*.md` 一共四份，**按轮次分层，各自成篇，不要合并**（合并会连坐所有引用）：

| 文件 | 权威范围 | 备注 |
|---|---|---|
| **本文件（`CONTRACT.md`）** | **第一/二轮的骨架契约**：文件所有权、布局网格、`editor.js` / `panels.js` / `main.js` 的模块签名与验收标准 | 模块签名仍然以本文件为准 |
| `CONTRACT_ROUND4.md` | 第三轮优化：**实测驱动的缺陷清单**（竖屏/横屏溢出实测数据）+ 移动端编码刚需 | 移动端视角，已被下一份判作废，保留作历史依据 |
| `CONTRACT_ROUND5_DESKTOP.md` | 第五轮：**桌面版对标 VS Code**——桌面实测基线、头号 bug、键位与布局对齐；明确「运行环境是电脑浏览器」 | **视口/键位这类话题以它为准**（它自己声明 `CONTRACT_ROUND4.md` 作废） |
| `CONTRACT_SCHEMATIC.md` | **电路图渲染模块（`schematic.js`）的权威**：符号、布局算法、自测要求、连接正确性判据 | 动 `schematic.js` 必须先读这份 |

另外两处也在讲这一层，但**不是契约**：

- `docs/ARCHITECTURE.md` 的 §6（IDE 前端结构）：实现现状与踩坑，描述性；
- `ccl/CONTRACT.md`：**后端 / CCL 层**的权威，前端只是它的壳，接口口径以那份为准；
- `tests_ui/README.md`：前端纯逻辑自测（`node tests_ui/schematic_selfcheck.mjs`）的说明。

目标：把 `web/ccl.html` 的单页聊天式界面，重构成一个 **VS Code 风格的 IDE**，
**桌面优先**：主场景是电脑浏览器（宽视口、键盘鼠标、文件工作区）。
手机横屏与平板是**兼容**目标（触屏可用、侧栏自动折叠），不是主场景。

## 文件与所有权（严格）

| 文件 | 内容 | 负责人 |
|---|---|---|
| `web/ide/index.html` | DOM 骨架（已定稿，**不要改结构，只可按需加 class**） | Lead ✅ |
| `web/ide/style.css` | 全部样式：VS Code 配色、布局网格、桌面与窄屏适配、分隔条 | **ui-shell** |
| `web/ide/editor.js` | 代码编辑器模块（行号、高亮、诊断标记） | **ui-editor** |
| `web/ide/panels.js` | 结果面板模块（波形/问题/指标/工作点/网表/报告） | **ui-panel** |
| `web/ide/main.js` | 集成与 API 调用 | Lead ✅ |

只改自己名下的文件。需要别人配合先发消息给 lead。

## 必须遵守的三条

1. **纯原生**：不引入任何 npm 包、CDN、框架。只用浏览器原生 API（ES module / SVG / Canvas 可选）。
2. **不做页面刷新**：单页应用，模块自己管理 DOM。
3. **桌面优先**：主要目标视口是桌面（`width ≥ 1024px`）。
   窄屏是**兼容**目标：`width < 720px && 竖屏` 时 `#orientationHint` 显示「建议横屏」
   且侧栏自动折叠（`main.js` 里已接好，`style.css` 负责显隐）。

## 布局网格（`index.html` 已定，`style.css` 负责实现）

```
#app  grid:
  ┌────────────── titlebar (36px) ──────────────┐
  │ activity │ sidebar │ main                   │
  │ 44px     │ 220px   │ 1fr                    │
  ├────────────── statusbar (22px) ─────────────┤
```

`#main` 内部是**垂直**两栏（编辑区 / 分隔条 / 面板）：

```
#main  display:grid; grid-template-rows: 1fr 6px var(--panel-h);
```

- `#splitter-h`：可拖动改变 `#panel` 高度；`main.js` 会写 CSS 变量 `--panel-h`
- 侧边栏收起：`body.sb-collapsed` → `#sidebar{display:none}`，网格列变 0
- 面板收起：`body.panel-collapsed` → `#panel{...}` 只留 `#panel-tabs`

**必须支持的两档断点（桌面 / 窄屏兼容）**
- `@media (max-width: 720px)`：sidebar 默认收起（`--sidebar-w: 0`），侧栏改为浮层
- `@media (min-width: 1000px)`：sidebar 220px、面板默认更高

## `editor.js` 契约（ui-editor 实现）

```js
/** @param {HTMLElement} host  编辑器挂载点（#editor-host）
 *  @param {{value?:string, onChange?:(v:string)=>void, onCursor?:(l:number,c:number)=>void}} opts
 *  @returns {EditorApi} */
export function createEditor(host, opts) {}

// EditorApi:
//   getValue(): string
//   setValue(s: string): void
//   focus(): void
//   setDiagnostics(list: {line:number, level:"error"|"warn", message:string}[]): void
//   goToLine(n: number): void
//   layout(): void          // 容器尺寸变化后调用
```

实现要求：
- **行号**：左侧固定列，与内容滚动同步
- **语法高亮**：用一层 `<pre>` 覆盖 + 透明 `<textarea>` 的方案，或 contenteditable；
  支持 Python 关键字 / 字符串 / 注释 / 数字 / CCL 专有（`Circuit`、`GND`、`c.xxx`、`.expect`）
- **诊断**：错误行的行号标红 + 行内左边框；`title` 提示 message
- **Tab 键**插入 4 空格；Ctrl/Cmd+Enter 触发 `opts.onRun`（可选第 4 个回调）
- 触屏可用：点击定位、长按选择、软键盘弹出时不遮挡光标行
- 不做自动补全（时间不够可以留 TODO，但要写清）

## `panels.js` 契约（ui-panel 实现）

```js
/** @param {{panelBody:HTMLElement, panelTabs:HTMLElement}} refs
 *  @returns {PanelsApi} */
export function createPanels(refs) {}

// PanelsApi:
//   showWaveform(traces, opts)      // traces: {节点名: {x:number[], y:number[], phase?:number[], unit:string}}
//                                   // opts: {kind:"ac"|"tran", active:string[]}
//   showProblems(issues)            // issues: [{level, title, detail, ref, code}]
//   showMetrics(metrics)            // {名称: 数值|null}
//   showOperatingPoint(op)          // {节点: 数值|null}
//   showNetlist(text)
//   showReport(markdownOrText)
//   setActive(panelId)              // "wave"|"problems"|"metrics"|"op"|"netlist"|"report"
//   clear()
```

实现要求：
- **波形**：SVG，对数 x 轴（AC）或线性（TRAN），多曲线 + 图例可点开关，
  十字线读数（pointer 事件，触屏与鼠标通用），坐标轴刻度自适应
- **问题**：按 error/warn 分色，点击某条 → 调用 `host.goToLine(ref?)`；
  如果 `issue.line` 存在则跳该行（`main.js` 会传）
- 面板空态要有说明文字，不能白屏
- 所有面板内容 `overflow:auto`，不能撑破布局

## `main.js`（Lead 写，已定）

已实现：活动栏切换、侧边栏内容、编辑器初始化、运行、AI 三个动作、报告下载、
状态栏更新、分隔条拖动、窄屏提示。**子智能体不要改它。**

## 后端接口（已存在，直接调）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/ccl/example` | `{examples:[{title, code, analysis}]}` |
| GET | `/api/ccl/blocks` | `{ok, blocks:[{name, summary, params}]}` |
| GET | `/api/health` | `{ngspice, topologies, llm_configured, llm_model}` |
| POST | `/api/ccl/run` | `{code, analysis}` → `{ok, circuit, analysis, lint, expect, netlist, error, line, stage}`，另含 `live` / `timeline` / `switch_states` / `switch_apply`（见下） |
| POST | `/api/ccl/ai` | `{action:"generate"|"fix"|"explain", prompt?, code?, analysis?}` |
| POST | `/api/ccl/report` | `{code, analysis}` → `{ok, markdown, id, filename}` |
| GET | `/api/ccl/report/<id>` | Markdown 附件下载 |

`analysis` 形如 `{kind:"ac", f_start, f_stop, points}` / `{kind:"op"}` / `{kind:"tran", t_step, t_stop}`

### `/api/ccl/run` 的四个「工作态」字段（M6 新增，口径以 `ccl/CONTRACT.md` 的 M6 节为准）

| 字段 | 出现时机 | 含义 |
|---|---|---|
| `live` | op / tran / dc 有；**ac 一律 `null`** | `{kind, t, items:{位号:{kind, current, voltage, power}}}`。**`tran`/`dc` 取末点、`op` 就是那一个点**（`t` 是那个时刻，电流与电压严格同刻；t=0 的旧行为已修）。`voltage` 是**绝对值**；**只有正好两个引脚的器件才有 `voltage`/`power`**，三端 `Q`/`M` 与四端开关 `S` 恒为 `null`。取不到的量是 `null`（不估算） |
| `timeline` | **只有 `tran`**；其它分析是 `null` | `{t, dt, points, raw_points, t_stop, series:{位号:{kind, current?, voltage?}}}`，最多 400 点（原始点数不足就原样）；降采样是**保峰**，但 `points` 不固定是 400（实测常见 200~400）。电压源**有** `current`（`i(v1)`） |
| `switch_states` | 请求里带了 `switch_states` 时 | 每个开关**最终的状态** `{"SW1":"on"}`——界面据此画开关视觉 |
| `switch_apply` | 同上 | 后端**用什么办法**强制状态：`"source"`（改控制源 DC）或 `"vt"`（改该开关 `.model Vt`）。**调试用，不是状态** |

**别把 `switch_apply` 当状态读**：它取值 `"source"`/`"vt"`，与 `on`/`off` 对不上——
M6 期间这个混淆导致「仿真对了但灯不亮、开关视觉被重置」，已由 `tests_api` 钉住。

### `panels.js` 的电路图接口（M6 扩展）

```js
showSchematic(html, legend, anim)
// anim（可选）：{ timeline, kinds, switches, onSwitch }
//   · 传了且 timeline 可用 → 图例下面多一条时间轴播放条（createPlayer）
//   · 不传 / timeline 为空    → 只有图，没有播放条（**不演假动画**）
//   · switches/onSwitch 单独保存：没有播放条时也要能点开关（wireSwitchClicks）
```

动画 / 开关 / 播放条的模块契约与口径（含 `createPlayer` / `wireSwitchClicks` / `applyLive` 的导出清单）
见 `web/ide/CONTRACT_SCHEMATIC.md` 的「工作态与瞬态动画层」一节。

### 开关覆盖状态：按标签页 + 常驻提示条（`main.js` + `panels.js`）

用户点开关 = 「对这份代码做的一次实验」，所以覆盖状态**属于那个标签页**：

| 项 | 位置 | 口径 |
|---|---|---|
| 存放 | `S.tabs[i].switchStates`（位号大写 → `true` 闭合 / `false` 断开） | 早先存在全局 `S.switchStates` 一份：A 页点了 `SW1` 断开 → 切到 B 页（B 也有 `SW1`）→ B 被**静默**强制断开，与 B 的代码不符、界面毫无提示，只能刷新页面恢复 |
| 存档 | `save()` 的 `v: 3` 起带 `tabs[i].switchStates` | 刷新后仍在，但**提示条会明说**，并有明确出口 |
| 唯一读写口 | `tabSwitches()` / `clearTabSwitches()` / `switchBarInfo()` / `refreshSwitchBar()` | 别处不要直接摸 `S.tabs[i].switchStates`，否则容易漏掉「换标签页要刷提示条」 |
| 代码一改就作废 | `editor` 的 `onChange` | 只有内容真的变了才清（`editor.setValue` 不触发 `onChange`，切标签页不会误清）；清完 `setStatus('代码已修改：界面上的开关覆盖已清空（按新代码运行）')` |
| 换标签页 | `selectTab()` → `dropForeignSchematic()` | 面板上如果挂着**别的标签页**跑出来的图，撤掉——图是代码的投影，留着只会误导 |
| 提示条 | `panels.js` 的 `setSwitchBar(info)` / `[data-sw-bar]` | `info = {owner, extra:[{cls,text}], onRestore}`，`owner` 形如 `SW1 断开 · SW2 闭合`；`extra` 是 `switchSideEffects()` 算出的「点一个动两个」与「推不出来」；`null` = 整条下线（不是留个空条） |
| 「恢复按代码运行」 | `[data-sw-restore]` → `onRestore()` | 清空本页覆盖 + **重新仿真**（不重跑的话图上还是刚才被覆盖过的结果，用户会以为按钮没生效） |
| 刷新时机 | `refreshSwitchBar()` | 点开关的**瞬间**就刷（用户点了就该立刻看到「已被覆盖」） |

**提示条必须常驻可见**：开关覆盖不在代码里、也不在图上。没有这条提示，用户只看到一张不动的图，
根本想不到「是我刚才点了开关」。`setSwitchBar()` **只换提示条这一个节点、绝不重画整个面板**——
若顺手 `renderSchematicPanel()`，`innerHTML` 会用**旧的** `data.schematic` 重建，刚被 `switchAt()`
掰过去的刀闸会当场弹回原样（看起来像点了没反应），正在播动画时还会把播放器销毁重建。

## 视觉规范（ui-shell 定，其他人对齐）

VS Code Dark+ 近似配色：

```
--bg           #1e1e1e   编辑区背景
--bg-panel     #252526   面板/侧栏
--bg-activity  #333333   活动栏
--bg-tab       #2d2d2d   未激活标签
--bg-tab-act   #1e1e1e   激活标签
--border       #3c3c3c
--fg           #cccccc
--fg-dim       #8c8c8c
--accent       #0e639c   VS Code 蓝（按钮/激活）
--accent-2     #1177bb
--ok           #4ec9b0
--warn         #d7ba7d
--err          #f14c4c
--sel          #264f78
```

字体：`ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`（编辑区）
与 `-apple-system, "PingFang SC", "Noto Sans SC", system-ui`（UI）

## 验收标准（Lead 用这个卡）

1. 手机横屏（360×640 旋转为 640×360）下**无横向滚动**，四个区域都可见
2. 不用滚动就能看到编辑器 + 波形面板
3. 侧边栏、面板都能收起，收起后编辑区占满
4. 分隔条可拖动（鼠标与触屏）
5. 代码有语法高亮、行号、Tab 缩进
6. 跑一次示例：波形画出、问题列表有内容、指标与网表正确
7. 错误代码：行号标红 + 问题面板给出可定位信息
8. 控制台无报错
9. 只改了名下的文件（git 无从查，靠自律 + 交付说明）

---

# 第二轮优化（Lead 审计后下发的增量）

## 审计结论（这些都是**实测确认缺失**的，不是猜的）

| 模块 | 缺什么 |
|---|---|
| `editor.js` | 自动缩进、多行 Tab/Shift-Tab、括号自动配对、Ctrl+/ 注释切换、光标行列上报、`insertText()` |
| `panels.js` | 相位副图、导出 PNG、框选缩放、y 轴范围按「可见曲线」算 |
| `style.css` | 可拖拽侧栏宽度、VS Code 级细节（tab 形状/焦点环/过渡）、命令面板样式 |
| `main.js` | **侧栏的块与器件不可点**（纯展示，点了没反应）——Lead 补 |

## 契约新增（只增不改，已有签名不得变动）

### `editor.js` 新增两个方法

```js
insertText(text: string): void   // 在光标处插入文本（多行自动对齐当前缩进），并保持焦点
getCursor(): {line:number, col:number}   // 1-based
```
`opts.onCursor?(line, col)` 要真的被调用（光标移动、输入、点击都要触发）。

### `panels.js` 不变（增强都在内部）

## 本轮三路任务

### ui-editor2（`editor.js`）
1. **回车自动保持缩进**：上一行有缩进则新行同样缩进；上一行以 `:` 结尾再 +4 空格
2. **多行缩进**：选中多行按 Tab 整体 +4、Shift+Tab 整体 −4（且**不能**把焦点移走）
3. **括号/引号自动配对**：输入 `(` `[` `{` `"` `'` 自动补右半边并**把光标放到中间**；
   已有选中内容时用括号包裹选中；输入右括号且下一个字符正是它时**跳过**而不是重复插入
4. **Ctrl/Cmd+/ 注释切换**：选中行（或当前行）行首加/去 `# `
5. **光标行列上报**：调用 `opts.onCursor(line, col)`，1-based
6. **`insertText()` / `getCursor()`** 按上面的契约实现
7. 全部操作要**可撤销**（用 `document.execCommand('insertText')` 或手动维护 undo 栈——
   手写 textarea 会破坏原生 undo，必须自己处理，这点最容易翻车）

### ui-panel2（`panels.js`）
1. **相位副图**：AC 分析时，主图下面给一条相位曲线（−180~0°），高度约主图 1/3，
   与主图共享 x 轴与十字线
2. **导出 PNG**：面板右上角一个「⤓ PNG」按钮，把当前 SVG 序列化成 PNG 下载
   （`XMLSerializer` + `canvas.drawImage`，注意 SVG 内联样式要先转成属性）
3. **y 轴范围只按可见曲线算**，隐藏的曲线不参与（切换曲线时重算）
4. **十字线吸附最近采样点**，并显示该点精确数值（不要浮在两点之间）
5. 曲线多时图例可折行，不要溢出

### ui-shell2（`style.css`）
1. **侧栏可拖拽宽度**：`#sidebar` 右边缘 4px 热区（`cursor:col-resize`），
   拖动写 CSS 变量 `--sidebar-w`（Lead 会在 main.js 里接手势，**你只需给热区样式与光条**：
   `#sidebar-resizer{position:absolute;right:0;top:0;bottom:0;width:4px;cursor:col-resize}`，
   并保证 `#sidebar` 是 `position:relative`）
2. **VS Code 级细节**：
   - 标签顶部 1px 主题色高亮条（激活标签）
   - 激活标签底色与编辑区一致、未激活略暗，hover 时再亮一档
   - 全局 `:focus-visible` 焦点环（`outline:1px solid var(--accent-2); outline-offset:-1px`）
   - 按钮 hover/active 过渡 `transition:background .12s`
   - 活动栏图标 hover 有 tooltip（用 `title` 已够，但要有 hover 底色）
   - 滚动条 8px、圆角、hover 变亮
3. **命令面板样式**（Lead 会加 `#cmdk` 浮层，DOM 由 Lead 注入）：
   ```css
   #cmdk{position:fixed;inset:0;background:rgba(0,0,0,.35);display:flex;
         justify-content:center;padding-top:12vh;z-index:100}
   #cmdk-box{width:min(560px,92vw);max-height:60vh;background:#252526;
             border:1px solid #454545;border-radius:6px;box-shadow:0 8px 32px rgba(0,0,0,.6);
             display:flex;flex-direction:column;overflow:hidden}
   #cmdk-input{...}   /* 无边框输入框，底部 1px 分隔 */
   #cmdk-list{overflow:auto}  .cmdk-item{padding:7px 12px;cursor:pointer}
   .cmdk-item.on{background:#094771}
   .cmdk-hint{color:#8c8c8c;font-size:11px}
   ```
4. **横屏再收紧**：`(orientation:landscape) and (max-height:420px)` 时
   标题栏 28px、活动栏 36px、面板默认 140px，确保 640×360 下编辑区仍有 ≥120px 高

## 验收（Lead 卡）

- 编辑器：自动缩进/多行缩进/括号配对/注释切换/insertText 各跑一遍；**撤销不坏**
- 面板：相位图出现、PNG 能下载、十字线吸附、隐藏曲线后 y 轴重算
- 样式：侧栏可拖宽、焦点环可见、命令面板样式正确、640×360 无横向滚动
- 三方都必须 `node --check` 通过（Lead 会验）
