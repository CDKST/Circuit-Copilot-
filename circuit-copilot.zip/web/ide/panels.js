/* ------------------------------------------------------------------
 * CCL Studio 结果面板 —— 归属：ui-panel
 * 正式版：SVG 波形（对数/线性轴、多曲线、图例开关、十字线读数、降采样）
 *         + 问题列表 + 指标 + 工作点 + 网表 + 报告
 * ------------------------------------------------------------------ */

import { createPlayer, wireSwitchClicks } from './schematic.js';

const COLORS = [
  '#4fc1ff', '#f14c4c', '#d7ba7d', '#4ec9b0',
  '#c586c0', '#ce9178', '#9cdcfe', '#dcdcaa',
  '#6a9955', '#d16969', '#569cd6', '#b5cea8',
];

let _uid = 0;
function uid() { return 'p' + (++_uid); }

export function createPanels(refs) {
  const body = refs.panelBody;
  const tabs = refs.panelTabs;
  let active = 'wave';

  const data = {
    schematic: '',       // 电路图 SVG（由代码生成，只读）
    /* 开关覆盖提示条：{ owner, extra:[{cls,text}], onRestore }。
     * 由 main.js 计算（它持有覆盖状态与仿真入口），面板只负责**持久地**画出来。 */
    switchBar: null,
    schemAnim: null,     // 动画包：{ svg, timeline, kinds, switches, onSwitch }；无 timeline 就是 null
    traces: {},
    opData: null,
    kind: 'ac',
    sweepVar: '',        // dc：被扫器件位号，如 "V1"（十字线读数用）
    secondVar: '',       // dc：第二维扫描位号（可能为空）
    problems: [],
    metrics: {},
    op: {},
    netlist: '',
    report: '',
  };

  let waveHidden = new Set();
  let _ro = null;
  let _raf = 0;
  // 电路图的时间轴播放器（每次重画面板都要销毁重建，否则会留下跑着的 rAF）
  let _player = null;
  let _animSvg = '';   // 建播放器时用的那份 SVG，用来判断"图换了要不要重建"
  // renderWave() 结束时挂上来的「按当前尺寸重画」入口（最大化/还原后补一帧重排用）。
  // 它只是 hideCross() + drawWave()，几何照样由 drawWave 自己按容器算 —— 不另算一套。
  let _waveReflow = null;

  // 后端在 unit==="dB" 时给的**已经是 dB 值**，不能再转一次。
  // 踩过的坑：0dB 被当成线性幅度 0 → 20*log10(1e-30) = -600dB，整张图被压成一条竖线。
  const toY = (tr, isAC) => {
    if (!isAC) return tr.y.slice();
    if ((tr.unit || "").toLowerCase() === "db") return tr.y.slice();
    return tr.y.map(v => 20 * Math.log10(Math.max(Math.abs(v), 1e-30)));
  };

  function esc(s) {
    return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  /* ---- dc：曲线族名字 / 单位 ---- */
  // 直流扫描的第二维扫描会给每条曲线一个 label（"V2=0.6V"），
  // 图例和读数框显示 label 比显示 traces 的 key（常常只是个节点名）更有用。
  function labelOf(name) {
    const tr = data.traces ? data.traces[name] : null;
    const lab = tr && typeof tr.label === 'string' ? tr.label.trim() : '';
    return lab || name;
  }

  function unitOf(name) {
    const tr = data.traces ? data.traces[name] : null;
    return tr && typeof tr.unit === 'string' ? tr.unit.trim() : '';
  }

  /* ---- dc：把后端可能的几种 traces 形状统一成 { key: {x,y,unit,label} } ---- */
  // 兼容三种（后端还没定稿，形状换了也不至于白屏）：
  //  1) { "out": {x,y,unit,label} }                 —— 契约形状；曲线族时 key 各不相同
  //  2) { "out": [ {label,x,y}, ... ] }             —— dc_curves() 的原始列表
  //  3) { "out": { curves: [ {label,x,y}, ... ] } } —— 包了一层
  function normalizeDCTraces(raw) {
    const out = {};
    for (const name of Object.keys(raw || {})) {
      const tr = raw[name];
      if (!tr) continue;
      if (Array.isArray(tr)) {
        const many = tr.length > 1;
        tr.forEach((c, idx) => {
          if (!c || !Array.isArray(c.x) || !Array.isArray(c.y)) return;
          const lab = typeof c.label === 'string' ? c.label.trim() : '';
          const key = many ? name + (lab ? '·' + lab : '#' + (idx + 1)) : name;
          // 没有 label 的曲线族补一个 #n，否则图例里会出现三条一模一样的名字
          out[key] = { x: c.x, y: c.y, unit: c.unit || '',
                       label: lab || (many ? name + ' #' + (idx + 1) : name) };
        });
        continue;
      }
      if (Array.isArray(tr.curves)) {
        const many = tr.curves.length > 1;
        tr.curves.forEach((c, idx) => {
          if (!c || !Array.isArray(c.x) || !Array.isArray(c.y)) return;
          const lab = typeof c.label === 'string' ? c.label.trim() : '';
          const key = many ? name + (lab ? '·' + lab : '#' + (idx + 1)) : name;
          out[key] = { x: c.x, y: c.y, unit: c.unit || tr.unit || '',
                       label: lab || (many ? name + ' #' + (idx + 1) : name) };
        });
        continue;
      }
      out[name] = tr;
    }
    return out;
  }

  // dc 纵轴单位：曲线里出现单位 A 就按电流画（输出特性 Ic–Vce），否则按电压
  function dcYUnit(namesList) {
    for (const n of namesList) {
      const u = unitOf(n);
      if (u && u.toLowerCase().charAt(0) === 'a') return 'A';
    }
    return 'V';
  }

  /* ================= 面板切换 ================= */
  tabs.addEventListener('click', (e) => {
    const b = e.target.closest('[data-panel]');
    if (!b) return;
    setActive(b.dataset.panel);
  });

  // 桌面习惯：双击任意 tab → 最大化 / 还原（VS Code 同款）。
  // 双击会先触发两次 click（setActive 幂等），所以这里只管最大化状态。
  tabs.addEventListener('dblclick', (e) => {
    if (!e.target.closest('[data-panel]')) return;   // 双击右侧「收起面板」按钮不算
    maximize(!isMaximized());
  });

  function setActive(id) {
    active = id;
    let hit = null;
    [...tabs.querySelectorAll('[data-panel]')].forEach(x => {
      const on = x.dataset.panel === id;
      x.classList.toggle('on', on);
      if (on) hit = x;
    });
    // 激活的 tab 必须可见：#panel-tabs 是 overflow-x:auto 的横向滚动条，
    // tab 一多（或窗口窄）激活的可能整条在屏外，用户会以为「点了没反应」。
    // inline/block 都用 nearest：只滚最小的距离，绝不带着整页上下跳。
    if (hit && typeof hit.scrollIntoView === 'function') {
      try {
        hit.scrollIntoView({ inline: 'nearest', block: 'nearest' });
      } catch (_) {
        try { hit.scrollIntoView(false); } catch (_) { /* 老引擎兜底失败就算了 */ }
      }
    }
    render();
  }

  /* ================= 面板最大化 ================= */
  // 唯一真源是 body 上的 class（样式由 style.css 的 body.panel-max 提供）：
  // 这里不写任何尺寸，也不自己算图的高度 —— 面板一变高，
  // renderWave() 里那个 ResizeObserver 就会触发 drawWave() 按新高度重排。
  function isMaximized() {
    return document.body.classList.contains('panel-max');
  }

  function maximize(on) {
    const want = !!on;
    if (want === isMaximized()) return;   // 状态没变：不重复派发，避免监听方回调造成来回触发
    document.body.classList.toggle('panel-max', want);
    // 最大化时如果面板处于「收起」状态，会只剩标签条、正文被 display:none，
    // 这时最大化等于白屏 —— 顺手把收起状态解除（--panel-h 由 CSS 自行恢复）。
    if (want) document.body.classList.remove('panel-collapsed');
    reflowSoon();
    // 让 main.js 收状态（持久化布局用）。派发在 body 上 + bubbles，
    // 所以监听挂在 body / document / window 都能收到。
    document.body.dispatchEvent(new CustomEvent('ccl:panel-max', {
      detail: { on: want },
      bubbles: true,
    }));
  }

  // 最大化/还原后补一帧重排：等样式落到布局上再画一次。
  // 尺寸真的变了的话 ResizeObserver 自己也会触发（那是主路径），这里只兜底。
  function reflowSoon() {
    requestAnimationFrame(() => {
      if (!_waveReflow) return;
      try { _waveReflow(); } catch (_) { /* 重排失败不影响交互 */ }
    });
  }

  // Esc 还原（验收项 9）。只在最大化时动，且不 preventDefault / 不 stopPropagation，
  // 免得抢掉命令面板、电路图全屏这些同样吃 Esc 的地方。
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (isMaximized()) maximize(false);
  });

  function render() {
    cleanupWave();
    if (active !== 'schematic' && _player) destroyPlayer();
    switch (active) {
      case 'wave': renderWave(); break;
      case 'problems': renderProblems(); break;
      case 'metrics': renderMetrics(); break;
      case 'op': renderOp(); break;
      case 'schematic': renderSchematicPanel(); break;
      case 'netlist': renderNetlist(); break;
      case 'report': renderReport(); break;
    }
  }

  /* ---------------- 开关覆盖提示条 ----------------
   * 为什么必须在面板里**常驻**：开关覆盖不在代码里、也不在图上。没有这条提示，
   * 用户只看到一张不动的图，根本想不到「是我刚点了开关」；反之，看到这条就知道
   * 图上的开关状态是界面覆盖过的，并且有一个明确出口（恢复按代码运行）。
   * 面板只做呈现：清不清、重不重跑都由 main.js 的 onRestore 决定。 */
  function switchBarHtml() {
    const b = data.switchBar;
    if (!b || !b.owner) return '';
    let extra = '';
    for (const it of (b.extra || [])) {
      if (!it || !it.text) continue;
      extra += '<span class="swbar-note' + (it.cls === 'unknown' ? ' swbar-unknown' : '') + '">'
        + ' · ' + esc(it.text) + '</span>';
    }
    return '<div class="swbar" data-sw-bar role="status">'
      + '<span class="swbar-title">开关状态已被界面覆盖：</span>'
      + '<span class="swbar-owner">' + esc(b.owner) + '</span>'
      + extra
      + '<button type="button" class="swbar-btn" data-sw-restore'
      + ' title="清空界面上的开关覆盖，按代码重新仿真">恢复按代码运行</button>'
      + '</div>';
  }

  function wireSwitchBar(root) {
    const btn = root ? root.querySelector('[data-sw-restore]') : null;
    if (!btn) return;
    btn.addEventListener('click', (ev) => {
      ev.preventDefault();
      const b = data.switchBar;
      if (b && typeof b.onRestore === 'function') b.onRestore();
    });
  }

  function renderSchematicPanel() {
    // 每次重画前先拆掉旧播放器：它带着一个 requestAnimationFrame 循环，
    // 不销毁的话，切几次面板就会有 N 个循环同时改同一批 DOM。
    destroyPlayer();

    if (data.schematic) {
      // 结构：图 → 图例 → 播放条。播放条**永远在图例下面**（契约 3.2）。
      // 没有 live 数据（交流分析）时 legend 为空，就不显示 —— 不假装有工作态。
      const lg = data.schemLegend
        ? '<div class="schem-legend">' + data.schemLegend + '</div>'
        : '';
      // 提示条放在图**上面**（图会滚动，它是 position:sticky top:0，永远看得见）
      body.innerHTML = '<div class="schem-wrap">' + switchBarHtml()
        + data.schematic + lg + '</div>';
      wireSwitchBar(body);

      // 动画：只有后端给了 timeline（仅 tran）才建播放条。
      // timeline 为 null / 缺系列 / 点数不足 → createPlayer 返回 null，
      // 面板里就**一条播放条都没有**，也不会去改 SVG 的任何属性（不演假动画）。
      const an = data.schemAnim;
      if (an && an.timeline) {
        const wrap = body.querySelector('.schem-wrap');
        try {
          _player = createPlayer({
            host: wrap,
            svg: data.schematic,
            timeline: an.timeline,
            kinds: an.kinds || {},
            switches: an.switches,
            onSwitch: typeof an.onSwitch === 'function' ? an.onSwitch : null,
          });
          _animSvg = data.schematic;
        } catch (e) {
          // 动画层出问题不能让整张电路图白屏（踩过的坑：applyLive 抛异常时
          // 整块被替换成空状态，很难排查）。图照常显示，问题写进 console。
          console.warn('[anim] 播放器初始化失败', e);
          _player = null;
        }
      }
      // ⚠ 开关必须在**没有播放条时**也能点（工作点/直流分析就是这样）。
      // 早先点击处理器绑在播放器里，于是 op 分析下点开关毫无反应 —— 实测踩到。
      if (!an || !an.timeline) {
        const wrap = body.querySelector('.schem-wrap');
        const so = data.schemSwitchOpts;
        if (wrap && so && typeof so.onSwitch === 'function') {
          wireSwitchClicks(wrap, { switches: so.switches, onSwitch: so.onSwitch });
        }
      }
    } else {
      _animSvg = '';
      body.innerHTML = switchBarHtml() + '<div class="empty">运行一次电路后这里显示电路图'
        + '<br>（由代码自动生成的只读视图，不能在上面编辑）</div>';
      wireSwitchBar(body);
    }
  }

  /** 销毁播放器并把它从 DOM 里摘掉（幂等）。
   *  注意：它会被 render()/setActive()/clear() 等多个入口调用，
   *  所以不能假设播放条一定还挂在 body 下面。 */
  function destroyPlayer() {
    if (_player) {
      try { _player.destroy(); } catch (_) { /* 已经没了就算了 */ }
      _player = null;
    }
    _animSvg = '';
    const old = body.querySelector('[data-anim]');
    if (old && old.parentNode) old.parentNode.removeChild(old);
  }

  function cleanupWave() {
    if (_ro) { _ro.disconnect(); _ro = null; }
    if (_raf) { cancelAnimationFrame(_raf); _raf = 0; }
    _waveReflow = null;
  }

  /* ================= 格式化工具 ================= */
  function fmtFreq(f) {
    const a = Math.abs(f);
    if (a >= 1e9) return (f / 1e9).toFixed(2) + 'GHz';
    if (a >= 1e6) return (f / 1e6).toFixed(2) + 'MHz';
    if (a >= 1e3) return (f / 1e3).toFixed(2) + 'kHz';
    if (a >= 1) return f.toFixed(1) + 'Hz';
    return f.toExponential(2) + 'Hz';
  }

  function fmtTime(t) {
    const a = Math.abs(t);
    if (a >= 1) return t.toFixed(3) + 's';
    if (a >= 1e-3) return (t * 1e3).toFixed(3) + 'ms';
    if (a >= 1e-6) return (t * 1e6).toFixed(3) + 'µs';
    if (a >= 1e-9) return (t * 1e9).toFixed(3) + 'ns';
    return t.toExponential(2) + 's';
  }

  function fmtDb(v) { return v.toFixed(1) + 'dB'; }

  function fmtVolt(v) {
    const a = Math.abs(v);
    if (a >= 1e3) return v.toFixed(1) + 'kV';
    if (a >= 1) return v.toFixed(3) + 'V';
    if (a >= 1e-3) return (v * 1e3).toFixed(2) + 'mV';
    if (a >= 1e-6) return (v * 1e6).toFixed(2) + 'µV';
    return v.toExponential(2) + 'V';
  }

  // 读数框里去掉无意义的尾零：3.160V → 3.16V、120.000µs → 120µs
  function trimZeros(s) {
    return String(s)
      .replace(/(\.\d*?)0+(?=\D*$)/, '$1')
      .replace(/\.(?=\D*$)/, '');
  }

  function fmtNum(v) {
    if (v === null || v === undefined) return '—';
    if (typeof v !== 'number') return String(v);
    if (!isFinite(v)) return String(v);
    if (v === 0) return '0';
    const a = Math.abs(v);
    if (a >= 1e6 || a < 1e-3) return v.toExponential(4);
    return v.toPrecision(4);
  }

  function fmtAmp(v) {
    const a = Math.abs(v);
    if (a >= 1) return v.toFixed(3) + 'A';
    if (a >= 1e-3) return (v * 1e3).toFixed(3) + 'mA';
    if (a >= 1e-6) return (v * 1e6).toFixed(3) + 'µA';
    if (a >= 1e-9) return (v * 1e9).toFixed(3) + 'nA';
    return v.toExponential(2) + 'A';
  }

  /* ---- 指标卡用的「带单位」格式化（第三轮：瞬态指标）---- */

  // 指定有效位 + 去掉尾零：219.7 → "219.7"，5.000 → "5"，0.0002197 → "0.0002197"
  function sigNum(v, digits) {
    const d = digits || 4;
    if (!isFinite(v)) return String(v);
    if (v === 0) return '0';
    const a = Math.abs(v);
    // 太大或太小时 toPrecision 会退化成科学计数，直接沿用指数写法（仍带单位）
    if (a >= 1e9 || a < 1e-6) return trimZeros(v.toExponential(d - 1));
    return trimZeros(String(parseFloat(v.toPrecision(d))));
  }

  // 时间自适应：2.197e-4s → 219.7µs
  function fmtDuration(t) {
    const a = Math.abs(t);
    if (!isFinite(t)) return '—';
    if (a === 0) return '0s';
    if (a >= 1) return sigNum(t, 4) + 's';
    if (a >= 1e-3) return sigNum(t * 1e3, 4) + 'ms';
    if (a >= 1e-6) return sigNum(t * 1e6, 4) + 'µs';
    if (a >= 1e-9) return sigNum(t * 1e9, 4) + 'ns';
    return sigNum(t * 1e12, 4) + 'ps';
  }

  // 百分比：16.3 → "16.3%"
  function fmtPct(v) {
    if (!isFinite(v)) return '—';
    return v.toFixed(1) + '%';
  }

  // 工程数量级刻度文字（直流扫描轴用）：0 / 0.5 / 1 / 2 / 10 / 1k / 1m
  // 刻意不重复单位（单位放在轴末端），避免「0.000V V」这种双重标注。
  function fmtEngTick(v) {
    if (!isFinite(v)) return String(v);
    const a = Math.abs(v);
    if (a === 0) return '0';
    if (a >= 1e9) return sigNum(v / 1e9, 3) + 'G';
    if (a >= 1e6) return sigNum(v / 1e6, 3) + 'M';
    if (a >= 1e3) return sigNum(v / 1e3, 3) + 'k';
    if (a >= 1) return sigNum(v, 4);
    if (a >= 1e-3) return sigNum(v * 1e3, 3) + 'm';
    if (a >= 1e-6) return sigNum(v * 1e6, 3) + 'µ';
    if (a >= 1e-9) return sigNum(v * 1e9, 3) + 'n';
    if (a >= 1e-12) return sigNum(v * 1e12, 3) + 'p';
    return sigNum(v, 3);
  }

  // 扫描变量是电压源还是电流源（位号约定：V* → V，I* → A）
  function sweepUnitOf(name) {
    return /^i/i.test(String(name || '')) ? 'A' : 'V';
  }

  // 十字线左侧读数：V1=3.2V（带工程单位，不留裸数字）
  function fmtSweepValue(v, name) {
    const u = sweepUnitOf(name);
    const s = u === 'A' ? fmtAmp(v) : fmtVolt(v);
    return trimZeros(s);
  }

  /* ================= 降采样 ================= */
  function downsample(xArr, yArr, maxPts) {
    const n = xArr.length;
    if (n <= maxPts) return { x: xArr, y: yArr };
    const step = (n - 1) / (maxPts - 1);
    const rx = new Array(maxPts);
    const ry = new Array(maxPts);
    for (let i = 0; i < maxPts; i++) {
      const j = Math.min(Math.round(i * step), n - 1);
      rx[i] = xArr[j];
      ry[i] = yArr[j];
    }
    return { x: rx, y: ry };
  }

  /* ================= 采样点吸附 ================= */
  // 十字线必须落在**真实采样点**上，而不是浮在相邻两点之间：
  // 先用 xInv() 把像素反算成频率/时间，再二分查找最近的采样点下标。
  // 前提：arr 单调递增（AC 扫频频率、TRAN 时间轴都满足）。
  function nearestIndex(arr, x) {
    const n = arr ? arr.length : 0;
    if (!n) return -1;
    if (x <= arr[0]) return 0;
    if (x >= arr[n - 1]) return n - 1;
    let lo = 0, hi = n - 1;
    while (lo < hi - 1) {
      const mid = (lo + hi) >> 1;
      if (arr[mid] <= x) lo = mid; else hi = mid;
    }
    return (x - arr[lo]) <= (arr[hi] - x) ? lo : hi;
  }

  /* ================= 线性插值 ================= */
  // 保留：吸附失败（曲线无采样点/x 超出范围）时的兜底读数
  function lerp(xArr, yArr, xTarget) {
    const n = xArr.length;
    if (n === 0) return null;
    if (xTarget <= xArr[0]) return yArr[0];
    if (xTarget >= xArr[n - 1]) return yArr[n - 1];
    let lo = 0, hi = n - 1;
    while (lo < hi - 1) {
      const mid = (lo + hi) >> 1;
      if (xArr[mid] <= xTarget) lo = mid; else hi = mid;
    }
    const dx = xArr[hi] - xArr[lo];
    if (dx === 0) return yArr[lo];
    const t = (xTarget - xArr[lo]) / dx;
    return yArr[lo] + t * (yArr[hi] - yArr[lo]);
  }

  /* ================= Nice Scale ================= */
  function niceNum(range, round) {
    if (range <= 0) return 1;
    const exp = Math.floor(Math.log10(range));
    const frac = range / Math.pow(10, exp);
    let nice;
    if (round) {
      if (frac < 1.5) nice = 1;
      else if (frac < 3) nice = 2;
      else if (frac < 7) nice = 5;
      else nice = 10;
    } else {
      if (frac <= 1) nice = 1;
      else if (frac <= 2) nice = 2;
      else if (frac <= 5) nice = 5;
      else nice = 10;
    }
    return nice * Math.pow(10, exp);
  }

  function linearTicks(min, max, maxTicks) {
    if (max <= min) { min -= 1; max += 1; }
    const range = niceNum(max - min, false);
    const spacing = niceNum(range / (maxTicks - 1), true);
    const nMin = Math.floor(min / spacing) * spacing;
    const nMax = Math.ceil(max / spacing) * spacing;
    const ticks = [];
    for (let v = nMin; v <= nMax + spacing * 0.01; v += spacing) {
      ticks.push(parseFloat(v.toPrecision(12)));
    }
    return { min: nMin, max: nMax, ticks, spacing };
  }

  function logTickValues(min, max) {
    if (min <= 0) min = 1e-30;
    const eMin = Math.floor(Math.log10(min));
    const eMax = Math.ceil(Math.log10(max));
    const ticks = [];
    for (let e = eMin; e <= eMax; e++) {
      ticks.push(Math.pow(10, e));
    }
    if (ticks.length < 3) {
      // 范围太小，退化为线性等分
      return linearTicks(min, max, 4).ticks;
    }
    return ticks;
  }

  /* ================= 导出：SVG → PNG（失败退 .svg） ================= */
  // 导出后的 SVG 是独立文档，拿不到页面 CSS：靠 class/继承来的 fill/stroke/font-size
  // 必须逐元素内联成属性，否则导出的图是透明的（文字/线全消失）。
  const SVGNS = 'http://www.w3.org/2000/svg';
  const EXPORT_BG = '#0a0d12';
  const INLINE_PROPS = [
    'fill', 'fill-opacity', 'stroke', 'stroke-width', 'stroke-opacity',
    'stroke-dasharray', 'stroke-linejoin', 'stroke-linecap', 'opacity',
    'visibility', 'font-size', 'font-family', 'font-weight', 'text-anchor',
  ];

  /** 把 srcRoot 上「计算后」的样式写进结构相同的 cloneRoot */
  function inlineComputedStyles(srcRoot, cloneRoot) {
    const srcEls = [srcRoot].concat(Array.from(srcRoot.querySelectorAll('*')));
    const dstEls = [cloneRoot].concat(Array.from(cloneRoot.querySelectorAll('*')));
    const n = Math.min(srcEls.length, dstEls.length);
    for (let i = 0; i < n; i++) {
      const s = srcEls[i], d = dstEls[i];
      if (!s || !d || d.nodeType !== 1) continue;
      let cs = null;
      try { cs = window.getComputedStyle(s); } catch (_) { continue; }
      if (!cs) continue;
      for (let k = 0; k < INLINE_PROPS.length; k++) {
        const p = INLINE_PROPS[k];
        const v = cs.getPropertyValue(p);
        if (v) d.setAttribute(p, String(v).trim());
      }
    }
  }

  function b64Encode(str) {
    const bytes = new TextEncoder().encode(str);
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }

  function stamp() {
    const d = new Date();
    const p = (v) => String(v).padStart(2, '0');
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-'
      + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
  }

  /** <a download> 触发下载；返回 true 表示点击已发出（不代表文件真的落盘） */
  function triggerDownload(href, filename) {
    const a = document.createElement('a');
    a.href = href;
    a.download = filename;
    a.rel = 'noopener';
    a.style.cssText = 'position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0;';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { try { a.remove(); } catch (_) {} }, 5000);
    return true;
  }

  /* ================= 波形图 ================= */
  const PHASE_MIN = -180;
  const PHASE_MAX = 0;

  function renderWave() {
    const traces = data.traces;
    const names = Object.keys(traces);

    if (!names.length) {
      body.innerHTML = '<div class="empty">运行一次电路后这里显示波形。</div>';
      return;
    }

    body.innerHTML = '';
    const container = document.createElement('div');
    container.style.cssText = 'display:flex;flex-direction:column;height:100%;overflow:hidden;position:relative;';

    /* ---- 右上角「⤓ PNG」（容器第一个子元素的右上角，绝对定位）---- */
    // class 给 style.css 的 .pv-export 用；下面这段 cssText 是「样式到位前」的内联兜底。
    // ⚠️ 内联优先级高于 class —— desk-shell 要统一视觉就告诉我，或用自己的选择器压过去。
    const pngBtn = document.createElement('button');
    pngBtn.type = 'button';
    pngBtn.className = 'pv-export';
    pngBtn.textContent = '⤓ PNG';
    pngBtn.title = '把当前波形导出为 PNG（解码失败时自动改导出 SVG）';
    pngBtn.style.cssText = 'position:absolute;right:6px;top:3px;z-index:7;'
      + 'font:11px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;'
      + 'padding:1px 7px;border:1px solid #3c3c3c;border-radius:3px;'
      + 'background:#2d2d2d;color:#ccc;cursor:pointer;';
    container.appendChild(pngBtn);

    const hintEl = document.createElement('div');
    hintEl.style.cssText = 'position:absolute;right:6px;top:25px;z-index:7;display:none;'
      + 'max-width:70%;padding:2px 6px;border-radius:3px;background:rgba(30,30,30,.94);'
      + 'border:1px solid #3c3c3c;color:#d7ba7d;font-size:10.5px;line-height:1.5;'
      + 'pointer-events:none;white-space:pre-wrap;';
    container.appendChild(hintEl);

    const svgWrap = document.createElement('div');
    svgWrap.style.cssText = 'flex:1;min-height:0;position:relative;overflow:hidden;'
      + 'display:flex;flex-direction:column;';
    container.appendChild(svgWrap);

    const mainHost = document.createElement('div');
    mainHost.style.cssText = 'position:relative;overflow:hidden;flex:0 0 auto;';
    svgWrap.appendChild(mainHost);

    const phaseHost = document.createElement('div');
    phaseHost.style.cssText = 'position:relative;overflow:hidden;flex:0 0 auto;display:none;';
    svgWrap.appendChild(phaseHost);

    // 十字线读数用 HTML 浮层（比 SVG 内画 tooltip 简单，且不会进导出图）
    const tip = document.createElement('div');
    tip.style.cssText = 'position:absolute;left:0;top:0;display:none;z-index:6;pointer-events:none;'
      + 'background:rgba(30,30,30,.94);border:1px solid #555;border-radius:3px;padding:3px 6px;'
      + 'font:10px/13px ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;color:#ccc;';
    svgWrap.appendChild(tip);

    // 跟随指针的数值气泡（只报「指针正压着的那条曲线」，避免读数框一行挤满）
    // 视觉交给 style.css 的 .wv-tip；这里只留 JS 必须算的 left/top/display 和曲线色。
    const bubble = document.createElement('div');
    bubble.className = 'wv-tip';
    bubble.style.cssText = 'position:absolute;left:0;top:0;display:none;z-index:7;pointer-events:none;';
    svgWrap.appendChild(bubble);

    const legend = document.createElement('div');
    // 折行 + 不撑破面板：
    //  - flex-wrap:wrap 让多曲线换行（原本就有）；
    //  - min-width:0 / max-width:100% / overflow-x:hidden / box-sizing:border-box
    //    保证永远不产生横向溢出（scrollWidth <= clientWidth）；
    //  - 高度最多吃容器的 40%，超了就在图例框内部竖向滚动 —— 这样哪怕 10 条曲线
    //    也不会把波形区挤没（下边 svgWrap 是 flex:1 min-height:0，会被压缩到 0 而白屏）。
    legend.style.cssText = 'display:flex;flex-wrap:wrap;align-content:flex-start;gap:2px 10px;'
      + 'padding:3px 8px;font-size:11px;flex-shrink:0;flex-grow:0;'
      + 'min-width:0;max-width:100%;box-sizing:border-box;'
      + 'overflow-x:hidden;overflow-y:auto;max-height:40%;';
    legend.setAttribute('data-role', 'legend');
    container.appendChild(legend);

    body.appendChild(container);

    /* ---- 闭包状态（每次 drawWave 重建）---- */
    let mainSvg = null, phaseSvg = null;
    let chMainG = null, chMainLine = null, chDotsMain = null;
    let chPhaseG = null, chPhaseLine = null, chDotsPhase = null;
    let isAC = false, isDC = false, hasPhase = false;
    let visTraces = [], phaseTraces = [];
    let snapX = null;            // 吸附参考轴（可见曲线里点数最多那条的原始 x 数组）
    let geo = null;

    function el(tag, attrs) {
      const e = document.createElementNS(SVGNS, tag);
      if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]);
      return e;
    }

    /** 面板右上角一行提示；可选带一个「补救」动作链接 */
    function showHint(msg, isErr, actionLabel, actionFn) {
      while (hintEl.firstChild) hintEl.removeChild(hintEl.firstChild);
      hintEl.style.color = isErr ? '#f14c4c' : '#d7ba7d';
      hintEl.style.display = 'block';
      hintEl.style.pointerEvents = actionLabel ? 'auto' : 'none';
      hintEl.appendChild(document.createTextNode(msg));
      if (actionLabel && actionFn) {
        const a = document.createElement('a');
        a.textContent = ' ' + actionLabel;
        a.style.cssText = 'color:#4fc1ff;cursor:pointer;text-decoration:underline;';
        a.onclick = (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          try { actionFn(); } catch (e) { /* 兜底动作失败就算了 */ }
        };
        hintEl.appendChild(a);
      }
      if (showHint._t) clearTimeout(showHint._t);
      showHint._t = setTimeout(() => { hintEl.style.display = 'none'; }, 25000);
    }

    function renderLegend() {
      legend.innerHTML = '';
      names.forEach((name, i) => {
        const color = COLORS[i % COLORS.length];
        const hidden = waveHidden.has(name);
        const span = document.createElement('span');
        // flex:0 1 auto + min-width:0 允许条目被压缩（名字再长也不会顶出横向滚动）
        span.style.cssText = 'cursor:pointer;display:inline-flex;align-items:center;gap:4px;'
          + 'flex:0 1 auto;min-width:0;max-width:100%;'
          + 'user-select:none;opacity:' + (hidden ? 0.35 : 1) + ';';
        span.setAttribute('data-trace', name);
        const swatch = document.createElement('span');
        swatch.style.cssText = 'display:inline-block;width:14px;height:3px;border-radius:1px;'
          + 'flex:0 0 auto;background:' + (hidden ? '#555' : color) + ';';
        span.appendChild(swatch);
        const nameSpan = document.createElement('span');
        nameSpan.style.cssText = 'min-width:0;overflow-wrap:anywhere;';
        nameSpan.textContent = labelOf(name);   // dc 曲线族显示后端给的 label
        span.appendChild(nameSpan);
        span.onclick = () => {
          if (waveHidden.has(name)) waveHidden.delete(name);
          else waveHidden.add(name);
          renderLegend();
          drawWave();   // 隐藏/显示后 y 轴范围要按新的可见集合重算并重绘
        };
        legend.appendChild(span);
      });
    }

    /* ---- 刻度文字：dc 走线性工程刻度（0 / 0.5 / 1 / 2），单位标在轴末端 ---- */
    function xTickText(v) {
      if (isAC) return fmtFreq(v);
      if (isDC) return fmtEngTick(v);
      return fmtTime(v);
    }

    function yTickText(v) {
      if (isAC) return fmtDb(v);
      if (isDC) return fmtEngTick(v);
      return fmtVolt(v);
    }

    // dc 横轴末端标注：V1 (V) —— 让「0/0.5/1」知道是伏还是安
    function dcXLabel() {
      const u = sweepUnitOf(data.sweepVar);
      return data.sweepVar ? data.sweepVar + ' (' + u + ')' : u;
    }

    /* ------------------- 主绘制 ------------------- */
    function drawWave() {
      const W = svgWrap.clientWidth;
      const H = svgWrap.clientHeight;
      if (W < 20 || H < 20) return;

      const kind = data.kind;
      isAC = kind === 'ac';
      isDC = kind === 'dc';   // 直流扫描：x 线性、y 线性、无相位副图

      if (kind === 'op') {
        mainSvg = null; phaseSvg = null; geo = null;
        mainHost.style.height = Math.max(40, H) + 'px';
        mainHost.innerHTML = '<div class="empty" style="padding:20px">直流工作点无波形，请查看「工作点」面板。</div>';
        phaseHost.style.display = 'none';
        phaseHost.innerHTML = '';
        return;
      }

      /* 副图存在性：AC 且至少一条曲线带 phase（与隐藏状态无关，避免开关图例时布局跳动） */
      hasPhase = isAC && names.some(n => traces[n] && Array.isArray(traces[n].phase) && traces[n].phase.length > 1);
      // 副图高约主图的 1/3：上限给主图留够 64px，下限保证 −180/−90/0 刻度放得下
      const phaseH = hasPhase
        ? Math.max(46, Math.min(Math.round(H * 0.34), H - 64))
        : 0;
      const mainH = H - phaseH;

      mainHost.style.display = 'block';
      mainHost.style.height = mainH + 'px';
      phaseHost.style.display = hasPhase ? 'block' : 'none';
      phaseHost.style.height = (hasPhase ? phaseH : 0) + 'px';

      const mL = 54, mR = 16;
      const mTop = 12;
      const mBotMain = hasPhase ? 10 : 26;
      const pw = W - mL - mR;
      const phMain = mainH - mTop - mBotMain;
      if (pw < 10 || phMain < 10) return;
      const mTopPhase = 5, mBotPhase = 19;
      const phPhase = hasPhase ? phaseH - mTopPhase - mBotPhase : 0;
      const drawPhase = hasPhase && phPhase >= 12;

      /* ---- 范围：只统计「可见」曲线（waveHidden 之外、有数据）---- */
      const visible = names.filter(n => !waveHidden.has(n) && traces[n] && traces[n].x && traces[n].x.length);
      const rangeNames = visible.length
        ? visible
        : names.filter(n => traces[n] && traces[n].x && traces[n].x.length);

      if (!rangeNames.length) {
        mainSvg = null; phaseSvg = null; geo = null;
        mainHost.innerHTML = '<div class="empty">无数据。</div>';
        phaseHost.style.display = 'none';
        return;
      }

      let xMin = Infinity, xMax = -Infinity, yMin = Infinity, yMax = -Infinity;
      for (const name of rangeNames) {
        const tr = traces[name];
        for (let i = 0; i < tr.x.length; i++) {
          if (tr.x[i] < xMin) xMin = tr.x[i];
          if (tr.x[i] > xMax) xMax = tr.x[i];
        }
        const yArr = toY(tr, isAC);
        for (let i = 0; i < yArr.length; i++) {
          const v = yArr[i];
          if (!isFinite(v)) continue;
          if (v < yMin) yMin = v;
          if (v > yMax) yMax = v;
        }
      }
      if (!isFinite(xMin) || !isFinite(yMin)) {
        mainSvg = null; phaseSvg = null; geo = null;
        mainHost.innerHTML = '<div class="empty">无数据。</div>';
        phaseHost.style.display = 'none';
        return;
      }

      // Y padding（全平的曲线也要有可视范围）
      const span0 = yMax - yMin;
      const pad = span0 > 1e-12 ? span0 * 0.06 : (Math.abs(yMax) * 0.1 || 1);
      yMin -= pad;
      yMax += pad;
      if (yMax - yMin < 1e-12) { yMin -= 1; yMax += 1; }

      /* ---- X 映射（主图与副图共用同一套，保证共享 x 轴）---- */
      let mapX, xInv;
      if (isAC) {
        const lxMin = Math.log10(Math.max(xMin, 1e-30));
        const lxMax = Math.log10(Math.max(xMax, 1e-30));
        const lxRange = lxMax - lxMin || 1;
        mapX = (x) => mL + (Math.log10(Math.max(x, 1e-30)) - lxMin) / lxRange * pw;
        xInv = (px) => Math.pow(10, lxMin + (px - mL) / pw * lxRange);
      } else {
        const xRange = xMax - xMin || 1;
        mapX = (x) => mL + (x - xMin) / xRange * pw;
        xInv = (px) => xMin + (px - mL) / pw * xRange;
      }

      /* ---- Y 映射 ---- */
      const ySpan = yMax - yMin || 1;
      const mapY = (y) => mTop + (1 - (y - yMin) / ySpan) * phMain;
      const mapYPhase = (v) => {
        const c = Math.min(PHASE_MAX, Math.max(PHASE_MIN, v));
        const t = (c - PHASE_MIN) / (PHASE_MAX - PHASE_MIN);
        return mTopPhase + (1 - t) * phPhase;
      };

      const xTicks = isAC ? logTickValues(xMin, xMax) : linearTicks(xMin, xMax, 5).ticks;
      const maxPts = Math.max(200, pw * 2);

      /* ================= 主图 ================= */
      visTraces = [];
      phaseTraces = [];
      snapX = null;

      const id = uid();
      const svg = el('svg', { width: W, height: mainH, viewBox: '0 0 ' + W + ' ' + mainH });
      svg.style.display = 'block';
      svg.setAttribute('data-role', 'main');
      mainSvg = svg;

      const defs = el('defs');
      const clip = el('clipPath', { id: 'clip-' + id });
      clip.appendChild(el('rect', { x: mL, y: mTop, width: pw, height: phMain }));
      defs.appendChild(clip);
      svg.appendChild(defs);

      svg.appendChild(el('rect', { x: mL, y: mTop, width: pw, height: phMain, fill: '#1a1a1a' }));

      // y 刻度：nice 算法有时只落进 2 个刻度，试几档上限，取「在可视范围内最多又不挤」的一档
      let yScale = null;
      for (const want of [5, 6, 4, 7, 8]) {
        const sc = linearTicks(yMin, yMax, want);
        const inside = sc.ticks.filter(v => v >= yMin && v <= yMax);
        if (inside.length >= 2) {
          const gap = phMain / Math.max(1, inside.length - 1);
          if (gap >= 14) { yScale = sc; break; }
        }
        if (!yScale && inside.length >= 2) yScale = sc;   // 兜底：先留住一个能用的
      }
      if (!yScale) yScale = linearTicks(yMin, yMax, 4);

      const gridG = el('g', { stroke: '#333', 'stroke-width': 0.5 });
      for (const xv of xTicks) {
        const px = mapX(xv);
        if (px < mL - 0.5 || px > mL + pw + 0.5) continue;
        gridG.appendChild(el('line', { x1: px, x2: px, y1: mTop, y2: mTop + phMain }));
      }
      for (const yv of yScale.ticks) {
        const py = mapY(yv);
        if (py < mTop - 0.5 || py > mTop + phMain + 0.5) continue;
        gridG.appendChild(el('line', { x1: mL, x2: mL + pw, y1: py, y2: py }));
      }
      svg.appendChild(gridG);

      svg.appendChild(el('rect', {
        x: mL, y: mTop, width: pw, height: phMain,
        fill: 'none', stroke: '#555', 'stroke-width': 0.5,
      }));

      const labelG = el('g', {
        fill: '#8c8c8c', 'font-size': '10',
        'font-family': 'ui-monospace,SFMono-Regular,Menlo,Consolas,monospace',
      });
      // x 刻度文字：有相位副图时放到副图下方（共享 x 轴就只标一次）
      if (!hasPhase) {
        for (const xv of xTicks) {
          const px = mapX(xv);
          if (px < mL - 0.5 || px > mL + pw + 0.5) continue;
          const t = el('text', { x: px, y: mTop + phMain + 14, 'text-anchor': 'middle' });
          t.textContent = xTickText(xv);
          labelG.appendChild(t);
        }
      }
      for (const yv of yScale.ticks) {
        const py = mapY(yv);
        if (py < mTop - 0.5 || py > mTop + phMain + 0.5) continue;
        const t = el('text', { x: mL - 4, y: py + 3.5, 'text-anchor': 'end' });
        t.textContent = yTickText(yv);
        labelG.appendChild(t);
      }
      const unitLabel = el('text', {
        x: mL + pw - 2, y: mTop - 3, 'text-anchor': 'end', fill: '#666', 'font-size': '9',
      });
      unitLabel.textContent = isAC ? 'dB' : (isDC ? dcYUnit(rangeNames) : 'V');
      labelG.appendChild(unitLabel);
      if (!hasPhase) {
        const xu = el('text', {
          x: mL + pw, y: mTop + phMain + 24, 'text-anchor': 'end', fill: '#666', 'font-size': '9',
        });
        xu.textContent = isAC ? 'Hz' : (isDC ? dcXLabel() : 's');
        labelG.appendChild(xu);
      }
      svg.appendChild(labelG);

      const curvesG = el('g', { 'clip-path': 'url(#clip-' + id + ')' });
      names.forEach((name, idx) => {
        if (waveHidden.has(name)) return;
        const tr = traces[name];
        if (!tr || !tr.x || !tr.x.length) return;
        const color = COLORS[idx % COLORS.length];

        const yArr = toY(tr, isAC);
        const ds = downsample(tr.x, yArr, maxPts);
        // rx/ry/rp = **未降采样**的原始采样点，专门给十字线吸附 & 取精确值用
        // （降采样后点数变少，可能丢掉离鼠标最近的那个真实采样点）
        visTraces.push({
          name, x: ds.x, y: ds.y, color, rx: tr.x, ry: yArr,
          label: labelOf(name), unit: tr.unit || '',
        });

        let d = '';
        for (let i = 0; i < ds.x.length; i++) {
          d += (i === 0 ? 'M' : 'L') + mapX(ds.x[i]).toFixed(1) + ',' + mapY(ds.y[i]).toFixed(1);
        }
        curvesG.appendChild(el('path', {
          d, stroke: color, 'stroke-width': 1.5, fill: 'none',
          'stroke-linejoin': 'round', 'data-trace': name,
        }));

        // 相位采样（与主图同一套降采样索引 → x 完全对齐）
        if (drawPhase && Array.isArray(tr.phase) && tr.phase.length === tr.x.length) {
          const dp = downsample(tr.x, tr.phase, maxPts);
          phaseTraces.push({ name, x: dp.x, y: dp.y, color, rx: tr.x, ry: tr.phase });
        }
      });
      svg.appendChild(curvesG);

      // 吸附参考轴：取可见曲线中点数最多的一条的原始 x。
      // 后端 AC/TRAN 各曲线共用同一 x 网格（ccl_api 里 xs 只算一次），
      // 所以这一条就代表了整张图的采样点位置。
      for (const vt of visTraces) {
        if (vt.rx && vt.rx.length && (!snapX || vt.rx.length > snapX.length)) snapX = vt.rx;
      }

      chMainG = el('g', { visibility: 'hidden' });
      chMainLine = el('line', { stroke: '#aaa', 'stroke-width': 0.5, 'stroke-dasharray': '3,2' });
      chMainG.appendChild(chMainLine);
      chDotsMain = el('g');
      chMainG.appendChild(chDotsMain);
      svg.appendChild(chMainG);

      /* ================= 相位副图 ================= */
      if (drawPhase) {
        const id2 = uid();
        const s2 = el('svg', { width: W, height: phaseH, viewBox: '0 0 ' + W + ' ' + phaseH });
        s2.style.display = 'block';
        s2.setAttribute('data-role', 'phase');
        phaseSvg = s2;

        const defs2 = el('defs');
        const clip2 = el('clipPath', { id: 'clip-' + id2 });
        clip2.appendChild(el('rect', { x: mL, y: mTopPhase, width: pw, height: phPhase }));
        defs2.appendChild(clip2);
        s2.appendChild(defs2);

        s2.appendChild(el('rect', { x: mL, y: mTopPhase, width: pw, height: phPhase, fill: '#161616' }));

        const g2 = el('g', { stroke: '#333', 'stroke-width': 0.5 });
        for (const xv of xTicks) {
          const px = mapX(xv);
          if (px < mL - 0.5 || px > mL + pw + 0.5) continue;
          g2.appendChild(el('line', { x1: px, x2: px, y1: mTopPhase, y2: mTopPhase + phPhase }));
        }
        for (const yv of [PHASE_MIN, -90, PHASE_MAX]) {
          const py = mapYPhase(yv);
          g2.appendChild(el('line', { x1: mL, x2: mL + pw, y1: py, y2: py }));
        }
        s2.appendChild(g2);

        s2.appendChild(el('rect', {
          x: mL, y: mTopPhase, width: pw, height: phPhase,
          fill: 'none', stroke: '#555', 'stroke-width': 0.5,
        }));

        const lab2 = el('g', {
          fill: '#8c8c8c', 'font-size': '10',
          'font-family': 'ui-monospace,SFMono-Regular,Menlo,Consolas,monospace',
        });
        for (const yv of [PHASE_MIN, -90, PHASE_MAX]) {
          const py = mapYPhase(yv);
          const t = el('text', { x: mL - 4, y: py + 3.5, 'text-anchor': 'end' });
          t.textContent = yv + '°';
          lab2.appendChild(t);
        }
        for (const xv of xTicks) {
          const px = mapX(xv);
          if (px < mL - 0.5 || px > mL + pw + 0.5) continue;
          const t = el('text', { x: px, y: mTopPhase + phPhase + 13, 'text-anchor': 'middle' });
          t.textContent = xTickText(xv);
          lab2.appendChild(t);
        }
        // 单位标记放在左侧 y 刻度列上方，不占副图内部空间
        const phTag = el('text', {
          x: mL - 4, y: mTopPhase + 7, 'text-anchor': 'end',
          fill: '#666', 'font-size': '9',
        });
        phTag.textContent = '°';
        lab2.appendChild(phTag);
        s2.appendChild(lab2);

        const cg2 = el('g', { 'clip-path': 'url(#clip-' + id2 + ')' });
        for (const pt of phaseTraces) {
          let d = '';
          for (let i = 0; i < pt.x.length; i++) {
            d += (i === 0 ? 'M' : 'L')
              + mapX(pt.x[i]).toFixed(1) + ',' + mapYPhase(pt.y[i]).toFixed(1);
          }
          cg2.appendChild(el('path', {
            d, stroke: pt.color, 'stroke-width': 1.5, fill: 'none',
            'stroke-linejoin': 'round', 'data-trace-phase': pt.name,
          }));
        }
        s2.appendChild(cg2);

        chPhaseG = el('g', { visibility: 'hidden' });
        chPhaseLine = el('line', { stroke: '#aaa', 'stroke-width': 0.5, 'stroke-dasharray': '3,2' });
        chPhaseG.appendChild(chPhaseLine);
        chDotsPhase = el('g');
        chPhaseG.appendChild(chDotsPhase);
        s2.appendChild(chPhaseG);
      } else {
        phaseSvg = null;
        chPhaseG = null; chPhaseLine = null; chDotsPhase = null;
      }

      /* ---- 挂载 ---- */
      mainHost.innerHTML = '';
      mainHost.appendChild(svg);
      phaseHost.innerHTML = '';
      if (phaseSvg) phaseHost.appendChild(phaseSvg);

      geo = {
        W, H, mL, pw, mainH, mainT: mTop, mainPlotH: phMain,
        phaseT: drawPhase ? mainH + mTopPhase : 0,
        phasePlotH: drawPhase ? phPhase : 0,
        hasPhase: drawPhase,
        xInv, mapX, mapY, mapYPhase,
        snapX,                       // 原始 x 采样点数组（吸附目标）
      };
    }

    /* ------------------- 十字线（主图 + 副图共享一根竖线）------------------- */
    function hideCross() {
      if (chMainG) chMainG.setAttribute('visibility', 'hidden');
      if (chPhaseG) chPhaseG.setAttribute('visibility', 'hidden');
      if (tip) tip.style.display = 'none';
      if (bubble) bubble.style.display = 'none';
    }

    function clearDots(g) {
      if (!g) return;
      while (g.firstChild) g.removeChild(g.firstChild);
    }

    // 每条曲线的读数：曲线名/label + 带工程单位的数值
    // dc 的曲线族 label 自带「=」（V2=0.6V），此时用空格分隔，避免连出两个等号
    function rowText(vt, yVal) {
      const u = String(vt.unit || '').toLowerCase();
      const val = u.charAt(0) === 'a' ? trimZeros(fmtAmp(yVal)) : trimZeros(fmtVolt(yVal));
      if (isAC) return vt.name + '=' + fmtDb(yVal);
      const lab = vt.label || vt.name;
      return lab.indexOf('=') >= 0 ? lab + '  ' + val : lab + '=' + val;
    }

    // 气泡文案：「节点名 数值 单位」。数值是吸附后的**真实采样点**值，不是像素插值。
    // 单位优先级：曲线自带 unit → dc 按曲线族判定（A/V）→ 瞬态按 V。
    function dotText(name, yVal) {
      const sep = name.indexOf('=') >= 0 ? '  ' : ' ';   // dc 的 "V2=0.6V" 不要再连等号
      if (isAC) return name + sep + fmtDb(yVal);
      const u = unitOf(name).toLowerCase();
      const eff = u ? u.charAt(0) : (isDC ? dcYUnit([name]).toLowerCase() : 'v');
      return name + sep + trimZeros(eff === 'a' ? fmtAmp(yVal) : fmtVolt(yVal));
    }

    function onPointerMove(ev) {
      if (!geo || !mainSvg) return;
      const r = svgWrap.getBoundingClientRect();
      const px = ev.clientX - r.left;
      const py = ev.clientY - r.top;

      const inMain = py >= geo.mainT && py <= geo.mainT + geo.mainPlotH;
      const inPhase = geo.hasPhase && py >= geo.phaseT && py <= geo.phaseT + geo.phasePlotH;

      if (px < geo.mL || px > geo.mL + geo.pw || (!inMain && !inPhase)) { hideCross(); return; }

      // ① 像素 → 频率/时间（这个值只用来「找最近的采样点」，不直接显示）
      const xRaw = geo.xInv(Math.max(geo.mL, Math.min(geo.mL + geo.pw, px)));

      // ② 吸附：在原始采样点数组上二分，取最近的采样点
      const ref = geo.snapX;
      let si = -1;
      let xVal = xRaw;
      if (ref && ref.length) {
        si = nearestIndex(ref, xRaw);
        if (si >= 0) xVal = ref[si];
      }

      // ③ 竖线画在**采样点**的像素位置（不是鼠标位置）
      const sx = Math.max(geo.mL, Math.min(geo.mL + geo.pw, geo.mapX(xVal)));

      chMainG.setAttribute('visibility', 'visible');
      chMainLine.setAttribute('x1', sx); chMainLine.setAttribute('x2', sx);
      chMainLine.setAttribute('y1', geo.mainT); chMainLine.setAttribute('y2', geo.mainT + geo.mainPlotH);
      // 便于外部/自测核对：吸附后的采样点 x 与下标
      chMainLine.setAttribute('data-x', String(xVal));
      chMainLine.setAttribute('data-idx', String(si));

      if (chPhaseG && chPhaseLine) {
        chPhaseG.setAttribute('visibility', 'visible');
        chPhaseLine.setAttribute('x1', sx); chPhaseLine.setAttribute('x2', sx);
        chPhaseLine.setAttribute('y1', geo.phaseT);
        chPhaseLine.setAttribute('y2', geo.phaseT + geo.phasePlotH);
      }

      clearDots(chDotsMain);
      clearDots(chDotsPhase);

      // 读数：每条曲线取**该采样点的精确 y**，不再做插值
      const rows = [];

      // 气泡候选：屏幕纵坐标离指针最近的那个采样点（只在该图区间内参与比较）
      let near = null, nearD = Infinity;

      for (const vt of visTraces) {
        const i = (vt.rx && vt.rx.length) ? nearestIndex(vt.rx, xVal) : -1;
        let yVal = null, cx = sx;
        if (i >= 0) {
          yVal = vt.ry[i];
          cx = geo.mapX(vt.rx[i]);
        } else {                       // 兜底：没有原始采样点时退回插值
          yVal = lerp(vt.x, vt.y, xVal);
        }
        if (yVal === null || !isFinite(yVal)) continue;
        const cyMain = geo.mapY(yVal);
        chDotsMain.appendChild(el('circle', {
          cx: Math.max(geo.mL, Math.min(geo.mL + geo.pw, cx)),
          cy: cyMain, r: 3, fill: vt.color, stroke: '#1e1e1e', 'stroke-width': 1,
        }));
        rows.push({ text: rowText(vt, yVal), color: vt.color });
        if (inMain) {
          const dd = Math.abs(cyMain - py);
          if (dd < nearD) {
            nearD = dd;
            near = { text: dotText(vt.label || vt.name, yVal), color: vt.color };
          }
        }
      }

      let nearP = null, nearPD = Infinity;

      for (const pt of phaseTraces) {
        const i = (pt.rx && pt.rx.length) ? nearestIndex(pt.rx, xVal) : -1;
        let pVal = null, cx = sx;
        if (i >= 0) {
          pVal = pt.ry[i];
          cx = geo.mapX(pt.rx[i]);
        } else {
          pVal = lerp(pt.x, pt.y, xVal);
        }
        if (pVal === null || !isFinite(pVal)) continue;
        const cyPhase = geo.mapYPhase(pVal);
        chDotsPhase.appendChild(el('circle', {
          cx: Math.max(geo.mL, Math.min(geo.mL + geo.pw, cx)),
          cy: cyPhase, r: 3, fill: pt.color, stroke: '#1e1e1e', 'stroke-width': 1,
        }));
        rows.push({ text: '∠' + pt.name + '=' + pVal.toFixed(1) + '°', color: pt.color });
        if (inPhase) {
          const dd = Math.abs(cyPhase - py);
          if (dd < nearPD) {
            nearPD = dd;
            nearP = { text: pt.name + ' ' + pVal.toFixed(1) + '°', color: pt.color };
          }
        }
      }

      // ④ 读数框：一行 —— 「1.00kHz  out=-3.2dB  in=0.0dB」
      const xText = isAC ? fmtFreq(xVal)
        : (isDC
          ? (data.sweepVar || 'x') + '=' + fmtSweepValue(xVal, data.sweepVar)
          : trimZeros(fmtTime(xVal)));
      while (tip.firstChild) tip.removeChild(tip.firstChild);
      const lineBox = document.createElement('div');
      lineBox.style.cssText = 'white-space:pre-wrap;word-break:break-word;';
      const xSpan = document.createElement('span');
      xSpan.style.color = '#ccc';
      xSpan.textContent = xText;
      lineBox.appendChild(xSpan);
      for (const row of rows) {
        lineBox.appendChild(document.createTextNode('  '));
        const sp = document.createElement('span');
        sp.style.color = row.color;
        sp.textContent = row.text;
        lineBox.appendChild(sp);
      }
      tip.appendChild(lineBox);
      tip.dataset.x = String(xVal);       // 精确采样点值（自测用）
      tip.dataset.idx = String(si);
      tip.style.display = 'block';

      const tw = tip.offsetWidth, th = tip.offsetHeight;
      let tx = sx + 12;
      if (tx + tw > geo.W - 4) tx = sx - tw - 8;
      if (tx < 4) tx = 4;
      let ty = py - th / 2;
      if (ty < 2) ty = 2;
      if (ty + th > geo.H - 2) ty = geo.H - th - 2;
      tip.style.left = Math.round(tx) + 'px';
      tip.style.top = Math.round(ty) + 'px';

      // ⑤ 跟随指针的数值气泡：只报「指针压得最近的那条曲线」，横向让开读数框
      const cand = inMain ? near : nearP;
      if (!cand) {
        bubble.style.display = 'none';
        return;
      }
      bubble.textContent = cand.text;
      bubble.style.color = cand.color;      // 曲线色（与图例一致）；底/边框交给 .wv-tip
      bubble.style.display = 'block';
      bubble.dataset.x = String(xVal);      // 吸附后的采样点值（自测用）
      bubble.dataset.idx = String(si);

      const bw = bubble.offsetWidth, bh = bubble.offsetHeight;
      let bx = px + 14;
      if (bx + bw > geo.W - 4) bx = px - bw - 14;
      if (bx < 4) bx = 4;
      let by = py + 16;
      if (by + bh > geo.H - 2) by = py - bh - 16;
      if (by < 2) by = 2;
      bubble.style.left = Math.round(bx) + 'px';
      bubble.style.top = Math.round(by) + 'px';
    }

    svgWrap.addEventListener('pointermove', onPointerMove);
    svgWrap.addEventListener('pointerleave', hideCross);
    svgWrap.addEventListener('pointercancel', hideCross);

    /* ------------------- 导出 ------------------- */
    /** 把主图 + 相位副图拼成一张独立 SVG（内联样式 + 硬底色） */
    function buildExportSvg(scale) {
      const W = Math.max(1, Math.round(svgWrap.clientWidth));
      const H = Math.max(1, Math.round(mainHost.clientHeight + phaseHost.clientHeight));
      const root = el('svg', {
        xmlns: SVGNS,
        width: String(Math.round(W * scale)),
        height: String(Math.round(H * scale)),
        viewBox: '0 0 ' + W + ' ' + H,
      });
      root.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');

      // 背景必须显式画：透明 PNG 在白底看图器里等于一张白纸
      root.appendChild(el('rect', {
        x: 0, y: 0, width: '100%', height: '100%', fill: EXPORT_BG,
      }));

      const absorb = (srcSvg, dy) => {
        if (!srcSvg) return;
        const clone = srcSvg.cloneNode(true);
        inlineComputedStyles(srcSvg, clone);
        const g = el('g', dy ? { transform: 'translate(0,' + dy + ')' } : null);
        while (clone.firstChild) g.appendChild(clone.firstChild);
        root.appendChild(g);
      };
      absorb(mainSvg, 0);
      if (hasPhase && phaseSvg) absorb(phaseSvg, Math.round(mainHost.clientHeight));
      return { root, W, H };
    }

    function exportSvgFallback(xml, reason) {
      try {
        const name = 'ccl-wave-' + stamp() + '.svg';
        triggerDownload('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml), name);
        showHint('PNG 导出失败（' + reason + '），已改为下载 SVG：' + name, true);
      } catch (e) {
        showHint('导出失败：' + (e && e.message ? e.message : '未知错误'), true);
      }
    }

    function exportWavePng() {
      if (!mainSvg) { showHint('还没有波形可以导出', true); return; }
      hideCross();
      let xml = '';
      try {
        const scale = 2;
        const { root, W, H } = buildExportSvg(scale);
        xml = new XMLSerializer().serializeToString(root);
        if (!xml || xml.length < 200) throw new Error('序列化结果异常');

        const url = 'data:image/svg+xml;base64,' + b64Encode(xml);
        const img = new Image();
        let settled = false;

        img.onload = () => {
          if (settled) return;
          settled = true;
          try {
            const cv = document.createElement('canvas');
            cv.width = Math.max(1, Math.round(W * scale));
            cv.height = Math.max(1, Math.round(H * scale));
            const ctx = cv.getContext('2d');
            ctx.fillStyle = EXPORT_BG;
            ctx.fillRect(0, 0, cv.width, cv.height);
            ctx.drawImage(img, 0, 0, cv.width, cv.height);
            const png = cv.toDataURL('image/png');   // 部分 WebView 会在这里抛 SecurityError
            if (!/^data:image\/png/.test(png)) throw new Error('canvas 未返回 PNG');
            const name = 'ccl-wave-' + stamp() + '.png';
            triggerDownload(png, name);
            // 注意：<a download> 是否真的落盘浏览器不回报。Android WebView 常把
            // data: 下载静默丢弃，所以这里不写「已保存」，并顺手给一个 SVG 兜底入口。
            showHint('已请求下载 PNG：' + name + '（没看到文件就点右边）', false,
              '改存 SVG', () => exportSvgFallback(xml, '手动选择 SVG'));
          } catch (e) {
            exportSvgFallback(xml, (e && e.message) ? e.message : 'canvas 导出失败');
          }
        };
        img.onerror = () => {
          if (settled) return;
          settled = true;
          exportSvgFallback(xml, 'SVG 解码失败');
        };
        setTimeout(() => {
          if (settled) return;
          settled = true;
          exportSvgFallback(xml, '图片加载超时');
        }, 6000);
        img.src = url;
      } catch (e) {
        if (xml) exportSvgFallback(xml, (e && e.message) ? e.message : '未知错误');
        else showHint('导出失败：' + (e && e.message ? e.message : '未知错误'), true);
      }
    }

    pngBtn.onclick = () => { try { exportWavePng(); } catch (e) { showHint('导出失败：' + e.message, true); } };

    /* ------------------- 启动 ------------------- */
    renderLegend();
    drawWave();

    // 最大化 / 还原后的「补一帧重排」入口（createPanels 里的 maximize 会调用它）。
    // 走的是同一条 drawWave，几何照样按当时的容器尺寸现算 —— 不另立一套算法。
    _waveReflow = () => { hideCross(); drawWave(); };

    _ro = new ResizeObserver(() => {
      if (_raf) return;
      _raf = requestAnimationFrame(() => {
        _raf = 0;
        hideCross();
        drawWave();
      });
    });
    _ro.observe(svgWrap);
  }

  /* ================= 问题列表 ================= */
  function renderProblems() {
    const list = data.problems || [];
    if (!list.length) {
      body.innerHTML = '<div class="empty">没有发现问题。</div>';
      return;
    }

    const div = document.createElement('div');
    div.style.cssText = 'overflow:auto;height:100%;';

    const table = document.createElement('table');
    table.style.cssText = 'width:100%;border-collapse:collapse;font-size:12px;';

    for (const issue of list) {
      const tr = document.createElement('tr');
      tr.style.cssText = 'border-bottom:1px solid #2d2d2d;';

      const levelColor = issue.level === 'error' ? '#f14c4c' : issue.level === 'warn' ? '#d7ba7d' : '#8c8c8c';
      const levelText = issue.level === 'error' ? '错误' : issue.level === 'warn' ? '警告' : '提示';

      const td1 = document.createElement('td');
      td1.style.cssText = `width:44px;padding:5px 6px;vertical-align:top;color:${levelColor};white-space:nowrap;font-size:11px;`;
      td1.textContent = levelText;

      const td2 = document.createElement('td');
      td2.style.cssText = 'padding:5px 6px;';

      const titleLine = document.createElement('div');
      const titleSpan = document.createElement('span');
      titleSpan.textContent = issue.title || '';
      titleLine.appendChild(titleSpan);

      if (issue.ref) {
        const refSpan = document.createElement('span');
        refSpan.style.cssText = 'color:#8c8c8c;margin-left:6px;font-size:11px;';
        refSpan.textContent = `[${issue.ref}]`;
        titleLine.appendChild(refSpan);
      }

      if (issue.code) {
        const codeSpan = document.createElement('span');
        codeSpan.style.cssText = 'color:#6a7078;margin-left:6px;font-size:11px;font-family:ui-monospace,Menlo,Consolas,monospace;';
        codeSpan.textContent = issue.code;
        titleLine.appendChild(codeSpan);
      }

      td2.appendChild(titleLine);

      if (issue.detail) {
        const detailDiv = document.createElement('div');
        detailDiv.style.cssText = 'color:#8c8c8c;font-size:11px;margin-top:2px;';
        detailDiv.textContent = issue.detail;
        td2.appendChild(detailDiv);
      }

      // Click to jump: 有行号用行号；没有行号（lint 的 Issue 只有位号）就传 ref，
      // 由 main.js 在源码里按位号找行。否则点问题列表完全没反应。
      if (issue.line != null || issue.ref) {
        tr.style.cursor = 'pointer';
        tr.onclick = () => {
          document.dispatchEvent(new CustomEvent('ccl:goto-line', {
            detail: { line: issue.line != null ? issue.line : null, ref: issue.ref || '' },
          }));
        };
        tr.title = issue.line != null
          ? `点击跳转到第 ${issue.line} 行`
          : `点击定位到代码里的 ${issue.ref}`;
      }

      tr.appendChild(td1);
      tr.appendChild(td2);
      table.appendChild(tr);
    }

    div.appendChild(table);
    body.innerHTML = '';
    body.appendChild(div);
  }

  /* ---- 行 hover 高亮：JS 只切 class，配色由 style.css 的 .row-hl 提供 ---- */
  // 指标 / 工作点 / 网表三处共用（网表的 <pre> 另有自己的一套，见 renderNetlist）。
  function wireRowHover(row) {
    if (!row) return;
    row.addEventListener('pointerenter', () => row.classList.add('row-hl'));
    row.addEventListener('pointerleave', () => row.classList.remove('row-hl'));
  }

  /* ================= 指标 ================= */
  // 第三轮：瞬态指标 → 中文标签 + 带单位格式化。
  // 口径：值测不到（null/NaN）就整行跳过，**不显示一排「—」**（后端测不到返回 None 是常态）。
  const METRIC_DEFS = {
    rise_time: { label: '上升时间', fmt: (v) => fmtDuration(v) },
    fall_time: { label: '下降时间', fmt: (v) => fmtDuration(v) },
    settling_time: { label: '建立时间', fmt: (v) => fmtDuration(v) },
    overshoot_pct: { label: '超调量', fmt: (v) => fmtPct(v) },
    steady_state: { label: '稳态值 (V)', fmt: (v) => sigNum(v, 4) },
  };

  function renderMetrics() {
    const m = data.metrics || {};
    const keys = Object.keys(m);
    const known = [];
    const others = [];
    for (const k of keys) {
      const def = METRIC_DEFS[k];
      if (!def) { others.push(k); continue; }
      const v = m[k];
      if (typeof v !== 'number' || !isFinite(v)) continue;   // 测不到 → 整行不出现
      known.push(k);
    }
    if (!known.length && !others.length) {
      body.innerHTML = '<div class="empty">没有可用的指标（测不到的项不显示）。</div>';
      return;
    }

    const div = document.createElement('div');
    div.style.cssText = 'overflow:auto;height:100%;padding:6px 10px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;line-height:2;';

    const addRow = (label, valueText, rawKey) => {
      const row = document.createElement('div');
      row.setAttribute('data-metric', rawKey);
      row.setAttribute('data-value', valueText);
      const name = document.createElement('span');
      name.style.color = '#9cdcfe';
      name.textContent = label;
      row.appendChild(name);
      const eq = document.createElement('span');
      eq.style.color = '#555';
      eq.textContent = ' = ';
      row.appendChild(eq);
      const val = document.createElement('span');
      val.style.color = '#b5cea8';
      val.textContent = valueText;
      row.appendChild(val);
      // 原始 key 淡显：既方便和后端对照，又不干扰阅读
      const raw = document.createElement('span');
      raw.style.cssText = 'color:#5a6169;font-size:10.5px;margin-left:8px;';
      raw.textContent = rawKey;
      row.appendChild(raw);
      wireRowHover(row);
      div.appendChild(row);
    };

    for (const k of known) addRow(METRIC_DEFS[k].label, METRIC_DEFS[k].fmt(m[k]), k);
    // 未知指标（AC 的 f3db / peak_db / 增益dB@低频 等）保持原有显示方式
    for (const k of others) {
      const v = m[k];
      addRow(k, (v === null || v === undefined) ? '—' : fmtNum(v), k);
    }

    body.innerHTML = '';
    body.appendChild(div);
  }

  /* ================= 工作点 ================= */
  function renderOp() {
    const o = data.op || {};
    const keys = Object.keys(o);
    if (!keys.length) {
      body.innerHTML = '<div class="empty">没有工作点数据（切换到直流工作点分析）。</div>';
      return;
    }

    const div = document.createElement('div');
    div.style.cssText = 'overflow:auto;height:100%;padding:6px 10px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;line-height:2;';

    for (const k of keys) {
      const row = document.createElement('div');
      const v = o[k];
      const isCurrent = /^i\(/i.test(k);
      const unit = isCurrent ? 'A' : 'V';
      const valStr = v === null || v === undefined ? '—' : fmtNum(v) + ' ' + unit;
      row.setAttribute('data-node', k);
      row.innerHTML = `<span style="color:#9cdcfe">${esc(k)}</span> <span style="color:#555">=</span> <span style="color:#b5cea8">${esc(valStr)}</span>`;
      wireRowHover(row);
      div.appendChild(row);
    }

    body.innerHTML = '';
    body.appendChild(div);
  }

  /* ================= 网表 ================= */
  function renderNetlist() {
    if (!data.netlist) {
      body.innerHTML = '<div class="empty">运行后显示 SPICE 网表。</div>';
      return;
    }

    // 网表是纯文本 <pre>，DOM 里没有「行」元素，所以行 hover 用一层高亮带实现：
    //  - wrap 自己建层叠上下文（position:relative + z-index:0），带子用 z-index:-1
    //    压到文字下面 —— 这样它盖得住 #panel-body 的底色，又不会糊住代码；
    //  - 带子的 top/height 按行高算，是 JS 必须做的部分；颜色交给 .row-hl。
    // 前提：pre 是 white-space:pre（不折行）→ 一行文本就是一行，可以整行乘行高。
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;z-index:0;height:100%;overflow:hidden;';

    const pre = document.createElement('pre');
    pre.style.cssText = 'margin:0;padding:8px 10px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;white-space:pre;overflow:auto;height:100%;color:#ccc;';
    pre.textContent = data.netlist;
    const lineCount = data.netlist.split('\n').length;

    const band = document.createElement('div');
    band.className = 'row-hl';
    band.style.cssText = 'position:absolute;left:0;right:0;top:0;height:0;display:none;'
      + 'z-index:-1;pointer-events:none;';

    let lineH = 0;      // 单行高（px）
    let padTop = 0;     // pre 的上内边距
    let curLine = -1;   // 当前 hover 的行下标

    // 首次 hover 才量（元素进 DOM 前拿不到计算样式）
    function measure() {
      try {
        const cs = getComputedStyle(pre);
        lineH = parseFloat(cs.lineHeight) || 0;
        padTop = parseFloat(cs.paddingTop) || 0;
        const padBot = parseFloat(cs.paddingBottom) || 0;
        // line-height 算出来可能是 "normal"（拿不到数值）：退回「内容总高 ÷ 行数」。
        // 前提同样是 white-space:pre（不折行），否则这个平均值没有意义。
        if (!(lineH > 4) && lineCount > 0 && pre.scrollHeight > 0) {
          lineH = (pre.scrollHeight - padTop - padBot) / lineCount;
        }
      } catch (_) { lineH = 0; }
      if (!(lineH > 4)) lineH = 0;   // 量不到行高就整套不亮：宁可不亮，也不要错位
    }

    function placeBand() {
      if (curLine < 0 || !lineH) { band.style.display = 'none'; return; }
      const top = padTop + curLine * lineH - pre.scrollTop;
      if (top + lineH <= padTop || top >= pre.clientHeight) { band.style.display = 'none'; return; }
      band.style.display = 'block';
      band.style.top = Math.round(top) + 'px';
      band.style.height = Math.round(lineH) + 'px';
    }

    pre.addEventListener('pointermove', (ev) => {
      if (!lineH) measure();
      if (!lineH) return;
      const r = pre.getBoundingClientRect();
      // clientY → 内容坐标：扣掉上内边距，再把滚动量加回来
      const y = ev.clientY - r.top - padTop + pre.scrollTop;
      let i = Math.floor(y / lineH);
      if (i < 0) i = 0;
      if (i > lineCount - 1) i = lineCount - 1;
      curLine = i;
      placeBand();
    });
    pre.addEventListener('pointerleave', () => { band.style.display = 'none'; });
    pre.addEventListener('scroll', placeBand);   // 滚动时带子跟着走

    wrap.appendChild(band);
    wrap.appendChild(pre);

    body.innerHTML = '';
    body.appendChild(wrap);
  }

  /* ================= 报告 ================= */
  function renderReport() {
    if (!data.report) {
      body.innerHTML = '<div class="empty">点右上角「报告」生成 Markdown（含网表、实测、检查、规格核对）。</div>';
      return;
    }

    const pre = document.createElement('pre');
    pre.style.cssText = 'margin:0;padding:8px 10px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;white-space:pre-wrap;word-break:break-word;overflow:auto;height:100%;color:#ccc;line-height:1.6;';
    pre.textContent = data.report;

    body.innerHTML = '';
    body.appendChild(pre);
  }

  /* ================= 徽标 ================= */
  function updatePill() {
    const pill = document.getElementById('problemCount');
    if (!pill) return;
    const errors = (data.problems || []).filter(i => i.level === 'error').length;
    const warns = (data.problems || []).filter(i => i.level === 'warn').length;
    const n = errors + warns;
    pill.hidden = n === 0;
    pill.textContent = String(n);
    pill.style.background = errors ? '#f14c4c' : '#d7ba7d';
  }

  /* ================= 初始化 ================= */
  render();

  return {
    // main.js calls: panels.showWaveform({ traces, op: a.op }, { kind: a.kind })
    // dc 还需要扫描位号：opts.sweepVar（Lead 会把 a.sweepVar 传进来），
    // 也兼容 arg.sweepVar / 后端的 snake_case 与 source 字段名。
    showWaveform(arg, opts) {
      const o = opts || {};
      const pickStr = (...keys) => {
        for (const src of [o, arg || {}]) {
          for (const k of keys) {
            const v = src[k];
            if (typeof v === 'string' && v.trim()) return v.trim();
          }
        }
        return '';
      };
      const kind = o.kind || (arg && arg.kind) || 'ac';
      let traces = (arg && arg.traces) ? arg.traces : (arg || {});
      if (kind === 'dc') traces = normalizeDCTraces(traces);
      data.traces = traces;
      data.opData = (arg && arg.op) || null;
      data.kind = kind;
      data.sweepVar = pickStr('sweepVar', 'sweep_var', 'source');
      data.secondVar = pickStr('secondVar', 'second_var', 'second_source');
      // Reset hidden set: current traces default hidden if i(...)
      // dc 例外：曲线族常常就是电流（输出特性 Ic–Vce），默认藏起来等于少一半曲线
      waveHidden = new Set();
      if (kind !== 'dc') {
        for (const name of Object.keys(data.traces)) {
          if (/^i\(/i.test(name)) waveHidden.add(name);
        }
      }
      if (active === 'wave') renderWave();
    },
    showProblems(issues) {
      data.problems = issues || [];
      updatePill();
      if (active === 'problems') renderProblems();
    },
    showMetrics(m) {
      data.metrics = m || {};
      if (active === 'metrics') renderMetrics();
    },
    showOperatingPoint(o) {
      data.op = o || {};
      if (active === 'op') renderOp();
    },
    /** 显示电路图。
     *  anim（可选）：{ timeline, kinds, switches, onSwitch }
     *    · 传了且 timeline 可用 → 图例下面多一条时间轴播放条
     *    · 不传 / timeline 为空    → 只有图，没有播放条（不演假动画）
     */
    showSchematic(html, legend, anim) {
      data.schematic = html || '';
      data.schemLegend = legend || '';
      data.schemAnim = (anim && anim.timeline) ? anim : null;
      // 开关接线信息单独存：没有播放条时也要能点开关
      data.schemSwitchOpts = anim
        ? { switches: anim.switches, onSwitch: anim.onSwitch }
        : null;
      if (active === 'schematic') renderSchematicPanel();
      else destroyPlayer();     // 不在这个面板上就不留跑着的 rAF
    },

    /* 开关覆盖提示条：info 为 null 表示「没有覆盖」，提示条整个下线（不是留个空条）。
     *
     * ⚑ 只换提示条这一个节点，**绝不重画整个面板**：
     * 点开关的瞬间 main.js 会先刷这条提示（用户点了就该立刻看到「已被覆盖」），
     * 若这里顺手 renderSchematicPanel()，innerHTML 会用**旧的** data.schematic 重建，
     * 刚被 switchAt() 掰过去的刀闸会当场弹回原样，看起来像点了没反应；
     * 万一正在播动画，还会把播放器销毁重建（rAF 断掉、进度丢失）。 */
    setSwitchBar(info) {
      data.switchBar = info && info.owner ? info : null;
      if (active !== 'schematic') return;             // 不在这个面板上：只存状态
      const wrap = body.querySelector('.schem-wrap');
      const old = body.querySelector('[data-sw-bar]');
      if (old && old.parentNode) old.parentNode.removeChild(old);
      const html = switchBarHtml();
      if (!html) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = html;
      const node = tmp.firstChild;
      if (!node) return;
      if (wrap) wrap.insertBefore(node, wrap.firstChild);
      else body.insertBefore(node, body.firstChild);
      wireSwitchBar(node);
    },

    showNetlist(t) {
      data.netlist = t || '';
      if (active === 'netlist') renderNetlist();
    },
    showReport(t) {
      data.report = t || '';
      if (active === 'report') renderReport();
    },
    setActive,
    maximize,        // maximize(on:boolean) —— 面板最大化 / 还原（样式来自 body.panel-max）
    isMaximized,     // isMaximized():boolean
    clear() {
      data.schematic = '';
      data.switchBar = null;
      data.schemAnim = null;
      destroyPlayer();
      data.traces = {};
      data.opData = null;
      data.problems = [];
      data.metrics = {};
      data.op = {};
      data.netlist = '';
      data.report = '';
      waveHidden = new Set();
      updatePill();
      render();
    },
  };
}
