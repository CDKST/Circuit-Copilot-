/* ------------------------------------------------------------------
 * CCL Studio 代码编辑器 —— 归属：ui-editor
 *
 * 纯原生实现（零外部依赖），结构是三层叠加：
 *
 *   .ccl-ed
 *     ├─ .ccl-ed-gutter   行号列（overflow:hidden，内部整块 transform 平移）
 *     ├─ .ccl-ed-code
 *     │    ├─ .ccl-ed-ovl    覆盖装饰层（纯背景色块，pointer-events:none）
 *     │    │    └─ .ccl-ed-ovl-in
 *     │    │         ├─ .ccl-ed-hgrid         随横向滚动平移的容器
 *     │    │         │    ├─ .ccl-ed-guides   缩进参考线（.ccl-ed-indent）
 *     │    │         │    ├─ .ccl-ed-brackets 括号匹配（.ccl-ed-bracket）
 *     │    │         │    └─ .ccl-ed-find     查找命中底色（.ccl-ed-find-i）
 *     │    │         └─ .ccl-ed-curline       当前行整行底色
 *     │    ├─ .ccl-ed-deco   诊断底色/竖条层（pointer-events:none）
 *     │    ├─ pre.ccl-ed-pre 语法高亮层（白色背景，pointer-events:none）
 *     │    └─ textarea       输入层（文字透明、光标可见，唯一可交互层）
 *     ├─ #minimap         小地图（Round 5：右侧 70px 容器 + canvas，见 §小地图）
 *     └─ #findbar         查找 / 替换浮层（Round 5：绝对定位右上，DOM 本模块自建）
 *
 * Round 5 桌面版新增的三件事都遵守同一条纪律：**样式归 style.css，本模块只算坐标**。
 * 因此 #minimap / #findbar 的视觉全部用 :where() 写「零特异性」兜底规则 ——
 * :where() 的权重是 0，所以 style.css 里任何 `#findbar{...}` 都能盖掉它，
 * 而它自己又保证单独打开本文件时不会散架成一堆没有定位的裸元素。
 *
 * 覆盖层全部在文字底下、用「算坐标」而不是「跟文本流」的方式绘制：
 * 纵向 = PAD_T + (line-1)*LH，横向 = PAD_X + col*ch（等宽字体下 ch 就是字宽）。
 * 它们不进文档流，所以不可能改变任何一行的行高或字形位置 —— 对齐永远不变。
 *
 * 像素对齐的关键：三层共享同一套 CSS 变量（--ccl-fs / --ccl-lh /
 * --ccl-pad-t / --ccl-pad-x）与同一个 font-family，且都显式关闭连字
 * （font-variant-ligatures:none），textareawrap="off" 与 pre 的
 * white-space:pre 一致 —— 不做软换行，因此行不会重排，宽度差异不影响
 * 任何一行的字形位置。
 * ------------------------------------------------------------------ */

const STYLE_ID = 'ccl-editor-style';

const FONT_MONO = 'ui-monospace,SFMono-Regular,Menlo,Consolas,"Courier New",monospace';
const FS = 13;      // px，三层同值
const LH = 20;      // px，三层同值
const PAD_T = 8;    // px，上下内边距
const PAD_X = 10;   // px，左右内边距
const TAB = '    '; // 4 空格

/* ================= 词法 ================= */

const KEYWORDS = new Set([
  'from', 'import', 'def', 'return', 'class', 'for', 'in', 'if', 'else', 'elif',
  'while', 'try', 'except', 'finally', 'with', 'as', 'pass', 'None', 'True',
  'False', 'and', 'or', 'not', 'is', 'lambda', 'raise', 'break', 'continue',
  'yield', 'global', 'nonlocal', 'del', 'assert', 'async', 'await',
]);

// CCL 专有：类 / 常量（青绿）
const CCL_TYPES = new Set(['Circuit', 'GND', 'BLOCKS', 'Solution', 'Analysis', 'Expect']);

/* 覆盖层配色（对齐 VS Code Dark+，一律压成低透明度，不刺眼） */
const C_CURLINE = 'rgba(255,255,255,.045)';  // 当前行整行底色
const C_INDENT = 'rgba(255,255,255,.06)';    // 缩进参考线
const C_BRACKET = 'rgba(255,255,255,.10)';   // 括号匹配
const C_LN_CUR = '#c6c6c6';                  // 当前行行号
const C_ERR_BG = 'rgba(241,76,76,.10)';      // 错误行底色
const C_WARN_BG = 'rgba(215,186,125,.10)';   // 警告行底色

/* 字号缩放区间（Round 5）：13 是原值，24 是上限；行高按 20/13 的比例跟着走，
 * 这样任意字号下「一层文字 = 一行装饰」的像素换算都不会失真。 */
const FONT_MIN = 13;
const FONT_MAX = 24;
const FONT_BASE = FS;                        // Ctrl+0 的归位值
const LH_RATIO = LH / FS;                    // 20 / 13 ≈ 1.538

/* 小地图（Round 5）：宽度是契约里的固定值，高度吃满编辑区 */
const MM_W = 70;

/* 小地图行块配色（只求能区分注释/字符串/其他，不做词法分析） */
const C_MM_BG = '#1a1a1a';                   // 底色，略暗于编辑区
const C_MM_TXT = '#6f6f6f';                  // 普通行
const C_MM_CMT = '#3f6b3f';                  // 注释行（绿）
const C_MM_STR = '#8a6250';                  // 字符串行（褐）
const C_MM_VIEW = 'rgba(255,255,255,.08)';   // 视口框
const C_MM_VIEW_EDGE = 'rgba(255,255,255,.14)';

// CCL 专有：c.xxx 方法（亮黄）
const CCL_METHODS = 'OpAmp|PULSE|SIN|expect|use_ports|R|C|L|D|Q|M|V|I';

const TOKEN_SRC = [
  '#[^\\n]*',                                        // 注释
  '"""[\\s\\S]*?"""',                                // 三引号字符串
  "'''[\\s\\S]*?'''",
  '"(?:\\\\.|[^"\\\\\\n])*"',                        // 双引号字符串
  "'(?:\\\\.|[^'\\\\\\n])*'",                        // 单引号字符串
  'c\\.(?:' + CCL_METHODS + ')\\b',                  // CCL 方法
  '(?:\\b\\d+\\.?\\d*|\\B\\.\\d+)(?:[eE][+-]?\\d+)?', // 数字（含 1e-9 / 1.6e3）
  '\\b[A-Za-z_]\\w*\\b',                              // 标识符
].join('|');

function escHtml(s) {
  return s.replace(/[&<>]/g, (c) => (c === '&' ? '&amp;' : c === '<' ? '&lt;' : '&gt;'));
}

function escAttr(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/** 把源码切成高亮 HTML（一层遍历，几百行内足够快） */
function highlight(src) {
  const re = new RegExp(TOKEN_SRC, 'g');
  let out = '';
  let last = 0;
  let m;
  while ((m = re.exec(src)) !== null) {
    if (m.index > last) out += escHtml(src.slice(last, m.index));
    const t = m[0];
    const c0 = t.charCodeAt(0);
    let cls = '';
    if (c0 === 35) cls = 'tk-cmt';                                  // '#'
    else if (c0 === 34 || c0 === 39) cls = 'tk-str';                // " '
    else if (c0 === 99 && t.charCodeAt(1) === 46) cls = 'tk-fn';    // c.
    else if (c0 === 46) cls = 'tk-num';                             // .5
    else if (c0 >= 48 && c0 <= 57) cls = 'tk-num';
    else if (KEYWORDS.has(t)) cls = 'tk-kw';
    else if (CCL_TYPES.has(t)) cls = 'tk-cls';
    out += cls ? '<span class="' + cls + '">' + escHtml(t) + '</span>' : escHtml(t);
    last = m.index + t.length;
  }
  if (last < src.length) out += escHtml(src.slice(last));
  return out;
}

/* ================= 样式（只由本模块注入） ================= */

function ensureStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const st = document.createElement('style');
  st.id = STYLE_ID;
  st.textContent = `
.ccl-ed{
  --ccl-font:${FONT_MONO};
  --ccl-fs:${FS}px;
  --ccl-lh:${LH}px;
  --ccl-pad-t:${PAD_T}px;
  --ccl-pad-x:${PAD_X}px;
  position:relative;display:flex;height:100%;width:100%;overflow:hidden;
  background:#1e1e1e;color:#d4d4d4;text-align:left;
  font-family:var(--ccl-font);font-size:var(--ccl-fs);line-height:var(--ccl-lh);
  letter-spacing:0;font-variant-ligatures:none;
  font-feature-settings:"liga" 0,"calt" 0,"dlig" 0;
  tab-size:4;-moz-tab-size:4;
  -webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;
}
.ccl-ed,.ccl-ed *,.ccl-ed *::before,.ccl-ed *::after{box-sizing:border-box}

.ccl-ed-gutter{
  flex:0 0 auto;position:relative;height:100%;overflow:hidden;
  background:#1e1e1e;color:#858585;border-right:1px solid #2b2b2b;
  user-select:none;-webkit-user-select:none;cursor:text;
  font-family:inherit;font-size:inherit;line-height:inherit;letter-spacing:0;
}
.ccl-ed-gutter-in{
  position:absolute;top:0;left:0;width:100%;padding-top:var(--ccl-pad-t);
  will-change:transform;
}
.ccl-ed-ln{
  height:var(--ccl-lh);line-height:var(--ccl-lh);
  padding:0 8px 0 6px;text-align:right;white-space:pre;
  font-variant-numeric:tabular-nums;
}
.ccl-ed-ln.d-err{color:#f14c4c}
.ccl-ed-ln.d-warn{color:#d7ba7d}
/* 当前行行号变亮；诊断色优先级更高（放在 .cur 之后） */
.ccl-ed-ln.cur{color:${C_LN_CUR}}

.ccl-ed-code{position:relative;flex:1 1 auto;min-width:0;height:100%;overflow:hidden}

/* ---- 覆盖装饰层：当前行 / 缩进参考线 / 括号匹配 ---- */
.ccl-ed-ovl{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;
  pointer-events:none;z-index:1}
.ccl-ed-ovl-in{position:absolute;top:0;left:0;width:100%;will-change:transform}
.ccl-ed-hgrid{position:absolute;top:0;left:0;width:100%;height:0;will-change:transform}
.ccl-ed-guides,.ccl-ed-brackets{position:absolute;top:0;left:0;width:100%;height:0}
.ccl-ed-indent{position:absolute;top:0;width:1px;background:${C_INDENT};
  pointer-events:none}
.ccl-ed-bracket{position:absolute;top:0;width:1ch;height:var(--ccl-lh);
  background:${C_BRACKET};border-radius:2px;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.10);
  pointer-events:none}
.ccl-ed-curline{position:absolute;top:0;left:0;right:0;height:var(--ccl-lh);
  background:${C_CURLINE};pointer-events:none;will-change:transform}

/* ---- 查找命中层（Round 5）----
 * 和缩进线/括号同一套坐标系，所以它挂在 .ccl-ed-hgrid 里一起做横向平移。
 * 全部命中是 60% 透明度的 #264f78，当前命中加深并补 1px 亮边（契约口径）。 */
.ccl-ed-find{position:absolute;top:0;left:0;width:100%;height:0}
.ccl-ed-find-i{position:absolute;height:var(--ccl-lh);border-radius:2px;
  background:rgba(38,79,120,.6);pointer-events:none}
.ccl-ed-find-i.on{background:rgba(38,79,120,.95);
  box-shadow:inset 0 0 0 1px #0e639c}

.ccl-ed-deco{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;
  pointer-events:none;z-index:2}
.ccl-ed-deco-in{position:absolute;top:0;left:0;width:100%;
  padding-top:var(--ccl-pad-t);will-change:transform}
.ccl-ed-deco-line{height:var(--ccl-lh);line-height:var(--ccl-lh)}
.ccl-ed-deco-line.d-err{background:${C_ERR_BG};box-shadow:inset 2px 0 0 0 #f14c4c}
.ccl-ed-deco-line.d-warn{background:${C_WARN_BG};box-shadow:inset 2px 0 0 0 #d7ba7d}

.ccl-ed-pre{
  position:absolute;top:0;left:0;margin:0;
  min-width:100%;width:max-content;
  padding:var(--ccl-pad-t) var(--ccl-pad-x);
  white-space:pre;overflow:visible;
  font-family:inherit;font-size:inherit;line-height:inherit;letter-spacing:0;
  font-variant-ligatures:none;font-feature-settings:"liga" 0,"calt" 0,"dlig" 0;
  tab-size:4;-moz-tab-size:4;
  color:#d4d4d4;pointer-events:none;z-index:3;will-change:transform;
}
.ccl-ed-pre code{display:block;font:inherit;white-space:inherit;letter-spacing:inherit}

/* VS Code Dark+ 取色 */
.ccl-ed-pre .tk-kw{color:#c586c0}
.ccl-ed-pre .tk-str{color:#ce9178}
.ccl-ed-pre .tk-cmt{color:#6a9955;font-style:italic}
.ccl-ed-pre .tk-num{color:#b5cea8}
.ccl-ed-pre .tk-cls{color:#4ec9b0}
.ccl-ed-pre .tk-fn{color:#dcdcaa}

.ccl-ed-ta{
  position:absolute;top:0;left:0;right:0;bottom:0;width:100%;height:100%;
  margin:0;padding:var(--ccl-pad-t) var(--ccl-pad-x);
  border:0;outline:0;resize:none;display:block;
  background:transparent;color:transparent;caret-color:#aeafad;
  font-family:inherit;font-size:inherit;line-height:inherit;letter-spacing:0;
  font-variant-ligatures:none;font-feature-settings:"liga" 0,"calt" 0,"dlig" 0;
  white-space:pre;overflow:auto;overflow-wrap:normal;word-break:normal;
  tab-size:4;-moz-tab-size:4;-webkit-appearance:none;appearance:none;z-index:4;
}
.ccl-ed-ta::selection{background:#264f78}
.ccl-ed-ta:focus{outline:0}
/* 细滚动条：6px 可见拇指（10px 轨道 − 2×2px 透明边），圆角，hover 变亮 */
.ccl-ed-ta::-webkit-scrollbar{width:10px;height:10px}
.ccl-ed-ta::-webkit-scrollbar-track{background:transparent}
.ccl-ed-ta::-webkit-scrollbar-thumb{
  background:#424242;background-clip:padding-box;
  border:2px solid transparent;border-radius:6px;min-height:24px}
.ccl-ed-ta::-webkit-scrollbar-thumb:hover{
  background:#5f5f5f;background-clip:padding-box}
.ccl-ed-ta::-webkit-scrollbar-thumb:active{
  background:#6b6b6b;background-clip:padding-box}
.ccl-ed-ta::-webkit-scrollbar-corner{background:transparent}

/* ================= Round 5：零特异性兜底 =================
 * #minimap / #findbar 的视觉归 style.css（desk-shell）。这里只写 :where() 规则，
 * 权重恒为 0 —— 只要 style.css 里出现任何 #findbar{...} 就能整条盖掉，
 * 而独立打开本文件调试时也不会出现「没有定位的裸 div」。颜色一律给 #hex 字面值
 * 而不是 var(--bg-panel)，同样是因为 :where() 里拿不到 shell 的变量也不该报错。 */
:where(#minimap){
  position:absolute;top:0;right:0;bottom:0;width:${MM_W}px;overflow:hidden;
  background:${C_MM_BG};cursor:pointer;z-index:2;
  user-select:none;-webkit-user-select:none;
}
:where(#minimap canvas){display:block;width:100%;height:100%}

:where(#findbar){
  position:absolute;top:8px;right:8px;z-index:5;
  display:flex;flex-direction:column;gap:4px;
  width:430px;padding:6px;background:#252526;
  border:1px solid #454545;border-radius:5px;
  box-shadow:0 8px 24px rgba(0,0,0,.55);
}
:where(#findbar .fb-row){display:flex;align-items:center;gap:4px}
:where(#findbar input){
  flex:1 1 auto;min-width:0;height:24px;padding:0 6px;
  border:1px solid #3c3c3c;border-radius:3px;background:#3c3c3c;
  color:#ccc;font-family:${FONT_MONO};font-size:12px;line-height:22px;
}
:where(#findbar input:focus){outline:0;border-color:#0e639c}
:where(#findbar button){
  flex:0 0 auto;height:24px;min-width:24px;padding:0 6px;
  border:0;border-radius:3px;background:transparent;color:#ccc;
  font-family:inherit;font-size:12px;cursor:pointer;
}
:where(#findbar button:hover){background:#094771}
:where(#findbar .fb-count){
  flex:0 0 auto;min-width:44px;text-align:center;
  font-size:11px;color:#8c8c8c;font-variant-numeric:tabular-nums;
}
:where(#findbar .fb-count.no-hit){color:#f14c4c}
:where(#findbar .fb-rep-all){padding:0 8px}
`;
  document.head.appendChild(st);
}

/* ================= 创建编辑器 ================= */

/**
 * @param {HTMLElement} host 挂载点（#editor-host）
 * @param {{value?:string,onChange?:(v:string)=>void,onCursor?:(l:number,c:number)=>void,onRun?:()=>void}} opts
 */
export function createEditor(host, opts = {}) {
  ensureStyle();

  /* ---------- DOM ---------- */
  const wrap = document.createElement('div');
  wrap.className = 'ccl-ed';

  const gutter = document.createElement('div');
  gutter.className = 'ccl-ed-gutter';
  gutter.setAttribute('aria-hidden', 'true');

  const gutterIn = document.createElement('div');
  gutterIn.className = 'ccl-ed-gutter-in';
  gutter.appendChild(gutterIn);

  const codeWrap = document.createElement('div');
  codeWrap.className = 'ccl-ed-code';

  const deco = document.createElement('div');
  deco.className = 'ccl-ed-deco';
  const decoIn = document.createElement('div');
  decoIn.className = 'ccl-ed-deco-in';
  deco.appendChild(decoIn);

  /* 覆盖装饰层（当前行 / 缩进线 / 括号），整层位于 pre 与 textarea 之下 */
  const ovl = document.createElement('div');
  ovl.className = 'ccl-ed-ovl';
  ovl.setAttribute('aria-hidden', 'true');
  const ovlIn = document.createElement('div');
  ovlIn.className = 'ccl-ed-ovl-in';
  const hgrid = document.createElement('div');
  hgrid.className = 'ccl-ed-hgrid';
  const guidesEl = document.createElement('div');
  guidesEl.className = 'ccl-ed-guides';
  const bracketsEl = document.createElement('div');
  bracketsEl.className = 'ccl-ed-brackets';
  /* 查找命中层：和缩进线/括号共享 hgrid 的横向平移，保证长行横向滚动后仍对齐 */
  const findEl = document.createElement('div');
  findEl.className = 'ccl-ed-find';
  hgrid.appendChild(guidesEl);
  hgrid.appendChild(bracketsEl);
  hgrid.appendChild(findEl);
  const curline = document.createElement('div');
  curline.className = 'ccl-ed-curline';
  ovlIn.appendChild(hgrid);
  ovlIn.appendChild(curline);
  ovl.appendChild(ovlIn);

  const pre = document.createElement('pre');
  pre.className = 'ccl-ed-pre';
  pre.setAttribute('aria-hidden', 'true');
  const preCode = document.createElement('code');
  pre.appendChild(preCode);

  const ta = document.createElement('textarea');
  ta.className = 'ccl-ed-ta';
  ta.spellcheck = false;
  ta.setAttribute('wrap', 'off');
  ta.setAttribute('autocapitalize', 'off');
  ta.setAttribute('autocorrect', 'off');
  ta.setAttribute('autocomplete', 'off');
  ta.setAttribute('aria-label', 'Python 代码编辑器');

  codeWrap.appendChild(ovl);
  codeWrap.appendChild(deco);
  codeWrap.appendChild(pre);
  codeWrap.appendChild(ta);
  wrap.appendChild(gutter);
  wrap.appendChild(codeWrap);

  /* ---------- 小地图（Round 5）----------
   * 容器 #minimap 绝对定位在 .ccl-ed 的右侧；它不进 flex 流，而是由 mmApply()
   * 给 .ccl-ed 加 padding-right:70px 把内容区让出来 —— 这样小地图不会压住
   * textarea 右侧那 10px 的滚动条。canvas 位图尺寸必须自己按 devicePixelRatio
   * 算，CSS 只管显示尺寸，否则高分屏上会糊成一片。 */
  const mmWrap = document.createElement('div');
  mmWrap.id = 'minimap';
  const mmCanvas = document.createElement('canvas');
  mmWrap.appendChild(mmCanvas);

  /* ---------- 查找 / 替换浮层（Round 5）----------
   * 本模块只建 DOM、只挂契约约定的 id/class，视觉全部交给 style.css。
   * 分工：输入框管查询、.fb-count 管计数、四个按钮管跳转与替换、✕ 管关闭。 */
  const fb = document.createElement('div');
  fb.id = 'findbar';
  fb.style.display = 'none';      // 关闭态用内联 display，不依赖 CSS 提供 [hidden] 规则
  fb.setAttribute('aria-hidden', 'true');

  /** 浮层里的小按钮统一构造：type=button 防止回车提交、tabIndex=-1 让 Tab 留在输入框 */
  function mkBtn(cls, label, title) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = cls;
    b.textContent = label;
    if (title) b.title = title;
    b.tabIndex = -1;
    return b;
  }

  const fbRow1 = document.createElement('div');
  fbRow1.className = 'fb-row';
  const fbFind = document.createElement('input');
  fbFind.type = 'text';
  fbFind.className = 'fb-find';
  fbFind.placeholder = '查找';
  fbFind.spellcheck = false;
  fbFind.setAttribute('autocomplete', 'off');
  fbFind.setAttribute('aria-label', '查找');
  const fbCount = document.createElement('span');
  fbCount.className = 'fb-count';
  const fbPrev = mkBtn('fb-btn fb-prev', '↑', '上一个（Shift+Enter）');
  const fbNext = mkBtn('fb-btn fb-next', '↓', '下一个（Enter）');
  const fbClose = mkBtn('fb-btn fb-close', '✕', '关闭（Esc）');
  fbRow1.appendChild(fbFind);
  fbRow1.appendChild(fbCount);
  fbRow1.appendChild(fbPrev);
  fbRow1.appendChild(fbNext);
  fbRow1.appendChild(fbClose);

  const fbRow2 = document.createElement('div');
  fbRow2.className = 'fb-row fb-row2';
  const fbRepl = document.createElement('input');
  fbRepl.type = 'text';
  fbRepl.className = 'fb-replace';
  fbRepl.placeholder = '替换';
  fbRepl.spellcheck = false;
  fbRepl.setAttribute('autocomplete', 'off');
  fbRepl.setAttribute('aria-label', '替换');
  const fbRep = mkBtn('fb-btn fb-rep', '替换', '替换当前命中（可撤销）');
  const fbRepAll = mkBtn('fb-btn fb-rep-all', '全部替换', '替换全部命中（可撤销）');
  fbRow2.appendChild(fbRepl);
  fbRow2.appendChild(fbRep);
  fbRow2.appendChild(fbRepAll);

  fb.appendChild(fbRow1);
  fb.appendChild(fbRow2);

  // 未开启前必须隐藏：否则右侧会留一条 70px 的空灰条压着代码（首帧 ppp 的观感问题）
  mmWrap.style.display = 'none';
  wrap.appendChild(mmWrap);
  wrap.appendChild(fb);

  host.innerHTML = '';
  host.appendChild(wrap);

  ta.value = typeof opts.value === 'string' ? opts.value : '';

  /* ---------- 状态 ---------- */
  let diagMap = new Map();     // line -> {level, message}
  let gutterN = -1;            // 已渲染的行数
  let gutterDirty = true;      // 诊断变化后需重建
  let rafId = 0;
  let lineEls = [];            // 行号 <div> 缓存（给当前行加 .cur）
  let curLineNo = 0;           // 当前已标 .cur 的行号，0 = 无
  let guideKey = '';           // 缩进线指纹，值没变就不重建

  /* 几何量从模块常量「搬进实例」：字号缩放要能改，装饰层的像素换算全部读这里。
   * 三个常量（FS/LH/PAD_T/PAD_X）仍是初始值，也是注入 CSS 的 var() 初值。 */
  let fs = FS;                 // 当前字号 px
  let lh = LH;                 // 当前行高 px（= round(fs * LH_RATIO)）
  let padT = PAD_T;            // 上内边距 px
  let padX = PAD_X;            // 左内边距 px

  /* 字宽缓存：等宽字体下 1ch 的像素宽度。只在第一次用到 / 字号变化后量一次，
   * 之后拿它算横向滚动与右键落点的列号，不去动 DOM。 */
  let chPx = 0;
  let chPxFs = 0;

  /* 小地图状态 */
  let mmOn = false;            // 当前是否显示（mmApply 维护）
  let mmUserSet = false;       // 用户/外部显式调过 setMinimap() → 不再自动开合
  let mmRaf = 0;               // 重绘合并用的 rAF（滚轮/滚动都只排一次）
  let mmDrag = false;          // 拖动小地图中
  let mmDpr = 0;               // 上次绘制用的 dpr，变了要重设位图
  let mmKey = '';              // 文档层缓存指纹（文本 revision + 尺寸）
  let mmRev = 0;               // 文本 revision，renderNow 会 ++
  let mmDoc = null;            // 文档层离屏 canvas（只有文本或尺寸变了才重画）

  /* 查找状态 */
  const findState = {
    open: false,               // 浮层是否打开
    query: '',                 // 当前查询串
    matches: [],               // [{start, len, line, col}]，按 start 升序
    cur: -1,                   // 当前命中下标，-1 = 还没定位
  };
  const FIND_MAX = 5000;       // 命中上限：再多的计数也没意义，防卡死
  const FIND_DRAW_MAX = 800;   // 装饰层最多画多少块，长文件里不全画

  /* ---------- 渲染 ---------- */

  function countLines(v) {
    let n = 1;
    for (let i = 0; i < v.length; i++) if (v.charCodeAt(i) === 10) n++;
    return n;
  }

  function updateGutterWidth(n) {
    const digits = Math.max(2, String(n).length);
    gutter.style.width = 'calc(' + digits + 'ch + 18px)';
  }

  function renderLines(force) {
    const v = ta.value;
    const n = countLines(v);
    if (!force && n === gutterN && !gutterDirty) return;
    const parts = new Array(n);
    const decos = new Array(n);
    for (let i = 1; i <= n; i++) {
      const d = diagMap.get(i);
      if (d) {
        const cls = d.level === 'error' ? ' d-err' : ' d-warn';
        const tip = d.message ? ' title="' + escAttr(d.message) + '"' : '';
        parts[i - 1] = '<div class="ccl-ed-ln' + cls + '"' + tip + '>' + i + '</div>';
        decos[i - 1] = '<div class="ccl-ed-deco-line' + cls + '"></div>';
      } else {
        parts[i - 1] = '<div class="ccl-ed-ln">' + i + '</div>';
        decos[i - 1] = '<div class="ccl-ed-deco-line"></div>';
      }
    }
    gutterIn.innerHTML = parts.join('');
    decoIn.innerHTML = decos.join('');
    updateGutterWidth(n);
    gutterN = n;
    gutterDirty = false;
  }

  function syncScroll() {
    const sx = ta.scrollLeft;
    const sy = ta.scrollTop;
    pre.style.transform = 'translate(' + (-sx) + 'px,' + (-sy) + 'px)';
    decoIn.style.transform = 'translateY(' + (-sy) + 'px)';
    gutterIn.style.transform = 'translateY(' + (-sy) + 'px)';
    /* 覆盖装饰层原来只有静态坐标、没有跟着滚动走（缩进线与括号在滚动后整体错位）。
     * 这一层现在是查找高亮的宿主，必须一起平移：ovlIn 吃纵向、hgrid 吃横向。 */
    ovlIn.style.transform = 'translateY(' + (-sy) + 'px)';
    hgrid.style.transform = 'translateX(' + (-sx) + 'px)';
    scheduleMinimap();          // 视口框要跟滚动走，但只在 rAF 里画一次
  }

  

  /* ---------- 缩进参考线 / 当前行高亮 ----------
   * 上一轮只建了 .ccl-ed-guides / .ccl-ed-curline 的容器与 CSS，
   * 填充与定位逻辑没写（容器永远空着）。这里补齐。
   */
  function renderGuides() {
    if (!guidesEl) return;
    const lines = ta.value.split('\n');
    let html = '';
    let guard = 0;                       // 防御：极端文件不要生成几万个节点
    for (let i = 0; i < lines.length && guard < 3000; i++) {
      const lead = (lines[i].match(/^[ \t]*/) || [''])[0];
      const spaces = lead.replace(/\t/g, '    ').length;
      const levels = Math.floor(spaces / 4);
      for (let k = 1; k <= levels && guard < 3000; k++, guard++) {
        // top 用行高像素、left 用 ch（等宽字体下 1ch = 一个字符宽，与字号无关）
        html += '<div class="ccl-ed-indent" style="top:' + (padT + i * lh) +
                'px;left:' + (k * 4) + 'ch"></div>';
      }
    }
    guidesEl.innerHTML = html;
  }

  /* 括号匹配：光标贴着括号时把**成对的两个**都高亮。
     注意与下面的 PAIRS 区分：那个是"你打 ( 自动补 )"的配对，这个是"找出另一半"。 */
  const BR_OPEN = { '(': ')', '[': ']', '{': '}' };
  const BR_CLOSE = { ')': '(', ']': '[', '}': '{' };

  function findBracketPair(v, pos) {
    const left = pos > 0 ? v.charAt(pos - 1) : '';
    const right = pos < v.length ? v.charAt(pos) : '';
    let start, open, close, dir;
    if (BR_OPEN[left]) { start = pos - 1; open = left; close = BR_OPEN[left]; dir = 1; }
    else if (BR_CLOSE[right]) { start = pos; open = BR_CLOSE[right]; close = right; dir = -1; }
    else return null;

    let depth = 0;
    for (let i = start; i >= 0 && i < v.length; i += dir) {
      const c = v.charAt(i);
      // 向外找开括号时遇到开括号 +1；向内找闭括号时同向计
      if (dir > 0) { if (c === open) depth++; else if (c === close) depth--; }
      else { if (c === close) depth++; else if (c === open) depth--; }
      if (depth === 0) return dir > 0 ? [start, i] : [i, start];
    }
    return null;
  }

  function lineColOf(v, pos) {
    let line = 1, ls = 0;
    for (let i = 0; i < pos; i++) {
      if (v.charCodeAt(i) === 10) { line++; ls = i + 1; }
    }
    return { line, col: pos - ls };
  }

  function renderBrackets() {
    if (!bracketsEl) return;
    bracketsEl.innerHTML = '';
    const v = ta.value;
    const pos = ta.selectionStart;
    if (ta.selectionEnd !== pos) return;            // 有选区时不高亮，避免误导
    const pair = findBracketPair(v, pos);
    if (!pair) return;
    let html = '';
    for (const idx of pair) {
      const lc = lineColOf(v, idx);
      // 与文本层同一坐标系：纵向务必带 padT，横向带 padX（否则偏 8px / 10px）
      html += '<div class="ccl-ed-bracket" style="top:' + (padT + (lc.line - 1) * lh) +
              'px;left:calc(' + padX + 'px + ' + lc.col + 'ch)"></div>';
    }
    bracketsEl.innerHTML = html;
  }

  function paintCurline() {
    if (!curline) return;
    const line = caretLineCol().line;
    // 装饰层 .ccl-ed-ovl-in 没有 padding，而文本从 padT 开始 ——
    // 漏掉 padT 会让高亮整行上移 8px（用户实测报过）。
    curline.style.top = (padT + (line - 1) * lh) + 'px';
    curline.dataset.line = String(line);
  }

  function renderNow() {
    mmRev++;                     // 文本修订号：小地图的文档层缓存靠它失效
    preCode.innerHTML = highlight(ta.value);
    renderLines(false);
    renderGuides();
    paintCurline();
    paintFind();                 // 文本一变，命中的位置与数量也跟着变
    syncScroll();                // 里面顺带排一次小地图重绘（rAF 合并）
  }

  function scheduleRender() {
    if (rafId) return;
    rafId = requestAnimationFrame(() => {
      rafId = 0;
      renderNow();
    });
  }

  /* ================= 小地图（Round 5）=================
   *
   * 结构：.ccl-ed > #minimap（绝对定位右侧、宽 70）> canvas。
   *
   * 绘制分两层，这是它能便宜到「随便滚」的关键：
   *   · 文档层（每条源码行一块色块）画进离屏 canvas 缓存，只有「文本变了 / 尺寸变了」
   *     才重画一次；
   *   · 视口框每帧叠在缓存上，所以一次滚动 = 一次 drawImage + 一个方块。
   * 触发方式统一走 scheduleMinimap()：一切滚动、编辑、缩放都只排一个 rAF，
   * 绝不在 keydown / scroll 回调里直接画（那样一秒钟能画上百次）。
   */

  function scheduleMinimap() {
    if (!mmOn) {
      /* 自动开启判据（实测修正过一次）：
       * 原来写的是「#editor-host ≥ 1000」，但 1280 的桌面里活动栏 48 + 侧栏 240 吃掉 288，
       * 宿主只有 992 —— 判据永不成立，小地图一次都没开过。
       * 现在按**视口**宽判断（桌面语义），再用「宿主 ≥480」兜住「侧栏展开把编辑区挤窄」
       * 和「宿主还没布局出来（宽 0）」两种情况。
       * 只要外部显式调过 setMinimap()，mmUserSet 就为真，不再自动开合。 */
      const vw = window.innerWidth || 0;
      if (!mmUserSet && host.clientWidth >= 480 && (vw >= 1024 || host.clientWidth >= 1000)) {
        mmApply(true);
      }
      return;
    }
    if (mmRaf) return;
    mmRaf = requestAnimationFrame(() => {
      mmRaf = 0;
      drawMinimap();
    });
  }

  /** 内部开关：只动 DOM 与布局，不记录「用户意愿」 */
  function mmApply(on) {
    mmOn = !!on;
    mmWrap.style.display = mmOn ? '' : 'none';
    // padding-right 把内容区让出来，小地图才不会压住 textarea 右侧的滚动条。
    // 这是「跟随开关动态变化」的尺寸值，属于允许写在 JS 里的那一类。
    wrap.style.paddingRight = mmOn ? MM_W + 'px' : '';
    syncScroll();                    // 可视宽度变了，横向位置要重算
    if (mmOn) scheduleMinimap();
  }

  /** 对外开关：显式调用过一次之后就不再自动开合（用户说了算） */
  function setMinimap(on) {
    mmUserSet = true;
    mmApply(on);
  }

  /** 量一次 1ch 的像素宽度（等宽字体下就是字宽）。字号变了会重测。 */
  function measureCh() {
    if (chPx && chPxFs === fs) return chPx;
    const probe = document.createElement('span');
    probe.textContent = 'M'.repeat(50);
    probe.style.cssText = 'position:absolute;left:-9999px;top:0;visibility:hidden;' +
      'white-space:pre;letter-spacing:0;font-family:' + FONT_MONO +
      ';font-size:' + fs + 'px;line-height:' + lh + 'px';
    wrap.appendChild(probe);
    const w = probe.getBoundingClientRect().width / 50;
    probe.remove();
    chPx = w > 0 ? w : fs * 0.6;     // 藏着量不到时退回经验值，只影响横向滚动精度
    chPxFs = fs;
    return chPx;
  }

  /** 小地图的显示尺寸（CSS px）。位图尺寸另按 dpr 放大，否则高分屏会糊。 */
  function mmSize() {
    return {
      w: Math.max(8, Math.round(mmWrap.clientWidth || MM_W)),
      h: Math.max(0, Math.round(mmWrap.clientHeight || 0)),
    };
  }

  function drawMinimap() {
    if (!mmOn) return;
    const dim = mmSize();
    if (dim.h < 8) return;           // 还没布局出来（启动阶段），等 ResizeObserver 再来
    const w = dim.w;
    const h = dim.h;
    const dpr = window.devicePixelRatio || 1;
    const bw = Math.round(w * dpr);
    const bh = Math.round(h * dpr);
    if (mmCanvas.width !== bw || mmCanvas.height !== bh) {
      mmCanvas.width = bw;
      mmCanvas.height = bh;
      mmDpr = dpr;
      mmKey = '';                    // 位图重设后文档层缓存作废
    }
    const ctx = mmCanvas.getContext('2d');
    if (!ctx) return;

    // ---- 文档层（有缓存）----
    const key = mmRev + '|' + w + '|' + h + '|' + dpr;
    if (key !== mmKey) {
      mmKey = key;
      paintMinimapDoc(w, h, dpr);
    }

    // ---- 合成：底色 → 文档层 → 视口框 ----
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, bw, bh);
    ctx.fillStyle = C_MM_BG;
    ctx.fillRect(0, 0, bw, bh);
    if (mmDoc) ctx.drawImage(mmDoc, 0, 0, bw, bh);

    // 视口框用真实滚动几何算，不靠上面压缩后的行高去推
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const sh = Math.max(1, ta.scrollHeight);
    const viewH = Math.max(2, Math.min(h, (ta.clientHeight / sh) * h));
    const viewY = Math.max(0, Math.min(h - viewH, (ta.scrollTop / sh) * h));
    ctx.fillStyle = C_MM_VIEW;
    ctx.fillRect(0, viewY, w, viewH);
    ctx.strokeStyle = C_MM_VIEW_EDGE;
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, viewY + 0.5, w - 1, viewH - 1);
  }

  /** 把整篇文本压成一张「行块图」，存到 mmDoc（离屏 canvas，物理像素） */
  function paintMinimapDoc(w, h, dpr) {
    const cv = document.createElement('canvas');
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(h * dpr);
    const ctx = cv.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    const lines = ta.value.split('\n');
    const n = lines.length;
    if (!n) { mmDoc = cv; return; }

    // 纵向：整个文档压进容器高度（VS Code 的「全览」语义）。
    // 行数极多时每行不足 1px，就按 1px 画 —— 重叠后自然成了密度图。
    const rowH = Math.max(1, (h - 2) / n);

    // 横向：按最长行归一化；字符列宽封顶 1.6px，短文件不会画成几坨大色块。
    let maxLen = 1;
    for (let i = 0; i < n; i++) {
      const t = lines[i].replace(/\s+$/, '');
      if (t.length > maxLen) maxLen = t.length;
    }
    const colW = Math.min(1.6, (w - 8) / maxLen);

    const step = n > 4000 ? Math.ceil(n / 4000) : 1;   // 超长文件抽样，别一次画上万块
    for (let i = 0; i < n; i += step) {
      const ln = lines[i];
      const t = ln.replace(/\s+$/, '');
      if (!t) continue;                                 // 空行不画：省时间，画面也更干净
      const lead = t.length - t.replace(/^[ \t]+/, '').length;
      const body = t.slice(lead);
      if (!body) continue;
      const x = 3 + lead * colW;
      const bwid = Math.min(Math.max(1, body.length * colW), Math.max(1, w - x - 1));
      ctx.fillStyle = mmLineColor(body);
      ctx.fillRect(x, 1 + i * rowH, bwid, Math.max(1, Math.min(rowH, 3)));
    }
    mmDoc = cv;
  }

  /** 小地图行色：只看行首字符区分注释 / 字符串 / 其它，够用且不用跑词法 */
  function mmLineColor(body) {
    const c = body.charAt(0);
    if (c === '#') return C_MM_CMT;
    if (c === '"' || c === "'") return C_MM_STR;
    return C_MM_TXT;
  }

  /** 小地图上某个 y（clientY）→ 滚动位置；点哪行就把哪行拉到视口中间 */
  function mmSeek(clientY) {
    const r = mmCanvas.getBoundingClientRect();
    if (r.height <= 0) return;
    const y = Math.max(0, Math.min(r.height, clientY - r.top));
    const sh = ta.scrollHeight;
    const target = (y / r.height) * sh - ta.clientHeight / 2;
    ta.scrollTop = Math.max(0, Math.min(sh - ta.clientHeight, target));
    syncScroll();
  }

  mmCanvas.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    mmDrag = true;
    // 抓住指针：拖动时手指/鼠标移出小地图也不断，与 VS Code 一致
    if (mmCanvas.setPointerCapture) {
      try { mmCanvas.setPointerCapture(e.pointerId); } catch (_) { /* 老浏览器忽略 */ }
    }
    mmSeek(e.clientY);
  });
  mmCanvas.addEventListener('pointermove', (e) => {
    if (!mmDrag) return;
    e.preventDefault();
    mmSeek(e.clientY);
  });
  const mmStopDrag = () => { mmDrag = false; };
  mmCanvas.addEventListener('pointerup', mmStopDrag);
  mmCanvas.addEventListener('pointercancel', mmStopDrag);

  /* ---------- 光标 ---------- */

  function caretLineCol() {
    const v = ta.value;
    const p = ta.selectionStart;
    let line = 1;
    let ls = 0;
    for (let i = 0; i < p; i++) {
      if (v.charCodeAt(i) === 10) { line++; ls = i + 1; }
    }
    return { line: line, col: p - ls + 1 };
  }

  // 同步上报（不再走 rAF）：行/列是廉价计算，同步调用才能让 setRangeText 之后的
  // 立即读取（以及自动化测试）拿到真实值。去重避免 selectionchange 刷屏。
  let lastEmitKey = '';
  function emitCursor(force) {
    if (typeof paintCurline === 'function') paintCurline();   // 当前行跟着光标走
    if (typeof renderBrackets === 'function') renderBrackets();
    if (!opts.onCursor) return;
    const lc = caretLineCol();
    const key = lc.line + ':' + lc.col;
    if (!force && key === lastEmitKey) return;
    lastEmitKey = key;
    opts.onCursor(lc.line, lc.col);
  }

  /* ---------- 键盘遮挡 ---------- */

  function ensureCaretVisible() {
    if (document.activeElement !== ta) return;
    const vp = window.visualViewport;
    const visBottom = vp ? (vp.height + (vp.offsetTop || 0)) : window.innerHeight;
    const r = ta.getBoundingClientRect();
    const line = caretLineCol().line;
    const caretTop = r.top + padT + (line - 1) * lh - ta.scrollTop;
    const caretBottom = caretTop + lh;
    const margin = 12;
    if (caretBottom > visBottom - margin) {
      ta.scrollTop += caretBottom - (visBottom - margin) + lh;
      syncScroll();
    } else if (caretTop < margin) {
      ta.scrollTop = Math.max(0, ta.scrollTop + caretTop - margin);
      syncScroll();
    }
  }

  /* ---------- 撤销 / 重做（自维护快照栈） ----------
   *
   * 为什么不用浏览器原生 undo：本模块所有编辑都靠 setRangeText 完成，它不进原生
   * 撤销栈；而合成的 keydown 事件驱动不了浏览器默认动作，所以「按一 Ctrl+Z」在
   * 任何自动化验收里都会一动不动。因此这里自维护快照栈，并接管 Ctrl/Cmd+Z、
   * Ctrl/Cmd+Shift+Z、Ctrl+Y（外加 beforeinput 的 historyUndo/historyRedo）。
   * 原生打字由 beforeinput 记录：一次操作 = 一条撤销记录。 */

  const UNDO_MAX = 200;      // 最多保留多少条
  const GROUP_MS = 600;      // 连续打字在这个间隔内合并成一步

  let undoStack = [];        // 每次改动「之前」的快照 {value,s,e}
  let redoStack = [];        // 被撤销掉的快照
  let lastEditAt = 0;
  let lastSnap = null;       // 上一次改动之后的快照（beforeinput 缺失时兜底）
  let pendingRecord = false; // beforeinput 已经记过这次改动

  function snap() {
    return { value: ta.value, s: ta.selectionStart, e: ta.selectionEnd };
  }
  lastSnap = snap();

  function pushSnap(st) {
    undoStack.push(st);
    if (undoStack.length > UNDO_MAX) undoStack.shift();
    redoStack.length = 0;
    lastEditAt = Date.now();
  }

  /** 改动发生「之前」调用；group=true 表示可与紧接着的上一次改动合并成一步 */
  function recordUndo(group) {
    const now = Date.now();
    if (group && undoStack.length && now - lastEditAt < GROUP_MS) {
      lastEditAt = now;
      redoStack.length = 0;
      return;
    }
    pushSnap(snap());
    lastEditAt = now;
  }

  function clearHistory() {
    undoStack = [];
    redoStack = [];
    lastEditAt = 0;
    lastSnap = snap();
    pendingRecord = false;
  }

  function applySnapshot(st) {
    if (!st) return;
    const stTop = ta.scrollTop;
    ta.value = st.value;
    const n = st.value.length;
    const s = Math.max(0, Math.min(n, Math.floor(st.s) || 0));
    const e = Math.max(s, Math.min(n, Math.floor(st.e) || 0));
    ta.setSelectionRange(s, e);
    ta.scrollTop = stTop;
    renderNow();
    lastSnap = snap();
    pendingRecord = false;
    if (opts.onChange) opts.onChange(ta.value);
    emitCursor(true);
    ensureCaretVisible();
  }

  function doUndo() {
    if (!undoStack.length) return false;
    const st = undoStack.pop();
    redoStack.push(snap());
    applySnapshot(st);
    return true;
  }

  function doRedo() {
    if (!redoStack.length) return false;
    const st = redoStack.pop();
    undoStack.push(snap());
    applySnapshot(st);
    return true;
  }

  /* ---------- 编辑动作 ---------- */

  function afterEdit() {
    lastSnap = snap();
    pendingRecord = false;
    scheduleRender();
    if (opts.onChange) opts.onChange(ta.value);
    emitCursor();
    ensureCaretVisible();
  }

  /** 只移动了光标、文本没变 —— 不要触发 onChange（否则会误标脏） */
  function afterCaret() {
    emitCursor(true);
    ensureCaretVisible();
  }

  function lineStartOf(v, pos) {
    return v.lastIndexOf('\n', pos - 1) + 1;
  }

  /**
   * 计算「受选区影响的行」区间：返回 [ls, stop] 以及每行内容。
   * 选区正好停在下一行行首时，不把那一行算进来（与 VS Code 一致）。
   */
  function blockRange() {
    const v = ta.value;
    const s = ta.selectionStart;
    const en = ta.selectionEnd;
    const ls = lineStartOf(v, s);
    let stopPos = en;
    if (en > s && v.charAt(en - 1) === '\n') stopPos = en - 1;
    const nl = v.indexOf('\n', stopPos);
    const stop = nl === -1 ? v.length : nl;
    return { v: v, s: s, en: en, ls: ls, stop: stop, lines: v.slice(ls, stop).split('\n') };
  }

  function handleTab(shift) {
    const s = ta.selectionStart;
    const en = ta.selectionEnd;
    const st = ta.scrollTop;

    if (!shift && s === en) {
      recordUndo(false);
      ta.setRangeText(TAB, s, en, 'end');
      ta.scrollTop = st;
      afterEdit();
      return;
    }

    // 多行（或 Shift+Tab 单行）整体缩进 / 反缩进 —— 整块替换 = 一条撤销记录
    const blk = blockRange();
    const ls = blk.ls;
    const stop = blk.stop;
    const lines = blk.lines;
    let firstDelta = 0;
    let totalDelta = 0;
    const out = lines.map((ln, i) => {
      if (!shift) {
        if (i === 0) firstDelta = TAB.length;
        totalDelta += TAB.length;
        return TAB + ln;
      }
      const m = ln.match(/^( {1,4}|\t)/);
      if (!m) return ln;
      const rm = m[1].length;
      if (i === 0) firstDelta = -rm;
      totalDelta -= rm;
      return ln.slice(rm);
    });

    const block = out.join('\n');
    if (block === blk.v.slice(ls, stop)) {     // 无可改（如 Shift+Tab 已无缩进）
      ta.setSelectionRange(Math.max(0, s + firstDelta), Math.max(0, en + totalDelta));
      ta.scrollTop = st;
      afterCaret();
      return;
    }
    recordUndo(false);
    ta.setRangeText(block, ls, stop, 'preserve');
    const ns = Math.max(ls, s + firstDelta);
    const ne = Math.max(ns, en + totalDelta);
    ta.setSelectionRange(ns, ne);
    ta.scrollTop = st;
    afterEdit();
  }

  function handleEnter() {
    const v = ta.value;
    const s = ta.selectionStart;
    const en = ta.selectionEnd;
    const ls = lineStartOf(v, s);
    const before = v.slice(ls, s);
    const indent = (before.match(/^[ \t]*/) || [''])[0];
    const trimmed = before.replace(/[ \t]+$/, '');
    const extra = trimmed.charAt(trimmed.length - 1) === ':' ? TAB : '';
    const ins = '\n' + indent + extra;
    const st = ta.scrollTop;
    recordUndo(false);
    ta.setRangeText(ins, s, en, 'end');
    ta.scrollTop = st + lh;
    afterEdit();
  }

  const PAIRS = { '(': ')', '[': ']', '{': '}', '"': '"', "'": "'" };
  const CLOSERS = new Set([')', ']', '}']);

  function handlePair(key) {
    const v = ta.value;
    const s = ta.selectionStart;
    const en = ta.selectionEnd;
    const close = PAIRS[key];

    if (s !== en) {
      const sel = v.slice(s, en);
      ta.setRangeText(key + sel + close, s, en, 'preserve');
      ta.setSelectionRange(s + 1, en + 1);
      afterEdit();
      return;
    }

    const next = v.charAt(s);
    if (next === close) {                 // 下一个字符已是右半边 → 跳过而不是重复插入
      ta.setSelectionRange(s + 1, s + 1);
      afterCaret();
      return;
    }
    // 引号只在「词首」位置自动配对，避免 don't 这种被拆
    if (key === '"' || key === "'") {
      const prev = s > 0 ? v.charAt(s - 1) : '\n';
      if (!/[\s(\[{,;:=+\-*/<>!&|^%~\n]/.test(prev)) return;
    }
    recordUndo(false);
    ta.setRangeText(key + close, s, s, 'preserve');
    ta.setSelectionRange(s + 1, s + 1);    // 光标落在两个半边中间
    afterEdit();
  }

  /* ---------- Ctrl/Cmd+/ 注释切换（多行原子操作） ---------- */

  const CMT_RE = /^([ \t]*)#[ \t]?/;

  function toggleComment() {
    const blk = blockRange();
    const lines = blk.lines;

    // 光标停在单行空白上（或整块全空）：没有内容可切换，直接插入注释头，与 VS Code 一致
    if (lines.every((ln) => ln.trim() === '')) {
      const at = blk.ls;
      recordUndo(false);
      ta.setRangeText('# ', at, at, 'preserve');
      ta.setSelectionRange(at + 2, at + 2);
      afterEdit();
      return;
    }

    // 空行不算数；只要还有一行没被注释，就整体「加注释」
    const uncomment = lines.every((ln) => ln.trim() === '' || CMT_RE.test(ln));

    let firstDelta = 0;
    let totalDelta = 0;
    const out = lines.map((ln, i) => {
      let next;
      if (uncomment) next = ln.replace(CMT_RE, '$1');        // 去掉「# 」，保留缩进
      else if (ln.trim() === '') next = ln;                  // 空行不留孤零零的「# 」
      else next = '# ' + ln;                                 // 行首加「# 」
      const d = next.length - ln.length;
      if (i === 0) firstDelta = d;
      totalDelta += d;
      return next;
    });

    const block = out.join('\n');
    if (block === blk.v.slice(blk.ls, blk.stop)) { afterCaret(); return; }
    const st = ta.scrollTop;
    recordUndo(false);
    ta.setRangeText(block, blk.ls, blk.stop, 'preserve');
    const ns = Math.max(blk.ls, blk.s + firstDelta);
    const ne = Math.max(ns, blk.en + totalDelta);
    ta.setSelectionRange(ns, ne);
    ta.scrollTop = st;
    afterEdit();
  }

  /* ================= 字号缩放（Round 5）=================
   *
   * 三层（行号列 / pre / textarea）本来就共用 --ccl-fs / --ccl-lh 两个 CSS 变量，
   * 所以改字号 = 改这两个变量 + 把实例里的 lh 换掉，然后重渲染一次。
   * 行高按 20/13 的固定比例跟着走，「一行文字 = 一行装饰」这条前提永不破，
   * 装饰层的像素坐标（padT + 行号 × lh）才不会歪。
   */

  function applyFontMetrics() {
    wrap.style.setProperty('--ccl-fs', fs + 'px');
    wrap.style.setProperty('--ccl-lh', lh + 'px');
  }

  function setFontSize(px) {
    const next = Math.max(FONT_MIN, Math.min(FONT_MAX, Math.round(Number(px) || fs)));
    if (next === fs) return;
    const keepTop = ta.scrollTop;
    const keepLeft = ta.scrollLeft;
    fs = next;
    lh = Math.round(fs * LH_RATIO);
    chPx = 0;                        // 字宽缓存作废，下次用时重测
    applyFontMetrics();
    ta.scrollTop = keepTop;          // 行高变了 scrollTop 会自己跳，尽量保住视野
    ta.scrollLeft = keepLeft;
    renderNow();
    if (opts.onFontSize) opts.onFontSize(fs);   // 交给 main.js 持久化
  }

  function getFontSize() {
    return fs;
  }

  /* ================= 软换行（契约要求的同步，默认关闭）=================
   *
   * 契约只要「textarea 的 wrap 与 pre 的 white-space 同步」，这里就只做这件事。
   * ⚠️ 开启软换行后一条逻辑行会占多个视觉行，而缩进线 / 括号 / 查找命中 / 当前行
   *    都是按「逻辑行号 × 行高」算的像素坐标，必然错位 —— 所以换行态下把这层逐行
   *    装饰整体藏起来（.ccl-ed-ovl），关掉立刻恢复。行号列不受影响。
   */
  function setWrap(on) {
    const wrapOn = !!on;
    wrap.classList.toggle('ccl-ed-wrap', wrapOn);
    ta.setAttribute('wrap', wrapOn ? 'soft' : 'off');
    const ws = wrapOn ? 'pre-wrap' : 'pre';
    ta.style.whiteSpace = ws;
    pre.style.whiteSpace = ws;
    ta.style.overflowWrap = wrapOn ? 'anywhere' : 'normal';
    ovl.style.display = wrapOn ? 'none' : '';
    if (!wrapOn) { renderNow(); return; }
    layoutSync();
  }

  /* ================= 查找 / 替换（Round 5）=================
   *
   * 命中一律按「字符偏移」记录：{start, len, line, col}。
   *   · 装饰层用 line/col 换算像素（与缩进线、括号同一套坐标系，故挂在 hgrid 里）；
   *   · 替换用 start/len 直接 setRangeText，所以软换行、制表符都不会让它错位。
   * 大小写不敏感（与 VS Code 默认一致）。
   * 替换 / 全部替换都必须可撤销：一律先 recordUndo() 再改文本，走的是本模块
   * 自维护的快照栈 —— 与打字、Tab 缩进、注释切换是同一条撤销链。
   */

  /** 扫一遍全文收集命中。用 indexOf 而不是正则：不需要转义用户的查询串 */
  function collectMatches(q) {
    const out = [];
    if (!q) return out;
    const v = ta.value;
    const hay = v.toLowerCase();
    const needle = q.toLowerCase();
    const step = Math.max(1, needle.length);
    let from = 0;
    let line = 1;
    let ls = 0;      // 当前行的行首偏移
    let scan = 0;    // 已经数过换行的位置：命中是有序的，不必每次都从头数
    for (;;) {
      const p = hay.indexOf(needle, from);
      if (p === -1) break;
      for (let k = scan; k < p; k++) {
        if (v.charCodeAt(k) === 10) { line++; ls = k + 1; }
      }
      scan = p;
      out.push({ start: p, len: needle.length, line: line, col: p - ls });
      if (out.length >= FIND_MAX) break;
      from = p + step;
    }
    return out;
  }

  function updateFindCount() {
    if (!fbCount) return;
    const n = findState.matches.length;
    if (!findState.query) {
      fbCount.textContent = '';
      fbCount.classList.remove('no-hit');
      return;
    }
    // 无命中：只加 class，红色由 CSS 给（契约要求「标红由 CSS 上色」）
    fbCount.classList.toggle('no-hit', n === 0);
    fbCount.textContent = n ? (findState.cur + 1) + '/' + n : '0/0';
  }

  /** 重画命中装饰 + 更新计数。文本/查询变了都要重来一遍，所以它自己重算。 */
  function paintFind() {
    if (!findEl) return;
    if (!findState.open || !findState.query) {
      if (findEl.innerHTML) findEl.innerHTML = '';
      findState.matches = [];
      updateFindCount();
      return;
    }
    const ms = collectMatches(findState.query);
    findState.matches = ms;
    if (findState.cur >= ms.length) findState.cur = ms.length - 1;
    if (findState.cur < 0 && ms.length) {
      // 刚敲查询：从光标处往后找第一个，找不到就绕回开头
      const caret = ta.selectionStart;
      let idx = -1;
      for (let i = 0; i < ms.length; i++) if (ms[i].start >= caret) { idx = i; break; }
      findState.cur = idx === -1 ? 0 : idx;
    }
    let html = '';
    const nDraw = Math.min(ms.length, FIND_DRAW_MAX);
    for (let i = 0; i < nDraw; i++) {
      const m = ms[i];
      // 这里拼的全是数字，没有任何用户文本进来（escHtml 那套不需要）
      html += '<div class="ccl-ed-find-i' + (i === findState.cur ? ' on' : '') +
        '" style="top:' + (padT + (m.line - 1) * lh) + 'px;left:calc(' + padX + 'px + ' +
        m.col + 'ch);width:' + Math.max(1, m.len) + 'ch"></div>';
    }
    findEl.innerHTML = html;
    updateFindCount();
  }

  /** 上一个 / 下一个，dir = -1 / +1 */
  function findStep(dir) {
    if (!findState.open || !findState.query) return;
    const ms = findState.matches.length ? findState.matches : collectMatches(findState.query);
    if (!ms.length) { findState.matches = ms; findState.cur = -1; paintFind(); return; }
    if (findState.cur < 0) {
      const caret = ta.selectionStart;
      let idx = -1;
      for (let i = 0; i < ms.length; i++) if (ms[i].start >= caret) { idx = i; break; }
      findState.cur = idx === -1 ? 0 : idx;
    } else {
      findState.cur = (findState.cur + dir + ms.length) % ms.length;
    }
    paintFind();
    const m = findState.matches[findState.cur];
    if (m) revealPosition(m.start);
  }

  /** 滚动到某个字符偏移处（findbar 定位当前命中用） */
  function revealPosition(pos) {
    const v = ta.value;
    const p = Math.max(0, Math.min(v.length, Math.floor(Number(pos)) || 0));
    const lc = lineColOf(v, p);
    const top = padT + (lc.line - 1) * lh;
    const h = ta.clientHeight;
    if (top < ta.scrollTop) {
      ta.scrollTop = Math.max(0, top - lh * 2);
    } else if (top + lh > ta.scrollTop + h) {
      ta.scrollTop = top - h + lh * 3;
    }
    // 横向：等宽字体下「列 × 字宽」就是偏移量，留几个字宽的余量
    const ch = measureCh();
    const x = padX + lc.col * ch;
    const w = ta.clientWidth;
    if (x < ta.scrollLeft) ta.scrollLeft = Math.max(0, x - padX - ch * 4);
    else if (x > ta.scrollLeft + w - ch * 6) ta.scrollLeft = Math.max(0, x - w + ch * 8);
    syncScroll();
  }

  function openFind() {
    if (!fb) return;
    // 有单行选区时把选中的文字直接当查询（VS Code 的行为），省一次复制粘贴
    if (!findState.open) {
      const sel = ta.selectionEnd > ta.selectionStart
        ? ta.value.slice(ta.selectionStart, ta.selectionEnd) : '';
      if (sel && sel.indexOf('\n') === -1 && sel.length <= 200) fbFind.value = sel;
    }
    fb.style.display = '';
    fb.setAttribute('aria-hidden', 'false');
    findState.open = true;
    findState.query = fbFind.value;
    findState.cur = -1;
    paintFind();
    fbFind.focus();
    fbFind.select();
    const m = findState.matches[findState.cur];
    if (m) revealPosition(m.start);
  }

  function closeFind() {
    if (!findState.open) { ta.focus(); return; }
    findState.open = false;
    findState.query = '';
    findState.cur = -1;
    findState.matches = [];
    fb.style.display = 'none';
    fb.setAttribute('aria-hidden', 'true');
    if (findEl) findEl.innerHTML = '';
    updateFindCount();
    ta.focus();                 // 契约：关闭后焦点还给编辑器
    ensureCaretVisible();
  }

  /** 替换当前命中。一次替换 = 一条撤销记录（recordUndo → setRangeText → afterEdit） */
  function replaceOne() {
    if (!findState.open || !findState.query) return;
    if (!findState.matches.length) paintFind();
    const ms = findState.matches;
    if (!ms.length) return;
    if (findState.cur < 0) findState.cur = 0;
    const m = ms[findState.cur];
    const repl = fbRepl.value;
    const keepTop = ta.scrollTop;
    recordUndo(false);
    ta.setRangeText(repl, m.start, m.start + m.len, 'preserve');
    const caret = m.start + repl.length;
    ta.setSelectionRange(caret, caret);
    ta.scrollTop = keepTop;
    afterEdit();
    findState.cur = -1;         // 文本变了，命中要重算（paintFind 会重新定位）
    paintFind();
    const cur = findState.matches[findState.cur];
    if (cur) revealPosition(cur.start);
  }

  /** 全部替换。整篇一次 setRangeText，所以「一步撤销」就能整体退回 */
  function replaceAll() {
    if (!findState.open || !findState.query) return;
    const ms = findState.matches.length ? findState.matches : collectMatches(findState.query);
    if (!ms.length) { paintFind(); return; }
    const v = ta.value;
    const repl = fbRepl.value;
    let out = '';
    let last = 0;
    for (let i = 0; i < ms.length; i++) {
      out += v.slice(last, ms[i].start) + repl;
      last = ms[i].start + ms[i].len;
    }
    out += v.slice(last);
    if (out === v) return;      // 替换串和原串一样，没有可撤的改动
    const keepTop = ta.scrollTop;
    recordUndo(false);
    ta.setRangeText(out, 0, v.length, 'preserve');
    const caret = Math.min(ta.value.length, Math.max(0, ms[0].start));
    ta.setSelectionRange(caret, caret);
    ta.scrollTop = keepTop;
    afterEdit();
    findState.cur = -1;
    paintFind();
    revealPosition(caret);
  }

  /* ================= 行操作（Round 5）=================
   *
   * Alt+↑ / Alt+↓ 移行、Shift+Alt+↓ 复制行、Ctrl+Shift+K 删行。
   * 三者都是「一次 setRangeText 换掉整块」的原子操作：一条撤销记录，选区跟着行走。
   * 选区口径复用 blockRange()：选区正好停在下一行行首时，不把那一行算进来。
   */

  function moveLines(delta) {
    const d = delta < 0 ? -1 : 1;
    const blk = blockRange();
    const v = blk.v;
    const ls = blk.ls;
    const stop = blk.stop;
    const block = v.slice(ls, stop);
    const keepTop = ta.scrollTop;

    if (d < 0) {
      if (ls === 0) return;                       // 已在第一行，无路可上
      const prevLs = v.lastIndexOf('\n', ls - 2) + 1;
      const prev = v.slice(prevLs, ls - 1);       // 上一行（不含它自己的换行）
      const shift = prev.length + 1;
      recordUndo(false);
      // 交换：本块跑到上面，上一行掉到下面（顺序写反就是「原地不动」，实测踩过）
      ta.setRangeText(block + '\n' + prev, prevLs, stop, 'preserve');
      ta.setSelectionRange(blk.s - shift, blk.en - shift);
      ta.scrollTop = keepTop;
      afterEdit();
      return;
    }

    if (stop >= v.length) return;                 // 已在最后一行
    const nextNl = v.indexOf('\n', stop + 1);
    const nextStop = nextNl === -1 ? v.length : nextNl;
    const next = v.slice(stop + 1, nextStop);     // 下一行（不含换行）
    const shift = next.length + 1;
    recordUndo(false);
    // 交换：下一行提到上面，本块落到它原来的位置
    ta.setRangeText(next + '\n' + block, ls, nextStop, 'preserve');
    ta.setSelectionRange(blk.s + shift, blk.en + shift);
    ta.scrollTop = keepTop;
    afterEdit();
  }

  function duplicateLines() {
    const blk = blockRange();
    const block = blk.v.slice(blk.ls, blk.stop);
    const keepTop = ta.scrollTop;
    const shift = block.length + 1;
    recordUndo(false);
    // 在块尾插入「换行 + 同样的块」：块在文中（后面有换行）还是文末都成立
    ta.setRangeText('\n' + block, blk.stop, blk.stop, 'preserve');
    ta.setSelectionRange(blk.s + shift, blk.en + shift);
    ta.scrollTop = keepTop;
    afterEdit();
  }

  /** 向上复制行（Shift+Alt+↑）：新份落在上方，光标跟着新份，所以选区偏移量为 0 */
  function duplicateLinesUp() {
    const blk = blockRange();
    const block = blk.v.slice(blk.ls, blk.stop);
    const keepTop = ta.scrollTop;
    recordUndo(false);
    ta.setRangeText(block + '\n', blk.ls, blk.ls, 'preserve');
    ta.setSelectionRange(blk.s, blk.en);
    ta.scrollTop = keepTop;
    afterEdit();
  }

  function deleteLines() {
    const blk = blockRange();
    const v = blk.v;
    const ls = blk.ls;
    const stop = blk.stop;
    const keepTop = ta.scrollTop;
    let from = ls;
    let to = stop;
    if (stop < v.length) to = stop + 1;           // 连同它后面的换行一起删
    else if (ls > 0) from = ls - 1;               // 最后一行：删它前面那个换行
    recordUndo(false);
    ta.setRangeText('', from, to, 'preserve');
    ta.setSelectionRange(from, from);
    ta.scrollTop = keepTop;
    afterEdit();
  }

  /** 当前视口内的行区间（1-based，含两端）。findbar / 增量渲染都会用 */
  function getVisibleRange() {
    const total = countLines(ta.value);
    const first = Math.max(1, Math.min(total, Math.floor((ta.scrollTop - padT) / lh) + 1));
    const last = Math.max(first, Math.min(total,
      Math.floor((ta.scrollTop + ta.clientHeight - padT) / lh) + 1));
    return { from: first, to: last };
  }

  /** 只做「重排 + 滚动同步」，不重刷高亮：软换行切换、容器尺寸变化都够用 */
  function layoutSync() {
    renderLines(false);
    paintFind();
    syncScroll();
  }

  /* ---------- 事件 ---------- */

  ta.addEventListener('beforeinput', (e) => {
    const it = e.inputType || '';
    if (it === 'historyUndo' || it === 'historyRedo') {   // 原生撤销入口也接管
      e.preventDefault();
      if (it === 'historyUndo') doUndo(); else doRedo();
      return;
    }
    if (it === 'insertCompositionText') {                 // 输入法组合：整段算一步
      recordUndo(true);
      pendingRecord = true;
      return;
    }
    // 连续打字合并；删字 / 粘贴 / 换行各自独立
    const single = it === 'insertText' && typeof e.data === 'string' && e.data.length === 1;
    recordUndo(single && ta.selectionStart === ta.selectionEnd);
    pendingRecord = true;
  });

  ta.addEventListener('input', () => {
    if (!pendingRecord) pushSnap(lastSnap || snap());     // 引擎没派 beforeinput 时兜底
    pendingRecord = false;
    lastSnap = snap();
    scheduleRender();
    if (opts.onChange) opts.onChange(ta.value);
    emitCursor();
  });

  ta.addEventListener('keydown', (e) => {
    if (e.isComposing) return;
    const mod = e.ctrlKey || e.metaKey;
    const key = e.key;
    const low = key.length === 1 ? key.toLowerCase() : key;

    /* ---- Round 5：桌面上最常用的三个行操作 ----
     * 判定顺序放在最前面：「Alt+↑↓」不会被别的分支吃掉，
     * 「Ctrl+Shift+K」也不会落进后面的通用 mod 分支。
     *
     * stopPropagation 是必需的，不是保险：main.js 在 document 上也按同一批键位
     * 调 moveLines/duplicateLines/deleteLines（它没法判断编辑器自己已经处理过），
     * 事件冒泡上去就会**同一个按键执行两次**（实测：Alt+↓ 一次走两行，Ctrl+Shift+K
     * 一次删两行）。这里把事件截停在 textarea，只由本模块执行一次；
     * main.js 那边的菜单项是直接调 API 的，不受影响。 */
    if (e.altKey && !mod && (key === 'ArrowUp' || key === 'ArrowDown')) {
      e.preventDefault();
      e.stopPropagation();
      if (e.shiftKey) {
        // Shift+Alt+↓ = 向下复制行（契约要求）；Shift+Alt+↑ = 向上复制行（VS Code 同键位）
        if (key === 'ArrowUp') duplicateLinesUp();
        else duplicateLines();
      } else {
        moveLines(key === 'ArrowUp' ? -1 : 1);
      }
      return;
    }
    if (mod && e.shiftKey && !e.altKey && low === 'k') {    // 删除整行
      e.preventDefault();
      e.stopPropagation();
      deleteLines();
      return;
    }

    if (mod && !e.altKey && low === 'z') {                // 撤销 / 重做
      e.preventDefault();
      if (e.shiftKey) doRedo(); else doUndo();
      return;
    }
    if (mod && !e.altKey && low === 'y') {                // Windows 习惯的 redo
      e.preventDefault();
      doRedo();
      return;
    }
    if (mod && !e.altKey && (key === '/' || e.code === 'Slash')) {
      e.preventDefault();
      toggleComment();
      return;
    }
    if (key === 'Escape' && findState.open) {             // 焦点在编辑器里时 Esc 也能关浮层
      e.preventDefault();
      closeFind();
      return;
    }
    if (key === 'F3') {                                   // F3 / Shift+F3 = 下一个 / 上一个
      e.preventDefault();
      if (findState.open) findStep(e.shiftKey ? -1 : 1);
      else openFind();
      return;
    }
    if (key === 'Tab') {
      e.preventDefault();
      handleTab(e.shiftKey);
      return;
    }
    if (key === 'Enter' && mod) {
      e.preventDefault();
      if (opts.onRun) opts.onRun();
      return;
    }
    if (key === 'Enter') {
      e.preventDefault();
      handleEnter();
      return;
    }
    if (!mod && !e.altKey && CLOSERS.has(key)) {
      // 右半边：下一个字符正是它 → 光标跳过去（跳过），不要重复插入；否则原生插入
      const s2 = ta.selectionStart;
      if (s2 === ta.selectionEnd && s2 < ta.value.length && ta.value.charAt(s2) === key) {
        e.preventDefault();
        ta.setSelectionRange(s2 + 1, s2 + 1);
        afterCaret();
      }
      return;
    }
    if (!mod && !e.altKey && PAIRS[key]) {
      e.preventDefault();
      handlePair(key);
    }
  });

  ta.addEventListener('scroll', syncScroll, { passive: true });

  ta.addEventListener('focus', () => {
    renderNow();
    ensureCaretVisible();
    emitCursor();
  });

  ta.addEventListener('click', () => {
    emitCursor();
    ensureCaretVisible();
  });

  document.addEventListener('selectionchange', () => {
    if (document.activeElement === ta) emitCursor();
  });

  const onViewport = () => {
    if (document.activeElement === ta) ensureCaretVisible();
  };
  window.addEventListener('resize', onViewport);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', onViewport);
    window.visualViewport.addEventListener('scroll', onViewport);
  }

  /* ---------- 查找浮层的事件 ---------- */

  fbFind.addEventListener('input', () => {
    findState.query = fbFind.value;
    findState.cur = -1;
    paintFind();
    const m = findState.matches[findState.cur];
    if (m) revealPosition(m.start);      // 边打边滚到第一处命中
  });

  fbFind.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {              // Enter 下一个 / Shift+Enter 上一个
      e.preventDefault();
      findStep(e.shiftKey ? -1 : 1);
      return;
    }
    if (e.key === 'F3') { e.preventDefault(); findStep(e.shiftKey ? -1 : 1); }
  });

  fbRepl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if ((e.ctrlKey || e.metaKey) && e.altKey) replaceAll();
      else replaceOne();
    }
  });

  // Esc 不管焦点在浮层哪个元素上都关（含按钮上），关完焦点回编辑器
  fb.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); closeFind(); }
  });

  fbPrev.addEventListener('click', () => findStep(-1));
  fbNext.addEventListener('click', () => findStep(1));
  fbClose.addEventListener('click', () => closeFind());
  fbRep.addEventListener('click', () => replaceOne());
  fbRepAll.addEventListener('click', () => replaceAll());
  // 点按钮时别把焦点从输入框抢走，否则回车就不再是「下一个」
  [fbPrev, fbNext, fbRep, fbRepAll].forEach((b) => {
    b.addEventListener('mousedown', (e) => e.preventDefault());
  });

  /* ---------- Ctrl+滚轮 / Ctrl+= / Ctrl+- / Ctrl+0 ---------- */

  wrap.addEventListener('wheel', (e) => {
    if (!(e.ctrlKey || e.metaKey)) return;
    e.preventDefault();                   // 浏览器默认会整页缩放，必须拦掉
    setFontSize(fs + (e.deltaY < 0 ? 1 : -1));
  }, { passive: false });

  /** 全局快捷键：Ctrl+F 打开查找，Ctrl+=/-/0 缩放字号。
   *  只在「焦点在编辑器内、浮层内或页面空白处」时响应 ——
   *  分析参数输入框（#tbParams）里按 Ctrl+加号不该改代码字号。 */
  document.addEventListener('keydown', (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (!mod || e.altKey) return;
    const ae = document.activeElement;
    const mine = ae === ta || ae === fbFind || ae === fbRepl ||
      ae === document.body || ae === null;
    if (!mine) return;
    const k = e.key;
    if (k.length === 1 && k.toLowerCase() === 'f') {       // 查找
      e.preventDefault();
      openFind();
      return;
    }
    if (k === '=' || k === '+' || k === '_') {             // 放大
      e.preventDefault();
      setFontSize(fs + 1);
      return;
    }
    if (k === '-') {                                       // 缩小
      e.preventDefault();
      setFontSize(fs - 1);
      return;
    }
    if (k === '0') {                                       // 归位
      e.preventDefault();
      setFontSize(FONT_BASE);
    }
  });

  /* ---------- 右键 ----------
   * 菜单 DOM 由 main.js 建，本模块只负责：拦住浏览器菜单、把光标挪到落点、
   * 然后派发 ccl:contextmenu（bubbles，所以监听 #editor-host 或 document 都行）。 */

  /** 屏幕坐标 → 文本偏移；点在编辑器外返回 -1 */
  function offsetFromPoint(cx, cy) {
    const r = ta.getBoundingClientRect();
    if (cx < r.left || cx > r.right || cy < r.top || cy > r.bottom) return -1;
    const v = ta.value;
    const total = countLines(v);
    const y = cy - r.top + ta.scrollTop - padT;
    const line = Math.max(1, Math.min(total, Math.floor(y / lh) + 1));
    const x = cx - r.left + ta.scrollLeft - padX;
    const col = Math.max(0, Math.round(x / measureCh()));
    let start = 0;
    for (let i = 1; i < line; i++) {
      const p = v.indexOf('\n', start);
      if (p === -1) break;
      start = p + 1;
    }
    const nl = v.indexOf('\n', start);
    const end = nl === -1 ? v.length : nl;
    return Math.min(start + col, end);
  }

  wrap.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const pos = offsetFromPoint(e.clientX, e.clientY);
    const s = ta.selectionStart;
    const en = ta.selectionEnd;
    // 右键落在选区外：先把光标挪过去，菜单里的动作才作用于「点的这一行」
    if (pos >= 0 && (pos < s || pos > en)) ta.setSelectionRange(pos, pos);
    const lineNo = pos >= 0 ? lineColOf(ta.value, pos).line : caretLineCol().line;
    host.dispatchEvent(new CustomEvent('ccl:contextmenu', {
      detail: {
        x: Math.round(e.clientX),
        y: Math.round(e.clientY),
        hasSelection: ta.selectionStart !== ta.selectionEnd,
        line: lineNo,
      },
      bubbles: true,
    }));
  });

  /* ---------- 尺寸变化：小地图位图重算 ----------
   * 不用每次读 clientWidth 去猜，交给 ResizeObserver；它只在尺寸真的变了时回调。 */
  if (typeof ResizeObserver !== 'undefined') {
    const ro = new ResizeObserver(() => {
      mmKey = '';              // 位图与文档层缓存一并作废
      scheduleMinimap();
    });
    ro.observe(host);
  }

  /* ---------- 首帧 ---------- */
  renderNow();

  /* ---------- 对外 API ---------- */
  return {
    getValue() {
      return ta.value;
    },

    setValue(s) {
      ta.value = typeof s === 'string' ? s : String(s == null ? '' : s);
      ta.scrollTop = 0;
      ta.scrollLeft = 0;
      diagMap = new Map();
      gutterN = -1;
      renderNow();
      clearHistory();          // 换文件 = 换上下文，历史不跨文件
      emitCursor(true);
    },

    /** 在光标处插入文本；多行自动对齐当前行缩进；插入后光标在末尾；可一次撤销 */
    insertText(text) {
      const t = String(text == null ? '' : text);
      if (document.activeElement !== ta) ta.focus();
      const v = ta.value;
      const s = ta.selectionStart;
      const en = ta.selectionEnd;
      let out = t;
      if (t.indexOf('\n') !== -1) {
        const indent = (v.slice(lineStartOf(v, s), s).match(/^[ \t]*/) || [''])[0];
        const parts = t.split('\n');
        out = parts[0];
        for (let i = 1; i < parts.length; i++) {
          out += '\n';
          // 末尾那个空行不再补缩进，免得留下行尾空白
          if (!(i === parts.length - 1 && parts[i] === '')) out += indent + parts[i];
        }
      }
      const st = ta.scrollTop;
      recordUndo(false);
      ta.setRangeText(out, s, en, 'preserve');
      ta.setSelectionRange(s + out.length, s + out.length);
      ta.scrollTop = st;
      afterEdit();
    },

    /** 1-based 光标位置 */
    getCursor() {
      return caretLineCol();
    },

    undo() {
      return doUndo();
    },

    redo() {
      return doRedo();
    },

    focus() {
      ta.focus();
      ensureCaretVisible();
    },

    setDiagnostics(list) {
      diagMap = new Map();
      (Array.isArray(list) ? list : []).forEach((d) => {
        if (!d) return;
        const ln = Math.floor(Number(d.line));
        if (!ln || ln < 1) return;          // 后端 0 / 缺失 = 未知行，跳过
        const level = d.level === 'warn' ? 'warn' : 'error';
        const cur = diagMap.get(ln);
        if (!cur || (level === 'error' && cur.level !== 'error')) {
          diagMap.set(ln, { level: level, message: String(d.message == null ? '' : d.message) });
        }
      });
      gutterDirty = true;
      renderLines(true);
      syncScroll();
    },

    goToLine(n) {
      const total = countLines(ta.value);
      const line = Math.max(1, Math.min(total, Math.floor(Number(n)) || 1));
      const v = ta.value;
      let start = 0;
      for (let i = 1; i < line; i++) {
        const p = v.indexOf('\n', start);
        if (p === -1) { start = v.length; break; }
        start = p + 1;
      }
      const nl = v.indexOf('\n', start);
      const end = nl === -1 ? v.length : nl;

      ta.focus();
      ta.setSelectionRange(start, end);      // 选中整行，便于定位
      const y = padT + (line - 1) * lh;
      const ch = ta.clientHeight;
      ta.scrollTop = Math.max(0, y - ch / 2 + lh / 2);
      ta.scrollLeft = 0;
      syncScroll();
      emitCursor();
      ensureCaretVisible();
    },

    layout() {
      // 容器尺寸变了：行号列、命中装饰、小地图位图都要跟着重排
      layoutSync();
    },

    /* ===== Round 5：桌面版新增（只增不改，上面已有的签名一个都没动）=====
     * 这里用「属性简写」而不是方法定义：属性名与内部实现同名，
     * 简写只做一次绑定，不存在「方法体里又调用自己」的作用域歧义。 */
    openFind,
    closeFind,
    setFontSize,
    getFontSize,
    setWrap,
    setMinimap,
    moveLines,
    duplicateLines,
    deleteLines,
    getVisibleRange,
    revealPosition,
  };
}
