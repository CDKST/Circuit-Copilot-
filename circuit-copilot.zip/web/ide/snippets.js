/* ------------------------------------------------------------------
 * CCL Studio 代码片段库
 *
 * 侧边栏点「子电路库 / 器件速查」时，往编辑器插入一段**可直接跑**的代码。
 * 之前这些条目是纯展示、点了没反应——审计时发现的缺口。
 * ------------------------------------------------------------------ */

/** 子电路块 → 一行 use_ports 调用（默认参数取自 blocks.py 的默认值） */
export const BLOCK_SNIPPETS = {
  rc_lowpass:        'c.use_ports(BLOCKS["rc_lowpass"](fc=1e3), {"in": "in", "out": "out"})',
  rc_highpass:       'c.use_ports(BLOCKS["rc_highpass"](fc=1e3), {"in": "in", "out": "out"})',
  divider:           'c.use_ports(BLOCKS["divider"](ratio=0.5, total_r=10e3), {"in": "in", "out": "out"})',
  rlc_bandpass:      'c.use_ports(BLOCKS["rlc_bandpass"](f0=100e3, q=10), {"in": "in", "out": "out"})',
  noninv_amp:        'c.use_ports(BLOCKS["noninv_amp"](gain=10, gbw=1.3e6), {"in": "in", "out": "out"})',
  inv_amp:           'c.use_ports(BLOCKS["inv_amp"](gain=10, gbw=1.3e6), {"in": "in", "out": "out"})',
  sallen_key_lowpass:'c.use_ports(BLOCKS["sallen_key_lowpass"](fc=10e3, q=0.707), {"in": "in", "out": "out"})',
  bjt_ce_bias:       'c.use_ports(BLOCKS["bjt_ce_bias"](rc=100, rb=100e3), {"vcc": "vcc", "in": "in", "out": "out"})',
  emitter_follower:  'c.use_ports(BLOCKS["emitter_follower"](rb=100e3, re=1e3), {"vcc": "vcc", "in": "in", "out": "out"})',
  // 下面三个与 ccl/blocks.py 的 BLOCKS 一一对应（契约测试会核对两边键名一致，
  // 别再让「积木表加了、面板没加」这种漂移发生）
  sallen_key_highpass:'c.use_ports(BLOCKS["sallen_key_highpass"](fc=5e3, q=0.707), {"in": "in", "out": "out"})',
  difference_amp:    'c.use_ports(BLOCKS["difference_amp"](gain=10), {"inp": "inp", "inn": "inn", "out": "out"})',
  twin_t_notch:      'c.use_ports(BLOCKS["twin_t_notch"](f0=50), {"in": "in", "out": "out"})',
};

/** 器件 → 一行构造调用 */
export const DEVICE_SNIPPETS = {
  'c.R(a, b, value)': 'c.R("n1", "n2", 1e3)',
  'c.C(a, b, value)': 'c.C("n1", GND, 100e-9)',
  'c.L(a, b, value)': 'c.L("n1", "n2", 1e-3)',
  'c.V(a, b, dc, ac)': 'c.V("in", GND, dc=0, ac=1)',
  'c.I(a, b, dc, ac)': 'c.I("n1", GND, dc=1e-3, ac=0)',
  'c.OpAmp(inp, inn, out, gbw=)': 'c.OpAmp("inp", "inn", "out", gbw=1e6)',
  'c.D(a, k, model)': 'c.D("a", GND, "D1N4148")',
  'c.Q(c, b, e, model)': 'c.Q("cc", "b", GND, "Q2N3904")',
  'c.M(d, g, s, bulk, model)': 'c.M("d", "g", GND, None, "M2N7002")',
  'c.PULSE(a, b, v1, v2, ...)': 'c.PULSE("in", GND, v1=0, v2=5, pw=1e-3, per=2e-3)',
  'c.SIN(a, b, vo, va, freq)': 'c.SIN("in", GND, vo=0, va=1, freq=1e3)',
  'c.expect(kind, node, value, tol)': 'c.expect("fc", "out", 1e3, tol=0.05)',
  'c.use_ports(block, {in, out})': 'c.use_ports(BLOCKS["rc_lowpass"](fc=1e3), {"in": "in", "out": "out"})',
};

/** 需要额外 import 的片段，插入时要保证 import 行存在 */
export function requiredImports(snippet) {
  const need = [];
  if (snippet.includes('BLOCKS[')) need.push('from ccl.blocks import BLOCKS');
  return need;
}

/**
 * 把片段插入源码：先补齐缺的 import 行，再把片段插到光标处。
 * @returns {{code:string, cursorHint:string}} 新源码 + 给用户的提示
 */
export function mergeSnippet(code, cursorLine, snippet) {
  let src = code || '';
  const added = [];
  for (const imp of requiredImports(snippet)) {
    if (!src.includes(imp)) {
      // 插在最后一条 import 之后；没有 import 就放最前面
      const lines = src.split('\n');
      let idx = 0;
      for (let i = 0; i < lines.length; i++) {
        if (/^\s*(from|import)\s/.test(lines[i])) idx = i + 1;
      }
      lines.splice(idx, 0, imp);
      src = lines.join('\n');
      added.push(imp);
    }
  }
  return { code: src, addedImports: added };
}
