/* ------------------------------------------------------------------
 * 命令面板（Ctrl/Cmd+Shift+P）—— VS Code 的核心交互之一
 *
 * 用法：
 *   openCommandPalette([
 *     {id:'run', label:'运行电路', hint:'Ctrl+Enter', run(){...}},
 *     ...
 *   ])
 *
 * 自建 DOM（#cmdk），样式由 style.css 提供。键盘：↑↓ 选择、Enter 执行、Esc 关闭。
 * ------------------------------------------------------------------ */

let host = null;
let items = [];
let filtered = [];
let cursor = 0;

export function isOpen() { return !!host; }

export function openCommandPalette(commands, { placeholder = '输入命令…' } = {}) {
  close();
  items = (commands || []).filter(c => c && c.label);
  filtered = items.slice();
  cursor = 0;

  host = document.createElement('div');
  host.id = 'cmdk';
  host.innerHTML = `
    <div id="cmdk-box">
      <input id="cmdk-input" placeholder="${esc(placeholder)}" autocomplete="off" spellcheck="false">
      <div id="cmdk-list"></div>
    </div>`;
  document.body.appendChild(host);

  const input = host.querySelector('#cmdk-input');
  host.addEventListener('mousedown', (e) => { if (e.target === host) close(); });
  input.addEventListener('input', () => { cursor = 0; renderList(); });
  input.addEventListener('keydown', onKey);
  renderList();
  setTimeout(() => input.focus(), 0);
}

export function close() {
  if (host && host.parentNode) host.parentNode.removeChild(host);
  host = null; items = []; filtered = []; cursor = 0;
}

function onKey(e) {
  if (e.key === 'Escape') { e.preventDefault(); close(); return; }
  if (e.key === 'ArrowDown') { e.preventDefault(); cursor = Math.min(cursor + 1, filtered.length - 1); renderList(); return; }
  if (e.key === 'ArrowUp') { e.preventDefault(); cursor = Math.max(cursor - 1, 0); renderList(); return; }
  if (e.key === 'Enter') {
    e.preventDefault();
    const pick = filtered[cursor];
    if (pick) { close(); pick.run && pick.run(); }
    return;
  }
}

function renderList() {
  if (!host) return;
  const q = host.querySelector('#cmdk-input').value.trim().toLowerCase();
  filtered = !q ? items.slice() : items.filter(c =>
    (c.label + ' ' + (c.hint || '') + ' ' + (c.id || '')).toLowerCase().includes(q));
  if (cursor >= filtered.length) cursor = Math.max(0, filtered.length - 1);

  const list = host.querySelector('#cmdk-list');
  if (!filtered.length) {
    list.innerHTML = '<div class="cmdk-item cmdk-hint">没有匹配的命令</div>';
    return;
  }
  list.innerHTML = filtered.map((c, i) => `
    <div class="cmdk-item${i === cursor ? ' on' : ''}" data-i="${i}">
      <span>${esc(c.label)}</span>
      ${c.hint ? `<span class="cmdk-kbd">${esc(c.hint)}</span>` : ''}
    </div>`).join('');

  list.querySelectorAll('.cmdk-item[data-i]').forEach(el => {
    el.onmouseenter = () => { cursor = Number(el.dataset.i); paint(); };
    el.onclick = () => { const pick = filtered[Number(el.dataset.i)]; close(); pick && pick.run && pick.run(); };
  });
  paint();
  // 保证选中项可见
  const on = list.querySelector('.cmdk-item.on');
  if (on && on.scrollIntoView) on.scrollIntoView({ block: 'nearest' });
}

function paint() {
  if (!host) return;
  host.querySelectorAll('.cmdk-item[data-i]').forEach(el => {
    el.classList.toggle('on', Number(el.dataset.i) === cursor);
  });
}

function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
