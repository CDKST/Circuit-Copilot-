/* ------------------------------------------------------------------
 * CCL Studio —— 集成层（Lead 维护）
 *
 * 职责：拿数据、调后端、把结果分发给 editor.js / panels.js。
 * 不实现具体视觉与编辑器细节（那些归 ui-shell / ui-editor / ui-panel）。
 * ------------------------------------------------------------------ */

import { createEditor } from './editor.js';
import { createPanels } from './panels.js';
import { openCommandPalette, close as closePalette } from './commands.js';
import { renderSchematic, schematicOrEmpty, applyLive, parseFlowNets, timelineIndex,
         netCurrentSeries, deriveSwitchStates, switchSideEffects } from './schematic.js';
import { loadPlugins, getPanels, getCommands, renderPanel as renderPluginPanel,
         renderManager as renderPluginManager } from './plugins.js';
import * as boot from './boot.js';
import { BLOCK_SNIPPETS, DEVICE_SNIPPETS, mergeSnippet } from './snippets.js';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const S = {
  tabs: [],          // [{id,title,code,analysis}]
  activeTab: null,
  analysis: {
    kind: 'ac', f_start: 1, f_stop: 1e6, points: 100,
    t_step: 1e-6, t_stop: 5e-4,
    source: 'V1', dc_start: 0, dc_stop: 10, dc_step: 0.5,
    second_source: '', second_start: 0, second_stop: 1e-3, second_step: 5e-4,
  },
  examples: [],
  blocks: [],
  act: 'files',          // 当前活动栏项
  busy: false,
  rerunPending: false,   // 仿真期间点过开关 → 结束后补跑一次
  lastResult: null,
  // 开关的「用户意图」现在存在**每个标签页**里（S.tabs[i].switchStates）：
  // 位号 → true(闭合) / false(断开)。这是**输入量**（用户点的），不是仿真数据；
  // 请求时作为 switch_states 发给后端，后端按它改控制电压再跑仿真 ——
  // 图上看到的电流永远是仿真结果，不是前端编的。
  //
  // ⚑ 为什么必须按标签页存（原来这里是全局一份）：A 页点了 SW1 断开 → 切到 B 页
  // （B 也有 SW1）→ B 被**静默**强制断开，与 B 的代码不符、界面毫无提示，
  // 只能刷新页面才能恢复。开关覆盖是「对这份代码做的实验」，天然属于那个标签页。
  schemFor: null,        // 面板上那张图是哪个标签页/哪份代码跑出来的 {tabId, code}
  directoryHandle: null,
  localFiles: [],
};

let editor = null;
let panels = null;

/* ---------------- 本地持久化 ----------------
 * App 被系统杀掉 / 页面刷新后，写了一半的电路不能丢（手机上是真实风险）。
 * 存三样：标签页（标题+代码+分析）、当前标签、当前分析设置。
 * 用 try/catch 包住：隐私模式或配额满时降级为"不持久化"，绝不因此崩页面。
 */
const STORE_KEY = 'ccl.studio.v1';
let _saveTimer = null;

function save() {
  if (_saveTimer) return;
  _saveTimer = setTimeout(() => {
    _saveTimer = null;
    try {
      const payload = {
        v: 3,     // v3 起：tab.switchStates（开关覆盖按标签页）+ ui 布局
        active: S.activeTab,
        activeIndex: S.tabs.findIndex(t => t.id === S.activeTab),
        analysis: S.analysis,
        // require：这段代码是为哪个需求生成的（AI 生成时记下）。
        // 存进 localStorage，重开页面还能继续核对「改了值以后还满不满足原需求」。
        tabs: S.tabs.map(t => ({ title: t.title, code: editor && t.id === S.activeTab ? editor.getValue() : t.code,
                                 analysis: t.analysis, require: t.require || null,
                                 /* v3：开关覆盖按标签页存。刷新后若还在，提示条会明说，
                                  * 用户点一下「恢复按代码运行」就清掉。 */
                                 switchStates: (t.switchStates && Object.keys(t.switchStates).length)
                                   ? t.switchStates : undefined })),
        // v2 新增：桌面布局状态。刷新后不该回到出厂布局（VS Code 会记住这些）。
        ui: readUi(),
      };
      localStorage.setItem(STORE_KEY, JSON.stringify(payload));
    } catch (_) { /* 配额满/隐私模式：降级，不影响使用 */ }
  }, 400);
}

function restore() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return false;
    const d = JSON.parse(raw);
    if (!d || !Array.isArray(d.tabs) || !d.tabs.length) return false;
    // 必须以**当前**的 S.analysis 默认值为底，不能用写死的小对象覆盖 ——
    // 否则后来新增的字段（如直流扫描的 source/dc_start）会被丢掉。
    S.analysis = Object.assign({}, S.analysis, d.analysis || {});
    for (const t of d.tabs.slice(0, 12)) {
      openTab({ title: t.title || 'untitled.py', code: t.code || '', analysis: t.analysis,
                require: t.require || null, switchStates: t.switchStates, silent: true });
    }
    const i = Number.isInteger(d.activeIndex) ? d.activeIndex : 0;
    const act = S.tabs[Math.max(0, Math.min(S.tabs.length - 1, i))];
    if (act) selectTab(act.id);
    renderTabs();
    renderToolbarParams();
    renderKindParams();
    setAnalysisKind(S.analysis.kind);
    // v1 数据没有 ui 字段 → applyUi 直接返回，老存档照常恢复
    applyUi(d.ui);
    return true;
  } catch (_) { return false; }
}

/* ================= 启动 ================= */
init();

async function init() {
  // 启动画面：每一步都是真实初始化，await 到真的做完才标记 ✓
  // boot 没走完之前编辑器可能还没建好，此时点「运行」会拿到 null 编辑器
  // （desk-panel 观察到 Cannot read properties of null）—— 先禁掉，finish 后再放开
  const btnRun = $('#btnRun');
  if (btnRun) btnRun.disabled = true;
  await boot.mount();

  await boot.step('editor', () => {
    editor = createEditor($('#editor-host'), {
      value: '',
      onChange: (v) => {
        const t = cur();
        if (!t) return;
        /* ⚑ 代码一改，这个标签页的开关覆盖就**作废**：
         * 覆盖是「对这份代码做的实验」，代码变了以后那个断开的 SW1 可能已经不存在、
         * 或者换了接法 —— 继续带着旧覆盖跑，界面会显示一个用户根本没要求的电路。
         * （只有真的内容变了才清：editor.setValue 不触发 onChange，切标签页不会误清。） */
        if (t.code !== v && t.switchStates && Object.keys(t.switchStates).length) {
          t.switchStates = {};
          t.switchDerived = null;
          t.switchSide = [];
          refreshSwitchBar();
          setStatus('代码已修改：界面上的开关覆盖已清空（按新代码运行）');
        }
        t.code = v;
        markDirty(true);
        save();
      },
      onRun: () => run(),
      onCursor: (line, col) => {
        const el = document.getElementById('stCursor');
        if (el) el.textContent = `行 ${line}, 列 ${col}`;
        // 面包屑第三段跟着光标走（内部有缓存，行号没变就直接返回）
        updateBreadcrumbs(line);
      },
    });
  });

  await boot.step('panels', () => {
    panels = createPanels({ panelBody: $('#panel-body'), panelTabs: $('#panel-tabs') });
  });

  await boot.step('chrome', () => {
    wireChrome();
    wireToolbar();
    addSidebarResizer();
    wireCommands();
    wireGotoLine();
    wireSchematicZoom();
    wireMenubar();        // 桌面版：文件/编辑/视图/… 菜单栏
    wireKeys();           // 桌面版：VS Code 键位（Ctrl+B / Ctrl+J / Ctrl+G / Ctrl+P …）
    wireContextMenu();    // 桌面版：编辑器右键菜单
  });

  await boot.step('backend', () => loadData());

  await boot.step('plugins', () => initPlugins());

  await boot.step('workspace', async () => {
    await restoreLocalDirectory();
    if (!restore()) {
      if (S.examples.length) openTab(S.examples[0]);
      else openTab({ title: 'untitled.py', code: DEFAULT_CODE, analysis: { kind: 'ac' } });
    }
    setSidebar('files');
    updateOrientation();
    window.addEventListener('resize', () => { updateOrientation(); editor && editor.layout(); });
  });

  await boot.finish();
  // 启动完成，放开「运行」；run() 里另有 editor null 保险（Ctrl+Enter 不走按钮）
  if (btnRun) btnRun.disabled = false;
}

function cur() { return S.tabs.find(t => t.id === S.activeTab) || null; }

/* ---------------- 开关覆盖状态：按标签页 ----------------
 * 存在 S.tabs[i].switchStates（位号大写 → true 闭合 / false 断开）。
 * 这套读写口是唯一的入口：别处一律不要直接摸 S.tabs[i].switchStates 的细节，
 * 否则很容易又漏掉「换了标签页要刷新提示条」这一步。
 */
function tabSwitches(create) {
  const t = cur();
  if (!t) return {};
  if (!t.switchStates && create) t.switchStates = {};
  return t.switchStates || {};
}

/** 清空当前标签页的开关覆盖（代码变了 / 用户点「恢复按代码运行」/ 覆盖已失效）。 */
function clearTabSwitches() {
  const t = cur();
  if (!t) return false;
  const had = !!(t.switchStates && Object.keys(t.switchStates).length);
  t.switchStates = {};
  t.switchDerived = null;
  t.switchSide = [];        // 连带影响也一起作废：覆盖都没了，没有什么会跟着动
  return had;
}

/** 提示条要显示什么：把「用户点过的覆盖」和「随之改变 / 无法确认的开关」分开写。
 *
 *  ⚑ 为什么提示条必须**持久可见**：开关覆盖是**界面上的状态**，它不在代码里、也不在
 *  图上。没有这条提示，用户只看到一张不流动的图，根本想不到「是我刚才点了开关」；
 *  更糟的是改了代码之后旧覆盖还挂着（所以代码一变就清空）。
 *  提示条只描述**已经发生的仿真事实**，不预测、不补数：
 *    · 用户覆盖的：来自本标签页的覆盖表（就是发出去的 switch_states）
 *    · 随之改变的：来自 deriveSwitchStates 算出来的实际状态（点 SW1 → SW2 也断开）
 *    · 无法确认的：共用控制节点但阈值/模型不同，推不出来 → 明说，不当成已断/已合
 */
function switchBarInfo() {
  const t = cur();
  if (!t) return null;
  const intent = t.switchStates || {};
  const refs = Object.keys(intent).sort();
  if (!refs.length) return null;

  const onOff = (b) => (b ? '闭合' : '断开');
  const owner = refs.map(ref => ref + ' ' + onOff(!!intent[ref])).join(' · ');
  /* 连带改变 / 无法确认的都来自**上一次运行**的事实（applyResult 里算好存下来），
   * 这里只做呈现 —— 不重新推、不补数。 */
  const extra = Array.isArray(t.switchSide) ? t.switchSide.slice() : [];

  return {
    owner,
    extra,
    /* 「恢复按代码运行」：清掉本标签页的覆盖并**重新仿真** —— 不重跑的话图上还是
     * 刚才那个被覆盖过的结果，用户会以为按钮没生效。 */
    onRestore: () => {
      if (!clearTabSwitches()) return;
      setStatus('已清空界面上的开关覆盖，按代码重新仿真…');
      refreshSwitchBar();
      run();
    },
  };
}

/** 把提示条推给面板（面板负责画；这里只决定它该说什么、显不显示）。 */
function refreshSwitchBar() {
  if (!panels) return;
  try { panels.setSwitchBar(switchBarInfo()); } catch (e) { console.warn('[switch] 提示条刷新失败', e); }
}

/* ================= 数据 ================= */
async function loadData() {
  // 后端没起也不该白屏（降级为可用但无示例），但**必须如实把失败抛出去**，
  // 否则启动画面会给一个假的 ✓。
  let h = {};
  try {
    h = await fetch('/api/health').then(r => r.json());
  } catch (e) {
    throw new Error('后端未响应：' + (e.message || 'HTTP 失败'));
  }
  const [ex, bl] = await Promise.all([
    fetch('/api/ccl/example').then(r => r.json()).catch(() => ({ examples: [] })),
    fetch('/api/ccl/blocks').then(r => r.json()).catch(() => ({ blocks: [] })),
  ]);
  S.examples = ex.examples || [];
  S.blocks = bl.blocks || [];
  $('#stEngine').textContent = 'ngspice ' + (h.ngspice || '?');
  if (!S.examples.length) throw new Error('示例为空');
}

/* ================= 顶栏与快捷键 ================= */
function wireChrome() {
  $('#btnRun').onclick = () => run();
  $('#btnCollapse').onclick = () => { document.body.classList.toggle('sb-collapsed'); editor && editor.layout(); };
  // 命令面板里切换侧栏后也要重排

  $('#btnPanelToggle').onclick = () => {
    document.body.classList.toggle('panel-collapsed');
    editor && editor.layout();
  };
  // VS Code 行为：点**别的**图标 → 展开侧栏并切换内容；
  // 点**当前已激活**的图标 → 收起 / 再展开（toggle）。
  // 之前的 bug：只换了内容不展开，于是竖屏下自动收起后点图标完全没反应。
  $('#activity').addEventListener('click', (e) => {
    const b = e.target.closest('.act');
    if (!b) return;
    const name = b.dataset.act;
    const collapsed = document.body.classList.contains('sb-collapsed');
    if (name === S.act && !collapsed) {
      document.body.classList.add('sb-collapsed');       // 收起
    } else {
      document.body.classList.remove('sb-collapsed');    // 展开
      setSidebar(name);
    }
    editor && editor.layout();
  });
  // 分隔条拖动（鼠标 + 触屏）
  dragSplitter($('#splitter-h'), (dy, startH) => {
    const h = Math.max(60, Math.min(startH - dy, window.innerHeight - 160));
    document.documentElement.style.setProperty('--panel-h', h + 'px');
    editor && editor.layout();
    save();          // 面板高度属于布局状态，必须落盘（save 内部已 400ms 节流）
  });
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); run(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); markDirty(false); }
  });
}

/* ---- 编辑区顶部工具条 ---- */
function wireToolbar() {
  const seg = $('#segKind');
  if (seg) {
    seg.onclick = (e) => {
      const b = e.target.closest('[data-k]');
      if (b) setAnalysisKind(b.dataset.k);
    };
  }
  renderToolbarParams();
}

/* ---- 侧栏宽度拖拽（样式由 style.css 提供 #sidebar-resizer） ---- */
function addSidebarResizer() {
  const sb = $('#sidebar');
  if (!sb || $('#sidebar-resizer')) return;
  const r = document.createElement('div');
  r.id = 'sidebar-resizer';
  r.title = '拖动调整宽度';
  sb.appendChild(r);
  dragSplitter(r, (dx, startW) => {
    if (document.body.classList.contains('sb-collapsed')) return;
    // 下限不能是 0：侧栏 0 宽时热区会被 overflow:hidden 一起裁掉，
    // 鼠标再也拖不回来（只能靠活动栏/命令面板恢复）。120px 是能容纳条目的最小宽度。
    const w = Math.max(120, Math.min(startW + dx, Math.min(420, window.innerWidth * 0.5)));
    document.documentElement.style.setProperty('--sidebar-w', w + 'px');
    editor && editor.layout();
    save();          // 侧栏宽度同样属于要记住的布局状态
  });
}

/* ---- 命令面板（Ctrl/Cmd+Shift+P）与快速打开（Ctrl/Cmd+P） ----
 * 与 VS Code 一致：Ctrl+Shift+P 是**命令**面板，Ctrl+P 是**文件**快速打开。
 * 之前两个键都开命令面板，桌面用户按 Ctrl+P 想切文件会一脸懵。 */
function wireCommands() {
  document.addEventListener('keydown', (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (!mod) { if (e.key === 'Escape') closePalette(); return; }
    const k = e.key.toLowerCase();
    if (e.shiftKey && k === 'p') { e.preventDefault(); showPalette(); return; }
    if (!e.shiftKey && k === 'p') { e.preventDefault(); quickOpen(); return; }
    if (e.key === 'Escape') closePalette();
  });
}

function showPalette() {
  openCommandPalette([
    { id: 'run', label: '运行电路', hint: 'Ctrl+Enter', run: () => run() },
    { id: 'report', label: '导出 Markdown 报告', hint: '', run: () => exportReport() },
    { id: 'ai-gen', label: 'AI：用一句话生成电路', hint: '', run: () => { setSidebar('ai'); } },
    { id: 'ai-fix', label: 'AI：修复当前电路', hint: '', run: () => aiCall('fix') },
    { id: 'ai-exp', label: 'AI：解释当前电路', hint: '', run: () => aiCall('explain') },
    { id: 'sb', label: '切换侧边栏显示', hint: '', run: () => { document.body.classList.toggle('sb-collapsed'); editor && editor.layout(); } },
    { id: 'panel', label: '切换结果面板显示', hint: '', run: () => { document.body.classList.toggle('panel-collapsed'); editor && editor.layout(); } },
    { id: 'kind-ac', label: '分析：交流扫频', hint: '', run: () => { S.analysis.kind = 'ac'; syncStatus(); setSidebar('settings'); } },
    { id: 'kind-op', label: '分析：直流工作点', hint: '', run: () => { S.analysis.kind = 'op'; syncStatus(); setSidebar('settings'); } },
    { id: 'kind-tran', label: '分析：瞬态', hint: '', run: () => { S.analysis.kind = 'tran'; syncStatus(); setSidebar('settings'); } },
    { id: 'kind-dc', label: '分析：直流扫描', hint: '传输特性 / 输出特性曲线族', run: () => { S.analysis.kind = 'dc'; syncStatus(); setSidebar('settings'); } },
    { id: 'bigschem', label: '电路图：全屏查看', hint: 'Esc 关闭', run: () => toggleBigSchem() },
    { id: 'blocks', label: '查看：代码速查（子电路 + 器件）', hint: '', run: () => setSidebar('blocks') },
    { id: 'files', label: '查看：示例代码', hint: '', run: () => setSidebar('files') },
    { id: 'bench', label: '系统：运行拦截基准', hint: 'AI 出错时抓不抓得住', run: () => setSidebar('bench') },
    { id: 'problems', label: '查看：问题列表', hint: '', run: () => { panels.setActive('problems'); setSidebar('problems'); } },
    // 插入子电路块 / 器件：不用先开侧栏再滚找，命令面板直接搜名字
    ...Object.keys(BLOCK_SNIPPETS).map(n => ({
      id: 'ins-blk-' + n, label: '插入子电路：' + n, hint: 'block', run: () => insertSnippet(BLOCK_SNIPPETS[n]),
    })),
    ...getCommands().map(c => ({ id: c.id, label: c.label, hint: c.hint || '插件', run: c.run })),
    { id: 'plugins-panel', label: '插件：查看已加载的扩展', hint: '', run: () => setSidebar('plugins') },
    ...Object.keys(DEVICE_SNIPPETS).map(k => ({
      id: 'ins-dev-' + k, label: '插入器件：' + k, hint: 'device', run: () => insertSnippet(DEVICE_SNIPPETS[k]),
    })),
  ]);
}

/* ---- 面板/编辑器之间的“跳转到行”约定（panels.js 派发自定义事件） ---- */
function wireSchematicZoom() {
  // 面板内的电路图点一下就全屏（只读，不改任何东西）。
  // 只认**电路图面板**：波形主图/相位图也有 viewBox，以前用 viewBox 判会误伤 ——
  // 点一下波形就弹出电路图全屏（desk-panel 实测踩到）。
  $('#panel-body').addEventListener('click', (e) => {
    // 点在开关上 = 切换开关，不是"打开全屏"。这个判断必须放在最前面：
    // 开关本身就在 <svg> 里，否则点一下会同时切开关和弹全屏，关都关不掉。
    if (e.target.closest && e.target.closest('g[data-switch]')) return;
    // 播放条上的任何东西（按钮 / 滑条 / 下拉）都不要触发全屏
    if (e.target.closest && e.target.closest('[data-anim]')) return;
    const svg = e.target.closest('svg');
    if (!svg) return;
    const activePanel = document.querySelector('#panel-tabs .ptab.on');
    if (!activePanel || activePanel.dataset.panel !== 'schematic') return;
    if (!S.lastSchematic) return;
    toggleBigSchem();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') toggleBigSchem(false);
  });
}

function wireGotoLine() {
  document.addEventListener('ccl:goto-line', (e) => {
    if (!editor) return;
    const d = (e && e.detail) || {};
    if (d.line) { editor.goToLine(d.line); return; }
    // lint 的 Issue 没有行号，只有位号（如 "R1"）。
    // 在前几行里找含该位号的行，跳过去 —— 否则点了问题列表毫无反应。
    if (d.ref) {
      const line = lineOfRef(editor.getValue(), d.ref);
      if (line) editor.goToLine(line);
    }
  });
}

/** 位号 → 源码行号。
 *  位号大多是**自动分配**的（用户写的是 c.R(...)，源码里没有 "R1" 字样），
 *  所以先按文本找（覆盖显式 ref=），找不到就按「第 N 个 c.<类型>( 调用」定位，
 *  这与 Circuit.add() 的按类型计数分配规则一致。 */
function lineOfRef(code, ref) {
  const literal = lineOfToken(code, ref);
  if (literal) return literal;

  // "U1.R1" 这种内联位号取最后一段
  const tail = String(ref || '').split('.').pop();
  const m = /^([A-Za-z]+)(\d+)$/.exec(tail);
  if (!m) return 0;
  const kind = m[1].toUpperCase();
  const nth = parseInt(m[2], 10);
  if (!nth) return 0;

  const re = new RegExp('\\.\\s*' + kind + '\\s*\\(');
  const lines = String(code).split('\n');
  let seen = 0;
  for (let i = 0; i < lines.length; i++) {
    if (re.test(lines[i])) {
      seen++;
      if (seen === nth) return i + 1;
    }
  }
  return 0;
}

/** 在源码里找含某个 token（位号/节点名）的第一行，返回 1-based 行号。 */
function lineOfToken(code, token) {
  if (!token) return 0;
  const lines = String(code).split('\n');
  const re = new RegExp('(^|[^A-Za-z0-9_])' + token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^A-Za-z0-9_]|$)');
  for (let i = 0; i < lines.length; i++) {
    if (re.test(lines[i])) return i + 1;
  }
  return 0;
}

/* ---- 插入片段（点侧栏的块/器件时用） ---- */
function insertSnippet(snippet) {
  if (!editor) return;
  const t = cur();
  let src = editor.getValue();

  // 1) 先补齐缺的 import（mergeSnippet 负责判断并插到 import 区末尾）
  const { code, addedImports } = mergeSnippet(src, 1, snippet);
  if (addedImports.length) {
    src = code;
    editor.setValue(src);
  }

  // 2) 插入调用的位置：
  //    优先用编辑器的 insertText（会插到光标处，行为最好）；
  //    没有就退回到「插在最后一行 return 之前」，而不是傻傻追加到文件末尾
  //    —— 追加到 return 之后会让整段代码失效（踩过）。
  if (editor.insertText) {
    editor.insertText(snippet + '\n');
  } else {
    const lines = src.split('\n');
    let idx = lines.length;
    for (let i = lines.length - 1; i >= 0; i--) {
      if (/^\s*return\b/.test(lines[i])) { idx = i; break; }
    }
    lines.splice(idx, 0, snippet);
    editor.setValue(lines.join('\n'));
    const pos = lines.slice(0, idx + 1).join('\n').length;
    const ta = document.querySelector('#editor-host textarea');
    if (ta) { ta.focus(); ta.setSelectionRange(pos, pos); }
  }

  if (t) t.code = editor.getValue();
  markDirty(true);
  $('#stStatus').textContent = addedImports.length
    ? `已插入（并补 ${addedImports.join(', ')}）` : '已插入代码片段';
}

function dragSplitter(el, onMove) {
  if (!el) return;
  const start = (ev) => {
    if (ev.button !== undefined && ev.button !== 0 && ev.type === 'mousedown') return;
    const p = point(ev);
    const startH = $('#panel').getBoundingClientRect().height;
    const move = (e2) => { const q = point(e2); onMove(q.y - p.y, startH); };
    const up = () => {
      window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up);
      window.removeEventListener('touchmove', move); window.removeEventListener('touchend', up);
    };
    window.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
    window.addEventListener('touchmove', move, { passive: false }); window.addEventListener('touchend', up);
    ev.preventDefault();
  };
  el.addEventListener('mousedown', start);
  el.addEventListener('touchstart', start, { passive: false });
}
function point(ev) {
  const t = ev.touches ? ev.touches[0] : ev;
  return { x: t.clientX, y: t.clientY };
}

/* ================= 标签 ================= */
function openTab(item) {
  const id = 't' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 6);
  S.tabs.push({ id, title: item.title, code: item.code || '', analysis: item.analysis || null,
                fileHandle: item.fileHandle || null, require: item.require || null,
                /* 开关覆盖是**这个标签页**的实验状态，跟着标签页走（见 tabSwitches）。 */
                switchStates: item.switchStates && typeof item.switchStates === 'object'
                  ? Object.assign({}, item.switchStates) : {} });
  S.activeTab = id;
  if (item.analysis) S.analysis = Object.assign({}, S.analysis, item.analysis);
  editor.setValue(item.code || '');
  markDirty(false);
  renderTabs();
  syncStatus();
  dropForeignSchematic();   // 新标签页 = 新上下文，上一张图不再对应当前代码
  refreshSwitchBar();
  save();
}

function selectTab(id) {
  const t = S.tabs.find(x => x.id === id);
  if (!t) return;
  S.activeTab = id;
  editor.setValue(t.code);
  if (t.analysis) S.analysis = Object.assign({}, S.analysis, t.analysis);
  /* 换标签页 → 开关覆盖换成本页自己的那份（互不影响：这正是原来全局一份的
   * 那个 bug 的修法）；面板上如果还挂着**别的标签页**的图，就撤掉 ——
   * 那张图与当前代码无关，留着只会误导（图是代码的投影，不是第二份真相）。 */
  dropForeignSchematic();
  refreshSwitchBar();
  renderTabs();
  save();
}

/** 面板上的图如果不是当前标签页跑出来的，就撤掉（幂等）。
 *  只在「真的换了标签页」时触发；同一个标签页内改代码不动图（改完再运行即可）。 */
function dropForeignSchematic() {
  const t = cur();
  if (!S.schemFor || !t || S.schemFor.tabId === t.id) return;
  S.schemFor = null;
  S.lastSchematic = '';
  if (panels) {
    try { panels.showSchematic(''); } catch (_) { /* 面板还没建好就算了 */ }
  }
}

function closeTab(id) {
  const i = S.tabs.findIndex(t => t.id === id);
  if (i < 0) return;
  S.tabs.splice(i, 1);
  if (S.activeTab === id) {
    const next = S.tabs[i] || S.tabs[i - 1];
    if (next) selectTab(next.id);
    else openTab({ title: 'untitled.py', code: DEFAULT_CODE });
  }
  renderTabs();
}

function closeOtherTabs() {
  if (!S.activeTab) return;
  S.tabs = S.tabs.filter(t => t.id === S.activeTab);
  renderTabs();
  save();
}

function closeAllTabs() {
  S.tabs = [];
  S.activeTab = null;
  editor.setValue('');
  openTab({ title: 'untitled.py', code: DEFAULT_CODE, analysis: { kind: S.analysis.kind } });
}

function downloadCode() {
  const t = cur();
  if (!t || !editor) return;
  t.code = editor.getValue();
  const name = (t.title || 'untitled.py').replace(/[^A-Za-z0-9_.-]+/g, '_');
  const blob = new Blob([t.code], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name.toLowerCase().endsWith('.py') ? name : name + '.py';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setStatus('已下载当前代码');
}

function renderTabs() {
  const el = $('#tabs');
  el.innerHTML = '';
  S.tabs.forEach(t => {
    const b = document.createElement('button');
    b.className = 'tab' + (t.id === S.activeTab ? ' on' : '');
    b.innerHTML = `<span>${esc(t.title)}</span><span class="tab-x" title="关闭">×</span>`;
    b.onclick = (e) => { e.target.classList.contains('tab-x') ? closeTab(t.id) : selectTab(t.id); };
    el.appendChild(b);
  });
  // 标签变了，面包屑第一段（文件名）也要跟着变
  updateBreadcrumbs();
}

/** 本标签页的开关覆盖 → 请求里的 switch_states（没有覆盖就返回 undefined，不发这个字段）。
 *  与 run() 用的是同一份逻辑：界面显示什么，导出的报告就必须按什么跑。 */
function switchStatesForRequest(tab) {
  const st = (tab && tab.switchStates) || {};
  const out = {};
  for (const [ref, on] of Object.entries(st)) out[ref] = on ? 'on' : 'off';
  return Object.keys(out).length ? out : undefined;
}

/* ================= 运行 ================= */
/* 点开关 → 立刻重跑仿真（不是前端假切换）。
 * 传 S.busy 判断而不是直接排队：仿真中再点会叠请求，后端会用后到的覆盖先到的。 */
function toggleSwitch(ref, closed) {
  if (!ref) return;
  // 覆盖状态写进**当前标签页**（不是全局）：换了标签页就互不影响。
  tabSwitches(true)[String(ref).toUpperCase()] = !!closed;
  // 提示条要立刻出现：用户点开关的那一刻就该看到「已被界面覆盖」与恢复入口，
  // 而不是等这次仿真跑完（仿真可能还要几秒，甚至失败）。
  refreshSwitchBar();
  if (S.busy) {
    /* ⚑ 仿真进行中点开关：意图先记下，**必须补跑**。
     * 早先这里只写意图就 return，从不补跑；接着在飞的那个请求回来、
     * 用「用户意图」兜底把刀闸画成闭合 —— 于是图上开关是合的、灯是灭的、
     * 图例说 0/5 有电流，用户以为电路坏了。实际是数据来自点开关之前。 */
    S.rerunPending = true;
    setStatus(`${ref} 已切到${closed ? '闭合' : '断开'}，等这次仿真结束会立刻重算`);
    return;
  }
  setStatus(`${ref} → ${closed ? '闭合' : '断开'}，重新仿真…`);
  run();
}

async function run(extra) {
  if (S.busy) return;
  if (!editor) return;   // boot 未完成 / 编辑器未建好时 Ctrl+Enter 进来会炸 getValue
  const t = cur();
  if (!t) return;
  S.busy = true; setStatus('仿真中…');
  $('#stStatus').textContent = '仿真中…';
  try {
    // switch_states：只有用户真的点过开关才带。
    // 没点过就不发这个字段 —— 后端按代码原样跑，行为与以前完全一致。
    const sw = {};
    for (const [ref, on] of Object.entries(tabSwitches(false))) {
      sw[ref] = on ? 'on' : 'off';
    }
    const hasSw = Object.keys(sw).length > 0;
    const r = await fetch('/api/ccl/run', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      // require 只在「这段代码是 AI 按某个需求生成的」时才有值。
      // 手写代码不带它 → 后端不做需求对账，行为与以前完全一致。
      body: JSON.stringify({ code: editor.getValue(), analysis: S.analysis,
                             require: t.require || undefined,
                             switch_states: hasSw ? sw : undefined,
                             switchStates: hasSw ? sw : undefined,
                             ...(extra || {}) }),
    });
    const d = await r.json();
    S.lastResult = d;
    /* 后端回报的 `switch_states` = 它**真的强制生效**的位号
     * （`switch_apply` 那栏才是「用什么办法」，两者别混 —— 早先把它当状态读，
     * 'source' 匹配不上 on/off 正则 → 一律判成 false → 点了开关灯不亮）。
     * 这里只对**发请求时那一个标签页**做归一化：
     *   · 生效的位号保留（on/off 归一成布尔）
     *   · 请求里带了、回报里没有的 → 丢掉，免得每次运行都发一个无效覆盖
     * ⚑ 不再写成 `S.switchStates = got`：覆盖状态属于标签页，而且「用户意图」
     * 不该被回报值整个替换（那样会把别的标签页的状态一起清掉）。 */
    if (d && d.switch_states && typeof d.switch_states === 'object') {
      const got = {};
      for (const [k, v] of Object.entries(d.switch_states)) {
        got[String(k).toUpperCase()] = /^(on|1|true|closed)$/i.test(String(v));
      }
      if (!t.switchStates) t.switchStates = {};
      for (const key of Object.keys(t.switchStates)) if (!(key in got)) delete t.switchStates[key];
      Object.assign(t.switchStates, got);
    }
    applyResult(d, t);
  } catch (e) {
    panels.showProblems([{ level: 'error', title: '请求失败', detail: e.message }]);
    panels.setActive('problems');
    $('#stStatus').textContent = '请求失败';
  } finally {
    S.busy = false;
    // 排队中的重跑（仿真期间点过开关 / 开关覆盖被判失效）在这里补上
    if (S.rerunPending) {
      S.rerunPending = false;
      setTimeout(() => { run(); }, 0);
    }
  }
}

/** 开关覆盖状态的自愈。
 *
 * 场景（实测会永久卡死）：点过开关 → 用户把 `c.SW(...)` 从代码里删掉或改名 →
 * 之后**每一次**运行都因「'SW1' 不是本电路里的开关」失败，
 * 而后端那条错误返回里没有 switch_states 字段，前端也就没机会清掉本地状态，
 * 只能刷页面才能恢复。
 *
 * 做法：识别出这类错误后，丢掉本地开关覆盖再跑一次（代码原样，什么都没改），
 * 并明确告诉用户「刚才是界面上的开关覆盖残留，已恢复成按代码跑」。
 */
function healSwitchState(d, tab) {
  if (!d || d.ok) return false;
  const text = String(d.error || '') + ' ' + String(d.detail || '');
  /* ⚑ 只认「界面上残留的开关覆盖，代码里已经没有这个开关」这一种。
   * 早先按 `stage === 'switch_states'` 一刀切，于是另一种完全不同的错误
   * （控制节点没有独立电压源 → 后端明确说「请给控制端接一个独立源」）
   * 也被当成残留，弹出一句**假话**：「代码里没有这个开关了，已恢复成按代码运行」
   * —— 代码里明明有，而且根本没重跑。用户永远学不到真正的修法。 */
  const isStaleOverride = /代码里已经没有这个开关|不是本电路里的开关|已忽略/.test(text);
  if (!isStaleOverride) return false;
  const t = tab || cur();
  if (!t || !t.switchStates || !Object.keys(t.switchStates).length) return false;
  t.switchStates = {};
  t.switchDerived = null;
  t.switchSide = [];
  refreshSwitchBar();
  setStatus('界面上的开关覆盖已失效（代码里没有这个开关了），正在按代码重跑…');
  /* ⚑ 不能在这里直接 run()：这一刻 S.busy 还是 true（它由 run() 的 finally 清），
   * run() 首行 `if (S.busy) return;` 会把重跑直接吞掉 —— 实测「重跑从未发生」，
   * 用户看到的是上一次的波形，却被告知「已恢复成按代码运行」。
   * 用一个已排队的标记，让 run() 在 finally 里补跑。 */
  S.rerunPending = true;
  return true;
}

/** 工作态图例：把「这些颜色代表什么」直接写在图上，避免用户猜。 */
function liveLegend(live, timeline) {
  /* ⚑ 有瞬态时间序列时，导通数必须按**整段波形的峰值**算，不能按某一时刻。
   * 实测：PULSE 电路里 led 峰值 1.97mA、r1 峰值 3.83mA，但 t=0 和末点
   * 都恰好落在低电平 → 「瞬时」永远是 0，图例写着「0/11 个器件导通」，
   * 与同一屏里正在播放的动画互相打脸。换端点解决不了（脉冲串两端都是 0）。
   */
  const series = timeline && timeline.series ? timeline.series : null;
  if (series) {
    const refs = Object.entries(series);
    if (!refs.length) return '';
    let on = 0;
    for (const [, v] of refs) {
      const cur = v && v.current;
      if (!Array.isArray(cur)) continue;
      let peak = 0;
      for (const x of cur) { const a = Math.abs(x || 0); if (a > peak) peak = a; }
      if (peak > 1e-6) on++;
    }
    return '<span class="lg-dim">工作态（真仿真数据）</span>'
      + '<span class="lg-dot" style="color:#ff5533">●</span><span>发光/LED</span>'
      + '<span class="lg-dot" style="color:#ff8c42">●</span><span>发热/电阻</span>'
      + '<span class="lg-dot" style="color:#4fc1ff">●</span><span>有电流</span>'
      + `<span class="lg-dim">${on}/${refs.length} 个器件有过电流（瞬态峰值）</span>`;
  }
  if (!live || !live.items) return '';
  const items = Object.entries(live.items);
  if (!items.length) return '';
  /* ⚑ 按**电流幅值**计数：电流是有符号量，反向电流同样代表"这里在导通/在动"。
   *  早先写的是 `(v.current || 0) > 1e-6`，只认正方向 —— 与 currentToLevel 那个
   *  「负半周整段不亮」是同一个 bug 的两种表现（图例说 0/3 导通，图上却亮着）。 */
  const on = items.filter(([, v]) => {
    const a = Math.abs(v && typeof v.current === 'number' ? v.current : 0);
    return a > 1e-6;
  }).length;
  return '<span class="lg-dim">工作态（真仿真数据）</span>'
    + '<span class="lg-dot" style="color:#ff5533">●</span><span>发光/LED</span>'
    + '<span class="lg-dot" style="color:#ff8c42">●</span><span>发热/电阻</span>'
    + '<span class="lg-dot" style="color:#4fc1ff">●</span><span>有电流</span>'
    + `<span class="lg-dim">${on}/${items.length} 个器件导通（当前工作点）</span>`;
}

/** 组装给面板的动画参数。
 *  **没有 timeline 就返回 null** —— 面板据此完全不建播放条、不动 SVG（不演假动画）。
 *  只认 tran：ac/op/dc 就算后端误塞了 timeline 也不播（那是频域数据，演时域会骗人）。 */
function animSpec(d, kinds, switches) {
  // 开关信息**总是**带出去：点开关跟有没有动画无关（op/dc 也要能点）。
  // timeline 为 null 时面板只绑开关、不建播放条。
  // switches 是 applyResult 算出来的**实际状态**（含共用控制节点被连带切换的那些、
  // 以及大小写两份位号），播放器据此画初始刀闸位置，与图上 data-sw 完全一致。
  const spec = {
    timeline: null,
    kinds,
    switches: switches instanceof Map ? switches : new Map(),
    onSwitch: (ref, closed) => toggleSwitch(ref, closed),
  };
  if (!d || !d.timeline) return spec;
  const kind = d.analysis && d.analysis.kind ? String(d.analysis.kind) : '';
  if (kind && kind !== 'tran') {
    console.warn('[anim] 非瞬态分析却带了 timeline，已忽略（' + kind + '）');
    return spec;
  }
  const tl = d.timeline;
  if (!Array.isArray(tl.t) || tl.t.length < 2) return spec;
  if (!tl.series || typeof tl.series !== 'object') return spec;
  spec.timeline = tl;
  return spec;
}

function applyResult(d, tab) {
  /* tab = 这次请求所属的标签页（run() 传进来）。中途切标签页也不会把结果算到别人头上。 */
  const t = tab || cur();
  if (!d.ok) {
    // 代码没跑通 → 这张图不再代表任何东西：提示条里的「连带影响」也一并作废
    if (t) { t.switchDerived = null; t.switchSide = []; }
    S.schemFor = null;
    refreshSwitchBar();                  // 连带影响作废 → 提示条只剩「用户点了什么」
    if (healSwitchState(d, t)) return;   // 开关残留导致失败 → 清掉重跑，别把用户钉死在错误上
    // 代码没跑通 = 没有电路，必须清掉上一次的图。
    // 否则用户会看着一张跟当前代码无关的图，比不显示更误导。
    S.lastSchematic = '';
    panels.showSchematic('');
    /* ⚑ P1：失败时必须把**所有**结果面板清干净。原来只清了电路图，于是同一屏会出现
     * 「器件数 —」配着上一次电路的 3 条波形曲线、指标表、工作点、网表，
     * 以及状态栏右边那句「规格 3/3 ✓ 38 ms」—— 全部与当前代码无关。 */
    try {
      panels.showWaveform({ traces: {}, op: null }, { kind: S.analysis.kind, sweepVar: '', secondVar: '' });
      panels.showMetrics({});
      panels.showOperatingPoint({});
      panels.showNetlist('');
    } catch (_) { /* 面板还没建好时无视 */ }
    const stExp = $('#stExpect'); if (stExp) stExp.textContent = '';
    const stTime = $('#stTime'); if (stTime) stTime.textContent = '';
    const soEl = $('#codeStdout'); if (soEl) { soEl.textContent = ''; soEl.hidden = true; }
    const issues = [{ level: 'error', title: d.error || '未知错误',
      detail: d.stage ? `阶段：${d.stage}` : '', line: d.line }];
    // 完整 traceback 也要能看到（后端一直有发 error_detail，前端从没读过）
    if (d.error_detail) issues.push({ level: 'error', title: '完整错误信息', detail: String(d.error_detail) });
    panels.showProblems(issues);
    panels.setActive('problems');
    if (d.line) {
      editor.setDiagnostics([{ line: d.line, level: 'error', message: d.error }]);
      // 报错但视口还停在文件开头 → 用户看不到错在哪。直接滚过去。
      editor.goToLine(d.line);
    }
    $('#stStatus').textContent = '有错误';
    syncStatus(d);
    return;
  }
  editor.setDiagnostics([]);

  // 电路图：由代码自动生成的只读视图（图是代码的投影，不是第二份真相）
  try {
    const comps = d.circuit.components || [];
    const intent = (t && t.switchStates) || {};   // 本标签页的用户覆盖（输入量）
    /* 器件类型表：动画层要用它决定「这个位号该发亮还是该发热」。
     * 后端 timeline.series 里不一定带 kind，所以在图这一侧兜底。 */
    const kinds = {};

    /* ---- 开关的**实际状态**：从这次仿真的数据推，不猜 ----
     * 两个开关共用一个控制节点时，点 SW1 物理上两个都切了，但后端只回报 SW1。
     * 这里用 deriveSwitchStates（节点电压 + 网表 Vt，或「同控制节点 + 同 model」的
     * 物理必然而不是估算）把**每个**开关的真实状态算出来，画面才和仿真结果一致。
     * 推不出来的位号在 states 里没有条目 → 才退回用户点的那一下 → 最后才是默认 off。 */
    const der = deriveSwitchStates({
      components: comps,
      netlist: d.netlist,
      op: (d.analysis || {}).op,
      reported: d.switch_states,
    });
    const swTxt = {};          // renderSchematic 用：'on' / 'off' 字符串
    const swBool = new Map();  // 播放器 / 点击处理用：位号 → true(闭合) / false(断开)
    for (const c of comps) {
      if (!c || c.ref == null) continue;
      const ref = String(c.ref).toUpperCase();
      const rawRef = String(c.ref);
      const kf = String(c.kind == null ? '' : c.kind).trim();
      const isSwitch = /^(SW|SWITCH|SPST|SPDT|S)$/i.test(kf);
      kinds[ref] = isSwitch ? 'S' : (kf.charAt(0).toUpperCase() || '?');
      if (!isSwitch) continue;
      let closed = der.states.has(ref) ? der.states.get(ref) : undefined;
      if (closed === undefined) {
        // 退路：用户点过的那一下（意图）。再没有就什么都不写 → renderSchematic 按
        // 「未指定」处理（默认 off，那是输入量的默认值，不是编出来的仿真数据）。
        const want = intent[ref] !== undefined ? intent[ref] : intent[rawRef];
        if (want !== undefined) closed = !!want;
      }
      if (closed === undefined) continue;
      // 同时写「原始位号」和「大写位号」：renderSchematic 用原始 c.ref 查表，
      // 播放器（applyLiveFrame）按大写查，点击处理按 data-ref 的原始大小写写。
      // 只写一份时，小写位号的开关（ref='sw1'）永远查不到 → 视觉被重置成 off。
      swTxt[ref] = closed ? 'on' : 'off';
      swTxt[rawRef] = closed ? 'on' : 'off';
      swBool.set(ref, closed);
      swBool.set(rawRef, closed);
    }

    /* ---- 提示条要写的「连带影响」：只写已经发生的事实 ----
     * 规则（谁受牵连）由 switchSideEffects 判定（纯函数、可自测），
     * 这里只负责措辞。 */
    const side = switchSideEffects(der, comps, intent).map(it => (it.kind === 'shared'
      ? { cls: 'derived',
          text: it.ref + ' ' + (it.state ? '闭合' : '断开')
            + '（与 ' + it.via + ' 共用控制节点 ' + it.ctrl + '，随之一同动作）' }
      : { cls: 'unknown',
          text: it.ref + ' 状态无法确认（与 ' + it.via + ' 共用控制节点 ' + it.ctrl
            + '，但这次结果里推不出它的实际状态），图上按代码呈现' }));
    if (t) { t.switchDerived = der; t.switchSide = side; }
    refreshSwitchBar();

    let svg = renderSchematic({ name: d.circuit.name, nodes: d.circuit.nodes,
                                components: comps },
                              { switchStates: swTxt });
    /* 工作态静态快照：只在**没有时间序列**时用（tran 有 timeline 就别叠了，
     * 那张静态图会跟播放到第 2 帧的状态打架，看起来像"亮着又灭了"）。
     * ac 分析没有 live（频域没有瞬时工作点），这里自然是空。 */
    if (d.live && !d.timeline) svg = applyLive(svg, d.live);
    /* 仿真是异步的：用户可能已经切到别的标签页了。那就**别画**——
     * 画上去的图不属于当前代码（与 selectTab 里 dropForeignSchematic 同一口径：
     * 图必须是当前代码的投影，宁可不显示也不显示错的）。提示条已经在上面按
     * 各自标签页的数据刷新过了，不受影响。 */
    if (t && S.activeTab !== t.id) {
      S.schemFor = null;
      S.lastSchematic = '';
    } else {
      S.lastSchematic = svg;
      S.schemFor = t ? { tabId: t.id, code: t.code } : null;
      panels.showSchematic(svg, liveLegend(d.live, d.timeline), animSpec(d, kinds, swBool));
    }
  } catch (e) {
    // 画图失败不能静默：否则用户只看到一张空图，以为是电路的问题。
    // （实测：applyLive 抛异常时这里把整张图替换成了「空状态」，很难排查。）
    console.error('[schematic] 渲染失败', e);
    S.lastSchematic = '';
    panels.showSchematic(schematicOrEmpty(null), '');
    try {
      panels.showProblems([...(d.lint || []), {
        level: 'warn', title: '电路图渲染失败（电路本身可能没问题）',
        detail: String(e && e.message || e),
      }]);
    } catch (_) {}
  }

  const a = d.analysis || {};
  const traces = a.traces || {};
  // dc 的十字线读数要显示 `V1=3.2V`，必须把扫描变量名传进去
  panels.showWaveform({ traces, op: a.op },
    { kind: a.kind, sweepVar: a.sweepVar || '', secondVar: a.secondVar || '' });
  panels.showMetrics(a.metrics || {});
  panels.showOperatingPoint(a.op || {});
  panels.showNetlist(d.netlist || '');
  // 问题列表 = 静态检查 + 自写断言 + **原需求对账**
  const issues = (d.lint || []).slice();
  const sp = d.spec;          // 只有 AI 生成的代码才有（手写代码为 null）
  if (sp && Array.isArray(sp.items)) {
    for (const it of sp.items) {
      if (it.ok) continue;
      // 标题已带标签，detail 里把重复的标签前缀去掉（否则读起来是「输出电压输出电压要求…」）
      const det = String(it.text || '').startsWith(it.label)
        ? String(it.text).slice(it.label.length) : String(it.text || '');
      issues.push({ level: 'error', title: `原需求未满足：${it.label}`, detail: det });
    }
    if (sp.checked === 0 && sp.text) {
      issues.push({ level: 'warn', title: '需求无法自动对账', detail: sp.text });
    }
  }
  /* ⚑ P0：代码里自己写的 `c.expect(...)` 没达标时，原来只在状态栏显示「规格 1/2 ✗」，
   * 问题面板一条都没有 —— 用户知道有问题，却不知道是哪一项、要求多少、实测多少，
   * 而那行字后端早就写在 expect.items / expect.text 里了。 */
  const exi = d.expect;
  if (exi && Array.isArray(exi.items)) {
    for (const it of exi.items) {
      if (it.ok !== false) continue;
      const unit = it.unit || '';
      const tgt = (it.target == null) ? '—' : `${it.target}${unit}`;
      const act = (it.actual == null || Number.isNaN(it.actual)) ? '测不到' : `${Number(it.actual).toPrecision(4)}${unit}`;
      issues.push({
        level: 'error',
        title: `规格未达标：${it.label || it.kind || '断言'}`,
        detail: `要求 ${tgt}，实测 ${act}`,
      });
    }
  }
  /* ⚑ P2-10：后端发的 warnings 前端一个字没读。最典型的是
   * 「步数过多，已把 t_step 放大到 Xs」—— 用户以为拿到的是 1ns 分辨率，
   * 实际被悄悄放宽了 500 倍。这类"我替你改了参数"必须让用户知道。 */
  for (const w of (d.warnings || [])) {
    if (w) issues.push({ level: 'warn', title: '注意', detail: String(w) });
  }
  for (const w of ((d.analysis || {}).warnings || [])) {
    if (w) issues.push({ level: 'warn', title: '分析参数被调整', detail: String(w) });
  }
  for (const w of (d.validate_warnings || [])) {
    if (w) issues.push({ level: 'warn', title: '结构提示', detail: String(w) });
  }
  panels.showProblems(issues);
  // 用户 print() 的输出（沙箱 sink）原来被吞掉；代码模式下这是最自然的自查手段
  const outEl = $('#codeStdout');
  if (outEl) {
    const so = String(d.code_stdout || '');
    outEl.textContent = so;
    outEl.hidden = !so.trim();
  }

  // 状态栏：规格 + 需求两栏
  const ex = d.expect;
  const expectTxt = ex
    ? (ex.passed ? `规格 ${ex.total}/${ex.total} ✓` : `规格 ${ex.total - ex.failed}/${ex.total} ✗`)
    : '';
  const specTxt = sp
    ? (sp.checked === 0 ? '需求 —'
       : (sp.passed ? `需求 ${sp.checked}/${sp.checked} ✓` : `需求 ${sp.checked - sp.failed}/${sp.checked} ✗`))
    : '';
  $('#stExpect').textContent = [expectTxt, specTxt].filter(Boolean).join('　');

  // 自动切到最有信息的面板
  if ((d.lint || []).some(i => i.level === 'error')) panels.setActive('problems');
  else if (a.kind === 'op' && Object.keys(a.op || {}).length) panels.setActive('op');
  else panels.setActive('schematic');   // 默认先看「我搭了个什么电路」

  $('#stStatus').textContent = ex && !ex.passed ? '规格未全通过' : '完成';
  $('#stTime').textContent = a.elapsed_ms != null ? a.elapsed_ms + ' ms' : '';
  syncStatus(d);
  if (S.blocks.length && !S._blocksRendered) { /* 首次运行后无需重复 */ }
}

function syncStatus(d) {
  const r = d || S.lastResult;
  const n = r && r.circuit ? r.circuit.component_count : null;
  $('#stDevices').textContent = n != null ? `${n} 器件` : '—';
  $('#stAnalysis').textContent = (r && r.analysis ? r.analysis.kind : S.analysis.kind).toUpperCase();
}

/* ================= 插件 ================= */
let pluginPanels = [];

async function initPlugins() {
  try {
    await loadPlugins();
  } catch (e) { console.warn('[plugins] 载入失败', e); }
  pluginPanels = getPanels();

  const nav = $('#activity');
  const spacer = nav && nav.querySelector('.act-spacer');
  for (const p of pluginPanels) {
    const b = document.createElement('button');
    b.className = 'act';
    b.dataset.act = p.key;
    b.title = `${p.title}（插件）`;
    b.textContent = p.icon;
    if (spacer) nav.insertBefore(b, spacer); else nav.appendChild(b);
  }
}

/* ================= 拦截基准（bench/ 的 IDE 入口） ================= */
function renderBench(box) {
  box.innerHTML = `
    <div style="padding:8px">
      <div class="sb-sub" style="line-height:1.6;margin-bottom:6px">
        「AI 出错时，我们抓不抓得住」。
        闸门层每次都<b>真跑</b>全部对抗用例（约 2 秒，不需要网络）；
        真实模型层展示最近一次存档（终端跑 <code>python3 bench/run_llm.py</code> 可刷新）。
      </div>
      <button class="sb-btn sb-wide" id="btnBenchRun">运行基准（闸门层）</button>
      <div id="benchOut" style="margin-top:10px"></div>
    </div>`;
  $('#btnBenchRun').onclick = runBench;
  runBench();   // 打开面板先出最近一次数字，2 秒内完成
}

async function runBench() {
  const btn = document.getElementById('btnBenchRun');
  const out = document.getElementById('benchOut');
  if (!btn || !out) return;
  btn.disabled = true;
  btn.textContent = '运行中…';
  try {
    // 必须带 Content-Type：服务端对所有 POST 做 JSON-only 校验（返回 415），
    // 早先这里只写 method:'POST'，被加固后的服务端直接拒掉（面板显示「基准失败」）。
    const r = await fetch('/api/bench/run', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || '基准失败');
    out.innerHTML = benchHtml(d);
  } catch (e) {
    out.innerHTML = `<div class="sb-sub" style="color:#f14c4c">✗ ${esc(String(e.message || e))}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = '运行基准（闸门层）';
  }
}

function benchHtml(d) {
  // 聚合口径与 bench/CONTRACT.md 一致：
  //   拦截率 = expect=reject 且 caught 的比例；误杀率 = expect=accept 且 caught 的比例。
  const cases = (d.gates && d.gates.cases) || [];
  const byCat = {};
  for (const c of cases) {
    const cat = c.category || '未分类';
    const b = byCat[cat] || (byCat[cat] = { rn: 0, rh: 0, an: 0, ah: 0 });
    if (c.expect === 'reject') { b.rn++; if (c.caught) b.rh++; }
    else { b.an++; if (c.caught) b.ah++; }
  }
  const pct = (a, b) => b ? Math.round(a / b * 100) + '%' : '—';
  let rn = 0, rh = 0, an = 0, ah = 0;
  const rows = Object.keys(byCat).sort().map(cat => {
    const b = byCat[cat];
    rn += b.rn; rh += b.rh; an += b.an; ah += b.ah;
    const flag = b.rh < b.rn ? ' <span style="color:#f14c4c">← 漏网</span>'
      : (b.ah > 0 ? ' <span style="color:#f14c4c">← 误杀</span>' : '');
    return `<tr><td style="padding:2px 6px">${esc(cat)}</td>
      <td style="padding:2px 6px;text-align:right">${b.rh}/${b.rn}</td>
      <td style="padding:2px 6px;text-align:right">${pct(b.rh, b.rn)}</td>
      <td style="padding:2px 6px;text-align:right">${b.ah}/${b.an}</td>
      <td style="padding:2px 6px;text-align:right">${pct(b.ah, b.an)}</td>
      <td style="padding:2px 6px">${flag}</td></tr>`;
  }).join('');
  const good = rh === rn && ah === 0;
  const big = (num, den, label) => `
    <div style="flex:1;padding:8px;border:1px solid var(--border);border-radius:4px;text-align:center">
      <div style="font-size:20px;color:${num === den ? '#6a9955' : '#f14c4c'}">${pct(num, den)}</div>
      <div class="sb-sub">${label} ${num}/${den}</div>
    </div>`;
  const head = `<div style="display:flex;gap:8px;margin:6px 0">
    ${big(rh, rn, '拦截率')}${big(ah, an, '误杀率')}</div>`;
  // 漏网/误杀逐条点名——这个面板存在的意义
  const bad = cases.filter(c =>
    (c.expect === 'reject' && !c.caught) || (c.expect === 'accept' && c.caught));
  const badHtml = bad.map(c =>
    `<div class="sb-item" style="white-space:normal">
      <span style="color:#f14c4c">${c.expect === 'reject' ? '✗ 漏网' : '✗ 误杀'}</span>
      ${esc(c.id || '')}
      <div class="sb-sub">${esc((c.detail || '').slice(0, 140))}</div>
    </div>`).join('');
  // —— 真实模型层（存档展示，不在这里重跑）——
  const t = d.llm && d.llm.totals;
  let llmHtml = `<div class="sb-sub" style="margin-top:8px;border-top:1px solid var(--border);padding-top:8px">
    真实模型层：还没有结果（终端跑 <code>python3 bench/run_llm.py</code>，约 3 分钟）</div>`;
  if (t) {
    const incomplete = (t.judged || 0) < (t.total || 0);
    const cell = (num, den, label, ok) => `
      <div style="flex:1;padding:6px;border:1px solid var(--border);border-radius:4px;text-align:center">
        <div style="font-size:16px;color:${ok ? '#6a9955' : '#f14c4c'}">${num}${den != null ? '/' + den : ''}</div>
        <div class="sb-sub">${label}</div>
      </div>`;
    llmHtml = `
      <div style="border-top:1px solid var(--border);margin-top:10px;padding-top:8px">
        <div class="sb-sub" style="margin-bottom:4px">真实模型端到端（最近一次存档${incomplete
          ? '，<span style="color:#d7ba7d">不完整跑，仅供参考</span>' : ''}）</div>
        <div style="display:flex;gap:8px">
          ${cell(t.b_caught || 0, t.b_n || 0, 'B 类拦截', t.b_caught === t.b_n)}
          ${cell(t.a_false_kill_n || 0, t.a_counted_n || 0, '真·误杀', !t.a_false_kill_n)}
          ${cell(t.hallucination_n || 0, null, '幻觉拦截', true)}
        </div>
        <div class="sb-sub" style="margin-top:4px">一次通过 ${Math.round((t.first_pass_rate || 0) * 100)}%｜
          硬凑 ${t.fabricated_n || 0}｜假成功 ${t.fake_success_n || 0}｜编造不自知 ${t.c_fabricated_n || 0}</div>
      </div>`;
  }
  return `${head}
    <table style="width:100%;border-collapse:collapse;font-size:11px">
      <tr style="color:var(--fg-dim)"><th style="text-align:left;padding:2px 6px">类别</th>
        <th style="padding:2px 6px">拦截</th><th style="padding:2px 6px">率</th>
        <th style="padding:2px 6px">误杀</th><th style="padding:2px 6px">率</th><th></th></tr>
      ${rows}
      <tr style="border-top:1px solid var(--border)">
        <td style="padding:2px 6px"><b>合计</b></td>
        <td style="padding:2px 6px;text-align:right">${rh}/${rn}</td>
        <td style="padding:2px 6px;text-align:right">${pct(rh, rn)}</td>
        <td style="padding:2px 6px;text-align:right">${ah}/${an}</td>
        <td style="padding:2px 6px;text-align:right">${pct(ah, an)}</td><td></td></tr>
    </table>
    ${good ? '' : badHtml}
    ${llmHtml}`;
}

/* ================= 参数化设计（把 copilot/ 做成 IDE 里的一个工具） ================= */
async function runParametricDesign() {
  const reqEl = document.getElementById('pdReq');
  const msg = document.getElementById('pdMsg');
  const out = document.getElementById('pdOut');
  if (!reqEl || !msg) return;
  const text = reqEl.value.trim();
  if (!text) { msg.innerHTML = '<span style="color:#d7ba7d">先写一句需求</span>'; return; }
  S.lastDesignReq = text;
  save();
  msg.innerHTML = '运行中…';
  out.innerHTML = '';

  try {
    const resp = await fetch('/api/design', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, use_llm: true }),
    });
    if (!resp.ok || !resp.body) { msg.textContent = '请求失败：HTTP ' + resp.status; return; }

    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    let result = null;

    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line) continue;
        let ev;
        try { ev = JSON.parse(line); } catch { continue; }

        if (ev.type === 'stage') {
          let t = escHtml(ev.label || ev.stage);
          if (ev.topology_name) t += `（${escHtml(ev.topology_name)}）`;
          if (ev.total) t += ` ${ev.done || 0}/${ev.total}`;
          msg.innerHTML = '<span style="color:var(--accent-2)">▸</span> ' + t;
        } else if (ev.type === 'error') {
          msg.innerHTML = '<span style="color:#f14c4c">✗ ' + escHtml(ev.error) + '</span>';
        } else if (ev.type === 'result') {
          result = ev;
        }
      }
    }

    if (!result) { msg.innerHTML = '<span style="color:#f14c4c">没有拿到结果</span>'; return; }
    const d = result.data || {};
    // 三种结局必须分开说：被拒（没做）/ 做了但有未达标 / 全部达标。
    // 以前一律打绿勾「✓ 设计完成」，连「这个结构做不到」都显示成功。
    if (d.error) {
      const head = (d.issues || []).some(i => String(i.code || '').startsWith('no_'))
        ? '⛔ 超出能力范围' : '✗ 未能完成';
      msg.innerHTML = `<span style="color:#f14c4c">${head}</span>`;
    } else if (d.passed === false) {
      msg.innerHTML = '<span style="color:#d7ba7d">⚠ 已出电路，有未达标项</span>';
    } else {
      msg.innerHTML = '<span style="color:#4ec9b0">✓ 全部达标</span>';
    }

    // 摘要：拓扑 / 元件参数 / 规格核对 / 蒙特卡洛成品率
    // （字段名以后端 simulate() 的 serialize 为准：spec / params / bom / mc）
    const rows = [];
    if (d.topology_name) rows.push(['拓扑', d.topology_name]);
    // 有结构化 issues 时不再重复整段 error（上面已分条渲染）
    if (d.error && !(d.issues || []).length) rows.push(['错误', String(d.error).slice(0, 300)]);
    for (const pr of (d.params || []).slice(0, 6)) {
      rows.push([pr.label || '', pr.value != null ? String(pr.value) : '']);
    }
    for (const sp of (d.spec || []).slice(0, 8)) {
      const got = sp.actual_text != null ? sp.actual_text
                : (sp.actual != null ? String(sp.actual) : '—');
      const want = sp.target_text != null ? sp.target_text : '';
      // ⚠ 后端字段名是 ok。历史上这里读错过字段名（读了一个不存在的键）：
      // undefined !== false 恒为真 → **所有指标行都显示 ✓**，包括没达标的。
      // 这条已用 API 实测核对过，并且有 tests_api/test_ui_contract.py 守着。
      const pass = sp.ok !== false;
      rows.push([sp.label || sp.key || '',
                 `${got}${want ? ' / ' + want : ''} ${pass ? '✓' : '✗'}`]);
    }
    const mc = d.mc || {};
    if (mc.yield_pct != null) {
      rows.push(['容差成品率', `${mc.yield_pct}%（${mc.ok_runs || 0}/${mc.runs || 0} 次）`]);
    }
    // 能力边界 / 不可行：分条渲染成「结论 + 为什么 + 怎么办」，而不是一坨文字
    const extra = [];
    if ((d.issues || []).length) {
      const card = (d.issues || []).map(i => {
        const bg = String(i.code || '').startsWith('no_') ? '#3a2a2a' : '#33301f';
        const bd = String(i.code || '').startsWith('no_') ? '#f14c4c' : '#d7ba7d';
        return `<div style="background:${bg};border-left:3px solid ${bd};` +
          `border-radius:3px;padding:7px 8px;margin-top:6px">` +
          `<div style="font-weight:600;font-size:11.5px">${escHtml(i.title || '')}</div>` +
          (i.evidence ? `<div class="sb-sub" style="margin-top:4px;line-height:1.55">` +
            `为什么：${escHtml(String(i.evidence).slice(0, 400))}</div>` : '') +
          (i.suggestion ? `<div class="sb-sub" style="margin-top:4px;line-height:1.55;color:#9cdcfe">` +
            `怎么办：${escHtml(String(i.suggestion).slice(0, 400))}</div>` : '') +
          `</div>`;
      }).join('');
      extra.push(card);
    }
    if (d.caveat) extra.push('<div class="sb-sub" style="margin-top:6px;color:#d7ba7d">⚠ ' +
      escHtml(String(d.caveat).slice(0, 160)) + '</div>');
    if (d.review) extra.push('<div class="sb-sub" style="margin-top:6px">' +
      escHtml(String(d.review).slice(0, 220)) + '</div>');

    const table = rows.length
      ? '<table style="width:100%;font-size:11.5px;border-collapse:collapse">' +
        rows.map(([k, v]) =>
          `<tr><td style="color:var(--fg-dim);padding:2px 0">${escHtml(k)}</td>` +
          `<td style="padding:2px 0;text-align:right">${escHtml(v)}</td></tr>`).join('') +
        '</table>'
      : '';
    // 被拒绝时本来就没有指标可列——不能报「后端未返回摘要」，
    // 那是把「我们主动说做不到」说成「后端出错」。
    const fallback = (d.error || (d.issues || []).length)
      ? '' : '<div class="sb-sub">后端未返回可展示的摘要，点下面看完整报告</div>';
    out.innerHTML = table + extra.join('') + fallback;

    if (result.id) {
      const btn = document.createElement('button');
      btn.className = 'sb-btn sb-wide';
      btn.style.marginTop = '8px';
      btn.textContent = '⤓ 打开完整报告';
      btn.onclick = () => openDesignReport(result.id);
      out.appendChild(btn);
    }
  } catch (e) {
    msg.innerHTML = '<span style="color:#f14c4c">✗ ' + escHtml(e.message) + '</span>';
  }
}

async function openDesignReport(sid) {
  try {
    const r = await fetch('/api/report/' + encodeURIComponent(sid));
    if (!r.ok) { setStatus('报告已过期，请重新设计'); return; }
    const md = await r.text();
    panels.showReport(md);            // 复用现有报告面板
    panels.setActive('report');
  } catch (e) { setStatus('报告打开失败'); }
}

/* ================= AI 模型配置 ================= */
async function loadAiConfig() {
  const msg = () => document.getElementById('cfgMsg');
  try {
    const r = await fetch('/api/config');
    const d = await r.json();
    const b = document.getElementById('cfgBase');
    const m = document.getElementById('cfgModel');
    if (b) b.value = d.base || '';
    if (m) m.value = d.model || '';
    const k = document.getElementById('cfgKey');
    if (k) {
      k.placeholder = d.hasKey ? `已配置（${d.keyMasked}），留空则不修改` : '还没配置';
    }
    if (msg()) {
      msg().innerHTML = d.hasKey
        ? '<span style="color:#4ec9b0">✓ 已配置</span>'
        : '<span style="color:#d7ba7d">⚠ 未配置 Key，AI 功能不可用（其他功能不受影响）</span>';
    }
  } catch (e) { if (msg()) msg().textContent = '读取配置失败：' + e.message; }
}

async function saveAiConfig(doSave) {
  const msg = document.getElementById('cfgMsg');
  const set = (t) => { if (msg) msg.innerHTML = t; };
  const base = (document.getElementById('cfgBase') || {}).value || '';
  const model = (document.getElementById('cfgModel') || {}).value || '';
  const key = (document.getElementById('cfgKey') || {}).value || '';

  if (doSave) {
    set('保存中…');
    try {
      const r = await fetch('/api/config', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base, model, key }),
      });
      const d = await r.json();
      if (!d.ok) { set('<span style="color:#f14c4c">保存失败：' + (d.error || '') + '</span>'); return; }
      const k = document.getElementById('cfgKey');
      if (k) k.value = '';                 // 保存后清空，不回显明文
    } catch (e) { set('<span style="color:#f14c4c">保存失败：' + e.message + '</span>'); return; }
  }

  // 真做一次极小调用 —— "保存成功"不等于"能用"
  set('正在测试连通性…');
  try {
    const r = await fetch('/api/config?test=1');
    const d = await r.json();
    const t = d.test || {};
    if (t.ok) {
      // 回复可能为空（小 max_tokens 被推理占满）—— 空就别显示「」
      const got = (t.reply || '').trim();
      const tail = got ? `，回复「${escHtml(got)}」` : '';
      set(`<span style="color:#4ec9b0">✓ 连通（${t.ms}ms${tail}）</span>` +
          `<br><span style="color:var(--fg-dim)">${escHtml(d.model || '')}</span>`);
    } else {
      set('<span style="color:#f14c4c">✗ 连不通：' + escHtml(t.error || '未知错误') + '</span>' +
          '<br><span style="color:var(--fg-dim)">检查接口地址 / Key / 网络</span>');
    }
  } catch (e) { set('<span style="color:#f14c4c">测试失败：' + e.message + '</span>'); }
}

function escHtml(t) {
  return String(t == null ? '' : t).replace(/[&<>"]/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/* ================= 电路图全屏查看 ================= */
function toggleBigSchem(force) {
  const exist = document.getElementById('bigschem');
  if (exist || force === false) { if (exist) exist.remove(); return; }
  const svg = S.lastSchematic;
  if (!svg) return;

  const box = document.createElement('div');
  box.id = 'bigschem';
  const inner = document.createElement('div');
  inner.id = 'bigschem-inner';
  inner.innerHTML = svg;
  // SVG 只带 viewBox、没有固有尺寸，放进浮层会塌成 0 宽。
  // 按 viewBox 显式给 width/height（放大 1.4 倍便于阅读）。
  const el = inner.querySelector('svg');
  if (el) {
    const vb = (el.getAttribute('viewBox') || '').split(/\s+/).map(Number);
    if (vb.length === 4 && vb[2] > 0 && vb[3] > 0) {
      el.setAttribute('width', Math.round(vb[2] * 1.4));
      el.setAttribute('height', Math.round(vb[3] * 1.4));
      el.removeAttribute('style');
    }
    el.style.cursor = 'default';
  }
  const hint = document.createElement('div');
  hint.className = 'bigschem-hint';
  hint.textContent = '点任意处或按 Esc 关闭';
  box.appendChild(inner);
  box.appendChild(hint);
  box.addEventListener('click', () => box.remove());
  document.body.appendChild(box);
}

/* ================= 电路图导出 ================= */
function exportSvg() {
  const svg = S.lastSchematic;
  if (!svg) { $('#stStatus').textContent = '先运行一次电路'; return; }
  // 导出前把 width/height 去掉，让看图器按 viewBox 自适应
  const clean = svg.replace(/width="100%"/, '').replace(/height="auto"/, '');
  const blob = new Blob(['<?xml version="1.0" encoding="UTF-8"?>\n' + clean],
                        { type: 'image/svg+xml;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `schematic-${(cur() || {}).title || 'circuit'}.svg`.replace(/\s/g, '_');
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
  $('#stStatus').textContent = '电路图已导出';
}

/* ================= 报告 ================= */
async function exportReport() {
  const t = cur();
  if (!t) return;
  $('#stStatus').textContent = '生成报告…';
  try {
    const r = await fetch('/api/ccl/report', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      // 必须带上开关覆盖状态：否则屏幕上是「SW1 闭合、19.4mA」，导出报告却按
      // 代码原样（开关断开、5nA）出数 —— 用户拿去评审的是另一条电路。
      body: JSON.stringify({
        code: editor.getValue(),
        analysis: S.analysis,
        switch_states: switchStatesForRequest(t),
      }),
    });
    const d = await r.json();
    if (!d.ok) { $('#stStatus').textContent = '报告失败'; panels.showProblems([{ level: 'error', title: '报告生成失败', detail: d.error }]); panels.setActive('problems'); return; }
    panels.showReport(d.markdown);
    panels.setActive('report');
    const isAndroid = /Android/i.test(navigator.userAgent);
    if (isAndroid && d.id) window.open('/api/ccl/report/' + d.id, '_blank');
    else {
      const blob = new Blob([d.markdown], { type: 'text/markdown;charset=utf-8' });
      const a2 = document.createElement('a');
      a2.href = URL.createObjectURL(blob); a2.download = d.filename || 'report.md';
      document.body.appendChild(a2); a2.click();
      setTimeout(() => { URL.revokeObjectURL(a2.href); a2.remove(); }, 800);
    }
    $('#stStatus').textContent = '报告已导出';
  } catch (e) { $('#stStatus').textContent = '报告失败'; }
}

/* ================= 本地文件工作区 ================= */
const FILE_DB_NAME = 'ccl-studio-files';
const FILE_DB_STORE = 'handles';

async function fileDbGet(key) {
  return new Promise((resolve) => {
    if (!window.indexedDB) return resolve(null);
    const req = indexedDB.open(FILE_DB_NAME, 1);
    req.onupgradeneeded = () => { req.result.createObjectStore(FILE_DB_STORE); };
    req.onsuccess = () => {
      const db = req.result;
      const get = db.transaction(FILE_DB_STORE, 'readonly').objectStore(FILE_DB_STORE).get(key);
      get.onsuccess = () => { db.close(); resolve(get.result || null); };
      get.onerror = () => { db.close(); resolve(null); };
    };
    req.onerror = () => resolve(null);
  });
}

async function fileDbPut(key, value) {
  return new Promise((resolve) => {
    if (!window.indexedDB) return resolve(false);
    const req = indexedDB.open(FILE_DB_NAME, 1);
    req.onupgradeneeded = () => { req.result.createObjectStore(FILE_DB_STORE); };
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction(FILE_DB_STORE, 'readwrite');
      tx.objectStore(FILE_DB_STORE).put(value, key);
      tx.oncomplete = () => { db.close(); resolve(true); };
      tx.onerror = () => { db.close(); resolve(false); };
    };
    req.onerror = () => resolve(false);
  });
}

async function ensureFilePermission(handle, writable = false) {
  if (!handle || !handle.queryPermission) return true;
  const mode = writable ? 'readwrite' : 'read';
  let state = await handle.queryPermission({ mode });
  if (state === 'granted') return true;
  state = await handle.requestPermission({ mode });
  return state === 'granted';
}

async function restoreLocalDirectory() {
  try {
    const handle = await fileDbGet('directory');
    if (!handle || !(await ensureFilePermission(handle, false))) return;
    S.directoryHandle = handle;
    await scanWorkspace();
  } catch (_) {}
}

async function openLocalDirectory() {
  try {
    if (!window.showDirectoryPicker) {
      setStatus('当前浏览器不支持目录选择，请使用打开本地文件');
      return;
    }
    const handle = await window.showDirectoryPicker({ mode: 'readwrite' });
    S.directoryHandle = handle;
    await fileDbPut('directory', handle);
    await scanWorkspace();
    if (S.act === 'files') setSidebar('files');
    setStatus('已打开目录：' + handle.name);
  } catch (e) {
    if (e && e.name !== 'AbortError') setStatus('无法打开目录：' + e.message);
  }
}

async function openLocalFile() {
  try {
    if (window.showOpenFilePicker) {
      const handles = await window.showOpenFilePicker({
        multiple: false,
        types: [{ description: '代码与文本文件', accept: { 'text/plain': ['.py', '.txt', '.md', '.cir', '.json', '.ccl'], 'application/json': ['.json'] } }],
      });
      const handle = handles[0];
      if (!(await ensureFilePermission(handle, false))) return;
      await openFileHandle(handle);
    } else {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.py,.txt,.md,.cir,.json,.ccl,text/plain';
      input.onchange = async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        openTab({ title: file.name, code: await file.text(), analysis: { kind: S.analysis.kind } });
      };
      input.click();
    }
  } catch (e) {
    if (e && e.name !== 'AbortError') setStatus('无法打开文件：' + e.message);
  }
}

async function openFileHandle(handle) {
  if (!(await ensureFilePermission(handle, false))) return;
  const file = await handle.getFile();
  const code = await file.text();
  const existing = S.tabs.find(t => t.fileHandle === handle);
  if (existing) selectTab(existing.id);
  else openTab({ title: handle.name, code, analysis: { kind: S.analysis.kind }, fileHandle: handle });
  setStatus('已打开：' + handle.name);
  markDirty(false);
}

async function createLocalFile() {
  const defaultName = 'untitled.py';
  const name = window.prompt('新建文件名', defaultName);
  if (!name) return;
  if (/[\\\/]/.test(name)) { setStatus('文件名不能包含路径分隔符'); return; }
  try {
    let handle;
    if (S.directoryHandle) {
      if (!(await ensureFilePermission(S.directoryHandle, true))) return;
      handle = await S.directoryHandle.getFileHandle(name, { create: true });
    } else if (window.showSaveFilePicker) {
      handle = await window.showSaveFilePicker({ suggestedName: name });
    } else {
      openTab({ title: name, code: DEFAULT_CODE, analysis: { kind: S.analysis.kind } });
      setStatus('已创建标签；当前浏览器不支持直接写入本地目录');
      return;
    }
    await openFileHandle(handle);
    await scanWorkspace();
    if (S.act === 'files') setSidebar('files');
  } catch (e) {
    if (e && e.name !== 'AbortError') setStatus('无法创建文件：' + e.message);
  }
}

async function saveCurrentFile() {
  const t = cur();
  if (!t || !editor) return;
  t.code = editor.getValue();
  save();
  markDirty(false);
  if (!t.fileHandle) {
    setStatus('已保存到本地会话');
    return;
  }
  try {
    if (!(await ensureFilePermission(t.fileHandle, true))) return;
    const writable = await t.fileHandle.createWritable();
    await writable.write(t.code);
    await writable.close();
    await scanWorkspace();
    if (S.act === 'files') setSidebar('files');
    setStatus('已保存：' + t.title);
  } catch (e) {
    setStatus('保存失败：' + e.message);
  }
}

async function scanWorkspace() {
  S.localFiles = [];
  if (!S.directoryHandle) return;
  await collectDirectory(S.directoryHandle, '', S.localFiles);
}

async function collectDirectory(directory, prefix, output) {
  for await (const entry of directory.values()) {
    const path = prefix ? prefix + '/' + entry.name : entry.name;
    output.push({ name: entry.name, path, kind: entry.kind, handle: entry });
    if (entry.kind === 'directory') await collectDirectory(entry, path, output);
  }
}

function renderWorkspaceTree(box) {
  if (!box) return;
  if (!S.directoryHandle) {
    box.innerHTML = '<div class="empty file-empty">未打开本地目录</div>'; return;
  }
  const rootName = esc(S.directoryHandle.name);
  box.innerHTML = `<div class="workspace-root"><span>▼ ${rootName}</span></div><div id="workspaceEntries"></div>`;
  const entries = box.querySelector('#workspaceEntries');
  renderDirectoryEntries(entries, S.localFiles);
}

function renderDirectoryEntries(container, entries) {
  if (!entries.length) {
    container.innerHTML = '<div class="empty file-empty">目录为空</div>'; return;
  }
  const sorted = entries.slice().sort((a, b) => {
    if (a.kind !== b.kind) return a.kind === 'directory' ? -1 : 1;
    return a.path.localeCompare(b.path);
  });
  container.innerHTML = sorted.map(e => {
    const depth = Math.max(0, e.path.split('/').length - 1);
    const index = entries.indexOf(e);
    return `<div class="sb-item sb-file ${e.kind === 'directory' ? 'sb-folder' : ''}" data-local-index="${index}" style="padding-left:${10 + depth * 14}px" title="${esc(e.path)}">
      ${e.kind === 'directory' ? '📁' : '📄'} ${esc(e.name)}
    </div>`;
  }).join('');
}

/* ================= 侧边栏 ================= */
const DEVICES = [
  ['c.R(a, b, value)', '电阻'],
  ['c.C(a, b, value)', '电容'],
  ['c.L(a, b, value)', '电感'],
  ['c.V(a, b, dc, ac)', '电压源'],
  ['c.I(a, b, dc, ac)', '电流源'],
  ['c.OpAmp(inp, inn, out, gbw=)', '运放（含 GBW）'],
  ['c.D(a, k, model)', '二极管 D1N4148/D1N4007/D1N5819'],
  ['c.Q(c, b, e, model)', '三极管 Q2N3904/Q2N3906'],
  ['c.M(d, g, s, bulk, model)', 'MOSFET M2N7002/MIRF540'],
  ['c.PULSE(a, b, v1, v2, ...)', '脉冲源（瞬态）'],
  ['c.SIN(a, b, vo, va, freq)', '正弦源'],
  ['c.expect(kind, node, value, tol)', '规格断言'],
  ['c.use_ports(block, {in, out})', '按端口内联子电路'],
];

function setActivity(name) {
  S.act = name;
  $$('#activity .act').forEach(b => b.classList.toggle('on', b.dataset.act === name));
}
function setSidebar(name) {
  setActivity(name);
  const title = { files: '文件', blocks: '代码速查', ai: 'AI 助手',
                    problems: '问题', export: '导出', design: '参数化设计',
                    plugins: '插件', settings: '分析设置', bench: '拦截基准' }[name]
    || (pluginPanels.find(p => p.key === name) || {}).title || name;
  $('#sidebarTitle').textContent = title;
  const box = $('#sidebar-content');

  // 插件面板优先：key 形如 plg:<pluginId>:<panelId>
  if (name.startsWith('plg:') && renderPluginPanel(name, box)) return;
  if (name === 'plugins') { renderPluginManager(box); return; }
  if (name === 'bench') { renderBench(box); return; }

  if (name === 'files') {
    box.innerHTML = `
      <div class="file-toolbar">
        <button class="sb-btn" id="openFolderBtn" title="打开本地目录">打开目录</button>
        <button class="sb-btn" id="openFileBtn" title="打开本地文件">打开文件</button>
        <button class="sb-btn" id="newFileBtn" title="在当前目录创建文件">新建</button>
        <button class="sb-btn" id="refreshFolderBtn" title="刷新目录文件列表">刷新</button>
      </div>
      <div id="workspaceTree"></div>
      <div class="sb-sub sb-examples-title">示例</div>
      <div id="exampleFiles"></div>`;
    box.querySelector('#openFolderBtn').onclick = () => openLocalDirectory();
    box.querySelector('#openFileBtn').onclick = () => openLocalFile();
    box.querySelector('#newFileBtn').onclick = () => createLocalFile();
    box.querySelector('#refreshFolderBtn').onclick = async () => {
      await scanWorkspace();
      setSidebar('files');
      setStatus(S.directoryHandle ? '目录已刷新：' + S.directoryHandle.name : '未打开本地目录');
    };
    renderWorkspaceTree(box.querySelector('#workspaceTree'));
    const exampleBox = box.querySelector('#exampleFiles');
    exampleBox.innerHTML = S.examples.map((e, i) =>
      `<div class="sb-item sb-file" data-ex="${i}" title="打开示例">📄 ${esc(e.title)}</div>`).join('') ||
      '<div class="empty">没有示例（后端未就绪）</div>';
    box.onclick = async (ev) => {
      const local = ev.target.closest('[data-local-index]');
      if (local) {
        const entry = S.localFiles[+local.dataset.localIndex];
        if (entry && entry.kind === 'file') await openFileHandle(entry.handle);
        else if (entry && entry.kind === 'directory') setStatus('目录：' + entry.path);
        return;
      }
      const ex = ev.target.closest('[data-ex]');
      if (ex) {
        const e = S.examples[+ex.dataset.ex];
        openTab({ title: e.title + '.py', code: e.code, analysis: e.analysis });
      }
    };
  } else if (name === 'blocks') {
    // 代码速查：子电路库 + 器件速查合并（同类功能——都是点击插入）
    box.innerHTML = `
      <div class="sb-sub" style="padding:6px 8px 2px">🧩 子电路库（点击插入）</div>
      ${S.blocks.map((b, i) =>
        `<div class="sb-item" data-blk="${i}" title="${esc(b.summary)}（点击插入）">🧩 ${esc(b.name)}
          <div class="sb-sub">${esc(b.summary)}</div></div>`).join('')
        || '<div class="empty">没有子电路库</div>'}
      <div class="sb-sub" style="padding:10px 8px 2px;border-top:1px solid var(--border);margin-top:6px">🔧 器件速查（点击插入）</div>
      ${DEVICES.map(([sig, desc], i) =>
        `<div class="sb-item" data-dev="${i}" title="点击插入示例代码"><code>${esc(sig)}</code>
          <div class="sb-sub">${esc(desc)}</div></div>`).join('')}`;
    box.onclick = (ev) => {
      const blk = ev.target.closest('[data-blk]');
      if (blk) {
        const b = S.blocks[+blk.dataset.blk];
        const snip = BLOCK_SNIPPETS[b.name];
        if (snip) insertSnippet(snip);
        return;
      }
      const dev = ev.target.closest('[data-dev]');
      if (dev) {
        const [sig] = DEVICES[+dev.dataset.dev];
        const snip = DEVICE_SNIPPETS[sig];
        if (snip) insertSnippet(snip);
      }
    };
  } else if (name === 'design') {
    box.innerHTML = `
      <div style="padding:8px">
        <div class="sb-sub" style="line-height:1.6;margin-bottom:6px">
          用一句话描述需求，自动选拓扑、定参数、做容差分析。
          <br>和代码编辑是两个入口，共用同一个 ngspice 内核。
        </div>
        <textarea id="pdReq" rows="3" class="cfg-in" style="resize:vertical"
          placeholder="例：做一个 1kHz 的 RC 低通滤波器，电源 5V"></textarea>
        <div style="display:flex;gap:6px;margin-top:6px">
          <button class="sb-btn sb-wide" id="btnPdRun">开始设计</button>
        </div>
        <div id="pdMsg" class="sb-sub" style="margin-top:8px;line-height:1.7"></div>
        <div id="pdOut" style="margin-top:8px"></div>
        <div style="margin-top:10px;border-top:1px solid var(--border);padding-top:8px">
          <div class="sb-sub" style="margin-bottom:5px">这里只有文字摘要。Bode 图、容差分布、报告导出在完整界面：</div>
          <button class="sb-btn sb-wide" id="pdOpenFull">↗ 在完整界面打开</button>
        </div>
      </div>`;
    $('#btnPdRun').onclick = () => runParametricDesign();
    // 双向打通：把当前输入的话带到根界面（/?q=…），那边预填后自动开跑。
    // 没输入时就地打开完整界面。Android WebView 不支持 window.open 多窗口
    // （target=_blank 被宿主吞掉，实测点击无反应），分流：Android 当前页
    // 导航，桌面浏览器开新标签保住 IDE 里的编辑状态。
    $('#pdOpenFull').onclick = () => {
      const t = ($('#pdReq').value || '').trim();
      const url = '/' + (t ? '?q=' + encodeURIComponent(t) : '');
      if (/Android/i.test(navigator.userAgent)) location.href = url;
      else window.open(url, '_blank');
    };
    const prev = S.lastDesignReq;
    if (prev) $('#pdReq').value = prev;
  } else if (name === 'ai') {
    box.innerHTML = `
      <div style="padding:8px">
        <input id="aiPrompt" placeholder="一句话描述电路…" style="width:100%;background:#3c3c3c;border:1px solid #3c3c3c;color:#ccc;border-radius:3px;padding:6px;font-size:12px">
        <div style="display:flex;gap:6px;margin-top:6px">
          <button class="sb-btn" id="btnAiGen">生成</button>
          <button class="sb-btn" id="btnAiFix">修复</button>
          <button class="sb-btn" id="btnAiExp">解释</button>
        </div>
        <div id="aiMsg" class="sb-sub" style="margin-top:8px"></div>

        <details id="aiCfg" style="margin-top:12px;border-top:1px solid var(--border);padding-top:8px">
          <summary style="cursor:pointer;color:var(--fg-dim);font-size:12px">⚙ 模型配置</summary>
          <div style="margin-top:8px;display:flex;flex-direction:column;gap:6px">
            <label class="cfg-lb">接口地址</label>
            <input class="cfg-in" id="cfgBase" placeholder="http://127.0.0.1:7863/v1">
            <label class="cfg-lb">模型</label>
            <input class="cfg-in" id="cfgModel" placeholder="cn:deepseek-v4-flash">
            <label class="cfg-lb">API Key</label>
            <input class="cfg-in" id="cfgKey" type="password" placeholder="留空 = 不修改">
            <div style="display:flex;gap:6px;margin-top:4px">
              <button class="sb-btn" id="btnCfgSave">保存并测试</button>
              <button class="sb-btn" id="btnCfgTest">仅测试</button>
            </div>
            <div id="cfgMsg" class="sb-sub" style="line-height:1.6"></div>
          </div>
        </details>
      </div>`;
    $('#btnAiGen').onclick = () => aiCall('generate');
    $('#btnAiFix').onclick = () => aiCall('fix');
    $('#btnAiExp').onclick = () => aiCall('explain');
    $('#btnCfgSave').onclick = () => saveAiConfig(true);
    $('#btnCfgTest').onclick = () => saveAiConfig(false);
    loadAiConfig();
  } else if (name === 'problems') {
    const list = (S.lastResult && S.lastResult.lint) || [];
    box.innerHTML = list.length
      ? list.map(i => `<div class="sb-item" data-line="${i.ref ? '' : ''}">
          <span style="color:${i.level === 'error' ? '#f14c4c' : '#d7ba7d'}">${i.level === 'error' ? '错误' : '警告'}</span>
          ${esc(i.title)}</div>`).join('')
      : '<div class="empty">没有问题，或还没运行。</div>';
  } else if (name === 'export') {
    box.innerHTML = `
      <div style="padding:8px;display:flex;flex-direction:column;gap:8px">
        <button class="sb-btn sb-wide" id="sbSvg">⤓ 电路图 SVG</button>
        <button class="sb-btn sb-wide" id="sbReport">⤓ Markdown 报告</button>
        <div class="sb-sub" style="margin-top:4px;line-height:1.6">
          · 电路图由代码自动生成，样式内联，可直接放进文档<br>
          · 报告含概况 / 器件清单 / 网表 / 实测 / 检查 / 规格核对
        </div>
      </div>`;
    $('#sbSvg').onclick = () => exportSvg();
    $('#sbReport').onclick = () => exportReport();
  } else if (name === 'settings') {
    // 这里**不再重复**分析类型/参数：编辑区顶部工具条已常驻（同样一份状态），
    // 两处各摆一套只会让人怀疑哪个才算数。设置面板只放工具条上没有的东西。
    const fs = (editor && editor.getFontSize) ? editor.getFontSize() : 14;
    const eng = $('#stEngine') ? $('#stEngine').textContent : 'ngspice ?';
    box.innerHTML = `
      <div style="padding:8px;font-size:12px">
        <div class="sb-sub" style="line-height:1.6;margin-bottom:10px">
          分析类型与参数在<b>编辑区顶部工具条</b>（交流 / 工作点 / 瞬态 / 直流扫描），
          这里只管工具条没有的设置。
        </div>

        <div style="margin-bottom:6px;color:var(--fg-dim)">编辑器字体</div>
        <div style="display:flex;gap:6px;align-items:center">
          <button class="sb-btn" id="sbFontDown" style="flex:0 0 40px">−</button>
          <div style="flex:1;text-align:center" id="sbFontVal">${fs}px</div>
          <button class="sb-btn" id="sbFontUp" style="flex:0 0 40px">+</button>
        </div>
        <button class="sb-btn sb-wide" id="sbFontReset" style="margin-top:6px">重置字号</button>

        <div style="margin-top:14px;padding-top:10px;border-top:1px solid var(--border);color:var(--fg-dim)">布局</div>
        <button class="sb-btn sb-wide" id="sbResetLayout" style="margin-top:6px">重置布局（侧栏宽 / 面板高 / 折叠）</button>

        <div style="margin-top:14px;padding-top:10px;border-top:1px solid var(--border);color:var(--fg-dim)">系统</div>
        <div class="sb-sub" style="line-height:1.8;margin-top:4px">引擎：${esc(eng)}</div>
        <button class="sb-btn sb-wide" id="sbGoBench" style="margin-top:6px">🛡 运行拦截基准</button>
        <button class="sb-btn sb-wide" id="sbGoPlugins" style="margin-top:6px">🔌 插件管理</button>
        <button class="sb-btn sb-wide" id="sbGoDesign" style="margin-top:6px">◆ 参数化设计</button>
      </div>`;
    const setFs = (px) => {
      // 必须写回 ui.fontSize：否则每次点击都拿初始值重算，
      // 连按两次「+」会卡在 15px 不动（实测踩过）。
      ui.fontSize = px;
      applyFontSize(px);
      const el = box.querySelector('#sbFontVal');
      if (el) el.textContent = px + 'px';
      save();
    };
    box.querySelector('#sbFontUp').onclick = () => setFs(Math.min(24, (ui.fontSize || fs) + 1));
    box.querySelector('#sbFontDown').onclick = () => setFs(Math.max(13, (ui.fontSize || fs) - 1));
    box.querySelector('#sbFontReset').onclick = () => { ui.fontSize = 14; setFs(14); };
    box.querySelector('#sbResetLayout').onclick = () => {
      const root = document.documentElement;
      root.style.removeProperty('--sidebar-w');
      root.style.removeProperty('--panel-h');
      document.body.classList.remove('sb-collapsed', 'panel-collapsed');
      document.body.classList.remove('panel-max');
      setStatus('布局已重置');
      save();
    };
    box.querySelector('#sbGoBench').onclick = () => setSidebar('bench');
    box.querySelector('#sbGoPlugins').onclick = () => setSidebar('plugins');
    box.querySelector('#sbGoDesign').onclick = () => setSidebar('design');
  }
}

/* 分析设置的**唯一入口**：侧栏「分析设置」与编辑区顶部工具条共享它，
   避免两处各改一份状态导致不同步。 */
function setAnalysisKind(kind) {
  S.analysis.kind = kind;
  $$('#segKind [data-k]').forEach(b => b.classList.toggle('on', b.dataset.k === kind));
  $$('#segKind2 [data-k]').forEach(b => b.classList.toggle('on', b.dataset.k === kind));
  renderToolbarParams();
  renderKindParams();
  syncStatus();
  save();
}

function setAnalysisParam(key, value) {
  const v = Number(value);
  if (!isFinite(v)) return;
  S.analysis[key] = v;
  save();
}

/* 顶部工具条的参数输入（与侧栏设置共用 S.analysis） */
function renderToolbarParams() {
  const box = $('#tbParams');
  if (!box) return;
  const k = S.analysis.kind;
  const f = (label, key, val, w) =>
    `<label class="tb-field" style="width:${w || 76}px"><span>${label}</span>
       <input data-k="${key}" value="${val}"></label>`;
  if (k === 'ac') {
    box.innerHTML = f('f起', 'f_start', S.analysis.f_start) +
                    f('f止', 'f_stop', S.analysis.f_stop) +
                    f('点/dec', 'points', S.analysis.points, 62);
  } else if (k === 'tran') {
    box.innerHTML = f('步长', 't_step', S.analysis.t_step || 1e-6) +
                    f('时长', 't_stop', S.analysis.t_stop || 5e-4);
  } else if (k === 'dc') {
    box.innerHTML = f('扫', 'source', S.analysis.source || 'V1', 54) +
                    f('起', 'dc_start', S.analysis.dc_start ?? 0) +
                    f('止', 'dc_stop', S.analysis.dc_stop ?? 10) +
                    f('步', 'dc_step', S.analysis.dc_step ?? 0.5, 62);
  } else {
    box.innerHTML = '<span class="tb-hint">工作点无需参数</span>';
  }
  box.querySelectorAll('input').forEach(inp => {
    inp.onchange = () => {
      const key = inp.dataset.k;
      if (key === 'source' || key === 'second_source') {   // 位号是字符串，别 Number 化
        S.analysis[key] = inp.value.trim();
        save();
      } else {
        setAnalysisParam(key, inp.value);
      }
    };
    inp.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); run(); } };
  });
}

function renderKindParams() {
  const box = $('#kParams');
  if (!box) return;
  const k = S.analysis.kind;
  if (k === 'ac') {
    box.innerHTML = field('起始频率', 'f_start', S.analysis.f_start) +
      field('终止频率', 'f_stop', S.analysis.f_stop) + field('点/十倍频', 'points', S.analysis.points);
  } else if (k === 'tran') {
    box.innerHTML = field('步长', 't_step', S.analysis.t_step || 1e-6) +
      field('时长', 't_stop', S.analysis.t_stop || 5e-4);
  } else if (k === 'dc') {
    box.innerHTML = field('被扫位号', 'source', S.analysis.source || 'V1') +
      field('起始', 'dc_start', S.analysis.dc_start ?? 0) +
      field('终止', 'dc_stop', S.analysis.dc_stop ?? 10) +
      field('步长', 'dc_step', S.analysis.dc_step ?? 0.5) +
      '<div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border)">' +
      '<div style="color:var(--fg-dim);margin-bottom:6px">第二维（可选，做输出特性曲线族）</div>' +
      field('位号', 'second_source', S.analysis.second_source || '') +
      field('起始', 'second_start', S.analysis.second_start ?? 0) +
      field('终止', 'second_stop', S.analysis.second_stop ?? 1e-3) +
      field('步长', 'second_step', S.analysis.second_step ?? 5e-4) +
      '<div style="color:var(--fg-dim);font-size:11px;margin-top:6px;line-height:1.5">' +
      '位号留空 = 只做一维扫描</div></div>';
  } else {
    box.innerHTML = '<div class="sb-sub">直流工作点不需要额外参数。</div>';
  }
  box.querySelectorAll('input').forEach(inp => {
    inp.onchange = () => {
      const key = inp.dataset.key;
      // 位号是字符串，不能 Number 化（'V1' → NaN）。空串表示「不做第二维」。
      if (key === 'source' || key === 'second_source') {
        S.analysis[key] = inp.value.trim();
        save();
      } else {
        setAnalysisParam(key, inp.value);
      }
    };
  });
}
function field(label, key, val) {
  return `<label style="display:block;margin-bottom:6px">
    <span class="sb-sub">${label}</span>
    <input data-key="${key}" value="${val}" style="width:100%;background:#3c3c3c;border:1px solid #3c3c3c;color:#ccc;border-radius:3px;padding:4px;font-family:var(--mono)">
  </label>`;
}

/* ================= AI ================= */
async function aiCall(action) {
  const msg = $('#aiMsg');
  const prompt = ($('#aiPrompt') && $('#aiPrompt').value || '').trim();
  if (action === 'generate' && !prompt) { if (msg) msg.textContent = '先写一句需求'; return; }
  if (msg) msg.textContent = { generate: 'AI 正在写电路…', fix: '诊断并修复…', explain: '正在解释…' }[action];
  try {
    const body = { action, code: editor.getValue(), analysis: S.analysis };
    if (prompt) body.prompt = prompt;
    const r = await fetch('/api/ccl/ai', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    const d = await r.json();
    if (!d.ok) { if (msg) msg.textContent = '失败：' + (d.error || ''); return; }
    if (action === 'explain') {
      if (msg) msg.innerHTML = `<div style="white-space:pre-wrap;line-height:1.7">${esc(d.text || '')}</div>`;
      return;
    }
    if (d.source) {
      editor.setValue(d.source);
      if (cur()) {
        cur().code = d.source;
        // 记下「这段代码是为哪句需求生成的」：之后每次 ▶ 运行都会带上它做需求对账，
        // 否则就是「生成时验一次、之后永远裸奔」（用户改了元件值也没人再核对）。
        if (action === 'generate' && (prompt || '').trim()) cur().require = prompt.trim();
      }
      markDirty(true);
    }
    if (msg) {
      const base = action === 'generate'
        ? `已生成（${(d.attempts || []).length} 轮${d.expectations ? `，${d.expectations} 条断言` : ''}）`
        : ((d.attempts || []).length === 0 ? '没发现问题（未调用模型）' : `已修复（${(d.attempts || []).length} 轮）`);
      // 不致命但必须让用户看见：模型自加的断言没过（它可能写错了）。
      // 以前这种情况直接判失败、把电路丢掉；现在交付但把可疑断言列出来。
      const warns = d.warnings || [];
      msg.innerHTML = esc(base) + (warns.length
        ? warns.map(w => `<div class="sb-sub" style="margin-top:6px;color:#d7ba7d;line-height:1.55">⚠ ${
            esc(String(w).slice(0, 300))}</div>`).join('')
        : '');
    }
    if (action === 'generate') run();
  } catch (e) { if (msg) msg.textContent = '请求失败：' + e.message; }
}

/* ==================================================================
 * 桌面版外壳（Lead 维护）
 *
 * 目标：在电脑浏览器里打开就像 VS Code。四块：
 *   1. 菜单栏（文件/编辑/视图/转到/运行/帮助）—— 下拉由本文件生成
 *   2. 面包屑（文件 › 函数 › 当前符号）
 *   3. VS Code 键位（Ctrl+B / Ctrl+J / Ctrl+G / Ctrl+P / Ctrl+= / Alt+↑↓ …）
 *   4. 编辑器右键菜单
 *
 * 约定：DOM 由这里建，视觉全部交给 style.css（#menubar / .mn-drop / #breadcrumbs /
 * #ctx-menu 等 class 已写在契约 CONTRACT_ROUND5_DESKTOP.md 里）。这里只写
 * **必须由 JS 计算**的内联值（坐标、宽度），不写颜色和圆角。
 * ================================================================== */

/** 布局状态（不变量存：面板高/侧栏宽这类值直接读 CSS 变量，唯一存内存的是字号） */
const ui = { fontSize: 0 };

/** 读出当前布局，交给 save() 写进 localStorage 的 ui 字段 */
function readUi() {
  const cs = getComputedStyle(document.documentElement);
  const n = (v) => { const x = parseInt(v, 10); return Number.isFinite(x) ? x : null; };
  const onTab = document.querySelector('#panel-tabs .ptab.on');
  return {
    panelH: n(cs.getPropertyValue('--panel-h')),
    sidebarW: n(cs.getPropertyValue('--sidebar-w')),
    sbCollapsed: document.body.classList.contains('sb-collapsed'),
    panelCollapsed: document.body.classList.contains('panel-collapsed'),
    panelMax: document.body.classList.contains('panel-max'),
    activePanel: onTab ? onTab.dataset.panel : null,
    sbAct: S.act,
    fontSize: ui.fontSize || null,
  };
}

/** 恢复布局。老存档（v1）没有 ui 字段 → 传进来是 undefined，直接返回。 */
function applyUi(u) {
  if (!u) return;
  const root = document.documentElement;
  if (u.panelH) root.style.setProperty('--panel-h', Math.min(u.panelH, Math.round(window.innerHeight * 0.7)) + 'px');
  if (u.sidebarW) root.style.setProperty('--sidebar-w', Math.min(u.sidebarW, Math.round(window.innerWidth * 0.5)) + 'px');
  document.body.classList.toggle('sb-collapsed', !!u.sbCollapsed);
  document.body.classList.toggle('panel-collapsed', !!u.panelCollapsed);
  if (u.fontSize) { ui.fontSize = u.fontSize; applyFontSize(u.fontSize); }
  if (u.activePanel && panels) panels.setActive(u.activePanel);
  // maximize 走 panels.js（它负责 body.panel-max + 派发事件）；还没交付就自己加 class
  if (u.panelMax) {
    if (panels && panels.maximize) panels.maximize(true);
    else document.body.classList.add('panel-max');
  }
  if (editor && editor.layout) editor.layout();
}

/* ---------------- 菜单栏 ---------------- */

/** 菜单定义。第三项是动作；'-' 是分隔线。键位与 VS Code 对齐。 */
const MENUS = [
  {
    label: '文件', items: [
      ['新建标签', 'Ctrl+N', () => openTab({ title: 'untitled.py', code: DEFAULT_CODE, analysis: { kind: S.analysis.kind } })],
      ['新建本地文件…', '', () => createLocalFile()],
      ['打开本地文件…', 'Ctrl+O', () => openLocalFile()],
      ['打开本地目录…', '', () => openLocalDirectory()],
      ['快速打开…', 'Ctrl+P', () => quickOpen()],
      ['保存（会话持久化）', 'Ctrl+S', () => saveCurrentFile()],
      '-',
      ['导出电路图 SVG', '', () => exportSvg()],
      ['导出报告 Markdown', 'Ctrl+Shift+R', () => exportReport()],
      ['下载当前代码', '', () => downloadCode()],
      '-',
      ['关闭当前标签', 'Ctrl+W', () => closeTab(S.activeTab)],
      ['关闭其他标签', '', () => closeOtherTabs()],
      ['关闭全部标签', '', () => closeAllTabs()],
    ],
  },
  {
    label: '编辑', items: [
      ['撤销', 'Ctrl+Z', () => fireEdKey('z', { ctrl: true })],
      ['重做', 'Ctrl+Y', () => fireEdKey('y', { ctrl: true })],
      '-',
      ['剪切', 'Ctrl+X', () => document.execCommand('cut')],
      ['复制', 'Ctrl+C', () => document.execCommand('copy')],
      ['粘贴', 'Ctrl+V', () => pasteIntoEditor()],
      ['全选', 'Ctrl+A', () => fireEdKey('a', { ctrl: true })],
      '-',
      ['查找 / 替换', 'Ctrl+F', () => openFind()],
      ['切换行注释', 'Ctrl+/', () => fireEdKey('/', { ctrl: true })],
      ['删除行', 'Ctrl+Shift+K', () => callEd('deleteLines')],
      ['上移行', 'Alt+↑', () => callEd('moveLines', -1)],
      ['下移行', 'Alt+↓', () => callEd('moveLines', 1)],
      ['复制当前行', 'Shift+Alt+↓', () => callEd('duplicateLines')],
    ],
  },
  {
    label: '视图', items: [
      ['命令面板…', 'Ctrl+Shift+P', () => showPalette()],
      ['切换侧边栏', 'Ctrl+B', () => toggleSidebar()],
      ['切换结果面板', 'Ctrl+J', () => togglePanel()],
      ['最大化结果面板', 'Esc 退出', () => togglePanelMax()],
      '-',
      ['放大字号', 'Ctrl+=', () => zoomFont(1)],
      ['缩小字号', 'Ctrl+-', () => zoomFont(-1)],
      ['重置字号', 'Ctrl+0', () => zoomFont(0)],
      ['自动换行', '', () => toggleWrap()],
    ],
  },
  {
    label: '转到', items: [
      ['转到行…', 'Ctrl+G', () => gotoLine()],
      ['转到文件…', 'Ctrl+P', () => quickOpen()],
      '-',
      ['问题列表', '', () => { panels.setActive('problems'); setSidebar('problems'); }],
      ['电路图', '', () => panels.setActive('schematic')],
      ['波形', '', () => panels.setActive('wave')],
      ['指标', '', () => panels.setActive('metrics')],
      ['工作点', '', () => panels.setActive('op')],
      ['网表', '', () => panels.setActive('netlist')],
      ['报告', '', () => panels.setActive('report')],
    ],
  },
  {
    label: '运行', items: [
      ['运行电路', 'Ctrl+Enter', () => run()],
      '-',
      ['分析：交流扫频', '', () => setAnalysisKind('ac')],
      ['分析：直流工作点', '', () => setAnalysisKind('op')],
      ['分析：瞬态', '', () => setAnalysisKind('tran')],
      ['分析：直流扫描', '', () => setAnalysisKind('dc')],
      '-',
      ['AI：生成电路', '', () => setSidebar('ai')],
      ['AI：修复当前电路', '', () => aiCall('fix')],
      ['AI：解释当前电路', '', () => aiCall('explain')],
    ],
  },
  {
    label: '帮助', items: [
      ['快捷键速查', '?', () => showKeys()],
      ['关于 CCL Studio', '', () => showAbout()],
    ],
  },
];

let openMenu = -1;

function wireMenubar() {
  const bar = $('#menubar');
  if (!bar) return;
  // 下拉要相对菜单栏绝对定位；CSS 由 style.css 提供，这里只兜底一次
  if (getComputedStyle(bar).position === 'static') bar.style.position = 'relative';
  bar.innerHTML = '';
  MENUS.forEach((m, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'mn-item';
    btn.textContent = m.label;
    btn.dataset.menu = String(i);
    btn.setAttribute('aria-haspopup', 'menu');
    btn.setAttribute('aria-expanded', 'false');
    btn.addEventListener('mousedown', (e) => { e.preventDefault(); e.stopPropagation(); toggleMenu(i); });
    btn.addEventListener('click', (e) => { if (e.detail === 0) toggleMenu(i, true); });
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault(); toggleMenu(i, true); focusMenuRow(0);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault(); toggleMenu((i + 1) % MENUS.length, true); focusMenuRow(0);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault(); toggleMenu((i - 1 + MENUS.length) % MENUS.length, true); focusMenuRow(0);
      }
    });
    btn.addEventListener('mouseenter', () => { if (openMenu >= 0 && openMenu !== i) toggleMenu(i); });
    bar.appendChild(btn);
  });
  // 点别处收起
  document.addEventListener('mousedown', (e) => {
    if (openMenu >= 0 && !e.target.closest('#menubar')) closeMenus();
  });
  // 菜单里点完动作，焦点还留在编辑器上体验更好
  bar.addEventListener('contextmenu', (e) => e.preventDefault());
}

function toggleMenu(i, force) {
  const bar = $('#menubar');
  if (!bar) return;
  if (openMenu === i && !force) { closeMenus(); return; }
  closeMenus();
  const m = MENUS[i];
  const btn = bar.querySelectorAll('.mn-item')[i];
  if (!m || !btn) return;
  btn.classList.add('on');
  btn.setAttribute('aria-expanded', 'true');

  const drop = document.createElement('div');
  drop.className = 'mn-drop';
  drop.setAttribute('role', 'menu');
  // 菜单内容：动作项与分隔线。用 mousedown 阻止默认，避免先触发 blur 再点空
  m.items.forEach((it) => {
    if (it[0] === '-') { const sep = document.createElement('div'); sep.className = 'mn-sep'; drop.appendChild(sep); return; }
    const [label, acc, run] = it;
    const row = document.createElement('div');
    row.className = 'mn-row';
    row.setAttribute('role', 'menuitem');
    row.tabIndex = 0;
    row.innerHTML = `<span>${esc(label)}</span>${acc ? `<span class="mn-acc">${esc(acc)}</span>` : ''}`;
    row.addEventListener('mousedown', (e) => e.preventDefault());
    row.addEventListener('click', (e) => {
      e.stopPropagation();
      closeMenus();
      try { run(); } catch (err) { console.warn('[menu]', label, err); }
    });
    row.addEventListener('keydown', (e) => {
      const rows = [...drop.querySelectorAll('.mn-row')];
      const n = rows.indexOf(row);
      if (e.key === 'ArrowDown') { e.preventDefault(); rows[Math.min(rows.length - 1, n + 1)]?.focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); rows[Math.max(0, n - 1)]?.focus(); }
      else if (e.key === 'Home') { e.preventDefault(); rows[0]?.focus(); }
      else if (e.key === 'End') { e.preventDefault(); rows[rows.length - 1]?.focus(); }
      else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); row.click(); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); toggleMenu((openMenu + 1) % MENUS.length, true); focusMenuRow(0); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); toggleMenu((openMenu - 1 + MENUS.length) % MENUS.length, true); focusMenuRow(0); }
    });
    drop.appendChild(row);
  });

  // fixed 定位：下拉面板始终贴标题栏按钮且不会被溢出裁切
  bar.appendChild(drop);
  const br = btn.getBoundingClientRect();
  const dw = drop.getBoundingClientRect().width || 200;
  const dh = drop.getBoundingClientRect().height || 260;
  const left = Math.max(4, Math.min(br.left, window.innerWidth - dw - 4));
  const top = br.bottom + 2 + dh <= window.innerHeight ? br.bottom + 2 : Math.max(4, br.top - dh - 2);
  drop.style.position = 'fixed';
  drop.style.left = Math.round(left) + 'px';
  drop.style.top = Math.round(top) + 'px';

  openMenu = i;
}

function focusMenuRow(index = 0) {
  const rows = [...document.querySelectorAll('#menubar .mn-row')];
  if (rows[index]) rows[index].focus();
}

function closeMenus() {
  const bar = $('#menubar');
  openMenu = -1;
  if (!bar) return;
  bar.querySelectorAll('.mn-drop').forEach((d) => d.remove());
  bar.querySelectorAll('.mn-item.on').forEach((b) => {
    b.classList.remove('on');
    b.setAttribute('aria-expanded', 'false');
  });
}

/* ---------------- 面包屑 ---------------- */

let _bcKey = '';

/** 面包屑：文件名 › 所在函数 › 当前行的元件调用。
 *  第三段对读电路代码最有用（一眼看出光标停在哪颗器件上）。
 *  @param {number} [line] 1-based 行号；不传就取编辑器当前行 */
function updateBreadcrumbs(line) {
  const box = $('#breadcrumbs');
  if (!box || !editor) return;
  const t = cur();
  if (!t) { box.innerHTML = ''; return; }
  const code = editor.getValue();
  const curLine = line || (editor.getCursor ? editor.getCursor().line : 1);
  // 光标每动一次都重算整篇太贵：行号 + 当前标签没变就直接复用
  const key = t.id + ':' + curLine + ':' + code.length;
  if (key === _bcKey) return;
  _bcKey = key;

  const lines = code.split('\n');
  const fn = enclosingDef(lines, curLine);
  const sym = symbolOnLine(lines[curLine - 1] || '');
  const parts = [`<span class="bc-item" data-k="file">${esc(t.title)}</span>`];
  if (fn) parts.push(`<span class="bc-sep">›</span><span class="bc-item" data-k="fn" data-line="${fn.line}">${esc(fn.name)}()</span>`);
  if (sym) parts.push(`<span class="bc-sep">›</span><span class="bc-item" data-k="sym">${esc(sym)}</span>`);
  parts.push(`<span class="bc-sep">›</span><span class="bc-item bc-dim">行 ${curLine}</span>`);
  box.innerHTML = parts.join('');
}

/** 光标所在行属于哪个 def（往上找最近的、缩进更小的 def） */
function enclosingDef(lines, line) {
  for (let i = Math.min(line, lines.length) - 1; i >= 0; i--) {
    const m = /^(\s*)def\s+([A-Za-z_]\w*)/.exec(lines[i] || '');
    if (m) return { name: m[2], line: i + 1, indent: m[1].length };
  }
  return null;
}

/** 一行里最有信息量的符号：优先 c.元件(...) 调用，退回到第一个标识符 */
function symbolOnLine(src) {
  const call = /\bc\.([A-Za-z_]\w*)\s*\(/.exec(src || '');
  if (call) return 'c.' + call[1] + '(…)';
  const id = /[A-Za-z_]\w{1,}/.exec((src || '').trim());
  return id ? id[0] : '';
}

/* ---------------- 编辑器胶水（子模块还没交付也不炸） ---------------- */

function edTextarea() { return document.querySelector('#editor-host textarea'); }

/** 给编辑器派发一次按键（用于菜单里的撤销/重做/注释切换：走编辑器自己的 undo 栈，
 *  不要另开一条路径，否则 Ctrl+Z 和菜单"撤销"会出现两套历史） */
function fireEdKey(key, { ctrl = false, shift = false, alt = false } = {}) {
  const ta = edTextarea();
  if (!ta) return;
  ta.focus();
  ta.dispatchEvent(new KeyboardEvent('keydown', {
    key, ctrlKey: ctrl, metaKey: ctrl, shiftKey: shift, altKey: alt, bubbles: true, cancelable: true,
  }));
}

/** 调用编辑器可选方法（desk-editor 交付后才存在，缺了静默跳过） */
function callEd(name, ...args) {
  if (!editor) return;
  if (typeof editor[name] === 'function') { editor[name](...args); return; }
  // 行操作没有 API 时，用键盘等价物兜底
  const fallback = { moveLines: null, duplicateLines: null, deleteLines: null };
  if (name in fallback) setStatus('该操作需要编辑器模块支持');
}

function openFind() {
  if (editor && editor.openFind) { editor.openFind(); return; }
  setStatus('查找面板需要编辑器模块支持');
}

async function pasteIntoEditor() {
  try {
    const text = await navigator.clipboard.readText();
    if (!text) return;
    if (editor && editor.insertText) editor.insertText(text);
    else { const ta = edTextarea(); if (ta) { ta.focus(); document.execCommand('insertText', false, text); } }
  } catch (e) {
    setStatus('剪贴板读取被浏览器拒绝（需授权）');
  }
}

function toggleSidebar() {
  document.body.classList.toggle('sb-collapsed');
  editor && editor.layout();
  save();
}

function togglePanel() {
  document.body.classList.toggle('panel-collapsed');
  editor && editor.layout();
  save();
}

function togglePanelMax() {
  if (panels && panels.isMaximized) { panels.maximize(!panels.isMaximized()); return; }
  document.body.classList.toggle('panel-max');
  editor && editor.layout();
  save();
}

function applyFontSize(px) {
  if (editor && editor.setFontSize) editor.setFontSize(px);
  else document.documentElement.style.setProperty('--fs', px + 'px');
}

function zoomFont(delta) {
  const base = ui.fontSize || (editor && editor.getFontSize ? editor.getFontSize() : 14);
  const px = delta === 0 ? 14 : Math.max(13, Math.min(24, base + delta));
  ui.fontSize = px;
  applyFontSize(px);
  setStatus('字号 ' + px + 'px');
  save();
}

function toggleWrap() {
  ui.wrap = !ui.wrap;
  if (editor && editor.setWrap) editor.setWrap(ui.wrap);
  setStatus('自动换行 ' + (ui.wrap ? '开' : '关'));
}

/* ---------------- VS Code 键位 ---------------- */

function wireKeys() {
  document.addEventListener('keydown', (e) => {
    const mod = e.ctrlKey || e.metaKey;
    const k = (e.key || '').toLowerCase();

    // Esc：按优先级逐个关浮层（菜单 → 右键菜单 → 最大化）
    if (e.key === 'Escape') {
      if (openMenu >= 0) { e.preventDefault(); closeMenus(); return; }
      if (closeCtxMenu()) { e.preventDefault(); return; }
      if (document.body.classList.contains('panel-max')) {
        e.preventDefault(); togglePanelMax(); return;
      }
      return;
    }

    if (!mod) {
      if (e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
        // Alt+↑↓：上移/下移当前行（VS Code 默认键位）
        if (document.activeElement && document.activeElement.closest('#editor-host')) {
          e.preventDefault(); callEd('moveLines', e.key === 'ArrowUp' ? -1 : 1);
        }
        return;
      }
      if (e.altKey && e.shiftKey && e.key === 'ArrowDown') {
        if (document.activeElement && document.activeElement.closest('#editor-host')) {
          e.preventDefault(); callEd('duplicateLines');
        }
        return;
      }
      // ? 打开快捷键速查。只在焦点不在编辑器/输入框里时生效 —— 代码里打 ? 是正常输入
      const typing = document.activeElement && document.activeElement.closest('#editor-host, input, textarea');
      if (e.key === '?' && !typing) { e.preventDefault(); showKeys(); }
      return;
    }

    // 下面都带 Ctrl/Cmd。编辑器自己处理的键（z/y//,/=/-/0）在 textarea 里优先，
    // 这里只在焦点不在编辑器时兜底，避免双触发。
    const inEditor = !!(document.activeElement && document.activeElement.closest('#editor-host'));

    if (e.shiftKey && k === 'k' && inEditor) { e.preventDefault(); callEd('deleteLines'); return; }
    if (e.shiftKey && k === 'r') { e.preventDefault(); exportReport(); return; }
    if (!e.shiftKey && k === 's') { e.preventDefault(); saveCurrentFile(); return; }
    if (!e.shiftKey && k === 'b') { e.preventDefault(); toggleSidebar(); return; }
    if (!e.shiftKey && k === 'j') { e.preventDefault(); togglePanel(); return; }
    if (!e.shiftKey && k === 'g') { e.preventDefault(); gotoLine(); return; }
    if (!e.shiftKey && k === 'w') { e.preventDefault(); closeTab(S.activeTab); return; }
    if (!e.shiftKey && k === 'n') { e.preventDefault(); openTab({ title: 'untitled.py', code: DEFAULT_CODE, analysis: { kind: S.analysis.kind } }); return; }
    if (!e.shiftKey && k === 'o') { e.preventDefault(); openLocalFile(); return; }
    // 查找归 editor.js 管（它自带浮层与命中高亮），只有它还没交付时才在这里兜底，
    // 否则同一次 Ctrl+F 会被两份监听器各开一次
    if (!e.shiftKey && k === 'f' && inEditor && !(editor && editor.openFind)) { e.preventDefault(); openFind(); return; }
    if (!e.shiftKey && (e.key === '=' || e.key === '+')) { e.preventDefault(); zoomFont(1); return; }
    if (!e.shiftKey && e.key === '-') { e.preventDefault(); zoomFont(-1); return; }
    if (!e.shiftKey && e.key === '0') { e.preventDefault(); zoomFont(0); return; }
  });
}

/* ---------------- 右键菜单 ---------------- */

function wireContextMenu() {
  const host = $('#editor-host');
  if (host) {
    host.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showCtxMenu(e.clientX, e.clientY);
    });
  }
  // desk-editor 交付后会派发这个事件（含命中信息）；两者都收着，重复调用是幂等的
  document.addEventListener('ccl:contextmenu', (e) => {
    const d = (e && e.detail) || {};
    showCtxMenu(d.x || 0, d.y || 0);
  });
  document.addEventListener('mousedown', (e) => {
    if (!e.target.closest('#ctx-menu')) closeCtxMenu();
  }, true);
  window.addEventListener('scroll', closeCtxMenu, true);
  // 面板最大化状态变化要落盘（panels.js 是事件源）
  document.addEventListener('ccl:panel-max', () => save());
}

function showCtxMenu(x, y) {
  closeCtxMenu();
  const items = [
    ['撤销', 'Ctrl+Z', () => fireEdKey('z', { ctrl: true })],
    ['重做', 'Ctrl+Y', () => fireEdKey('y', { ctrl: true })],
    '-',
    ['剪切', 'Ctrl+X', () => document.execCommand('cut')],
    ['复制', 'Ctrl+C', () => document.execCommand('copy')],
    ['粘贴', 'Ctrl+V', () => pasteIntoEditor()],
    '-',
    ['切换行注释', 'Ctrl+/', () => fireEdKey('/', { ctrl: true })],
    ['查找 / 替换', 'Ctrl+F', () => openFind()],
    ['删除行', 'Ctrl+Shift+K', () => callEd('deleteLines')],
    '-',
    ['转到行…', 'Ctrl+G', () => gotoLine()],
    ['运行电路', 'Ctrl+Enter', () => run()],
  ];
  const menu = document.createElement('div');
  menu.id = 'ctx-menu';
  menu.setAttribute('role', 'menu');
  items.forEach((it) => {
    if (it[0] === '-') { const s = document.createElement('div'); s.className = 'cx-sep'; menu.appendChild(s); return; }
    const [label, acc, fn] = it;
    const row = document.createElement('div');
    row.className = 'cx-item';
    row.setAttribute('role', 'menuitem');
    row.innerHTML = `<span>${esc(label)}</span>${acc ? `<span class="cx-acc">${esc(acc)}</span>` : ''}`;
    row.addEventListener('click', () => { closeCtxMenu(); try { fn(); } catch (err) { console.warn('[ctx]', label, err); } });
    menu.appendChild(row);
  });
  // 只写坐标（必须 JS 算）；配色圆角全在 style.css
  menu.style.position = 'fixed';
  menu.style.zIndex = '120';
  document.body.appendChild(menu);
  const r = menu.getBoundingClientRect();
  const left = Math.min(x, window.innerWidth - r.width - 6);
  const top = Math.min(y, window.innerHeight - r.height - 6);
  menu.style.left = Math.max(4, Math.round(left)) + 'px';
  menu.style.top = Math.max(4, Math.round(top)) + 'px';
}

function closeCtxMenu() {
  const m = document.getElementById('ctx-menu');
  if (!m) return false;
  m.remove();
  return true;
}

/* ---------------- 快速打开 / 转到行 / 快捷键表 ---------------- */

/** Ctrl+P：VS Code 的快速打开。列表 = 已打开标签 + 示例，选中即切换。 */
function quickOpen() {
  const opened = S.tabs.map((t) => ({
    id: 'tab-' + t.id,
    label: t.title,
    hint: t.id === S.activeTab ? '当前标签' : '已打开',
    run: () => { selectTab(t.id); renderTabs(); },
  }));
  const examples = S.examples.map((ex, i) => ({
    id: 'ex-' + i,
    label: ex.title,
    hint: '示例',
    run: () => openTab({ title: ex.title, code: ex.code, analysis: ex.analysis }),
  }));
  const local = S.localFiles.filter(e => e.kind === 'file').map((e, i) => ({
    id: 'local-' + i,
    label: e.path,
    hint: S.directoryHandle ? S.directoryHandle.name : '本地文件',
    run: () => openFileHandle(e.handle),
  }));
  openCommandPalette([...opened, ...local, ...examples], { placeholder: '按文件名搜索（标签 + 本地文件 + 示例）' });
}

/** Ctrl+G：转到行。用自建小浮层而不是 window.prompt —— prompt 会阻塞并且样式不可控。 */
function gotoLine() {
  if (!editor || document.getElementById('goto-box')) return;
  const total = editor.getValue().split('\n').length;
  const curLine = editor.getCursor ? editor.getCursor().line : 1;
  const box = document.createElement('div');
  box.id = 'goto-box';
  box.style.cssText = 'position:fixed;inset:0;display:flex;justify-content:center;align-items:flex-start;padding-top:12vh;z-index:130;background:rgba(0,0,0,.35)';
  box.innerHTML = `
    <div style="width:min(380px,90vw);background:#252526;border:1px solid #454545;border-radius:6px;box-shadow:0 8px 32px rgba(0,0,0,.6);padding:8px">
      <input id="goto-input" placeholder="行号 1 - ${total}" value="${curLine}"
        style="width:100%;height:28px;box-sizing:border-box;background:#3c3c3c;border:1px solid #0e639c;border-radius:3px;color:#cccccc;font-family:ui-monospace,Consolas,monospace;font-size:12px;padding:0 8px;outline:none">
      <div style="color:#8c8c8c;font-size:11px;margin-top:6px">Enter 跳转 · Esc 取消</div>
    </div>`;
  document.body.appendChild(box);
  const inp = box.querySelector('#goto-input');
  const close = () => box.remove();
  box.addEventListener('mousedown', (e) => { if (e.target === box) close(); });
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    if (e.key === 'Enter') {
      e.preventDefault();
      const n = Math.max(1, Math.min(total, parseInt(inp.value, 10) || 1));
      close();
      editor.goToLine(n);
    }
  });
  setTimeout(() => { inp.focus(); inp.select(); }, 0);
}

/** 快捷键速查（帮助 → 快捷键速查 / 按 ?） */
function showKeys() {
  const rows = [
    ['Ctrl+Enter', '运行电路'],
    ['Ctrl+Shift+P', '命令面板'],
    ['Ctrl+P', '快速打开文件'],
    ['Ctrl+B', '开合侧边栏'],
    ['Ctrl+J', '开合结果面板'],
    ['Ctrl+G', '转到行'],
    ['Ctrl+F', '查找 / 替换'],
    ['Ctrl+/', '切换行注释'],
    ['Ctrl+= / Ctrl+- / Ctrl+0', '缩放 / 重置字号'],
    ['Alt+↑ / Alt+↓', '上移 / 下移当前行'],
    ['Shift+Alt+↓', '向下复制当前行'],
    ['Ctrl+Shift+K', '删除当前行'],
    ['Ctrl+W', '关闭当前标签'],
    ['Ctrl+S', '保存到本地会话'],
    ['Esc', '关闭浮层 / 退出最大化'],
  ];
  openCommandPalette(rows.map(([k, v]) => ({ id: k, label: v, hint: k, run: () => {} })),
    { placeholder: '快捷键速查（Esc 关闭）' });
  // 速查表只读：把列表项的"点击执行"变成无操作，用户按 Esc 退出即可
}

function showAbout() {
  openCommandPalette([
    { id: 'about', label: 'CCL Studio — 电路代码 IDE（电路 → 网表 → 仿真 → 报告）', hint: 'v5', run: () => {} },
    { id: 'health', label: '后端：ngspice ' + ($('#stEngine') ? $('#stEngine').textContent.replace('ngspice ', '') : '?'), hint: '', run: () => {} },
  ], { placeholder: '关于（Esc 关闭）' });
}

/* ================= 杂项 ================= */
function markDirty(on) { const d = $('#dirtyDot'); if (d) d.hidden = !on; }
function setStatus(t) { $('#stStatus').textContent = t; }
function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
function updateOrientation() {
  const portrait = window.innerHeight > window.innerWidth;
  const hint = $('#orientationHint');
  if (hint) hint.hidden = !(portrait && window.innerWidth < 720);
  if (portrait && window.innerWidth < 720) document.body.classList.add('sb-collapsed');
}

const DEFAULT_CODE = `from ccl import Circuit, GND

def build():
    c = Circuit("rc_lowpass")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-9)
    c.expect("fc", "out", 1000, tol=0.05)
    return c
`;
