/* 插件宿主（前端）。
 *
 * 职责：
 *   1. 从 /api/plugins 拿到清单
 *   2. 逐个动态 import 插件的 ui.js（失败只影响该插件）
 *   3. 给插件一个**受限 API**：注册侧栏面板 / 注册命令 / 写日志
 *   4. 把注册结果交给主程序渲染
 *
 * 设计原则和项目一致：**插件写坏不许拖垮 IDE**。
 * 单个插件的 import 失败、activate 抛异常、注册重复 id，全部被隔离并记账。
 */

const state = {
  loaded: false,
  plugins: [],          // 清单 + 每个插件的结果
  panels: new Map(),    // id -> {icon, title, render, pluginId}
  commands: [],         // {id, label, hint, run, pluginId}
  errors: [],
};

function esc(t) {
  return String(t == null ? '' : t).replace(/[&<>"]/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/** 给单个插件的受限接口。插件拿不到任何主程序内部对象。 */
function makeAPI(pluginId) {
  const logs = [];
  const api = {
    pluginId,
    version: '1',
    log(msg) { logs.push(String(msg)); },

    registerSidebarPanel(def) {
      if (!def || !def.id || typeof def.render !== 'function') {
        throw new Error('registerSidebarPanel 需要 {id, render(box)}');
      }
      const key = 'plg:' + pluginId + ':' + def.id;
      if (state.panels.has(key)) throw new Error('面板 id 重复: ' + def.id);
      state.panels.set(key, {
        key,
        icon: def.icon || '🔌',
        title: def.title || def.id,
        render: def.render,
        pluginId,
      });
      logs.push('注册面板 ' + def.title);
    },

    registerCommand(def) {
      if (!def || !def.id || typeof def.run !== 'function') {
        throw new Error('registerCommand 需要 {id, run()}');
      }
      state.commands.push({
        id: 'plg:' + pluginId + ':' + def.id,
        label: def.label || def.id,
        hint: def.hint || '',
        run: def.run,
        pluginId,
      });
      logs.push('注册命令 ' + (def.label || def.id));
    },
  };
  Object.defineProperty(api, '_logs', { get: () => logs });
  return api;
}

export async function loadPlugins() {
  if (state.loaded) return state;
  state.loaded = true;

  let list = [];
  try {
    const r = await fetch('/api/plugins');
    const d = await r.json();
    list = d.plugins || [];
  } catch (e) {
    state.errors.push('拉取插件清单失败: ' + e.message);
    return state;
  }

  for (const p of list) {
    const rec = { ...p, uiStatus: '无 UI', activated: false };
    state.plugins.push(rec);
    if (!p.hasUI || !p.ok) continue;

    try {
      const url = `/plugins/${encodeURIComponent(p.id)}/${p.uiFile}`;
      const mod = await import(/* @vite-ignore */ url);
      if (typeof mod.activate !== 'function') {
        throw new Error('ui.js 必须 export function activate(api)');
      }
      const api = makeAPI(p.id);
      await mod.activate(api);
      rec.activated = true;
      rec.uiStatus = '已激活';
      rec.uiLog = api._logs.slice();
    } catch (e) {
      // 单个插件坏掉不影响其他插件和主程序
      rec.uiStatus = '激活失败';
      rec.uiError = (e && e.message) || String(e);
      state.errors.push(`[${p.id}] ${rec.uiError}`);
      console.error('[plugin]', p.id, e);
    }
  }
  return state;
}

export function getPlugins() { return state.plugins; }
export function getPanels() { return [...state.panels.values()]; }
export function getCommands() { return state.commands.slice(); }
export function getErrors() { return state.errors.slice(); }

/** 渲染插件面板到给定容器；找不到返回 false（让主程序走自己的分支）。 */
export function renderPanel(key, box) {
  const p = state.panels.get(key);
  if (!p) return false;
  try {
    p.render(box);
  } catch (e) {
    box.innerHTML = `<div style="padding:10px;color:#f14c4c;font-size:12px">
      插件「${esc(p.title)}」渲染失败：<br>${esc(e.message)}</div>`;
  }
  return true;
}

/** 插件管理页（宿主自带，便于排查）。 */
export function renderManager(box) {
  const rows = state.plugins.map(p => {
    const ok = p.ok !== false && (!p.hasUI || p.activated);
    const color = ok ? '#4ec9b0' : '#f14c4c';
    const detail = [];
    if (p.hasUI) detail.push('UI: ' + p.uiStatus);
    else detail.push('UI: 无');
    detail.push('后端: ' + (p.backend || '无'));
    if (p.error) detail.push('错误: ' + p.error);
    if (p.uiError) detail.push('UI 错误: ' + p.uiError);
    if ((p.uiLog || []).length) detail.push('UI 日志: ' + p.uiLog.join('；'));
    if ((p.log || []).length) detail.push('后端日志: ' + p.log.join('；'));
    return `<div style="padding:8px 0;border-bottom:1px solid var(--border)">
      <div style="display:flex;justify-content:space-between;gap:8px">
        <b style="color:${color}">${esc(p.name)}</b>
        <span style="color:var(--fg-dim)">v${esc(p.version)}</span>
      </div>
      <div style="color:var(--fg-dim);font-size:11px;margin-top:3px;line-height:1.55">
        <code style="color:var(--accent-2)">${esc(p.id)}</code><br>
        ${p.description ? esc(p.description) + '<br>' : ''}
        ${detail.map(esc).join('<br>')}
      </div></div>`;
  }).join('');

  box.innerHTML = `<div style="padding:8px">
    <details id="aiPlugin" style="margin-bottom:10px;border:1px solid var(--border);border-radius:4px">
      <summary style="cursor:pointer;padding:7px 8px;font-size:12px;color:var(--accent-2)">
        ✦ 用 AI 做一个插件
      </summary>
      <div style="padding:0 8px 8px;display:flex;flex-direction:column;gap:6px">
        <textarea id="aiPlgReq" rows="2" class="cfg-in" style="resize:vertical"
          placeholder="例：检查电容两端电压是否超过 25V，超了就提醒换高耐压型号"></textarea>
        <div style="display:flex;gap:6px">
          <button class="sb-btn sb-wide" id="btnAiPlg">让 AI 生成</button>
        </div>
        <div id="aiPlgMsg" class="sb-sub" style="line-height:1.6"></div>
        <div id="aiPlgOut"></div>
      </div>
    </details>
    <div class="sb-sub" style="line-height:1.6;margin-bottom:6px">
      插件放在 <code>plugins/&lt;id&gt;/</code>：<code>plugin.json</code> 是清单，
      <code>backend.py</code> 加检查规则/子电路块，<code>ui.js</code> 加面板/命令。
      <br>某个插件写坏只影响它自己。
    </div>
    ${rows || '<div class="sb-sub">没有发现插件</div>'}
    ${state.errors.length ? `<div style="margin-top:8px;color:#d7ba7d;font-size:11px">
        载入期错误：<br>${state.errors.map(esc).join('<br>')}</div>` : ''}
  </div>`;

  const btn = box.querySelector('#btnAiPlg');
  if (btn) btn.onclick = () => aiMakePlugin(box);
}

/* ---------------- AI 生成插件 ---------------- */

async function aiMakePlugin(box) {
  const reqEl = box.querySelector('#aiPlgReq');
  const msg = box.querySelector('#aiPlgMsg');
  const out = box.querySelector('#aiPlgOut');
  const btn = box.querySelector('#btnAiPlg');
  const request = (reqEl.value || '').trim();
  if (!request) { msg.innerHTML = '<span style="color:#d7ba7d">先写一句想要什么插件</span>'; return; }

  btn.disabled = true;
  out.innerHTML = '';
  const t0 = Date.now();
  const tick = setInterval(() => {
    msg.innerHTML = `<span style="color:var(--accent-2)">▸</span> 模型生成中… ${Math.round((Date.now() - t0) / 1000)}s`;
  }, 500);

  let d;
  try {
    const r = await fetch('/api/plugin/draft', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ request }),
    });
    d = await r.json();
  } catch (e) {
    clearInterval(tick); btn.disabled = false;
    msg.innerHTML = '<span style="color:#f14c4c">请求失败：' + esc(e.message) + '</span>';
    return;
  }
  clearInterval(tick);
  btn.disabled = false;

  const checks = (d.validation && d.validation.checks) || [];
  const pass = checks.filter(c => c.ok).length;

  if (!d.ok) {
    msg.innerHTML = `<span style="color:#f14c4c">✗ 没通过校验（${pass}/${checks.length}）</span>` +
      (d.error ? `<br><span style="color:#d7ba7d">${esc(d.error)}</span>` : '');
    out.innerHTML = renderChecks(checks);
    return;
  }

  msg.innerHTML = `<span style="color:#4ec9b0">✓ 已生成并通过全部校验（${pass}/${checks.length}，${(d.elapsed_ms / 1000).toFixed(0)}s）</span>` +
    `<br><b>${esc(d.name)}</b> <code style="color:var(--accent-2)">${esc(d.id)}</code>`;
  const pre = (txt, h) =>
    '<pre style="max-height:' + h + 'px;overflow:auto;background:#1e1e1e;' +
    'border:1px solid var(--border);border-radius:4px;padding:8px;font-size:10.5px;' +
    'line-height:1.5;white-space:pre-wrap">' + esc(txt) + '</pre>';
  const fold = (title, body) =>
    '<details style="margin-top:6px"><summary style="cursor:pointer;' +
    'color:var(--fg-dim);font-size:11.5px">' + title + '</summary>' + body + '</details>';

  let html = renderChecks(checks);
  html += fold('查看生成的代码（backend.py · ' + d.backend_py.length + ' 字符）',
               pre(d.backend_py, 220));
  if (d.ui_js) {
    html += fold('查看生成的代码（ui.js · ' + d.ui_js.length + ' 字符）',
                 pre(d.ui_js, 180));
  }
  html += '<div style="margin-top:8px;padding:7px 8px;background:rgba(215,186,125,.1);' +
    'border-left:2px solid #d7ba7d;border-radius:3px;font-size:11px;line-height:1.6;' +
    'color:#d7ba7d">⚠ 后端插件是能在本进程运行的 Python，没有沙箱。' +
    '安装前请确认上面的代码没有危险操作（读写文件 / 联网 / os.system）。</div>';
  out.innerHTML = html;

  const btnBox = document.createElement('div');
  btnBox.style.marginTop = '8px';
  const inst = document.createElement('button');
  inst.className = 'sb-btn sb-wide';
  inst.textContent = '✓ 安装并写入 plugins/';
  inst.onclick = () => installPlugin(d, inst, msg);
  btnBox.appendChild(inst);
  out.appendChild(btnBox);
}

function renderChecks(checks) {
  return '<div style="font-size:11px;line-height:1.65;margin-top:4px">' +
    checks.map(c => `<div style="color:${c.ok ? '#4ec9b0' : '#f14c4c'}">` +
      `${c.ok ? '✓' : '✕'} ${esc(c.name)}` +
      (c.detail ? `<span style="color:var(--fg-dim)">　${esc(String(c.detail).slice(0, 90))}</span>` : '') +
      '</div>').join('') + '</div>';
}

async function installPlugin(d, btn, msg) {
  btn.disabled = true;
  btn.textContent = '写入中…';
  try {
    const r = await fetch('/api/plugin/install', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: d.id, plugin_json: d.plugin_json,
        backend_py: d.backend_py, ui_js: d.ui_js,
      }),
    });
    const o = await r.json();
    if (!o.ok) {
      btn.disabled = false;
      btn.textContent = '✓ 安装并写入 plugins/';
      msg.innerHTML += `<br><span style="color:#f14c4c">安装失败：${esc(o.error)}</span>`;
      return;
    }
    btn.textContent = '✓ 已写入';
    msg.innerHTML += `<br><span style="color:#4ec9b0">已写入 plugins/${esc(o.id)}/（${(o.files || []).join(', ')}）</span>` +
      `<br><span style="color:#d7ba7d">后端规则需要重启服务才生效：在项目目录跑 bash start.sh；` +
      `前端面板刷新页面即可。</span>`;
  } catch (e) {
    btn.disabled = false;
    btn.textContent = '✓ 安装并写入 plugins/';
    msg.innerHTML += `<br><span style="color:#f14c4c">安装失败：${esc(e.message)}</span>`;
  }
}
