# CCL Studio — 桌面版对标 VS Code（Round 5）

## 相关契约（别处）

本文件是**桌面浏览器**视角的第五轮契约，视口与键位类问题以它为准。同层另有三份：

| 文件 | 权威范围 |
|---|---|
| `web/ide/CONTRACT.md` | 第一/二轮骨架：文件所有权、布局网格、模块签名（仍然有效） |
| `web/ide/CONTRACT_ROUND4.md` | 移动端实测缺陷清单（被本文件判作移动端视角，仅作历史依据） |
| **本文件（`CONTRACT_ROUND5_DESKTOP.md`）** | 桌面实测基线、头号 bug、与 VS Code 的键位/布局对齐 |
| `web/ide/CONTRACT_SCHEMATIC.md` | 电路图渲染模块（`schematic.js`）的权威 |

后端 / CCL 层的口径在 `ccl/CONTRACT.md`；实现现状与踩坑在 `docs/ARCHITECTURE.md` §6。

> **运行环境更正**：本项目**在电脑上用浏览器打开**（1280×800 / 1440×900 / 1920×1080），
> 不是在手机 App 里。上一版 `CONTRACT_ROUND4.md` 是移动端视角，**作废**，以本文为准。
> 目标：桌面浏览器里**看起来就是用 VS Code**，键位、布局、交互都对齐。

## 一、桌面实测基线（真实数据）

用 1440×900 / 1280×800 / 1920×1080 三个视口在 `/ide/` 里量出来的：

| 视口 | 编辑器 | 面板 | 可见行数 | 横向溢出 |
|---|---|---|---|---|
| 1280×800 | 992×408 | 992×260 | 20 | 无 |
| 1440×900 | 1152×508 | 1152×260 | 25 | 无 |
| 1920×1080 | 1632×688 | 1632×260 | 34 | 无 |

布局骨架本身是健康的：活动栏 48、状态栏 22、标题栏 40、侧栏 240，都与 VS Code 同量级。
**问题不在骨架，在细节和缺件。**

### 1.1 头号 Bug（已用 A/B 实验证实，1280×800）

```
修复前：#editor-toolbar  clientWidth 992 / scrollWidth 1336
        #segKind        宽 976（本该 ~219）
        #tbParams（f起 / f止 / 点per-dec 三个输入框）x=1280 → 完全在屏外
修复后：#editor-toolbar  clientWidth 992 / scrollWidth 992  ✓
        #segKind        宽 219
        #tbParams        x=523 ✓ 可见

注入的补丁（等价写法）：
  #segKind{width:auto;flex:0 0 auto}
  #segKind button{flex:0 0 auto;padding:0 10px;min-height:24px}
```

**根因**：`style.css:237` 的 `.seg{width:100%}` + `.seg button{flex:1 1 0}`
原本是给**侧栏**的分段控件写的，但编辑区顶部的 `#segKind` 复用了同一个 `.seg` 类，
于是 `width:100%` 把分段控件拉满整条工具条（976px），把分析参数挤出可视区。
桌面下要改分析参数（f起/f止/点数）**必须横向滚一个看不见的滚动条** —— 这是当前最痛的可用性问题。

### 1.2 其他实测瑕疵

| 位置 | 现象 | 数字 |
|---|---|---|
| `#tabs` | 标签被容器裁 4px（激活标签的顶部 1px 主题色条被切） | `#tabs` h=32，内部 `.tab` h=36 |
| `#panel-tabs` | 同上 | h=32 vs 内部 36 |

### 1.3 与 VS Code 的缺件（grep 全仓 0 命中）

| VS Code 有 | 本项目 | 影响 |
|---|---|---|
| 菜单栏 File/Edit/… | 无 | 第一眼就不像 VS Code |
| 面包屑（文件 › 符号） | 无 | 长文件里丢了位置感 |
| 查找/替换（Ctrl+F 浮层） | 无 | 桌面最常用操作缺失 |
| 小地图 minimap | 无 | 长文件无法快速定位 |
| Ctrl+P 快速打开 | 被命令面板占用 | 与 VS Code 键位冲突 |
| Ctrl+B / Ctrl+J 开合侧栏/面板 | 无 | 键位不熟的人第一下就卡 |
| Ctrl+= / Ctrl+- / Ctrl+滚轮 缩放 | 无 | 高分屏看不清代码 |
| Alt+↑↓ 移行、Shift+Alt+↑↓ 复制行、Ctrl+Shift+K 删行 | 无 | 重排代码只能剪切粘贴 |
| Ctrl+G 跳行 | 无 | 报错行号只能手拖 |
| 右键上下文菜单 | 无（`contextmenu` 0 命中） | 桌面右键没反应 |
| 面板最大化（双击 tab） | 只有电路图有全屏 | 波形只能挤在 260px 里 |
| 布局状态持久化 | 无（只存代码） | 每次刷新回到出厂布局 |

## 二、纪律（沿用原契约，不放松）

1. **纯原生**：不加 npm / CDN / 框架。ES module、SVG、Canvas 为主。
2. **单页不刷新**：模块自己管 DOM。
3. **只改自己名下的文件**，接口**只增不改**；已有的函数签名一个都不许动。
4. 每个文件改完必须 `node --check <file>` 通过。
5. 需求没写的，不要顺手重构。看到别人的文件有 bug，写进交付说明，别动。
6. 视觉统一用现有 token（`--bg` `--fg` `--accent` `--border` …），不要新造颜色。

## 三、文件归属与接口

### 我（Lead）改：`index.html` + `main.js`

只往 `index.html` 里加两个**空容器**，其余 DOM 全部由各模块自建：

```html
<!-- 标题栏内，logo 之后 -->
<nav id="menubar" aria-label="菜单栏"></nav>
<!-- #tabs 之后，#editor-toolbar 之前 -->
<div id="breadcrumbs" aria-label="面包屑"></div>
```

### desk-shell → `style.css`

必须提供的样式钩子（id/class 名字固定，JS 侧按这些名字生成 DOM）：

| 选择器 | 说明 |
|---|---|
| `#menubar` / `#menubar .mn-item` / `#menubar .mn-item.on` | 菜单栏按钮，高 24，hover 底 `#2a2d2e`，激活 `#094771` |
| `.mn-drop` | 下拉面板：`#252526` 底、1px `#454545` 边、圆角 5、阴影 `0 8px 24px rgba(0,0,0,.55)`、`padding:4px 0`、宽 ≥180 |
| `.mn-row` / `.mn-row:hover` / `.mn-sep` / `.mn-acc` | 下拉项：高 24、左内边距 22、快捷键文字右对齐 `--fg-dim` 11px、分隔线 1px |
| `#breadcrumbs` | 高 22、字号 12、`--fg-dim`、左右 padding 8、`overflow:hidden`、`white-space:nowrap` |
| `.bc-item` / `.bc-item:hover` / `.bc-sep` | 面包屑片段，hover 提亮为 `--fg`；分隔符 `›` 用 `--fg-dim` |
| `#minimap` | 绝对定位在 `#editor-host` 内右侧，宽 70，`pointer-events:auto`，底色略暗于编辑区 |
| `#findbar` | 编辑器内右上角浮层：宽 430、`#252526`、圆角 5、阴影、`z-index` 高于 `#minimap`、`padding:6px` |
| `#findbar input` / `#findbar button` / `#findbar .fb-count` | 输入框高 24（`#3c3c3c` 底、聚焦边框 `--accent`）；按钮 24×24 无边框；计数 11px `--fg-dim` |
| `#ctx-menu` / `.cx-item` / `.cx-item:hover` / `.cx-sep` / `.cx-acc` | 右键菜单：宽 ≥200、`#252526`、圆角 4、阴影、item 高 24、hover `#094771` |
| `body.panel-max` | `#main{grid-template-rows:0 0 1fr}`、`#editor-area,#splitter-h{display:none}`、**必须再加 `#panel{grid-row:3}`** |

> ⚠️ `body.panel-max` 这条配方**原稿是错的**，desk-shell 实测发现：两个子项 `display:none`
> 会从栅格项目列表里消失，`#panel` 于是被自动排进第 1 行（`0` 高），最大化后一片空白。
> 补 `body.panel-max #panel{grid-row:3}` 后实测面板高度 738 = `#main` 738。已修在 style.css 里。
| `#tabs` / `#panel-tabs` 高度一致 | 修掉 32 vs 36 的裁剪（容器高度或内部高度对齐，任选其一，别两边都改） |
| `@media (min-width:1280px)` | `--fs:14px`（VS Code 默认字号），`#panel-body` padding 更大 |
| `@media (min-width:1600px)` | `--sidebar-w:280px`、`--panel-h:300px` |

必须修的：1.1 的 `.seg` 溢出（顶部 `#segKind` 自适应宽，**侧栏 `.seg` 保持 100% 不变**）。

### desk-editor → `editor.js`

只增，不动现有签名。新增导出/方法：

```js
// EditorApi 新增
openFind(): void                 // 显示查找浮层并把焦点给输入框
closeFind(): void
setFontSize(px: number): void    // 13~24，改 pre 与 textarea 的 font-size/line-height，然后 layout()
getFontSize(): number
setWrap(on: boolean): void       // textarea wrap + pre white-space 同步
setMinimap(on: boolean): void    // 默认开启（宽 ≥1000 时）
moveLines(delta: 1|-1): void     // 上下移动选中行/当前行，保持选区
duplicateLines(): void
deleteLines(): void
getVisibleRange(): {from:number, to:number}   // 1-based 行号
revealPosition(pos: number): void             // 滚动到字符偏移处（findbar 用）
```

实现要点：

1. **查找替换浮层**：DOM 自建（`#findbar`），挂在编辑器 wrap 内。
   - `Ctrl+F` 打开、`Esc` 关闭、`Enter` 下一个、`Shift+Enter` 上一个。
   - 全部命中在装饰层画淡底（`#264f78` 60%），当前命中用更亮的框。
   - 计数显示 `3/17`；无命中标红。
   - 替换 / 全部替换走 `insertText` 或手动 undo 栈，**必须可撤销**。
2. **小地图**：`#editor-host` 内右侧 70px `<canvas>`。
   - 每行画一条缩进色块（按 `highlight()` 的 token 类别取色够用，纯色即可）。
   - 叠加当前视口框（`rgba(255,255,255,.08)`）。
   - 点击/拖动小地图 → 滚动到对应行。
   - 文本变化在现有 rAF 里重绘，**不要**每键事件直接重绘。
   - `devicePixelRatio` 缩放，别糊。
3. **字号缩放**：内部监听 `wheel`（`ctrlKey`）与 `Ctrl+=` / `Ctrl+-` / `Ctrl+0`，
   改字号后调用 `opts.onFontSize?.(px)` 让 main.js 持久化。
4. **右键**：`contextmenu` 事件 `preventDefault()`，并 `host.dispatchEvent(new CustomEvent('ccl:contextmenu', {detail:{x,y,hasSelection,line}, bubbles:true}))`。
5. **行操作**：`Alt+↑↓` / `Shift+Alt+↑↓` / `Ctrl+Shift+K` 在 textarea keydown 里处理，全部走 undo 栈。

### desk-panel → `panels.js`

只增：

```js
maximize(on: boolean): void
isMaximized(): boolean
```

1. **面板最大化**：`maximize(true)` 给 `document.body` 加 `panel-max`（样式由 shell 提供），
   并 `dispatchEvent(new CustomEvent('ccl:panel-max', {detail:{on}}))` 让 main.js 收状态。
   双击 `.ptab` 切换；最大化时面板内所有图按新高度重排（复用现有 `ResizeObserver`，别绕过）。
2. `setActive(id)` 里补 `tab.scrollIntoView({inline:'nearest'})`，保证激活的 tab 一定可见。
3. **波形 hover tooltip**：十字线已有，补一个跟随指针的数值气泡（显示节点名与精确值），
   指标与网表面板做 hover 行高亮。
4. 确认 PNG 导出可用（现有 `XMLSerializer` + `drawImage` 路径），没有就在面板右上角补按钮。

## 四、验收（Lead 用这个卡，全在 1280×800 与 1440×900 下量）

1. `#editor-toolbar` 的 `scrollWidth === clientWidth`（= 992 / 1152），三个分析参数输入框可见。
2. 菜单栏可见可点，下拉能开能关，`Esc` 与点外都能关。
3. 面包屑显示 `文件名 › 函数名`，点击文件名无副作用、hover 有反馈。
4. `Ctrl+F` 浮层出现，命中计数正确，替换可撤销；`Esc` 关闭后焦点回编辑器。
5. 小地图可见（右侧 ~70px），点击可跳转，滚动时视口框跟随。
6. `Ctrl+P` 打开快速文件列表（示例名 + 当前标签），选中即切换；`Ctrl+Shift+P` 仍是命令面板。
7. `Ctrl+B` 开合侧栏、`Ctrl+J` 开合面板、`Ctrl+G` 跳行、`Ctrl+=/-/0` 缩放字号、`Alt+↑↓` 移行，全部生效。
8. 编辑器内右键弹菜单，项可点（剪切/复制/粘贴走原生；其余走命令）。
9. 双击面板 tab 最大化，`Esc` 还原；再次双击回到原位。
10. 拖高面板 + 收起侧栏 + 改字号 + 最大化状态，刷新后全部还原。
11. 控制台 0 报错；`style.css` 无损（CSS 允许无 `node --check`，但必须自身闭合合法）、
    `editor.js` / `panels.js` / `main.js` 三个 `node --check` 全过。
12. 1280×800 下 `document.documentElement.scrollWidth === innerWidth`（无横向滚动）。

## 五、交付说明要求

每个模块交回时附：
- 改了哪些函数 / 新增了哪些导出（逐条）
- `node --check` 输出
- 有没有需要 Lead 在 `main.js` 里接的钩子（事件名、回调签名）
- 你发现但**没动**的别人的问题
