/* 启动画面。
 *
 * 设计原则：**不做假进度条。** 每一步都对应真正在执行的初始化动作，
 * 显示的是该步的真实耗时（ms）。如果整机太快（<0.6s），
 * 会保持 0.6s 再淡出——这是"避免闪一下"的最短展示时间，
 * 不是虚构的进度，页面里也会如实标注。
 */

const STEPS = [
  ['editor', '构建编辑器'],
  ['panels', '初始化面板'],
  ['chrome', '绑定界面与快捷键'],
  ['backend', '连接仿真后端'],
  ['plugins', '加载插件'],
  ['workspace', '恢复工作区'],
];

let el = null;
let listEl = null;
let barEl = null;
let noteEl = null;
const rows = new Map();     // id -> {wrap, icon, note}
let t0 = 0;
let finished = false;

function h(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

export function mount() {
  if (el) return;
  t0 = performance.now();

  el = h('div', null);
  el.id = 'boot';

  const card = h('div', 'boot-card');

  // 标识
  const logo = h('div', 'boot-logo');
  logo.innerHTML = '<span class="boot-mono">CCL</span><span class="boot-sub">Circuit Copilot</span>';

  const title = h('div', 'boot-title', '正在启动');
  const sub = h('div', 'boot-hint', '代码优先的电路设计工作台');

  // 进度条
  const barWrap = h('div', 'boot-bar');
  barEl = h('div', 'boot-bar-in');
  barWrap.appendChild(barEl);
  barEl.style.width = '0%';

  // 步骤列表
  listEl = h('div', 'boot-steps');
  for (const [id, label] of STEPS) {
    const wrap = h('div', 'boot-step');
    const icon = h('span', 'boot-ico', '·');
    const name = h('span', 'boot-name', label);
    const note = h('span', 'boot-note', '');
    wrap.appendChild(icon);
    wrap.appendChild(name);
    wrap.appendChild(note);
    listEl.appendChild(wrap);
    rows.set(id, { wrap, icon, note });
  }

  noteEl = h('div', 'boot-foot', '');

  card.appendChild(logo);
  card.appendChild(title);
  card.appendChild(sub);
  card.appendChild(barWrap);
  card.appendChild(listEl);
  card.appendChild(noteEl);
  el.appendChild(card);
  document.body.appendChild(el);

  // 安全兜底：启动画面绝不能变成"永远盖住应用"的一层。
  // 初始化若中途抛异常导致 finish() 没被调用，这里强制收场。
  const safety = setTimeout(() => {
    if (!finished) {
      console.warn('[boot] 超过 8s 未完成，强制收场（检查初始化异常）');
      try {
        if (noteEl) noteEl.textContent = '启动超时，已跳过（部分功能可能不可用）';
      } catch (_) {}
      setTimeout(() => { if (el) { el.remove(); el = null; } }, 900);
    }
  }, 8000);
  el._safety = safety;

  // 页面级错误也触发兜底：白屏比慢启动更糟
  window.addEventListener('error', () => {
    if (!finished && el) {
      clearTimeout(safety);
      el.classList.add('boot-out');
      setTimeout(() => { if (el) { el.remove(); el = null; } }, 320);
    }
  }, { once: true });

  // 让第一帧先画出来，避免"同步跑完才看到"
  return new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
}

function setBar() {
  const done = [...rows.values()].filter(r => r.wrap.dataset.state === 'ok').length;
  const pct = Math.round((done / STEPS.length) * 100);
  if (barEl) barEl.style.width = pct + '%';
}

/** 启动数据留档：window.__boot = {steps:[{id,label,ms,ok,err}], totalMs} */
const telemetry = [];

function begin(id) {
  const r = rows.get(id);
  if (!r) return;
  r.wrap.dataset.state = 'run';
  r.wrap.classList.add('is-run');
  r.icon.textContent = '';
  r.icon.classList.add('spin');
  r.wrap.scrollIntoView && r.wrap.scrollIntoView({ block: 'nearest' });
}

function done(id, ms, failed) {
  const r = rows.get(id);
  if (!r) return;
  r.wrap.classList.remove('is-run');
  r.icon.classList.remove('spin');
  r.wrap.dataset.state = failed ? 'err' : 'ok';
  r.icon.textContent = failed ? '✕' : '✓';
  r.note.textContent = failed ? (ms.err || '失败') : ms + ' ms';
  telemetry.push({
    id,
    label: STEPS.find(x => x[0] === id)?.[1] || id,
    ms: failed ? null : ms,
    ok: !failed,
    err: failed ? (ms.err || '失败') : '',
  });
  setBar();
}

/** 执行一步。fn 可以是同步或异步；抛异常只标记失败，不打断启动。 */
export async function step(id, fn) {
  if (!el) { return typeof fn === 'function' ? await fn() : fn; }
  begin(id);
  const s = performance.now();
  try {
    const v = typeof fn === 'function' ? await fn() : fn;
    done(id, Math.round(performance.now() - s), false);
    return v;
  } catch (e) {
    done(id, { err: (e && e.message) || String(e) }, true);
    console.warn('[boot] 步骤失败:', id, e);
    return undefined;
  }
}

/** 收尾：淡出并移除。整机过快时补到最短展示时间。 */
export async function finish() {
  if (!el || finished) return;
  finished = true;
  if (el && el._safety) clearTimeout(el._safety);

  const elapsed = performance.now() - t0;
  const MIN_MS = 620;                       // 最短展示时间，避免闪一下
  if (elapsed < MIN_MS) {
    await new Promise(r => setTimeout(r, MIN_MS - elapsed));
  }
  const real = Math.round(performance.now() - t0);
  if (noteEl) {
    noteEl.textContent = `启动完成 · 实际耗时 ${real} ms` +
      (real > MIN_MS ? '' : `（含 ${MIN_MS} ms 最短展示）`);
  }
  try {
    window.__boot = {
      steps: telemetry.slice(),
      totalMs: real,
      minHoldMs: MIN_MS,
    };
  } catch (_) { /* 诊断信息，写不进去也不影响启动 */ }

  el.classList.add('boot-out');
  await new Promise(r => setTimeout(r, 320));
  el.remove();
  el = null;
}

export function isMounted() { return !!el; }
