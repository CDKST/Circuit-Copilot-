/* ------------------------------------------------------------------
 * CCL Studio —— 只读电路图渲染（SVG 字符串）
 * 契约：web/ide/CONTRACT_SCHEMATIC.md
 *
 * 唯一导出：
 *   renderSchematic(circuit, opts) -> string   完整 <svg> 字符串
 *   schematicOrEmpty(circuit, opts) -> string  空电路时给空态提示（不含 <svg>）
 *   applyLive(svg, live) -> string             单点静态快照（导出 / 旧调用方）
 *
 * 开关（数据侧）：deriveSwitchStates({components, netlist, op, reported})
 *                     → 由本次仿真的节点电压 + 网表 Vt 推出每个开关的实际状态
 *                 switchSideEffects(der, components, intent)
 *                     → 共用控制节点导致「点一个、动两个」的连带影响（含推不出来的）
 *
 * 动画侧（时间序列驱动，契约 out/ANIM_CONTRACT.md 层 3）：
 *   applyLiveFrame(svgRoot, frame)  改属性、不重画：一帧的器件亮度 / 导线流动
 *   createPlayer({host, svg, timeline, ...})  时间轴播放条（没有 timeline 就不建）
 *
 * 设计约束：
 *   · 全部样式内联成 SVG 属性（因为要能导出独立 .svg 文件，拿不到页面 CSS）
 *   · 只用正交走线（水平 / 垂直），绝不画斜线连接
 *   · 连接关系必须永远正确：宁丑勿错
 *     —— 每个引脚只连到自己那一条网络母线，交点一律靠「实心圆点」标注，
 *        没有圆点的交叉就是「不连接」（电路图通用约定）
 *
 * 不依赖任何框架 / DOM（纯字符串拼接），可在 Node 里直接跑自测。
 * ------------------------------------------------------------------ */

const GND_NET = '0';
const FONT = 'ui-monospace, monospace';

/* ============================ 配色 ============================ */
/* 深色对齐 style.css 的 :root 变量风格 */
const THEMES = {
  dark: {
    wire: '#8c8c8c',   /* 走线 / 母线 */
    comp: '#d4d4d4',   /* 元件符号 */
    ref: '#9cdcfe',    /* 位号 */
    val: '#b5cea8',    /* 值 */
    dot: '#d4d4d4',    /* 节点圆点 */
    gnd: '#8c8c8c',    /* 地符号 */
    dim: '#6a7078',    /* 辅助小字 */
  },
  light: {
    wire: '#666a70',
    comp: '#2b3138',
    ref: '#0b5cad',
    val: '#0a7a2f',
    dot: '#2b3138',
    gnd: '#666a70',
    dim: '#8a9099',
  },
};

/* ============================ 布局常量 ============================ */
const L = {
  colGap: 128,     /* 相邻网络列间距 */
  lead: 16,        /* 元件本体到母线的引线长度（下限） */
  rowTop: 40,      /* 第一行的中心线 y */
  blockH: 100,     /* 三/四端器件占的纵向高度 */
  rowH: 42,        /* 两端横放元件占的纵向高度 */
  vGap: 26,        /* 行带到竖直带顶部的距离 */
  vBand: 84,       /* 竖直带高度（源 / 电容等悬挂元件） */
  marginL: 62,
  marginR: 42,
  marginT: 18,
  marginB: 40,
  maxValLen: 14,   /* 值文本最长字符数，超出截断 */
};

/* ============================ 小工具 ============================ */
function f(v) {
  // ⚑ 不能写 `if (!isFinite(v))`：`isFinite(null) === true`（null 被转成 0），
  // 于是「没有坐标」会被画到原点。统一先 Number() 再 Number.isFinite，
  // 数值与数字字符串的行为不变，null/undefined/NaN/Infinity 一律退化成 '0'。
  const n = Number(v);
  if (!Number.isFinite(n)) return '0';
  const r = Math.round(n * 10) / 10;
  return (r === 0 ? 0 : r).toString();
}

/** 取值：只在「真的是一个有限数」时返回数字，其余一律 null。
 *
 *  ⚑ 为什么必须专门有这么个函数：`isFinite(null) === true`（null 被隐式转成 0），
 *  于是后端明确给的 `null`（含义是「这个器件这一帧取不到数据」）会被当成 0A/0V
 *  参与亮度、功耗、归一化的计算 —— 「取不到就不画」的契约就断了。
 *  这里把 null / undefined / 空串 / NaN / ±Infinity 全部收敛成 null。 */
function numOrNull(v) {
  if (v == null || v === '') return null;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** 后端/前端的「开关」各种写法统一认：'S'、'SW'、'switch'、'SPST'… */
function isSwitchKind(k) {
  return /^(SW|SWITCH|SPST|SPDT|S)$/i.test(String(k == null ? '' : k).trim());
}

/** 值文本太长时压缩显示：OPA_100000_1p3e06 -> OPA 1.3e06 */
function shortValue(raw) {
  let s = String(raw == null ? '' : raw).replace(/\s+/g, ' ').trim();
  if (!s) return '';
  if (s.length <= L.maxValLen) return s;
  const parts = s.split('_');
  if (parts.length >= 3) {
    const head = parts[0];
    const tail = parts[parts.length - 1].replace(/p/gi, '.');
    const cand = head + ' ' + tail;
    if (/^[A-Za-z0-9.+\- ]+$/.test(cand) && cand.length <= L.maxValLen + 2) return cand;
  }
  if (parts.length >= 2 && parts[0].length <= 8) {
    const cand = parts[0] + ' ' + parts[1];
    if (cand.length <= L.maxValLen + 2) return cand;
  }
  return s.slice(0, L.maxValLen - 1) + '…';
}

/** 箭头三角（tip 在 (x1,y1)，从 (x0,y0) 指向 (x1,y1)） */
function arrowTri(x0, y0, x1, y1, size) {
  const dx = x1 - x0, dy = y1 - y0;
  const len = Math.hypot(dx, dy) || 1;
  const ux = dx / len, uy = dy / len;
  const px = -uy, py = ux;
  const bx = x1 - ux * size, by = y1 - uy * size;
  const w = size * 0.55;
  return [
    [x1, y1],
    [bx + px * w, by + py * w],
    [bx - px * w, by - py * w],
  ];
}

/* ============================ 画笔 ============================ */
/* 收集图元字符串，同时累积内容包围盒 */
function createPen() {
  const out = [];
  const bb = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };

  function grow(x, y, px, py) {
    px = px || 0; py = py || 0;
    if (!isFinite(x) || !isFinite(y)) return;
    if (x - px < bb.x0) bb.x0 = x - px;
    if (x + px > bb.x1) bb.x1 = x + px;
    if (y - py < bb.y0) bb.y0 = y - py;
    if (y + py > bb.y1) bb.y1 = y + py;
  }

  const pen = {
    out,
    bb,
    grow,
    raw(s) { out.push(s); },

    line(x1, y1, x2, y2, color, w, extra) {
      grow(x1, y1); grow(x2, y2);
      out.push('<line x1="' + f(x1) + '" y1="' + f(y1) + '" x2="' + f(x2)
        + '" y2="' + f(y2) + '" stroke="' + color + '" stroke-width="' + (w == null ? 1 : w)
        + '" stroke-linecap="round" fill="none"' + (extra || '') + '/>');
    },

    poly(pts, color, w) {
      const d = pts.map(p => { grow(p[0], p[1]); return f(p[0]) + ',' + f(p[1]); }).join(' ');
      out.push('<polyline points="' + d + '" fill="none" stroke="' + color
        + '" stroke-width="' + (w == null ? 1 : w) + '" stroke-linejoin="round" stroke-linecap="round"/>');
    },

    path(d, color, w, bboxPts) {
      if (bboxPts) for (const p of bboxPts) grow(p[0], p[1]);
      out.push('<path d="' + d + '" fill="none" stroke="' + color
        + '" stroke-width="' + (w == null ? 1 : w) + '" stroke-linejoin="round" stroke-linecap="round"/>');
    },

    rect(x, y, w, h, stroke, sw, fill) {
      grow(x, y); grow(x + w, y + h);
      out.push('<rect x="' + f(x) + '" y="' + f(y) + '" width="' + f(w) + '" height="' + f(h)
        + '" fill="' + (fill || 'none') + '" stroke="' + stroke
        + '" stroke-width="' + (sw == null ? 1.5 : sw) + '"/>');
    },

    circle(cx, cy, r, stroke, sw, fill) {
      grow(cx, cy, r + 1, r + 1);
      out.push('<circle cx="' + f(cx) + '" cy="' + f(cy) + '" r="' + f(r) + '" fill="'
        + (fill || 'none') + '" stroke="' + stroke + '" stroke-width="'
        + (sw == null ? 1.5 : sw) + '"/>');
    },

    dot(cx, cy, color) {
      grow(cx, cy, 3, 3);
      out.push('<circle cx="' + f(cx) + '" cy="' + f(cy) + '" r="2.6" fill="' + color
        + '" stroke="none" data-junction="1"/>');
    },

    polygon(pts, color, sw, fill) {
      pen.livePolygon(pts, color, sw, fill, '');
    },

    /* 带动画挂钩的 polygon / line：attrs 是额外内联属性串（如 data-led / data-sw-blade），
     * style 是内联样式串。动画层靠这些挂钩**只改属性**，从不重建元素。 */
    livePolygon(pts, color, sw, fill, attrs, style) {
      const d = pts.map(p => { grow(p[0], p[1]); return f(p[0]) + ',' + f(p[1]); }).join(' ');
      out.push('<polygon points="' + d + '" fill="' + (fill || 'none') + '" stroke="' + color
        + '" stroke-width="' + (sw == null ? 1.2 : sw) + '" stroke-linejoin="round"'
        + (attrs || '') + (style ? ' style="' + style + '"' : '') + '/>');
    },

    liveRect(x, y, w, h, attrs, style) {
      grow(x, y); grow(x + w, y + h);
      out.push('<rect x="' + f(x) + '" y="' + f(y) + '" width="' + f(w) + '" height="' + f(h)
        + '" fill="none" stroke="none"' + (attrs || '')
        + (style ? ' style="' + style + '"' : '') + '/>');
    },

    liveLine(x1, y1, x2, y2, color, w, attrs, style) {
      grow(x1, y1); grow(x2, y2);
      out.push('<line x1="' + f(x1) + '" y1="' + f(y1) + '" x2="' + f(x2)
        + '" y2="' + f(y2) + '" stroke="' + color + '" stroke-width="' + (w == null ? 1 : w)
        + '" stroke-linecap="round"' + (attrs || '')
        + (style ? ' style="' + style + '"' : '') + '/>');
    },

    liveText(x, y, str, color, size, anchor, weight, attrs) {
      pen.text(x, y, str, color, size, anchor, weight);
      if (!attrs) return;
      /* pen.text 已经 push 了一条 <text>，把属性插进去（在 '>' 前、紧贴标签）。
       * 不能放在 </text> 之前：那样属性会掉进 textContent 里，变成看得见的文字。 */
      const i = out.length - 1;
      const t = out[i];
      out[i] = t.replace(/^(<text\b[^>]*)>/, '$1' + attrs + '>');
    },

    text(x, y, str, color, size, anchor, weight) {
      const s = String(str == null ? '' : str);
      if (!s) return;
      const wpx = s.length * size * 0.62;
      let x0 = x, x1 = x;
      if (anchor === 'middle') { x0 = x - wpx / 2; x1 = x + wpx / 2; }
      else if (anchor === 'end') { x0 = x - wpx; }
      else { x1 = x + wpx; }
      bb.x0 = Math.min(bb.x0, x0);
      bb.x1 = Math.max(bb.x1, x1);
      bb.y0 = Math.min(bb.y0, y - size * 0.8);
      bb.y1 = Math.max(bb.y1, y + size * 0.3);
      out.push('<text x="' + f(x) + '" y="' + f(y) + '" fill="' + color
        + '" font-family="' + FONT + '" font-size="' + size + '"'
        + (anchor && anchor !== 'start' ? ' text-anchor="' + anchor + '"' : '')
        + (weight ? ' font-weight="' + weight + '"' : '')
        + '>' + esc(s) + '</text>');
    },
  };
  return pen;
}

/* ============================ 数据规范化 ============================ */
function normalizeComponents(circuit) {
  const raw = circuit && Array.isArray(circuit.components) ? circuit.components : [];
  const comps = [];
  for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (!c || typeof c !== 'object') continue;
    const pn = (c.pin_nodes && typeof c.pin_nodes === 'object') ? c.pin_nodes : {};
    const order = (Array.isArray(c.pins) && c.pins.length) ? c.pins.slice() : Object.keys(pn);
    const pins = [];
    for (const name of order) {
      const net = pn[name];
      if (net === undefined || net === null || net === '') continue;
      pins.push({ name: String(name), net: String(net) });
    }
    if (!pins.length) continue;
    const kindFull = String(c.kind == null ? '' : c.kind).trim();
    /* 后端给单字符（'R'）或全名（'res' / 'SW' / 'switch'）。
     * 以前只有单字符能对；'SW' 首字母是 S 也对，但 'switch' 会变成 S 之外的值，
     * 所以这里额外把"开关"的各种写法统一成 S —— 否则界面上点不了、也画不出触点。 */
    let kind = kindFull ? kindFull.charAt(0).toUpperCase() : '?';
    if (/^(SW|SWITCH|SPST|SPDT|S)$/i.test(kindFull)) kind = 'S';
    const vtext = c.value_text != null ? String(c.value_text)
      : (c.model != null ? String(c.model) : (c.value != null ? String(c.value) : ''));
    comps.push({
      ref: String(c.ref == null ? '?' : c.ref),
      kind,
      kindFull,
      pins,
      value: shortValue(vtext),
      valueRaw: vtext,
      model: c.model == null ? '' : String(c.model),
    });
  }
  return comps;
}

/* 器件端子的「信号流」角色：left 侧 -> right 侧 */
function pinRoles(c) {
  const idx = {};
  c.pins.forEach((p, i) => { if (idx[p.name] === undefined) idx[p.name] = i; });
  const n = c.pins.length;
  const pick = (name, dflt) => (idx[name] !== undefined ? idx[name] : dflt);
  switch (c.kind) {
    case 'X': {                       /* 运放：inp / inn -> out */
      const o = pick('out', n - 1);
      const left = [];
      for (let i = 0; i < n; i++) if (i !== o) left.push(i);
      return { left, right: [o] };
    }
    case 'Q': {                       /* 三极管：b -> c / e */
      const b = pick('b', n >= 3 ? 1 : 0);
      const right = [];
      for (let i = 0; i < n; i++) if (i !== b) right.push(i);
      return { left: [b], right };
    }
    case 'M': {                       /* MOSFET：g -> d / s / b */
      const g = pick('g', n >= 3 ? 1 : 0);
      const right = [];
      for (let i = 0; i < n; i++) if (i !== g) right.push(i);
      return { left: [g], right };
    }
    case 'D': {                       /* 二极管：a -> k */
      return { left: [pick('a', 0)], right: [pick('k', n - 1)] };
    }
    default: {
      if (n <= 2) return { left: [0], right: [Math.max(0, n - 1)] };
      const right = [];
      for (let i = 1; i < n; i++) right.push(i);
      return { left: [0], right };
    }
  }
}

/* ============================ 分层（rank）============================ */
function computeRanking(comps) {
  const nets = [];
  const seen = new Set();
  for (const c of comps) {
    for (const p of c.pins) {
      if (!seen.has(p.net)) { seen.add(p.net); nets.push(p.net); }
    }
  }
  const ranked = nets.filter(n => n !== GND_NET);
  const adj = new Map();
  for (const n of ranked) adj.set(n, new Set());

  const reaches = (a, b) => {
    if (a === b) return true;
    const st = [a];
    const vis = new Set([a]);
    while (st.length) {
      const x = st.pop();
      const vs = adj.get(x);
      if (!vs) continue;
      for (const y of vs) {
        if (y === b) return true;
        if (!vis.has(y)) { vis.add(y); st.push(y); }
      }
    }
    return false;
  };
  const addEdge = (u, v) => {
    if (u === v || !adj.has(u) || !adj.has(v)) return false;
    if (reaches(v, u)) return false;   /* 会成环就丢弃这条（反馈边） */
    adj.get(u).add(v);
    return true;
  };

  const strong = [];
  const weak = [];
  for (const c of comps) {
    const roles = pinRoles(c);
    const isStrong = (c.kind === 'X' || c.kind === 'Q' || c.kind === 'M' || c.kind === 'D');
    const bucket = isStrong ? strong : weak;
    for (const i of roles.left) {
      const a = c.pins[i];
      if (!a || a.net === GND_NET) continue;
      for (const j of roles.right) {
        const b = c.pins[j];
        if (!b || b.net === GND_NET) continue;
        bucket.push([a.net, b.net]);
      }
    }
  }
  for (const [u, v] of strong) addEdge(u, v);
  for (const [u, v] of weak) { if (!addEdge(u, v)) addEdge(v, u); }

  /* 最长路径分层（图已无环） */
  const preds = new Map();
  for (const n of ranked) preds.set(n, []);
  for (const [u, vs] of adj) for (const v of vs) preds.get(v).push(u);

  const memo = new Map();
  const rankOf = (n, stack) => {
    if (memo.has(n)) return memo.get(n);
    if (stack.has(n)) return 0;
    stack.add(n);
    let r = 0;
    const ps = preds.get(n) || [];
    for (const p of ps) r = Math.max(r, rankOf(p, stack) + 1);
    stack.delete(n);
    memo.set(n, r);
    return r;
  };
  for (const n of ranked) rankOf(n, new Set());

  /* 同 rank 内的次序：按「后继的最小 rank」排，源自然在最左 */
  const order = new Map();
  ranked.forEach((n, i) => order.set(n, i));
  const groups = new Map();
  for (const n of ranked) {
    const r = memo.get(n) || 0;
    if (!groups.has(r)) groups.set(r, []);
    groups.get(r).push(n);
  }
  const score = (n) => {
    let s = Infinity;
    for (const v of adj.get(n) || []) s = Math.min(s, memo.get(v) || 0);
    return isFinite(s) ? s : 1e6;
  };
  for (const arr of groups.values()) {
    arr.sort((a, b) => (score(a) - score(b)) || (order.get(a) - order.get(b)));
  }

  /* 每个网络独占一列，列 = 全局递增序号（层级有序 => 天然单调） */
  const colOf = new Map();
  let col = 0;
  const ranks = [...groups.keys()].sort((a, b) => a - b);
  for (const r of ranks) {
    for (const n of groups.get(r)) { colOf.set(n, col); col += 1; }
  }
  return { nets, ranked, rankOf: memo, colOf, rankCount: ranks.length };
}

/* ============================ 元件符号 ============================ */
/* 局部坐标 (u, w)：u 沿元件轴（+ 方向 = pin0 -> pin1），w 垂直于轴。
 * axis='h' 时 u 向右、axis='v' 时 u 向下；flip 负责极性方向。 */

function drawTwoPinBody(pen, kind, cx, cy, axis, flip, C, opts) {
  const HL = 22;
  const pt = (u, w) => (axis === 'h'
    ? [cx + flip * u, cy + w]
    : [cx + w, cy + flip * u]);
  const P = (u, w) => { const p = pt(u, w); return p; };
  const S = (u, w) => { const p = pt(u, w); pen.grow(p[0], p[1]); return f(p[0]) + ',' + f(p[1]); };
  const seg = (u1, w1, u2, w2, color, wid) => {
    const a = pt(u1, w1), b = pt(u2, w2);
    pen.line(a[0], a[1], b[0], b[1], color, wid);
  };

  const k = kind;
  if (k === 'R') {
    /* 矩形电阻：本体 40 × 16 */
    const a = pt(-20, -8), b = pt(20, 8);
    pen.rect(Math.min(a[0], b[0]), Math.min(a[1], b[1]),
      Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]), C.comp, 1.5, 'none');
    return;
  }
  if (k === 'C') {
    /* 两条极板 */
    seg(-5, -12, -5, 12, C.comp, 2.4);
    seg(5, -12, 5, 12, C.comp, 2.4);
    return;
  }
  if (k === 'L') {
    /* 4 个半圆弧 */
    const n = 4, span = (2 * HL) / n;
    let d = 'M ' + S(-HL, 0);
    const bbox = [];
    for (let i = 0; i < n; i++) {
      const u0 = -HL + i * span;
      d += ' Q ' + S(u0 + span / 2, -11) + ' ' + S(u0 + span, 0);
      bbox.push(P(u0, 0), P(u0 + span / 2, -11), P(u0 + span, 0));
    }
    pen.path(d, C.comp, 1.5, bbox);
    return;
  }
  if (k === 'V' || k === 'I') {
    const p = pt(0, 0);
    pen.circle(p[0], p[1], 14, C.comp, 1.5, 'none');
    if (k === 'V') {
      /* + 在 u<0（pin a 侧），− 在 u>0 */
      seg(-6, -4, -6, 4, C.comp, 1.4);
      seg(-10, 0, -2, 0, C.comp, 1.4);
      seg(2, 0, 10, 0, C.comp, 1.4);
    } else {
      /* 电流源：内部箭头 */
      seg(-7, 0, 7, 0, C.comp, 1.4);
      const t0 = pt(-7, 0), t1 = pt(7, 0);
      pen.polygon(arrowTri(t0[0], t0[1], t1[0], t1[1], 7), C.comp, 0.5, C.comp);
    }
    return;
  }
  if (k === 'D') {
    /* 三角形 + 阴极竖线；导通方向 a -> k（u 负 -> u 正）。
     * data-led 是动画层的挂钩：播放时直接给这个三角形染发光色（见 ledAt）。 */
    const t1 = pt(-11, -10), t2 = pt(-11, 10), t3 = pt(9, 0);
    pen.livePolygon([t1, t2, t3], C.comp, 1.2, C.comp, ' data-led="' + esc(k) + '"');
    seg(9, -11, 9, 11, C.comp, 2.2);
    return;
  }

  if (k === 'S') {
    /* 开关：左触点 → 刀闸 → 右触点。
     * 两种状态画的是**同一个** blade 元素（<line data-sw-blade>），
     * 开/合靠改它的 transform（-30° / 0°），这样播放时不会重建节点。 */
    seg(-14, 0, -8, 0, C.comp, 1.6);
    seg(8, 0, 14, 0, C.comp, 1.6);
    const d0 = pt(-8, 0), d1 = pt(8, 0);
    pen.liveLine(d0[0], d0[1], d1[0], d1[1], C.comp, 2,
      ' data-sw-blade="1"',
      'transform-origin:' + f(d0[0]) + 'px ' + f(d0[1]) + 'px');
    for (const u of [-8, 8]) {
      const c = pt(u, 0);
      pen.circle(c[0], c[1], 1.8, C.comp, 0, C.comp);
    }
    /* 透明命中矩形：符号本体只有 28×4，手指点不准。
     * 它**不画任何颜色**，只负责放大可点区域（样式见 style.css 的 [data-sw-hit]）。
     * 只有 SVG 模式下才加（导出成图片时它也是透明的，不影响观感）。 */
    if (opts && opts.switchHit !== false) {
      const h1 = pt(-20, -15), h2 = pt(20, 15);
      pen.liveRect(Math.min(h1[0], h2[0]), Math.min(h1[1], h2[1]),
        Math.abs(h2[0] - h1[0]), Math.abs(h2[1] - h1[1]), ' data-sw-hit="1"');
    }
    return;
  }
  /* 未知 kind：降级方框 */
  const a = pt(-20, -9), b = pt(20, 9);
  pen.rect(Math.min(a[0], b[0]), Math.min(a[1], b[1]),
    Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]), C.comp, 1.5, 'none');
  seg(-20, 0, -14, 0, C.comp, 1.2);
  seg(14, 0, 20, 0, C.comp, 1.2);
}

/* ======================= 工作态叠加（数据驱动） =======================
 * 每个器件的视觉状态都由**真实仿真数据**决定，不做装饰动画：
 *   二极管/LED  → 按实测电流决定发光亮度（对数映射，1µA 以下不亮）
 *   电阻        → 按实测功耗决定发热色（接近/超过额定功率才变红）
 *   电容/电感   → 按实测电流显示充放电强度
 *   三极管/MOS  → 按实测电流显示导通程度
 * 没有 live 数据（如交流分析）就完全不叠加——不假装有瞬时状态。
 * ========================================================================= */

/** 电流**幅值** → 0..1 的亮度。用对数刻度：1µA 起步，100mA 满亮。
 *
 *  ⚑ 必须取绝对值。瞬态电流本来就分正负（交流/正弦驱动的电路里一半取样点是负的）。
 *  早先这里是 `if (!(amp > 0)) return 0`，等于「只认正半周」：
 *  实测 5V/1kHz SIN + 100Ω + 1µF 的 RC（t_step=10µs, t_stop=1ms）里，
 *  C1 的 112 个取样点有 **51 个是负值**，|I| 峰值 **26.668mA**，
 *  但负半周那 51 帧的亮度全是 0 —— 屏幕上的效果就是「电流倒着走的时候整段熄灭」。
 *  幅值是「有多强」的量纲，方向另有用途（见 liveStyle 里 LED 的正向特例）。
 *
 *  @param {number|null} amp 有符号电流（A）。null/NaN/0 都返回 0（不亮）。 */
export function currentToLevel(amp) {
  const a = numOrNull(amp);
  if (a == null) return 0;
  const mag = Math.abs(a);
  if (!(mag > 0)) return 0;
  const lo = 1e-6, hi = 100e-3;
  const t = (Math.log10(mag) - Math.log10(lo)) / (Math.log10(hi) - Math.log10(lo));
  return Math.max(0, Math.min(1, t));
}

/** 按器件类型给它一个「工作色 + 光晕半径」；返回 null 表示不叠加。
 *  注意：UI 依赖 st.kind 区分「发光类」（有 t 就别再画静态圆，改由 LED 符号本身发亮）
 *  与「其它」两类，所以两个分支各带一个 kind 标签。 */
export function liveStyle(kind, item) {
  if (!item) return null;
  /* 取不到就是取不到：null 不许被当成 0 参与计算（`item.current || 0` 会静默做这件事）。
   * 电流类视觉（发光/充放电/导通）没有电流数据时整条不叠加。 */
  const I = numOrNull(item.current);
  const P = numOrNull(item.power);
  const k = String(kind || '').toUpperCase();
  if (k === 'D') {
    /* ⚑ 二极管 / LED 是**唯一**按有符号电流判亮的器件：反向只漏电、不发光。
     *  发光是正向注入载流子复合发光，反偏不发光（只有 nA 级漏电）；
     *  而 ngspice 的 `@d[i]` 符号约定正好是「阳极 → 阴极为正」（实测 5V/220Ω/LED
     *  正弦驱动：正向 19.406mA 为正、反向半周最小 -0.82µA），与图上箭头方向一致。
     *  用符号判亮还顺带挡住「反向击穿 / 齐纳区」那种大反向电流被画成灯亮。
     *  实测影响：这 26 个负值样本最大只有 0.82µA，本来就低于 1µA 的亮度门槛，
     *  所以对真实二极管「取幅值」与「取正半周」画面上没有区别 —— 但语义上只有
     *  「取正半周」是对的，所以这里按正半周判。
     *  注意数据来源的差别：`timeline.series[*].current` 是**带符号**的原始波形，
     *  而 `live.items[*].current`（后端 copilot/sim.branch_currents）已经取过
     *  abs()，恒 ≥ 0 —— 所以这条有符号判据实际只影响瞬态动画里的二极管。 */
    if (I == null || !(I > 0)) return null;
    const lv = currentToLevel(I);
    if (lv <= 0.02) return null;
    return { color: '#ff5533', glow: 3 + 9 * lv, opacity: 0.35 + 0.65 * lv, level: lv, kind: 'light' };
  }
  if (k === 'R') {
    // 以 0.25W 碳膜电阻为参照：超过 50% 额定才开始显色，超过 100% 变红。
    // 发热只看**幅值**（功率本来就取了绝对值）：反向电流一样发热，物理正确。
    if (P == null) return null;
    const lv = Math.min(1, P / 0.25);
    if (lv < 0.5) return null;
    return { color: lv >= 1 ? '#ff2d2d' : '#ff8c42', glow: 2 + 6 * lv, opacity: 0.5 + 0.5 * lv, level: lv, kind: 'glow' };
  }
  if (k === 'C' || k === 'L') {
    // 充放电强弱只看幅值：充电和放电都是「有电流在动」。
    const lv = currentToLevel(I);
    if (lv <= 0.02) return null;
    return { color: k === 'C' ? '#4fc1ff' : '#d7ba7d', glow: 2 + 5 * lv, opacity: 0.3 + 0.6 * lv, level: lv, kind: 'glow' };
  }
  if (k === 'Q' || k === 'M') {
    // 导通程度按幅值（反向电流同样意味着沟道在导通）。
    const lv = currentToLevel(I);
    if (lv <= 0.02) return null;
    return { color: '#6a9955', glow: 2 + 7 * lv, opacity: 0.35 + 0.65 * lv, level: lv, kind: 'glow' };
  }
  return null;
}

/** 给 SVG 里的每个器件组插入一层光晕（DOM 操作，不做字符串拼接）。
 *
 * 早先用 String.indexOf 拼字符串插入，实测一个都没插进去——因为 SVG 里有
 * 转义与嵌套，字符串定位很容易错位。改成直接操作 DOM：找到 g[data-ref]，
 * 读它的 data-x/data-y，再 insertAdjacentHTML 在组首插两个圆。
 *
 * 现在这条路径只负责**一个时间点的静态快照**（会话边角预览 / 导出 / 自检）。
 * 播放动画走的是 applyLiveFrame() —— 它不产生任何字符串，只改既有节点的属性。
 */
export function applyLive(svg, live) {
  if (!svg || !live || !live.items) return svg;
  if (typeof document === 'undefined') return svg;   // node 环境（自检脚本）直接跳过

  const host = document.createElement('div');
  host.innerHTML = svg;
  const root = host.querySelector('svg');
  if (!root) return svg;

  for (const [ref, item] of Object.entries(live.items)) {
    const st = liveStyle(item.kind, item);
    if (!st) continue;
    const g = root.querySelector('g[data-ref="' + cssRef(ref) + '"]');
    if (!g) continue;
    // 发光类（二极管/LED）直接点亮符号本身，而不是套一个光晕圆：
    // 早先这里写的是 `continue`（把发光交给动画帧的 ledAt()），结果**静态快照
    // 路径没人点亮它** —— 工作点分析下明明有 19mA，灯却是灰的（实测踩到）。
    if (st.kind === 'light') { ledAt(g, st); continue; }
    const cx = numOrNull(g.getAttribute('data-x'));
    const cy = numOrNull(g.getAttribute('data-y'));
    if (cx == null || cy == null) continue;
    // 两层同心圆：外层柔和光晕，内层亮一些。data-live 供测试与调试定位。
    g.insertAdjacentHTML('afterbegin',
      '<circle data-live="' + esc(ref) + '" cx="' + cx + '" cy="' + cy + '" r="' + st.glow.toFixed(1)
      + '" fill="' + st.color + '" opacity="' + (0.22 * st.opacity).toFixed(2) + '"/>'
      + '<circle cx="' + cx + '" cy="' + cy + '" r="' + (st.glow * 0.55).toFixed(1)
      + '" fill="' + st.color + '" opacity="' + (0.30 * st.opacity).toFixed(2) + '"/>');
  }
  return host.innerHTML;
}

/* ======================= 动画层（时间序列驱动） =======================
 * 契约：out/ANIM_CONTRACT.md 层 3。
 *
 * 与上面的静态叠加的区别只有一条：**从头到尾不重新渲染**。
 *   · SVG 字符串只在 run() 时生成一次
 *   · 每一帧只做两件事：改已存在的元素属性 + 写文本
 * 所以 200 个器件 × 60fps 也不会掉帧（没有 innerHTML、没有 querySelector 大范围搜索）。
 *
 * 铁律的工程化：时间序列取不到 → 对应器件这一帧保持「无数据」的原样，绝不补数。
 * ==================================================================== */

/** 位号 → 可用于 CSS 选择器的字符串（和旧版 applyLive 的清洗规则一致） */
function cssRef(ref) {
  return String(ref == null ? '' : ref).toUpperCase().replace(/[^A-Z0-9_]/g, '');
}

/** DOM 版光晕：按 level(0..1) 重新定位/改色/改透明度。
 *  不新建节点、不删节点，只写属性 —— 每帧都调用也不会造成重排抖动。
 *  entry 是 applyLiveFrame 里的元素缓存项（{g, ref, outer, inner}）。 */
function glowAt(entry, st) {
  const g = entry.g;
  if (!entry.outer) {
    const cx = g.getAttribute('data-x');
    const cy = g.getAttribute('data-y');
    if (cx == null || cy == null) return;
    const outer = document.createElementNS(SVGNS, 'circle');
    outer.setAttribute('data-glow', entry.ref);
    outer.setAttribute('cx', cx);
    outer.setAttribute('cy', cy);
    const inner = document.createElementNS(SVGNS, 'circle');
    inner.setAttribute('data-glow-inner', '1');
    // 光晕要垫在符号下面：插到组的第一个子节点之前
    g.insertBefore(outer, g.firstChild);
    g.insertBefore(inner, g.firstChild.nextSibling);
    entry.outer = outer;
    entry.inner = inner;
  }
  const a = entry.outer;
  a.setAttribute('r', st.glow.toFixed(1));
  a.setAttribute('fill', st.color);
  a.setAttribute('opacity', (0.22 * st.opacity).toFixed(2));
  const b = entry.inner;
  if (b) {
    b.setAttribute('cx', a.getAttribute('cx'));
    b.setAttribute('cy', a.getAttribute('cy'));
    b.setAttribute('r', (st.glow * 0.55).toFixed(1));
    b.setAttribute('fill', st.color);
    b.setAttribute('opacity', (0.30 * st.opacity).toFixed(2));
  }
}

/** LED / 二极管：让符号本身发亮 —— 填充发光 + 外发光滤镜 + 亮度。
 *  （纯光晕圆落在符号下面本来就要被实的三角遮住，看起来没有「灯亮」的差别，
 *    所以发光类的器件改成染符号。） */
/** 向上找到根 <svg>（避免依赖 document.documentElement 上的主题类） */
function svgRootOf(el) {
  let n = el;
  for (let guard = 0; n && guard < 40; guard++) {
    if (n.tagName && String(n.tagName).toLowerCase() === 'svg') return n;
    n = n.parentNode;
  }
  return null;
}

function ledAt(g, st) {
  const on = !!(st && st.level > 0.02);
  const kx = on ? (0.30 + 0.70 * st.level) : 0;
  // 关键帧只用一个 <feGaussianBlur>：比多层滤镜便宜，SVG 里也不会因缺 stdDeviation 报错
  g.setAttribute('style', on
    ? 'opacity:' + (0.6 + 0.4 * st.level).toFixed(2)
    : '');
  const body = g.querySelector('[data-led]');
  if (!body) return;
  if (on) {
    body.setAttribute('fill', st.color);
    body.setAttribute('fill-opacity', kx.toFixed(2));
    body.setAttribute('stroke', '#ffd0b0');
    body.setAttribute('stroke-width', (1.2 + 1.6 * st.level).toFixed(2));
    body.setAttribute('filter', 'url(#cclGlow)');
  } else {
    body.removeAttribute('fill-opacity');
    body.setAttribute('fill', 'none');
    body.setAttribute('stroke', '');
    body.removeAttribute('stroke');
    body.setAttribute('stroke-width', '1.2');
    body.removeAttribute('filter');
    // 恢复主题色（drawTwoPinBody 原本用 C.comp）。取深色主题的元件色：
    // 深色下 #d4d4d4、浅色下留空由 CSS 接管 —— 两种都能看清符号本身。
    const root = svgRootOf(body);
    const light = !!(root && root.getAttribute
      && /light/.test(String(root.getAttribute('data-theme') || '')));
    body.setAttribute('stroke', light ? THEMES.light.comp : THEMES.dark.comp);
  }
}

/** 开关：两种明确不同的图形 + 一眼能看出可点。 */
function switchAt(g, closed) {
  if (!g) return;
  g.setAttribute('data-sw', closed ? 'on' : 'off');
  const blade = g.querySelector('[data-sw-blade]');
  if (blade) blade.setAttribute('transform', closed ? 'rotate(0)' : 'rotate(-30)');
  const st = g.querySelector('[data-sw-state]');
  if (st) {
    st.textContent = closed ? '闭合' : '断开';
    st.setAttribute('fill', closed ? '#4ec9b0' : '#d7ba7d');
  }
}

/** 让电路图里的开关可点（**独立于播放器**）。
 *
 * 为什么要单独导出：早先这段逻辑写在 createPlayer 里，于是「只有瞬态分析
 *（有播放条）时开关才能点」—— 工作点分析下点开关完全没反应，用户会以为坏了。
 * 开关是电路的一部分，跟有没有动画无关。
 *
 * @param {Element} host            电路图容器
 * @param {object}  opts.switches   位号 → 是否闭合（Map）
 * @param {function} opts.onSwitch  (ref, closed) 回调（上层重跑仿真）
 * @returns {function}              解绑函数
 */
export function wireSwitchClicks(host, opts) {
  if (!host || typeof document === 'undefined') return () => {};
  const o = opts || {};
  const switches = o.switches instanceof Map ? o.switches : new Map();

  function onClick(e) {
    const g = e.target && e.target.closest ? e.target.closest('g[data-ref]') : null;
    if (!g || g.getAttribute('data-kind') !== 'S') return;
    const ref = g.getAttribute('data-ref');
    const next = g.getAttribute('data-sw') !== 'on';
    switches.set(ref, next);
    switchAt(g, next);                        // 立即视觉反馈
    if (typeof o.onSwitch === 'function') o.onSwitch(ref, next);
  }
  function onKey(e) {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const g = e.target && e.target.closest ? e.target.closest('g[data-ref][data-kind="S"]') : null;
    if (!g) return;
    e.preventDefault();
    onClick(e);
  }
  host.addEventListener('click', onClick);
  host.addEventListener('keydown', onKey);
  return () => {
    host.removeEventListener('click', onClick);
    host.removeEventListener('keydown', onKey);
  };
}

/* ============== 开关的「实际状态」：由后端这次真的给回来的数据推 ==============
 * 要解决的问题（实测，见 out/probe_shared_ctrl_api.py）：
 *   两个开关接在**同一个控制节点**上时，点 SW1 实际把两个都切了 —— 物理上完全正确，
 *   因为「开关」吃的是那个节点的电平。但后端只回报被请求的位号（`switch_states`
 *   只含 SW1），于是界面把 SW2 还画成原状态：画面与仿真结果不符，而且没有任何提示。
 *
 * 前端不许"猜"，所以状态只能从后端这次返回的数据里推：
 *   1) `analysis.op`（只有 op 分析有）给出**每个节点的电压**；开关的判据就是
 *      ngspice 的 `V(ctrl) > Vt`，而 Vt 就在后端网表的
 *      `.model <名字> SW(Ron=.. Roff=.. Vt=..)` 里，`S<ref> a b <ctrl> 0 <model>`
 *      又给出每个开关用哪条 model、控制节点是哪个。两个数都拿得到 → 状态是**算出来的**。
 *      实测：SW1/SW2 共用 ctrlc，点 SW1 断开后 op 里 V(ctrlc)=0.0、
 *      `.model ... Vt=2.5` → 0 > 2.5 为假 → SW2 确实也断开（与 V(m2)=0.0000V 一致）。
 *   2) tran / dc / ac 的 `analysis.op` 是 null，拿不到节点电压。此时只能退一步：
 *      **同一个控制节点 + 同一个 model（即同一 Vt）** 的两个开关看到的是同一个 V(ctrl)，
 *      必然同状态 —— 这是物理必然，不是估算。model 不同（阈值不同，例如被 Vt 路径
 *      强制过的那一个）就推不出来，返回「未知」。
 *   3) 后端 `switch_states` 回报过的位号（它确认强制生效了）作为该位号本身的可信来源。
 *
 * 推不出来就**没有条目**（不是 false，也不是沿用代码默认值）—— 调用方据此保持原样
 * 并在提示条里如实写「无法确认」，绝不编一个状态。
 * ------------------------------------------------------------------------- */
export function deriveSwitchStates(opts) {
  const o = opts || {};
  const states = new Map();   // 位号(大写) → true(闭合) / false(断开)
  const info = new Map();     // 位号(大写) → {how, ctrl, vt, vctrl, model, via}

  const comps = Array.isArray(o.components) ? o.components : [];
  const sws = [];
  for (const c of comps) {
    if (!c || c.ref == null) continue;
    if (!isSwitchKind(c.kind)) continue;      // 后端给的是 'SW'，别只认单字符 'S'
    const pn = c.pin_nodes && typeof c.pin_nodes === 'object' ? c.pin_nodes : {};
    sws.push({
      key: String(c.ref).toUpperCase(),
      ctrl: pn.ctrl == null ? null : String(pn.ctrl),
    });
  }
  if (!sws.length) return { states, info };

  /* ---- 网表：S 元件行（控制节点 + model 名）与 .model 的 Vt ---- */
  const vtOf = new Map();      // model 名 → Vt
  const modelOf = new Map();   // 位号(大写) → model 名
  const ctrlOf = new Map();    // 位号(大写) → 控制节点（网表写法）
  for (const raw of String(o.netlist || '').split('\n')) {
    const s = raw.trim();
    if (!s) continue;
    const mModel = /^\.model\s+(\S+)\s+sw\s*\(([^)]*)\)/i.exec(s);
    if (mModel) {
      const vt = /\bvt\s*=\s*([-+0-9.eE]+)/i.exec(mModel[2]);
      if (vt) { const n = numOrNull(vt[1]); if (n != null) vtOf.set(mModel[1], n); }
      continue;
    }
    /* `S<位号> <a> <b> <ctrl> 0 <model>`（SPICE 的开关实例，位号本身以 S 开头）。
     * ⚑ 名字要整段一起抓：`^s(\S+)` 只吃了 S 后面的部分（'SW1' → 'W1'），
     *   于是网表里的位号和电路表里的 'SW1' 永远对不上（实测踩到，推导全落空）。 */
    const mSw = /^(s\S*)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s*$/i.exec(s);
    if (mSw) {
      const ref = mSw[1].toUpperCase();
      modelOf.set(ref, mSw[6]);
      ctrlOf.set(ref, mSw[4]);
    }
  }

  /* ---- op 节点电压（节点名大小写不敏感地查；地恒为 0V） ---- */
  const op = o.op && typeof o.op === 'object' ? o.op : null;
  const opLower = new Map();
  if (op) for (const k of Object.keys(op)) opLower.set(String(k).toLowerCase(), op[k]);
  const vOf = (node) => {
    if (node == null) return null;
    if (/^(0|gnd)$/i.test(String(node))) return 0;
    if (!op) return null;
    const v = numOrNull(op[node]);
    return v != null ? v : numOrNull(opLower.get(String(node).toLowerCase()));
  };

  const reported = new Map();
  if (o.reported && typeof o.reported === 'object') {
    for (const [k, v] of Object.entries(o.reported)) {
      reported.set(String(k).toUpperCase(), /^(on|1|true|closed|close)$/i.test(String(v)));
    }
  }

  /* 1) 节点电压 + 网表阈值 → 本次仿真真正用的状态 */
  for (const sw of sws) {
    const model = modelOf.get(sw.key) || null;
    const vt = model && vtOf.has(model) ? vtOf.get(model) : null;
    const ctrl = ctrlOf.get(sw.key) || sw.ctrl;
    if (vt == null) continue;
    const v = vOf(ctrl);
    if (v == null) continue;
    states.set(sw.key, v > vt);
    info.set(sw.key, { how: 'sim', ctrl, vt, vctrl: v, model });
  }

  /* 2) 后端回报过的位号（它确认把状态强制生效了） */
  for (const sw of sws) {
    if (states.has(sw.key) || !reported.has(sw.key)) continue;
    states.set(sw.key, reported.get(sw.key));
    info.set(sw.key, { how: 'reported' });
  }

  /* 3) 同控制节点 + 同 model → 物理上必然同状态（多轮，容许链式传播） */
  for (let guard = 0; guard < 8; guard++) {
    let changed = false;
    for (const sw of sws) {
      if (states.has(sw.key)) continue;
      const model = modelOf.get(sw.key) || null;
      const ctrl = ctrlOf.get(sw.key) || sw.ctrl;
      if (!model || ctrl == null) continue;
      for (const other of sws) {
        if (other.key === sw.key || !states.has(other.key)) continue;
        const octrl = ctrlOf.get(other.key) || other.ctrl;
        const omodel = modelOf.get(other.key) || null;
        if (String(octrl) !== String(ctrl) || omodel !== model) continue;
        states.set(sw.key, states.get(other.key));
        info.set(sw.key, { how: 'shared', via: other.key, ctrl, model });
        changed = true;
        break;
      }
    }
    if (!changed) break;
  }

  return { states, info };
}

/** 共用控制节点带来的**连带影响**：哪些开关不是用户点的、却也会跟着动（或推不出来）。
 *
 * 这条规则单独提出来（而不是塞在 main.js 里）有两个理由：
 *   · 它是**物理结论**，不是文案：同一控制节点上的两个开关看到同一个 V(ctrl)，
 *     所以「点 SW1 会不会连 SW2 一起变」是可判定的；
 *   · 可以脱离 DOM 直接自测（out/test_ide_fixes.mjs）。
 * 文案由调用方决定（main.js 组装提示条），这里只给事实。
 *
 * @param {{states:Map, info:Map}} der   deriveSwitchStates 的返回值
 * @param {Array}  comps                 后端器件表（要 pin_nodes.ctrl）
 * @param {object} intent                本标签页的用户覆盖 {位号(大写): true/false}
 * @returns {Array<{ref:string, kind:'shared'|'unknown', state?:boolean, via:string, ctrl:string}>}
 */
export function switchSideEffects(der, comps, intent) {
  const out = [];
  if (!der || !der.info) return out;
  const want = intent && typeof intent === 'object' ? intent : {};

  const ctrlOf = new Map();     // 位号(大写) → 控制节点
  for (const c of (Array.isArray(comps) ? comps : [])) {
    if (!c || c.ref == null || !isSwitchKind(c.kind)) continue;
    const pn = c.pin_nodes && typeof c.pin_nodes === 'object' ? c.pin_nodes : {};
    if (pn.ctrl != null) ctrlOf.set(String(c.ref).toUpperCase(), String(pn.ctrl));
  }

  /* 一个开关算「连带」的充分条件：**不是**用户点的那个，但和某个用户点的开关
   * 共用同一个控制节点。它到底变成什么，要么有结论（states 里有），要么明说不知道。 */
  const listed = new Set();
  for (const ref of Object.keys(want).sort()) {
    const ctrl = ctrlOf.get(ref);
    if (ctrl == null) continue;
    for (const [other, octrl] of ctrlOf) {
      if (other === ref || want[other] !== undefined || listed.has(other)) continue;
      if (String(octrl) !== String(ctrl)) continue;
      listed.add(other);
      if (der.states.has(other)) {
        out.push({ ref: other, kind: 'shared', state: !!der.states.get(other), via: ref, ctrl });
      } else {
        out.push({ ref: other, kind: 'unknown', via: ref, ctrl });
      }
    }
  }
  return out;
}

/** 把一条导线（line）变成等价的 path d。
 *  用 <path> 而不是继续用 <line>：路径才能表达"一条网络的多段连线"，
 *  流动虚线在接缝处才不会断掉（见 ensureFlow 的聚合逻辑）。 */
function pathOf(line) {
  if (!line || !line.getAttribute) return null;
  const x1 = numOrNull(line.getAttribute('x1'));
  const y1 = numOrNull(line.getAttribute('y1'));
  const x2 = numOrNull(line.getAttribute('x2'));
  const y2 = numOrNull(line.getAttribute('y2'));
  if (x1 == null || y1 == null || x2 == null || y2 == null) return null;
  if (Math.abs(x1 - x2) < 0.01 && Math.abs(y1 - y2) < 0.01) return null;  // 零长线
  return 'M ' + f(x1) + ' ' + f(y1) + ' L ' + f(x2) + ' ' + f(y2);
}

/** 导线：给每条导线补一条「电流叠加层」（只做一次，之后只改属性）。
 *
 *  按网络聚合：真电路里一根母线常被拆成很多段（每个器件一段引线），
 *  逐段各自跑虚线会在接缝处断开，看着像「电流在跳」。这里把同一网络的
 *  所有线段并进一条 <path>，一次 dashoffset 就贯穿整根母线。
 */
function ensureFlow(root) {
  if (!root || !root.querySelector) return null;
  const done = root.querySelector('[data-role="flow"]');
  if (done) return done;
  const wires = root.querySelector('[data-role="wires"]');
  if (!wires) return null;
  const layer = document.createElementNS(SVGNS, 'g');
  layer.setAttribute('data-role', 'flow');

  const perNet = new Map();                    /* net -> [line 元素, ...] */
  const kids = [...wires.childNodes];
  for (const ch of kids) {
    if (!ch || ch.nodeType !== 1) continue;
    const net = ch.getAttribute('data-net');
    if (net == null) continue;                 // 节点圆点 / 其它图元不带 data-net
    if (String(ch.tagName).toLowerCase() !== 'line') continue;
    if (!perNet.has(net)) perNet.set(net, []);
    perNet.get(net).push(ch);
  }

  for (const [net, lines] of perNet) {
    const parts = [];
    for (const ln of lines) { const p = pathOf(ln); if (p) parts.push(p); }
    if (!parts.length) continue;               // 取不到端点就不画这一路（不编图形）
    const el = document.createElementNS(SVGNS, 'path');
    el.setAttribute('d', parts.join(' '));
    el.setAttribute('data-flow', net);
    el.setAttribute('stroke', '#3fe0ff');
    el.setAttribute('opacity', '0');           // 没有数据时完全看不见
    el.setAttribute('stroke-width', '2');
    el.setAttribute('stroke-dasharray', '5 13');
    el.setAttribute('fill', 'none');
    el.setAttribute('stroke-linecap', 'round');
    layer.appendChild(el);
  }
  wires.parentNode.insertBefore(layer, wires.nextSibling);
  return layer;
}

/** 网络电流强度 → 注入到 SVG 样式表里的「流动强度」档位类。
 *  CSS 侧用 classes["f4"] .f4{...} 拼规则即可，这里只输出最终字符串。 */
function flowClasses(n) {
  let out = '';
  for (let i = 1; i <= n; i++) {
    out += '.ccl-flow-svg .f' + i + '{--fi:' + (i / n).toFixed(3) + '}';
  }
  return out;
}

const SVGNS = 'http://www.w3.org/2000/svg';
let _flowSheet = null;

/** 把「帧强度 → CSS 常量」用的样式表塞进 SVG（或文档）一次。
 *  为什么用 CSS 变量：每帧要给几十条导线设 width/opacity，
 *  写成 style.setProperty 是 N 次字符串解析；写成 class 切换是 N 次属性写，
 *  但真正的数值仍然要落到具体像素上 —— 所以档位化(6 档)是性价比最高的做法：
 *  帧内只改 className，数值全部由 CSS 常量提供。 */
function ensureFlowSheet() {
  if (_flowSheet) return _flowSheet;
  const css = flowClasses(6)
    + '.ccl-flow-svg [data-flow]{transition:none}';
  if (typeof document === 'undefined') { _flowSheet = css; return css; }
  const st = document.createElement('style');
  st.setAttribute('data-ccl', 'flow');
  st.textContent = css
    // 笔画粗细 / 不透明度 / 虚线节奏全部由 --fi 决定，帧内切换 class 即生效
    + '.ccl-flow-svg [data-flow]{'
    + '  stroke-width:calc(1.2px + 2.6px * var(--fi,0));'
    + '  opacity:calc(var(--fi,0));'
    + '  animation:cclDash calc(1.6s - 1.15s * var(--fi,0)) linear infinite;'
    + '}'
    + '@keyframes cclDash{from{stroke-dashoffset:0}to{stroke-dashoffset:-18}}';
  document.head.appendChild(st);
  _flowSheet = st;
  return st;
}

/** 电流序列归一化：用**整条序列的峰值**做量纲，这样同一段动画里
 *  强弱比例是真的（不会因为某一帧是主峰就把别的帧都压成看不见）。
 *  单一器件内自比，不与其它器件比 —— 否则一个大电流支路会让所有小支路消失。 */
function seriesPeak(arr) {
  let m = 0;
  if (!arr || !arr.length) return 0;
  for (let i = 0; i < arr.length; i++) {
    // null（后端说这一帧取不到）不能算成 0 参与取峰值，但也不能让峰值变成 NaN
    const v = numOrNull(arr[i]);
    if (v == null) continue;
    const a = Math.abs(v);
    if (a > m) m = a;
  }
  return m;
}

/** 时间序列索引：ref/位号 → {peak, arr}。**只收真实数据**。 */
export function timelineIndex(timeline) {
  const out = { refs: new Map(), t: [], dt: 0 };
  if (!timeline || typeof timeline !== 'object') return out;
  const t = Array.isArray(timeline.t) ? timeline.t : null;
  const series = timeline.series && typeof timeline.series === 'object' ? timeline.series : null;
  if (!t || !t.length || !series) return out;
  out.t = t;
  out.dt = Number(timeline.dt) || 0;
  for (const [ref, ser] of Object.entries(series)) {
    if (!ser || typeof ser !== 'object') continue;
    const cur = Array.isArray(ser.current) ? ser.current : null;
    const volt = Array.isArray(ser.voltage) ? ser.voltage : null;
    if (!cur && !volt) continue;
    const peakI = cur ? seriesPeak(cur) : 0;
    const peakV = volt ? seriesPeak(volt) : 0;
    out.refs.set(String(ref).toUpperCase(), {
      current: cur, voltage: volt, peakI, peakV,
      kind: String(ser.kind || '').toUpperCase(),
    });
  }
  return out;
}

/** 一帧的器件状态：ref → {current, power, kind}。
 *  取不到的字段一律 null —— 下游看见 null 就不画，绝不填 0。 */
export function frameState(idx, i, kinds) {
  const st = new Map();
  if (!idx || !idx.refs || !idx.refs.size) return st;
  const n = idx.t.length;
  const k = Math.max(0, Math.min(n - 1, Math.floor(i)));
  for (const [ref, ser] of idx.refs) {
    /* ⚑ 这里曾经写 `isFinite(ser.current[k])` —— `isFinite(null) === true`，
     * 于是后端明确给的 null（=「这个器件这一帧取不到」）被当成 **0A**：
     * 该器件会被画成「有数据但电流为 0」，而不是「没有数据所以不画」。
     * 全部改走 numOrNull()：null/undefined/''/NaN/±Infinity 一律 null。 */
    const cur = ser.current ? numOrNull(ser.current[k]) : null;
    const vRaw = ser.voltage ? numOrNull(ser.voltage[k]) : null;
    const volt = vRaw == null ? null : Math.abs(vRaw);
    let power = null;
    let kind = ser.kind || '';
    if (kinds && kinds[ref]) kind = String(kinds[ref]).toUpperCase() || kind;
    /* 功耗 = |V·I|：V 与 I 取的是同一器件同一时刻的实测值，不是 I²R 反推。
     * 缺电压就是 null（不拿额定值去凑一个功率出来）。 */
    if (cur !== null && volt !== null) power = Math.abs(cur * volt);
    st.set(ref, { current: cur, power, kind });
  }
  return st;
}

/** 解析 SVG 上的 data-flow-nets：net → [[ref, ±1], ...]（+1 = 该器件把电流注入本网络）。 */
export function parseFlowNets(svgRoot) {
  const out = new Map();
  if (!svgRoot || !svgRoot.getAttribute) return out;
  const raw = svgRoot.getAttribute('data-flow-nets') || '';
  for (const chunk of raw.split(' ')) {
    if (!chunk) continue;
    const i = chunk.indexOf('|');
    if (i < 0) continue;
    const net = chunk.slice(0, i);
    const list = [];
    const body = chunk.slice(i + 1);
    if (body) {
      for (const tok of body.split(';')) {
        const j = tok.lastIndexOf(':');
        if (j < 0) continue;
        const v = Number(tok.slice(j + 1));
        if (v !== 1 && v !== -1) continue;
        list.push([tok.slice(0, j), v]);
      }
    }
    if (list.length) out.set(net, list);
  }
  return out;
}

/** 一个网络在这条时间序列上的电流（安培，带符号：+ = 沿该导线自身的正方向）。
 *
 *  依据：该网络所有关联器件端点的净流出一律为 0（基尔霍夫电流定律），所以
 *  「净从端点流进网络」的量就等价于「这个网络往外送出去的电流」。
 *  网络里只要有一个端点没数据（如某个支路没有 @dev[i]），整个网络就返回 null ——
 *  少一个支路算出来的电流是错的，宁可这条导线这一帧不亮，也不画一个错的数。
 */
export function netCurrentSeries(entry, idx, net, tCount) {
  const list = entry || [];
  if (!list.length || !idx || !idx.refs) return null;

  /* ⚑ 这里**绝对不能把所有支路电流加起来**：
   * 一个网络上的器件电流之和就是 KCL 残差，而正确解里它恒等于 0。
   * 实测（修复前）：5V/220Ω/LED 电路里支路电流 19.41mA，
   * 但按「求和」得到的网络基准是 2.84e-7 A（纯数值噪声，还被归一化成满亮），
   * 另两个电路里内部网络的峰值正好 0.0 → 被 `peak<=0` 丢弃 → **一条导线都不流动**。
   * 也就是说「电流沿导线流动」这个功能事实上是空的。
   *
   * 正确做法：一条导线代表一个网络的一段，它的电流就是**某一条支路**的电流，
   * 不是各支路之和。这里取本网络上电流绝对值最大的那条支路（串联元件电流相同，
   * 所以选哪条都一致；取最大只是为了在并联时选到最能代表"有电"的那条）。
   * 取不到数据的支路跳过（不放弃整个网络）——契约仍然是「没数据不画」。
   */
  let best = null;
  let bestAmp = -1;
  let bestSgn = 1;
  for (const [ref, sgn] of list) {
    const ser = idx.refs.get(String(ref).toUpperCase());
    if (!ser || !ser.current) continue;
    let amp = 0;
    let ok = true;
    for (let k = 0; k < tCount; k++) {
      const v = numOrNull(ser.current[k]);
      if (v == null) { ok = false; break; }   // null = 这一帧取不到 → 整条支路不用
      const a = Math.abs(v);
      if (a > amp) amp = a;
    }
    if (!ok) continue;
    if (amp > bestAmp) { bestAmp = amp; best = ser.current; bestSgn = sgn; }
  }
  if (!best) return null;
  const series = new Array(tCount);
  for (let k = 0; k < tCount; k++) {
    // sgn = -1 表示「该器件从本网络汲取」；取反后才是「注入本网络」。
    // 取不到的点保持 null（下游 flowAt 会判成「这一帧没有数据」），不补 0。
    const v = numOrNull(best[k]);
    series[k] = v == null ? null : -bestSgn * v;
  }
  return series;
}

/** 把一个网络的电流序列压成 flows 用的 {dir, level}：
 *  · dir  = 相邻时间点的多数方向（+1 沿导线正方向），用来定虚线跑动方向
 *  · level= 本网络峰值归一化后的当前强度（0..1），体现「多强」 */
export function flowAt(series, k, peak) {
  if (!series || k < 0 || k >= series.length) return null;
  const v = numOrNull(series[k]);
  if (v == null) return null;         // 取不到数据 → 这一帧这条导线不画（不补 0）

  /* ⚑ 方向必须取**电流的符号**，不是电流的斜率。
   * 早先这里用 slope = next - prev 定方向，实测后果很荒谬：
   *   · 电流在峰值处（+10.3mA）箭头反向 —— 因为那里导数刚好变号
   *   · 过零点（真正的换向时刻）箭头却不换
   *   · 恒定的负电流永远顺着跑（永远 dir=+1）
   * 等于把「正/负半周」演成了「上升段/下降段」，和电流毫无关系。
   */
  const dir = v >= 0 ? 1 : -1;

  /* ⚑ 亮度必须带**绝对下限**：只用「本网络自身峰值」归一化时，
   * 开关断开后的 5nA 漏电也会被归一化成满亮（level=1），
   * 与 19.4mA 导通时**画面一模一样** —— 用户以为「导线在流动=有电流」。
   * 图例侧的判据是 1e-6 A，这里取同一个门限：低于它就当没电流。
   */
  const abs = Math.abs(v);
  const FLOOR = 1e-6;
  const lv = (peak > 0 && abs >= FLOOR) ? abs / peak : 0;
  return { dir, level: Math.max(0, Math.min(1, lv)) };
}

/** 帧内的一次性准备：把导线层建好、把 SVG 标成动画版。返回可复用的句柄。 */
export function armSchematic(svgRoot) {
  if (!svgRoot || !svgRoot.querySelector) return null;
  svgRoot.classList.add('ccl-flow-svg');
  ensureFlowSheet();
  return { flow: ensureFlow(svgRoot) };
}

/** 画一帧。返回 true 表示这一帧有真实数据可用。
 *  · flows：net → {dir, level}（level 0..1；dir<0 表示虚线朝反方向跑）
 *  · items：ref → {current, power, kind}
 *
 *  任何一层缺数据，那一层就保持「看不见」—— 绝不沿用上一帧的残影（那是假数据）。
 *  性能：全程只改属性，且元素列表在第一次调用时缓存下来
 *  （之后每帧没有 querySelector，只有 N 次 setAttribute）。
 */
export function applyLiveFrame(svgRoot, frame) {
  if (!svgRoot || typeof document === 'undefined') return false;
  const f = frame || {};
  let drew = false;

  /* 元素缓存：挂在 svg 元素上，图换了（svgRoot 换了）自然失效 */
  let cache = svgRoot.__cclAnim;
  if (!cache) {
    const flowNodes = [];
    const flowLayer = svgRoot.querySelector('[data-role="flow"]');
    if (flowLayer) {
      for (const el of flowLayer.childNodes) {
        if (el && el.nodeType === 1) flowNodes.push(el);
      }
    }
    const groups = [];
    for (const g of svgRoot.querySelectorAll('g[data-ref]')) {
      groups.push({
        g,
        ref: String(g.getAttribute('data-ref') || '').toUpperCase(),
        kind: String(g.getAttribute('data-kind') || '').toUpperCase(),
        outer: null, inner: null,
      });
    }
    cache = { flowNodes, groups };
    try { svgRoot.__cclAnim = cache; } catch (_) { /* 冻结点属性也就算了，只是不缓存 */ }
  }

  /* ---- 导线流动 ---- */
  for (const el of cache.flowNodes) {
    const net = el.getAttribute('data-flow');
    const spec = f.flows ? f.flows.get(net) : null;
    // spec.level 是 0..1 的强度；null（这一帧没数据）按 0 处理 —— 这里 0 的含义是
    // 「不亮」，不是「电流是 0A」：下面直接走关灯分支。
    const lv = spec ? (numOrNull(spec.level) ?? 0) : 0;
    if (!(lv > 0.02)) {
      // 没数据 → 这一帧就是暗的。class 也要清掉：留着 f3 之类的档位，
      // 下一帧若换了图，会带着旧强度闪一下。
      el.setAttribute('opacity', '0');
      el.removeAttribute('class');
      continue;
    }
    drew = true;
    const lvl = Math.max(0, Math.min(1, lv));
    // 档位化（6 档）：数值全由 CSS 常量给，帧内只写一个 class + 一个 opacity
    el.setAttribute('class', 'f' + Math.max(1, Math.round(lvl * 6)));
    el.setAttribute('opacity', (0.35 + 0.65 * lvl).toFixed(2));
    if (spec.dir < 0) el.setAttribute('style', 'animation-direction:reverse');
    else el.removeAttribute('style');
  }

  /* ---- 器件 ---- */
  const kinds = f.kinds || null;
  for (const e of cache.groups) {
    const item = f.items ? f.items.get(e.ref) : null;
    const kind = kinds && kinds[e.ref] ? String(kinds[e.ref]).toUpperCase() : e.kind;
    if (kind === 'S') {
      // 开关的闭/合是**输入量**（用户点的），不是仿真数据，与 timeline 无关
      switchAt(e.g, !!(f.switches && f.switches.get(e.ref) === true));
      continue;
    }
    if (kind === 'D') {
      ledAt(e.g, item ? liveStyle('D', item) : null);
      if (item) drew = true;
      continue;
    }
    const st = item ? liveStyle(kind, item) : null;
    if (st) { glowAt(e, st); drew = true; }
    else if (e.outer) { e.outer.setAttribute('opacity', 0); e.outer.setAttribute('r', 0); }
  }
  return drew;
}

/* ============================ 主渲染 ============================ */
export function renderSchematic(circuit, opts) {
  const o = opts || {};
  const themeName = o.theme === 'light' ? 'light' : 'dark';
  const C = THEMES[themeName];
  const comps = normalizeComponents(circuit);

  if (!comps.length) return emptyState(circuit, themeName);

  const { colOf } = computeRanking(comps);

  const xOf = new Map();
  for (const [net, col] of colOf) xOf.set(net, L.marginL + col * L.colGap);
  const colX = (col) => L.marginL + col * L.colGap;

  /* ---------- 1. 分类 & 列跨度 ---------- */
  for (const c of comps) {
    const ranked = c.pins.filter(p => p.net !== GND_NET && colOf.has(p.net));
    const gndPins = c.pins.filter(p => p.net === GND_NET);
    const cols = ranked.map(p => colOf.get(p.net));
    c.minCol = cols.length ? Math.min(...cols) : 0;
    c.gndPins = gndPins;
    c.gndCount = gndPins.length;
    if (c.pins.length <= 2 && gndPins.length >= 1) c.mode = 'v';
    else if (c.pins.length <= 2) c.mode = 'h';
    else c.mode = 'block';
    /* 两端都接地 / 两端同一网络：仍然画，但用 v / h 的最小跨度兜底 */
    if (c.mode === 'h' && c.pins.length === 2
      && c.pins[0].net === c.pins[1].net) c.mode = 'self';
  }

  /* ---------- 2. 竖直元件的横向错位（同一网络挂多个时）---------- */
  const vGroups = new Map();
  for (const c of comps) {
    if (c.mode !== 'v') continue;
    const sig = c.pins.find(p => p.net !== GND_NET);
    if (!sig) { c.mode = 'skip'; continue; }
    c.sigPin = sig;
    if (!vGroups.has(sig.net)) vGroups.set(sig.net, []);
    vGroups.get(sig.net).push(c);
  }
  for (const arr of vGroups.values()) {
    const k = arr.length;
    const spacing = k > 1 ? Math.max(20, Math.min(40, 100 / (k - 1))) : 0;
    arr.forEach((c, i) => { c.off = (i - (k - 1) / 2) * spacing; });
  }

  /* ---------- 3. 行带排布（横放元件 + 三/四端器件）---------- */
  const boxes = [];
  const packBox = (x0, x1, h) => {
    let y = L.rowTop;
    for (let guard = 0; guard < 500; guard++) {
      const r = { x0, x1, y0: y, y1: y + h };
      let hit = null;
      for (const b of boxes) {
        if (r.x0 < b.x1 - 0.5 && b.x0 < r.x1 - 0.5 && r.y0 < b.y1 && b.y0 < r.y1) { hit = b; break; }
      }
      if (!hit) { boxes.push(r); return y; }
      y = hit.y1 + 8;
    }
    return y;
  };

  const rowComps = comps.filter(c => c.mode === 'h' || c.mode === 'block' || c.mode === 'self');
  rowComps.sort((a, b) => (a.minCol - b.minCol) || String(a.ref).localeCompare(String(b.ref)));

  for (const c of rowComps) {
    const cols = c.pins.filter(p => p.net !== GND_NET && colOf.has(p.net)).map(p => colOf.get(p.net));
    const cMin = cols.length ? Math.min(...cols) : c.minCol;
    const cMax = cols.length ? Math.max(...cols) : c.minCol;
    if (c.mode === 'block') {
      const top = packBox(colX(cMin), colX(Math.max(cMax, cMin + 1)), L.blockH);
      c.rowY = top + L.blockH / 2;
    } else {
      const top = packBox(colX(cMin), colX(Math.max(cMax, cMin + 1)), L.rowH);
      c.rowY = top + L.rowH / 2;
    }
  }

  /* ---------- 4. 竖直带（悬挂元件 + 地母线）---------- */
  const rowBottom = boxes.length ? Math.max(...boxes.map(b => b.y1)) : L.rowTop;
  const vTop = rowBottom + L.vGap;
  const gndY = vTop + L.vBand;

  /* ---------- 5. 画 ---------- */
  const pen = createPen();
  const attach = new Map();           /* net -> [{x,y}] */
  const addAttach = (net, x, y) => {
    if (!attach.has(net)) attach.set(net, []);
    attach.get(net).push({ x, y });
  };

  const partGroups = [];              /* 每个元件一个 <g>，最后拼进去 */
  /* 每个网络「净流出的电流」端点记账。动画层据此推每条导线的电流方向：
   *   direction = sign(从别的器件流进这个网络 − 从本器件流出这个网络)
   * 把每个元件内部的导线端点按 (in/out) 记一笔，比事后去猜图形方向可靠得多。 */
  const netIn = new Map();            /* net -> [[ref, +1 流入 / -1 流出], ...] */

  /* 把网名标到线上一份：自测脚本可以据此反推连接关系，证明「没接错」 */
  const netAttr = (net) => ' data-net="' + esc(net) + '"';
  const gndAttr = ' data-net="' + GND_NET + '"';
  const addFlow = (net, ref, sgn) => {
    if (net == null) return;
    if (!netIn.has(net)) netIn.set(net, []);
    netIn.get(net).push([String(ref), sgn]);
  };

  for (const c of comps) {
    if (c.mode === 'skip') continue;
    const sub = createPen();
    const local = [];                 /* 本元件每个引脚的落点：{net,x,y} */
    const att = (net, x, y) => { local.push({ net, x, y }); addAttach(net, x, y); };
    let dx = 0, dy = 0, axis = 'h';

    /* -------- (a) 横放的两端元件 -------- */
    if (c.mode === 'h' || c.mode === 'self') {
      const p0 = c.pins[0], p1 = c.pins[1] || c.pins[0];
      let xa = xOf.get(p0.net), xb = xOf.get(p1.net);
      if (xa == null) xa = L.marginL;
      if (xb == null) xb = xa + L.colGap;
      const same = Math.abs(xb - xa) < 1;
      if (same) xb = xa + 60;                       /* 自环/同网兜底，避免零宽 */
      const cy = c.rowY;
      const cx = (xa + xb) / 2;
      const flip = xb >= xa ? 1 : -1;
      const hl = Math.max(10, Math.min(22, Math.abs(xb - xa) / 2 - L.lead));

      sub.line(xa, cy, cx - flip * hl, cy, C.wire, 1, netAttr(p0.net));
      sub.line(cx + flip * hl, cy, xb, cy, C.wire, 1, netAttr(p1.net));
      drawTwoPinBody(sub, c.kind, cx, cy, 'h', flip, C, o);
      labelHorizPen(sub, c, cx, cy, C);
      if (c.kind === 'S') switchLabel(sub, cx, cy + 33, C);

      dx = cx; dy = cy; axis = 'h';
      att(p0.net, xa, cy);
      att(p1.net, xb, cy);
      /* 极性：p0 是首脚。D 的首脚是阳极（电流 a→k 即 p0→p1）；
       * 其它两端器件按"电流从 p0 流入、从 p1 流出"记账（V/R/C/L 的约定方向）。
       * 但两脚同网（自环）时两个方向记账要互相抵消，不能重复记。 */
      if (p0.net !== p1.net) {
        addFlow(p0.net, c.ref, -1);
        addFlow(p1.net, c.ref, +1);
      }
    }

    /* -------- (b) 竖放的两端元件（一端接地）-------- */
    else if (c.mode === 'v') {
      const sig = c.sigPin;
      const x = xOf.get(sig.net) + (c.off || 0);
      const cyv = (vTop + gndY) / 2;
      const hl = Math.min(22, (gndY - vTop) / 2 - 14);
      const p0Gnd = c.pins[0].net === GND_NET;
      const p0y = p0Gnd ? gndY : vTop;
      const p1 = c.pins[1] || c.pins[0];
      const p1y = p1.net === GND_NET ? gndY : vTop;
      const flip = p1y >= p0y ? 1 : -1;

      sub.line(x, p0y, x, cyv - flip * hl, C.wire, 1, netAttr(c.pins[0].net));
      sub.line(x, cyv + flip * hl, x, p1y, C.wire, 1, netAttr(p1.net));
      drawTwoPinBody(sub, c.kind, x, cyv, 'v', flip, C, o);
      if (c.kind === 'S') switchLabel(sub, x, cyv + 34, C);
      /* 横向引线到母线 */
      const busX = xOf.get(sig.net);
      if (Math.abs(x - busX) > 0.5) sub.line(x, vTop, busX, vTop, C.wire, 1, netAttr(sig.net));
      /* 标注放右侧 */
      sub.text(x + 19, cyv - 2, c.ref, C.ref, 10.5, 'start');
      if (c.value) sub.text(x + 19, cyv + 11, c.value, C.val, 10, 'start');

      dx = x; dy = cyv; axis = 'v';
      att(sig.net, busX, vTop);
      att(GND_NET, x, gndY);
      /* 竖放：电流从 p0 侧流到 p1 侧。哪一侧是信号网就记哪一侧。
       * 两端同网（自环）时两条记账互相抵消 —— 基尔霍夫定律在这里不成立，
       * 少记一笔比记成"这根母线有 2A"更诚实。 */
      if (c.pins[0].net !== p1.net) {
        addFlow(c.pins[0].net, c.ref, -1);
        addFlow(p1.net, c.ref, +1);
      }
    }

    /* -------- (c) 三/四端器件 -------- */
    else {
      const g = drawBlock(sub, c, {
        xOf, colOf, rowY: c.rowY, gndY, C, comps,
        addAttach: att,
        netAttr, gndAttr,
      });
      dx = g.cx; dy = g.cy; axis = g.axis || 'block';
    }

    let extra = '';
    if (c.kind === 'S') {
      /* 初始状态：优先用后端回给这个开关的 switch_states（它才是这次仿真用的状态），
       * 没有再退回用户点击时记下的本地状态。两个都没有就是 off —— 但这是**输入量**
       * 的默认值，不是编出来的仿真数据。 */
      const want = (o.switchStates && o.switchStates[c.ref])
        || (o.switchStatesLower && o.switchStatesLower[c.ref])
        || 'off';
      const closed = /^(on|1|true|closed|close)$/i.test(String(want));
      extra = ' data-sw="' + (closed ? 'on' : 'off') + '"'
        + ' data-switch="1" tabindex="0" role="button"'
        + ' style="cursor:pointer" aria-label="开关 ' + esc(c.ref) + '（点一下切换）"';
    }
    partGroups.push(
      '<g data-ref="' + esc(c.ref) + '" data-kind="' + esc(c.kind)
      + '" data-mode="' + esc(c.mode === 'self' ? 'h' : c.mode)
      + '" data-axis="' + esc(axis)
      + '" data-x="' + f(dx) + '" data-y="' + f(dy) + '"'
      + extra
      + ' data-pins="' + local.map(q => esc(q.net) + '@' + f(q.x) + ',' + f(q.y)).join(' ') + '">'
      + sub.out.join('') + '</g>');
    /* 并入总包围盒 */
    if (isFinite(sub.bb.x0)) {
      pen.bb.x0 = Math.min(pen.bb.x0, sub.bb.x0);
      pen.bb.y0 = Math.min(pen.bb.y0, sub.bb.y0);
      pen.bb.x1 = Math.max(pen.bb.x1, sub.bb.x1);
      pen.bb.y1 = Math.max(pen.bb.y1, sub.bb.y1);
    }
  }

  /* -------- (d) 网络母线 + 节点圆点 + 地母线 -------- */
  const wires = createPen();
  const netEntries = [...attach.entries()];
  for (const [net, pts] of netEntries) {
    if (net === GND_NET) continue;
    const x = xOf.get(net);
    if (x == null) continue;
    let y0 = Infinity, y1 = -Infinity;
    for (const p of pts) { y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }
    if (y1 - y0 > 0.5) wires.line(x, y0, x, y1, C.wire, 1, netAttr(net));
    if (pts.length >= 3) {
      const uniq = [];
      for (const p of pts) {
        if (!uniq.some(q => Math.abs(q.x - p.x) < 0.6 && Math.abs(q.y - p.y) < 0.6)) uniq.push(p);
      }
      for (const p of uniq) wires.dot(p.x, p.y, C.dot);
    }
  }

  /* 地母线 */
  const gpts = attach.get(GND_NET) || [];
  if (gpts.length) {
    let gx0 = Infinity, gx1 = -Infinity;
    for (const p of gpts) { gx0 = Math.min(gx0, p.x); gx1 = Math.max(gx1, p.x); }
    const gxEnd = gx1 + 28;
    wires.line(gx0, gndY, gxEnd, gndY, C.gnd, 1, gndAttr);
    /* GND 符号挂在地母线右端 */
    wires.line(gxEnd, gndY, gxEnd, gndY + 8, C.gnd, 1.2);
    wires.line(gxEnd - 10, gndY + 8, gxEnd + 10, gndY + 8, C.gnd, 2);
    wires.line(gxEnd - 6.5, gndY + 12, gxEnd + 6.5, gndY + 12, C.gnd, 1.6);
    wires.line(gxEnd - 3, gndY + 16, gxEnd + 3, gndY + 16, C.gnd, 1.4);
    wires.text(gxEnd, gndY + 27, 'GND', C.dim, 9, 'middle');
    if (gpts.length >= 3) {
      const uniq = [];
      for (const p of gpts) {
        if (!uniq.some(q => Math.abs(q.x - p.x) < 0.6 && Math.abs(q.y - p.y) < 0.6)) uniq.push(p);
      }
      for (const p of uniq) wires.dot(p.x, p.y, C.dot);
    }
  }

  /* ---------- 6. 组装 ---------- */
  const all = pen.bb;
  const bb = {
    x0: Math.min(all.x0, wires.bb.x0),
    y0: Math.min(all.y0, wires.bb.y0),
    x1: Math.max(all.x1, wires.bb.x1),
    y1: Math.max(all.y1, wires.bb.y1),
  };
  const W = Math.max(160, Math.ceil(bb.x1 + L.marginR));
  const H = Math.max(90, Math.ceil(bb.y1 + 10));

  const name = circuit && circuit.name ? String(circuit.name) : '';
  const nodeCount = circuit && Array.isArray(circuit.nodes) ? circuit.nodes.length : 0;
  const title = (name || '电路图') + ' · ' + comps.length + ' 元件 / ' + nodeCount + ' 节点';

  /* 流动端点的紧凑序列化：net|ref:符号@x,y;ref:符号@x,y —— 解析成本比 JSON 低，
   * 而且不会因为引号/转义把属性写坏。 */
  const flowNets = [];
  for (const [net, list] of netIn) {
    if (!list.length) continue;
    flowNets.push(net.replace(/[|@;]/g, '_') + '|'
      + list.map(([r, g]) => r.replace(/[:@;|]/g, '_') + ':' + g).join(';'));
  }

  const svg = [
    '<svg xmlns="http://www.w3.org/2000/svg" width="' + (o.width ? o.width : '100%') + '"'
    + ' height="auto" viewBox="0 0 ' + W + ' ' + H + '"'
    + ' preserveAspectRatio="xMidYMid meet" data-schematic="1"'
    + (name ? ' data-name="' + esc(name) + '"' : '')
    + ' data-flow-nets="' + esc(flowNets.join(' ')) + '"'
    + '>',
    '<title>' + esc(title) + '</title>',
    /* 发光滤镜：LED 播放时给它挂 filter="url(#cclGlow)"。
     * 同一个 <svg> 里只能有一个 id，导出成独立 .svg 也不会坏。 */
    '<defs><filter id="cclGlow" x="-80%" y="-80%" width="260%" height="260%">'
    + '<feGaussianBlur stdDeviation="2.4" result="b"/>'
    + '<feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>'
    + '</filter></defs>',
    '<g fill="none" stroke-linecap="round" font-family="' + FONT + '">',
    '<g data-role="wires">' + wires.out.join('') + '</g>',
    '<g data-role="parts">' + partGroups.join('') + '</g>',
    '</g>',
    '</svg>',
  ].join('');

  return svg;
}

/* 开关的状态小字：闭合 / 断开。它是个动画挂钩（data-sw-state），
 * 点一下只要改 textContent 与 fill —— 不需要重画电路图。 */
function switchLabel(pen, x, y, C) {
  pen.liveText(x, y, '断开', '#d7ba7d', 9, 'middle', '', ' data-sw-state="1"');
}

/* 横放元件的标注（画在 sub 画笔上） */
function labelHorizPen(pen, c, cx, cy, C) {
  pen.text(cx, cy - 13, c.ref, C.ref, 10.5, 'middle');
  if (c.value) pen.text(cx, cy + 21, c.value, C.val, 10, 'middle');
}

/* ============================ 三/四端器件 ============================ */
function drawBlock(pen, c, ctx) {
  const { xOf, colOf, rowY, gndY, C, addAttach, netAttr, gndAttr } = ctx;
  const NA = netAttr || (() => '');
  const GA = gndAttr || '';
  const cy = rowY;

  const pin = (name, dflt) => {
    for (const p of c.pins) if (p.name === name) return p;
    return c.pins[dflt] || null;
  };
  const colOfNet = (p) => (p && colOf.has(p.net) ? colOf.get(p.net) : null);
  const xOfNet = (p) => (p && xOf.has(p.net) ? xOf.get(p.net) : null);

  /* 引脚出线：横向 -/-> 母线 */
  const routeH = (px, py, net) => {
    if (net === GND_NET) return dropToGnd(px, py);
    const nx = xOf.get(net);
    if (nx == null) return null;
    pen.line(px, py, nx, py, C.wire, 1, NA(net));
    addAttach(net, nx, py);
    return { x: nx, y: py };
  };
  const dropToGnd = (px, py) => {
    pen.line(px, py, px, gndY, C.wire, 1, GA);
    addAttach(GND_NET, px, gndY);
    return { x: px, y: gndY };
  };
  /* 先竖向离开本体一段，再横走到母线 */
  const routeVH = (px, py, dy, net) => {
    if (net === GND_NET) return dropToGnd(px, py);
    const ny = py + dy;
    pen.line(px, py, px, ny, C.wire, 1, NA(net));
    return routeH(px, ny, net);
  };

  if (c.kind === 'X') {
    /* ---------------- 运放：三角形 ---------------- */
    const inp = pin('inp', 0);
    const inn = pin('inn', 1);
    const outp = pin('out', c.pins.length - 1);
    const outCol = colOfNet(outp);
    const inCols = [colOfNet(inp), colOfNet(inn)].filter(v => v !== null);
    /* 本体放在「输出列 - 1」，这样输出永远向右出、输入永远在左边；
     * 输入网络恰好等于输出网络时（跟随器 / 单位增益反馈），输入脚从下面绕回来 */
    let base = (outCol == null ? (inCols.length ? Math.max(...inCols) : 0) : outCol - 1);
    for (const cc of inCols) if (outCol != null && cc < outCol) base = Math.max(base, cc);
    if (base < 0) base = 0;
    const bxL = L.marginL + base * L.colGap + 32;
    const bw = 40, bh = 54;
    const apex = bxL + bw;

    pen.polygon([[bxL, cy - bh / 2], [bxL, cy + bh / 2], [apex, cy]], C.comp, 1.6, 'none');
    pen.text(bxL + 9, cy - 8, '+', C.ref, 12, 'middle');
    pen.text(bxL + 9, cy + 16, '−', C.ref, 12, 'middle');

    const piY = cy - 14, niY = cy + 14;
    pen.line(bxL, piY, bxL + 7, piY, C.wire, 1, inp ? NA(inp.net) : '');
    pen.line(bxL, niY, bxL + 7, niY, C.wire, 1, inn ? NA(inn.net) : '');
    /* 输入脚：网络在本体左边就走直的；在右边（反馈 / 跟随时）从下面绕过去 */
    const routeIn = (py, net) => {
      const nx = xOf.get(net);
      if (nx == null) return;
      if (net === GND_NET) { routeH(bxL, py, net); return; }
      if (nx < bxL - 4) { routeH(bxL, py, net); return; }
      const aroundY = cy + bh / 2 + 16;
      pen.line(bxL, py, bxL - 14, py, C.wire, 1, NA(net));
      pen.line(bxL - 14, py, bxL - 14, aroundY, C.wire, 1, NA(net));
      pen.line(bxL - 14, aroundY, nx, aroundY, C.wire, 1, NA(net));
      addAttach(net, nx, aroundY);
    };
    if (inp) routeIn(piY, inp.net);
    if (inn) routeIn(niY, inn.net);
    if (outp) {
      const nx = xOf.get(outp.net);
      if (nx != null && nx < apex - 4 && outp.net !== GND_NET) {
        /* 输出网络在左边：从下面绕回去，别压三角形 */
        const aroundY = cy + bh / 2 + 30;
        pen.line(apex, cy, apex + 14, cy, C.wire, 1, NA(outp.net));
        pen.line(apex + 14, cy, apex + 14, aroundY, C.wire, 1, NA(outp.net));
        pen.line(apex + 14, aroundY, nx, aroundY, C.wire, 1, NA(outp.net));
        addAttach(outp.net, nx, aroundY);
      } else {
        routeH(apex, cy, outp.net);
      }
    }

    pen.text(bxL + bw / 2, cy - bh / 2 - 8, c.ref, C.ref, 10.5, 'middle');
    if (c.value) pen.text(apex + 6, cy + bh / 2 + 8, c.value, C.val, 10, 'start');
    return { cx: bxL + bw / 2, cy, axis: 'block' };
  }

  if (c.kind === 'Q') {
    /* ---------------- 三极管：圆 + 基极竖线 + 斜引线 ---------------- */
    const bp = pin('b', 1);
    const cp = pin('c', 0);
    const ep = pin('e', c.pins.length - 1);
    const bCol = colOfNet(bp) != null ? colOfNet(bp) : 0;
    const cx = L.marginL + bCol * L.colGap + 48;

    pen.circle(cx, cy, 17, C.comp, 1.5, 'none');
    pen.line(cx - 7, cy - 11, cx - 7, cy + 11, C.comp, 2.4);   /* 基极竖线 */
    pen.line(cx - 26, cy, cx - 7, cy, C.comp, 1.4);            /* 基极引线 */
    pen.poly([[cx - 4, cy - 5], [cx + 9, cy - 17], [cx + 9, cy - 30]], C.comp, 1.6);
    pen.poly([[cx - 4, cy + 5], [cx + 9, cy + 17], [cx + 9, cy + 30]], C.comp, 1.6);
    pen.polygon(arrowTri(cx - 4, cy + 5, cx + 7.5, cy + 15, 7), C.comp, 0.5, C.comp);

    if (bp) routeH(cx - 26, cy, bp.net);
    if (cp) routeVH(cx + 9, cy - 30, -16, cp.net);
    if (ep) routeVH(cx + 9, cy + 30, 16, ep.net);

    pen.text(cx + 26, cy - 24, c.ref, C.ref, 10.5, 'start');
    if (c.value) pen.text(cx + 26, cy - 11, c.value, C.val, 10, 'start');
    return { cx, cy, axis: 'block' };
  }

  if (c.kind === 'M') {
    /* ---------------- MOSFET ---------------- */
    const gp = pin('g', 1);
    const dp = pin('d', 0);
    const sp = pin('s', 2);
    const bkp = pin('b', 3);
    const gCol = colOfNet(gp) != null ? colOfNet(gp) : 0;
    const cx = L.marginL + gCol * L.colGap + 48;

    pen.line(cx - 9, cy - 14, cx - 9, cy + 14, C.comp, 2.4);        /* 栅极竖线 */
    pen.line(cx - 28, cy, cx - 9, cy, C.comp, 1.4);                 /* 栅极引线 */
    pen.line(cx - 2, cy - 15, cx - 2, cy - 7, C.comp, 2.2);         /* 沟道三段 */
    pen.line(cx - 2, cy - 3.5, cx - 2, cy + 3.5, C.comp, 2.2);
    pen.line(cx - 2, cy + 7, cx - 2, cy + 15, C.comp, 2.2);
    pen.poly([[cx - 2, cy - 11], [cx + 12, cy - 11], [cx + 12, cy - 30]], C.comp, 1.6);
    pen.poly([[cx - 2, cy + 11], [cx + 12, cy + 11], [cx + 12, cy + 30]], C.comp, 1.6);
    pen.line(cx - 2, cy, cx + 12, cy, C.comp, 1.4);                 /* 衬底引线 */
    pen.polygon(arrowTri(cx + 12, cy, cx - 0.5, cy, 7), C.comp, 0.5, C.comp);
    pen.line(cx + 12, cy, cx + 26, cy, C.comp, 1.4);                /* 衬底出脚 */

    if (gp) routeH(cx - 28, cy, gp.net);
    if (dp) routeVH(cx + 12, cy - 30, -16, dp.net);
    if (sp) routeVH(cx + 12, cy + 30, 16, sp.net);
    if (bkp) {
      if (bkp.net === GND_NET) dropToGnd(cx + 26, cy);
      else routeH(cx + 26, cy, bkp.net);
    }

    pen.text(cx + 32, cy - 24, c.ref, C.ref, 10.5, 'start');
    if (c.value) pen.text(cx + 32, cy - 11, c.value, C.val, 10, 'start');
    return { cx, cy, axis: 'block' };
  }

  /* ---------------- 其它未知多端器件：方框 ---------------- */
  const cols = c.pins.map(colOfNet).filter(v => v !== null);
  const baseCol = cols.length ? Math.min(...cols) : 0;
  const bx = L.marginL + baseCol * L.colGap + 40;
  const bwid = 44, bh = Math.max(34, 16 * c.pins.length);
  pen.rect(bx, cy - bh / 2, bwid, bh, C.comp, 1.5, 'none');
  c.pins.forEach((p, i) => {
    const py = cy - bh / 2 + (i + 1) * (bh / (c.pins.length + 1));
    if (p.net === GND_NET) { dropToGnd(bx + bwid, py); return; }
    const nx = xOf.get(p.net);
    if (nx == null) return;
    pen.line(bx, py, nx, py, C.wire, 1, NA(p.net));
    addAttach(p.net, nx, py);
  });
  pen.text(bx + bwid / 2, cy - bh / 2 - 8, c.ref, C.ref, 10.5, 'middle');
  if (c.value) pen.text(bx + bwid / 2, cy + bh / 2 + 14, c.value, C.val, 10, 'middle');
  return { cx: bx + bwid / 2, cy, axis: 'block' };
}

/* ============================ 空态 ============================ */
function emptyState(circuit, theme) {
  const C = THEMES[theme === 'light' ? 'light' : 'dark'];
  const name = circuit && circuit.name ? String(circuit.name) : '';
  return '<div class="schematic-empty" data-schematic-empty="1"'
    + ' style="display:flex;align-items:center;justify-content:center;'
    + 'min-height:120px;height:100%;padding:18px;box-sizing:border-box;'
    + 'font-family:' + FONT + ';font-size:12px;line-height:1.7;text-align:center;'
    + 'color:' + C.dim + ';">'
    + '电路图：还没有元件' + (name ? '（' + esc(name) + '）' : '')
    + '<br>在代码里加一个 V / R / C 再运行，图会出现在这里'
    + '</div>';
}

/* ============================ 播放器 ============================
 * 一条时间轴播放条 + 每帧的 DOM 更新。与具体面板解耦：
 *   createPlayer({ container, onFrame, onToggle }) -> { mount, destroy, ... }
 * container 是播放条要插进去的父元素（panels.js 的电路图面板）。
 *
 * 为什么自己算墙钟时间而不用 SVG/CSS 动画：
 *   数据是**离散的真实时间点**（降采样后每点间隔不等），CSS 动画只会给出
 *   一个平滑但虚构的中间态。这里用真实时间推进游标，每帧对到最近的采样点，
 *   显示的永远是「某个真实仿真时刻」的状态 —— 拖到哪就是哪一帧的数。
 * ================================================================ */

/** 时间格式化（播放条上的当前时刻）：跟随量级自动选 ns / µs / ms / s */
export function fmtT(sec) {
  const a = Math.abs(Number(sec) || 0);
  if (a >= 1) return a.toFixed(3) + ' s';
  if (a >= 1e-3) return (a * 1e3).toFixed(3) + ' ms';
  if (a >= 1e-6) return (a * 1e6).toFixed(2) + ' µs';
  if (a >= 1e-9) return (a * 1e9).toFixed(2) + ' ns';
  return (a * 1e9).toFixed(1) + ' ns';
}

/** 总时长：优先用后端给的时间轴长度（最后一个时间点 - 第一个），
 *  没给就用序列的点数估算（仅用于把动画播完，不影响任何显示的数值）。 */
function timelineSpan(t) {
  if (!t || t.length === 0) return 0;
  const a = numOrNull(t[0]), b = numOrNull(t[t.length - 1]);
  if (a != null && b != null && b > a) return b - a;
  return 0;
}

/**
 * @param {object} opts
 *   @param {HTMLElement} opts.host        播放条挂到哪个元素里
 *   @param {string}      opts.svg         renderSchematic 的产物
 *   @param {object}      opts.timeline    后端给的 timeline（可为 null → 整个播放器不建）
 *   @param {object}      opts.kinds       位号 → 器件类型（大写单字母）
 *   @param {number}      opts.speed       倍速（默认 1）
 *   @param {function}    opts.onFrame     (i, time) 每帧回调（面板可用来同步别的显示）
 *   @param {function}    opts.onSwitch    (ref, closed) 点开关时回调（由 main.js 重跑仿真）
 *   @param {Map}         opts.switches    位号 → true(闭合) / false(断开)
 * @returns {object|null} 播放器；timeline 不可用时返回 null（**不显示播放条**）
 */
export function createPlayer(opts) {
  const o = opts || {};
  if (typeof document === 'undefined') return null;
  const idx = timelineIndex(o.timeline);
  if (idx.t.length < 2 || idx.refs.size === 0) return null;   // 没数据 → 不演

  const host = o.host;
  if (!host) return null;
  const kinds = o.kinds || {};
  const switches = o.switches instanceof Map ? o.switches : new Map();

  /* ---------------- 播放条的 DOM ---------------- */
  const bar = document.createElement('div');
  bar.className = 'anim-bar';
  bar.setAttribute('data-anim', '1');
  bar.innerHTML =
    '<button class="anim-play" data-anim-play title="播放 / 暂停（空格）">▶</button>'
    + '<input class="anim-range" data-anim-range type="range" min="0" max="' + (idx.t.length - 1)
    + '" step="1" value="0" aria-label="时间轴">'
    + '<span class="anim-time" data-anim-time>0</span>'
    + '<select class="anim-speed" data-anim-speed title="播放速度">'
    + '<option value="0.25">0.25×</option><option value="0.5">0.5×</option>'
    + '<option value="1" selected>1×</option><option value="2">2×</option>'
    + '<option value="4">4×</option></select>'
    + '<span class="anim-src" data-anim-src></span>';

  const btn = bar.querySelector('[data-anim-play]');
  const range = bar.querySelector('[data-anim-range]');
  const timeEl = bar.querySelector('[data-anim-time]');
  const speedEl = bar.querySelector('[data-anim-speed]');
  const srcEl = bar.querySelector('[data-anim-src]');

  /* 数据来源：必须写清真数据 + 点数 + 时长（契约 3.3）。
   * 时长是**仿真覆盖的时间**，不是动画播放多久 —— 这两个数很容易被混为一谈。 */
  const span = timelineSpan(idx.t);
  const samples = idx.t.length;
  srcEl.textContent = '数据：ngspice 瞬态仿真 · ' + samples + ' 点 / '
    + (span > 0 ? fmtT(span) : '时长未知');
  srcEl.title = '每一点都是 ngspice 导出的真实时间点；共 ' + samples + ' 点'
    + (span > 0 ? '，覆盖 ' + fmtT(span) : '');

  host.appendChild(bar);

  /* ---------------- SVG 句柄 ---------------- */
  const svgRoot = host.querySelector('svg[data-schematic]')
    || (host.closest ? host.closest('svg') : null);
  let handle = null;
  try { handle = armSchematic(svgRoot); } catch (_) { handle = null; }
  const flowNets = parseFlowNets(svgRoot);
  /* 每个网络的电流序列只算一次（播放/拖动/循环都复用），峰值也一起归一化。 */
  const nets = [];
  for (const [net, list] of flowNets) {
    const ser = netCurrentSeries(list, idx, net, idx.t.length);
    if (!ser) continue;
    let peak = 0;
    for (const v of ser) { const x = numOrNull(v); if (x != null) { const a = Math.abs(x); if (a > peak) peak = a; } }
    if (peak <= 0) continue;                  // 全程 0A 的网络没有可看的流动 —— 不算数据
    nets.push({ net, ser, peak });
  }

  /* ---------------- 状态机 ---------------- */
  let i = 0;
  let playing = false;
  let speed = 1;
  let raf = 0;
  let last = 0;
  let acc = 0;              // 已经播放过的墙钟秒数（乘过速度）
  let segFrom = 0;          // 当前这一段是从第几点开始播的
  /* 一整轮播完需要多少秒墙钟时间。默认压到 6 秒左右，
   * 因为仿真时长常常是微秒级，按 1× 播完是「一眨眼」，看不出东西。
   * 它是**时长**比例，不是物理时间的真实倍率 —— 真实时刻由 idx.t 显示。 */
  const CYCLE_SEC = 6;
  /* ⚑ 倍速必须是**函数**，不能算成常量。
   * 早先这里是 `const durPerCycle = CYCLE_SEC / clamp(speed)`，只在建播放器时算一次；
   * 下拉框 onchange 改的 `speed` 之后再没人读 → 选 0.25× 还是 4× 都跑 6 秒一轮，
   * 控件在、样式在、onchange 也执行了，就是数字不变。 */
  const cycleSeconds = () => CYCLE_SEC / Math.max(0.25, Math.min(4, speed));

  /** 把游标对齐到 k 点，并重置「这一段」的计时起点。
   *  播放推进和拖动走的是同一条路径：先 seek，再往下跑。 */
  function goto(k, keepAcc) {
    const n = idx.t.length;
    let kk = Math.round(k);
    if (!isFinite(kk)) kk = 0;
    i = ((kk % n) + n) % n;         // 越界取模 → 拖过头就回绕，不会落到空帧
    segFrom = i;
    // keepAcc=true 用于「播放推进到下一帧」：此时累加器里还有没消费完的零头，
    // 归零会让播放变慢（见 tick 里的注释）。用户手动拖动进度条时不传 → 归零对齐。
    if (!keepAcc) acc = 0;
    paint(i);
    setRangeVal(i);
  }

  function frameData(k) {
    const items = frameState(idx, k, kinds);
    const flows = new Map();
    for (const n of nets) {
      const f = flowAt(n.ser, k, n.peak);
      if (f) flows.set(n.net, f);
    }
    return { items, flows, kinds, switches };
  }

  function paint(k) {
    if (!svgRoot) return;
    try {
      applyLiveFrame(svgRoot, frameData(k));
    } catch (e) {
      console.warn('[anim] 单帧更新失败，已停止播放', e);
      pause();
    }
  }

  function setRangeVal(k) {
    range.value = String(k);
    timeEl.textContent = fmtT(idx.t[k]) + ' / ' + fmtT(idx.t[idx.t.length - 1]);
    if (typeof o.onFrame === 'function') {
      try { o.onFrame(k, idx.t[k]); } catch (_) { /* 面板侧的错误不影响动画 */ }
    }
  }

  /** 跳到第 k 点。
   *  · byClock=false（拖进度条 / 首帧）：墙钟累加器对齐到这一帧
   *  · byClock=true （播放推进）：保留多出来的小数部分
   *    一开始两者被写成了同一个行为，结果播放每帧都被"对齐"回整数点，
   *    游标永远原地不动 —— 现在分开。 */


  /* ---------------- 主循环 ---------------- */
  /* 主循环：按真实时间推进。
   * 早先的写法是「每帧把游标改成 i+1」，被固定帧率（60Hz）卡死后
   * 一整轮就被拉成了 N/60 秒 —— 速度旋钮形同虚设。
   * 现在按墙钟走：游标 = 起点 + 已播秒数 / 每点占用的秒数，
   * 于是 1× = 6 秒一轮，4× = 1.5 秒一轮，与帧率无关。 */
  function tick(now) {
    if (!playing) return;
    /* 时间戳可能不单调（首帧为 0、被面板切换打断、测试里手喂时钟），
     * 负数一律当 0 —— 否则减法的绝对值会把游标往前推。 */
    const raw = last ? (now - last) / 1000 : 0;
    const dt = raw > 0 ? Math.min(0.5, raw) : 0;
    last = now;
    acc += dt;
    const n = idx.t.length;
    const step = cycleSeconds() / n;               // 每一个仿真点占用多少墙钟秒（随倍速变化）
    const adv = Math.floor(acc / step);
    if (adv > 0) {
      // 只扣掉已经消费掉的整数点，**余下的零头必须留给下一帧**。
      // ⚑ 早先这里还有一行 `acc = 0;`，把每帧的零头都扔掉了 ——
      // 于是播放整体慢 11%（400 点 @60fps 实测 6.67s 而不是 6s），
      // 90Hz 下更糟，慢 48%（8.89s vs 6s）。
      // 丢了零头还会让「进度条位置」和「显示的时刻」对不上标称速度。
      acc -= adv * step;
      goto(segFrom + adv, true);                  // true = 保留累加器余量
    }
    raf = requestAnimationFrame(tick);
  }

  function play() {
    if (playing) return;
    if (i >= idx.t.length - 1) goto(0);             // 播到末尾再按播放 → 从头开始
    playing = true;
    last = 0;
    btn.textContent = '⏸';
    btn.setAttribute('data-state', 'playing');
    raf = requestAnimationFrame(tick);
    if (typeof o.onToggle === 'function') o.onToggle(true);
  }

  function pause() {
    if (!playing) return;
    playing = false;
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    btn.textContent = '▶';
    btn.setAttribute('data-state', 'paused');
    if (typeof o.onToggle === 'function') o.onToggle(false);
  }

  btn.addEventListener('click', () => { playing ? pause() : play(); });
  range.addEventListener('input', () => {
    pause();                                        // 拖动时真的停下来（不是假装）
    goto(Number(range.value));
  });
  speedEl.addEventListener('change', () => {
    const s = Number(speedEl.value) || 1;
    speed = s;
    // 改速度不重置游标：重新描述"这一刻"的成本为 0（只有剩下的部分按新速度跑）
    acc = 0;
    segFrom = i;
  });

  /* 空格：只在电路图面板可见、且焦点不在输入框里时接管（否则会吃掉编辑器打字）。 */
  function onKey(e) {
    if (e.key !== ' ' && e.code !== 'Space') return;
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    if (bar.closest('[hidden]')) return;
    e.preventDefault();
    playing ? pause() : play();
  }
  document.addEventListener('keydown', onKey);

  /* 开关点击：不重建整张图，只改这个开关自己的视觉 + 通知上层重跑。
   * 视觉先切（用户立刻看到反馈），数据以重新仿真回来的为准。 */
  // 开关点击：复用独立函数（与播放器解耦，见 wireSwitchClicks 的注释）
  const detachSwitch = wireSwitchClicks(host, { switches, onSwitch: o.onSwitch });

  /* 首帧：静态画一次第 0 点。有真数据才画，没数据就是原样（导线全暗）。 */
  goto(0);
  if (nets.length === 0) {
    /* 有 timeline 但一条导线都推不出电流（比如器件全在两脚同网的怪电路）：
     * 播放条照样显示（器件亮度仍然是真的），但把这件事如实标出来。 */
    srcEl.title += '\n注意：这次没有可推出的支路电流，导线流动效果不显示。';
  }

  return {
    play, pause, seek: goto,
    get playing() { return playing; },
    get index() { return i; },
    get length() { return idx.t.length; },
    get nets() { return nets.length; },
    destroy() {
      pause();
      document.removeEventListener('keydown', onKey);
      try { detachSwitch(); } catch (_) {}
      if (bar.parentNode) bar.parentNode.removeChild(bar);
    },
  };
}

/** 给面板用：空电路返回空态提示，否则返回 SVG */
export function schematicOrEmpty(circuit, opts) {
  const has = circuit && Array.isArray(circuit.components) && circuit.components.length > 0;
  if (!has) return emptyState(circuit, (opts && opts.theme) || 'dark');
  return renderSchematic(circuit, opts);
}

export default renderSchematic;
