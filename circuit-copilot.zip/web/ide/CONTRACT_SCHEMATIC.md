# 电路图渲染模块契约（`web/ide/schematic.js`）

## 相关契约（别处）

本文件只管一件事：**`web/ide/schematic.js` 这个只读电路图模块**（符号、布局、走线、连接正确性判据）。
同层其他契约：

| 文件 | 权威范围 |
|---|---|
| `web/ide/CONTRACT.md` | IDE 骨架：文件所有权、布局网格、其余模块（`editor.js` / `panels.js` / `main.js`）的签名 |
| `web/ide/CONTRACT_ROUND4.md` | 移动端实测缺陷清单 |
| `web/ide/CONTRACT_ROUND5_DESKTOP.md` | 桌面版对标 VS Code（视口/键位以它为准） |
| **本文件（`CONTRACT_SCHEMATIC.md`）** | `schematic.js` 的唯一权威：改这个文件前先读完 |

两处下文校正（**与本文正文冲突时以本节为准**）：

- 自测脚本已从 `scratch_m1/` **迁到 `tests_ui/`**：`node tests_ui/schematic_selfcheck.mjs`
  （51 项；第 7 组是几何连通性反推）。`scratch_m1/` 目录已随里程碑清理下线，
  正文「验证方式」一节里提到的旧路径不再存在。
- 「9 个真实后端示例的连通性」那条是**人工核对**，脚本（`_viz/realcheck.mjs`）已一并下线，
  现在不是自动化回归项；自动化回归是上面那条 51 项 + `tests_ccl/test_schematic.py`。
- **符号是 10 种，不是 9 种**：M6 加了 `S`（电压控制开关，见文末「工作态与瞬态动画层」）。
  注意 `tests_ui/schematic_selfcheck.mjs` 里还只覆盖原来的 9 种——`S` 目前**没有**前端自测，
  它的回归在 `tests_api/test_ui_contract.py`（按源码断言：`wireSwitchClicks` 必须独立导出、
  不得回到播放器内部）。
- **「模块不碰 DOM、对外只有两个导出」这句已过时**（正文「唯一交付物」一节）：
  静态渲染路径仍是纯字符串，但动画层（`applyLive` / `applyLiveFrame` / `createPlayer` /
  `wireSwitchClicks`）必须操作 DOM。这些函数开头都有 `typeof document === 'undefined'` 守卫，
  所以在 Node 里 import 仍然安全（自测能直接跑），但只有静态渲染那条路是无 DOM 的。
  当前 `schematic.js` 共 **17 个命名导出 + 1 个 default**（清单见文末）。

连接正确性的实现口径与实测数据见 `docs/ARCHITECTURE.md` §6.5。

## 目标

**从代码生成的电路图，只读，不可编辑。**
代码是真相，图只是它的一个投影——所以永远不需要"在图上画"，这也正是它绕开了图形编辑器死亡陷阱的原因。

产出：一段 SVG 字符串，可嵌进面板、可导出 `.svg`、可放进报告。

## 唯一交付物

`web/ide/schematic.js`（新建文件）

**禁止修改**任何其他文件（`index.html` / `main.js` / `panels.js` / `style.css` / `ccl/` / `copilot/` / `tests_ccl/` 全部不动，接线由 Lead 做）。

## 导出接口（契约固定）

```js
/**
 * @param {Object} circuit 后端返回的电路结构：
 *   {
 *     name: "rc_lowpass",
 *     nodes: ["in", "0", "out"],
 *     components: [
 *       { ref:"V1", kind:"V", value_text:"AC 1V", model:null,
 *         pins:["a","b"], pin_nodes:{a:"in", b:"0"} },
 *       ...
 *     ]
 *   }
 * @param {Object} [opts]
 *   { width?: number, theme?: "dark" }
 * @returns {string} 完整 SVG 字符串（含 <svg> 根元素与内联样式属性）
 */
export function renderSchematic(circuit, opts) {}

/** 给面板用：返回可直接插入 DOM 的 SVG 字符串（空电路时返回带提示文字的空态） */
export function schematicOrEmpty(circuit) {}
```

## 元件种类与符号（必须都支持）

后端 `kind` 字段可能的值：

| kind | 元件 | 符号要求 |
|---|---|---|
| `R` | 电阻 | 矩形（或折线），两端引线，标 `R1` + 阻值 |
| `C` | 电容 | 两条平行短线（极板），标 `C1` + 容值 |
| `L` | 电感 | 3~4 个半圆弧 |
| `V` | 电压源 | 圆 + 内部 `+`/`−` |
| `I` | 电流源 | 圆 + 内部箭头 |
| `D` | 二极管 | 三角形 + 竖线，标型号 |
| `Q` | 三极管 | 圆 + 基极竖线 + 集电极/发射极斜线（NPN 箭头朝外） |
| `M` | MOSFET | 栅极竖线 + 沟道三段 + 源/漏/衬底引线 |
| `X` | 运放（子电路实例） | 三角形 + 左两输入（`+`/`−`）+ 右输出 |
| `S` | 开关（M6 新增） | 左触点 → 刀闸 → 右触点；开/合靠**改同一个 blade 的 `transform`**（`rotate(-30)` / `rotate(0)`），不在播放中重建节点。另带一个透明命中矩形放大可点区域（`data-sw-hit`） |

`kind` 不认识时**画成一个带位号的方框**（降级但不出错）。

## 布局算法（这是本任务成败的关键）

要求按「**信号从左到右、电源在上、地在下**」的工程习惯排布。

### 1. 建图
- 网络（net）= `pin_nodes` 里出现的每个节点值
- GND 恒为 `"0"`（后端已保证地节点叫 `0`）
- 元件 = 连接其各引脚所在网络的超边

### 2. 分层（rank）
- **源网络**：含 `V`/`I` 元件且该元件**第 0 个引脚（`a`）**接在它上面的网络 → rank 0
- 从源网络出发做 **BFS**，`rank(net)` = 最小跳数
- 不可达的网络（孤立子网）排到最后
- **不要给 GND 分层**——GND 单独作为底部母线

### 3. 摆位
- 列坐标：`x(net) = margin.left + rank * COL_GAP`
- 每个元件的「列」= 它两端网络中 **rank 较小**的那个
- 同一列内的元件按行依次排开（`y = margin.top + i * ROW_GAP`）
- **一端接 GND 的元件竖着画**（从网络向下连到 GND 母线）；
  两端都不是 GND 的**横着画**

### 4. 走线
- 每个网络画一条**垂直母线**（在该网络的 x 上，纵跨它所有引脚的高度范围）
- 每个引脚到母线之间画一条**水平短线**
- 同一个网络有 **≥3 个引脚**时，在母线上画**实心圆点**（节点连接点）
- 全部用**正交**（只走水平/垂直线），不要斜线

### 5. 标注
- 位号（`R1`）和值（`1.6kΩ`）放在符号旁边，不要压在线上
- 值太长的截断到合理宽度（比如 `OPA_100000_1p3e06` 显示成 `OPA(1e6)` 或直接截断）
- GND 母线下方画一个 GND 符号

## 视觉要求

- **深色主题**配 `style.css` 的变量风格：背景透明、线条 `#8c8c8c`、元件 `#d4d4d4`、标注 `#9cdcfe`、值 `#b5cea8`
- 全部样式**内联为 SVG 属性**（`stroke` / `fill` / `font-size`），因为要能导出独立文件
- 字体 `ui-monospace, monospace`，字号 10~11
- 线宽 1.5（元件）/ 1（走线）
- `viewBox` 自适应内容尺寸；`width="100%"`、`height="auto"`、`preserveAspectRatio="xMidYMid meet"`
- 元件与母线之间留出引线长度（约 14px）

## 必须自测并在报告里贴数字

写一个**纯 Node 可跑**的自测脚本 `scratch_m1/schematic_selfcheck.mjs`（用 `node --input-type=module` 或直接 `node scratch_m1/schematic_selfcheck.mjs`），
用构造数据覆盖：

1. **RC 低通**（V1/R1/C1，3 网络）
   → SVG 里 `<line`/`<path`/`<rect`/`<text` 各多少；V1 的 x 应小于 R1 的 x（源在左）；C1 应是竖直（它的两条引线 y 不同、x 相同区域）
2. **级联**（V1 + 内联的 U1.R1/U1.C1 + U2.R1/U2.R2/U2.X1）
   → 至少 6 个元件符号；X1（运放）是三角形；`U2.X1` 的位号出现在 SVG 文本里
3. **含 3 引脚网络**（RC + 一个额外电阻接到 `out`）
   → 该网络母线上出现 `circle`（节点圆点），且数量 ≥1
4. **BJT / MOS / 二极管**各一个 → 对应符号被画出（检查特定 path/形状标记，或给你画的每个符号加 `data-kind` 属性便于断言）
5. **未知 kind**（构造 `{kind:"Z"}`）→ 降级成方框、不抛异常、位号仍显示
6. **空电路**（components 为空）→ `schematicOrEmpty` 返回带提示文字的空态，不产生 `<svg>`

**建议给每个元件符号的外层 `<g>` 加 `data-ref` 与 `data-kind` 属性**，自测直接用 `querySelectorAll` 数，比数 path 可靠。

## 验证方式

自测脚本里可以用极简的正则/DOM stub 统计，不要引入任何 npm 包。
如果要用真 DOM，可用浏览器工具在 `http://127.0.0.1:3081/ide` 里 eval（但别改页面）。

## 环境
- `cd /storage/emulated/0/文件夹/dz/circuit-copilot`
- 只用原生 JS（ES module），**禁止 npm / CDN / 框架**
- 重启服务用 `bash start.sh`（不要 pkill）

## 交付
send_message 给 `lead`：
1. 布局算法实际怎么做的（分层、摆位、GND 处理）
2. 上面 6 项自测的**实际数字**（各自统计到多少元素）
3. 你判断哪些电路类型会画得好看、哪些会乱（诚实）
4. 遗留问题

**预期管理**：简单链式电路（RC / 分压 / 单级放大 / 级联）要画得像手画；
多回路反馈、差分对这类**允许乱**，但**不允许崩或画出错误连接**——连接关系错了比丑严重得多。

---

# 工作态与瞬态动画层（M6 新增，已实现并验证）

这一节是 `schematic.js` **动画部分**的权威：静态渲染（符号/布局/走线/连接正确性）仍以上文为准。

## 三条铁律（和 `ccl/CONTRACT.md` 的 M6 节一致）

1. **所有视觉由真仿真数据驱动**——不做装饰动画；
2. **拿不到数据就不显示**：某一帧取不到就保持「看不见」，**绝不沿用上一帧的残影/绝不补 0**；
3. **没有 `timeline` 就不演**（`ac` / `op` / `dc` 不建播放条、不动 SVG）。

## 导出清单（**17 个命名导出 + `default`**，以 `grep -n '^export ' web/ide/schematic.js` 为准）

| 导出 | 用途 |
|---|---|
| `renderSchematic(circuit, opts)` / `schematicOrEmpty(circuit, opts)` / `default` | 静态渲染（纯字符串，无 DOM 也能跑） |
| `currentToLevel(amp)` | 电流**幅值** → 0..1 亮度（对数刻度：1µA→0，100mA→1）。**必须取 `\|amp\|`**：瞬态电流本来就分正负，早先只认正半周，实测 5V/1kHz SIN 驱动下 C1 的 112 点里有 51 个负值、`\|I\|` 峰值 26.668mA，那 51 帧亮度全是 0（屏幕上就是「电流倒着走时整段熄灭」） |
| `liveStyle(kind, item)` | 器件 → `{color, glow, opacity, level, kind}`；返回 `null` 表示不叠加。`item.current`/`item.power` 为 `null` **一律不叠加**（`item.current \|\| 0` 会把「取不到」静默变成 0）。**二极管是唯一按有符号电流判亮的**（反偏只漏电、不发光），其余（R 按功耗、C/L/Q/M 按电流幅值）都取幅值 |
| `applyLive(svg, live)` | **静态快照**叠加：吃后端 `live`，返回新 SVG 字符串；只在**没有 timeline** 时用 |
| `armSchematic(svgRoot)` | 把导线流动层建好（只做一次），返回句柄 |
| `applyLiveFrame(svgRoot, frame)` | 画**一帧**：只改已存在节点的属性，不产生字符串、不重渲染 |
| `frameState(idx, i, kinds)` | 第 `i` 帧每个器件的 `{current, power, kind}`（功耗 = `abs(V*I)`，缺电压就是 `null`） |
| `timelineIndex(timeline)` | 把后端 `timeline` 索引成 `{refs: Map, t, dt}`，只收真实数据 |
| `parseFlowNets(svgRoot)` | 解析 `data-flow-nets`：网络 → `[[位号, ±1], …]` |
| `netCurrentSeries(entry, idx, net, tCount)` | 一个网络的电流序列：**取本网络上 `\|I\|` 最大的那一条支路**（不是各支路求和——求和等于 KCL 残差，正确解里恒为 0） |
| `flowAt(series, k, peak)` | 压成 `{dir, level}`：`level = |I|/本网络峰值`，`dir` 见下 |
| `deriveSwitchStates(opts)` | 由**本次仿真的节点电压 + 网表里的 `Vt`** 推出每个开关的**实际**状态，返回 `{states: Map, info: Map}`。注意 `kind` 后端给的是 `'SW'`，别只认单字符 `'S'` |
| `switchSideEffects(der, comps, intent)` | 共用控制节点导致「点一个、动两个」的连带影响，返回 `[{ref, kind:'shared'\|'unknown', state?, via, ctrl}]`；推不出来的标 `unknown`，**不猜成已断/已合** |
| `createPlayer(opts)` | 时间轴播放条 + rAF 主循环；**timeline 不可用时返回 `null`** |
| `wireSwitchClicks(host, opts)` | 开关点击绑定，**独立于播放器**（返回解绑函数） |
| `fmtT(sec)` | 时间格式化（ns/µs/ms/s） |

## 播放条（`createPlayer`）

- DOM：`[data-anim]` 容器内含 `▶/⏸`（`[data-anim-play]`）、可拖进度条（`[data-anim-range]`）、
  当前时刻（`[data-anim-time]`）、速度下拉（`[data-anim-speed]`：**0.25 / 0.5 / 1 / 2 / 4×**）、
  数据来源标签（`[data-anim-src]`）
- 来源标签文案固定为 `数据：ngspice 瞬态仿真 · N 点 / X 时长`（N 是 `timeline.t` 的长度，
  时长是**仿真覆盖的时间**——不是动画播放多久）
- **播放节奏与仿真时长无关**：一整轮固定约 **6 秒墙钟时间**（`CYCLE_SEC = 6`，按倍速缩放），
  因为仿真时长常在微秒级，按真实比例播是一眨眼。**真实时刻由 `idx.t` 显示**，别把这个 6 秒当物理时间
- 主循环按墙钟推进（`requestAnimationFrame` + 累加器），游标落在**真实采样点**上（对到最近的点），
  所以任意一帧都是「某个真实仿真时刻」的状态；拖动 = 暂停后 seek（不是假装暂停）
- 空格键播放/暂停（焦点在输入框内、或面板隐藏时不接管）
- 键位/销毁：`destroy()` 摘掉播放条、解绑键盘与开关点击；离开面板时 `panels.js` 会调它（不留跑着的 rAF）

## 每个器件怎么画（`liveStyle()` / `ledAt()` / `switchAt()`）

| 器件 | 数据 | 映射（实测口径） |
|---|---|---|
| 二极管 / LED（`D`） | 电流 | 对数映射 `currentToLevel()`：1µA → 0，100mA → 1；`level ≤ 0.02` 判为不亮。点亮 = **染符号本身**（填充 + `fill-opacity` + `url(#cclGlow)` 滤镜 + 描边加粗），不套光晕圆 |
| 电阻（`R`） | 功耗 | 以 0.25W 为满量程：`P < 0.125W`（<50%）**不显色**；≥0.125W 橙色 `#ff8c42`；`P ≥ 0.25W` 变红 `#ff2d2d` |
| 电容 / 电感（`C`/`L`） | 电流 | 同上对数映射，蓝 / 土黄光晕 |
| 三极管 / MOS（`Q`/`M`） | 电流 | 同上对数映射，绿色光晕 |
| 开关（`S`） | **不是仿真数据**，是用户输入 | `switchAt()` 改 blade 角度 + 「闭合/断开」小字 + `data-sw`；与 timeline 无关（op/dc 也照样能点） |
| 其它（`V`/`I`/`X`/未知） | — | 不叠加（电压源没有支路电流可画，见 `live` 的口径） |

`applyLive()` 的静态快照路径**必须自己点亮 LED**（`ledAt(g, st)`）：M6 期间真出过
「`if (st.kind === 'light') continue;` 把发光全交给动画帧，而 op 分析没有动画帧 →
19mA 流过、灯是灰的」。这条已由 `tests_api` 的前端契约测试钉住。

## 导线电流流动

- 每条导线先聚合成「每个网络一条 `<path>`」（`ensureFlow()`）：同一网络的多段线并成一条路径，
  虚线在接缝处才不断；透明度/粗细由 class `f1…f6`（6 档）+ `--fi` 决定（`ensureFlowSheet()` 注入 CSS）
- `level` 用**本网络整条序列的峰值**归一化：强弱比例在时间轴上是真的，但**跨网络不可比**
  （一个大电流支路不会把小支路压没，代价是不同网络的粗细不能互相比较）
- **虚线跑动方向（`dir`）取自该网络电流的时间导数符号**（`flowAt()`：`next − prev` 的符号），
  稳态时固定为正向。**它不承载物理极性**——只有 `level`（电流大小）是数据。
  这一点必须写清，否则容易被读成「电流方向」
- 系统开了「减少动态效果」（`prefers-reduced-motion`）时停掉跑动的虚线，保留亮度/粗细

## 开关点击（`wireSwitchClicks`）

- 命中：`g[data-ref][data-kind="S"]`（点击或 Enter/空格），透明命中矩形 `[data-sw-hit]` 放大触控区域
- 行为：先切视觉（立刻反馈）→ 回调 `onSwitch(ref, closed)` → `main.js` 的 `toggleSwitch()`
  带着 `switch_states` **重跑仿真**（真切换，不是前端假动画）；仿真中再点只排队提示，不叠请求
- **必须独立于播放器**：`panels.js` 在**没有播放条的分支**里也要绑（op/dc 分析下也能点）。
  这条是回归项（`tests_api/test_switch_clickable_without_player`，按源码断言）
- 开关的闭/合状态是**输入量**（用户点的），不是仿真结果——所以它不参与「取不到数据就不显示」那条规矩

## `main.js` 侧的接线（给改前端的人）

- `animSpec(d, svg, kinds)`：**timeline 为空/点数 < 2/没有 series → 返回 `{timeline: null, …}`**，
  面板据此不建播放条；`kind !== 'tran'` 时即便有 timeline 也忽略（并 `console.warn`）
- `applyResult(d)`：`if (d.live && !d.timeline) svg = applyLive(svg, d.live)`——静态快照与逐帧动画
  **互斥**，否则「亮着又灭了」看起来像 bug
- 点击开关不能被电路图全屏的点击处理器抢走（`main.js` 里先判 `g[data-switch]` 与 `[data-anim]` 再判全屏）
