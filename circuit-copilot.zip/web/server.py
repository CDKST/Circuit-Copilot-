"""Web 服务：零依赖（纯 stdlib），直接跑在手机上。

为什么不用 FastAPI/Flask：这个项目要能在 Android/Termux 里一条命令起来，
多一个依赖就多一个装不上的理由。stdlib 的 ThreadingHTTPServer 完全够用。
"""

from __future__ import annotations

import json
import math
import os
import subprocess
import sys
import threading
import time
import traceback
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from copilot import agent, llm, report, topologies as T  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SESSIONS: dict[str, agent.Session] = {}
LOCK = threading.Lock()

# 后端插件：启动时加载。单个插件失败只记录，不影响服务启动。
try:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/..")
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "plugins"))
    import plugins.loader as PLUGINS
    _PLUGINS_INFO = PLUGINS.activate_all()
    _ok = sum(1 for v in _PLUGINS_INFO.values() if v.get("ok"))
    print(f"[plugins] 已加载 {_ok}/{len(_PLUGINS_INFO)} 个插件")
    for _pid, _v in _PLUGINS_INFO.items():
        if not _v.get("ok"):
            print(f"[plugins]   ✗ {_pid}: {_v.get('error')}")
        else:
            for _line in (_v.get("log") or []):
                print(f"[plugins]   {_pid}: {_line}")
except Exception as _e:
    print(f"[plugins] 插件系统不可用（已跳过）：{type(_e).__name__}: {_e}")
    PLUGINS = None


def _num(v):
    """转成 JSON 安全的数字：NaN/Inf/缺失一律 None。

    为什么必须做：Python 的 json.dumps 会把 NaN 写成裸 `NaN`，
    那是非法 JSON，浏览器 JSON.parse 直接抛异常——整条结果都丢了。
    """
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    return f


def serialize_mc(s: agent.Session) -> dict | None:
    """蒙特卡洛容差分析 → 前端 JSON（契约见任务书，报告侧同源）。

    items 只输出 spec 里出现的指标，顺序与 spec 一致——前端区间条按
    同一顺序渲染，指标核对表和容差卡片就能横向对齐。
    """
    mc = getattr(s, "mc", None)
    if mc is None or not getattr(mc, "runs", 0):
        return None

    dists = getattr(mc, "dists", {}) or {}
    tol_src = getattr(mc, "tol", {}) or {}
    # 只输出「这个拓扑真的在被扰动」的容差项：
    #   tol 表是全局默认值（含 GBW/A0/Vin），照抄会让人以为 RC 滤波器也拿运放容差算了。
    #   monte_carlo 的取值规则是 tol.get(参数kind) 否则 tol.get(参数name)，这里照抄同一规则。
    tol: dict[str, float] = {}
    try:
        topo = T.get(s.topology) if s.topology else None
    except KeyError:  # 拓扑被改名/删除时不要让整条结果陪葬
        topo = None
    if topo is not None:
        for p in topo.params:
            key = p.kind if p.kind in tol_src else p.name
            if key.startswith("_") or key in tol:
                continue
            v = _num(tol_src.get(key))
            if v is not None and v > 0:
                tol[key] = round(float(v), 6)
    if not tol:  # 兜底：拓扑信息不可用时退回元件三类
        for k in ("R", "C", "L"):
            v = _num(tol_src.get(k))
            if v is not None and v > 0:
                tol[k] = round(float(v), 6)

    items = []
    for r in s.rows:
        d = dists.get(r.key)
        unit = r.unit
        lo = _num(getattr(d, "lo", None)) if d is not None else None
        p5 = _num(getattr(d, "p5", None)) if d is not None else None
        mean = _num(getattr(d, "mean", None)) if d is not None else None
        p95 = _num(getattr(d, "p95", None)) if d is not None else None
        hi = _num(getattr(d, "hi", None)) if d is not None else None
        items.append({
            "key": r.key,
            "label": r.label,
            "unit": unit,
            "target": _num(r.target),
            "target_text": T.fmt_value(r.target, unit),
            "lo": lo,
            "p5": p5,
            "mean": mean,
            "p95": p95,
            "hi": hi,
            "p5_text": T.fmt_value(p5, unit) if p5 is not None else "—",
            "mean_text": T.fmt_value(mean, unit) if mean is not None else "—",
            "p95_text": T.fmt_value(p95, unit) if p95 is not None else "—",
        })

    return {
        "runs": int(getattr(mc, "runs", 0) or 0),
        "ok_runs": int(getattr(mc, "ok_runs", 0) or 0),
        "yield_pct": _num(getattr(mc, "yield_pct", None)),
        "failures": int(getattr(mc, "failures", 0) or 0),
        "tol": tol,
        "items": items,
    }


def serialize(s: agent.Session, *, with_curve: bool = True) -> dict:
    topo = T.get(s.topology) if s.topology else None
    out = {
        "request": s.request,
        "topology": s.topology,
        "topology_name": s.topology_name,
        "summary": topo.summary if topo else "",
        "passed": s.passed,
        "error": s.error,
        "reason": s.reason,
        "caveat": s.caveat,
        "review": s.review,
        # 结构化的可行性/能力边界问题，供界面分条渲染。
        # 只给一句 error 字符串的话，手机侧栏里就是一大坨右对齐文字，读不下去。
        "issues": ([i.as_dict() for i in s.feasibility.issues]
                   if getattr(s, "feasibility", None) is not None else []),
        "plan_source": s.plan_source,
        "sims": s.total_sims,
        "ms": round(s.total_ms),
        "spec": [
            {"key": r.key, "label": r.label, "unit": r.unit, "mode": r.mode,
             "target": r.target, "target_text": T.fmt_value(r.target, r.unit),
             "actual": None if (r.actual is None or r.actual != r.actual) else r.actual,
             "actual_text": T.fmt_value(r.actual, r.unit), "ok": r.ok}
            for r in s.rows
        ],
    }
    if s.best is not None:
        out["params"] = [{"label": k, "value": v} for k, v in s.best.human_params(topo)]
        out["bom"] = report.bom(s.best.netlist)
        out["netlist"] = s.best.netlist
        if with_curve:
            out["curve"] = report.curve_points(s.best)
    out["mc"] = serialize_mc(s)
    return out


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # 静音访问日志
        pass

    # ---------------- 安全闸 ----------------
    # 本地单用户服务，不设 token；但必须挡住两类浏览器侧攻击：
    # 1) 恶意网页跨站打 127.0.0.1:3081（simple request 不触发预检）→ Host 校验；
    #    DNS rebinding 的 Host 是攻击者域名，同样在这里被拒。
    # 2) 超大请求体把手机内存打爆 → Content-Length 预检。
    _MAX_BODY = 2_000_000     # 2MB：电路代码/插件源码远用不到这么多

    def _check_host(self) -> bool:
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
        if host in ("127.0.0.1", "localhost", "::1"):
            return True
        self._json({"error": f"Host 不允许：{host or '(缺失)'}；本服务只接受 127.0.0.1/localhost"},
                   403)
        return False

    def _pre_check_post(self) -> bool:
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            self._json({"error": "Content-Type 必须是 application/json"}, 415)
            return False
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n > self._MAX_BODY:
            self._json({"error": f"请求体过大（{n} 字节 > 上限 {self._MAX_BODY}）"}, 413)
            return False
        return True

    # ---------------- 基础 ----------------
    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode())

    def _read_body(self) -> dict:
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return {}
        if not n:
            return {}
        if n > self._MAX_BODY:      # 双保险：入口预检漏掉时这里也不读进内存
            self._json({"error": "请求体过大"}, 413)
            raise ValueError("请求体过大")
        try:
            return json.loads(self.rfile.read(n).decode())
        except Exception:
            return {}

    # ---------------- 路由 ----------------
    def do_GET(self):
        if not self._check_host():
            return
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            with open(os.path.join(HERE, "index.html"), "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        elif path in ("/ide", "/ide/"):
            try:
                with open(os.path.join(HERE, "ide", "index.html"), "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self._json({"error": "web/ide/index.html 未部署"}, 404)
        elif path.startswith("/ide/"):
            # IDE 静态资源（style.css / editor.js / panels.js / main.js）。
            # realpath 断言而不是挡字面量 ".."：编码变体（%2e%2e）不该靠运气挡住。
            rel = path[len("/ide/"):]
            fp = os.path.realpath(os.path.join(HERE, "ide", rel))
            ide_root = os.path.realpath(os.path.join(HERE, "ide")) + os.sep
            if not fp.startswith(ide_root) or not os.path.isfile(fp):
                self._json({"error": "path 非法"}, 400)
                return
            rel = os.path.relpath(fp, ide_root)
            ctype = {"css": "text/css; charset=utf-8",
                     "js": "text/javascript; charset=utf-8",
                     "html": "text/html; charset=utf-8",
                     "json": "application/json; charset=utf-8"}.get(rel.rsplit(".", 1)[-1], "text/plain; charset=utf-8")
            try:
                with open(fp, "rb") as f:
                    self._send(200, f.read(), ctype)
            except FileNotFoundError:
                self._json({"error": f"资源不存在: {rel}"}, 404)
        elif path == "/api/plugins":
            if PLUGINS is None:
                self._json({"ok": False, "plugins": [], "error": "插件系统未加载"})
            else:
                self._json({"ok": True, "plugins": PLUGINS.list_for_api()})
        elif path.startswith("/plugins/"):
            # 插件静态资源（ui.js 等）。loader 里已挡掉 ../ 穿越。
            if PLUGINS is None:
                self._json({"error": "插件系统未加载"}, 404)
                return
            rest = path[len("/plugins/"):]
            pieces = rest.split("/", 1)
            if len(pieces) != 2:
                self._json({"error": "路径应为 /plugins/<id>/<file>"}, 400)
                return
            got = PLUGINS.read_asset(pieces[0], pieces[1])
            if got is None:
                self._json({"error": f"插件资源不存在: {rest}"}, 404)
                return
            body, ctype = got
            self._send(200, body, ctype)
        elif path in ("/ccl", "/ccl.html"):
            # UI 已重构为 VS Code 风格 IDE，旧单页改为跳转（文件保留作参考）
            self.send_response(302)
            self.send_header("Location", "/ide")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        elif path in ("/ccl.html.old",):
            try:
                with open(os.path.join(HERE, "ccl.html"), "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self._json({"error": "ccl.html 未部署"}, 404)
        elif path.startswith("/api/ccl/report/"):
            rid = path.rsplit("/", 1)[-1]
            try:
                import ccl_api
            except ImportError:
                sys.path.insert(0, HERE)
                import ccl_api
            rep = ccl_api.get_report(rid)
            if not rep:
                self._json({"error": "报告不存在或已过期，请重新生成"}, 404)
                return
            body = rep["markdown"].encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/markdown; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            # ⚑ 中文电路名会让 send_header 抛 UnicodeEncodeError（HTTP 头是 latin-1），
            # 连接直接断掉、前端什么都拿不到，而状态栏照样写「报告已导出」——
            # Android 走 window.open 这条分支，**必现静默失败**。
            # 按 RFC 5987 用 filename* 传 UTF-8，另给一个 ASCII 兜底名。
            _fn = rep["filename"]
            _ascii = _fn.encode("ascii", "replace").decode("ascii").replace("?", "_")
            self.send_header("Content-Disposition",
                             'attachment; filename="%s"; filename*=UTF-8\'\'%s'
                             % (_ascii, quote(_fn, safe="")))
            self.end_headers()
            self.wfile.write(body)
            return
        elif path in ("/api/ccl/blocks", "/api/ccl/blocks/"):
            try:
                import ccl_api
            except ImportError:
                sys.path.insert(0, HERE)
                import ccl_api
            self._json(ccl_api.blocks_catalog())
        elif path == "/api/ccl/example":
            try:
                import ccl_examples
            except ImportError:
                sys.path.insert(0, HERE)
                import ccl_examples
            self._json(ccl_examples.payload())
        elif path == "/api/health":
            self._json(agent.diagnose())
        elif path == "/api/config":
            # 读当前 AI 配置。**key 永不回传明文**，只告诉前端有没有配。
            try:
                cfg = llm.load_config()
                k = cfg.get("key") or ""
                masked = (k[:6] + "…" + k[-4:]) if len(k) > 12 else ("已配置" if k else "")
                out = {
                    "ok": True,
                    "base": cfg.get("base") or "",
                    "model": cfg.get("model") or "",
                    "hasKey": bool(k),
                    "keyMasked": masked,
                }
                # ?test=1 做一次**真实**的极小调用 —— 光"保存成功"不等于"能用"
                if "test=1" in (self.path or ""):
                    if not k:
                        out["test"] = {"ok": False, "error": "还没有填 API Key"}
                    else:
                        t0 = time.time()
                        try:
                            r = llm.LLM().chat(
                                [{"role": "user", "content": "只回复两个字：通了"}],
                                max_tokens=12)
                            out["test"] = {"ok": True,
                                           "reply": (r or "").strip()[:20],
                                           "ms": int((time.time() - t0) * 1000)}
                        except Exception as e:
                            out["test"] = {"ok": False,
                                           "error": f"{type(e).__name__}: {e}",
                                           "ms": int((time.time() - t0) * 1000)}
                self._json(out)
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 500)
        elif path == "/api/catalog":
            self._json(T.catalog())
        elif path.startswith("/api/report/"):
            sid = path.rsplit("/", 1)[-1]
            s = SESSIONS.get(sid)
            if not s:
                self._json({"error": "报告不存在或已过期，请重新生成设计"}, 404)
                return
            body = report.markdown(s).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/markdown; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            # ASCII 文件名：中文拓扑名走前端 blob 下载时的 filename 参数
            self.send_header("Content-Disposition",
                             f'attachment; filename="circuit-report-{sid}.md"')
            self.end_headers()
            self.wfile.write(body)
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        if not self._check_host() or not self._pre_check_post():
            return
        path = urlparse(self.path).path
        if path == "/api/design":
            self._design()
        elif path == "/api/bench/run":
            self._bench_run()
        elif path == "/api/ccl/run":
            self._ccl_run()
        elif path == "/api/ccl/ai":
            self._ccl_ai()
        elif path == "/api/ccl/report":
            self._ccl_report()
        elif path == "/api/plugin/draft":
            # AI 生成插件**草稿**（不落盘）。校验不过就不返回 ok。
            body = self._read_body()
            req = (body.get("request") or "").strip()
            if not req:
                self._json({"ok": False, "error": "请输入想做的插件"}, 400)
                return
            try:
                if os.path.join(HERE, "..") not in sys.path:
                    sys.path.insert(0, os.path.join(HERE, ".."))
                from ccl.ai import plugin_gen as PG
                d = PG.draft(req)
                self._json(d.to_dict())
            except Exception as e:
                traceback.print_exc()
                self._json({"ok": False, "error": f"{type(e).__name__}: {e}"}, 500)
        elif path == "/api/plugin/install":
            body = self._read_body()
            try:
                if os.path.join(HERE, "..") not in sys.path:
                    sys.path.insert(0, os.path.join(HERE, ".."))
                from ccl.ai import plugin_gen as PG
                out = PG.install(
                    pid=body.get("id") or "",
                    plugin_json=body.get("plugin_json") or "",
                    backend_py=body.get("backend_py") or "",
                    ui_js=body.get("ui_js") or "",
                )
                self._json(out)
            except Exception as e:
                traceback.print_exc()
                self._json({"ok": False, "error": f"{type(e).__name__}: {e}"}, 500)
        elif path == "/api/config":
            body = self._read_body()
            try:
                p = llm.save_config(
                    key=(body.get("key") or "").strip(),
                    base=(body.get("base") or "").strip(),
                    model=(body.get("model") or "").strip(),
                )
                self._json({"ok": True, "path": p, **agent.diagnose()})
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 500)
        else:
            self._json({"error": "not found"}, 404)

    # ---------------- 设计（NDJSON 流式） ----------------
    def _design(self):
        body = self._read_body()
        request = (body.get("text") or "").strip()
        if not request:
            self._json({"error": "请输入电路需求"}, 400)
            return
        use_llm = body.get("use_llm", True)
        sid = uuid.uuid4().hex[:12]

        # NDJSON 流式：无 Content-Length，必须显式关连接，否则客户端读到天荒地老
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()

        def write(obj):
            try:
                self.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                pass  # 用户点了「停止」/ 关掉了页面：正常现象，不写 traceback

        stage_label = {
            "understand": "解析电路需求",
            "design": "推导初始参数",
            "simulate": "参数寻优与仿真",
            "tolerance": "容差分析（蒙特卡洛）",
            "review": "生成工程评审",
            "done": "完成",
        }

        def progress(stage: str, payload: dict):
            msg = {"type": "stage", "stage": stage, "label": stage_label.get(stage, stage)}
            if stage == "simulate":
                msg["done"] = payload.get("done")
                msg["total"] = payload.get("total")
            s = payload.get("session")
            if s and s.topology:
                msg["topology_name"] = s.topology_name
            write(msg)

        try:
            s = agent.run(request, use_llm=use_llm, progress=progress)
            with LOCK:
                SESSIONS[sid] = s
            write({"type": "result", "id": sid, "data": serialize(s)})
        except Exception as e:
            traceback.print_exc()
            write({"type": "error", "error": f"{type(e).__name__}: {e}"})


    # ---------------- CCL：报告导出 ----------------
    def _ccl_report(self):
        body = self._read_body()
        code = body.get("code") or ""
        if not code.strip():
            self._json({"ok": False, "error": "代码为空"}, 400)
            return
        try:
            import ccl_api
        except ImportError:
            sys.path.insert(0, HERE)
            import ccl_api
        try:
            out = ccl_api.build_report(code, body.get("analysis"),
                                       switch_states=(body.get("switch_states") or None) or {})
        except Exception as e:
            traceback.print_exc()
            out = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        self._json(out)

    # ---------------- CCL：AI（生成 / 解释 / 修复） ----------------
    def _ccl_ai(self):
        body = self._read_body()
        action = (body.get("action") or "generate").strip()
        try:
            import ccl_api
        except ImportError:
            sys.path.insert(0, HERE)
            import ccl_api
        try:
            if action == "generate":
                out = ccl_api.ai_generate(body.get("prompt") or "", model=body.get("model"))
            elif action == "fix":
                out = ccl_api.ai_fix(body.get("code") or "",
                                     request=body.get("prompt") or "",
                                     model=body.get("model"))
            elif action == "explain":
                out = ccl_api.ai_explain(body.get("code") or "",
                                         body.get("analysis") or {},
                                         model=body.get("model"))
            else:
                out = {"ok": False, "error": f"未知 action {action!r}"}
        except Exception as e:
            traceback.print_exc()
            out = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        self._json(out)

    # ---------------- 基准：AI 拦截能力量化 ----------------
    def _bench_run(self):
        """跑确定性闸门层基准（bench/run_gates.py，约 1.5s，不需要 Key）。

        子进程退出码**不是**成败信号：基准发现漏网时退出码是 1（这是设计——
        「有漏网」正是要展示给用户看的东西）。只要结果 JSON 有效就算跑成功。
        真实模型层（run_llm.py）要几分钟且依赖网关，不适合「点一下就等」，
        只读它的最近一次存档 results_llm.json 做展示。
        """
        root = os.path.dirname(HERE)
        script = os.path.join(root, "bench", "run_gates.py")
        try:
            r = subprocess.run(
                [sys.executable, script],
                cwd=root, capture_output=True, text=True, timeout=120)
        except subprocess.TimeoutExpired:
            self._json({"ok": False, "error": "基准子进程超时（>120s）"}, 500)
            return
        except Exception as e:
            self._json({"ok": False, "error": f"{type(e).__name__}: {e}"}, 500)
            return
        gp = os.path.join(root, "bench", "results_gates.json")
        if not os.path.isfile(gp):
            tail = (r.stderr or r.stdout or "")[-400:]
            self._json({"ok": False, "error": f"基准没有产出结果文件。{tail}"}, 500)
            return
        try:
            with open(gp, encoding="utf-8") as f:
                gates = json.load(f)
        except Exception as e:
            self._json({"ok": False, "error": f"结果文件解析失败: {e}"}, 500)
            return
        # llm 层：只读存档，不在这里重跑。skipped（端点不可用）就不展示。
        llm = None
        lp = os.path.join(root, "bench", "results_llm.json")
        try:
            with open(lp, encoding="utf-8") as f:
                d = json.load(f)
            if not d.get("skipped"):
                llm = d
        except Exception:
            pass
        self._json({"ok": True, "gates": gates, "llm": llm})

    # ---------------- CCL：写代码跑电路 ----------------
    def _ccl_run(self):
        body = self._read_body()
        code = body.get("code") or ""
        if not code.strip():
            self._json({"ok": False, "error": "代码为空"}, 400)
            return
        try:
            import ccl_api
        except ImportError:
            sys.path.insert(0, HERE)
            try:
                import ccl_api
            except Exception as e:
                self._json({"ok": False, "error": "CCL 后端不可用：%s" % e}, 500)
                return
        try:
            # require：这段代码原本要满足的需求（AI 生成时记下的）。
            # 有它才做「需求 vs 实测」对账；手写代码没有这个字段，行为不变。
            result = ccl_api.execute(code, body.get("analysis") or {},
                                     require=(body.get("require") or None),
                                     switch_states=(body.get("switch_states") or None))
        except Exception as e:
            traceback.print_exc()
            result = {"ok": False, "error": "%s: %s" % (type(e).__name__, e), "stage": "server"}
        self._json(result)


def main(port: int = 3081, host: str = "127.0.0.1"):
    srv = ThreadingHTTPServer((host, port), Handler)
    diag = agent.diagnose()
    print(f"Circuit Copilot 已启动  http://{host}:{port}")
    print(f"  ngspice   : {diag['ngspice']}")
    print(f"  拓扑数    : {diag['topologies']}")
    print(f"  大模型    : {'已配置 ' + diag['llm_model'] if diag['llm_configured'] else '未配置（规则模式）'}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 3081)
