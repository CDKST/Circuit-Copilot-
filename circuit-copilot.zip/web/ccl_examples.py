"""CCL 页面的示例代码（前端「示例」按钮用）。

单独一个文件是为了让 server.py 保持干净，
而且示例代码必须是**能真实跑通的**——改动 devices/compile 后要重新跑一遍验证。
"""

from __future__ import annotations

EXAMPLES = [
    {
        "title": "RC 一阶低通",
        "analysis": {"kind": "ac", "f_start": 1, "f_stop": 1e6, "points": 100},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 一阶 RC 低通：fc = 1/(2*pi*R*C) = 1/(2*pi*1.6k*100n) = 995 Hz\n"
            "    c = Circuit(\"rc_lowpass\")\n"
            "    c.V(\"in\", GND, ac=1)\n"
            "    c.R(\"in\", \"out\", 1.6e3)\n"
            "    c.C(\"out\", GND, 100e-9)\n"
            "    return c\n"
        ),
    },
    {
        "title": "运放同相放大",
        "analysis": {"kind": "ac", "f_start": 1, "f_stop": 1e7, "points": 120},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 同相放大：增益 = 1 + R2/R1 = 10；闭环带宽约 GBW/10 = 130kHz\n"
            "    c = Circuit(\"noninv_amp\")\n"
            "    c.V(\"src\", GND, ac=1)\n"
            "    c.R(\"sum\", GND, 1e3)\n"
            "    c.R(\"out\", \"sum\", 9e3)\n"
            "    c.OpAmp(\"src\", \"sum\", \"out\", gbw=1.3e6)\n"
            "    return c\n"
        ),
    },
    {
        "title": "Sallen-Key 二阶低通",
        "analysis": {"kind": "ac", "f_start": 10, "f_stop": 1e6, "points": 120},
        "code": (
            "from ccl import Circuit, GND\n"
            "import math\n"
            "\n"
            "def build():\n"
            "    # 二阶低通 10kHz，Q=0.707（巴特沃斯）\n"
            "    fc, Q = 10e3, 0.707\n"
            "    c2 = 10e-9\n"
            "    c1 = c2 * (2 * Q) ** 2          # 单位增益 SK：Q = 0.5*sqrt(C1/C2)\n"
            "    r = 1 / (2 * math.pi * fc * math.sqrt(c1 * c2))\n"
            "    c = Circuit(\"sallen_key_lp\")\n"
            "    c.V(\"in\", GND, ac=1)\n"
            "    c.R(\"in\", \"n1\", r)\n"
            "    c.R(\"n1\", \"n2\", r)\n"
            "    c.C(\"n1\", \"out\", c1)\n"
            "    c.C(\"n2\", GND, c2)\n"
            "    c.OpAmp(\"n2\", \"out\", \"out\", gbw=1e6)\n"
            "    return c\n"
        ),
    },
    {
        "title": "二极管正向压降",
        "analysis": {"kind": "op"},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 5V 经 1k 串 1N4148，看直流工作点的正向压降（约 0.65V）\n"
            "    c = Circuit(\"diode_fwd\")\n"
            "    c.V(\"in\", GND, dc=5)\n"
            "    c.R(\"in\", \"a\", 1e3)\n"
            "    c.D(\"a\", GND, \"D1N4148\")\n"
            "    return c\n"
        ),
    },
    {
        "title": "BJT 共射偏置",
        "analysis": {"kind": "op"},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 2N3904 共射偏置：看 Vbe / Vce 是否落在放大区\n"
            "    c = Circuit(\"bjt_ce\")\n"
            "    c.V(\"vcc\", GND, dc=5)\n"
            "    c.R(\"vcc\", \"b\", 100e3)\n"
            "    c.R(\"vcc\", \"c\", 100)\n"
            "    c.Q(\"c\", \"b\", GND, \"Q2N3904\")\n"
            "    return c\n"
        ),
    },
    {
        "title": "PULSE + RC 阶跃",
        "analysis": {"kind": "tran", "t_step": 1e-6, "t_stop": 5e-4},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 方波驱动 RC：t=RC 时电容电压应到 63.2%\n"
            "    c = Circuit(\"pulse_rc\")\n"
            "    c.PULSE(\"in\", GND, v1=0, v2=5, pw=1e-3, per=2e-3)\n"
            "    c.R(\"in\", \"out\", 1e3)\n"
            "    c.C(\"out\", GND, 100e-9)\n"
            "    return c\n"
        ),
    },
    {
        "title": "带规格断言的 RC 低通（M3）",
        "analysis": {"kind": "ac", "f_start": 1, "f_stop": 1e5, "points": 100},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 声明规格：改元件后跑一遍就知道有没有坏\n"
            "    c = Circuit(\"rc_checked\")\n"
            "    c.V(\"in\", GND, ac=1)\n"
            "    c.R(\"in\", \"out\", 1.6e3)\n"
            "    c.C(\"out\", GND, 100e-9)\n"
            "    c.expect(\"fc\", \"out\", 1e3, tol=0.05)        # 截止 1kHz ±5%\n"
            "    c.expect(\"gain\", \"out\", 1.0, tol=0.02)       # 通带增益 1 倍\n"
            "    c.expect(\"peak_db\", \"out\", 0.5, mode=\"max\", tol=0.5)\n"
            "    return c\n"
        ),
    },
    {
        "title": "子电路块组合（M5）",
        "analysis": {"kind": "ac", "f_start": 1, "f_stop": 1e6, "points": 120},
        "code": (
            "from ccl import Circuit, GND\n"
            "from ccl.blocks import BLOCKS\n"
            "\n"
            "def build():\n"
            "    # 一级 RC 低通 + 一级同相放大，按端口名连起来\n"
            "    c = Circuit(\"two_stage\")\n"
            "    c.V(\"src\", GND, ac=1)\n"
            "    c.use_ports(BLOCKS[\"rc_lowpass\"](fc=1e3), {\"in\": \"src\", \"out\": \"n1\"})\n"
            "    c.use_ports(BLOCKS[\"noninv_amp\"](gain=10, gbw=1.3e6), {\"in\": \"n1\", \"out\": \"y\"})\n"
            "    c.expect(\"gain\", \"y\", 10, tol=0.05)\n"
            "    return c\n"
        ),
    },
    {
        "title": "正弦波激励",
        "analysis": {"kind": "tran", "t_step": 2e-6, "t_stop": 2e-3},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 1kHz 正弦，幅度 2V\n"
            "    c = Circuit(\"sine\")\n"
            "    c.SIN(\"in\", GND, vo=0, va=2, freq=1e3)\n"
            "    c.R(\"in\", GND, 1e3)\n"
            "    return c\n"
        ),
    },
    {
        "title": "Twin-T 陷波（50Hz 工频）",
        "analysis": {"kind": "ac", "f_start": 1, "f_stop": 5000, "points": 800},
        "code": (
            "from ccl import Circuit, GND\n"
            "\n"
            "def build():\n"
            "    # 无源 Twin-T 陷波：掐掉 50Hz 工频，两侧放行。\n"
            "    # 对称条件是全部：R1=R2=R、C1=C2=C、C3=2C、R3=R/2。\n"
            "    # 写成 C3=C/2、R3=2R 只会得到 -5dB 的“小坑”，工频照样过。\n"
            "    # 无源 Twin-T 的 Q 固定 0.25（带宽 = 4*f0），凹陷深度取决于元件匹配。\n"
            "    f0, C = 50.0, 100e-9\n"
            "    R = 1.0 / (2 * 3.141592653589793 * f0 * C)\n"
            "    c = Circuit(\"notch50\")\n"
            "    c.V(\"in\", GND, ac=1)\n"
            "    c.R(\"in\", \"a\", R)\n"
            "    c.R(\"a\", \"t\", R)\n"
            "    c.C(\"a\", GND, 2 * C)        # C3 = 2C\n"
            "    c.C(\"in\", \"b\", C)\n"
            "    c.C(\"b\", \"t\", C)\n"
            "    c.R(\"b\", GND, R / 2)        # R3 = R/2\n"
            "    c.OpAmp(\"t\", \"out\", \"out\", gbw=1e6)\n"
            "    # 断言：50Hz 处幅度必须被压到 0.02 以下（相对通带约 -34dB）\n"
            "    # expect 支持 fc/gain/peak_db/q/bw/v/i/p/value_at；凹陷深度用 value_at 表达\n"
            "    c.expect(\"value_at\", \"out\", 0.02, mode=\"max\", at=50.0)\n"
            "    return c\n"
        ),
    },
    {
        "title": "子电路块：Sallen-Key 高通（积木组合）",
        "analysis": {"kind": "ac", "f_start": 10, "f_stop": 1e6, "points": 200},
        "code": (
            "from ccl import Circuit, GND\n"
            "from ccl.blocks import BLOCKS\n"
            "\n"
            "def build():\n"
            "    # 用积木组合：二阶高通 fc=5kHz，Q=0.707（巴特沃斯）\n"
            "    # BLOCKS 里 12 种积木，全部参数化且声明了端口\n"
            "    c = Circuit(\"hp_block\")\n"
            "    c.V(\"src\", GND, ac=1)\n"
            "    c.use_ports(BLOCKS[\"sallen_key_highpass\"](fc=5e3, q=0.707),\n"
            "                {\"in\": \"src\", \"out\": \"out\"})\n"
            "    c.expect(\"fc\", \"out\", 5e3, tol=0.10)\n"
            "    return c\n"
        ),
    },
]


def payload() -> dict:
    return {"examples": EXAMPLES}
