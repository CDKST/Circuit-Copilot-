"""CCL Web 接口：把「写代码 → 仿真 → 看波形」搬到浏览器里。

刻意做成独立模块而不是塞进 server.py：
- server.py 是参数化工具（一句话出电路）的入口，两者理念不同，混在一起会互相拖累
- 这里只依赖 `ccl`，参数化工具坏了也不影响它，反之亦然
"""

from __future__ import annotations

import json
import math

# 报告按 id 缓存：Android WebView 里 Blob+a[download] 不落地（实测），
# 必须走「同源 URL + Content-Disposition」才能触发系统下载器。
import itertools as _it
_REPORTS: dict[str, dict] = {}
_REPORT_IDS = _it.count(1)


def _num(v, nd: int = 6):
    """JSON 里绝不能出现 NaN/Inf —— 浏览器 JSON.parse 会直接抛异常，整条结果全丢。"""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(f):
        return None
    return round(f, nd)


def _downsample(xs: list, ys: list, n: int = 400):
    """波形面板用的降采样。**保峰**（每桶取 min/max 两点），不是均匀取下标。

    为什么不能用均匀取：实测 1µs 步长 + 1ns 边沿的脉冲，峰值 4.9975mA 会被抽成
    3.4220mA（丢 31.5%）；50ns 的窄脉冲（10 万点）更是从 4.76mA 变成 **0**，
    用户看到的是一条平线 —— 这是**显示错误**，不是动画问题。
    35 器件电路里有 11 条曲线丢 >1%，最坏丢 45%。

    min/max 包络是示波器和波形查看器的标准做法：每桶保留极值，包络一定不丢。
    """
    if len(xs) <= n:
        return xs, ys
    n_bucket = max(2, n // 2)
    step = len(xs) / n_bucket
    idx: list[int] = []
    for b in range(n_bucket):
        lo = int(b * step)
        hi = min(max(lo + 1, int((b + 1) * step)), len(xs))
        if lo >= len(xs):
            break
        y_lo = y_hi = lo
        v_lo = v_hi = ys[lo]
        for k in range(lo + 1, hi):
            v = ys[k]
            if v > v_hi:
                v_hi, y_hi = v, k
            if v < v_lo:
                v_lo, y_lo = v, k
        idx.append(y_hi)
        if y_lo != y_hi:
            idx.append(y_lo)
    idx.sort()
    if idx and idx[-1] != len(xs) - 1:
        idx.append(len(xs) - 1)
    return [xs[i] for i in idx], [ys[i] for i in idx]


#: 瞬态时间序列的点数窗口（契约要求 120~400，少了波形失真、多了前端动画用不着）
_TIMELINE_MIN_POINTS = 120
_TIMELINE_MAX_POINTS = 400


def _downsample_idx(n_total: int, n_keep: int,
                    probes: list[list[float]] | None = None) -> list[int]:
    """抽样的下标序列。**保峰**（每桶取归一化后的 max/min 两点），不是均匀取。

    为什么不能用均匀取下标：实测 10ns 步长、1ms 总长（10 万点）里一个 2µs 的脉冲，
    均匀抽 400 点后**一个非零点都不剩**（原始 214 个非零点 → 0 个），
    动画会显示"电路从没动过"。

    ⚑ 为什么必须**按每条曲线自己的幅度归一化**再比较极值：
    不同探针量纲不同（节点电压 ~1 伏、支路电流 ~1e-2 安）。直接拿原始值比较大小，
    电压永远压过电流 —— 于是「电压恒定、电流有尖峰」的电路里，桶内挑中的是电压的
    某个点，电流尖峰被丢掉。归一化后每条曲线在自己的尺度上都贡献 0~1，
    尖峰一定能赢下它所在的桶。顺带解决点数塌缩（某条曲线在桶内是常量时，
    它的 min/max 落在同一下标，不再把整桶拉成 1 点）。

    每桶最多 2 点（max 位置 + min 位置），所以总点数 ≤ 2×n_keep/2 ≈ n_keep；
    末点必取（否则时间轴会短一截，实测丢 0.24% 时长）。
    """
    if n_total <= n_keep:
        return list(range(n_total))
    n_keep = max(4, int(n_keep))
    if not probes:
        step = n_total / n_keep
        out = [min(int(i * step), n_total - 1) for i in range(n_keep)]
        if out and out[-1] != n_total - 1:
            out[-1] = n_total - 1
        return out

    # 每条探针的全局幅度，用于归一化（恒为常量的探针幅度记 0，后面跳过它）
    scales: list[float] = []
    for ys in probes:
        lo_v = min(ys) if ys else 0.0
        hi_v = max(ys) if ys else 0.0
        scales.append((hi_v - lo_v) or 0.0)

    # 每桶最多 2 点，末尾还要补 1 个末点 → 桶数取 (n_keep-1)//2，
    # 保证总点数**不超过** n_keep（契约 120~400）
    n_bucket = max(2, (n_keep - 1) // 2)
    step = n_total / n_bucket
    picked: list[int] = []
    for b in range(n_bucket):
        lo = int(b * step)
        hi = min(max(lo + 1, int((b + 1) * step)), n_total)
        if lo >= n_total:
            break
        best_hi_k, best_hi_v = None, -1e300
        best_lo_k, best_lo_v = None, 1e300
        for ys, sc in zip(probes, scales):
            if sc <= 0.0:
                continue                      # 常数曲线：没有"峰"可保，跳过
            seg = ys[lo:hi]                   # C 级切片
            if not seg:
                continue
            v_hi = max(seg)
            v_lo = min(seg)
            n_hi = (v_hi - min(ys)) / sc      # 归一化到 0~1
            n_lo = (v_lo - min(ys)) / sc
            if n_hi > best_hi_v:
                best_hi_v, best_hi_k = n_hi, seg.index(v_hi) + lo
            if n_lo < best_lo_v:
                best_lo_v, best_lo_k = n_lo, seg.index(v_lo) + lo
        if best_hi_k is None:
            best_hi_k = lo
        picked.append(best_hi_k)
        # 每桶要给出两个**不同**的样本，否则点数会塌到一半（实测 400 预算只剩 200）：
        # 某条曲线在桶内是常量、或峰谷恰好落在同一下标时，max 与 min 会重合。
        # 这时补一个桶中点（真实样本，不插值）—— 极值不会因此丢失，只是多一个点。
        second = best_lo_k if (best_lo_k is not None and best_lo_k != best_hi_k) else None
        if second is None:
            mid = (lo + hi - 1) // 2
            if mid != best_hi_k:
                second = mid
        if second is not None:
            picked.append(second)
    picked.sort()
    if picked and picked[-1] != n_total - 1:
        picked.append(n_total - 1)
    return picked


def _current_key(ref: str, waves) -> str | None:
    """在 rawfile 的波形名里找这个器件的支路电流（`i(@r1[i])` / `i(@d1[id])`）。

    找不到就返回 None —— 调用方据此**不放**这个器件（契约：取不到就不显示，
    绝不填 0）。
    """
    ref = str(ref).strip().lower()
    for name in waves:
        if not (name.startswith("i(@") and name.endswith(")")):
            continue
        try:
            inner = name[3: name.index("[")]
        except ValueError:
            continue
        if inner == ref:
            return name
    # 电压源的支路电流在 rawfile 里叫 `i(v1)`（不是 `i(@v1[i])`），
    # 它**本来就有**，不需要 save。没有这一步，挂着电源的网络就永远没有电流数据
    # → 前端「电流沿导线流动」在那几段永远是空的（实测）。
    for name in waves:
        if name.lower() == "i(" + ref + ")":
            return name
    return None


def collect_timeline(circuit, solution, *, max_points: int = _TIMELINE_MAX_POINTS) -> dict | None:
    """瞬态时间序列 → JSON，供前端按帧播放物理动画。

    **只搬运真实仿真数据**：`t` 是 ngspice 的时间轴，`series[ref]` 里的每条
    曲线都是 rawfile 里那一条波形降采样后的结果。取不到支路电流的器件
    **不放进 series**（不填 0 —— 填 0 会让前端演一个「电流为零」的假象）。

    非 tran 分析返回 None（ac 是频域，没有时域序列可演）。
    """
    if solution is None or getattr(solution, "kind", "") != "tran":
        return None

    waves = getattr(solution, "waves", None) or {}
    t_full = list(getattr(solution, "x", []) or [])
    if not t_full:
        return None

    n = len(t_full)
    keep = max(_TIMELINE_MIN_POINTS, min(int(max_points), _TIMELINE_MAX_POINTS))
    # 保峰抽样需要"原始波形"当探针：把每个器件的支路电流与每个节点的电压都喂进去，
    # 格子里的尖峰/振铃才不会因为均匀取点被跳过。
    # 探针只留少量：支路电流优先（尖峰最常出现在电流上），再补前几个节点电压。
    # 全部波形都当探针没有额外收益，却要把每条波形都转一遍（10 万点 × 26 条）。
    probes: list[list[float]] = []
    _cur_names = [nm for nm in waves if nm.startswith("i(")]
    _vol_names = [nm for nm in waves if nm.startswith("v(")]
    for nm in (_cur_names + _vol_names)[:8]:
        w = waves[nm]
        try:
            ys = w.real() if hasattr(w, "real") else [complex(x).real for x in w.y]
        except Exception:
            continue
        if len(ys) >= n:
            probes.append(ys)
    idx = _downsample_idx(n, keep, probes)
    t_out = [_num(t_full[i], 12) for i in idx]

    def node_series(node):
        """节点对地电压序列；节点不存在返回 None。"""
        try:
            w = solution.v(node)
        except Exception:
            return None
        if len(w.y) < n:
            return None
        # ⚑ 只转换被保留的那 200 个点，别把 10 万点全转一遍再扔掉
        #（每个节点全量 .real 转换，10 万点 × N 节点，实测占 collect_timeline 大头）
        return [_num(complex(w.y[i]).real, 9) for i in idx]

    def is_gnd(node):
        return str(node).lower() in ("0", "gnd")

    series: dict[str, dict] = {}
    for comp in circuit.components:
        ref = str(comp.ref)
        key = _current_key(ref, waves)
        cur = None
        if key is not None:
            wv = waves[key]
            if len(wv.y) >= n:
                cur = [_num(complex(wv.y[i]).real, 9) for i in idx]

        # 两端电压：第一个引脚对地电压 − 第二个引脚对地电压（地按 0V 计）
        nodes = [str(x) for x in comp.nodes()]
        volt = None
        if len(nodes) >= 2:
            pa = [0.0] * len(idx) if is_gnd(nodes[0]) else node_series(nodes[0])
            pb = [0.0] * len(idx) if is_gnd(nodes[1]) else node_series(nodes[1])
            if pa is not None and pb is not None:
                volt = [_num(a - b, 9) for a, b in zip(pa, pb)]

        if cur is None and volt is None:
            continue                      # 两条都取不到 → 这个器件根本不进 series
        item: dict = {}
        if cur is not None:
            item["current"] = cur
        if volt is not None:
            item["voltage"] = volt
        item["kind"] = str(getattr(comp, "kind", "")).upper()
        series[str(ref).lower()] = item

    if not series:
        return None
    # 时间步长：真实相邻采样间隔（时间轴本身不均匀时取中位数，比端点差值稳）
    steps = sorted(t_full[i + 1] - t_full[i] for i in range(n - 1)) if n > 1 else []
    dt = steps[len(steps) // 2] if steps else (getattr(solution, "x", [0.0]) or [0.0])[-1]
    return {
        "t": t_out,
        "dt": _num(dt, 12),
        "points": len(t_out),
        "raw_points": n,
        "t_stop": _num(t_full[-1], 12),
        "series": series,
    }


def _human_value(comp) -> str:
    """器件的显示值：电阻 1.6kΩ、电容 100nF、电源 DC 5V / AC 1V……"""
    kind = comp.kind.upper()

    # 时域激励：把 spec 摊开成人话（原始数字对用户没意义）
    spec = getattr(comp, "spec", None)
    if isinstance(spec, dict) and spec:
        unit = "A" if kind == "I" else "V"
        if "pw" in spec:
            return (f"PULSE {spec['v1']:g}→{spec['v2']:g}{unit} "
                    f"@ {spec['per'] * 1e3:g}ms")
        if "freq" in spec:
            return f"SIN {spec['va']:g}{unit} @ {spec['freq']:g}Hz"

    # 独立源：dc / ac 两个分量都写出来
    if hasattr(comp, "dc") and hasattr(comp, "ac"):
        unit = "A" if kind == "I" else "V"
        parts = []
        if getattr(comp, "dc", 0):
            parts.append(f"DC {comp.dc:g}{unit}")
        if getattr(comp, "ac", 0):
            parts.append(f"AC {comp.ac:g}{unit}")
        return " ".join(parts) or f"DC 0{unit}"

    v = comp.value
    if v is None:
        return comp.model or ""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)

    # 人话单位用已验证的 copilot.elements（避免自己再写一套格式化）
    try:
        from copilot import elements as E
        if kind == "R":
            return E.human_r(v)
        if kind == "C":
            return E.human_c(v)
        if kind == "L":
            return E.human_l(v)
    except Exception:
        pass
    return f"{v:.6g}"


def describe_circuit(circuit) -> dict:
    """电路结构 → JSON（器件表 + 节点表）。"""
    comps = []
    for c in circuit.components:
        comps.append({
            "ref": c.ref,
            "kind": c.kind,
            "model": c.model,
            "value": _num(c.value) if isinstance(c.value, (int, float)) else None,
            "value_text": _human_value(c),
            "nodes": c.nodes(),
            "pins": [p.name for p in c.pins],
            # 显式引脚→网络映射：画电路图时按名字对应，不靠数组下标对齐
            "pin_nodes": {p.name: p.node for p in c.pins},
        })
    try:
        nodes = circuit.nodes()
    except Exception:
        nodes = []
    return {
        "name": getattr(circuit, "name", "circuit"),
        "components": comps,
        "nodes": nodes,
        "component_count": len(comps),
        "node_count": len(nodes),
    }

def collect_live(circuit, solution, kind: str) -> dict | None:
    """每个器件的「活数据」：电流、两端电压、功耗。给界面的可视化用。

    **只搬运真实仿真数据**，一律不估算：
      · 电流来自 ngspice 的 @dev[i]/@dev[id]（sim.branch_currents）
      · 电压来自两端节点电压之差（两端都非地的才算；一端接地就是对地电压）
      · 功耗 = I²·R（电阻）/ |V·I|（其它），只有电流和电压都拿到时才算

    交流分析（ac）没有瞬时工作点，这里返回 None —— 界面上不显示「发光」这类
    时域语义，避免用频域数据假装时域状态。

    ⚑ 已知限制：ngspice 的 **S（开关）元件在 `.op` 下 `@sw1[i]` 恒为 ~0**
    （实测 1.9e-13），`.tran` 下才给真实电流。所以工作点分析里开关的"电流"
    看起来是 0 —— 那是**取不到**，不是没电流。动画走瞬态，不受影响。
    """
    if solution is None or kind == "ac":
        return None
    from copilot import sim as _sim

    # ⚑ 取哪个时刻？**不能取 t=0**：
    # 瞬态里 t=0 往往还没通电（PULSE 起始电平 0），于是「活数据」全是 0，
    # 图例显示「0/3 个器件导通」—— 而同一份时间序列中段明明是 19.4mA（实测）。
    # 直流扫描同理：x=0 时输出还没抬起来。
    # 取**最后一个点**（稳态/扫描终点），代表"跑完之后电路是什么样"。
    t_pick = 0.0
    xs = list(getattr(solution, "x", []) or [])
    if kind in ("tran", "dc") and xs:
        try:
            t_pick = float(xs[-1])
        except Exception:
            t_pick = 0.0

    # 电流与电压必须来自**同一时刻**，否则功耗 |I·V| 没有物理意义
    idx_pick = 0
    if kind in ("tran", "dc") and xs:
        idx_pick = len(xs) - 1
    currents = _sim.branch_currents(solution, at_index=idx_pick)

    def node_v(n):
        try:
            return float(solution.value_at(n, t_pick))
        except Exception:
            return None

    def is_gnd(n):
        return str(n).lower() in ("0", "gnd")

    items: dict[str, dict] = {}
    for c in circuit.components:
        ref = str(c.ref).lower()
        pts = [str(n) for n in c.nodes()]
        kind_u = str(getattr(c, "kind", "")).upper()
        # ⚑ 电压/功耗**只对两端器件有意义**。
        # 三端以上（Q/M 有 3~4 个引脚）取"前两个引脚之差"得到的是任意一对引脚，
        # 实测：BJT 得 Vcb=1.008V（真实 Vce=1.706V）、功耗 3.32mW（真实 5.63mW）；
        # MOSFET 得 Vdg=4.767V（真实 Vds=0.233V）、功耗差 **20 倍**。
        # 与其给一个"看起来像对"的错数，不如不给 —— 电流仍是真实值。
        volt = None
        if len(pts) == 2:
            # 两端电压：地节点按 0V 计（一端接地就取对地电压）
            pa = 0.0 if is_gnd(pts[0]) else node_v(pts[0])
            pb = 0.0 if is_gnd(pts[1]) else node_v(pts[1])
            if pa is not None and pb is not None:
                volt = pa - pb
        cur = currents.get(ref)
        power = None
        if cur is not None and volt is not None:
            power = abs(cur * volt)
        items[ref] = {
            "kind": kind_u,
            "current": None if cur is None else round(float(cur), 9),
            "voltage": None if volt is None else round(abs(float(volt)), 6),
            "power": None if power is None else round(float(power), 9),
        }
    return {"kind": kind, "t": round(t_pick, 12), "items": items}



def _reuse_simulation(circuit, kind: str, params):
    """上一次仿真能不能直接用？能就返回那个 Solution，不能返回 None。

    **为什么这里值得做**：用户代码里通常已经写过 `c.tran(...)`（沙箱执行时会
    真跑一次 ngspice），`run_analysis` 又跑一遍 —— 同一件事算两次。实测 35 器件
    电路：沙箱 1.75s + 分析 1.87s，49% 的时间在重算同一个结果。

    **为什么敢复用**：`Circuit.recall_simulation` 要求「分析类型 + 参数数值 +
    电路状态指纹」三者逐值相等。参数比的是数值（`1e-6` 与 `0.000001` 相等），
    不是分析卡字符串；电路被动过（元件值、端子、`.model`、开关 Vt）指纹就变，
    一律不复用。实测两次独立 ngspice 运行的结果逐点最大偏差 **0.0**（完全相同）。
    """
    recall = getattr(circuit, "recall_simulation", None)
    if not callable(recall):
        return None
    try:
        return recall(kind, params)
    except Exception:
        return None


def run_analysis(circuit, spec: dict) -> tuple[dict, object]:
    """按请求跑分析，返回 (JSON 摘要, Solution 对象)。

    Solution 一律走**返回值**局部传递：曾经塞进模块级全局 `_last_solution`
    让后续检查去取——ThreadingHTTPServer 下两个并发请求会互相覆盖，
    A 的 lint/规格核对拿到 B 的波形，数据静默串台。

    ⚑ 每次仿真前先看 `circuit` 上有没有「参数与电路状态都逐值相等」的现成结果
    （用户代码里刚跑过的那次），有就复用，返回里的 `reused` 字段说明走的是哪条路。
    spec: {kind, f_start, f_stop, points, t_step, t_stop}
    """
    kind = (spec or {}).get("kind") or "ac"
    warnings: list[str] = []
    reused = False

    def run(fn, key_kind, key_params):
        """先找缓存，没有再真跑；两种情况都把结果记回 circuit。"""
        nonlocal reused
        hit = _reuse_simulation(circuit, key_kind, key_params)
        if hit is not None:
            reused = True
            return hit
        return fn()

    if kind == "op":
        sol = run(circuit.op, "op", ())
    elif kind == "dc":
        src = (spec.get("source") or "").strip()
        if not src:
            raise ValueError("直流扫描需要指定被扫器件位号（如 V1）")
        a = float(spec.get("dc_start") or 0.0)
        b = float(spec.get("dc_stop") or 10.0)
        st = float(spec.get("dc_step") or ((b - a) / 100.0 or 1.0))
        if st == 0:
            raise ValueError("扫描步长不能为 0")
        second = None
        s2 = (spec.get("second_source") or "").strip()
        if s2:
            second = (s2, float(spec.get("second_start") or 0.0),
                      float(spec.get("second_stop") or 1e-3),
                      float(spec.get("second_step") or 5e-4))
        # 缓存键与 ccl.runner.dc_sweep 记录的一致：位号小写 + 四个数 + 第二维
        key = (src.lower(), a, b, st,
               None if second is None else (second[0].lower(),) + tuple(second[1:]))
        sol = run(lambda: circuit.dc(src, a, b, st, second=second), "dc", key)
    elif kind == "tran":
        t_step = float(spec.get("t_step") or 1e-6)
        t_stop = float(spec.get("t_stop") or 1e-3)
        if t_step <= 0 or t_stop <= 0:
            raise ValueError("t_step 与 t_stop 必须 > 0")
        if t_stop / t_step > 2_000_000:
            t_step = t_stop / 2_000_000
            warnings.append(f"步数过多，已把 t_step 放大到 {t_step:.3g}s")
        sol = run(lambda: circuit.tran(t_step, t_stop), "tran", (t_step, t_stop))
    else:
        kind = "ac"
        f1 = float(spec.get("f_start") or 1.0)
        f2 = float(spec.get("f_stop") or 1e6)
        pts = int(spec.get("points") or 100)
        if f1 <= 0 or f2 <= f1:
            raise ValueError("扫频范围要求 0 < f_start < f_stop")
        pts = max(10, min(pts, 1000))
        sol = run(lambda: circuit.ac(f1, f2, pts), "ac", (f1, f2, pts))

    names = list(sol.node_names())
    # 电压节点挑出来（电流 i(...) 单独标）
    v_nodes = [n for n in names if not n.lower().startswith("i(")]
    i_nodes = [n for n in names if n.lower().startswith("i(")]

    xs = list(getattr(sol, "x", []) or [])
    traces: dict[str, dict] = {}
    ops: dict[str, float | None] = {}

    if kind == "op":
        for n in names:
            try:
                ops[n] = _num(sol.value_at(n, 0.0))
            except Exception:
                ops[n] = None
        xs = []
    elif kind == "ac":
        for n in names:
            try:
                db = sol.db(n)
                ph = sol.phase(n)
                x2, db2 = _downsample(xs, db)
                _, ph2 = _downsample(xs, ph)
                traces[n] = {"x": [_num(v) for v in x2],
                             "y": [_num(v) for v in db2],
                             "phase": [_num(v) for v in ph2],
                             "unit": "dB"}
            except Exception:
                continue
    else:  # tran
        for n in names:
            try:
                # 必须直接用波形自己的数组，**不要逐点调 value_at**：
                # value_at 每次都在整条波形上做线性插值（O(n)），
                # 逐点调用就变成 O(n²)。实测 5023 点 × 3 条波形 → 15069 次
                # value_at ≈ 21 秒；直接取数组是毫秒级。
                w = sol.v(n)
                ys = w.real()
                xw = list(getattr(w, "x", None) or xs)
                if len(xw) != len(ys):        # 极端情况回退到扫描轴
                    xw = xs
                x2, y2 = _downsample(xw, ys)
                traces[n] = {"x": [_num(v) for v in x2],
                             "y": [_num(v, 9) for v in y2], "unit": "V"}
            except Exception:
                continue

    # 直流扫描：按曲线族序列化（有第二维时每条曲线一个独立 key，图例自然显示 label）
    if kind == "dc":
        traces = {}
        for n in v_nodes:
            try:
                curves = sol.dc_curves(n)
            except Exception:
                curves = []
            if not curves:
                try:
                    x2, y2 = _downsample(xs, [w.real for w in sol.v(n).y])
                    traces[n] = {"x": [_num(v) for v in x2],
                                 "y": [_num(v, 9) for v in y2], "unit": "V", "label": ""}
                except Exception:
                    pass
                continue
            multi = len(curves) > 1
            for c in curves:
                lbl = c.get("label") or ""
                key = n if not multi else (f"{n} @ {lbl}".strip() if lbl else n)
                x2, y2 = _downsample(list(c.get("x") or []), list(c.get("y") or []))
                traces[key] = {"x": [_num(v) for v in x2],
                               "y": [_num(v, 9) for v in y2], "unit": "V", "label": lbl}

    metrics: dict[str, float | None] = {}
    probe = (spec or {}).get("probe") or ("out" if "out" in names else (v_nodes[-1] if v_nodes else None))
    if kind == "ac" and probe:
        for label, fn in (("f3db", lambda: sol.f3db(probe)),
                          ("peak_db", lambda: sol.peak_db(probe)),
                          ("增益dB@低频", lambda: sol.value_at(probe, xs[0]) if xs else None)):
            try:
                metrics[label] = _num(fn())
            except Exception:
                metrics[label] = None

    if kind == "tran" and probe:
        for label, fn in (("rise_time", lambda: sol.rise_time(probe)),
                          ("fall_time", lambda: sol.fall_time(probe)),
                          ("overshoot_pct", lambda: sol.overshoot_pct(probe)),
                          ("settling_time", lambda: sol.settling_time(probe)),
                          ("steady_state", lambda: sol.steady_state(probe))):
            try:
                metrics[label] = _num(fn())
            except Exception:
                metrics[label] = None

    all_nodes = names
    return ({
        "kind": kind,
        "node_names": all_nodes,
        "voltage_nodes": v_nodes,
        "current_nodes": i_nodes,
        "traces": traces,
        "op": ops if kind == "op" else None,
        "metrics": metrics,
        "probe": probe,
        "sweepVar": (spec or {}).get("source") or "",
        "secondVar": (spec or {}).get("second_source") or "",
        "points": len(xs),
        # 复用时 elapsed_ms 是**那一次真仿真**的耗时（不是 0）—— 界面上的耗时
        # 不该因为「省了一次」而变成一个好看但失真的数字。
        "elapsed_ms": _num(getattr(sol, "elapsed_ms", None)),
        "reused": bool(reused),
        "warnings": warnings,
    }, sol)


def execute(source: str, analysis: dict | None = None, *, timeout_s: float = 20.0,
            require: str | None = None, switch_states: dict | None = None) -> dict:
    """执行用户代码 → 电路 → 仿真，返回可直接给前端的 JSON。

    `require` 是**这段代码原本要满足的需求原文**（AI 生成时记下来的）。
    给了它，就额外做一次「需求 vs 实测」对账（spec_check），结果放在 out["spec"]。
    不给（手写代码）则完全不做——代码模式没有意图文本，硬对账只会变成噪音。

    `switch_states` 是 `{"SW1": "on"|"off"}`：界面上点了开关时带进来。
    覆盖发生在**仿真前对电路对象**上（改控制源的 DC 值，或改该开关的 Vt），
    **绝不修改用户代码文本**，所以代码框里看到的东西始终是用户自己写的。
    """
    out: dict = {"ok": False, "stage": "", "line": None, "error": None,
                 "circuit": None, "analysis": None, "netlist": None,
                 "code_stdout": ""}
    try:
        from ccl.ai import sandbox as SB
    except Exception as e:
        out["error"] = f"CCL 沙箱不可用：{type(e).__name__}: {e}"
        return out

    res = SB.run_source(source, timeout_s=timeout_s, require_circuit=True)
    out["stage"] = getattr(res, "stage", "")
    out["line"] = getattr(res, "line", None)
    out["code_stdout"] = getattr(res, "stdout", "") or ""
    if not res.ok or res.circuit is None:
        out["error"] = getattr(res, "error", "未知错误")
        try:
            out["error_detail"] = res.trace()
        except Exception:
            pass
        return out

    circuit = res.circuit
    out["circuit"] = describe_circuit(circuit)

    # 开关状态覆盖：在仿真**之前**改电路对象（不动用户代码文本）。
    # 放在 describe_circuit 之后，是为了让前端看到的器件表仍是代码里的原样，
    # 而实际被改的值由 switch_states 字段单独回报。
    if switch_states:
        try:
            from ccl.runner import apply_switch_states
            # ⚠ 两个字段含义不同，别混：
            #   switch_states → 每个开关**最终的状态**（on/off），界面据此渲染
            #   switch_apply  → 后端**用什么办法**把它强制成这个状态（source/vt），调试用
            # 早先只返回后者，前端把它当状态读，'source' 不匹配 on/off 正则会判成
            # false —— 开关视觉被重置、灯不亮（实测踩到的 bug）。
            # 未知位号（界面残留、代码里已经删掉的开关）**不再抛错**：
            # 覆盖状态只是界面附加意图，不该让整次运行失败。忽略 + 写 warnings。
            sw_notes: list[str] = []
            how = apply_switch_states(circuit, switch_states, warnings=sw_notes)
            out["switch_apply"] = how
            # 只回报**真实生效**的开关（未生效的绝不编一个状态出来）
            out["switch_states"] = {
                str(k).upper(): ("on" if str(v).lower() in ("on", "1", "true", "closed", "close") else "off")
                for k, v in (switch_states or {}).items()
                if str(k).upper() in {str(x).upper() for x in how}
            }
            if sw_notes:
                out.setdefault("warnings", []).extend(sw_notes)
        except Exception as e:
            out["error"] = f"{type(e).__name__}: {e}"
            out["stage"] = "switch_states"
            return out

    # 结构自检：悬空节点/无地这类问题在这里就说清楚，别等到仿真报怪错
    try:
        warns = circuit.validate()
        if warns:
            out.setdefault("validate_warnings", []).extend(warns)
    except Exception as e:
        out["error"] = str(e)
        out["stage"] = "validate"
        try:
            out["netlist"] = circuit.to_spice()
        except Exception:
            pass
        return out

    try:
        net = circuit.to_spice(analysis=_analysis_card(analysis))
        out["netlist"] = net
    except Exception:
        out["netlist"] = None

    try:
        analysis_out, sol = run_analysis(circuit, analysis or {})
        out["analysis"] = analysis_out
        out["ok"] = True
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"
        out["stage"] = "simulate"
        out["lint"] = collect_lint(circuit, None)
        return out

    # M3：检查 + 规格核对（sol 来自上面的返回值，不走全局）
    out["lint"] = collect_lint(circuit, sol)
    try:
        out["expect"] = collect_expect(circuit, (analysis or {}).get("kind") or "ac", sol)
    except Exception as e:
        out["expect"] = {"passed": False, "items": [], "text": f"规格核对异常：{e}",
                         "total": 0, "failed": 0, "extra": []}
    # 需求对账（只在有需求原文时做）
    out["spec"] = collect_spec(require, circuit, sol)
    # 时间序列（只有 tran 有；ac/op/dc 一律 null，前端据此不显示播放条）
    try:
        out["timeline"] = collect_timeline(circuit, sol)
    except Exception as e:
        out["timeline"] = None
        out.setdefault("warnings", []).append(f"时间序列采集失败：{type(e).__name__}: {e}")
    # 器件活数据：LED 按电流发光、电阻按功耗发热都靠它（ac 不提供）
    try:
        kind = (analysis or {}).get("kind") or "ac"
        # 取哪个时刻由 collect_live 自己决定（tran/dc 取末点、电流电压同刻）
        out["live"] = collect_live(circuit, sol, kind)
    except Exception as e:
        out["live"] = None
        out.setdefault("warnings", []).append(f"器件活数据采集失败：{type(e).__name__}: {e}")
    return out


def collect_spec(require: str | None, circuit, solution) -> dict | None:
    """把「代码原本要满足的需求」与仿真实测对一次账。

    为什么只在代码路径做这种事需要小心：手写代码没有需求文本，
    所以 `require` 为空时**一律返回 None**，前端据此不显示任何东西 ——
    绝不凭空造一个需求出来对账。

    AI 生成的代码则必须带着需求走：生成时验过一次，用户后来改了元件值，
    如果不再对账，就变成「AI 生成时验过、之后永远裸奔」。
    """
    if not (require or "").strip():
        return None
    try:
        from ccl.ai import spec_check as SC
        targets = SC.parse_targets(require)
        if not targets:
            return {"required": require, "checked": 0, "failed": 0,
                    "passed": True, "items": [],
                    "text": "需求里没有可量化的指标，无法自动对账（需人工确认）"}
        # ⚑ 用**严格版**：测不到（拿不到 solution / 读不出节点 / 没写输入电压）
        # 会抛 Unmeasurable，由下面的 except 如实报「这次没能对账」。
        # 非严格版会把"测不到"返回成 `[]`，在界面上就显示成「全部达标」——
        # 正是这条路径最容易出的错（拿不到证据就判无罪）。
        misses = SC.check_targets_strict(targets, solution, circuit=circuit)
        items = []
        for t in targets:
            miss = next((m for m in misses if m.target is t), None)
            items.append({
                "label": t.label(),
                "target": t.value,
                "ok": miss is None,
                "actual": None if miss is None or not _finite(miss.actual) else round(float(miss.actual), 4),
                "text": "" if miss is None else miss.message(),
            })
        text = ("原需求核对：%d/%d 项达标" % (len(targets) - len(misses), len(targets))
                if misses else "原需求核对：%d 项全部达标" % len(targets))
        return {"required": require, "checked": len(targets), "failed": len(misses),
                "passed": not misses, "items": items, "text": text,
                "hint": SC.repair_hint(misses) if misses else ""}
    except Exception as e:
        # 对账本身出问题也要如实说，不能静默当成通过
        try:
            from ccl.ai import spec_check as _SC2
            _unmeas = isinstance(e, _SC2.Unmeasurable)
        except Exception:
            _unmeas = False
        head = "需求没能在这次结果上对账" if _unmeas else "需求对账异常"
        return {"required": require, "checked": 0, "failed": 0, "passed": False,
                "items": [], "text": f"{head}：{e}",
                "hint": "" if not _unmeas else
                        "常见原因是：仿真没跑出结果、电路里没有可测的输出节点、"
                        "或需求里没写输入电压（如「把 12V 分压到 3.3V」）。"}


def _finite(x) -> bool:
    try:
        return x is not None and float(x) == float(x)
    except Exception:
        return False


def collect_lint(circuit, solution) -> list[dict]:
    """静态 + 工作点检查结果 → JSON。"""
    out = []
    try:
        for i in circuit.lint(solution):
            out.append({"level": i.level, "code": getattr(i, "code", ""),
                        "title": i.title, "detail": i.detail, "ref": getattr(i, "ref", "")})
    except Exception as e:
        out.append({"level": "warn", "code": "lint_error",
                    "title": "检查器异常", "detail": f"{type(e).__name__}: {e}", "ref": ""})
    return out


def collect_expect(circuit, kind: str, solution) -> dict | None:
    """执行用户的 expect 规格并核对。

    用户声明的规格可能既有交流类也有工作点类，而页面一次只跑一种分析，
    所以缺的那一类会**补跑一次**（单次仿真几十毫秒，换来完整的规格核对）。
    """
    exps = list(getattr(circuit, "expectations", []) or [])
    if not exps:
        return None
    from ccl.assertions import evaluate
    ac_sol = solution if kind == "ac" else None
    op_sol = solution if kind == "op" else None
    extra_warn = []
    try:
        if ac_sol is None and any(e.needs_ac() for e in exps):
            ac_sol = circuit.ac(1.0, 1e6, 100)
            extra_warn.append("为核对交流类规格，额外跑了一次扫频（1Hz~1MHz）")
        if op_sol is None and any(e.needs_op() for e in exps):
            op_sol = circuit.op()
            extra_warn.append("为核对工作点类规格，额外跑了一次 .op")
    except Exception as e:
        extra_warn.append(f"补跑分析失败：{type(e).__name__}: {e}")
    rep = evaluate(exps, circuit, ac_sol=ac_sol, op_sol=op_sol)
    return {
        "passed": rep.passed,
        "total": len(rep.results),
        "failed": len(rep.failed),
        "items": rep.table(),
        "text": str(rep),
        "extra": extra_warn,
    }


def _analysis_card(spec: dict | None) -> str:
    s = spec or {}
    kind = s.get("kind") or "ac"
    if kind == "op":
        return ".op"
    if kind == "tran":
        return f".tran {float(s.get('t_step') or 1e-6):.6g} {float(s.get('t_stop') or 1e-3):.6g}"
    if kind == "dc":
        a = float(s.get("dc_start") or 0.0)
        b = float(s.get("dc_stop") or 10.0)
        st = float(s.get("dc_step") or ((b - a) / 100.0 or 1.0))
        card = ".dc %s %.6g %.6g %.6g" % (s.get("source") or "V1", a, b, st)
        if (s.get("second_source") or "").strip():
            card += " %s %.6g %.6g %.6g" % (s["second_source"],
                float(s.get("second_start") or 0.0),
                float(s.get("second_stop") or 1e-3),
                float(s.get("second_step") or 5e-4))
        return card
    return (f".ac dec {max(10, min(int(s.get('points') or 100), 1000))} "
            f"{float(s.get('f_start') or 1.0):.6g} {float(s.get('f_stop') or 1e6):.6g}")


# ==========================================================================
# M4：AI 能力（生成 / 解释 / 修复）
# ==========================================================================
# 全部走 ccl.ai（独立可选子包）。没有 Key 时这些接口返回明确错误，
# 但手写代码那条路完全不受影响。

def _ai():
    try:
        from ccl import ai
        return ai, None
    except Exception as e:
        return None, f"AI 模块不可用：{type(e).__name__}: {e}"


def ai_generate(prompt: str, *, model: str | None = None) -> dict:
    """一句话 → 可执行的电路代码。"""
    if not (prompt or "").strip():
        return {"ok": False, "error": "描述为空"}
    ai, err = _ai()
    if ai is None:
        return {"ok": False, "error": err}
    try:
        g = ai.generate(prompt, model=model)
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    exps = getattr(getattr(g, "circuit", None), "expectations", None) or []
    return {
        "ok": bool(getattr(g, "ok", False)),
        "source": getattr(g, "source", "") or "",
        "error": getattr(g, "error", None),
        "expectations": len(exps),
        # 不致命但用户必须看见的问题（如「模型自加的断言没通过」）
        "warnings": list(getattr(g, "warnings", None) or []),
        "attempts": [{"n": a.n, "stage": getattr(a, "stage", ""),
                      "error": getattr(a, "error", None)} for a in (getattr(g, "attempts", None) or [])],
        "elapsed_ms": _num(getattr(g, "elapsed_ms", None)),
    }


def ai_fix(code: str, *, request: str = "", model: str | None = None) -> dict:
    """按实际问题修正现成代码。诊断是确定性的，没问题就不调用模型。"""
    if not (code or "").strip():
        return {"ok": False, "error": "代码为空"}
    ai, err = _ai()
    if ai is None:
        return {"ok": False, "error": err}
    try:
        g = ai.fix(code, request=request, model=model)
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    return {
        "ok": bool(getattr(g, "ok", False)),
        "source": getattr(g, "source", "") or "",
        "error": getattr(g, "error", None),
        "attempts": [{"n": a.n, "stage": getattr(a, "stage", ""),
                      "error": getattr(a, "error", None)} for a in (getattr(g, "attempts", None) or [])],
        "elapsed_ms": _num(getattr(g, "elapsed_ms", None)),
    }


def ai_explain(code: str, analysis: dict | None = None, *, model: str | None = None) -> dict:
    """解释这段电路在做什么、实测如何。"""
    if not (code or "").strip():
        return {"ok": False, "error": "代码为空"}
    ai, err = _ai()
    if ai is None:
        return {"ok": False, "error": err}
    # 先把电路跑起来，拿到 circuit / solution
    try:
        from ccl.ai import sandbox as SB
        res = SB.run_source(code, timeout_s=20.0, require_circuit=True)
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    if not res.ok or res.circuit is None:
        return {"ok": False, "error": getattr(res, "error", "电路构建失败")}
    circuit = res.circuit
    real_sol = None
    try:
        _, real_sol = run_analysis(circuit, analysis or {"kind": "ac"})
    except Exception:
        real_sol = None
    # explain 需要的是 Solution 对象而不是我们序列化后的 dict
    try:
        text = ai.explain(circuit, real_sol, model=model)
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    return {"ok": True, "text": text or ""}


# ==========================================================================
# M5：子电路库 + 报告导出
# ==========================================================================

def blocks_catalog() -> dict:
    """可复用子电路清单。"""
    try:
        from ccl.blocks import catalog
        return {"ok": True, "blocks": catalog()}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "blocks": []}


def build_report(code: str, analysis: dict | None = None,
                 switch_states: dict | None = None) -> dict:
    """执行代码 → 出 Markdown 报告。

    `switch_states` 必须和界面上一致：用户点了开关、屏幕上是 19.4mA，
    导出报告却按代码原样（开关断开、5nA）出数——他拿去评审的是另一条电路。
    """
    from ccl.ai import sandbox as SB
    from ccl import report as RPT

    res = SB.run_source(code or "", timeout_s=20.0, require_circuit=True)
    if not res.ok or res.circuit is None:
        return {"ok": False, "error": getattr(res, "error", "电路构建失败"),
                "line": getattr(res, "line", None)}
    circuit = res.circuit
    # 与界面走同一条开关覆盖路径（不改用户代码文本，只改电路对象）
    if switch_states:
        try:
            from ccl.runner import apply_switch_states
            apply_switch_states(circuit, switch_states)
        except Exception:
            pass
    sol = None
    desc = ""
    spec = analysis or {"kind": "ac"}
    try:
        _, sol = run_analysis(circuit, spec)
        desc = _analysis_card(spec)
    except Exception:
        sol = None
    try:
        text = RPT.markdown(circuit, sol, analysis_desc=desc)
    except Exception as e:
        return {"ok": False, "error": f"报告生成失败：{type(e).__name__}: {e}"}
    rid = f"r{next(_REPORT_IDS)}"
    _REPORTS[rid] = {
        "markdown": text,
        "filename": f"circuit-report-{getattr(circuit, 'name', 'ccl')}.md",
    }
    if len(_REPORTS) > 30:          # 只留最近 30 份，避免内存无限涨
        for k in list(_REPORTS)[:-30]:
            _REPORTS.pop(k, None)
    return {"ok": True, "markdown": text, "id": rid,
            "filename": _REPORTS[rid]["filename"]}


def get_report(rid: str) -> dict | None:
    return _REPORTS.get(rid)
