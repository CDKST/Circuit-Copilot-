"""无源/有源滤波器拓扑，以及「按指标反解元件值」的三种综合器。

前半：RCLowpass / RCHighpass / RLCBandpass / SallenKeyLowpass / SallenKeyHighpass /
TwinTNotch —— 单级结构与二阶节的参数、网表、判据。
后半：FilterLowpassSynth / FilterHighpassSynth / FilterBandpassSynth —— 用户只说
「几阶 / 什么响应 / 截止多少」，这里负责把归一化极点表分配到各级二阶节。

归一化极点表（`pole_table` 及 `_butter_pairs`/`_cheb_pairs`/`_bessel_pairs`/
`_proto_3db` 等）放在本文件而不是 `base.py`：它唯一的消费者就是这里的三个综合器。
"""

from __future__ import annotations

import math

from .. import elements as E

from .base import (
    AC_FULL,
    PI2,
    Param,
    Topology,
    _attenuation_at,
    _db_at,
    _db_interp,
    _f0_from_phase,
    _f0_from_phase_high,
    _f3db_highpass,
    _find_f3db,
    _fnan,
    _hp_f3_over_f0,
    _interp_x,
    _passband_db,
    _series_values,
    opamp_subckt,
)

# --------------------------------------------------------------------------
# 滤波器综合用的数学：归一化极点表 + 原型 −3dB 频率
#
# 为什么要有这一层：用户说的是「4 阶 Butterworth，截止 10kHz」，
# 而教科书公式给的是每级的 ω0 与 Q。要把「总 −3dB = 10kHz」落到各级，
# 就必须知道每种响应的原型自身在哪到 −3dB——Butterworth 恰好是 1（定义如此），
# Chebyshev 与 Bessel 都远不是 1（0.5dB Chebyshev 差 +45%，Bessel 差 −21%），
# 直接拿 fc 当各级 f0 会让截止频率偏出 ±10% 的判定区间。
#
# 所有极点都从公式算，不查表（本文件各族的核对数值直接写在
# 下面 _butter_pairs / _cheb_pairs / _bessel_pairs 的 docstring 里，
# 改动公式时请照着重算一遍；整套推导也只依赖本文件的 _proto_3db）。约定：
#     一对共轭极点 p = −a ± jb  →  ω0 = |p|，Q = |p| / (2a)
#     每级二阶节 H_k(s) = ω0² / (s² + (ω0/Q)s + ω0²)   （直流增益 1）
# --------------------------------------------------------------------------
def _butter_pairs(n: int) -> list[tuple[float, float]]:
    """Butterworth：极点均布在左半单位圆，与虚轴夹角 θ_k=(2k+1)π/(2N)。

    p = −sinθ + jcosθ  ⇒  ω0 = 1，Q = 1/(2sinθ)。
    N=2 → Q=0.7071；N=4 → Q=0.5412 / 1.3066；N=6 → 0.5176 / 0.7071 / 1.9319。
    """
    out = []
    for k in range(n // 2):
        th = math.pi * (2 * k + 1) / (2 * n)
        out.append((1.0, 1.0 / (2.0 * math.sin(th))))
    return out


def _cheb_eps(ripple_db: float) -> float:
    """通带波纹（dB）→ 纹波因子 ε，由 波纹 = 10log10(1+ε²) 反解。"""
    r = min(max(float(ripple_db), 1e-3), 12.0)
    return math.sqrt(10.0 ** (r / 10.0) - 1.0)


def _cheb_pairs(n: int, ripple_db: float) -> list[tuple[float, float]]:
    """Chebyshev I 型：极点落在椭圆上，a = asinh(1/ε)/N。

        p = −sinh(a)·sinθ ± j·cosh(a)·cosθ,  θ=(2k+1)π/(2N)

    注意 N=2 时 ω0 受波纹影响（0.5dB → ω0=1.2313），所以「各级 f0 相同」
    在这个族里本来就不成立——进一步说明必须做原型归一化。
    手算核对：0.5dB → a=0.8871，Q=0.8637（由峰化反算亦得 +0.5000dB）；
    1dB → Q=0.9565；两者与峰化公式 peak=20log10(Q/√(1−1/(4Q²))) 自洽。
    """
    eps = _cheb_eps(ripple_db)
    a = math.asinh(1.0 / eps) / n
    out = []
    for k in range(n // 2):
        th = math.pi * (2 * k + 1) / (2 * n)
        re = -math.sinh(a) * math.sin(th)
        im = math.cosh(a) * math.cos(th)
        w0 = math.hypot(re, im)
        out.append((w0, w0 / (2.0 * abs(re))))
    return out


def _bessel_coeffs(n: int) -> list[float]:
    """反向 Bessel 多项式 θ_n(s) 的系数（升幂）：a_k=(2n−k)!/(2^(n−k) k! (n−k)!)。

    n=2 → 3 + 3s + s²；n=4 → 105 + 105s + 45s² + 10s³ + s⁴。
    """
    return [
        math.factorial(2 * n - k)
        / (2.0 ** (n - k) * math.factorial(k) * math.factorial(n - k))
        for k in range(n + 1)
    ]


def _poly_roots(coeffs: list[float]) -> list[complex]:
    """Durand–Kerner 求根（升幂系数）。只用标准库，次数 ≤6 时秒收敛。"""
    n = len(coeffs) - 1
    lead = coeffs[-1]
    c = [v / lead for v in coeffs]

    def f(z: complex) -> complex:
        return sum(ck * z ** k for k, ck in enumerate(c))

    roots = [complex(0.4, 0.9) ** k for k in range(n)]
    for _ in range(200):
        new = []
        for i, zi in enumerate(roots):
            d = 1 + 0j
            for j, zj in enumerate(roots):
                if i != j:
                    d *= zi - zj
            new.append(zi - f(zi) / d)
        done = max(abs(new[i] - roots[i]) for i in range(n))
        roots = new
        if done < 1e-14:
            break
    return roots


def _bessel_pairs(n: int) -> list[tuple[float, float]]:
    """Bessel（最平坦群延迟）：解 θ_n(s)=0 取上半平面根。

    手算核对 n=4：根 −2.8962±0.8672j / −2.1038±2.6574j
      → (ω0,Q) = (3.0233, 0.5219) / (3.3894, 0.8055)，
      与常见「延时归一化」Bessel 表一致。
    """
    out = []
    for z in _poly_roots(_bessel_coeffs(n)):
        if z.imag > 1e-9:
            w0 = abs(z)
            out.append((w0, w0 / (2.0 * abs(z.real))))
    out.sort(key=lambda t: t[1])
    return out


def _proto_db(pairs: list[tuple[float, float]], w: float) -> float:
    """归一化原型的幅频（dB）：各节级联，直流增益 1。"""
    db = 0.0
    for w0, q in pairs:
        num = w0 ** 4
        den = (w0 * w0 - w * w) ** 2 + (w * w0 / q) ** 2
        db += 10.0 * math.log10(num / den) if den > 0 else -300.0
    return db


def _proto_3db(pairs: list[tuple[float, float]]) -> float:
    """原型的 −3dB 角频率（对 log ω 二分；原型是单调下降的，必收敛）。

    Butterworth 恒为 1.0（这正好是这套数值方法的自检点）；
    Chebyshev 0.5dB/N2 → 1.4479；Bessel N2 → 1.3617；Bessel N4 → 2.1139。
    """
    lo, hi = 1e-3, 1e3
    for _ in range(200):
        mid = math.sqrt(lo * hi)
        if _proto_db(pairs, mid) > -3.0103:
            lo = mid
        else:
            hi = mid
    return math.sqrt(lo * hi)


_POLE_CACHE: dict[tuple[int, str, float], tuple[tuple[tuple[float, float], ...], float]] = {}


def pole_table(n: int, kind: str, ripple_db: float) -> tuple[list[tuple[float, float]], float]:
    """(归一化极点表 [(ω0,Q)...] 按 Q 升序, 原型 −3dB 角频率 ω3)。

    返回的 ω0 是相对 ω3 归一化前的原值，调用方按 f0_k = fc·ω0_k/ω3 分配到各级。
    """
    key = (int(n), str(kind), round(float(ripple_db), 3))
    hit = _POLE_CACHE.get(key)
    if hit is None:
        if kind == "butterworth":
            pairs = _butter_pairs(n)
        elif kind == "chebyshev":
            pairs = _cheb_pairs(n, ripple_db)
        elif kind == "bessel":
            pairs = _bessel_pairs(n)
        else:
            raise ValueError(f"未知滤波器类型 {kind}")
        pairs.sort(key=lambda t: t[1])
        hit = (tuple(pairs), _proto_3db(pairs))
        _POLE_CACHE[key] = hit
    return [tuple(p) for p in hit[0]], hit[1]


# ==========================================================================
# 1. RC 一阶低通
# ==========================================================================
class RCLowpass(Topology):
    id = "rc_lowpass"
    name = "RC 一阶低通滤波"
    summary = "最简单的无源低通，−20dB/十倍频滚降，常用于电源去耦、信号抗混叠前置。"
    params = [
        Param("R", "电阻 R", "R", 1.0, 1e7, series="E24"),
        Param("C", "电容 C", "C", 1e-12, 1e-3, series="E12"),
    ]
    metrics_keys = ["gain_db", "fc", "atten_db"]

    def render(self, p):
        return (
            f"* RC 一阶低通\n"
            f"Vin in 0 AC 1\n"
            f"R1 in out {E.fmt(p['R'])}\n"
            f"C1 out 0 {E.fmt(p['C'])}\n"
            f"{AC_FULL}\n.end"
        )

    def extract(self, res, p):
        w = res.waves["v(out)"]
        db = w.db()
        dc = db[0]
        fc = _find_f3db(w, dc)
        atten = _attenuation_at(w, fc * 10, dc) if fc else None
        return {
            "gain_db": dc,
            "fc": fc if fc else float("nan"),
            "atten_db": atten if atten is not None else float("nan"),
        }

    def design(self, spec):
        """反解 RC。**电容不能死写**（实测：死写 100nF 让 fc=0.1Hz 报成 1.59Hz、+1491%）。

        做法与 RLC 带通一致：先按常规电阻（10kΩ）反解电容，再按本拓扑的
        电容量程夹一次、用夹完的值重算电阻。量程两端够不着时由 `Param.clamp`
        留「超出量程」警告，上层据此如实判未达标（而不是给一个像真值的错数）。
        """
        fc = spec["fc"]
        c = 1.0 / (PI2 * fc * 1e4)        # 以 10kΩ 为常规电阻反解
        c = min(max(c, 1e-12), 1e-3)      # 电容量程
        r = 1.0 / (PI2 * fc * c)
        return {"R": r, "C": c}


# ==========================================================================
# 2. RC 一阶高通
# ==========================================================================
class RCHighpass(Topology):
    id = "rc_highpass"
    name = "RC 一阶高通滤波"
    summary = "隔直/去直流偏置，−20dB/十倍频，常用于音频耦合与传感器交流提取。"
    params = [
        Param("R", "电阻 R", "R", 1.0, 1e7, series="E24"),
        Param("C", "电容 C", "C", 1e-12, 1e-3, series="E12"),
    ]
    metrics_keys = ["gain_db", "fc", "atten_db"]

    def render(self, p):
        return (
            f"* RC 一阶高通\n"
            f"Vin in 0 AC 1\n"
            f"C1 in out {E.fmt(p['C'])}\n"
            f"R1 out 0 {E.fmt(p['R'])}\n"
            f"{AC_FULL}\n.end"
        )

    def extract(self, res, p):
        w = res.waves["v(out)"]
        db = w.db()
        hf = db[-1]
        # 高通：从高频往回找跌破 −3dB 的点
        xs = list(reversed(w.x))
        db_rev = list(reversed(db))
        f = _interp_x(xs, db_rev, hf - 3.0103)
        atten = _attenuation_at(w, (f / 10) if f else 1.0, hf)
        return {
            "gain_db": hf,
            "fc": f if f else float("nan"),
            "atten_db": atten if atten is not None else float("nan"),
        }

    def design(self, spec):
        # 与 RC 低通同理：按 10kΩ 反解电容再夹量程（死写容值会让极端 fc 报错数，
        # 实测 fc=0.1Hz 报成 1.59Hz、+1491%）
        fc = spec["fc"]
        c = 1.0 / (PI2 * fc * 1e4)
        c = min(max(c, 1e-12), 1e-3)
        r = 1.0 / (PI2 * fc * c)
        return {"R": r, "C": c}


# ==========================================================================
# 3. RLC 串联带通
# ==========================================================================
class RLCBandpass(Topology):
    id = "rlc_bandpass"
    name = "RLC 串联带通滤波"
    summary = "无源二阶带通，Q 由 R 决定，常用于射频前端选频、谐振检测。"
    params = [
        Param("L", "电感 L", "L", 1e-9, 1.0, series="E12"),
        Param("C", "电容 C", "C", 1e-12, 1e-3, series="E12"),
        Param("R", "电阻 R", "R", 0.01, 1e6, series="E24"),
    ]
    metrics_keys = ["f0", "q", "bw", "gain_db"]

    def render(self, p):
        return (
            f"* RLC 串联带通\n"
            f"Vin in 0 AC 1\n"
            f"L1 in n1 {E.fmt(p['L'])}\n"
            f"C1 n1 out {E.fmt(p['C'])}\n"
            f"R1 out 0 {E.fmt(p['R'])}\n"
            f"{AC_FULL}\n.end"
        )

    def extract(self, res, p):
        w = res.waves["v(out)"]
        db = w.db()
        imax = max(range(len(db)), key=lambda i: db[i])
        f0, peak = w.x[imax], db[imax]
        lo = _interp_x(w.x[: imax + 1], db[: imax + 1], peak - 3.0103)
        hi = _interp_x(w.x[imax:], db[imax:], peak - 3.0103)
        bw = (hi - lo) if (lo and hi) else float("nan")
        q = (f0 / bw) if (bw and bw > 0) else float("nan")
        return {"f0": f0, "q": q, "bw": bw, "gain_db": peak}

    def design(self, spec):
        """反解 L/C/R。**电容不能死写**——这是实测事故的根因。

        早先这里写死 `c = 10e-9`，于是 1kHz 解出 L = 2.533H，而 L 的量程上限是 1H，
        被 `Param.clamp` **静默**压成 1H → f0 变成 1591.55Hz（偏 **+59%**），
        报告还写着「已遍历 9 组标准件组合…无解」。实测纯 E12/E24 穷举有 15 组达标
        （L=0.82H / C=33nF / R=1kΩ → 967.5Hz、Q=4.99、成品率 97.5%）。
        误杀带：带通在 **5Hz~1591Hz** 整整三个十倍频都报"做不到"。

        做法：先按**常规电感量**（10mH）反解电容，再各自钳到本拓扑量程内，
        最后用钳位后的值重算 L。低频端电容受 1mF 上限约束、高频端受 1pF 下限约束，
        两端都会如实体现为"需求超出量程"（钳位警告已会出现在报告里）。
        """
        f0, bw = spec["f0"], spec.get("bw")
        q = spec.get("q") or (f0 / bw if bw else 5.0)
        w = (PI2 * f0) ** 2
        # 1) 先按 10mH 这个"常见电感"反解电容（工程上先选电感档位再配电容）
        c = 1.0 / (w * 10e-3)
        c = min(max(c, 1e-12), 1e-3)      # 电容量程
        l = 1.0 / (w * c)
        if l > 1.0:                       # 电感超上限 → 反过来放大电容
            l = 1.0
            c = 1.0 / (w * l)
            c = min(max(c, 1e-12), 1e-3)
            l = 1.0 / (w * c)
        elif l < 1e-9:                    # 电感低于下限 → 减小电容
            l = 1e-9
            c = 1.0 / (w * l)
            c = min(max(c, 1e-12), 1e-3)
            l = 1.0 / (w * c)
        R = (1.0 / q) * math.sqrt(l / c)
        return {"L": l, "C": c, "R": R}


# ==========================================================================
# 7. Sallen-Key 二阶有源低通
# ==========================================================================
class SallenKeyLowpass(Topology):
    id = "sallen_key_lowpass"
    name = "Sallen-Key 二阶有源低通"
    summary = "单位增益二阶低通，−40dB/十倍频。Q 决定是否峰化，是抗混叠滤波器的标准结构。"
    params = [
        Param("R1", "电阻 R1", "R", 10.0, 1e6, series="E96"),
        Param("R2", "电阻 R2", "R", 10.0, 1e6, series="E96"),
        Param("C1", "电容 C1", "C", 1e-12, 1e-3, series="E12"),
        Param("C2", "电容 C2", "C", 1e-12, 1e-3, series="E12"),
        Param("GBW", "运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "运放开环增益", "gain", 1e3, 1e7),
    ]
    metrics_keys = ["gain_db", "fc", "f0", "q", "peaking_db"]
    gain_node = "out"
    # 滤波器的截止频率是精确指标（用户要 1kHz 就给 1kHz），不设 min 覆盖；
    # min 语义只适用于放大器「带宽不低于」这类需求。

    def render(self, p):
        return (
            f"* Sallen-Key 二阶低通\n"
            f"Vin in 0 AC 1\n"
            f"R1 in n1 {E.fmt(p['R1'])}\n"
            f"R2 n1 np {E.fmt(p['R2'])}\n"
            f"C2 np 0 {E.fmt(p['C2'])}\n"
            f"C1 n1 out {E.fmt(p['C1'])}\n"
            f"X1 np out out OPA\n"
            + opamp_subckt(p["A0"], p["GBW"])
            + "\n"
            + AC_FULL
            + "\n.end"
        )

    def extract(self, res, p):
        w = res.waves["v(out)"]
        db = w.db()
        dc = db[0]
        peak = max(db) - dc
        fc = _find_f3db(w, dc)
        # 实测 f0（含运放 GBW 带来的偏差）与 Q：Q = |H(f0)| / |H(0)|
        f0 = _f0_from_phase(w) or _fnan()
        h0 = _db_at(w, f0) if not math.isnan(f0) else None
        q = 10 ** ((h0 - dc) / 20) if h0 is not None else _fnan()
        return {
            "gain_db": dc,
            "fc": fc if fc else _fnan(),
            "f0": f0,
            "q": q,
            "peaking_db": peak,
        }

    def design(self, spec):
        """R1=R2=R 时：ω0 = 1/(R√(C1C2))，Q = √(C1/C2)/2 → C1/C2 = 4Q²。"""
        fc = spec["fc"]
        q = spec.get("q") or 0.7071
        # 按常规电阻 10kΩ 与 Q 反解 c2（死写 10nF 让 fc=1Hz 报成 11.25Hz、+1025%）
        c2 = 1.0 / (PI2 * fc * 1e4 * max(1.0, 2.0 * q))
        c2 = min(max(c2, 1e-12), 1e-3)
        c1 = 4.0 * q * q * c2
        r = 1.0 / (PI2 * fc * math.sqrt(c1 * c2))
        # SK 对运放 GBW 敏感，给 20 倍截止频率的裕量
        return {"R1": r, "R2": r, "C1": c1, "C2": c2, "GBW": max(fc * 20, 1e6), "A0": 1e5}


# ==========================================================================
# 8. Sallen-Key 二阶有源高通
# ==========================================================================
class SallenKeyHighpass(Topology):
    """结构与低通完全对偶：把两条通路的 R/C 互换。

    基波方程（缓冲器理想、out=np）：
        H(s) = s²·C1C2R1R2 / (1 + s·R1(C1+C2) + s²·C1C2R1R2)
      → ω0 = 1/√(R1R2C1C2)，1/(Qω0) = R1(C1+C2)

    两个反直觉、但必须记住的结论（都已用 ngspice 实测确认）：
      1. **R1=R2=R 时 Q = √(C1C2)/(C1+C2) ≤ 0.5**，无论怎么配 C 都上不去。
         想要 Q=0.707 必须让 R2/R1≠1：取 C1=C2=C 时 Q = ½√(R2/R1)，即 R2=4Q²R1。
         （「C2/C1=4Q²」是另一个结构的公式，套到这里 Q 会错一倍以上。）
      2. Q 对运放 GBW 极其敏感（比低通敏感一个量级）：GBW/fc=100 时 Q 偏
         +21%、30 倍时偏 +65%，300 倍仍有 +3.8%，500 倍降到 +1.4%。
         所以按 500×fc 留量，且只信实测值。
    """

    id = "sallen_key_highpass"
    name = "Sallen-Key 二阶有源高通"
    summary = (
        "单位增益二阶高通，−40dB/十倍频。C1=C2 时 Q=½√(R2/R1)，"
        "对运放 GBW 极敏感（实测 GBW/fc=100 时 Q 偏 +21%，建议 ≥300×fc），"
        "常用于隔直后抑制低频共模/工频干扰。"
    )
    params = [
        Param("R1", "反馈电阻 R1", "R", 10.0, 1e6, series="E96"),
        Param("R2", "接地电阻 R2", "R", 10.0, 1e6, series="E96"),
        Param("C1", "串联电容 C1", "C", 1e-12, 1e-3, series="E12"),
        Param("C2", "节点电容 C2", "C", 1e-12, 1e-3, series="E12"),
        Param("GBW", "运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "运放开环增益", "gain", 1e3, 1e7),
    ]
    metrics_keys = ["gain_db", "fc", "f0", "q", "peaking_db"]
    gain_node = "out"
    # 滤波器的截止频率是精确指标（用户要 1kHz 就给 1kHz），不设 min 覆盖；
    # min 语义只适用于放大器「带宽不低于」这类需求。

    def render(self, p):
        return (
            f"* Sallen-Key 二阶高通\n"
            f"Vin in 0 AC 1\n"
            f"C1 in n1 {E.fmt(p['C1'])}\n"
            f"C2 n1 np {E.fmt(p['C2'])}\n"
            f"R2 np 0 {E.fmt(p['R2'])}\n"
            f"R1 n1 out {E.fmt(p['R1'])}\n"
            f"X1 np out out OPA\n"
            + opamp_subckt(p["A0"], p["GBW"])
            + "\n"
            + AC_FULL
            + "\n.end"
        )

    def extract(self, res, p):
        w = res.waves["v(out)"]
        db = w.db()
        f0 = _f0_from_phase_high(w)
        if f0 is None:
            return {"gain_db": db[-1], "fc": _fnan(), "f0": _fnan(),
                    "q": _fnan(), "peaking_db": _fnan()}
        plateau = _passband_db(w, f0)                # 通带（高频平台）增益
        fc = _f3db_highpass(w, plateau, f0 * 20.0)   # 从平台往低频找 −3dB
        h0 = _db_at(w, f0)
        q = 10 ** ((h0 - plateau) / 20.0) if h0 is not None else _fnan()
        return {
            "gain_db": plateau,
            "fc": fc if fc else _fnan(),
            "f0": f0,
            "q": q,
            "peaking_db": max(db) - plateau,
        }

    def design(self, spec):
        """C1=C2=C、R2=4Q²R1（因 Q=½√(R2/R1)），ω0=1/(C√(R1R2)) → R1=1/(2π·2Q·f0·C)。

        两处必须修正，否则实测会明显偏（都验证过）：
          1. 预畸变：规格给的是 f3dB，而公式算的是 f0，两者之差只由 Q 决定。
             Q=2 时不修正 fc 会低 33%。
          2. 裕量：fc 在这里是「不低于」型指标（判定区间 ≥0.9×目标）。留 5% 不是
             为了过判定，而是让批次中位数落在目标之上——用户说的是「1kHz 以上要通」，
             标称点压线意味着一半产品低于诉求。
        """
        fc = float(spec["fc"])
        q = float(spec.get("q") or 0.7071)
        q = min(max(q, 0.1), 20.0)
        f0 = fc * 1.05 / _hp_f3_over_f0(q)   # 裕量 + 预畸变 → 目标 f0
        # 先让 R1 落在 ~10kΩ；Q 大时按 R2 ≤ 1MΩ 反推，避免 R2 顶到量程
        r1_target = min(10e3, 1e6 / (4.0 * q * q))
        c = 1.0 / (PI2 * 2.0 * q * f0 * r1_target)
        c = min(max(c, 1e-12), 1e-3)
        r1 = 1.0 / (PI2 * 2.0 * q * f0 * c)
        r2 = 4.0 * q * q * r1
        # Q 对 GBW 极敏感（低通 20 倍就够，高通不够）：
        # 实测 GBW/fc = 100 时 Q 偏 +21%、30 倍时偏 +65%，300 倍仍有 +3.8%，
        # 500 倍降到 +1.4%，1000 倍才完全干净。取 500 倍——既是正常可买到的器件，
        # 误差也压在判定的 15% 容差里。
        gbw = min(max(fc * 500.0, 1e6), 1e10)
        return {"R1": r1, "R2": r2, "C1": c, "C2": c, "GBW": gbw, "A0": 1e5}

    def note(self, p, m):
        fc, gbw = m.get("fc"), p.get("GBW", 0.0)
        if fc and gbw and fc > 0 and gbw / fc < 200.0:
            return (
                f"运放 GBW 只有截止频率的 {gbw / fc:.0f} 倍。SK 高通的 Q 直接吃 GBW："
                f"实测 Q={m.get('q', float('nan')):.2f}、峰化 {m.get('peaking_db', float('nan')):+.2f}dB，"
                f"通带还会下垂——建议 GBW ≥ 100×fc。"
            )
        return ""


# ==========================================================================
# 10. 有源低通滤波器综合（Butterworth / Chebyshev / Bessel，2/4/6 阶）
# ==========================================================================
_KIND_CODE = {"butterworth": 1, "chebyshev": 2, "bessel": 3}
_KIND_NAME = {"butterworth": "Butterworth（巴特沃斯）", "chebyshev": "Chebyshev（切比雪夫）",
              "bessel": "Bessel（贝塞尔）"}


def _peak_db_of_q(q: float) -> float:
    """二阶节的峰化（相对直流）：Q ≤ 1/√2 不峰化，Q 更大时 peak = 20log10(Q/√(1−1/(4Q²)))。"""
    if q <= 0.70710678:
        return 0.0
    return 20.0 * math.log10(q / math.sqrt(max(1.0 - 1.0 / (4.0 * q * q), 1e-12)))


class FilterLowpassSynth(Topology):
    """低通**综合**（不是验证）：输入「几阶 / 什么响应 / 截止多少」，反解元件值。

    与 `sallen_key_lowpass` 的分工很清楚：
      - `sallen_key_lowpass`：你已经有 4 个元件值，问「这个电路怎么样」；
      - 本拓扑：只需要说「4 阶 Butterworth，−3dB 在 10kHz」，Q 由本模块算。

    ## 极点表与 fc 的分配

    偶次阶全极点低通的极点必然成对共轭，每对就是一个二阶节：
        H_k(s) = ω0k² / (s² + (ω0k/Qk)s + ω0k²)      （Sallen-Key 单位增益实现，直流增益 1）
    Q 全部由公式推、不查表（推导与手算核对见本包 filters.py 的极点表一节）：
      - 共轭极点 p=−a±jb ⇒ ω0=|p|、Q=|p|/(2a)；
      - **Butterworth**：极点均布左半单位圆，θ_k=(2k+1)π/(2N) ⇒ ω0=1、Q=1/(2sinθ)。
        N=2：0.7071；N=4：0.5412/1.3066；N=6：0.5176/0.7071/1.9319。
      - **Chebyshev I**：极点落椭圆，a=asinh(1/ε)/N、ε=√(10^(rp/10)−1)
        ⇒ p=−sinh(a)sinθ ± jcosh(a)cosθ。N=2：0.5dB→Q=0.8637、1dB→Q=0.9565
        （用峰化公式 peak=20log10(Q/√(1−1/(4Q²))) 反算亦得 +0.500/+1.000dB，自洽）。
      - **Bessel**：解反向 Bessel 多项式 θ_N(s)（Durand–Kerner），
        N=2：Q=0.5774；N=4：(ω0,Q)=(3.0233,0.5219)/(3.3894,0.8055)。

    规格给的 fc 是**整机 −3dB 点**，而极点表给的是原型归一化坐标。两者的比例只由响应
    类型决定（Butterworth 恰好是 1，这是定义；Chebyshev 0.5dB/N2 是 1.4479；Bessel N2
    是 1.3617），所以统一做一次原型归一化：**f0_k = fc·ω0_k/ω3**。
    直接令各级 f0=fc 的「简化方案」做不到 ±10%：Chebyshev 会偏 +45%、Bessel −21%。

    ## 元件反解：f0 用电阻绝对值定标，Q 用电阻比精调

    Sallen-Key 单位增益低通（C1 是 n1→out 的反馈电容，C2 是 np 对地电容）：
        ω0 = 1/√(R1R2C1C2) ,  Q = √(R1R2C1C2) / (C2(R1+R2))
    取 R1=R·β、R2=R/β（几何平均都是 R）：
        ω0 = 1/(R√(C1C2))            ← 只由 R 与电容决定
        Q  = √(C1/C2) / (β + 1/β)     ← 只由电容比与 β 决定
    于是**两个自由度正交**：R 定标 f0（=fc·ω0/ω3），β 精调 Q。
    第二步不是洁癖：E24 电容比的粒度约 1%，而 Q 是电容比的平方根，Q=1.93 那级用等阻
    只能凑到 ±0.25%，6 阶 Butterworth 通带就会冒出 0.4dB 鼓包（实测），且候选搜索为了
    压 fc 还会换电容对、把 Q 一起带跑。允许 β≠1（两只串联电阻不等值，工程上很常见）
    之后 Q 恒等于理论值，搜索怎么换元件组合都不会把通带形状搞坏。
    β 由 Q 反解：β + 1/β = √(C1/C2)/Q = k ⇒ β = ½(k+√(k²−4))，要求 k≥2（比值 ≥4Q²）。
    """

    id = "filter_lowpass_synth"
    name = "有源低通滤波器综合（Butterworth/Chebyshev/Bessel）"
    summary = (
        "输入阶数（2/4/6）+ 响应类型 + 截止频率，自动反解各级 Sallen-Key 的 f0 与 Q 并给出元件值。"
        "Butterworth 最平坦通带；Chebyshev 以通带等波纹换更陡的过渡带；Bessel 群延迟最平坦但选择性最差。"
    )
    params = [
        Param("order", "阶数", "enum", 2.0, 6.0),
        Param("kind", "响应类型", "enum", 1.0, 3.0),
        Param("ripple_db", "Chebyshev 通带波纹", "db", 0.1, 3.0),
        # 每级：一个电阻（两只串联电阻的几何平均，β 由 Q 反解）+ 一对电容 + Q 目标
        Param("R1", "级1 电阻（几何平均）", "R", 10.0, 1e6, series="E96"),
        Param("C1", "级1 反馈电容 C1", "C", 1e-12, 1e-3, series="E24"),
        Param("C2", "级1 对地电容 C2", "C", 1e-12, 1e-3, series="E24"),
        Param("Q1", "级1 目标 Q", "ratio", 0.2, 30.0),
        Param("R2", "级2 电阻（几何平均）", "R", 10.0, 1e6, series="E96"),
        Param("C3", "级2 反馈电容 C1", "C", 1e-12, 1e-3, series="E24"),
        Param("C4", "级2 对地电容 C2", "C", 1e-12, 1e-3, series="E24"),
        Param("Q2", "级2 目标 Q", "ratio", 0.2, 30.0),
        Param("R3", "级3 电阻（几何平均）", "R", 10.0, 1e6, series="E96"),
        Param("C5", "级3 反馈电容 C1", "C", 1e-12, 1e-3, series="E24"),
        Param("C6", "级3 对地电容 C2", "C", 1e-12, 1e-3, series="E24"),
        Param("Q3", "级3 目标 Q", "ratio", 0.2, 30.0),
        Param("GBW", "运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "运放开环增益", "gain", 1e3, 1e7),
    ]
    enum_labels = {
        "order": {2: "2 阶", 4: "4 阶", 6: "6 阶"},
        "kind": {1: "Butterworth 巴特沃斯", 2: "Chebyshev 切比雪夫", 3: "Bessel 贝塞尔"},
    }
    metrics_keys = ["gain_db", "fc", "peaking_db", "atten_db"]
    gain_node = "out"
    # 阶数/类型/波纹是「设计选择」而非指标：判定表里没有它们，但 design() 必须拿到。
    design_keys = {"order", "kind", "ripple_db"}
    # fc 是精确指标（eq ±10%），不能设成 min——截止频率「越高越好」对滤波器毫无意义。
    spec_overrides: dict[str, str] = {}

    #: 电容系列：E24（C0G/薄膜都有货）。Q 由电容比的平方根决定，E12 只有 12 个值/十倍频，
    #: 比值分辨率太粗（Q=2.94 要比值 34.5，E12 只能给 30.3 或 36.4）。
    CAP_SERIES = "E24"
    #: 运放 GBW 预算：GBW ≥ GBW_MULT × fc × Qmax。实测（单级 SK、fc=10kHz、扫 GBW）
    #:     δQ/Q ≈ 0.9·Q·(fc/GBW)
    #: GBW/fc=100 时 Q=1.3 偏 +1.27%、Q=2.94 偏 +2.76%、Q=6.5 偏 +5.63%；
    #: 取 1000×Q 后压到 +0.12%/+0.27%/+0.57%，波纹误差 <0.05dB。
    #: （写死 100×fc 会让 6 阶 Chebyshev 的 0.5dB 波纹涨到 2.9dB——实测数字，不是估计。）
    GBW_MULT = 1000.0
    #: 目标阻抗量级：据此把电容定在「好用区间」，再反算电阻
    R_TARGET = 10e3

    # ---- 枚举参数解析（render/extract/build 共用）----
    @staticmethod
    def order_of(p: dict[str, float]) -> int:
        n = int(round(float(p.get("order", 2))))
        return min((2, 4, 6), key=lambda k: abs(k - n))

    @staticmethod
    def kind_of(p: dict[str, float]) -> str:
        return {1: "butterworth", 2: "chebyshev", 3: "bessel"}.get(
            int(round(float(p.get("kind", 1)))), "butterworth")

    @staticmethod
    def r_ratio(c1: float, c2: float, q: float) -> float:
        """两只串联电阻的比值 β=R1/R2（≥1），使 Q 精确等于目标。

        Q = √(C1/C2)/(β+1/β) ⇒ β+1/β = √(C1/C2)/Q = k。
        k>2 解二次方程；k≤2 说明电容比不够大（<4Q²），只能退回等阻（β=1）。
        """
        k = math.sqrt(max(c1, 1e-18) / max(c2, 1e-18)) / max(float(q), 1e-6)
        if k <= 2.0:
            return 1.0
        return 0.5 * (k + math.sqrt(k * k - 4.0))

    def sweep_center(self, p: dict[str, float]) -> float | None:
        """扫频中心 = 设计截止频率本身（由第 1 级的 f0 反推，不是猜）。

        基类的启发式在这里会认错：它见到 R1/C1/C2 就当「单级 Sallen-Key」算
        1/(2π√(R1R2C1C2))，而本拓扑的 R2 是**第 2 级**的电阻，混起来会得到
        13.3kHz（真实 fc=10kHz）。扫频窗虽然够宽不会算错，但白花钱：直接给 fc。
        """
        try:
            f0_1 = 1.0 / (PI2 * p["R1"] * math.sqrt(p["C1"] * p["C2"]))
            pairs, w3 = pole_table(self.order_of(p), self.kind_of(p), p.get("ripple_db", 0.5))
            return f0_1 * w3 / pairs[0][0]      # f0_1 = fc·ω0_1/ω3  ⇒  fc = f0_1·ω3/ω0_1
        except (KeyError, ZeroDivisionError, ValueError, IndexError):
            return None

    def _stage_q(self, p, i: int) -> float:
        """第 i 级的实际 Q（由元件值回算，不是抄理论值）。"""
        c1, c2 = p.get(f"C{2 * i + 1}", 1e-9), p.get(f"C{2 * i + 2}", 1e-9)
        b = self.r_ratio(c1, c2, p.get(f"Q{i + 1}", 1.0))
        return math.sqrt(c1 / c2) / (b + 1.0 / b)

    # ---- 子类实现 ----
    def render(self, p):
        n = self.order_of(p)
        kind = self.kind_of(p)
        nst = n // 2
        lines = [f"* {n} 阶 {_KIND_NAME[kind]} 低通综合（{nst} 级 Sallen-Key 级联，单位增益）",
                 "Vin in 0 AC 1"]
        prev = "in"
        for i in range(nst):
            ra, rb = f"R{2 * i + 1}", f"R{2 * i + 2}"
            c1, c2 = f"C{2 * i + 1}", f"C{2 * i + 2}"
            na, npp = f"s{i + 1}a", f"s{i + 1}p"   # 内部节点逐级独立，不与别级/子电路冲突
            out = "out" if i == nst - 1 else f"s{i + 1}o"
            band = self.r_ratio(p[c1], p[c2], p[f"Q{i + 1}"])
            r1v, r2v = p[f"R{i + 1}"] * band, p[f"R{i + 1}"] / band
            lines += [
                f"* 级 {i + 1}: C1/C2={p[c1] / p[c2]:.3f} R1/R2={band:.4f} → Q={self._stage_q(p, i):.4f}",
                f"{ra} {prev} {na} {E.fmt(r1v)}",
                f"{rb} {na} {npp} {E.fmt(r2v)}",
                f"{c2} {npp} 0 {E.fmt(p[c2])}",
                f"{c1} {na} {out} {E.fmt(p[c1])}",
                f"X{i + 1} {npp} {out} {out} OPA",
            ]
            prev = out
        lines += [opamp_subckt(p["A0"], p["GBW"]), AC_FULL, ".end"]
        return "\n".join(lines) + "\n"

    def extract(self, res, p):
        w = res.waves["v(out)"]
        xs, db = w.x, w.db()
        dc = db[0]
        peak = max(db) - dc
        fc = _find_f3db(w, dc) or _fnan()

        def atten(f: float) -> float:
            """相对直流的衰减（正值=被压制）。扫频范围外不硬凑，返回 NaN。"""
            if not math.isfinite(f) or f <= 0 or f > xs[-1] * 0.9:
                return _fnan()
            v = _db_interp(w, f)
            return (dc - v) if v is not None else _fnan()

        a2 = atten(fc * 2.0)
        a10 = atten(fc * 10.0)
        # 实测斜率只取 4fc→10fc：再往深处走会撞到运放有限 A0/GBW 造成的 −100dB 量级
        # 「地板」（宏模型 A0=1e5 的跟随误差就是 1e-5），在那里量斜率会得到 10dB/dec 的假数字。
        a4 = atten(fc * 4.0)
        slope = (a10 - a4) / math.log10(10.0 / 4.0) if (
            math.isfinite(a4) and math.isfinite(a10)) else _fnan()
        pairs, _w3 = pole_table(self.order_of(p), self.kind_of(p), p.get("ripple_db", 0.5))
        return {
            "gain_db": dc,
            "fc": fc,
            "peaking_db": peak,
            "atten_db": a10,          # 判定用：10×fc 处的衰减
            "atten_2fc_db": a2,       # 诊断：2×fc 处
            "slope_db_dec": slope,    # 诊断：实测滚降斜率（4fc→10fc 段）
            "q_max": max(q for _w, q in pairs),
        }

    def design(self, spec):
        """由 fc/order/kind 反解各级元件值（三步，顺序有意义）。

          1. 极点表给出每级的**归一化** (ω0, Q)；
          2. 按 Q 挑 E24 电容对（比值 ≥4Q²，留出 β 的调节余地），β 由 Q 精确反解；
          3. 用实际 Q 重算这组级联的 −3dB 位置，把各级 f0 定标到「整机 −3dB = fc」，
             再反算电阻 R（R = 1/(2π·f0·√(C1C2))）。
        """
        fc = float(spec.get("fc") or spec.get("f0") or 1e3)
        # ⚑ 不再硬夹 fc：夹了就等于**改用户指标**（实测 fc=0.1Hz 报成 1Hz、+900%）。
        # 真的够不着时由元件反解 + Param.clamp 报「超出量程」，上层据此如实判未达标。
        order = self.order_of({"order": spec.get("order", 2)})
        kind = self._kind_from_spec(spec.get("kind"))
        ripple = min(max(float(spec.get("ripple_db") or 0.5), 0.1), 3.0)

        pairs, _w3 = pole_table(order, kind, ripple)
        uses = order // 2
        w3 = max(_w3, 1e-9)

        caps: list[tuple[float, float]] = []
        q_used: list[float] = []
        for i in range(uses):
            w0n, q = pairs[i]
            caps.append(self._pick_caps(q, fc * w0n / w3))
            q_used.append(q)                 # Q 由 β 精确实现，故这里就是理论 Q
        # 用真实 Q 重算级联 −3dB 的位置（对量化误差免疫；理想情况下等于原型的 ω3）
        w3_act = _proto_3db([(pairs[i][0], q_used[i]) for i in range(uses)])

        out: dict[str, float] = {
            "order": float(order),
            "kind": float(_KIND_CODE[kind]),
            "ripple_db": ripple,
        }
        for i in range(3):
            idx = min(i, uses - 1)           # 用不到的级填第 1 级的量值（不渲染，只是占位）
            c1, c2 = caps[idx]
            f0 = fc * pairs[idx][0] / w3_act
            out[f"R{i + 1}"] = 1.0 / (PI2 * f0 * math.sqrt(c1 * c2))
            out[f"C{2 * i + 1}"], out[f"C{2 * i + 2}"] = c1, c2
            out[f"Q{i + 1}"] = float(q_used[idx])
        # 运放带宽：高 Q 级对 GBW 的胃口与 Q 成正比（见 GBW_MULT 注释）
        out["GBW"] = min(max(fc * self.GBW_MULT * max(q_used), 1e6), 1e10)
        out["A0"] = float(spec.get("A0") or 1e5)
        return out

    # ---- 内部工具 ----
    @staticmethod
    def _kind_from_spec(v) -> str:
        """design() 的 kind 既可能是字符串（LLM/规则给的「butterworth」）也可能是枚举码。"""
        if isinstance(v, str):
            s = v.strip().lower()
            for k, code in _KIND_CODE.items():
                if s == k or s == str(code):
                    return k
            if "butter" in s or "巴特" in s:
                return "butterworth"
            if "cheb" in s or "切比" in s or "雪夫" in s:
                return "chebyshev"
            if "bessel" in s or "贝塞" in s:
                return "bessel"
            return "butterworth"
        try:
            return {1: "butterworth", 2: "chebyshev", 3: "bessel"}.get(int(round(float(v))), "butterworth")
        except (TypeError, ValueError):
            return "butterworth"

    def _pick_caps(self, q: float, f0: float) -> tuple[float, float]:
        """为一级选 E24 电容对 (C1, C2)。

        约束：比值 ≥ 4Q²（否则 β 解不出来、Q 顶不到目标）、阻值落在 50Ω~500kΩ。
        在此前提下挑「比值最接近 4Q²、阻抗量级靠近 R_TARGET」的组合——
        Q 的精度由 β 保证，电容对只需要比值够大且不浪费动态范围。
        """
        c2_ideal = 1.0 / (4.0 * math.pi * f0 * q * self.R_TARGET)   # R=1/(4πf0Q·C2)
        vals = _series_values(self.CAP_SERIES, 1e-11, 1e-6)
        if not vals:
            return 4.0 * q * q * 1e-9, 1e-9
        want_ratio = 4.0 * q * q
        best: tuple[float, float, float] | None = None
        for c2 in vals:
            if not (c2_ideal / 8.0 <= c2 <= c2_ideal * 8.0):
                continue
            for c1 in vals:
                ratio = c1 / c2
                if ratio < want_ratio or ratio > want_ratio * 1.15:
                    continue
                r = 1.0 / (PI2 * f0 * math.sqrt(c1 * c2))
                if not (50.0 <= r <= 5e5):
                    continue
                score = abs(math.log(ratio / want_ratio)) + 0.05 * abs(math.log(r / self.R_TARGET))
                if best is None or score < best[0]:
                    best = (score, c1, c2)
        if best is None:                     # 兜底：理想值硬凑（β 会退回 1）
            c2 = min(max(c2_ideal, 1e-11), 1e-6)
            return min(want_ratio * c2 * 1.01, 1e-3), c2
        return best[1], best[2]

    def inactive_params(self, p: dict[str, float]) -> set[str]:
        """按设计选择裁剪：用不到的级、以及不适用于当前响应类型的参数都不显示。"""
        nst = self.order_of(p) // 2
        hide: set[str] = set()
        for i in range(3):
            if i >= nst:
                hide |= {f"R{i + 1}", f"Q{i + 1}", f"C{2 * i + 1}", f"C{2 * i + 2}"}
        if self.kind_of(p) != "chebyshev":
            hide.add("ripple_db")        # 波纹只对 Chebyshev 有意义
        return hide

    def note(self, p, m):
        order = self.order_of(p)
        kind = self.kind_of(p)
        pairs, w3 = pole_table(order, kind, p.get("ripple_db", 0.5))
        fc_meas = m.get("fc")
        fc_int = fc_meas if (fc_meas and math.isfinite(fc_meas)) else _fnan()
        ok_fc = math.isfinite(fc_int)
        parts: list[str] = []

        stage_txt: list[str] = []
        for i in range(order // 2):
            w0n, q_th = pairs[i]
            c1, c2 = p.get(f"C{2 * i + 1}", 1.0), p.get(f"C{2 * i + 2}", 1.0)
            band = self.r_ratio(c1, c2, p.get(f"Q{i + 1}", q_th))
            f_txt = f"f0≈{E.human_f(fc_int * w0n / w3)}/" if ok_fc else ""
            stage_txt.append(
                f"级{i + 1} {f_txt}Q={self._stage_q(p, i):.4f}（理论 {q_th:.4f}，R1/R2={band:.3f}）")
        extra_txt = ""
        if abs(w3 - 1.0) > 0.02:
            extra_txt = (
                f"各级 f0 刻意不相等：按原型 −3dB 归一化，f0_k=fc·ω0_k/{w3:.4f}；"
                f"若偷懒让各级都取 f0=fc，整机 −3dB 会落到 {w3:.2f}×fc（偏 {100 * (w3 - 1):+.1f}%）。"
            )
        parts.append(
            f"{order} 阶 {_KIND_NAME[kind]} 低通，{order // 2} 级 Sallen-Key 级联："
            + "、".join(stage_txt) + "。" + extra_txt
        )

        qmax = max([self._stage_q(p, i) for i in range(order // 2)] or [0.707])
        pk_max = _peak_db_of_q(qmax)
        # Q 对「本级 C1/C2 比值」是半灵敏度：dQ/Q = ½·d(C1/C2)/(C1/C2)。
        # 两个 ±5% 电容各自独立 → 比值偏差 σ≈7.07% → Q 偏 ±3.5%。
        dq = qmax * 0.035
        dpk = _peak_db_of_q(qmax + dq) - pk_max
        parts.append(
            f"最高 Q 级 Q={qmax:.4f}（该级单独看峰化 {pk_max:+.2f}dB）。Q 由 R1/R2 精调到位，"
            f"但它的**不稳定性**来自电容比：两电容各 ±5%（比值 ±7.1%）→ 该级 Q 偏 ±3.5%、"
            f"峰化再飘 {dpk:+.2f}dB。整机对容差最敏感的就是这一级，要上 1% 电容先保它。"
        )

        # 运放带宽是这类滤波器的隐性预算（实测 δQ/Q ≈ 0.9·Q·fc/GBW）
        gbw = float(p.get("GBW", 0.0))
        if ok_fc and fc_int > 0 and gbw > 0:
            ratio = gbw / fc_int
            need = self.GBW_MULT * qmax
            if ratio < need * 0.95:
                dq_gbw = 100.0 * 0.9 * qmax * fc_int / gbw
                parts.append(
                    f"运放带宽不够：GBW={E.human_f(gbw)} 只有 {ratio:.0f}×fc，"
                    f"而 Q={qmax:.2f} 这级要 ≥{need:.0f}×fc。实测 δQ/Q≈0.9·Q·fc/GBW，"
                    f"该级 Q 已偏约 {dq_gbw:+.1f}%，通带形状（波纹/峰化）跟着走样。"
                )
            else:
                slow = 100.0 * 0.9 * qmax / 300.0
                parts.append(
                    f"运放带宽是本设计的隐性预算：GBW={E.human_f(gbw)}（{ratio:.0f}×fc，"
                    f"按 GBW≥{self.GBW_MULT:.0f}×Q·fc 取，使 δQ/Q<0.2%）。"
                    f"若换成常见的 300×fc 通用运放，Q={qmax:.2f} 这级会偏 {slow:+.1f}%，"
                    f"波纹/峰化随之恶化——这里省运放会直接吃掉滤波器的形状。"
                )

        a10 = m.get("atten_db", _fnan())
        if kind == "chebyshev":
            edge = fc_int / w3 if ok_fc else _fnan()
            parts.append(
                f"Chebyshev 的两个「截止」别混：通带波纹带边是 "
                f"{E.human_f(edge) if ok_fc else '—'}（=fc/{w3:.3f}），"
                f"而 {E.human_f(fc_int) if ok_fc else 'fc'} 才是整机 −3dB 点。"
                f"波纹 {p.get('ripple_db', 0.5):.2f}dB 换来更陡的过渡带，"
                f"代价是通带峰化 {m.get('peaking_db', _fnan()):+.2f}dB 与群延迟起伏（方波会振铃）。"
            )
        elif kind == "bessel":
            parts.append(
                f"Bessel 用选择性换线性相位：原型 ω3={w3:.3f}，各级 f0 都在 fc 之上，"
                f"10×fc 只衰减 {a10:.1f}dB（同阶 Butterworth 是 {20 * order}dB 量级）。"
                f"另外它的 −3dB 点对 Q 很敏感（Q 掉 5% 会让 f3dB 掉约 13%），"
                f"fc 的批次分散度比 Butterworth 大——要稳定的截止点别选 Bessel。"
            )
        else:
            a2 = m.get("atten_2fc_db", _fnan())
            parts.append(
                f"Butterworth 通带最平坦、阻带按 {20 * order}dB/十倍频滚降："
                f"实测 2×fc 处 {a2:.1f}dB、10×fc 处 {a10:.1f}dB，"
                f"实测斜率 {m.get('slope_db_dec', _fnan()):.0f}dB/dec（理论 {20 * order}）。"
            )

        bands = [self.r_ratio(p.get(f"C{2 * i + 1}", 1.0), p.get(f"C{2 * i + 2}", 1.0),
                              p.get(f"Q{i + 1}", 1.0)) for i in range(order // 2)]
        if any(abs(b - 1.0) > 0.005 for b in bands):
            parts.append(
                "同级两只串联电阻**故意不相等**（R1/R2=" + "、".join(f"{b:.3f}" for b in bands)
                + "）：等值时 Q 只能由电容比决定，E24 的粒度会让 Q 偏 0.2%~2%、6 阶 Butterworth "
                "通带就冒出 0.4dB 鼓包；用阻值比精调后 Q 精确到 0.1% 以内。"
                "阻值比同样吃电阻容差，但对 Q 的灵敏度只有电容比的 1/5 左右。"
            )

        rmax = 0.0
        for i in range(order // 2):
            b = self.r_ratio(p.get(f"C{2 * i + 1}", 1.0), p.get(f"C{2 * i + 2}", 1.0),
                             p.get(f"Q{i + 1}", 1.0))
            rmax = max(rmax, p.get(f"R{i + 1}", 0.0) * b)
        if rmax > 3e5:
            parts.append(
                f"最大阻值约 {E.human_r(rmax)}：偏大，运放偏置电流与电阻热噪声会成为误差源，"
                f"工程上更愿意加大电容把这级阻值降下来。"
            )
        return "".join(parts)


class FilterHighpassSynth(Topology):
    """有源高通滤波器综合 —— 级联一阶 RC 高通 + 缓冲隔离。

    ## 为什么不用 Sallen-Key

    本可以做「低通的 RC↔CR 对偶」，但实测四条候选接法全不成立：
      · C1/C2 角色互换        → 退化成 1 阶（通带 −10dB、斜率 20dB/dec）
      · R1 直接对地（教材画法）→ 1kHz 点对，但 0.288×GBW 处冒 +20.9dB 假峰，
                                且加大 GBW 峰跟着跑（GBW=1e8 时 +37dB@288kHz）
      · 逐元件对偶            → 见下，f0 与 −3dB 点差 1.7 倍，不是标准二阶
      · 反相跟随              → 同退化成 1 阶
    逐元件对偶那条尤其危险：它通带 0dB、斜率 40dB/dec 看着全对，
    但 −3dB 点在 2.21×f0，f0 处只有 −8.28dB ——「曲线像对的」这类错误最难发现。

    所以改用**级联一阶高通**：每级一只电容串 + 一只电阻对地 + 单位增益缓冲。
    它给的响应不是 Butterworth（通带边缘不够陡），但：
      · −3dB 位置可精确标定（实测偏差 <0.1%）
      · 滚降严格 20·N dB/dec（与阶数一致）
      · 拓扑简单到不会错，每一级都是教科书里的一阶节

    ## 标定公式（已用 ngspice 核对）

    N 级相同一阶高通（每级 f1）级联，整机 −3dB 位置：
        |H(f)| = (x/√(1+x²))^N,  x = f/f1
        令 |H|²=½ ⇒ x² = ½^(1/N) / (1 − ½^(1/N))
    所以   f1 = fc / √( ½^(1/N) / (1 − ½^(1/N)) )
    实测（fc=1kHz、N=2）：f1=643.6Hz、−3dB=999.9Hz（偏差 −0.01%）。

    ## 阶数与级数的关系

    一阶节只能给奇数阶；偶数阶（如 2 阶）用「N=阶数/2 个二阶节」做不到，
    所以这里按**级数 = 阶数/2 向上取整**来用（2 阶 → 1 次要二阶？
    不行，一阶节串不出 2 阶）。因此本拓扑的 order 指**级数**（每级 1 阶），
    允许 1~3 级 → 1/2/3 阶，滚降 20/40/60 dB/dec。
    """

    id = "filter_highpass_synth"
    name = "有源高通滤波器综合（级联一阶节 + 缓冲隔离）"
    summary = (
        "输入阶数（1~3 级）+ 截止频率，给出各级 RC 高通元件值。"
        "每级 = 串联电容 + 对地电阻 + 单位增益缓冲，级间互不加载。"
        "阻带在截止频率以下按 20·N dB/十倍频滚降；−3dB 位置按级联公式精确标定。"
    )
    params = [
        Param("order", "级数（阶）", "enum", 1.0, 3.0),
        Param("C1", "级1 电容", "C", 1e-12, 1e-3, series="E24"),
        Param("R1", "级1 电阻", "R", 10.0, 1e6, series="E96"),
        Param("C2", "级2 电容", "C", 1e-12, 1e-3, series="E24"),
        Param("R2", "级2 电阻", "R", 10.0, 1e6, series="E96"),
        Param("C3", "级3 电容", "C", 1e-12, 1e-3, series="E24"),
        Param("R3", "级3 电阻", "R", 10.0, 1e6, series="E96"),
        Param("GBW", "运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "运放开环增益", "gain", 1e3, 1e7),
    ]
    enum_labels = {"order": {1: "1 阶", 2: "2 阶", 3: "3 阶"}}
    metrics_keys = ["gain_db", "fc", "peaking_db", "atten_db"]
    gain_node = "out"
    design_keys = {"order"}
    spec_overrides: dict[str, str] = {}

    #: 目标阻抗量级（与低通综合一致）
    R_TARGET = 10e3
    #: 电容只用 E24 的常用段，避免选到 0.1pF / 10mF 这种买不到的值
    CAP_RANGE = (1e-10, 1e-6)

    @staticmethod
    def order_of(p: dict[str, float]) -> int:
        n = int(round(float(p.get("order", 1))))
        return min((1, 2, 3), key=lambda k: abs(k - n))

    # ---- 标定：N 级级联的 f1 与整机 fc 的关系 ----
    @staticmethod
    def _cascade_x(n: int) -> float:
        """N 级级联时 x = f3/f1。|H|²=(x²/(1+x²))^N = ½ 的解。"""
        h = 0.5 ** (1.0 / max(int(n), 1))
        return math.sqrt(h / (1.0 - h))

    @classmethod
    def stage_f1(cls, fc: float, n: int) -> float:
        """整机 −3dB 定在 fc 时，每级的单极点频率 f1。"""
        return float(fc) / cls._cascade_x(n)

    def sweep_center(self, p) -> float | None:
        try:
            n = self.order_of(p)
            return self.stage_f1(1e3, n) * (p.get("R1", 1.0) / self.R_TARGET) * 1e3 \
                if False else 1.0 / (PI2 * float(p["R1"]) * float(p["C1"])) * self._cascade_x(n)
        except (KeyError, ZeroDivisionError, ValueError):
            return None

    # ---- 渲染 ----
    def render(self, p):
        n = self.order_of(p)
        f1 = 1.0 / (PI2 * float(p["R1"]) * float(p["C1"]))
        fc = f1 * self._cascade_x(n)
        lines = [f"* {n} 阶高通综合（{n} 级一阶 RC 串联，级间单位增益缓冲隔离）",
                 f"* 每级 f1={E.human_f(f1)}，整机 −3dB≈{E.human_f(fc)}", "Vin in 0 AC 1"]
        prev = "in"
        for i in range(n):
            c, r = f"C{i + 1}", f"R{i + 1}"
            na = f"h{i + 1}"
            out = "out" if i == n - 1 else f"b{i + 1}"
            lines.append(f"{c} {prev} {na} {E.fmt(p[c])}")
            lines.append(f"{r} {na} 0 {E.fmt(p[r])}")
            if i == n - 1:
                # 末级用真实运放宏模型（前面几级用理想缓冲，避免多级 GBW 累积）
                lines.append(f"X{i + 1} {na} out out OPA")
            else:
                lines.append(f"E{i + 1} {out} 0 {na} 0 1")
            prev = out
        lines += [opamp_subckt(p["A0"], p["GBW"]), AC_FULL, ".end"]
        return "\n".join(lines) + "\n"

    # ---- 测量 ----
    def _find_f3db_rising(self, xs, db, target):
        """从低频往高频找**第一次向上穿过** target 的点（对数轴线性插值）。

        高通的 −3dB 在上升沿上。取第一次穿越而不是最后一次：
        多级级联若有峰化还会再穿回来，取末尾会落到通带平台上。
        """
        for i in range(1, len(db)):
            lo, hi = db[i - 1], db[i]
            if lo < target <= hi and hi > lo:
                t = (target - lo) / (hi - lo)
                lx0, lx1 = math.log10(xs[i - 1]), math.log10(xs[i])
                return 10.0 ** (lx0 + t * (lx1 - lx0))
        return None

    def extract(self, res, p):
        w = res.waves["v(out)"]
        xs, db = w.x, w.db()
        # 参考电平 = 通带平台。高通通带在高频端，但**不能取 db[-1]**：
        # 扫频上限可能扫进运放滚降区，端点电平会偏低（低通那边取 db[0] 是同理的坑）。
        # 取「高频侧稳定段」的中位数：最后 10% 的点足够代表通带，又不被端点噪声影响。
        tail = db[int(len(db) * 0.9):] or db[-1:]
        ref = sorted(tail)[len(tail) // 2]
        peak = max(db) - ref
        fc = self._find_f3db_rising(xs, db, ref - 3.0103) or _fnan()

        def atten(f: float) -> float:
            """相对通带的衰减（正值=被压制）。扫频范围外不硬凑，返回 NaN。"""
            if not math.isfinite(f) or f <= 0 or f < xs[0] * 1.05:
                return _fnan()
            v = _db_interp(w, f)
            return (ref - v) if v is not None else _fnan()

        n = self.order_of(p)
        # ⚠ 斜率要在**远场**量，不能在 fc/4→fc/10 量：
        # 一阶节的渐近斜率 20dB/dec 只在 f≪f1 时才成立，过渡带里斜率偏小。
        # 实测（2 阶、fc=1kHz）：fc/4→fc/10 段只有 25dB/dec，
        # 而理论值 40dB/dec 要到 fc/100 以下才显出来。
        # 取样点用 fc/100 与 fc/1000（都在阻带深处），并检查是否落在扫频范围内。
        a2 = atten(fc / 2.0)
        a10 = atten(fc / 10.0)        # 判定用：0.1×fc 处的衰减（近场）
        a100 = atten(fc / 100.0)
        a1000 = atten(fc / 1000.0)
        slope = _fnan()
        if math.isfinite(a100) and math.isfinite(a1000):
            slope = a1000 - a100      # 相差一个十倍频，差值即 dB/dec
        elif math.isfinite(a10) and math.isfinite(a100):
            slope = a100 - a10
        return {
            "gain_db": ref,
            "fc": fc,
            "peaking_db": peak,
            "atten_db": a10,          # 判定用：0.1×fc 处的衰减
            "atten_2fc_db": a2,
            "atten_100fc_db": a100,   # 诊断：深阻带（远场斜率用）
            "slope_db_dec": slope,
            "q_max": 0.5,             # 一阶节恒为 0.5（保持与低通一致的键）
        }

    # ---- 设计 ----
    def design(self, spec):
        """按整机 fc、级数 N 反解各级 RC。

        先定 f1 = fc / x(N)，再选 E24 电容、算电阻，
        最后用**实际选中的元件值**回算 f1 并据此微调，保证整机 fc 落回目标。
        """
        fc = float(spec.get("fc") or spec.get("f0") or 1e3)
        # ⚑ 不再硬夹 fc：夹了就等于**改用户指标**（实测 fc=0.1Hz 报成 1Hz、+900%）。
        # 真的够不着时由元件反解 + Param.clamp 报「超出量程」，上层据此如实判未达标。
        n = self.order_of({"order": spec.get("order", 1)})
        want_f1 = self.stage_f1(fc, n)

        # 选电容：让 R 落在 R_TARGET 附近（C = 1/(2π·f1·R_TARGET)），再吸附 E24
        c_ideal = 1.0 / (PI2 * want_f1 * self.R_TARGET)
        lo, hi = self.CAP_RANGE
        c_ideal = min(max(c_ideal, lo), hi)
        caps = _series_values("E24", lo, hi) or [c_ideal]
        cap = min(caps, key=lambda v: abs(math.log(v / c_ideal)))
        r = 1.0 / (PI2 * want_f1 * cap)

        out: dict[str, float] = {"order": float(n)}
        for i in range(3):
            out[f"C{i + 1}"], out[f"R{i + 1}"] = cap, r
        # 运放带宽：级联后每级都要 GBW 远高于本级 f1，否则高频端通带下垂
        out["GBW"] = min(max(want_f1 * 1000.0, 1e6), 1e10)
        out["A0"] = float(spec.get("A0") or 1e5)
        return out

    def inactive_params(self, p):
        n = self.order_of(p)
        hide = set()
        for i in range(3):
            if i >= n:
                hide |= {f"C{i + 1}", f"R{i + 1}"}
        return hide

    def note(self, p, m):
        n = self.order_of(p)
        try:
            f1 = 1.0 / (PI2 * float(p["R1"]) * float(p["C1"]))
        except (KeyError, ZeroDivisionError):
            return ""
        fc = m.get("fc")
        x = self._cascade_x(n)
        parts = [
            f"{n} 阶高通：{n} 级一阶 RC 串联，级间用单位增益缓冲隔离（否则后级对地电阻会把前级负载拖偏，"
            f"实测 −3dB 会偏 2.5 倍）。每级 f1={E.human_f(f1)}，"
        ]
        if fc and math.isfinite(fc):
            parts.append(f"级联后整机 −3dB 实测 {E.human_f(fc)}（级联标定系数 x={x:.4f}）。")
        parts.append(
            f"滚降 {20 * n}dB/十倍频。**注意**：这不是 Butterworth——一阶节级联的通带边缘"
            f"不如同阶 Sallen-Key 陡，换来的是 −3dB 位置可精确标定、拓扑不会接错。"
        )
        gbw = float(p.get("GBW", 0))
        if fc and gbw and gbw / max(fc, 1e-9) < 100:
            parts.append(
                f"运放 GBW 只有 {gbw / fc:.0f}×fc，建议 ≥100×，否则通带高端会下垂。"
            )
        return "".join(parts)


class FilterBandpassSynth(Topology):
    """有源带通滤波器综合 —— 高通段 × 低通段 级联，级间缓冲隔离。

    ## 结构

    N 级一阶高通串 N 级一阶低通，每级之间用单位增益缓冲隔离（否则后级对地
    电阻会把前级负载拖偏，实测 −3dB 会偏 2.5 倍——见 filter_highpass_synth 的注释）。
    每侧 N 级，滚降两侧各 20·N dB/十倍频，所以**总阶数 = 2N**：
    order=2 → 每侧 1 级；order=4 → 每侧 2 级；order=6 → 每侧 3 级。

    ## 角频率必须联立求解，不能解耦

    直觉做法是「高通角频率 = fL/x(N)、低通角频率 = fH/x(N)」，其中 x(N) 是
    N 级级联的 −3dB 偏移系数。**这个做法在窄带时错得很厉害**：在目标下边沿 fL 处，
    低通段已经贡献了相当一部分衰减，两条曲线叠加后 −3dB 点会整体内缩。
    实测解耦做法在 fL/fH=900/1100（Q≈5）时，边沿偏到 −6dB 量级。

    所以这里用**联立求解**：在理想级联模型
        |H(f)| = (x/√(1+x²))^N · (1/√(1+y²))^N ,  x=f/f1h, y=f/f1l
    下交替二分 f1h（固定 f1l，令 |H(fL)|=½ 功率）与 f1l（固定 f1h，令 |H(fH)|=½），
    迭代到收敛。实测 8 组参数（含 Q=5 窄带、100Hz~100kHz 宽带）边沿全部落在 −3.01dB。

    ## 诚实声明

    这是「相同节级联」，**不是 Butterworth 带通**：通带的幅度形状不是最大平坦，
    窄带时还有插损（900~1100Hz 实测峰值 −2.97dB，宽带的 100~100kHz 只有 −0.01dB）。
    换来的是边沿位置可精确标定、拓扑简单到不会接错。窄带且要求低插损时，
    该用谐振型（rlc_bandpass）或多重反馈拓扑，`note()` 里会提示。
    """

    id = "filter_bandpass_synth"
    name = "有源带通滤波器综合（高通段 × 低通段级联）"
    summary = (
        "输入中心频率/带宽（或上下边沿）+ 阶数，自动解出高通段与低通段的角频率并给出元件值。"
        "每侧 N 级一阶节，级间缓冲隔离；两侧滚降各 20·N dB/十倍频，总阶数 = 2N。"
    )
    params = [
        Param("order", "阶数", "enum", 2.0, 6.0),
        Param("CHP", "高通段 电容", "C", 1e-12, 1e-3, series="E24"),
        Param("RHP", "高通段 电阻", "R", 10.0, 1e6, series="E96"),
        Param("CLP", "低通段 电容", "C", 1e-12, 1e-3, series="E24"),
        Param("RLP", "低通段 电阻", "R", 10.0, 1e6, series="E96"),
        Param("GBW", "运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "运放开环增益", "gain", 1e3, 1e7),
    ]
    enum_labels = {
        "order": {2: "2 阶（每侧 1 级）", 4: "4 阶（每侧 2 级）", 6: "6 阶（每侧 3 级）"},
    }
    metrics_keys = ["f0", "q", "bw", "gain_db"]
    gain_node = "out"
    design_keys = {"order"}
    spec_overrides: dict[str, str] = {}

    R_TARGET = 10e3
    CAP_RANGE = (1e-10, 1e-6)
    _TARGET_DB = -3.0103

    @staticmethod
    def order_of(p: dict[str, float]) -> int:
        n = int(round(float(p.get("order", 2))))
        return min((2, 4, 6), key=lambda k: abs(k - n))

    @classmethod
    def stages_of(cls, p: dict[str, float]) -> int:
        """每侧的级数 N = 阶数/2。"""
        return max(1, cls.order_of(p) // 2)

    # ---- 理想级联模型（求解用，纯数学，不仿真）----
    @staticmethod
    def _mag_db(f: float, f1h: float, f1l: float, n: int) -> float:
        x = f / f1h
        y = f / f1l
        hp = (x / math.sqrt(1.0 + x * x)) ** n
        lp = (1.0 / math.sqrt(1.0 + y * y)) ** n
        g = hp * lp
        return 20.0 * math.log10(g) if g > 0 else -300.0

    @classmethod
    def _solve_corners(cls, f_low: float, f_high: float, n: int) -> tuple[float, float, float]:
        """解每侧角频率，使响应的**峰值相对 −3dB** 点落在 f_low / f_high。

        返回 (f1h, f1l, 预估峰值dB)。

        ⚠ 两个曾经搞错的地方，别再犯：

        1) **带宽必须相对峰值算，不是绝对 −3.01dB**。级联 RC 窄带时峰值本身就有
           插损（900~1100Hz 的 1 级实测峰值 −5.2dB），此时"绝对 −3dB 电平"几乎就在
           峰顶上，用它定边沿会把带宽算成实际值的 10 倍（实测：目标 200Hz、量出 2204Hz）。
           judge 与 rlc_bandpass 用的都是「峰值降 3dB」这个标准口径，必须对齐。

        2) **不能用解耦公式**（f1h=fL/x、f1l=fH/x）。两段在边沿处互相吃掉衰减，
           窄带时误差很大。

        解法：级联响应在 log 频率上镜像对称（HP 段与 LP 段互为倒频），于是
            r = fH/fL = f1l/f1h，  |H(峰值)| = (r/(1+r))^n
            u = fL/f1h = fH/f1l，  |H(fL)| = u·r/√((1+u²)(r²+u²))
        令 |H(fL)| = 2^(−½)·(r/(1+r))^n，在 u∈(0,1) 上二分即可（f 单调递增）。
        """
        prod = float(f_low) * float(f_high)

        def drop(k: float) -> float:
            """角频率比为 k 时，f_low 处相对峰值的衰减量（正数）。"""
            f1h = math.sqrt(prod / k)
            f1l = math.sqrt(prod * k)
            pk = 20.0 * n * math.log10(k / (1.0 + k)) if k > 0 else -300.0
            return pk - cls._mag_db(f_low, f1h, f1l, n)

        if drop(1.0) < 3.0103:
            _q = math.sqrt(prod) / (f_high - f_low)
            _qmax = cls.q_max(n)
            # Q = f0/bw ⇒ 要 Q≤q_max 就得让 bw ≥ f0/q_max（带宽是**变宽**）
            _widen = math.sqrt(prod) / _qmax
            raise ValueError(
                f"级联 RC 带通做不到这么窄的通带：要 {f_low:g}~{f_high:g}Hz"
                f"（Q={_q:.2f}），而每侧 {n} 级（{2 * n} 阶）的结构上限是 Q={_qmax:.2f}。"
                f"三个可选方向：① 放宽带宽到 Q≤{_qmax:.2f}"
                f"（{f_high - f_low:.0f}Hz → 约 {_widen:.0f}Hz 以上）；"
                f"② 用 RLC 串联带通（谐振型，Q 可任意，但只有 2 阶）；"
                f"③ 需要高阶窄带时用低通原型做频率变换的综合，或 MFB 带通级联。")
        # drop(k) 随 k 单调递减（k=1 时衰减最大），二分
        lo, hi = 1.0, 1e6
        for _ in range(200):
            mid = math.sqrt(lo * hi)
            if drop(mid) > 3.0103:
                lo = mid
            else:
                hi = mid
        k = math.sqrt(lo * hi)
        return (math.sqrt(prod / k), math.sqrt(prod * k),
                20.0 * n * math.log10(k / (1.0 + k)))

    @classmethod
    def q_max(cls, n: int) -> float:
        """每侧 n 级时可达的最高 Q（Q = f0/bw，按「峰值降 3dB」口径）。

        由 20n·log10((r+1)/(2√r)) = 3.0103 解出最小可达的边沿比 r，再换成 Q：
            每侧 1 级（2 阶）→ 0.500    每侧 2 级（4 阶）→ 0.777
            每侧 3 级（6 阶）→ 0.981    每侧 4 级（8 阶）→ 1.150

        **这是级联 RC 的物理上限，不是实现缺陷**：单调上升再单调下降的无源串接
        结构没有谐振，Q 顶不上去。想要 Q>1 的窄带必须换谐振型（rlc_bandpass、
        多重反馈 MFB、或 Sallen-Key 的带通变体）。
        """
        g = 10.0 ** (3.0103 / (20.0 * max(1, int(n))))
        s = g + math.sqrt(max(g * g - 1.0, 0.0))
        return 1.0 / max(s - 1.0 / s, 1e-12)

    @staticmethod
    def _edges_from_spec(spec: dict[str, float]) -> tuple[float, float]:
        """从 spec 取上下边沿。支持 f_low/f_high、f0+bw、f0+q 三种写法。"""
        fl = spec.get("f_low") or spec.get("fL")
        fh = spec.get("f_high") or spec.get("fH")
        if fl and fh and float(fh) > float(fl):
            return float(fl), float(fh)
        f0 = float(spec.get("f0") or spec.get("fc") or 1e3)
        bw = spec.get("bw")
        if bw is None:
            q = spec.get("q")
            if q:
                bw = f0 / float(q)
        bw = float(bw) if bw else f0 / 5.0
        # f0 按几何中心理解：fL = (√(bw²+4f0²) − bw)/2 ，fH = f0²/fL
        f_low = (math.sqrt(bw * bw + 4.0 * f0 * f0) - bw) / 2.0
        f_high = (f0 * f0) / max(f_low, 1e-9)
        return f_low, f_high

    # ---- 渲染 ----
    def render(self, p):
        n = self.stages_of(p)
        f1h = 1.0 / (PI2 * float(p["RHP"]) * float(p["CHP"]))
        f1l = 1.0 / (PI2 * float(p["RLP"]) * float(p["CLP"]))
        lines = [f"* {2 * n} 阶带通综合（{n} 级高通 + {n} 级低通串联，级间缓冲隔离）",
                 f"* 高通段 f1={E.human_f(f1h)}，低通段 f1={E.human_f(f1l)}", "Vin in 0 AC 1"]
        prev = "in"
        # 高通段：C 串联、R 对地、缓冲
        for i in range(n):
            na = f"h{i + 1}"
            out = f"hb{i + 1}"
            lines += [f"CHP{i + 1} {prev} {na} {E.fmt(p['CHP'])}",
                      f"RHP{i + 1} {na} 0 {E.fmt(p['RHP'])}",
                      f"EHP{i + 1} {out} 0 {na} 0 1"]
            prev = out
        # 低通段：R 串联、C 对地、缓冲（末级用真实运放宏模型）
        for i in range(n):
            na = f"l{i + 1}"
            out = "out" if i == n - 1 else f"lb{i + 1}"
            lines.append(f"RLP{i + 1} {prev} {na} {E.fmt(p['RLP'])}")
            lines.append(f"CLP{i + 1} {na} 0 {E.fmt(p['CLP'])}")
            if i == n - 1:
                lines.append(f"X{i + 1} {na} out out OPA")
            else:
                lines.append(f"ELP{i + 1} {out} 0 {na} 0 1")
            prev = out
        lines += [opamp_subckt(p["A0"], p["GBW"]), AC_FULL, ".end"]
        return "\n".join(lines) + "\n"

    def sweep_card(self, p) -> str | None:
        """带通要同时看到两侧裙边：从高通角频率/50 到低通角频率×50。

        上限还要压住运放 GBW（扫进去会让高频裙边失真），下限不低于 1mHz。
        """
        try:
            f1h = 1.0 / (PI2 * float(p["RHP"]) * float(p["CHP"]))
            f1l = 1.0 / (PI2 * float(p["RLP"]) * float(p["CLP"]))
        except (KeyError, ZeroDivisionError, ValueError):
            return None
        lo = max(f1h / 50.0, 1e-3)
        hi = f1l * 50.0
        gbw = float(p.get("GBW") or 0)
        if gbw > 0:
            hi = min(hi, gbw / 20.0)
        if hi <= lo:
            return None
        return f".ac dec 200 {lo:.6g} {hi:.6g}"

    def sweep_center(self, p) -> float | None:
        try:
            f1h = 1.0 / (PI2 * float(p["RHP"]) * float(p["CHP"]))
            f1l = 1.0 / (PI2 * float(p["RLP"]) * float(p["CLP"]))
            return math.sqrt(f1h * f1l)
        except (KeyError, ZeroDivisionError, ValueError):
            return None

    # ---- 测量 ----
    def extract(self, res, p):
        w = res.waves["v(out)"]
        xs, db = w.x, w.db()
        if len(db) < 3:
            return {"f0": _fnan(), "q": _fnan(), "bw": _fnan(), "gain_db": _fnan()}
        imax = max(range(len(db)), key=lambda i: db[i])
        peak = db[imax]
        target = peak - 3.0103
        # 左侧（上升沿）：从峰值往低频找第一次跌破
        lo3 = None
        for i in range(imax, 0, -1):
            if db[i - 1] < target <= db[i]:
                lo3 = _interp_x(xs[max(0, i - 1):i + 1], db[max(0, i - 1):i + 1], target)
                break
        # 右侧（下降沿）
        hi3 = None
        for i in range(imax, len(db) - 1):
            if db[i] >= target > db[i + 1]:
                hi3 = _interp_x(xs[i:i + 2], db[i:i + 2], target)
                break
        if lo3 and hi3 and hi3 > lo3:
            bw = hi3 - lo3
            f0 = math.sqrt(lo3 * hi3)      # 几何中心（带通的标准定义）
            q = f0 / bw if bw > 0 else _fnan()
        else:
            bw = f0 = q = _fnan()
        return {"f0": f0, "q": q, "bw": bw, "gain_db": peak,
                "f_low": lo3 if lo3 else _fnan(), "f_high": hi3 if hi3 else _fnan()}

    # ---- 设计 ----
    def design(self, spec):
        n_req = self.order_of({"order": spec.get("order", 2)})
        n = max(1, n_req // 2)
        f_low, f_high = self._edges_from_spec(spec)
        f_low = min(max(f_low, 1e-2), 5e6)
        f_high = min(max(f_high, f_low * 1.0001), 5e7)
        f1h, f1l, _gpk = self._solve_corners(f_low, f_high, n)

        def pick(f1):
            c_ideal = 1.0 / (PI2 * f1 * self.R_TARGET)
            lo, hi = self.CAP_RANGE
            c_ideal = min(max(c_ideal, lo), hi)
            vals = _series_values("E24", lo, hi) or [c_ideal]
            c = min(vals, key=lambda v: abs(math.log(v / c_ideal)))
            return c, 1.0 / (PI2 * f1 * c)

        chp, rhp = pick(f1h)
        clp, rlp = pick(f1l)
        return {
            "order": float(n_req),
            "CHP": chp, "RHP": rhp, "CLP": clp, "RLP": rlp,
            # 两级以上的级联都要 GBW 远高于最高角频率，否则高端裙边被运放压平
            "GBW": min(max(f1l * 1000.0, 1e6), 1e10),
            "A0": float(spec.get("A0") or 1e5),
        }

    def inactive_params(self, p):
        return set()

    def note(self, p, m):
        n = self.stages_of(p)
        try:
            f1h = 1.0 / (PI2 * float(p["RHP"]) * float(p["CHP"]))
            f1l = 1.0 / (PI2 * float(p["RLP"]) * float(p["CLP"]))
        except (KeyError, ZeroDivisionError):
            return ""
        parts = [
            f"{2 * n} 阶带通：{n} 级一阶高通串 {n} 级一阶低通（级间缓冲隔离），"
            f"两侧滚降各 {20 * n}dB/十倍频。"
            f"高通段角频率 {E.human_f(f1h)}、低通段 {E.human_f(f1l)}，"
            f"这两个值由**联立求解**得到（不是简单取 fL、fH），因为窄带时两段在边沿处互相吃掉衰减。"
        ]
        q = m.get("q")
        g = m.get("gain_db")
        if q and math.isfinite(q) and g is not None and math.isfinite(g):
            if q > 5 and g < -1.0:
                parts.append(
                    f"带宽较窄（Q={q:.2f}），插损 {g:+.2f}dB：这是相同节级联的固有代价。"
                    f"若要求低插损，应改用谐振型（rlc_bandpass）或多重反馈带通。"
                )
        return "".join(parts)


class TwinTNotch(Topology):
    """Twin-T 双 T 陷波器（无源）—— 掐掉单一频率，其余放行。

    ## 结构

    两个 T 网络并联，输入同一点、输出同一点：

        R1 → a → R2 ┐            a 点经 C3 接地      （低通 T）
        C1 → b → C2 ┤→ t → 缓冲   b 点经 R3 接地      （高通 T）
                    └→ out

    在 f0 = 1/(2πRC) 处，两条支路对输出节点的贡献**大小相等、方向相反**，
    互相抵消，V(t)≈0 —— 这就是凹陷。所以：

    **对称条件是全部**（实测核对，不是查表）：R1=R2=R、C1=C2=C、
    **C3=2C、R3=R/2**。写成 C3=C/2、R3=2R（我第一版就是这样）只会得到 −5dB 的
    「小坑」，看着像能用，其实只压下去了 5dB——工频干扰照样过。

    ## 无源 Twin-T 的两个硬事实

    1. **Q 固定 0.25**：实测 −3dB 带宽 11.8~211.5Hz、Q=0.250，与理论一致。
       带宽 = 4×f0。要更窄（Q>1）必须加正反馈（有源陷波），本工具暂不做。
    2. **凹陷深度由元件匹配决定，不是由结构决定**：理想匹配下实测 −76dB，
       但一只电阻偏 5% 就掉到约 −50dB，全器件随机散布（蒙特卡洛）会明显再浅。
       这是 Twin-T 最容易被忽略的一点：标称值算对不等于量产能挖那么深。

    ## 输出为什么经缓冲

    两条支路的汇合点 t 是**高阻节点**（只接 R2、C2），直接拿去用会被后级负载
    一挂就破坏抵消条件。所以用单位增益缓冲隔离，out = V(t)。
    """

    id = "twin_t_notch"
    name = "Twin-T 双 T 陷波器（50/60Hz 工频干扰）"
    summary = (
        "无源 Twin-T 陷波：在 f0=1/(2πRC) 处把该频率掐掉（实测 −76dB），两侧放行。"
        "Q 固定 0.25（带宽=4×f0），凹陷深度取决于 R1/R2 与 C1/C2 的匹配精度。"
    )
    params = [
        Param("R1", "串联电阻 R1", "R", 10.0, 1e6, series="E96"),
        Param("R2", "串联电阻 R2", "R", 10.0, 1e6, series="E96"),
        Param("C1", "串联电容 C1", "C", 1e-12, 1e-3, series="E24"),
        Param("C2", "串联电容 C2", "C", 1e-12, 1e-3, series="E24"),
        Param("R3", "并联电阻 R3（对地）", "R", 1.0, 1e6, series="E96"),
        Param("C3", "并联电容 C3（对地）", "C", 1e-12, 1e-3, series="E24"),
        Param("GBW", "缓冲运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "缓冲运放开环增益", "gain", 1e3, 1e7),
    ]
    metrics_keys = ["f0", "depth_db", "q", "bw", "gain_db"]
    gain_node = "out"
    design_keys: set[str] = set()
    spec_overrides: dict[str, str] = {}

    R_TARGET = 10e3
    CAP_RANGE = (1e-10, 1e-6)

    def render(self, p):
        return (
            f"* Twin-T 陷波（R1=R2={E.fmt(p['R1'])}，C1=C2={E.fmt(p['C1'])}，"
            f"C3=2C={E.fmt(p['C3'])}，R3=R/2={E.fmt(p['R3'])}）\n"
            f"Vin in 0 AC 1\n"
            f"R1 in a {E.fmt(p['R1'])}\n"
            f"R2 a t {E.fmt(p['R2'])}\n"
            f"C3 a 0 {E.fmt(p['C3'])}\n"
            f"C1 in b {E.fmt(p['C1'])}\n"
            f"C2 b t {E.fmt(p['C2'])}\n"
            f"R3 b 0 {E.fmt(p['R3'])}\n"
            f"Xt t out out OPA\n"
            f"{opamp_subckt(p['A0'], p['GBW'])}\n{AC_FULL}\n.end"
        )

    def sweep_center(self, p) -> float | None:
        try:
            return 1.0 / (PI2 * float(p["R1"]) * float(p["C1"]))
        except (KeyError, ZeroDivisionError, ValueError):
            return None

    def sweep_card(self, p) -> str | None:
        """凹陷是窄带特征，扫频要围着 f0 足够密。

        无源 Twin-T 的 Q=0.25，凹口本身不算极窄，但深度对频率很敏感
        （偏 1% 就可能少 10dB），所以用 800 点/十倍频、上下各 2 个十倍频。
        """
        c = self.sweep_center(p)
        if not c:
            return None
        lo = max(c / 100.0, 1e-3)
        hi = min(c * 100.0, float(p.get("GBW") or 1e9) / 20.0)
        if hi <= lo:
            return None
        return f".ac dec 800 {lo:.6g} {hi:.6g}"

    def extract(self, res, p):
        w = res.waves["v(out)"]
        xs, db = w.x, w.db()
        if len(db) < 3:
            return {"f0": _fnan(), "depth_db": _fnan(), "q": _fnan(),
                    "bw": _fnan(), "gain_db": _fnan()}
        # 通带参考：两侧（很低与很高频）电平应当一致，取两者较大值更稳
        ref = max(db[0], db[-1])
        imin = min(range(len(db)), key=lambda i: db[i])
        depth = ref - db[imin]
        f_notch = xs[imin]
        # −3dB 带宽：通带电平降 3dB 的两个交点（凹陷两侧各一个）
        tgt = ref - 3.0103
        cross = []
        for i in range(1, len(db)):
            a, b = db[i - 1] - tgt, db[i] - tgt
            if a * b <= 0 and db[i] != db[i - 1]:
                t = (tgt - db[i - 1]) / (db[i] - db[i - 1])
                cross.append(10 ** (math.log10(xs[i - 1])
                                   + t * (math.log10(xs[i]) - math.log10(xs[i - 1]))))
        if len(cross) >= 2:
            lo3, hi3 = cross[0], cross[-1]
            bw = hi3 - lo3
            q = f_notch / bw if bw > 0 else _fnan()
        else:
            lo3 = hi3 = bw = q = _fnan()
        return {"f0": f_notch, "depth_db": depth, "q": q, "bw": bw,
                "gain_db": db[0], "f_low": lo3, "f_high": hi3}

    def design(self, spec):
        """由 f0 反解元件。f0 = 1/(2πRC)，取 R1=R2=R、C1=C2=C、C3=2C、R3=R/2。"""
        f0 = float(spec.get("f0") or spec.get("fc") or 50.0)
        # ⚑ 这里原来写 `f0 = min(max(f0, 0.1), 1e6)` —— **直接改掉了用户给的指标**。
        # 实测：要 2MHz 陷波，工具"实测"报 1.00027MHz（−50%）却当成达标，
        # 因为判据比对的是被改过的 f0 语境。用户要什么就是什么，做不到就如实说。
        # 元件量程夹紧留给下面的 c/r 反解与 `Param.clamp`（会留"超出量程"警告）。
        c_ideal = 1.0 / (PI2 * f0 * self.R_TARGET)
        lo, hi = self.CAP_RANGE
        c_ideal = min(max(c_ideal, lo), hi)
        vals = _series_values("E24", lo, hi) or [c_ideal]
        c = min(vals, key=lambda v: abs(math.log(v / c_ideal)))
        r = 1.0 / (PI2 * f0 * c)
        return {
            "R1": r, "R2": r, "C1": c, "C2": c,
            "R3": r / 2.0, "C3": 2.0 * c,
            # 缓冲要在 f0 以上仍有足够环路增益：给 1000×f0，与其它综合拓扑同量级
            "GBW": min(max(f0 * 1000.0, 1e6), 1e10),
            "A0": float(spec.get("A0") or 1e5),
        }

    def note(self, p, m):
        try:
            f0 = 1.0 / (PI2 * float(p["R1"]) * float(p["C1"]))
        except (KeyError, ZeroDivisionError):
            return ""
        q = m.get("q")
        depth = m.get("depth_db")
        parts = [
            f"Twin-T 陷波：f0=1/(2πRC)={E.human_f(f0)}，对称条件 "
            f"R1=R2、C1=C2、C3=2C、R3=R/2（缺一条凹陷就只剩几 dB）。"
        ]
        if q is not None and math.isfinite(q):
            parts.append(
                f"无源 Twin-T 的 Q 是**固定的 0.25**（实测 {q:.3f}），"
                f"带宽 = 4×f0 ≈ {4 * f0:.0f}Hz —— 它不只掐 {E.human_f(f0)}，"
                f"±2 个倍频程内都有明显衰减。要更窄（Q>1）必须加正反馈做成有源陷波。"
            )
        if depth is not None and math.isfinite(depth):
            parts.append(
                f"凹陷深度实测 {depth:.1f}dB，但它**取决于元件匹配**而不是结构："
                f"一只电阻偏 5% 就少约 25dB。量产深度请看容差分析（蒙特卡洛）的结果，"
                f"不要只看标称值的这个数。"
            )
        return "".join(parts)
