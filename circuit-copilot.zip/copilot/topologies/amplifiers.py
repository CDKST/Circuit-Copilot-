"""运放类拓扑：同相/反相放大与差分放大（减法器）。

三者共享同一套运放建模脚手架——`opamp_subckt` 行为级子电路、开环/闭环两套网表的
跑法、环路相位裕度判据 `_pm_from_loop`——放在一起才好对照阅读。

`OpampInverting` 直接继承 `OpampNonInverting`（只换输入节点与增益符号），两者必须
同文件；`DifferenceAmp` 复用的也是同一套运放建模与 CMRR 判据。
"""

from __future__ import annotations

import math

from .. import elements as E
from .. import sim

from .base import (
    AC_FAST,
    AC_FULL,
    AC_LOOP,
    Param,
    Topology,
    _combine_cmrr_db,
    _find_f3db,
    _fnan,
    _interp_x,
    _pm_from_loop,
    opamp_subckt,
)

# ==========================================================================
# 5. 运放同相放大
# ==========================================================================
class OpampNonInverting(Topology):
    id = "opamp_noninverting"
    name = "运放同相放大"
    summary = "高输入阻抗、增益 = 1+R2/R1。实际带宽受 GBW 限制：BW = GBW/增益。"
    params = [
        Param("R1", "接地电阻 R1", "R", 1.0, 1e6, series="E96"),
        Param("R2", "反馈电阻 R2", "R", 1.0, 1e7, series="E96"),
        Param("GBW", "运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "运放开环增益", "gain", 1e3, 1e7),
    ]
    metrics_keys = ["gain_lin", "gain_db", "fc", "ugf", "pm", "peaking_db"]
    gain_node = "out"
    spec_overrides = {"fc": "min"}  # 放大器：要求「带宽不低于」

    def _circuit(self, p, loop_break: bool = False):
        if not loop_break:
            return (
                f"Vin src 0 AC 1\n"
                f"R1 inn 0 {E.fmt(p['R1'])}\n"
                f"R2 out inn {E.fmt(p['R2'])}\n"
                f"X1 src inn out OPA\n"
            )
        # 环路增益测试：输入接地，在输出与反馈网络之间串入 1V 交流源
        return (
            f"Vin src 0 AC 0\n"
            f"R1 inn 0 {E.fmt(p['R1'])}\n"
            f"R2 fb inn {E.fmt(p['R2'])}\n"
            f"X1 src inn oa OPA\n"
            f"Vx oa fb AC 1\n"
        )

    def render(self, p, loop_break: bool = False):
        return (
            f"* 运放同相放大\n"
            + self._circuit(p, loop_break)
            + "Rload out 0 1Meg\n"
            + opamp_subckt(p["A0"], p["GBW"])
            + "\n"
            + AC_FULL
            + "\n.end"
        )

    def extract(self, res, p):
        w = res.waves["v(out)"]
        db = w.db()
        dc = db[0]
        fc = _find_f3db(w, dc)
        ugf = _interp_x(w.x, db, 0.0)
        peak = max(db) - dc
        # 环路增益 → 相位裕度
        pm = float("nan")
        try:
            loop = sim.run(self.render(p, loop_break=True))
            vo = loop.waves["v(oa)"].y
            t = [v / (1 - v) for v in vo]
            mag = [abs(v) for v in t]
            ph = [math.degrees(math.atan2(v.imag, v.real)) for v in t]
            xs = loop.waves["v(oa)"].x
            # |T| 穿越 1 的频率（对数轴线性插值）
            idx = None
            for i in range(1, len(mag)):
                if mag[i - 1] >= 1.0 >= mag[i]:
                    idx = i
                    break
            if idx:
                t_f = (1.0 - mag[idx - 1]) / (mag[idx] - mag[idx - 1])
                ph_c = ph[idx - 1] + t_f * (ph[idx] - ph[idx - 1])
                pm = 180.0 + ph_c
        except sim.SimError:
            pass
        return {
            "gain_db": dc,
            "gain_lin": 10 ** (dc / 20),
            "fc": fc if fc else float("nan"),
            "ugf": ugf if ugf else float("nan"),
            "pm": pm,
            "peaking_db": peak,
        }

    def design(self, spec):
        g = (
            spec.get("gain_lin")
            or spec.get("gain")
            or (10 ** (spec["gain_db"] / 20) if "gain_db" in spec else 10.0)
        )
        r1 = spec.get("R1") or 1e3
        r2 = (g - 1) * r1
        # 为带宽留裕量：先按目标带宽选 GBW
        gbw = spec.get("GBW") or ((spec.get("bw") or spec.get("fc") or 1e4) * g * 1.3)
        return {"R1": r1, "R2": r2, "GBW": gbw, "A0": spec.get("A0") or 1e5}


# ==========================================================================
# 6. 运放反相放大
# ==========================================================================
class OpampInverting(OpampNonInverting):
    id = "opamp_inverting"
    name = "运放反相放大"
    summary = "增益 = −R2/R1，输入阻抗 = R1。虚地结构，抗共模能力强。"
    metrics_keys = ["gain_lin", "gain_db", "fc", "ugf", "pm", "peaking_db"]

    def _circuit(self, p, loop_break: bool = False):
        if not loop_break:
            return (
                f"Vin src 0 AC 1\n"
                f"R1 src inn {E.fmt(p['R1'])}\n"
                f"R2 out inn {E.fmt(p['R2'])}\n"
                f"X1 0 inn out OPA\n"
            )
        return (
            f"Vin src 0 AC 0\n"
            f"R1 src inn {E.fmt(p['R1'])}\n"
            f"R2 fb inn {E.fmt(p['R2'])}\n"
            f"X1 src inn oa OPA\n"
            f"Vx oa fb AC 1\n"
        )

    def design(self, spec):
        """反相放大：|增益| = R2/R1 → R2 = |增益|·R1。

        原先继承了同相版的 (g−1)·R1，10 倍反相算出 9k/1k=9.09 倍；
        且候选搜索只在初值 ±2 档内游走，永远够不到正确的 10k（B2）。
        """
        g = (
            spec.get("gain_lin")
            or spec.get("gain")
            or (10 ** (spec["gain_db"] / 20) if "gain_db" in spec else 10.0)
        )
        r1 = spec.get("R1") or 1e3
        r2 = abs(g) * r1
        bw = spec.get("bw") or spec.get("fc") or 1e4
        gbw = spec.get("GBW") or (bw * (1.0 + abs(g)) * 1.3)  # 噪声增益决定带宽
        return {"R1": r1, "R2": r2, "GBW": gbw, "A0": spec.get("A0") or 1e5}

    def render(self, p, loop_break: bool = False):
        return (
            f"* 运放反相放大\n"
            + self._circuit(p, loop_break)
            + "Rload out 0 1Meg\n"
            + opamp_subckt(p["A0"], p["GBW"])
            + "\n"
            + AC_FULL
            + "\n.end"
        )


# ==========================================================================
# 9. 差分放大 / 减法器（单运放四电阻）
# ==========================================================================
class DifferenceAmp(Topology):
    """单运放差动放大器。

        Vout = (R4/(R3+R4))·(1+R2/R1)·Vin2 − (R2/R1)·Vin1

    取 R1=R3、R2=R4 时差模增益 Ad=R2/R1，共模增益理论为 0。

    CMRR 由两个误差源并联决定，谁也压不住谁：
        1/CMRR = 1/CMRR_电阻失配 + 1/CMRR_运放自身
      - 电阻失配：CMRR ≈ (1+R2/R1)/(4·δ)。1% 电阻、Ad=10 时最好只有 ≈49dB，
        0.1% 才有 ≈69dB（解析式与 ngspice 实测在最坏符号组合上吻合到 0.001dB）。
      - 运放自身：典型 80~100dB，参数 CMRR_OPA 可调。

    注意 `opamp_subckt()` 是**理想运放**（无限共模抑制），所以共模仿真只能给出
    电阻失配那一半。若直接把它当总 CMRR 报出去会得到 100dB 以上的假数字，
    因此提取时用上面的串联公式与 CMRR_OPA 合成，并额外保留 cmrr_res_db
    让报告能区分「仿真测到的电阻失配贡献」和「合成后的真实可达值」。
    """

    id = "difference_amp"
    name = "差分放大 / 减法器"
    summary = (
        "单运放四电阻差动放大，Ad=R2/R1（需 R2=R4、R1=R3）。CMRR 由电阻匹配"
        "（≈(1+Ad)/4δ）与运放自身 CMRR 并联决定：1% 电阻只能到 ~48dB，"
        "想摸到运放的 90dB 必须用匹配电阻阵列或集成差分放大器。"
    )
    params = [
        Param("R1", "反相输入电阻 R1", "R", 1.0, 1e6, series="E96"),
        Param("R2", "反相反馈电阻 R2", "R", 1.0, 1e7, series="E96"),
        Param("R3", "同相输入电阻 R3", "R", 1.0, 1e6, series="E96"),
        Param("R4", "同相接地电阻 R4", "R", 1.0, 1e7, series="E96"),
        Param("GBW", "运放 GBW", "opamp", 1e4, 1e10),
        Param("A0", "运放开环增益", "gain", 1e3, 1e7),
        Param("CMRR_OPA", "运放自身 CMRR", "db", 60.0, 140.0),
    ]
    metrics_keys = ["gain_lin", "gain_db", "cmrr_db", "fc", "pm"]
    gain_node = "out"
    spec_overrides = {"fc": "min", "cmrr_db": "min"}

    def _circuit(self, p: dict[str, float], mode: str = "diff") -> str:
        """mode: diff=差模激励 / cm=共模激励 / loop=环路增益测试（两输入接地）。"""
        if mode == "loop":
            return (
                f"Vin1 in1 0 AC 0\n"
                f"Vin2 in2 0 AC 0\n"
                f"R1 in1 inn {E.fmt(p['R1'])}\n"
                f"R2 fb inn {E.fmt(p['R2'])}\n"
                f"R3 in2 inp {E.fmt(p['R3'])}\n"
                f"R4 inp 0 {E.fmt(p['R4'])}\n"
                f"X1 inp inn oa OPA\n"
                f"Vx oa fb AC 1\n"
            )
        ac2 = "1" if mode == "cm" else "0"
        return (
            f"Vin1 in1 0 AC 1\n"
            f"Vin2 in2 0 AC {ac2}\n"
            f"R1 in1 inn {E.fmt(p['R1'])}\n"
            f"R2 out inn {E.fmt(p['R2'])}\n"
            f"R3 in2 inp {E.fmt(p['R3'])}\n"
            f"R4 inp 0 {E.fmt(p['R4'])}\n"
            f"X1 inp inn out OPA\n"
            f"Rload out 0 1Meg\n"
        )

    def render(self, p, mode: str = "diff"):
        ac = AC_LOOP if mode == "loop" else AC_FAST
        tag = {"diff": "差分放大（差模激励）", "cm": "差分放大（共模激励）",
               "loop": "差分放大（环路增益）"}[mode]
        return f"* {tag}\n" + self._circuit(p, mode) + opamp_subckt(p["A0"], p["GBW"]) + "\n" + ac + "\n.end"

    def cmrr_theory_db(self, p: dict[str, float]) -> float:
        """理想运放下由电阻失配决定的 CMRR（报告里的失配敏感性提示就靠它）。"""
        r1, r2, r3, r4 = p["R1"], p["R2"], p["R3"], p["R4"]
        ad = r2 / r1
        ac = (r4 / (r3 + r4)) * (1.0 + r2 / r1) - r2 / r1
        if abs(ac) < 1e-18:
            return float("inf")
        return 20.0 * math.log10(abs(ad / ac))

    def extract(self, res, p):
        w = res.waves["v(out)"]
        xs, db = w.x, w.db()
        ad = abs(w.y[0])  # 差模增益（DC，输入 AC 1）
        gain_db = 20.0 * math.log10(ad) if ad > 0 else _fnan()
        fc = _interp_x(xs, db, db[0] - 3.0103)
        # 共模：两输入同时加 AC 1 → 仿真测到的只是「电阻失配 + 有限 A0」那一半
        cmrr_res = _fnan()
        try:
            rc = sim.run(self.render(p, "cm"))
            ac = abs(rc.waves["v(out)"].y[0])
            if ac > 0 and ad > 0:
                cmrr_res = 20.0 * math.log10(ad / ac)
        except (sim.SimError, KeyError):
            pass
        return {
            "gain_lin": ad,
            "gain_db": gain_db,
            # 真实可达 CMRR：与运放自身 CMRR 按误差串联合成
            "cmrr_db": _combine_cmrr_db(cmrr_res, p.get("CMRR_OPA", 90.0)),
            "cmrr_res_db": cmrr_res,
            "fc": fc if fc else _fnan(),
            "pm": _pm_from_loop(self.render(p, "loop")),
        }

    def design(self, spec):
        g = (
            spec.get("gain_lin")
            or spec.get("gain")
            or (10 ** (spec["gain_db"] / 20.0) if "gain_db" in spec else 10.0)
        )
        g = min(max(float(g), 0.1), 1000.0)
        # 差模输入阻抗 = 2·R1，先取 10k；增益大时压低 R1，免得 R2 顶到量程
        r1 = 10e3 if g * 10e3 <= 1e6 else max(1e6 / g, 1.0)
        r2 = g * r1  # 差动结构 Ad = R2/R1（不像同相放大要 +1）
        fc = spec.get("fc")
        # 噪声增益 = 1+g，闭环带宽 ≈ GBW/(1+g)；fc 是「不低于」型指标，留 30% 裕量
        gbw = (float(fc) * (1.0 + g) * 1.3) if fc else 1e6
        return {"R1": r1, "R2": r2, "R3": r1, "R4": r2,
                "GBW": gbw, "A0": spec.get("A0") or 1e5,
                "CMRR_OPA": float(spec.get("CMRR_OPA") or 90.0)}

    def _cmrr_worst(self, p, delta: float) -> float:
        """四个电阻各自 ±δ 的最坏符号组合下的 CMRR（理想运放解析式）。"""
        lo = float("inf")
        for bits in range(16):
            s = [delta if (bits >> k) & 1 else -delta for k in range(4)]
            v = {
                "R1": p["R1"] * (1 + s[0]), "R2": p["R2"] * (1 + s[1]),
                "R3": p["R3"] * (1 + s[2]), "R4": p["R4"] * (1 + s[3]),
            }
            lo = min(lo, self.cmrr_theory_db(v))
        return lo

    def note(self, p, m):
        """把这个拓扑最有价值的结论写清楚：CMRR 是三笔账，不是仿真器那一个数字。"""
        g = p["R2"] / p["R1"]
        opa = float(p.get("CMRR_OPA", 90.0))
        res_db = m.get("cmrr_res_db")
        total = m.get("cmrr_db")
        nominal = self.cmrr_theory_db(p)
        w1, w01 = self._cmrr_worst(p, 0.01), self._cmrr_worst(p, 0.001)

        parts = [f"差模增益 Ad={g:.4g}（噪声增益 1+Ad={1 + g:.4g}，闭环带宽 ≈ GBW/(1+Ad)）。"]

        if res_db is None or not math.isfinite(res_db):
            parts.append("共模仿真未取到有效值，CMRR 只能按容差估算。")
        elif res_db >= 120.0:
            parts.append(
                f"电阻比值严格匹配，共模仿真只测到有限 A0 的残余（{res_db:.0f}dB）——"
                f"这一项已经不是真实的限制，别把它当结论。"
            )
        else:
            parts.append(
                f"电阻失配这一项仿真测到 {res_db:.1f}dB"
                + (f"（理想运放解析上限 {nominal:.1f}dB，两者一致）" if math.isfinite(nominal) else "")
                + "。"
            )

        if total is not None and math.isfinite(total):
            parts.append(
                f"加上运放自身 CMRR={opa:.0f}dB 后按 1/CMRR 串联合成，"
                f"**真实可达 CMRR = {total:.1f}dB**。"
            )

        parts.append(
            f"落到实际元件：四个电阻各 ±1% 时失配最坏 {w1:.0f}dB、合成后 "
            f"{_combine_cmrr_db(w1, opa):.1f}dB；各 ±0.1% 时 {w01:.0f}dB、合成后 "
            f"{_combine_cmrr_db(w01, opa):.1f}dB。"
        )
        if _combine_cmrr_db(w01, opa) < opa - 1.0:
            parts.append(
                f"也就是说：默认档电阻（±1%）把运放那 {opa:.0f}dB 白扔了 "
                f"{opa - _combine_cmrr_db(w1, opa):.0f}dB。想用满运放的 CMRR，"
                f"必须用同批次匹配电阻阵列或集成差分放大器（INA/AD8xxx），而不是挑更贵的运放。"
            )
        else:
            parts.append("电阻容差已经足够紧，此时限制在运放自身 CMRR 上，换低 CMRR 漂移的运放才有意义。")
        return "".join(parts)
