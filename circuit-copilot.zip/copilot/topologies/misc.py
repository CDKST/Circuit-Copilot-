"""不属于滤波器、也不属于运放放大器的零散拓扑。

目前只有 Divider（电阻分压）：纯无源分压网络，判据是「功耗 vs 输出阻抗」，既没有
极点也没有运放，塞进 `filters.py` 或 `amplifiers.py` 都名不副实，单独一个文件最省心。
以后新增同类（分流器、衰减器、端接网络之类）也放这里。
"""

from __future__ import annotations

from .. import elements as E

from .base import (
    Param,
    Topology,
)

# ==========================================================================
# 4. 电阻分压
# ==========================================================================
class Divider(Topology):
    id = "divider"
    name = "电阻分压网络"
    summary = "ADC 采样前级、基准分压、偏置网络。真正的取舍在「功耗 vs 输出阻抗」。"
    params = [
        Param("R1", "上臂 R1", "R", 1.0, 1e8, series="E96"),
        Param("R2", "下臂 R2", "R", 1.0, 1e8, series="E96"),
        Param("Vin", "输入电压", "volt", 0.1, 100.0),
    ]
    metrics_keys = ["vout", "iout", "power", "rout"]

    def render(self, p):
        return (
            f"* 电阻分压\n"
            f"Vin in 0 DC {E.fmt(p['Vin'])} AC 1\n"
            f"R1 in out {E.fmt(p['R1'])}\n"
            f"R2 out 0 {E.fmt(p['R2'])}\n"
            f".ac dec 1 1 10\n.end"
        )

    def extract(self, res, p):
        w = res.waves["v(out)"]
        vout = abs(w.y[0]) * p["Vin"]
        itot = p["Vin"] / (p["R1"] + p["R2"])
        return {
            "vout": vout,
            "iout": itot,
            "power": p["Vin"] * itot,
            "rout": (p["R1"] * p["R2"]) / (p["R1"] + p["R2"]),
        }

    def design(self, spec):
        vout, vin = spec["vout"], spec["Vin"]
        ratio = vout / vin
        # 折中：总阻值 10kΩ 量级（功耗 ~0.5mW @5V，输出阻抗可控）
        total = spec.get("Rtotal") or 10e3
        r2 = total * ratio
        r1 = total - r2
        return {"R1": r1, "R2": r2, "Vin": vin}
