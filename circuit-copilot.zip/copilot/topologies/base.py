"""拓扑库的地基：数据模型 + 判据/测量辅助 + 网表脚手架。

放这里的是「所有拓扑都要用、且互相之间没有方向性」的东西：`MetricInfo`/`Param`/
`Design`/`Topology` 这一套数据模型与 `METRICS` 词表，从仿真波形反算指标的判据辅助
（`_find_f3db`/`_passband_db`/`_q_from_peaking` …），以及扫频卡、行为级运放子电路
这类网表脚手架。

不放别处的原因：`filters.py` / `amplifiers.py` / `misc.py` 全部依赖本模块，而本模块
不 import 它们任何一个——依赖只有这一个方向，绕不成环。极点表虽然也是通用数学，但
只有滤波器综合会用到，所以留在 `filters.py`。
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

from .. import elements as E
from .. import sim

PI2 = 2.0 * math.pi


# --------------------------------------------------------------------------
# 指标词表（全局统一，报告与前端都靠它渲染）
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class MetricInfo:
    label: str
    unit: str
    fmt: str ="{:.4g}"
    higher_better: bool | None = None  # None = 中立


METRICS: dict[str, MetricInfo] = {
    "fc": MetricInfo("截止频率 −3dB", "Hz"),
    "f0": MetricInfo("中心频率", "Hz"),
    # 陷波专用：凹陷处相对通带的衰减。用独立指标而不是复用「阻带衰减」——
    # 一个是「窄带里挖多深」，一个是「阻带里压多狠」，判据方向虽同为 ≥，语义不同。
    "depth_db": MetricInfo("凹陷深度", "dB", higher_better=True),
    "bw": MetricInfo("带宽", "Hz"),
    "q": MetricInfo("品质因数 Q", ""),
    "gain_db": MetricInfo("增益", "dB", higher_better=None),
    "gain_lin": MetricInfo("电压增益", "倍"),
    "cmrr_db": MetricInfo("共模抑制比", "dB", higher_better=True),
    "cmrr_res_db": MetricInfo("CMRR（仅电阻失配）", "dB", higher_better=True),
    "ugf": MetricInfo("单位增益频率", "Hz"),
    "pm": MetricInfo("相位裕度", "°", higher_better=True),
    "peaking_db": MetricInfo("增益峰化", "dB", higher_better=False),
    "atten_db": MetricInfo("阻带衰减", "dB", higher_better=True),
    "vout": MetricInfo("输出电压", "V"),
    "iout": MetricInfo("输出电流", "A"),
    "power": MetricInfo("功耗", "W", higher_better=False),
    "rout": MetricInfo("输出阻抗", "Ω", higher_better=False),
    "phase_deg": MetricInfo("相位", "°"),
    # ---- 滤波器综合的补充诊断量（只用于报告/自检，不参与判定）----
    # 它们不进任何拓扑的 metrics_keys，判定仍只看 fc / atten_db，
    # 因此也不需要（不应）出现在 judge.SPEC_RULE 里。
    "atten_2fc_db": MetricInfo("2×fc 处衰减", "dB", higher_better=True),
    "slope_db_dec": MetricInfo("阻带斜率", "dB/dec", fmt="{:.3g}"),
    "q_max": MetricInfo("最高级 Q", "", fmt="{:.4g}"),
}


def fmt_value(v: float | None, unit: str = "", digits: int = 4) -> str:
    """按单位做人类友好的量级缩放。"""
    if v is None:
        return "—"
    if unit == "Hz":
        return E.human_f(v)
    if unit == "Ω":
        return E.human_r(v)
    if unit == "W":
        if v < 1e-3:
            return f"{v * 1e6:.3g}µW"
        if v < 1:
            return f"{v * 1e3:.3g}mW"
        return f"{v:.3g}W"
    if unit == "A":
        if v < 1e-3:
            return f"{v * 1e6:.3g}µA"
        if v < 1:
            return f"{v * 1e3:.3g}mA"
        return f"{v:.3g}A"
    if unit == "V":
        return f"{v:.4g}V"
    if unit == "°":
        return f"{v:.1f}°"
    if unit == "dB":
        return f"{v:.2f}dB"
    return f"{v:.{digits}g}{(' ' + unit) if unit else ''}"


@dataclass
class Param:
    name: str
    label: str
    kind: str  # R / C / L / freq / gain / volt / ratio / opamp
    lo: float
    hi: float
    series: str | None = None  # 指定则做 E 系列吸附

    def clamp(self, v: float) -> float:
        return min(max(float(v), self.lo), self.hi)


@dataclass
class Design:
    """一次仿真的产物：参数 + 结果 + 指标。"""

    topology: str
    params: dict[str, float]
    metrics: dict[str, float] = field(default_factory=dict)
    netlist: str = ""
    waves: dict[str, sim.Wave] = field(default_factory=dict)
    elapsed_ms: float = 0.0
    warnings: list[str] = field(default_factory=list)
    iteration: int = 0

    def human_params(self, topo: "Topology") -> list[tuple[str, str]]:
        out = []
        # 综合类拓扑会按设计选择裁掉用不到的级，报告里不该显示那些「占位」参数
        try:
            hidden = topo.inactive_params(self.params)
        except Exception:
            hidden = set()
        for p in topo.params:
            if p.name in hidden:
                continue
            v = self.params.get(p.name)
            if v is None:
                continue
            if p.kind == "R":
                s = E.human_r(v)
            elif p.kind == "C":
                s = E.human_c(v)
            elif p.kind == "L":
                s = E.human_l(v)
            elif p.kind == "freq":
                s = E.human_f(v)
            elif p.kind == "opamp":
                s = E.human_f(v)
            elif p.kind == "gain":
                s = f"{v:.4g}"
            elif p.kind == "db":
                s = f"{v:.4g}dB"
            elif p.kind == "volt":
                s = f"{v:.4g}V"
            elif p.kind == "enum":
                s = topo.enum_labels.get(p.name, {}).get(int(round(v)), f"{v:.4g}")
            elif p.kind == "ratio":
                s = f"{v:.4g}"
            else:
                s = E.human_r(v)
            out.append((p.label, s))
        return out


class Topology:
    """参数化拓扑基类。"""

    id: str = ""
    name: str = ""
    summary: str = ""
    params: list[Param] = []
    metrics_keys: list[str] = []
    gain_node: str = "out"
    spec_overrides: dict[str, str] = {}  # 指标比较方式覆盖：fc -> "min"
    # 枚举型参数（kind="enum"）的取值 → 人话名称，只影响报告显示
    enum_labels: dict[str, dict[int, str]] = {}

    # ---- 子类实现 ----
    def render(self, p: dict[str, float]) -> str:
        raise NotImplementedError

    def extract(self, res: sim.SimResult, p: dict[str, float]) -> dict[str, float]:
        raise NotImplementedError

    def design(self, spec: dict[str, float]) -> dict[str, float]:
        """由目标指标解析出初始参数（不吸附标准值）。"""
        raise NotImplementedError

    def note(self, p: dict[str, float], m: dict[str, float]) -> str:
        """拓扑专属的工程提示（渲染进报告）。默认无话可说。"""
        return ""

    def inactive_params(self, p: dict[str, float]) -> set[str]:
        """按设计选择可裁剪的参数名（例如综合滤波器只用到前 order/2 级）。

        默认没有可裁剪的参数；报告渲染时这些名字会被跳过，
        build() 仍然要求它们存在（候选搜索按拓扑的全部参数生成网格）。
        """
        return set()

    # ---- 通用 ----
    def sweep_center(self, p: dict[str, float]) -> float | None:
        """推断这个设计该重点关心哪个频率。子类可覆盖。"""
        if p.get("fc"):
            return float(p["fc"])
        try:
            if "L" in p and "C" in p and "R" in p:          # RLC：按 Q 加密
                return 1.0 / (PI2 * math.sqrt(p["L"] * p["C"]))
            if "R1" in p and "C1" in p and "C2" in p:      # Sallen-Key
                r2 = p.get("R2", p["R1"])
                return 1.0 / (PI2 * math.sqrt(p["R1"] * r2 * p["C1"] * p["C2"]))
            if "R" in p and "C" in p:                      # RC 一阶
                return 1.0 / (PI2 * p["R"] * p["C"])
            if "GBW" in p and "R2" in p:                   # 运放类：闭环带宽
                g = 1.0 + p["R2"] / p["R1"] if "R1" in p else 1.0
                return p["GBW"] / max(g, 1.0)
        except (ZeroDivisionError, ValueError):
            return None
        return None

    def build(self, params: dict[str, float]) -> Design:
        p = {}
        clamped: list[str] = []
        for spec in self.params:
            v = params.get(spec.name)
            if v is None:
                raise KeyError(f"缺少参数 {spec.name}")
            cv = spec.clamp(v)
            # ⚑ 钳位**绝不能静默**。实测事故：RLC 带通 `design()` 死写 C=10nF，
            # 1kHz 时反解出 L=2.533H，而 L 的量程上限是 1H → 被压成 1H →
            # f0 变成 1591.55Hz（偏 +59%），但 warning 一个字都没有，
            # 报告还写着「已遍历 9 组标准件组合…无解」。用户拿到的是一个
            # **看起来非常像真值**的错数（1591.55 这种数不会让人起疑）。
            # 钳位生效就说明「这个需求落在本拓扑的量程之外」，必须让上层知道。
            if abs(float(cv) - float(v)) > 1e-12 * max(1.0, abs(float(v))):
                clamped.append(f"{spec.name} 超出量程 [{spec.lo:g}, {spec.hi:g}]："
                               f"要求 {float(v):.6g}，被压到 {float(cv):.6g}")
            p[spec.name] = cv
        net = self.render(p)
        center = self.sweep_center(p)
        if center:
            # RLC 高 Q 时 −3dB 带宽可能比扫频步长还窄，必须按 Q 加密
            q = None
            if "L" in p and "C" in p and "R" in p and p["R"] > 0:
                q = math.sqrt(p["L"] / p["C"]) / p["R"]
            # 拓扑可以自带扫频卡：带通要同时覆盖两侧裙边，通用的"围绕中心 X 个十倍频"
            # 算不出来（它不知道通带有多宽）。有就用它的，否则走通用逻辑。
            _own = getattr(self, "sweep_card", None)
            card = _own(p) if callable(_own) else None
            if card:
                pass
            elif self.id == "filter_highpass_synth":
                # 高通：往下多扫（阻带在低频侧，远场斜率要 100×fc 以下才显出来），
                # 往上压住（扫进运放 GBW 滚降区会让通带参考电平整体偏低，
                # 实测扫到 1e7 时通带报成 −12.27dB、fc 报成 175Hz）。
                gbw = float(p.get("GBW") or 0)
                dec_down = 4.0
                dec_up = 1.0
                if gbw > 0 and center > 0:
                    dec_up = max(0.5, min(1.5, math.log10(gbw / (30.0 * center))))
                card = ac_sweep_asym(center, dec_down, dec_up)
            elif q and q > 10:
                # ⚑ 点数必须随 Q 走，**不能封顶**。−3dB 带宽 f0/Q，测量它的步长必须远小于带宽：
                # 早先封顶 4000，于是 f0=100kHz 时步长 57.6Hz：
                #   Q=2000（解析恰为 2000.0）测出 2306.8（+15.3%）→ 好设计被误杀
                #   Q=5000 测出 4423.9（−11.5%）→ 不达标却判达标
                # 这不是精度问题，是**测量分辨率不够**导致的结论方向都错。
                # 上限放到 400k：Q=5000 需要 ~350k 点，再高就交给下面「测不到」的保护。
                card = ac_sweep(center, ppd=min(max(200, int(70 * q)), 400_000), decades=2.0)
            else:
                card = ac_sweep(center)
            net = _retune(net, card)
        res = sim.run(net)
        m = self.extract(res, p)
        return Design(
            topology=self.id,
            params=p,
            metrics=m,
            netlist=res.netlist,
            waves=res.waves,
            elapsed_ms=res.elapsed_ms,
            # 钳位警告排在最前面：它是「这个结果为什么偏」的第一解释
            warnings=list(clamped) + list(res.warnings),
        )

    #: 非指标型的设计选择（如滤波器的 order/kind/ripple_db）。
    #: 声明在这里的键会被 agent 的规格规范化原样放行到 design()，
    #: 但不进入判定表（判定只看 METRICS 里登记过的指标）。
    design_keys: set[str] = set()


# --------------------------------------------------------------------------
# 工具：从波形里找特征频率
# --------------------------------------------------------------------------
def _fnan() -> float:
    return float("nan")


def _interp_x(xs: list[float], ys: list[float], target: float) -> float | None:
    """在对数频率轴上线性插值，找出 y=target 的 x。要求 ys 单调穿过 target。"""
    for i in range(1, len(xs)):
        y0, y1 = ys[i - 1], ys[i]
        if (y0 - target) * (y1 - target) <= 0 and y0 != y1:
            if xs[i] <= 0 or xs[i - 1] <= 0:
                return xs[i]
            lx0, lx1 = math.log10(xs[i - 1]), math.log10(xs[i])
            t = (target - y0) / (y1 - y0)
            return 10 ** (lx0 + t * (lx1 - lx0))
    return None


def _find_f3db(w: sim.Wave, ref_db: float | None = None) -> float | None:
    """-3dB 点（相对参考增益）。低频低通 / 高频高通都能处理。"""
    xs, db = w.x, w.db()
    if not db:
        return None
    ref = ref_db if ref_db is not None else max(db)
    target = ref - 3.0103
    # 从头找第一次跌破
    f = _interp_x(xs, db, target)
    return f


def _attenuation_at(w: sim.Wave, f: float, ref_db: float) -> float | None:
    """求 f 处的衰减（相对 ref_db 的负值取正）。"""
    xs, db = w.x, w.db()
    if f <= xs[0] or f >= xs[-1]:
        return None
    # 找最近点
    best = min(range(len(xs)), key=lambda i: abs(math.log10(xs[i]) - math.log10(f)))
    return ref_db - db[best]


def _f0_from_phase(w: sim.Wave) -> float | None:
    """二阶低通在 f0 处相位恒为 −90°，与 Q 无关——这是测 Q 的可靠锚点。"""
    ph, xs = w.phase_deg(), w.x
    for i in range(1, len(ph)):
        if ph[i - 1] >= -90.0 >= ph[i]:
            t = (-90.0 - ph[i - 1]) / (ph[i] - ph[i - 1]) if ph[i] != ph[i - 1] else 0.0
            lx0, lx1 = math.log10(xs[i - 1]), math.log10(xs[i])
            return 10 ** (lx0 + t * (lx1 - lx0))
    return None


def _db_at(w: sim.Wave, f: float) -> float | None:
    xs, db = w.x, w.db()
    if not xs or f is None:
        return None
    i = min(range(len(xs)), key=lambda k: abs(math.log10(xs[k]) - math.log10(f)))
    return db[i]


def _q_from_peaking(peak_db: float) -> float | None:
    """由二阶低通的峰化量反推 Q：peak = 20log10(Q/sqrt(1-1/(4Q²)))。"""
    if peak_db <= 0.01:
        return None
    lo, hi = 0.7091, 50.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        val = 20 * math.log10(mid / math.sqrt(max(1 - 1 / (4 * mid * mid), 1e-12)))
        if val < peak_db:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def _unwrap_phase(ph: list[float]) -> list[float]:
    """相位解卷绕。高通低频端应为 +180°，若 atan2 落在 −180 分支先整体抬 360°。"""
    if not ph:
        return ph
    out = [p + 360.0 if p < 0 else p for p in ph]
    for i in range(1, len(out)):
        while out[i] - out[i - 1] > 180.0:
            out[i] -= 360.0
        while out[i] - out[i - 1] < -180.0:
            out[i] += 360.0
    return out


def _f0_from_phase_high(w: sim.Wave, target: float = 90.0) -> float | None:
    """二阶高通在 f0 处相位恒为 **+90°**（与 Q 无关），方向和低通相反：
    相位随频率从 +180° 降到 0°，因此要找「向下穿过 +90°」的那一次。

    主用相位交点；若相位被运放高频极点扰乱，退回「Re(H) 由负变正且 Im>0」
    —— 数学上 H(jω0) 的实部恰在 ω0 处过零。
    """
    xs = w.x
    ph = _unwrap_phase(w.phase_deg())
    for i in range(1, len(ph)):
        if ph[i - 1] >= target >= ph[i] and ph[i] != ph[i - 1]:
            t = (target - ph[i - 1]) / (ph[i] - ph[i - 1])
            return 10 ** (math.log10(xs[i - 1]) + t * (math.log10(xs[i]) - math.log10(xs[i - 1])))
    re = w.real()
    for i in range(1, len(re)):
        if re[i - 1] <= 0.0 <= re[i] and w.y[i].imag > 0 and re[i] != re[i - 1]:
            t = -re[i - 1] / (re[i] - re[i - 1])
            return 10 ** (math.log10(xs[i - 1]) + t * (math.log10(xs[i]) - math.log10(xs[i - 1])))
    return None


def _passband_db(w: sim.Wave, f0: float, k_lo: float = 20.0, k_hi: float = 300.0) -> float:
    """高通通带增益：取 f0 上方 k_lo~k_hi 倍频段的中位数。

    不能直接读 db[-1]：高通在 f0 附近还没进入平台，而最高频端又被运放滚降污染，
    两头都不可信，必须取中间那段平的地方。
    """
    xs, db = w.x, w.db()
    lo, hi = f0 * k_lo, min(f0 * k_hi, xs[-1])
    vals = sorted(db[i] for i in range(len(xs)) if lo <= xs[i] <= hi)
    if not vals:  # f0 太高，平台段已跑出扫频范围
        tail = db[max(0, len(db) - 5):]
        return sorted(tail)[len(tail) // 2]
    n = len(vals)
    return vals[n // 2] if n % 2 else 0.5 * (vals[n // 2 - 1] + vals[n // 2])


def _f3db_highpass(w: sim.Wave, plateau_db: float, f_hi: float) -> float | None:
    """高通的 −3dB 点：从 f_hi（通带平台内）往低频扫，找第一次跌破。"""
    xs, db = w.x, w.db()
    i_hi = min(range(len(xs)), key=lambda i: abs(math.log10(xs[i]) - math.log10(max(f_hi, xs[0]))))
    seg_x = list(reversed(xs[: i_hi + 1]))
    seg_db = list(reversed(db[: i_hi + 1]))
    return _interp_x(seg_x, seg_db, plateau_db - 3.0103)


def _hp_f3_over_f0(q: float) -> float:
    """二阶高通 −3dB 点与 f0 的比值（只由 Q 决定，与元件取值无关）。

    |H|² = x²/((1−x)² + x/Q²)（x=(f/f0)²），令 =1/2 解二次方程：
        x² + x(2 − 1/Q²) − 1 = 0  →  f3dB/f0 = √x
    Q=1/√2 时正好等于 1（这也是「fc=f0=1/(2πRC√…)」这个常见结论的来历）；
    Q≠1/√2 时两者不同，设计时不预畸变就会偏 5%~33%。
    """
    x = 2.0 - 1.0 / (q * q)
    return math.sqrt((-x + math.sqrt(x * x + 4.0)) / 2.0)


def _combine_cmrr_db(cmrr_res_db: float, cmrr_opa_db: float) -> float:
    """共模误差串联：1/CMRR_total = 1/CMRR_电阻失配 + 1/CMRR_运放自身。

    这是真实差分电路的标准结论——运放自身 CMRR（典型 80~100dB）与电阻失配
    是两个并联的误差源，谁也压不住另一个。宏模型是理想运放（无限共模抑制），
    若只信仿真会给出一条物理上做不到的 165dB，所以必须在这里按工程实际合成。
    """
    if cmrr_res_db is None or not math.isfinite(cmrr_res_db):
        return float(cmrr_opa_db) if cmrr_opa_db and math.isfinite(cmrr_opa_db) else _fnan()
    if not cmrr_opa_db or not math.isfinite(cmrr_opa_db):
        return float(cmrr_res_db)
    return -20.0 * math.log10(10 ** (-cmrr_res_db / 20.0) + 10 ** (-cmrr_opa_db / 20.0))


def _pm_from_loop(netlist: str, node: str = "v(oa)") -> float:
    """在运放输出处串入 1V 测试源测环路增益 T = v/(1−v)，由 |T|=1 处相位得相位裕度。

    与 OpampNonInverting.extract 用的是同一套方法，单独抽出来给新拓扑复用。
    """
    try:
        loop = sim.run(netlist)
        w = loop.waves[node]
    except (sim.SimError, KeyError):
        return float("nan")
    mag: list[float] = []
    phs: list[float] = []
    for v in w.y:
        den = 1.0 - v
        if abs(den) < 1e-12:
            continue
        t = v / den
        mag.append(abs(t))
        phs.append(math.degrees(math.atan2(t.imag, t.real)))
    for i in range(1, len(mag)):
        if mag[i - 1] >= 1.0 >= mag[i] and mag[i] != mag[i - 1]:
            t = (1.0 - mag[i - 1]) / (mag[i] - mag[i - 1])
            return 180.0 + phs[i - 1] + t * (phs[i] - phs[i - 1])
    return float("nan")


def _series_values(series: str, lo: float, hi: float) -> list[float]:
    """列出 [lo, hi] 区间内的全部 E 系列标称值（用于电容对的穷举匹配）。"""
    base = E.SERIES.get(series, E.E12)
    out = []
    for dec in range(-14, 4):
        for m in base:
            v = m * (10.0 ** dec)
            if lo <= v <= hi:
                out.append(v)
    return out


def ac_sweep_asym(center: float, dec_down: float, dec_up: float, ppd: int = 200) -> str:
    """不对称扫频：中心以下 dec_down 个十倍频，以上 dec_up 个。

    高通用得上——它的阻带在低频侧，要往下多扫才能看到远场斜率；
    而往上扫太多会撞进运放 GBW 滚降区，产生假峰把参考电平带偏。
    """
    center = max(float(center), 1e-6)
    lo = max(center / (10.0 ** dec_down), 1e-6)
    hi = center * (10.0 ** dec_up)
    return f".ac dec {int(ppd)} {lo:.6g} {hi:.6g}"


def _db_interp(w: sim.Wave, f: float) -> float | None:
    """对数频率轴上线性插值求 f 处的 dB（比取最近点的误差小一个量级）。"""
    xs, db = w.x, w.db()
    if not xs or f <= 0:
        return None
    if f <= xs[0]:
        return db[0]
    if f >= xs[-1]:
        return db[-1]
    for i in range(1, len(xs)):
        if xs[i] >= f:
            lx0, lx1 = math.log10(xs[i - 1]), math.log10(xs[i])
            t = (math.log10(f) - lx0) / (lx1 - lx0) if lx1 != lx0 else 0.0
            return db[i - 1] + t * (db[i] - db[i - 1])
    return db[-1]


# --------------------------------------------------------------------------
def opamp_subckt(a0: float = 1e5, gbw: float = 1e6, rout: float = 50.0) -> str:
    """单极点行为级运放：直流增益 A0，增益带宽积 GBW。

    C0 = A0 / (2π·GBW) 使开环极点在 GBW/A0，从而 A0·fp = GBW。
    注意：用纯线性结构（不带限幅 B 源），否则 AC 分析 gmin stepping 不收敛。
    输出饱和在 Python 侧以「峰值是否超出电源轨」判定。
    """
    c0 = a0 / (PI2 * gbw)
    return (
        f".subckt OPA inp inn out\n"
        f"Rin inp inn 10Meg\n"
        f"E0 ox1 0 inp inn {E.fmt(a0)}\n"
        f"R0 ox1 ox2 1\n"
        f"C0 ox2 0 {E.fmt(c0)}\n"
        f"Rout ox2 out {E.fmt(rout)}\n"
        f".ends"
    )


AC_FULL = ".ac dec 200 1 100meg"

_RE_AC = re.compile(r"\.ac\s+dec\s+\d+\s+\S+\s+\S+")


def ac_sweep(center: float, ppd: int = 200, decades: float = 4.0) -> str:
    """围绕关心频率生成扫频卡。

    固定 1Hz~100MHz 是错的：截止频率 1Hz 时第一个采样点就已经在 −3dB 处，
    `db[0]` 被当成「直流增益」，−3dB 点无处可找 → 1Hz 低通被报成 1.73Hz（B3）。
    扫频范围必须跟着电路走。
    """
    center = max(float(center), 1e-6)
    lo = max(center / (10.0 ** decades), 1e-4)
    hi = center * (10.0 ** decades)
    return f".ac dec {int(ppd)} {lo:.6g} {hi:.6g}"


def _retune(net: str, card: str | None) -> str:
    if not card:
        return net
    return _RE_AC.sub(card, net, count=1)


# 带运放、要跑 2~3 个网表的拓扑用更稀的扫频：指标全在 Python 侧插值计算，
# 60 点/十倍频足够（对数轴插值误差 <0.01%），单次仿真却快 2 倍多。
AC_FAST = ".ac dec 60 1 100meg"
AC_LOOP = ".ac dec 24 1 100meg"
