"""参数化电路拓扑库。

核心设计决策：AI 不直接生成网表，而是「选拓扑 + 填参数」。
    - 拓扑由本模块保证语法正确、物理合理
    - 参数在 Python 侧算成纯数字写入网表（ngspice 不认 pi）
    - 指标从仿真波形在 Python 侧计算（.meas 不可靠）

这样即使 AI 给出荒谬参数，最坏结果也只是「仿真不达标」，不会出现
「网表报错」或「编造数据」。物理正确性由 ngspice 兜底。

本文件只是包门面：实现已按职责拆到 base / filters / amplifiers / misc 四个子模块，
这里把它们的名字（**包括私有名**，外部确实在用 `T._KIND_CODE`、`T._combine_cmrr_db`）
原样 re-export 出来，所以外部 `from . import topologies as T` 一行都不用改。

`REGISTRY` / `get` / `catalog` 留在门面而不是某个子模块：注册表天然是「全库视图」，
放进任何子模块都会让那个子模块反向依赖另外三个，把单向依赖绕成环。
"""

from __future__ import annotations

import math  # noqa: F401  re-export：原单文件模块的命名空间里就有它
import re  # noqa: F401
from dataclasses import dataclass, field  # noqa: F401

from .. import elements as E  # noqa: F401
from .. import sim  # noqa: F401

from .base import (  # noqa: F401
    PI2,
    MetricInfo,
    METRICS,
    fmt_value,
    Param,
    Design,
    Topology,
    _fnan,
    _interp_x,
    _find_f3db,
    _attenuation_at,
    _f0_from_phase,
    _db_at,
    _q_from_peaking,
    _unwrap_phase,
    _f0_from_phase_high,
    _passband_db,
    _f3db_highpass,
    _hp_f3_over_f0,
    _combine_cmrr_db,
    _pm_from_loop,
    _series_values,
    ac_sweep_asym,
    _db_interp,
    opamp_subckt,
    AC_FULL,
    _RE_AC,
    ac_sweep,
    _retune,
    AC_FAST,
    AC_LOOP,
)

from .filters import (  # noqa: F401
    _butter_pairs,
    _cheb_eps,
    _cheb_pairs,
    _bessel_coeffs,
    _poly_roots,
    _bessel_pairs,
    _proto_db,
    _proto_3db,
    _POLE_CACHE,
    pole_table,
    RCLowpass,
    RCHighpass,
    RLCBandpass,
    SallenKeyLowpass,
    SallenKeyHighpass,
    _KIND_CODE,
    _KIND_NAME,
    _peak_db_of_q,
    FilterLowpassSynth,
    FilterHighpassSynth,
    FilterBandpassSynth,
    TwinTNotch,
)

from .amplifiers import (  # noqa: F401
    OpampNonInverting,
    OpampInverting,
    DifferenceAmp,
)

from .misc import (  # noqa: F401
    Divider,
)

REGISTRY: dict[str, Topology] = {
    t.id: t
    for t in [
        RCLowpass(),
        RCHighpass(),
        RLCBandpass(),
        Divider(),
        OpampNonInverting(),
        OpampInverting(),
        SallenKeyLowpass(),
        SallenKeyHighpass(),
        DifferenceAmp(),
        FilterLowpassSynth(),
        FilterHighpassSynth(),
        FilterBandpassSynth(),
        TwinTNotch(),
    ]
}


def get(tid: str) -> Topology:
    if tid not in REGISTRY:
        raise KeyError(f"未知拓扑 {tid}，可用：{', '.join(REGISTRY)}")
    return REGISTRY[tid]


def catalog() -> list[dict]:
    """给 AI 和前端用的拓扑清单。"""
    out = []
    for t in REGISTRY.values():
        out.append(
            {
                "id": t.id,
                "name": t.name,
                "summary": t.summary,
                "params": [
                    {"name": p.name, "label": p.label, "kind": p.kind, "range": [p.lo, p.hi]}
                    for p in t.params
                ],
                "metrics": [{"key": k, "label": METRICS[k].label, "unit": METRICS[k].unit} for k in t.metrics_keys],
            }
        )
    return out
