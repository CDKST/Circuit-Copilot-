"""语义对账闸门：把「用户真正说的数字」和「系统实际设计的规格」逐项核对。

## 为什么需要独立的一层

真实发生过的事故：「把 12V 分压到 3.3V」被解析成 vout=6.0，而且系统判定「达标」。
一次正则写漏，就产出一个**看起来成功、实际错得离谱**的答案。这是这类工具最致命的
失败模式——比报错危险得多，因为用户会直接拿去打样。

修复思路不是去打补丁补那一个正则（那只治一个症状），而是加一道**独立于解析逻辑**的
对账：从用户原文里抽出所有带单位的数字，与最终 spec 比对，不一致就明确报冲突并
**禁止声称达标**。

这一层刻意不依赖大模型、也不复用 parse_rules 的任何中间结果——独立实现才叫独立校验。
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class Conflict:
    code: str
    message: str
    said: str      # 用户原文里的那个值
    got: str       # 系统实际采用的规格

    def as_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "said": self.said, "got": self.got}


_SI = {"p": 1e-12, "n": 1e-9, "u": 1e-6, "µ": 1e-6, "m": 1e-3,
       "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9}


def _num(s: str) -> float:
    m = re.match(r"([-+]?\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)", s)
    if not m:
        return float("nan")
    return float(m.group(1)) * _SI.get(m.group(2), 1.0)


def volts(text: str) -> list[float]:
    return [_num(m.group(1) + (m.group(2) or "")) for m in
            re.finditer(r"(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*[vV](?![a-zA-Z])", text)]


def hertz(text: str) -> list[float]:
    out = []
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*(?:hz|赫兹|赫)", text, re.I):
        out.append(_num(m.group(1) + (m.group(2) or "")))
    return out


def decibels(text: str) -> list[tuple[float, str]]:
    """返回 [(dB 值, 上下文关键词)]。"""
    out = []
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*db", text, re.I):
        ctx = text[max(0, m.start() - 12): m.start()]
        out.append((float(m.group(1)), ctx))
    return out


def gains(text: str) -> list[float]:
    out = []
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*(?:倍|×)", text):
        out.append(float(m.group(1)))
    m = re.search(r"增益\s*(?:为|是|:)?\s*(\d+(?:\.\d+)?)", text)
    if m:
        out.append(float(m.group(1)))
    return out


def _close(a: float, b: float, rel: float = 0.05) -> bool:
    if a != a or b != b:
        return False
    return abs(a - b) <= max(abs(b) * rel, 1e-12)


_DIVIDER_WORDS = ("分压", "降压", "衰减到", "转成", "变成")
_HIGHPASS_WORDS = ("高通",)
_LOWPASS_WORDS = ("低通",)
_BANDPASS_WORDS = ("带通",)


def expect_topology(request: str) -> set[str] | None:
    """从文本里推断「必须是哪一类拓扑」。返回 None 表示无法判断（不干涉）。

    为什么需要它：大模型在 temperature>0 时对同一句话会给出不同拓扑
    （实测「把12V分压到3.3V给STM32的ADC采样」一次给 divider、一次给 rc_lowpass）。
    LLM 的不稳定必须由一层确定性的语义对账来兜住，否则用户会拿到完全错的电路。
    """
    vs = volts(request)
    want: set[str] = set()
    if any(w in request for w in _DIVIDER_WORDS) and len(vs) >= 2:
        want.add("divider")
    if any(w in request for w in ("陷波", "带阻", "notch")):
        # 陷波 ≠ 带通：一个掐掉中心频率，一个放行。词表必须分开，
        # 否则「50Hz 陷波」会被判成「选了带通」而报拓扑不一致。
        want.add("twin_t_notch")
    elif any(w in request for w in _BANDPASS_WORDS):
        # 带通有两条合法实现路径：单级谐振（rlc_bandpass）和级联综合
        # （filter_bandpass_synth）。只认前者会把「四阶带通」的正确选型判成
        # 「需求与设计不一致」，白白给一个假的未达标项。
        want.update({"rlc_bandpass", "filter_bandpass_synth"})
    elif any(w in request for w in _HIGHPASS_WORDS):
        want.add("sallen_key_highpass")
        want.add("rc_highpass")
        want.add("filter_highpass_synth")
    elif any(w in request for w in _LOWPASS_WORDS):
        want.update({"sallen_key_lowpass", "filter_lowpass_synth", "rc_lowpass"})
    return want or None


def verify(request: str, topology_id: str, spec: dict[str, float]) -> list[Conflict]:
    """对账。返回冲突列表，空列表表示「文本与规格一致」。"""
    out: list[Conflict] = []

    # 0) 拓扑与语义是否对得上（兜住大模型的选择不稳定）
    want = expect_topology(request)
    if want and topology_id not in want:
        out.append(Conflict(
            code="topology_mismatch",
            message=(f"需求读起来是「{'/'.join(sorted(want))}」，但系统选了 {topology_id}"),
            said="/".join(sorted(want)), got=topology_id))

    # 1) 分压：文本里的电压必须能对上 Vin 与 vout
    if topology_id == "divider":
        vs = volts(request)
        # 键名兼容：历史上 feasibility 用 "Vin"、verify 用 "__Vin"，
        # 传错一个就**静默跳过整条检查**（实测 {"vout":10,"vin":5} 零 issue）。
        vin = None
        for k in ("__Vin", "Vin", "vin"):
            if spec.get(k) is not None:
                vin = spec[k]
                break
        vout = spec.get("vout")
        if len(vs) >= 2 and vout is not None:
            target = vs[-1]          # 「把 A 分压到 B」→ B 是最后一个电压
            if not _close(target, vout, 0.02):
                out.append(Conflict(
                    code="divider_target",
                    message=f"用户要求的输出是 {target:g}V，但系统按 {vout:g}V 设计",
                    said=f"{target:g}V", got=f"{vout:g}V"))
            # 输入端也要对账：否则「24V 分压到 3.3V」按 12V 算分压比，
            # 输出值看着对、比例全错，打样出来是 6.6V。只在恰好 2 个电压时判断，
            # 3 个以上（如「3.3V 供电，把 24V 分压到 3.3V」）语义有歧义，不猜。
            if len(vs) == 2 and vin and not _close(vs[0], vin, 0.02):
                out.append(Conflict(
                    code="divider_vin",
                    message=(f"用户给的输入电压是 {vs[0]:g}V，但系统按 {vin:g}V "
                             f"算分压比——输出值可能对，比例是错的"),
                    said=f"{vs[0]:g}V", got=f"{vin:g}V"))
        elif len(vs) == 1 and vin and not _close(vs[0], vin, 0.02):
            out.append(Conflict(
                code="divider_vin",
                message=f"用户给的输入电压是 {vs[0]:g}V，但系统按 {vin:g}V 设计",
                said=f"{vs[0]:g}V", got=f"{vin:g}V"))

    # 1b) 带宽对账：文本明确写了「带宽 X」时，必须与 spec["bw"] 一致。
    #     原来 spec["bw"] 从不参与对账 —— 而「把 fc 当 bw」是模型最常见的错之一。
    #     只在上下文里明确出现「带宽/带宽/BW/bandwidth」时才比对，
    #     避免把普通的 fc 描述误判成带宽要求。
    bw = spec.get("bw")
    if bw:
        # 必须让「带宽」这个词**紧接在数字前面**才算带宽要求。
        # 早先的写法是「数字前后 ±24 字内出现带宽」，于是
        # 「中心频率 1kHz，带宽 800Hz」会把 1kHz 当成带宽要求 → 误报需求不一致。
        said_bw = None
        m = re.search(
            r"(?:带宽|带通带宽|bandwidth|BW)\s*(?:约|为|是|=|:|：)?\s*"
            r"(\d+(?:\.\d+)?)\s*([kKmMgG]?)\s*(?:Hz|HZ|hz)",
            request, re.I)
        if m:
            said_bw = float(m.group(1)) * {"": 1, "k": 1e3, "K": 1e3,
                                           "m": 1e-3, "M": 1e6,
                                           "g": 1e9, "G": 1e9}[m.group(2)]
        if said_bw and not _close(said_bw, bw, 0.05):
            out.append(Conflict(
                code="bw_mismatch",
                message=(f"用户要求的带宽是 {said_bw:g}Hz，但系统按 {bw:g}Hz 设计"),
                said=f"{said_bw:g}Hz", got=f"{bw:g}Hz"))

    # 2) 「衰减 X dB」不能被当成增益 X dB
    for db, ctx in decibels(request):
        if re.search(r"衰减|抑制|抑制到|衰减到|挡掉|滤除", ctx):
            for key in ("gain_db",):
                if key in spec and _close(abs(spec[key]), db, 0.1):
                    out.append(Conflict(
                        code="atten_as_gain",
                        message=f"「衰减 {db:g}dB」是阻带要求，不能当成增益 {db:g}dB 来设计",
                        said=f"衰减{db:g}dB", got=f"gain_db={spec[key]:g}"))
            if "gain_lin" in spec and _close(10 ** (db / 20), spec["gain_lin"], 0.1):
                out.append(Conflict(
                    code="atten_as_gain",
                    message=f"「衰减 {db:g}dB」被误当成 {spec['gain_lin']:g} 倍增益",
                    said=f"衰减{db:g}dB", got=f"gain_lin={spec['gain_lin']:g}"))

    # 3) 增益倍数
    gs = gains(request)
    if gs and "gain_lin" in spec:
        g = spec["gain_lin"]
        if not any(_close(x, g, 0.05) for x in gs):
            out.append(Conflict(
                code="gain_mismatch",
                message=f"用户要求的增益是 {gs[0]:g} 倍，但系统按 {g:g} 倍设计",
                said=f"{gs[0]:g}×", got=f"{g:g}×"))

    # 4) 频率
    hs = hertz(request)
    if hs:
        key = "f0" if topology_id == "rlc_bandpass" else "fc"
        if key in spec and not any(_close(x, spec[key], 0.10) for x in hs):
            out.append(Conflict(
                code="freq_mismatch",
                message=f"用户给的频率是 {hs[0]:g}Hz，但系统按 {spec[key]:g}Hz 设计",
                said=f"{hs[0]:g}Hz", got=f"{spec[key]:g}Hz"))

    return out
