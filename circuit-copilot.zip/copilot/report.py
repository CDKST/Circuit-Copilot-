"""报告与 BOM 生成。

BOM 直接从「实际被仿真的网表」里解析，而不是从参数表反推——
这样报告里写的一定是仿真器真正跑的东西，不存在两套数据打架。
"""

from __future__ import annotations

import math
import re

from . import elements as E
from . import topologies as T
from .agent import Session

_SUFFIX = {
    "t": 1e12, "g": 1e9, "meg": 1e6, "k": 1e3, "m": 1e-3,
    "u": 1e-6, "n": 1e-9, "p": 1e-12, "f": 1e-15,
}

_REF_KIND = {
    "R": ("电阻", "Ω", E.human_r),
    "C": ("电容", "F", E.human_c),
    "L": ("电感", "H", E.human_l),
    "X": ("运放", "", lambda v: "1 个"),
    "V": ("电源", "V", lambda v: "—"),
}


def spice_num(tok: str) -> float | None:
    """解析 SPICE 数值：10k / 1Meg / 4.7u / 2.2e3"""
    tok = tok.strip().lower()
    m = re.fullmatch(r"([-+]?\d*\.?\d+)(e[-+]?\d+)?([a-z]*)", tok)
    if not m:
        return None
    val = float(m.group(1))
    if m.group(2):
        val *= 10 ** int(m.group(2)[1:])
    suf = m.group(3)
    if suf:
        for k in ("meg", "t", "g", "k", "m", "u", "n", "p", "f"):
            if suf.startswith(k):
                val *= _SUFFIX[k]
                break
    return val


SIM_ONLY_REFS = {"rload", "rlod", "r_sim", "rsim"}


def bom(netlist: str) -> list[dict]:
    """从网表解析元件清单。"""
    rows: list[dict] = []
    counts: dict[str, int] = {}
    in_subckt = 0  # 跳过 .subckt 内部元件（运放宏模型不是物料）
    for raw in netlist.splitlines():
        ln = raw.strip()
        if ln.lower().startswith(".subckt"):
            in_subckt += 1
            continue
        if ln.lower().startswith(".ends"):
            in_subckt = max(0, in_subckt - 1)
            continue
        if in_subckt:
            continue
        if not ln or ln.startswith(("*", ".", "+")):
            continue
        toks = ln.split()
        if len(toks) < 3:
            continue
        name = toks[0]
        if name.lower() in SIM_ONLY_REFS:   # 仿真专用负载，不是真物料（B4）
            continue
        kind = name[0].upper()
        if kind not in _REF_KIND:
            continue
        if kind == "X":
            key = "opamp"
            rows.append({"ref": name, "type": "运放", "value": "1 个", "kind": kind})
            counts[key] = counts.get(key, 0) + 1
            continue
        if kind == "V":
            continue  # 电源不是物料
        val = None
        for t in reversed(toks[1:]):
            v = spice_num(t)
            if v is not None:
                val = v
                break
        if val is None:
            continue
        label, unit, human = _REF_KIND[kind]
        rows.append({"ref": name, "type": label, "value": human(val), "kind": kind, "si": val})
        counts[kind] = counts.get(kind, 0) + 1
    # 同规格合并计数
    merged: dict[tuple[str, str], dict] = {}
    for r in rows:
        k = (r["type"], r["value"])
        if k in merged:
            merged[k]["count"] = merged[k].get("count", 1) + 1
            merged[k]["ref"] += f", {r['ref']}"
        else:
            merged[k] = {**r, "count": 1}
    return list(merged.values())


def curve_points(design: T.Design, node: str = "v(out)", n: int = 220) -> dict:
    """给前端画图的波形数据（对数频率轴，降采样）。"""
    w = design.waves.get(node) or (next(iter(design.waves.values())) if design.waves else None)
    if w is None:
        return {"freq": [], "db": [], "phase": []}
    xs, db, ph = w.x, w.db(), w.phase_deg()
    if len(xs) > n:
        step = len(xs) / n
        idx = [int(i * step) for i in range(n)]
        xs = [xs[i] for i in idx]
        db = [db[i] for i in idx]
        ph = [ph[i] for i in idx]
    return {"freq": xs, "db": db, "phase": ph}


def _band_text(row) -> str:
    """把 judge 给出的允许区间写成「≥900Hz」「0.9kHz ~ 1.1kHz」这种样子。

    判定是个黑盒最容易被质疑的地方，把区间直接写在报告里，用户能自己复核。
    """
    info = T.METRICS.get(row.key)
    unit = info.unit if info else ""
    lo, hi = row.lo, row.hi
    if math.isinf(lo) and math.isinf(hi):
        return "—"
    if math.isinf(lo):
        return f"≤ {T.fmt_value(hi, unit)}"
    if math.isinf(hi):
        return f"≥ {T.fmt_value(lo, unit)}"
    return f"{T.fmt_value(lo, unit)} ~ {T.fmt_value(hi, unit)}"


def _tolerance_section(s: Session) -> list[str]:
    """「## 容差分析」：标称值达标 ≠ 能生产。

    这一节存在的理由：仿真给的是理想元件下的完美结果，而量产时每个电阻电容
    都有自己的容差。报告里必须回答「这东西做 100 台能有几台达标」。
    """
    mc = s.mc
    out = ["## 容差分析\n"]
    if mc is None:
        out.append("> 本次未执行蒙特卡洛（仿真实例不足或拓扑无可用样本）。\n")
        return out
    if not mc.runs:
        out.append(
            f"> 按 {mc.tol_summary()} 跑了 {mc.failures} 次扰动，全部仿真失败——"
            f"设计点很可能贴在收敛边界上，先加大裕量再谈成品率。\n"
        )
        return out

    out.append(
        f"按 **{mc.tol_summary()}** 高斯扰动跑了 **{mc.runs + mc.failures} 次**"
        + (f"（其中 {mc.failures} 次仿真不收敛，按未达标计）" if mc.failures else "")
        + "：\n"
    )
    y = mc.yield_pct
    out.append(f"- **成品率**：{mc.ok_runs}/{mc.runs + mc.failures} = **{y:.0f}%**")
    weak = mc.weakest()
    if weak:
        k, cnt = weak
        label = T.METRICS[k].label if k in T.METRICS else k
        out.append(f"- **主要短板**：{label}（{cnt}/{mc.runs} 次落在规格外）")
    out.append("")

    out.append("| 指标 | 目标 | p5 | 均值 | p95 | 5–95% 波动 |")
    out.append("|---|---|---|---|---|---|")
    keys = [k for k in s.spec if k in T.METRICS]
    keys += [k for k in mc.dists if k not in keys and k in T.METRICS]
    for k in keys:
        info = T.METRICS[k]
        target = s.spec.get(k)
        target_txt = T.fmt_value(target, info.unit) if target is not None else "—"
        d = mc.dists.get(k)
        if d is None or d.n == 0:
            out.append(f"| {info.label} | {target_txt} | — | — | — | — |")
            continue
        # 波动列：均值接近 0 的指标（如 ±0.05dB 的增益）算相对值会得到 ±41% 这种
        # 没意义的数字，这种情况改报绝对半宽。
        width = d.p95 - d.p5
        if math.isfinite(width) and math.isfinite(d.mean) and abs(d.mean) > 1e-12 \
                and abs(width / d.mean) < 0.2:
            spread_txt = f"±{50 * width / abs(d.mean):.1f}%"
        elif math.isfinite(width):
            spread_txt = f"±{T.fmt_value(width / 2, info.unit)}"
        else:
            spread_txt = "—"
        out.append(
            f"| {info.label} | {target_txt} | "
            f"{T.fmt_value(d.p5, info.unit)} | {T.fmt_value(d.mean, info.unit)} | "
            f"{T.fmt_value(d.p95, info.unit)} | {spread_txt} |"
        )
    out.append("")
    out.append(f"**结论**：{mc.verdict()}\n")
    return out


#: 运放类拓扑：仿真用行为级模型，必须提醒用户换真实器件
_OPAMP_TOPS = ("opamp_noninverting", "opamp_inverting", "difference_amp",
               "sallen_key_lowpass", "sallen_key_highpass", "twin_t_notch",
               "filter_lowpass_synth", "filter_highpass_synth", "filter_bandpass_synth")


def _landing_section(topo, s: Session) -> list[str]:
    """落地前必须确认的事——把「仿真通过」与「焊出来能用」之间的断层说清。

    为什么必须写这一节：本工具的核心主张是「不许编、不许糊」。那它就不能只说
    「✅ 全部达标」，而不说**这个达标是在什么假设下成立的**。实测踩过的坑：
    成品率 ≥95% 时报告直接写「可直接打样」，但运放是行为级模型（没有电源脚、
    没有饱和、没有压摆率）、电容介质没指定、寄生全无 —— 那句话撑不住。
    """
    out = ["## 落地前必须确认（仿真未覆盖的部分）\n"]
    items: list[str] = []

    if topo.id in _OPAMP_TOPS:
        gbw = None
        try:
            gbw = float(s.best.params.get("GBW") or 0) or None
        except Exception:
            gbw = None
        g = f"（本设计反推要求 **GBW ≥ {gbw / 1e6:.2f} MHz**）" if gbw else ""
        items.append(
            "**运放必须换成真实型号**：仿真用的是行为级单极点宏模型（只有 A0 / GBW / Rout=50Ω），"
            "**没有电源引脚、没有输出饱和、没有压摆率、没有输入偏置电流与失调、没有噪声**。"
            f"选型时请核对：GBW{g}、压摆率是否够、输出摆幅与输入共模范围是否覆盖你的电平、"
            "供电与功耗是否可接受。"
        )

    if topo.id in ("sallen_key_lowpass", "sallen_key_highpass", "twin_t_notch",
                   "filter_lowpass_synth", "filter_highpass_synth", "filter_bandpass_synth"):
        items.append(
            "**电容请用 C0G/NP0 或薄膜**：报告里只给容值，不代表介质。X7R/Y5V 的容值随温度与"
            "直流偏压明显漂移、介质吸收还会压低 Q —— 高 Q 级用错介质会直接做不出来。"
            "（本工具的容差分析只扰容值，不模拟介质效应。）"
        )

    if topo.id == "divider":
        items.append(
            "**注意分压器的负载与功耗**：输出电压只有在「后级输入阻抗远大于分压电阻」时才成立；"
            "接上 ADC/负载会拉低输出。另请核对每只电阻的额定功率。"
        )

    items.append(
        "**寄生与布局没有建模**：ESR/ESL、PCB 分布电容、走线电感、负载电容一个都没算。"
        "工作频率越高、通带越窄，影响越大（>100kHz 或高 Q 时尤其要复核）。"
    )
    items.append(
        "**温度与老化没有建模**：容差分析只扰元件初始容差，不含温度系数、老化与焊接应力。"
    )
    items.append(
        "**本工具不做的**：环路稳定性裕度以外的 EMI/EMC、热设计、PCB 布线、机械与安规。"
    )

    for it in items:
        out.append(f"- {it}")
    out.append("")
    return out


def markdown(s: Session) -> str:
    topo = T.get(s.topology) if s.topology else None
    lines: list[str] = []
    lines.append(f"# 电路设计报告\n")
    lines.append(f"**需求**：{s.request}\n")
    if s.error:
        # 「本工具不做这类电路」和「设计失败」是两件事，别混成一句话：
        # 前者是能力边界（不是我们算错了），后者才是失败。
        _scope = []
        if s.feasibility is not None:
            _scope = [i for i in getattr(s.feasibility, "issues", [])
                      if str(getattr(i, "code", "")).startswith("no_")]
        if _scope:
            lines.append(f"> ⛔ **超出本工具的能力范围**：{_scope[0].title}\n")
            for i in _scope:
                lines.append(f"**为什么不做**：{i.evidence}\n")
                lines.append(f"**替代路径**：{i.suggestion}\n")
        else:
            lines.append(f"> ⚠️ 设计失败：{s.error}\n")
        return "\n".join(lines)
    assert s.best is not None and topo is not None

    verdict = "✅ 全部达标" if s.passed else "⚠️ 存在未达标项"
    lines.append(f"**结论**：{verdict}\n")
    lines.append(f"**拓扑**：{topo.name}（`{topo.id}`）\n")
    lines.append(f"> {topo.summary}\n")

    note = topo.note(s.best.params, s.best.metrics) if hasattr(topo, "note") else ""
    if note:
        lines.append(f"**拓扑提示**：{note}\n")

    if s.reason:
        lines.append(f"**选型理由**：{s.reason}\n")
    if s.caveat:
        lines.append(f"**注意**：{s.caveat}\n")

    lines.append("## 设计规格与实测\n")
    lines.append("| 指标 | 目标 | 实测 | 允许区间 | 结论 |")
    lines.append("|---|---|---|---|---|")
    for r in s.rows:
        mark = "✅" if r.ok else "❌"
        lines.append(
            f"| {r.label} | {T.fmt_value(r.target, r.unit)} | "
            f"{T.fmt_value(r.actual, r.unit)} | {_band_text(r)} | {mark} |"
        )
    lines.append("")

    lines.append("## 元件清单（BOM）\n")
    lines.append("| 位号 | 类型 | 规格 | 数量 |")
    lines.append("|---|---|---|---|")
    for b in bom(s.best.netlist):
        lines.append(f"| {b['ref']} | {b['type']} | {b['value']} | {b.get('count', 1)} |")
    lines.append("")

    lines.append("## 设计参数\n")
    for label, val in s.best.human_params(topo):
        lines.append(f"- {label}：**{val}**")
    lines.append("")

    lines.extend(_tolerance_section(s))

    if s.review:
        lines.append("## 工程评审\n")
        lines.append(s.review + "\n")

    lines.extend(_landing_section(topo, s))

    lines.append("## 仿真统计\n")
    lines.append(
        f"- 参数组合尝试：{s.total_sims} 次\n"
        f"- 累计仿真耗时：{s.total_ms:.0f} ms\n"
        f"- 单次平均：{s.total_ms / max(s.total_sims, 1):.1f} ms\n"
        f"- 需求解析来源：{'大模型' if s.plan_source == 'llm' else '规则引擎'}\n"
    )

    lines.append("## 仿真网表\n")
    lines.append("```spice")
    lines.append(s.best.netlist)
    lines.append("```")
    return "\n".join(lines)
