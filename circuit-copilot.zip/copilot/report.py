"""报告与 BOM 生成。

BOM 直接从「实际被仿真的网表」里解析，而不是从参数表反推——
这样报告里写的一定是仿真器真正跑的东西，不存在两套数据打架。
"""

from __future__ import annotations

import math
import re

from . import elements as E
from . import topologies as T
from .agent import Session

_SUFFIX = {
    "t": 1e12, "g": 1e9, "meg": 1e6, "k": 1e3, "m": 1e-3,
    "u": 1e-6, "n": 1e-9, "p": 1e-12, "f": 1e-15,
}

_REF_KIND = {
    "R": ("电阻", "Ω", E.human_r),
    "C": ("电容", "F", E.human_c),
    "L": ("电感", "H", E.human_l),
    "X": ("运放", "", lambda v: "1 个"),
    "V": ("电源", "V", lambda v: "—"),
}


def spice_num(tok: str) -> float | None:
    """解析 SPICE 数值：10k / 1Meg / 4.7u / 2.2e3"""
    tok = tok.strip().lower()
    m = re.fullmatch(r"([-+]?\d*\.?\d+)(e[-+]?\d+)?([a-z]*)", tok)
    if not m:
        return None
    val = float(m.group(1))
    if m.group(2):
        val *= 10 ** int(m.group(2)[1:])
    suf = m.group(3)
    if suf:
        for k in ("meg", "t", "g", "k", "m", "u", "n", "p", "f"):
            if suf.startswith(k):
                val *= _SUFFIX[k]
                break
    return val


SIM_ONLY_REFS = {"rload", "rlod", "r_sim", "rsim"}


def bom(netlist: str) -> list[dict]:
    """从网表解析元件清单。"""
    rows: list[dict] = []
    counts: dict[str, int] = {}
    in_subckt = 0  # 跳过 .subckt 内部元件（运放宏模型不是物料）
    for raw in netlist.splitlines():
        ln = raw.strip()
        if ln.lower().startswith(".subckt"):
            in_subckt += 1
            continue
        if ln.lower().startswith(".ends"):
            in_subckt = max(0, in_subckt - 1)
            continue
        if in_subckt:
            continue
        if not ln or ln.startswith(("*", ".", "+")):
            continue
        toks = ln.split()
        if len(toks) < 3:
            continue
        name = toks[0]
        if name.lower() in SIM_ONLY_REFS:   # 仿真专用负载，不是真物料（B4）
            continue
        kind = name[0].upper()
        if kind not in _REF_KIND:
            continue
        if kind == "X":
            key = "opamp"
            rows.append({"ref": name, "type": "运放", "value": "1 个", "kind": kind})
            counts[key] = counts.get(key, 0) + 1
            continue
        if kind == "V":
            continue  # 电源不是物料
        val = None
        for t in reversed(toks[1:]):
            v = spice_num(t)
            if v is not None:
                val = v
                break
        if val is None:
            continue
        label, unit, human = _REF_KIND[kind]
        rows.append({"ref": name, "type": label, "value": human(val), "kind": kind, "si": val})
        counts[kind] = counts.get(kind, 0) + 1
    # 同规格合并计数
    merged: dict[tuple[str, str], dict] = {}
    for r in rows:
        k = (r["type"], r["value"])
        if k in merged:
            merged[k]["count"] = merged[k].get("count", 1) + 1
            merged[k]["ref"] += f", {r['ref']}"
        else:
            merged[k] = {**r, "count": 1}
    return list(merged.values())


def curve_points(design: T.Design, node: str = "v(out)", n: int = 220) -> dict:
    """给前端画图的波形数据（对数频率轴，降采样）。"""
    w = design.waves.get(node) or (next(iter(design.waves.values())) if design.waves else None)
    if w is None:
        return {"freq": [], "db": [], "phase": []}
    xs, db, ph = w.x, w.db(), w.phase_deg()
    if len(xs) > n:
        step = len(xs) / n
        idx = [int(i * step) for i in range(n)]
        xs = [xs[i] for i in idx]
        db = [db[i] for i in idx]
        ph = [ph[i] for i in idx]
    return {"freq": xs, "db": db, "phase": ph}


def _band_text(row) -> str:
    """把 judge 给出的允许区间写成「≥900Hz」「0.9kHz ~ 1.1kHz」这种样子。

    判定是个黑盒最容易被质疑的地方，把区间直接写在报告里，用户能自己复核。
    """
    info = T.METRICS.get(row.key)
    unit = info.unit if info else ""
    lo, hi = row.lo, row.hi
    if math.isinf(lo) and math.isinf(hi):
        return "—"
    if math.isinf(lo):
        return f"≤ {T.fmt_value(hi, unit)}"
    if math.isinf(hi):
        return f"≥ {T.fmt_value(lo, unit)}"
    return f"{T.fmt_value(lo, unit)} ~ {T.fmt_value(hi, unit)}"


def _tolerance_section(s: Session) -> list[str]:
    """「## 容差分析」：标称值达标 ≠ 能生产。

    这一节存在的理由：仿真给的是理想元件下的完美结果，而量产时每个电阻电容
    都有自己的容差。报告里必须回答「这东西做 100 台能有几台达标」。
    """
    mc = s.mc
    out = ["## 容差分析\n"]
    if mc is None:
        out.append("> 本次未执行蒙特卡洛（仿真实例不足或拓扑无可用样本）。\n")
        return out
    if not mc.runs:
        out.append(
            f"> 按 {mc.tol_summary()} 跑了 {mc.failures} 次扰动，全部仿真失败——"
            f"设计点很可能贴在收敛边界上，先加大裕量再谈成品率。\n"
        )
        return out

    out.append(
        f"按 **{mc.tol_summary()}** 高斯扰动跑了 **{mc.runs + mc.failures} 次**"
        + (f"（其中 {mc.failures} 次仿真不收敛，按未达标计）" if mc.failures else "")
        + "：\n"
    )
    y = mc.yield_pct
    out.append(f"- **成品率**：{mc.ok_runs}/{mc.runs + mc.failures} = **{y:.0f}%**")
    weak = mc.weakest()
    if weak:
        k, cnt = weak
        label = T.METRICS[k].label if k in T.METRICS else k
        out.append(f"- **主要短板**：{label}（{cnt}/{mc.runs} 次落在规格外）")
    out.append("")

    out.append("| 指标 | 目标 | p5 | 均值 | p95 | 5–95% 波动 |")
    out.append("|---|---|---|---|---|---|")
    keys = [k for k in s.spec if k in T.METRICS]
    keys += [k for k in mc.dists if k not in keys and k in T.METRICS]
    for k in keys:
        info = T.METRICS[k]
        target = s.spec.get(k)
        target_txt = T.fmt_value(target, info.unit) if target is not None else "—"
        d = mc.dists.get(k)
        if d is None or d.n == 0:
            out.append(f"| {info.label} | {target_txt} | — | — | — | — |")
            continue
        # 波动列：均值接近 0 的指标（如 ±0.05dB 的增益）算相对值会得到 ±41% 这种
        # 没意义的数字，这种情况改报绝对半宽。
        width = d.p95 - d.p5
        if math.isfinite(width) and math.isfinite(d.mean) and abs(d.mean) > 1e-12 \
                and abs(width / d.mean) < 0.2:
            spread_txt = f"±{50 * width / abs(d.mean):.1f}%"
        elif math.isfinite(width):
            spread_txt = f"±{T.fmt_value(width / 2, info.unit)}"
        else:
            spread_txt = "—"
        out.append(
            f"| {info.label} | {target_txt} | "
            f"{T.fmt_value(d.p5, info.unit)} | {T.fmt_value(d.mean, info.unit)} | "
            f"{T.fmt_value(d.p95, info.unit)} | {spread_txt} |"
        )
    out.append("")
    out.append(f"**结论**：{mc.verdict()}\n")
    return out


#: 运放类拓扑：仿真用行为级模型，必须提醒用户换真实器件
_OPAMP_TOPS = ("opamp_noninverting", "opamp_inverting", "difference_amp",
               "sallen_key_lowpass", "sallen_key_highpass", "twin_t_notch",
               "filter_lowpass_synth", "filter_highpass_synth", "filter_bandpass_synth")


def _fmax_of(s: Session) -> float | None:
    """本设计的最高关注频率（截止/中心频率）。取不到返回 None。"""
    m = getattr(getattr(s, "best", None), "metrics", None) or {}
    for k in ("f0", "fc"):
        v = m.get(k)
        try:
            v = float(v)
        except (TypeError, ValueError):
            continue
        if math.isfinite(v) and v > 0:
            return v
    return None


def _gain_lin_of(s: Session) -> float | None:
    m = getattr(getattr(s, "best", None), "metrics", None) or {}
    try:
        gdb = float(m.get("gain_db"))
        if math.isfinite(gdb):
            return float(10.0 ** (gdb / 20.0))
    except (TypeError, ValueError):
        pass
    try:
        g = float(m.get("gain_lin"))
        if math.isfinite(g) and g > 0:
            return g
    except (TypeError, ValueError):
        pass
    return None


def _opamp_selection_table(topo, s: Session) -> list[str]:
    """把「运放要核对 GBW / 压摆率 / 摆幅」变成**带本设计数值**的选型表。

    ⚑ 为什么不能只写一句提醒：
    「请核对压摆率是否够」这种话用户没法执行 —— 够是多少？他不知道该代什么数。
    这张表把**能算的都算出来**，算不出来的**写清缺哪个量、公式是什么**，
    让他只需代一个数就能得出结论。

    诚实边界（必须写进表里，不能假装全知道）：
      · 交流分析的波形是**按 1V 激励归一化**的，所以「输出幅度」本身算不出来 ——
        它取决于用户的实际信号电平，需求里写了才用得上，没写就必须明说「需你代入」。
      · 压摆率、输出摆幅、输入共模范围都直接依赖那个幅度，同理。
    """
    rows: list[str] = []
    fmax = _fmax_of(s)
    gain = _gain_lin_of(s)
    gbw = None
    try:
        gbw = float(s.best.params.get("GBW") or 0) or None
    except Exception:
        gbw = None

    rows.append("| 选型项 | 本设计的要求 | 依据（公式 + 本设计的数） |")
    rows.append("|---|---|---|")

    if gbw:
        # ⚑ 两个数字要同时给出，否则读的人会发现「依据算出 18.9kHz，
        # 为什么要求 1MHz？」而以为表格写错了。
        # gbw 是 design() 选的值（带余量地板），公式算出的是**下限**。
        if gain and fmax:
            floor = gain * fmax
            basis = (f"公式下限 = 增益 × 带宽 = {gain:.3g} × {fmax:,.0f} Hz "
                     f"= {floor / 1e6:.3g} MHz；"
                     f"本设计取 {gbw / 1e6:.3g} MHz（"
                     f"{gbw / max(floor, 1e-9):.0f}× 余量，给带宽与温度漂移留余地）")
        else:
            basis = "由本设计的增益与带宽反推"
        rows.append(f"| 增益带宽积 GBW | **≥ {gbw / 1e6:.3g} MHz** | {basis} |")
    if fmax:
        rows.append(
            f"| 压摆率 SR | **≥ 2π × {fmax:,.0f} × V_pk** "
            f"= {2 * math.pi * fmax / 1e6:.3g} × V_pk  V/µs | "
            f"SR ≥ 2π·f·V_pk（满功率正弦不失真）；V_pk = 你的输出峰值电压 |")
        rows.append(
            f"| 输出摆幅 | **≥ 1.2 × V_pk**（留 20% 余量） | "
            f"输出峰值 V_pk 要比电源轨低 1~2V；摆幅不足会削顶，而宏模型不会告诉你 |")
    rows.append(
        "| 输入共模范围 | **必须包含本级的直流工作点**（见「工作点」面板的输入节点电压） | "
        "超出共模范围时真实运放会失效，宏模型看不出来 |")
    rows.append(
        "| 输入偏置电流 / 失调 | **按你的源阻抗估计误差**：ΔV = I_b × R_source | "
        "宏模型没有这两项；高阻源（>100kΩ）时这一项常常是主要误差 |")
    rows.append(
        "| 供电与功耗 | 电源电压 ≥ 输出摆幅 + 2V；静态电流 × 电源电压 ≤ 你的预算 | "
        "宏模型没有电源引脚，功耗完全没算 |")
    rows.append("")
    rows.append("> **V_pk 需要你代入**：交流分析的波形是按 1V 激励归一化的，"
                "所以「输出幅度」取决于你的实际信号电平——需求里没写，本工具就不编。")
    rows.append("")
    return rows


def _divider_selection_table(s: Session) -> list[str]:
    """分压器的落地表：负载、功耗、精度——都用本设计的实测值。

    分压器最容易翻车的地方不是阻值算错，而是**接上负载就塌**：
    输出电压只有在后级输入阻抗 ≫ 分压器输出阻抗时才成立。
    所以 rout 必须是表里的第一行，而不是一句「注意负载效应」。
    """
    m = getattr(getattr(s, "best", None), "metrics", None) or {}

    def num(key):
        try:
            v = float(m.get(key))
            return v if math.isfinite(v) else None
        except (TypeError, ValueError):
            return None

    rout, pw, iout, vout = num("rout"), num("power"), num("iout"), num("vout")
    rows = ["| 落地项 | 本设计的数 | 判据 / 怎么用 |", "|---|---|---|"]
    if rout:
        rows.append(f"| 输出阻抗 rout | **{rout:,.4g} Ω** | "
                    f"后级输入阻抗应 ≥ 100×rout = **{rout * 100:,.4g} Ω**，"
                    f"否则输出被拉动（ADC 采样、运放输入、万用表 10MΩ 都要对一下） |")
    if vout:
        rows.append(f"| 空载输出 | {vout:.4g} V | 这是**空载**值；接上负载后的值 = "
                    f"Vout × R_load/(R_load+rout) |")
    if pw:
        rows.append(f"| 总功耗 | **{pw * 1000:.4g} mW** | "
                    f"分摊到各电阻；单只电阻额定功率应 ≥ 2× 它自己的功耗（0603 通常 100mW，0805 为 125mW） |")
    if iout:
        rows.append(f"| 输出电流能力 | {iout * 1000:.4g} mA | 后级消耗不能超过它，否则电压塌陷 |")
    rows.append("| 电阻精度 | 决定输出电压精度 | "
                "非比例式分压请用 0.1%~1% 金属膜；同批次同封装的两只电阻温度系数更接近 |")
    rows.append("")
    return rows


def _landing_section(topo, s: Session) -> list[str]:
    """落地前必须确认的事——把「仿真通过」与「焊出来能用」之间的断层说清。

    为什么必须写这一节：本工具的核心主张是「不许编、不许糊」。那它就不能只说
    「✅ 全部达标」，而不说**这个达标是在什么假设下成立的**。实测踩过的坑：
    成品率 ≥95% 时报告直接写「可直接打样」，但运放是行为级模型（没有电源脚、
    没有饱和、没有压摆率）、电容介质没指定、寄生全无 —— 那句话撑不住。
    """
    out = ["## 落地前必须确认（仿真未覆盖的部分）\n"]
    items: list[str] = []

    if topo.id in _OPAMP_TOPS:
        table = _opamp_selection_table(topo, s)
        if table:
            # ⚑ 表格必须作为一个整体塞进 items：直接 extend(out) 会跑到
            # 所有条目**前面**（items 是在函数末尾才统一 append 的），
            # 于是"先看到表、再看到为什么要看表"。
            block = ("**运放要按这张表选型**：仿真用的是行为级单极点宏模型"
                     "（只有 A0 / GBW / Rout=50Ω），**没有电源引脚、没有输出饱和、"
                     "没有压摆率、没有输入偏置电流与失调、没有噪声**。"
                     "所以下面这些必须由你按真实器件核对：\n\n"
                     + "\n".join(table))
            items.append(block)

    if topo.id in ("sallen_key_lowpass", "sallen_key_highpass", "twin_t_notch",
                   "filter_lowpass_synth", "filter_highpass_synth", "filter_bandpass_synth"):
        items.append(
            "**电容请用 C0G/NP0 或薄膜**：报告里只给容值，不代表介质。X7R/Y5V 的容值随温度与"
            "直流偏压明显漂移、介质吸收还会压低 Q —— 高 Q 级用错介质会直接做不出来。"
            "（本工具的容差分析只扰容值，不模拟介质效应。）"
        )

    if topo.id == "divider":
        block = ("**分压器接上去能不能用，看这张表**（不是只看「达标」两个字）：\n\n"
                 + "\n".join(_divider_selection_table(s)))
        items.append(block)

    items.append(
        "**寄生与布局没有建模**：ESR/ESL、PCB 分布电容、走线电感、负载电容一个都没算。"
        "工作频率越高、通带越窄，影响越大（>100kHz 或高 Q 时尤其要复核）。"
    )
    items.append(
        "**温度与老化没有建模**：容差分析只扰元件初始容差，不含温度系数、老化与焊接应力。"
    )
    items.append(
        "**本工具不做的**：环路稳定性裕度以外的 EMI/EMC、热设计、PCB 布线、机械与安规。"
    )

    for it in items:
        out.append(f"- {it}")
    out.append("")
    return out


def markdown(s: Session) -> str:
    topo = T.get(s.topology) if s.topology else None
    lines: list[str] = []
    lines.append(f"# 电路设计报告\n")
    lines.append(f"**需求**：{s.request}\n")
    if s.error:
        # 「本工具不做这类电路」和「设计失败」是两件事，别混成一句话：
        # 前者是能力边界（不是我们算错了），后者才是失败。
        _scope = []
        if s.feasibility is not None:
            _scope = [i for i in getattr(s.feasibility, "issues", [])
                      if str(getattr(i, "code", "")).startswith("no_")]
        if _scope:
            lines.append(f"> ⛔ **超出本工具的能力范围**：{_scope[0].title}\n")
            for i in _scope:
                lines.append(f"**为什么不做**：{i.evidence}\n")
                lines.append(f"**替代路径**：{i.suggestion}\n")
        else:
            lines.append(f"> ⚠️ 设计失败：{s.error}\n")
            # ⚑ 把「为什么做不到」的**判据**摊开，而不是只给一句结论。
            # 这个项目唯一的差异化就是「带证据的拒绝」；如果拒绝理由只是一句自然语言，
            # 第三方没法复核，那和“另一句话”没区别。
            _all = list(getattr(s.feasibility, "issues", []) or []) if s.feasibility else []
            if _all:
                lines.append("## 判据与证据\n")
                lines.append("> 每条都能自己代一遍：公式 → 代入的数 → 结论；"
                             "「出处」指向判据在哪个函数里实现，可直接去读代码。\n")
                for i in _all:
                    lines.append(f"### {getattr(i, 'title', '')}\n")
                    for dl in (i.derivation_lines() if hasattr(i, "derivation_lines") else []):
                        lines.append(f"- {dl}")
                    ev = getattr(i, "evidence", "")
                    if ev:
                        lines.append(f"- 说明：{ev}")
                    sug = getattr(i, "suggestion", "")
                    if sug:
                        lines.append(f"- 可行路径：{sug}")
                    lines.append("")
        return "\n".join(lines)
    assert s.best is not None and topo is not None

    verdict = "✅ 全部达标" if s.passed else "⚠️ 存在未达标项"
    lines.append(f"**结论**：{verdict}\n")
    lines.append(f"**拓扑**：{topo.name}（`{topo.id}`）\n")
    lines.append(f"> {topo.summary}\n")

    note = topo.note(s.best.params, s.best.metrics) if hasattr(topo, "note") else ""
    if note:
        lines.append(f"**拓扑提示**：{note}\n")

    if s.reason:
        lines.append(f"**选型理由**：{s.reason}\n")
    if s.caveat:
        lines.append(f"**注意**：{s.caveat}\n")

    lines.append("## 设计规格与实测\n")
    lines.append("| 指标 | 目标 | 实测 | 允许区间 | 结论 |")
    lines.append("|---|---|---|---|---|")
    for r in s.rows:
        mark = "✅" if r.ok else "❌"
        lines.append(
            f"| {r.label} | {T.fmt_value(r.target, r.unit)} | "
            f"{T.fmt_value(r.actual, r.unit)} | {_band_text(r)} | {mark} |"
        )
    lines.append("")

    lines.append("## 元件清单（BOM）\n")
    lines.append("| 位号 | 类型 | 规格 | 数量 |")
    lines.append("|---|---|---|---|")
    for b in bom(s.best.netlist):
        lines.append(f"| {b['ref']} | {b['type']} | {b['value']} | {b.get('count', 1)} |")
    lines.append("")

    lines.append("## 设计参数\n")
    for label, val in s.best.human_params(topo):
        lines.append(f"- {label}：**{val}**")
    lines.append("")

    lines.extend(_tolerance_section(s))

    if s.review:
        lines.append("## 工程评审\n")
        lines.append(s.review + "\n")

    lines.extend(_landing_section(topo, s))

    lines.append("## 仿真统计\n")
    lines.append(
        f"- 参数组合尝试：{s.total_sims} 次\n"
        f"- 累计仿真耗时：{s.total_ms:.0f} ms\n"
        f"- 单次平均：{s.total_ms / max(s.total_sims, 1):.1f} ms\n"
        f"- 需求解析来源：{'大模型' if s.plan_source == 'llm' else '规则引擎'}\n"
    )

    lines.append("## 仿真网表\n")
    lines.append("```spice")
    lines.append(s.best.netlist)
    lines.append("```")
    return "\n".join(lines)
