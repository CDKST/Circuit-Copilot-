"""能力边界：这些电路本工具**不做**，必须当场说清，不能兜底凑一个。

## 为什么必须单独有这一层

实测（本次改动前的真实输出）：

    「做一个 Buck 降压电路，输出 5V」
      → 拓扑：电阻分压网络
      → 结论：✅ 全部达标，成品率 100%（20/20），可直接打样

用户要的是开关电源，拿到的是一组分压电阻，而且报告说「可直接打样」。
同类还有：陷波器 → 给了 RLC **带通**（带通放行 50Hz，陷波要掐死它，方向相反）、
Boost / LDO / LED 限流 / 恒流源 / 振荡器 / 整流桥 / 仪用放大 / 三极管共射放大
—— 12 条这样的需求，12 条全部静默落到 `rc_lowpass` 或最接近的既有拓扑。

这件事的严重性在于它**不是"少个功能"，是"静默交付错的东西并宣称达标"**，
正好是本项目立身要防的那一类错误。所以宁可拒绝。

## 与 feasibility 的分工

- `feasibility`：**这个结构**做不做得到（一阶 RC 要 60dB、Sallen-Key 要 Q=25）
- `scope`（本模块）：**本工具有没有这个类别**（开关电源、陷波、振荡器…）

两者都是 hard 拒绝，但话术不同：前者说「换个参数/结构」，后者说「这类电路不在这里」。

## 词表的两个纪律

1. **不认「降压」「稳压」这类单字**——「24V 降压到 3.3V」是分压器的正常说法，
   认它会把合法需求误杀。只认「Buck」「开关电源」「LDO」这种**类别词**。
2. **不认「阻带」**——「阻带衰减 60dB」是低通的规格，不是要带阻滤波器。
   带阻只认「带阻」「陷波」「notch」。
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .feasibility import Issue


@dataclass(frozen=True)
class Limit:
    """一类本工具不做的电路。"""

    code: str
    title: str
    evidence: str
    suggestion: str
    words: tuple[str, ...]

    def matches(self, text: str) -> bool:
        low = text.lower()
        for w in self.words:
            wl = w.lower()
            if wl.isascii():
                # 英文词按词边界匹配，避免 "buck" 命中 "bucketless" 之类
                if re.search(rf"(?<![a-z]){re.escape(wl)}(?![a-z])", low):
                    return True
            elif wl in low:
                # 中文（以及中英混写，如「LED 限流」）都走小写文本比较：
                # 中文不受 lower() 影响，而大小写不统一会漏拦（实测「LED 限流电阻」
                # 被 words 里的小写「led 限流」漏掉）。
                return True
        return False


#: 顺序有意义：越具体的类别放前面（开关电源要先于「分压」类需求被识别）。
LIMITS: tuple[Limit, ...] = (
    Limit(
        code="no_switching_supply",
        title="本工具没有开关电源拓扑（Buck / Boost / Buck-Boost / LDO）",
        evidence=(
            "现有 12 个拓扑全部是线性电路：无源 RC/RLC、分压器、运放放大与滤波。"
            "开关电源靠电感储能＋开关管斩波来变压，需要**非线性时域仿真**（开关损耗、"
            "纹波、电感饱和）和**环路稳定性**判据（相位裕度），与现有的线性交流分析"
            "不是同一套引擎。用分压电阻凑出同样的直流电压是错的：效率、负载调整率、"
            "隔离都与开关电源完全不同，接上负载会直接塌掉。"
        ),
        suggestion=(
            "开关电源请用专门的电源设计工具（或 TI WEBENCH / LTpowerCAD）。"
            "本工具能做的相关部分是：给开关电源做**后级 LC 输出滤波**设计、"
            "反馈分压网络（用 divider 拓扑算电阻比）、以及纹波测量的仿真建模。"
        ),
        words=("buck", "boost", "buck-boost", "开关电源", "开关稳压", "开关型",
               "dc-dc", "dcdc", "dc—dc", "电荷泵", "charge pump", "ldo",
               "线性稳压", "稳压器", "升压", "降压芯片", "switching regulator",
               "反激", "flyback", "正激", "forward converter"),
    ),
    Limit(
        code="no_current_source",
        title="本工具没有恒流源 / 电流镜拓扑",
        evidence=(
            "现有拓扑都是电压型（分压、放大、滤波）。恒流源需要基准 + 误差放大 + 调整管"
            "构成的闭环（或用电流镜复制电流），它的关键指标是**输出电流随负载/温度的变化**，"
            "要跑负载调整与温漂，不是交流扫频能回答的。"
        ),
        suggestion=(
            "恒流源可用运放 + 采样电阻 + 调整管自行搭建，用 ccl 代码仿真其负载调整率；"
            "若只是给 LED 限流，一个电阻（R=(Vcc−Vf)/I）就够，本工具的分压拓扑可直接算。"
        ),
        words=("恒流源", "恒流驱动", "恒流电路", "电流镜", "current mirror",
               "constant current", "稳流"),
    ),
    Limit(
        code="no_oscillator",
        title="本工具没有振荡器拓扑（RC 振荡 / 文氏桥 / 多谐 / 环形）",
        evidence=(
            "振荡器要靠**正反馈满足巴克豪森判据**（环路增益 ≥1 且相位 360°），"
            "起振与稳幅是非线性过程；现有引擎做线性交流分析，可以算环路增益，"
            "但没有振荡器的起振时序与稳幅机构模型。"
        ),
        suggestion=(
            "RC 振荡器（文氏桥、移相式）可先用 ccl 代码搭网表看环路增益与频率；"
            "本工具的 rlc_bandpass 能算**选频网络**的中心频率与 Q，但那只是振荡器的一部分。"
        ),
        words=("振荡器", "振荡电路", "文氏桥", "wien bridge", "oscillator",
               "多谐振荡", "环形振荡", "弛张"),
    ),
    Limit(
        code="no_rectifier",
        title="本工具没有整流 / 电源变换拓扑（整流桥、半波、全波、倍压）",
        evidence=(
            "整流是非线性过程（二极管导通角随负载变化），要算导通角、纹波电压、"
            "峰值电流与变压器利用率；现有 AC 分析是小信号线性化的，给不出整流后的直流量。"
            "（ccl 代码层可以直接搭二极管网表跑瞬态，但参数化拓扑层没有这类模板。）"
        ),
        suggestion="用 ccl 代码搭二极管桥式/半波整流网表跑 `.tran`；需要参数化模板可以单独加。",
        words=("整流", "整流桥", "rectifier", "半波整流", "全波整流", "倍压"),
    ),
    Limit(
        code="no_instrumentation_amp",
        title="本工具没有仪用放大器（三运放）拓扑",
        evidence=(
            "现有 difference_amp 是单运放四电阻差分放大，输入阻抗受电阻限制（几十 kΩ）；"
            "仪用放大器是三运放结构（两级：缓冲 + 差分），输入阻抗极高、CMRR 很高，"
            "是不同电路，不能互相替代。"
        ),
        suggestion=(
            "要求不高时用 difference_amp（输入阻抗约 R1+R2，注意信号源内阻分压）；"
            "要高输入阻抗的仪用放大器请用三运放结构，本工具暂未内置。"
        ),
        words=("仪用放大", "仪表放大", "instrumentation", "三运放", "ina1", "ad620"),
    ),
    Limit(
        code="no_bjt_amplifier",
        title="参数化拓扑层没有三极管放大电路（共射 / 共基 / 射极跟随）",
        evidence=(
            "三极管放大器的核心是**静态工作点**与偏置稳定性（β 离散性、温漂、"
            "饱和/截止边界），参数化模板只按小信号交流指标搜索元件值，给不出"
            "「这个偏置在 −40℃ 会不会饱和」这类结论。"
            "现有的 bjt_ce_bias / emitter_follower **积木**在 ccl 代码层可用，但没有"
            "对应的参数化拓扑（无法按「增益 50」自动搜阻值）。"
        ),
        suggestion=(
            "用 CCL 代码：`from ccl.blocks import BLOCKS; c.use_ports(BLOCKS['bjt_ce_bias'](...), {...})`，"
            "再自己设偏置并跑 `c.op()` 检查工作点、`c.ac()` 看增益。"
        ),
        words=("共射", "共基", "三极管放大", "晶体管放大", "bjt 放大", "bjt放大",
               "射极跟随", "射随", "emitter follower"),
    ),
    Limit(
        code="no_led_driver",
        title="本工具没有 LED 驱动 / 恒流点灯拓扑",
        evidence=(
            "LED 是二极管（指数 I-V），限流电阻要按 (Vcc−Vf)/I 算且要考虑 Vf 的批次离散与"
            "温度系数；多个 LED 串并、PWM 调光还要算功耗与热。现有拓扑没有二极管负载模型。"
        ),
        suggestion=(
            "单个 LED：R=(Vcc−Vf)/I，本工具的 divider 拓扑可以算这个电阻（把 Vout 当成 Vf）；"
            "多串并或大功率请用专用 LED 驱动 IC。"
        ),
        words=("led 限流", "led限流", "led 驱动", "led驱动", "发光二极管限流",
               "点灯", "led 灯"),
    ),
    Limit(
        code="no_rf",
        title="本工具没有射频 / 传输线 / 阻抗匹配能力",
        evidence=(
            "集总参数模型在波长可比于电路尺寸时失效（经验界线约 f > 300MHz 或线长 > λ/10）。"
            "阻抗匹配、S 参数、微带线需要分布参数与电磁仿真，现有集总 SPICE 引擎给不出。"
        ),
        suggestion="射频请用 Smith 圆图工具或电磁仿真（openEMS / HFSS / ADS）。",
        words=("阻抗匹配", "smith", "微带", "传输线", "s参数", "s 参数",
               "驻波", "vswr", "巴伦", "balun", "天线"),
    ),
    Limit(
        code="no_transformer",
        title="本工具没有变压器 / 隔离拓扑",
        evidence="现有引擎的器件模型只有 R/L/C/二极管/三极管/MOSFET/运放，没有耦合电感与磁芯模型。",
        suggestion="需要隔离或变比时请用变压器方案，本工具可算其前级驱动与后级滤波。",
        words=("变压器", "隔离电源", "耦合电感", "transformer"),
    ),
)


def detect(request: str) -> list[Issue]:
    """命中所有「本工具不做」的类别，返回 Issue 列表（空 = 没命中）。

    返回**全部**命中而不是第一个：用户可能同时提到两类不支持的电路，
    逐条说清比只报一个更有用。
    """
    out: list[Issue] = []
    if not request:
        return out
    for lim in LIMITS:
        if lim.matches(request):
            out.append(Issue(
                code=lim.code,
                title=lim.title,
                evidence=lim.evidence,
                suggestion=lim.suggestion,
                severity="hard",
            ))
    return out


def first(request: str) -> Issue | None:
    hits = detect(request)
    return hits[0] if hits else None
