"""元件值与系列化。

真实工程约束：电阻电容只能买到 E 系列标准值。AI 给出的「理想值」必须落到
标准值上，这个误差正是「需要迭代仿真」的根本原因——也是本工具的价值所在。

支持 E6 / E12 / E24 / E96，以及容差与常见耐压/封装提示。
"""

from __future__ import annotations

import math

E6 = [1.0, 1.5, 2.2, 3.3, 4.7, 6.8]
E12 = [1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2]
E24 = [
    1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
    3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
]
E96 = [
    1.00, 1.02, 1.05, 1.07, 1.10, 1.13, 1.15, 1.18, 1.21, 1.24, 1.27, 1.30,
    1.33, 1.37, 1.40, 1.43, 1.47, 1.50, 1.54, 1.58, 1.62, 1.65, 1.69, 1.74,
    1.78, 1.82, 1.87, 1.91, 1.96, 2.00, 2.05, 2.10, 2.15, 2.21, 2.26, 2.32,
    2.37, 2.43, 2.49, 2.55, 2.61, 2.67, 2.74, 2.80, 2.87, 2.94, 3.01, 3.09,
    3.16, 3.24, 3.32, 3.40, 3.48, 3.57, 3.65, 3.74, 3.83, 3.92, 4.02, 4.12,
    4.22, 4.32, 4.42, 4.53, 4.64, 4.75, 4.87, 4.99, 5.11, 5.23, 5.36, 5.49,
    5.62, 5.76, 5.90, 6.04, 6.19, 6.34, 6.49, 6.65, 6.81, 6.98, 7.15, 7.32,
    7.50, 7.68, 7.87, 8.06, 8.25, 8.45, 8.66, 8.87, 9.09, 9.31, 9.53, 9.76,
]

SERIES = {"E6": E6, "E12": E12, "E24": E24, "E96": E96}

# 电容常见标称（pF 档)，工程上实际以 E12 为主
CAP_SERIES = {"E6": E6, "E12": E12, "E24": E24}


def snap(value: float, series: str = "E24") -> float:
    """把理想值吸附到最近的 E 系列标称值（1-10 为一个 decade）。"""
    if value <= 0 or not math.isfinite(value):
        return value
    base = SERIES.get(series, E24)
    decade = math.floor(math.log10(value))
    scaled = value / (10 ** decade)
    best = min(base, key=lambda v: abs(v - scaled))
    snapped = best * (10 ** decade)
    # 处理 9.1 → 10 的跨 decade 情况
    if scaled > base[-1] * 1.05:
        snapped = base[0] * (10 ** (decade + 1))
    return snapped


def snap_pair(value: float, series: str = "E24") -> list[float]:
    """返回 [向下取标称, 最近标称, 向上取标称]，供迭代器选择方向。"""
    if value <= 0:
        return [value, value, value]
    base = SERIES.get(series, E24)
    decade = math.floor(math.log10(value))
    scaled = value / (10 ** decade)
    lo = max([v for v in base if v <= scaled], default=base[-1] * 10)
    hi = min([v for v in base if v >= scaled], default=base[0] * 10)
    near = min(base, key=lambda v: abs(v - scaled))
    return sorted({v * (10 ** decade) for v in (lo, near, hi)})


def fmt(value: float) -> str:
    """SPICE 数值格式化：避免科学计数法歧义，保留 6 位有效。"""
    if value == 0:
        return "0"
    return f"{value:.6g}"


def human_r(ohms: float) -> str:
    """人话显示：4700 → 4.7kΩ"""
    if ohms >= 1e6:
        return f"{ohms / 1e6:.3g}MΩ"
    if ohms >= 1e3:
        return f"{ohms / 1e3:.3g}kΩ"
    return f"{ohms:.3g}Ω"


def human_c(farads: float) -> str:
    if farads >= 1e-3:
        return f"{farads * 1e3:.3g}mF"
    if farads >= 1e-6:
        return f"{farads * 1e6:.3g}µF"
    if farads >= 1e-9:
        return f"{farads * 1e9:.3g}nF"
    return f"{farads * 1e12:.3g}pF"


def human_l(henry: float) -> str:
    if henry >= 1:
        return f"{henry:.3g}H"
    if henry >= 1e-3:
        return f"{henry * 1e3:.3g}mH"
    return f"{henry * 1e6:.3g}µH"


def human_f(hz: float) -> str:
    if hz >= 1e6:
        return f"{hz / 1e6:.3g}MHz"
    if hz >= 1e3:
        return f"{hz / 1e3:.3g}kHz"
    return f"{hz:.3g}Hz"
