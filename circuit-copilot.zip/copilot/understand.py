"""需求理解层：把「一句话」变成「可执行的设计任务」。

这是「AI 那一层」的编排器，串起四件事：
    1. 语言理解（LLM 或规则兜底）→ 拓扑 + 目标指标
    2. 假设声明 → 用户没说的地方必须摊开讲，不许悄悄替他做决定
    3. 物理可行性预判（feasibility，纯确定性）→ 做不到就当场说清，别硬算
    4. 语义一致性复核 → 防止「用户要高通，系统做了低通」

设计原则：**不阻塞用户**。信息不足时按合理默认往下做，但把假设和追问一并返回，
让用户看得见你替他决定了什么。只有物理上确实做不到时才停下并给出替代路径。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from . import feasibility as F
from . import llm as L
from . import topologies as T
from . import verify as VF


@dataclass
class Understanding:
    request: str
    topology: str = ""
    topology_name: str = ""
    spec: dict[str, float] = field(default_factory=dict)
    reason: str = ""
    assumptions: list[str] = field(default_factory=list)
    clarify: list[str] = field(default_factory=list)
    caveat: str = ""
    confidence: float = 0.5
    verdict: F.Verdict = field(default_factory=F.Verdict)
    intent: dict = field(default_factory=lambda: {"match": True, "problem": "", "severity": "none"})
    source: str = "rule"          # llm | rule
    blocked: bool = False          # 物理不可行，不进入设计
    stopband: tuple[float, float] | None = None
    conflicts: list["VF.Conflict"] = field(default_factory=list)  # 文本 vs 规格 对账冲突

    @property
    def questions(self) -> list[str]:
        """要给用户看的补充问题（不阻塞设计）。"""
        out = list(self.clarify)
        for i in self.verdict.issues:
            if i.severity == "tight":
                out.append(f"{i.title} —— {i.suggestion}")
        return out[:4]

    @property
    def trustworthy(self) -> bool:
        """设计结果是否可以被信任地宣布达标。

        对账有冲突时**一律不许声称达标**——宁可说「我不确定」，
        也不能把一个错答案标成成功。
        """
        return not self.blocked and not self.conflicts

    def headline(self) -> str:
        """一句话状态，给前端顶部条用。"""
        if self.blocked:
            return "物理上做不到"
        if self.conflicts:
            return "需求与设计不一致，需确认"
        if self.verdict.tight:
            return "可行但很勉强"
        return "可行"


# --------------------------------------------------------------------------
# 规则层：从文本里抽取物理需求（不依赖大模型）
# --------------------------------------------------------------------------
_CN_NUM = {"一": 1, "两": 2, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8}


def detect_stopband(text: str) -> tuple[float, float] | None:
    """识别「在 N 倍截止频率处衰减 X dB」这类阻带需求 → (ratio, atten_db)。

    支持：10倍...60dB / 60dB...10倍 / @10fc 60dB / 十倍频程
    """
    t = text.replace("十倍", "10倍").replace("百倍", "100倍").replace("两倍", "2倍")
    # 先找 dB 数（含负号、含「衰减/抑制/抑制到」）
    atten_m = re.search(r"(?:衰减|抑制|抑制到|低于|小于)\s*(?:约|约|-)?\s*(\d+(?:\.\d+)?)\s*dB", t, re.I)
    if not atten_m:
        atten_m = re.search(r"(\d+(?:\.\d+)?)\s*dB", t, re.I)
    ratio_m = re.search(r"(\d+(?:\.\d+)?)\s*倍", t)
    if not ratio_m:
        ratio_m = re.search(r"@\s*(\d+(?:\.\d+)?)\s*fc", t, re.I)
    if not (atten_m and ratio_m):
        return None
    atten = float(atten_m.group(1))
    ratio = float(ratio_m.group(1))
    if ratio <= 1 or atten <= 0:
        return None
    return (ratio, atten)


def detect_order(text: str) -> int:
    """识别阶数：一阶/二阶/1阶/2阶/4阶。"""
    m = re.search(r"(\d+)\s*阶", text)
    if m:
        return int(m.group(1))
    for cn, n in _CN_NUM.items():
        if re.search(rf"{cn}\s*阶", text):
            return n
    return 1


def detect_q(text: str) -> float | None:
    m = re.search(r"[Qq]\s*[=＝:：]\s*(\d+(?:\.\d+)?)", text)
    return float(m.group(1)) if m else None


def _fill_defaults(
    topo: T.Topology, spec: dict[str, float], vin: float | None, assumptions: list[str]
) -> dict[str, float]:
    """用户没给指标时补一个有意义的目标，**并把这次补充写进 assumptions**。

    悄悄替用户做决定是这类工具最容易失去信任的地方，所以补默认值必须留痕。
    """
    out = dict(spec)
    if topo.id == "rlc_bandpass":
        if "f0" not in out:
            out["f0"] = 100e3
            assumptions.append("未指定中心频率，按 100kHz 处理")
    elif topo.id == "divider":
        if "vout" not in out:
            base = float(vin) if vin else 5.0
            out["vout"] = base / 2
            assumptions.append(f"未指定输出电压，按输入 {base:g}V 的一半处理")
    elif topo.id.startswith("opamp"):
        if "gain_lin" not in out and "gain_db" not in out:
            out["gain_lin"] = 10.0
            assumptions.append("未指定增益，按 10 倍（20dB）处理")
    elif topo.id in ("rc_lowpass", "rc_highpass", "sallen_key_lowpass",
                     "sallen_key_highpass", "filter_lowpass_synth"):
        if "fc" not in out:
            out["fc"] = 1e3
            assumptions.append("未指定截止频率，按音频常用 1kHz 处理")
    if topo.id.startswith("sallen") and "q" not in out:
        out["q"] = 0.7071
        assumptions.append("未指定 Q，按巴特沃斯响应 Q=0.707 处理（最平坦，无峰化）")
    return out


# --------------------------------------------------------------------------
# 主入口
# --------------------------------------------------------------------------
def prepare(
    request: str,
    taxonomy: str,
    *,
    use_llm: bool = True,
    history: list[str] | None = None,
) -> Understanding:
    """把一句需求变成可执行的设计任务（含物理可行性判定与假设声明）。"""
    from . import agent as A  # 延迟导入，避免 agent ↔ understand 循环依赖
    from . import scope as _SCOPE

    u = Understanding(request=request)
    client = L.LLM()

    plan: dict
    if use_llm and client.available():
        try:
            plan = L.plan(client, request, taxonomy, history)
            u.source = "llm"
        except L.LLMError as e:
            plan = A.parse_rules(request)
            plan["caveat"] = f"大模型调用失败（{e}），已降级为规则解析"
            u.source = "rule"
    else:
        plan = A.parse_rules(request)
        u.source = "rule"

    tid = plan.get("topology") or "rc_lowpass"

    # ---- 「显式阶数 / 响应类型」是确定性事实，不该由模型自由裁定 ----
    # 实测：需求「四阶带通滤波器，中心频率 1kHz，带宽 800Hz」，模型选了单级
    # RLC 串联带通（它自己的选型理由里甚至在描述级联结构，前后自相矛盾），
    # 结果中心频率偏 59%、带宽超 950Hz。阶数写没写在需求里是可以用正则确定判断的，
    # 这种事实交给规则层；模型只在「语义理解」上说话。
    _SYNTH = A._SYNTH_IDS
    _rule_plan: dict | None = None
    if u.source == "llm":
        try:
            _rule_plan = A.parse_rules(request)
        except Exception:
            _rule_plan = None
        _rt = A.prefer_synth_topology(request) or ""
        if _rt and _rt != tid:
            u.caveat = f"需求写明了阶数/响应类型，模型选的 {tid} 做不到；已改用 {_rt}。"
            tid = _rt

    try:
        topo = T.get(tid)
    except KeyError:
        topo = T.get("rc_lowpass")
    u.topology, u.topology_name = topo.id, topo.name
    u.reason = (plan.get("reason") or "").strip()
    u.caveat = (plan.get("caveat") or "").strip()
    u.assumptions = [str(a).strip() for a in (plan.get("assumptions") or []) if str(a).strip()]
    u.clarify = [str(c).strip() for c in (plan.get("clarify") or []) if str(c).strip()]
    try:
        u.confidence = float(plan.get("confidence") or 0.6)
    except (TypeError, ValueError):
        u.confidence = 0.6

    spec, vin = A._normalize_spec(topo, plan.get("spec") or {})
    # 综合拓扑（低通/高通/带通）必须有 order；模型的 spec 常常漏掉它，
    # 而规则层算得很准（含「奇数阶向上取偶数」这类硬约束）。
    if topo.id in _SYNTH:
        _rs = ((_rule_plan or {}).get("spec") or {})
        for _k in ("order", "kind", "ripple_db"):
            if _k not in spec and _k in _rs:
                spec[_k] = _rs[_k]
        if "order" not in spec:
            _o = int(max(2, detect_order(request) or 2))
            # 带通是「每侧 N 级」，总阶数必须偶数
            if topo.id == "filter_bandpass_synth" and _o % 2:
                _o += 1
            spec["order"] = float(_o)
    # ⚑ 规则层解析出的量化指标，模型漏了就必须补上。
    # 「输出阻抗小于100Ω」「功耗小于1mW」「带宽500Hz」「品质因数5」这类**都是正则能确定
    # 判断的事实**，不该由温度>0 的模型自由裁定——模型一漏，用户就拿到一个
    # 盖着「✅ 全部指标达标」印章的错答案（实测：要求 ≤1mW、实测 14.2mW，仍判达标）。
    # 原则与本文件前面「阶数/响应类型交给规则层」完全一致。
    _rs_all = ((_rule_plan or {}).get("spec") or {})
    for _k, _v in _rs_all.items():
        if _k.startswith("__"):
            continue                      # __Vin 这类内部量由 _fill_defaults 处理
        if _k not in spec:
            spec[_k] = _v
            u.assumptions.append(f"需求里的「{_k}」由规则层解析得到 {_v:g}（模型没有给出）")
    spec = _fill_defaults(topo, spec, vin, u.assumptions)
    u.spec = spec

    # ---- 物理可行性预判（确定性，不依赖模型）----
    u.stopband = detect_stopband(request)
    order = max(detect_order(request), 2 if topo.id.startswith("sallen") else 1)
    gain = spec.get("gain_lin") or (10 ** (spec["gain_db"] / 20) if spec.get("gain_db") else None)
    q = detect_q(request) if detect_q(request) is not None else spec.get("q")

    u.verdict = F.evaluate(
        topo.id,
        {**spec, **({"Vin": vin} if vin else {})},
        order=order,
        q=q,
        stopband=u.stopband,
    )
    # 能力边界：本工具不做的电路类别（开关电源/陷波/振荡器…）。
    # 必须在这里就拦——否则界面会拿一个「最接近的拓扑」当答案，
    # 用户看到的是「✅ 达标」而不是「我们不做这个」。
    for _iss in _SCOPE.detect(request):
        u.verdict.add(_iss)
    # 滤波器阶数与用户实际指定拓扑不匹配时，直接判不可行
    if u.stopband and topo.id in ("rc_lowpass", "rc_highpass"):
        need = F.order_for_attenuation(u.stopband[1], u.stopband[0])
        if need > 1:
            u.verdict.add(
                F.Issue(
                    code="order_mismatch",
                    title=f"所选拓扑是一阶，但需求隐含需要 {need} 阶",
                    evidence=(
                        f"在 {u.stopband[0]:g}×截止频率处要衰减 {u.stopband[1]:g}dB，"
                        f"一阶最多 {F.rc_one_pole_atten_db(u.stopband[0]):.1f}dB。"
                    ),
                    suggestion=f"改用 {need} 阶设计；本工具可用 Sallen-Key 二阶（或级联）实现。",
                )
            )
    u.blocked = not u.verdict.possible

    # ---- 语义对账（独立于解析逻辑的第二双眼睛）----
    u.conflicts = VF.verify(request, topo.id, {**spec, **({"__Vin": vin} if vin else {})})
    for c in u.conflicts:
        u.clarify.append(f"{c.message}，请确认按哪个来。")

    # ---- 语义一致性复核（只在会用大模型时做，避免白烧 token）----
    if use_llm and client.available() and not u.blocked:
        u.intent = L.judge_intent(client, request, u.topology_name, spec)
        if not u.intent["match"] and u.intent["severity"] == "hard":
            u.caveat = (u.caveat + "；" + u.intent["problem"]).strip("；")

    return u
