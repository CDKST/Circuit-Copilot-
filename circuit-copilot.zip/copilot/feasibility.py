"""物理可行性预判（确定性推理，不依赖大模型）。

## 为什么需要这一层

真实用户会提出物理上做不到的需求：
    「一阶 RC 低通，在 10 倍截止频率处衰减 60dB」  ← 一阶只有 20dB
    「增益 100 倍，带宽 1MHz，用 GBW=1MHz 的运放」 ← 闭环带宽只有 10kHz
    「无源 RC 做二阶巴特沃斯（Q=0.707）」          ← 无源 RC 的 Q 恒为 0.5

一个只会「尽力而为」的工具会把这类需求硬算出一个零件清单，用户拿去打样才发现根本不行。
本模块在**动手之前**就把硬约束算清楚，要么直接拒绝并给出可行路径，
要么标出「紧」并说明代价。

全部是解析公式，可独立复核 —— 这是它值得信任的原因。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class Issue:
    code: str            # 机器可读标识
    title: str           # 一句话结论
    evidence: str        # 支撑这个结论的算式/数字（必须可复核）
    suggestion: str      # 可行路径
    severity: str = "hard"  # hard = 做不到；tight = 能做但很勉强

    def as_dict(self) -> dict:
        return {
            "code": self.code,
            "title": self.title,
            "evidence": self.evidence,
            "suggestion": self.suggestion,
            "severity": self.severity,
        }


@dataclass
class Verdict:
    issues: list[Issue] = field(default_factory=list)

    @property
    def hard(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == "hard"]

    @property
    def tight(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == "tight"]

    @property
    def possible(self) -> bool:
        return not self.hard

    def add(self, *issues: Issue) -> None:
        self.issues.extend(issues)

    def summary(self) -> str:
        if not self.issues:
            return ""
        return "；".join(i.title for i in self.issues)


# --------------------------------------------------------------------------
# 核心公式
# --------------------------------------------------------------------------
def butterworth_atten_db(order: int, ratio: float) -> float:
    """N 阶巴特沃斯在 f/fc=ratio 处的衰减（dB）。|H|=1/√(1+r^{2N})"""
    if order <= 0 or ratio <= 0:
        return 0.0
    return 10.0 * math.log10(1.0 + ratio ** (2 * order))


def order_for_attenuation(atten_db: float, ratio: float, kind: str = "butterworth") -> int:
    """给定「在 ratio 倍截止频率处要衰减 atten_db」，反解所需最小阶数。"""
    if atten_db <= 0 or ratio <= 1:
        return 1
    if kind == "butterworth":
        # 10log10(1+r^{2N}) >= A  →  N >= log10(10^{A/10}-1) / (2·log10(r))
        need = math.log10(10 ** (atten_db / 10.0) - 1.0) / (2.0 * math.log10(ratio))
        return max(1, math.ceil(need))
    # 去归一化斜率近似：每阶每十倍频 20dB
    return max(1, math.ceil(atten_db / (20.0 * math.log10(ratio))))


def rc_one_pole_atten_db(ratio: float) -> float:
    """一阶 RC 在 f/fc=ratio 处的衰减。"""
    return 10.0 * math.log10(1.0 + ratio * ratio)


# --------------------------------------------------------------------------
# 单项检查
# --------------------------------------------------------------------------
def check_stopband_order(
    topology_id: str, fc: float, atten_db: float, ratio: float
) -> Issue | None:
    """无源一阶拓扑能否满足阻带衰减需求。"""
    if topology_id not in ("rc_lowpass", "rc_highpass"):
        return None
    got = rc_one_pole_atten_db(ratio)
    if atten_db <= got:
        return None
    need = order_for_attenuation(atten_db, ratio)
    return Issue(
        code="stopband_order",
        title=f"{atten_db:g}dB 阻带衰减在一阶 RC 上做不到",
        evidence=(
            f"一阶 RC 在 {ratio:g}×fc（{fc * ratio:g}Hz）处只能衰减 "
            f"{got:.1f}dB（10·log10(1+{ratio:g}²)={got:.1f}），"
            f"而要求 {atten_db:g}dB。一阶滚降固定 −20dB/十倍频。"
        ),
        suggestion=(
            f"按巴特沃斯响应需要至少 {need} 阶（{10 * math.log10(1 + ratio ** (2 * need)):.1f}dB）。"
            + ("级联两节 Sallen-Key 可得四阶。" if need > 2 else "改用 Sallen-Key 二阶有源滤波即可。")
        ),
    )


def check_passive_q(topology_id: str, q: float) -> Issue | None:
    """无源 RC 无法实现 Q>0.5。"""
    if topology_id not in ("rc_lowpass", "rc_highpass"):
        return None
    if q <= 0.5 + 1e-9:
        return None
    return Issue(
        code="passive_q",
        title=f"无源 RC 做不出 Q={q:g}",
        evidence=(
            "无源 RC 一阶网络的 Q 恒为 0.5（两个实极点，无峰化）。"
            f"Q>0.5 需要复数极点，必须用有源或有感结构，要求 Q={q:g} 无法实现。"
        ),
        suggestion="改用 Sallen-Key 二阶有源滤波（Q 可做到 0.5~10）；若要 Q≤0.5 的缓变响应则本身不需要二阶。",
    )


def check_cascaded_bandpass_q(topology_id: str, q: float, order: int = 2) -> Issue | None:
    """级联 RC 带通的 Q 上限。

    单调「先升后降」的无源串接结构没有谐振，Q 顶不上去——每侧 n 级的 Q 上限是
    0.50 / 0.78 / 0.98 / 1.15（n=1/2/3/4），由 20n·log10((r+1)/(2√r))=3.0103 解出。
    这**不是实现缺陷，是物理限制**：要 Q>1 的窄带必须换谐振型。

    宁可在这里说「做不到」，也不要返回一个通带比要求宽 20 倍的电路。
    """
    if topology_id != "filter_bandpass_synth":
        return None
    if q is None or q <= 0:
        return None
    n = max(1, int(round(order / 2.0))) if order else 1
    try:
        from .topologies import FilterBandpassSynth as _FBS
        qmax = _FBS.q_max(n)
    except Exception:
        g = 10.0 ** (3.0103 / (20.0 * n))
        sq = g + math.sqrt(max(g * g - 1.0, 0.0))
        qmax = 1.0 / max(sq - 1.0 / sq, 1e-12)
    # 边界容差：q_max 是解析解，浮点会给出 0.4999999 这种值，
    # 不加容差会把「Q=0.50 正好在设计上限」的合法需求误判为做不到。
    if q <= qmax * (1.0 + 1e-6) + 1e-9:
        return None
    need_order = None
    for cand in (2, 4, 6, 8, 10):
        try:
            from .topologies import FilterBandpassSynth as _FBS2
            if q <= _FBS2.q_max(max(1, cand // 2)):
                need_order = cand
                break
        except Exception:
            break
    tail = (f"要 Q={q:g} 至少需要 {need_order} 阶的级联结构；"
            if need_order else "")
    return Issue(
        code="cascaded_bp_q",
        title=f"级联 RC 带通做不出 Q={q:g}（上限 {qmax:.2f}）",
        evidence=(
            f"每侧 {n} 级（{2 * n} 阶）的级联 RC 带通，Q 上限是 {qmax:.2f}。"
            f"单调上升再单调下降的串接结构没有谐振，Q 无法更高——这是结构决定的，"
            f"不是元件精度问题。{tail}而在 Q>1 的窄带上强行用级联，通带会比要求宽一个数量级。"
        ),
        suggestion=(
            "窄带（Q>1）请改用谐振型：RLC 串联带通（无源、高 Q）、"
            "或多重反馈（MFB）带通、或 Sallen-Key 带通变体（有源、Q 可到 10+）。"
        ),
        severity="hard",
    )


def check_opamp_gbw(
    topology_id: str, gain: float, bw: float, gbw_hint: float | None = None
) -> Issue | None:
    """运放闭环带宽 × 增益 ≤ GBW（一阶补偿运放的硬约束）。"""
    if topology_id not in ("opamp_noninverting", "opamp_inverting", "difference_amp"):
        return None
    if gain <= 0 or bw <= 0:
        return None
    need_gbw = gain * bw
    if gbw_hint and need_gbw > gbw_hint * 1.05:
        return Issue(
            code="opamp_gbw",
            title=f"所需 GBW {need_gbw / 1e6:.3g}MHz 超过给定运放的 {gbw_hint / 1e6:.3g}MHz",
            evidence=(
                f"闭环带宽 ≈ GBW/增益 → GBW ≥ {gain:g}×{bw:g} = {need_gbw:g}Hz。"
                f"给定 GBW={gbw_hint:g}Hz，实际带宽只能到 {gbw_hint / gain:g}Hz。"
            ),
            suggestion=f"换 GBW ≥ {need_gbw * 1.3 / 1e6:.3g}MHz 的运放（留 30% 裕量），或把增益降到 {gbw_hint / bw:.2f}。",
        )
    if need_gbw > 1e9:
        return Issue(
            code="opamp_gbw_extreme",
            title=f"要求的 GBW（{need_gbw / 1e9:.3g}GHz）超出常见运放",
            evidence=f"GBW ≥ 增益×带宽 = {gain:g}×{bw:g} = {need_gbw / 1e9:.3g}GHz。",
            suggestion="降低增益或带宽，或改用多级放大（每级增益取 √总增益）。",
        )
    if need_gbw > 5e7:
        return Issue(
            code="opamp_gbw_tight",
            title=f"GBW 需求偏紧（{need_gbw / 1e6:.3g}MHz）",
            evidence=f"GBW ≥ {gain:g}×{bw:g} = {need_gbw / 1e6:.3g}MHz，属于高速运放档位。",
            suggestion="确认器件可选性（成本、功耗上升）；可考虑电流反馈型运放或降低增益。",
            severity="tight",
        )
    return None


def check_divider_ratio(topology_id: str, vout: float, vin: float) -> Issue | None:
    """无源电阻分压只能衰减。"""
    if topology_id != "divider":
        return None
    if vin <= 0 or vout <= vin * 1.0001:
        return None
    return Issue(
        code="divider_ratio",
        title=f"无源分压无法把 {vin:g}V 升到 {vout:g}V",
        evidence=f"电阻分压输出 = Vin·R2/(R1+R2) ≤ Vin，比值 R2/(R1+R2) 最大趋近 1，给不出增益。",
        suggestion="要升压需要开关电源（Boost）或有源电路，不是分压网络能做的。",
    )


FILTER_TOPO = ("rc_lowpass", "rc_highpass", "sallen_key_lowpass",
               "sallen_key_highpass", "filter_lowpass_synth")


def check_component_range(topology_id: str, fc: float) -> Issue | None:
    """元件值是否会落到买不到/做不出的范围。"""
    if topology_id not in FILTER_TOPO:
        return None
    if fc <= 0:
        return None
    # 典型取值：R 在 1k~1M 比较舒服；C 在 100pF~10µF 比较舒服
    # 由 RC 定 fc 量级判断
    if fc < 1.0:
        return Issue(
            code="fc_too_low",
            title=f"截止频率 {fc:g}Hz 太低，元件值不现实",
            evidence=f"fc={fc:g}Hz 时 R·C ≈ {1 / (2 * math.pi * fc):.3g}s，需要 1F 级电容或 100MΩ 级电阻。",
            suggestion="改用开关电容滤波、数字滤波，或先用有源滤波再分频；请确认这个频率是否写错了。",
            severity="tight",
        )
    if fc > 5e8:
        return Issue(
            code="fc_too_high",
            title=f"截止频率 {fc:g}Hz 超出集总参数电路的适用范围",
            evidence=f"fc={fc:g}Hz 时波长已与元件尺寸可比，寄生参数主导，集总参数模型失效。",
            suggestion="改用分布参数设计（微带/腔体滤波器）或射频专用滤波器。",
            severity="hard",
        )
    return None


def check_sk_high_q(topology_id: str, q: float, order: int = 2) -> Issue | None:
    """Sallen-Key 的 Q 上限与高 Q 的元件敏感度。"""
    if topology_id not in ("sallen_key_lowpass", "sallen_key_highpass"):
        return None
    if q <= 0:
        return None
    if q > 15:
        return Issue(
            code="sk_q_too_high",
            title=f"Q={q:g} 超出 Sallen-Key 的实用范围",
            evidence=(
                # 公式与方向都用 ngspice 实测核对过（相位/幅值法，与理论逐位吻合）：
                # Q = √(R1R2C1C2)/(C2(R1+R2))；R1=R2 时 Q = 0.5·√(C1/C2)。
                # 注意：拉大 R2/R1 **反而压低** Q（实测 R2/R1=10 → Q=0.288
                # 而不是 0.5），所以"靠 R2/R1 拉高"是错的，会把人带偏。
                f"单位增益 Sallen-Key 的 Q = 0.5·√(C1/C2)（R1=R2 时）。"
                f"要 Q={q:g} 需要 C1/C2={(2 * q) ** 2:.3g}，即电容比高达 "
                f"{(2 * q) ** 2:.3g}:1 —— 容差与寄生会被放大 Q 倍，无法稳定实现。"
                f"（抬高 R2/R1 只会**压低** Q，别往那个方向调。）"
            ),
            suggestion="Q>10 建议改用多级低 Q 级联（每级 Q 控制在 0.5~3），或多重反馈（MFB）拓扑。",
            severity="hard",
        )
    if q > 5:
        return Issue(
            code="sk_q_tight",
            title=f"Q={q:g} 偏高，元件容差敏感",
            evidence=f"Q 的相对误差约为元件相对误差的 Q 倍，Q={q:g} 时 1% 电阻会带来约 {q:.1f}% 的 Q 偏差。",
            suggestion="建议用 0.1% 电阻，或拆成两级低 Q 级联。",
            severity="tight",
        )
    return None


# --------------------------------------------------------------------------
# 统一入口
# --------------------------------------------------------------------------
def evaluate(
    topology_id: str,
    spec: dict[str, float],
    *,
    order: int = 1,
    q: float | None = None,
    gbw_hint: float | None = None,
    stopband: tuple[float, float] | None = None,
) -> Verdict:
    """对一条设计需求做物理可行性预判。

    spec 里认得的键：fc / f0 / gain_lin / gain_db / bw / vout / q
    stopband: (ratio, atten_db) 例如 (10, 60) 表示「10 倍截止频率处衰减 60dB」
    """
    v = Verdict()
    fc = spec.get("fc") or spec.get("f0") or 0.0
    gain = spec.get("gain_lin")
    if gain is None and spec.get("gain_db") is not None:
        gain = 10 ** (spec["gain_db"] / 20.0)
    bw = spec.get("bw") or spec.get("fc") or 0.0
    qq = q if q is not None else spec.get("q")

    if stopband is None and spec.get("atten_db"):
        # 用户只说了「要衰减 60dB」没说在几倍频率处：按行业习惯的 10×fc 评估，
        # 否则这条要求会完全绕过物理校验，一阶 RC 也敢声称达标。
        stopband = (10.0, float(spec["atten_db"]))

    if stopband:
        ratio, atten = stopband
        iss = check_stopband_order(topology_id, fc, atten, ratio)
        if iss:
            v.add(iss)
    # 带通常常只给「中心频率 + 带宽」，没显式写 Q —— 这时也要换算出来检查，
    # 否则 Q 上限形同虚设（实测「四阶带通 1kHz 带宽 800Hz」一路走到 design()
    # 才炸，报告里只写「无法推出初始参数」，用户看不出是物理限制）。
    if qq is None and topology_id == "filter_bandpass_synth":
        _bw = spec.get("bw")
        _f0 = spec.get("f0") or spec.get("fc")
        if _bw and _f0 and float(_bw) > 0:
            qq = float(_f0) / float(_bw)

    if qq is not None:
        iss = check_passive_q(topology_id, qq)
        if iss:
            v.add(iss)
        iss = check_sk_high_q(topology_id, qq, order)
        if iss:
            v.add(iss)
        iss = check_cascaded_bandpass_q(topology_id, qq, order)
        if iss:
            v.add(iss)
    if gain and bw:
        iss = check_opamp_gbw(topology_id, gain, bw, gbw_hint)
        if iss:
            v.add(iss)
    # 键名兼容：verify 侧历史上用 "__Vin"，这里用 "Vin"。传小写 "vin"
    # 会让整条分压比检查**静默跳过**（实测 {"vout":10,"vin":5} 零 issue）。
    _vin = None
    for _k in ("Vin", "__Vin", "vin"):
        if spec.get(_k) is not None:
            _vin = spec[_k]
            break
    if topology_id == "divider" and spec.get("vout") is not None and _vin:
        iss = check_divider_ratio(topology_id, spec["vout"], _vin)
        if iss:
            v.add(iss)
    if fc:
        iss = check_component_range(topology_id, fc)
        if iss:
            v.add(iss)
    return v


def required_order_table(ratio: float, targets: tuple[float, ...] = (20, 40, 60, 80)) -> list[tuple[float, int]]:
    """给用户看的「要衰减多少 dB 就需要几阶」对照表。"""
    return [(a, order_for_attenuation(a, ratio)) for a in targets]
