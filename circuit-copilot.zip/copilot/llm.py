"""大模型接入（OpenAI 兼容协议，零依赖，纯 stdlib）。

只做两件事：
  1. 自然语言 → 结构化需求（选拓扑 + 目标指标）
  2. 仿真结果 → 人话解释（设计取舍、风险、物理限制）

**刻意不让 LLM 算参数、做优化**：那是数值搜索的活。
LLM 猜数字是这类系统最常见的翻车点——猜得很快，错得很自信。
"""

from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass

DEFAULT_BASE = os.environ.get("CC_LLM_BASE", "https://api.deepseek.com/v1")
DEFAULT_MODEL = os.environ.get("CC_LLM_MODEL", "deepseek-chat")


def _config_path() -> str:
    home = os.environ.get("CC_HOME", os.path.expanduser("~/.cc"))
    return os.path.join(home, "config.json")


def load_config() -> dict:
    cfg = {
        "base": DEFAULT_BASE,
        "model": DEFAULT_MODEL,
        "key": os.environ.get("CC_LLM_KEY") or os.environ.get("DEEPSEEK_API_KEY") or "",
    }
    try:
        with open(_config_path()) as f:
            disk = json.load(f)
        for k in ("base", "model", "key"):
            if disk.get(k):
                cfg[k] = disk[k]
    except FileNotFoundError:
        pass    # 没配置过是常态，走内置默认
    except Exception as e:
        # 配置文件存在但损坏（半截 JSON、编码错）不能无声跳过：用户会以为
        # 自己的 key 生效了，实际回退到了环境变量/默认值。
        import sys
        print(f"[llm] 配置文件 {_config_path()} 无法解析（已忽略，用内置默认/环境变量）："
              f"{type(e).__name__}: {e}", file=sys.stderr)
    return cfg


def save_config(**kw) -> str:
    path = _config_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cfg = load_config()
    cfg.update({k: v for k, v in kw.items() if v})
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2)
    os.chmod(path, 0o600)
    return path


class LLMError(RuntimeError):
    pass


@dataclass
class LLM:
    def __post_init__(self):
        cfg = load_config()
        self.base = cfg["base"].rstrip("/")
        self.model = cfg["model"]
        self.key = cfg["key"]

    def available(self) -> bool:
        return bool(self.key)

    def chat(
        self,
        messages: list[dict],
        *,
        temperature: float = 0.2,
        max_tokens: int = 1600,
        json_mode: bool = False,
        timeout: float = 90.0,
    ) -> str:
        if not self.key:
            raise LLMError("未配置 API Key")
        body = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        req = urllib.request.Request(
            f"{self.base}/chat/completions",
            data=json.dumps(body).encode(),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.key}",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            detail = e.read().decode(errors="replace")[:500]
            raise LLMError(f"HTTP {e.code}: {detail}") from None
        except urllib.error.URLError as e:
            raise LLMError(f"网络错误: {e.reason}") from None
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            raise LLMError(f"响应格式异常: {json.dumps(data)[:300]}") from None


def extract_json(text: str) -> dict:
    """从模型回复里抠出 JSON（容忍 ```json 包裹和前后废话）。"""
    text = text.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if m:
        text = m.group(1).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start, depth = None, 0
    for i, ch in enumerate(text):
        if ch == "{":
            if start is None:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start is not None:
                try:
                    return json.loads(text[start : i + 1])
                except json.JSONDecodeError:
                    start = None
    raise LLMError("模型没有返回可解析的 JSON")


# --------------------------------------------------------------------------
# Prompt —— 这一层是产品差异化的核心，不要写空话
# --------------------------------------------------------------------------

SYSTEM_PLAN = """你是资深模拟电路工程师。把用户的自然语言需求翻译成结构化设计规格。

{taxonomy}

{constraints}

## 输出格式
严格 JSON，不要任何多余文字：
{{
  "topology": "上面清单里的 id",
  "spec": {{"指标key": 数值}},
  "reason": "一句话说明为什么选这个拓扑结构（要提到关键权衡，不要只说'因为它是低通'）",
  "assumptions": ["用户没说但你必须定的量，以及你定的值"],
  "clarify": ["为了更准确，需要用户补充的信息（没有就空数组）"],
  "caveat": "需求里物理上做不到的部分，直说；没有就空字符串",
  "confidence": 0.0~1.0
}}

## 硬性规则
- spec 的 key 必须**逐字**来自该拓扑的「可用指标」列表。不在列表里的 key 会被系统直接丢弃。
- 频率一律填 Hz（1kHz=1000，1MHz=1e6）。增益用 gain_lin（倍数）或 gain_db（dB，20log10）。
- **只填用户真正提出的指标**。用户没提的（比如没说要 Q）不要擅自加。
- 用户没说但拓扑必需的（运放 GBW、开环增益）**不要填**，系统会自动选。
- 用户说「衰减 X dB」「抑制 X dB」是阻带要求，不是增益；放 caveat 说明，不要当成 gain。

## 三个必须做对的判断
1. **区分 eq 与 min 语义**
   - 滤波器「截止频率 1kHz」= 精确指标（1kHz）
   - 放大器「带宽 100kHz」= 下限要求（≥100kHz），填 fc=100000
2. **assumptions 必须写**。例如用户说「做一个低通」没说频率，你按 1kHz 设计，
   就写 "未指定截止频率，按通用音频场景取 1kHz"。这是诚实，不是啰嗦。
3. **clarify 只在真的影响结果时才问**，不要为了显得谨慎而问。
   ❌ "请问您的应用场景是什么"（没用）
   ✅ "没说带宽是按 -3dB 还是 -20dB 定义，本设计按 -3dB"

## 示例

用户：二阶低通，截止1kHz，Q=0.707
输出：{{"topology":"sallen_key_lowpass","spec":{{"fc":1000,"q":0.707}},"reason":"Q=0.707 是巴特沃斯响应，需要复数极点，无源 RC 的 Q 恒为 0.5 做不到，故选单位增益 Sallen-Key 二阶有源结构","assumptions":[],"clarify":[],"caveat":"","confidence":0.95}}

用户：一阶RC低通，10倍截止频率处要衰减60dB
输出：{{"topology":"rc_lowpass","spec":{{"fc":1000}},"reason":"用户指定一阶 RC，先按此设计","assumptions":["未指定截止频率，按 1kHz 设计以便计算阻带"],"clarify":["建议确认是否必须一阶：若要 60dB 需至少三阶"],"caveat":"一阶 RC 在 10 倍截止频率处只能衰减约 20dB，60dB 在物理上做不到，需要至少 3 阶（或级联两节 Sallen-Key 得四阶）","confidence":0.9}}

用户：10倍同相放大，需要100kHz带宽
输出：{{"topology":"opamp_noninverting","spec":{{"gain_lin":10,"fc":100000}},"reason":"同相结构输入阻抗高，增益=1+R2/R1；带宽以 -3dB 为下限要求，意味着需 GBW≥1MHz","assumptions":["带宽按 -3dB 定义","未指定电源电压与负载"],"clarify":[],"caveat":"","confidence":0.9}}

用户：把5V分压到2.5V给ADC采样
输出：{{"topology":"divider","spec":{{"vout":2.5}},"reason":"纯衰减且要求比例精确，电阻分压最直接；主要取舍是功耗与输出阻抗","assumptions":["输入 5V，输出 2.5V"],"clarify":[],"caveat":"","confidence":0.95}}

用户：做个滤波器
输出：{{"topology":"rc_lowpass","spec":{{"fc":1000}},"reason":"需求过于笼统，先给最通用的 RC 低通作为起点","assumptions":["未指定低通/高通/带通，按最常见的低通处理","未指定截止频率，按音频常用 1kHz"],"clarify":["需要低通、高通还是带通？","截止频率大概多少？","对滚降有要求吗（决定用一阶还是二阶有源）？"],"caveat":"需求信息不足，以下结果是按默认假设给出的，可能不是你要的电路","confidence":0.3}}
"""

SYSTEM_REVIEW = """你是资深模拟电路工程师，给一位硬件工程师写设计评审。

你会收到一份 JSON：需求原文、选定拓扑、设计规格、实际元件值、ngspice 仿真实测指标、
达标判定、蒙特卡洛容差分析结果（成品率与各指标分布）。

## 写法要求
写 200~300 字中文，结构固定为三段：

1. **结论**（一句话）：达标就说达标，不达标就直接说哪项差多少。
2. **取舍与代价**：为什么这个结构/这些元件值合理，代价是什么（成本、精度、功耗、面积）。
3. **风险与下一步**：给 1~2 条**具体的、可执行**的建议，必须带数字。

## 铁律
- **必须引用具体数字**（元件值、Hz、dB、成品率百分比），不许只做定性描述。
- 如果成品率低，必须点出**是哪一项指标、分布压到了哪一侧**，以及该怎么改（收紧某个元件的容差、把标称值往中心挪、换拓扑）。
- 不许重复罗列已经给出的指标表。
- 不许说「性能良好」「设计合理」「满足需求」这类废话。
- 不许编造数据里没有的数字。
- 不许提「作为 AI」「根据提供的信息」这类元话语。
"""

SYSTEM_INTENT = """你是严格的评审员。判断「设计出来的电路」是否真的是「用户想要的电路」。

给你用户原始需求和最终选定的拓扑 + 规格。只需回答：
- 拓扑是否对得上需求（比如用户要高通却选了低通，就是不匹配）
- 指标理解是否合理（比如用户说"衰减 60dB"却把 60 当成增益）
- 有没有明显偷换概念或遗漏

输出严格 JSON：
{"match": true/false, "problem": "if false, 一句话说清哪里错了", "severity": "hard/warn/none"}
不要客套，不要解释你的推理过程。"""


def _constraints_text() -> str:
    """把物理硬约束写进 prompt —— 让模型先知道「什么做不到」，而不是硬编一个答案。"""
    return """## 已知物理硬约束（选拓扑和写 caveat 时要遵守）
- 无源 RC 一阶网络的 Q 恒为 0.5，做不出 Q>0.5（即巴特沃斯 Q=0.707 必须有源）。
- 一阶 RC 阻带滚降固定 −20dB/十倍频；N 阶巴特沃斯在 10×fc 处衰减约 20N dB。
  要 60dB@10fc 至少需要 3 阶。
- 运放闭环带宽 ≈ GBW/增益，所以 GBW 必须 ≥ 增益×带宽。
- 无源电阻分压只能衰减，输出 ≤ 输入，不能升压。
- 单位增益 Sallen-Key 的 Q 实用上限约 5~10；Q>10 应改成多级低 Q 级联。
- 集总参数电路在 500MHz 以上失效；1Hz 以下的 RC 需要不现实的元件值。"""


def plan(llm: LLM, request: str, taxonomy: str, history: list[str] | None = None) -> dict:
    """自然语言 → {topology, spec, reason, assumptions, clarify, caveat, confidence}"""
    sys_prompt = SYSTEM_PLAN.format(taxonomy=taxonomy, constraints=_constraints_text())
    user = request
    if history:
        user += "\n\n## 对话上下文（同一会话之前的轮次，按时间顺序）\n" + "\n".join(history[-4:])
    raw = llm.chat(
        [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user},
        ],
        json_mode=True,
        temperature=0.1,
        max_tokens=1200,
    )
    try:
        return extract_json(raw)
    except LLMError:
        # 一次修复重试：把原始输出和格式要求再喂一次，比直接失败有用
        raw2 = llm.chat(
            [
                {"role": "system", "content": "你上一条回复不是合法 JSON。只输出 JSON 对象，不要任何解释、不要 markdown 代码围栏。"},
                {"role": "user", "content": f"原始需求：{request}\n你上一条回复：{raw[:600]}\n请重新输出合法的 JSON。"},
            ],
            json_mode=True,
            temperature=0.0,
            max_tokens=1200,
        )
        return extract_json(raw2)


def review(llm: LLM, payload: dict) -> str:
    return llm.chat(
        [
            {"role": "system", "content": SYSTEM_REVIEW},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False, indent=2)},
        ],
        temperature=0.35,
        max_tokens=900,
    ).strip()


def judge_intent(llm: LLM, request: str, topology_name: str, spec: dict) -> dict:
    """语义一致性复核：防止「用户要 A，系统做了 B」这种最伤人的错误。"""
    try:
        raw = llm.chat(
            [
                {"role": "system", "content": SYSTEM_INTENT},
                {
                    "role": "user",
                    "content": json.dumps(
                        {"用户需求": request, "选定拓扑": topology_name, "设计规格": spec},
                        ensure_ascii=False,
                    ),
                },
            ],
            json_mode=True,
            temperature=0.0,
            max_tokens=300,
        )
        out = extract_json(raw)
        return {
            "match": bool(out.get("match", True)),
            "problem": str(out.get("problem") or "").strip(),
            "severity": str(out.get("severity") or "none"),
            "degraded": False,
        }
    except LLMError as e:
        # 模型不可用 ≠ 复核通过：显式标记 degraded，让上层能区分
        # 「模型确认没冲突」和「复核根本没做成」，并在 stderr 留痕。
        import sys
        print(f"[llm] 语义复核不可用（按未复核处理）：{type(e).__name__}: {e}", file=sys.stderr)
        return {"match": True, "problem": "", "severity": "none", "degraded": True}
