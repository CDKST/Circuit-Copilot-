"""指标判定：确定性代码，不含任何模型成分。

单独成模块是为了让 tolerance → judge 的依赖不绕回 agent（避免循环导入），
同时也守住了架构边界：判定逻辑必须能被独立复核。

## 容差语义（这里踩过一个严重 bug，务必看清）

容差有「相对」和「绝对」两种，**不能混用**：
    - 频率、增益倍数、电压、阻抗：相对容差（10% 就是目标值的 ±10%）
    - dB 值、角度：绝对容差（±1dB、±5°）

早期实现把 SPEC_RULE 里的容差一律当相对值存放，但 `min`/`max` 模式却按绝对值
比较，结果「截止频率目标 1000Hz、容差 10%」被解释成 `actual >= 999.9Hz`——
990.9Hz 被判不合格，Sallen-Key 滤波器成品率被算成 50%（真实应为 95%+）。
现在每个规则显式声明 tol_kind，比较统一走「允许区间」，不再有歧义。
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from . import topologies as T


@dataclass(frozen=True)
class Rule:
    mode: str   # eq（落在区间内） | min（不低于） | max（不高于）
    tol: float
    kind: str   # rel（相对目标值） | abs（绝对单位）

    def band(self, target: float) -> tuple[float, float]:
        """返回允许区间 [lo, hi]。"""
        d = abs(target) * self.tol if self.kind == "rel" else self.tol
        if self.mode == "eq":
            return target - d, target + d
        if self.mode == "min":
            return target - d, math.inf
        if self.mode == "max":
            return -math.inf, target + d
        raise ValueError(f"未知模式 {self.mode}")


# 指标 → 判定规则
SPEC_RULE: dict[str, Rule] = {
    "fc": Rule("eq", 0.10, "rel"),
    "f0": Rule("eq", 0.10, "rel"),
    "bw": Rule("eq", 0.15, "rel"),
    "q": Rule("eq", 0.15, "rel"),
    "gain_lin": Rule("eq", 0.05, "rel"),
    "gain_db": Rule("eq", 0.6, "abs"),
    "atten_db": Rule("min", 1.0, "abs"),
    "depth_db": Rule("min", 1.0, "abs"),
    "pm": Rule("min", 5.0, "abs"),
    "peaking_db": Rule("max", 0.6, "abs"),
    "cmrr_db": Rule("min", 3.0, "abs"),
    "vout": Rule("eq", 0.02, "rel"),
    "iout": Rule("eq", 0.10, "rel"),
    "power": Rule("max", 0.15, "rel"),
    "rout": Rule("max", 0.20, "rel"),
    "ugf": Rule("eq", 0.15, "rel"),
}


@dataclass
class CheckRow:
    key: str
    target: float
    actual: float
    ok: bool
    mode: str
    tol: float
    kind: str = "rel"
    lo: float = -math.inf
    hi: float = math.inf

    @property
    def label(self) -> str:
        return T.METRICS.get(self.key, T.MetricInfo(self.key, "")).label

    @property
    def unit(self) -> str:
        return T.METRICS.get(self.key, T.MetricInfo(self.key, "")).unit

    def _scale(self) -> float:
        d = abs(self.target) * self.tol if self.kind == "rel" else self.tol
        return max(d, 1e-12)

    def deviation(self) -> float:
        """超出允许区间的程度（0 = 在区间内），已按容差归一化，可跨指标相加。"""
        if self.actual is None or (isinstance(self.actual, float) and math.isnan(self.actual)):
            return math.inf
        if self.lo <= self.actual <= self.hi:
            return 0.0
        scale = self._scale()
        if self.actual < self.lo:
            return (self.lo - self.actual) / scale
        return (self.actual - self.hi) / scale

    def center_dev(self) -> float:
        """离目标中心有多远（已归一化）。**排序用**，与合格判定严格分开。

        为什么需要它：`deviation()` 对区间内一律返回 0，若直接拿它排序，
        所有合格候选都同分，搜索会停在「第一个合格」而不是「最贴近目标」。
        结果就是 1kHz 的高通给出 1.12kHz——合格但白扔 12% 余量。
        对 min/max 类指标（如衰减、相位裕度）没有「越靠目标越好」的含义，
        区间内统一记 0，不干扰排序。
        """
        if self.actual is None or (isinstance(self.actual, float) and math.isnan(self.actual)):
            return math.inf
        if self.mode != "eq":
            return self.deviation()
        return abs(self.actual - self.target) / self._scale()


def _rule_for(key: str, mode_override: str | None) -> Rule:
    base = SPEC_RULE.get(key, Rule("eq", 0.10, "rel"))
    if mode_override and mode_override != base.mode:
        return Rule(mode_override, base.tol, base.kind)
    return base


def check(spec: dict[str, float], metrics: dict[str, float],
          overrides: dict[str, str] | None = None) -> list[CheckRow]:
    rows: list[CheckRow] = []
    overrides = overrides or {}
    for k, target in spec.items():
        if k not in T.METRICS:
            continue
        rule = _rule_for(k, overrides.get(k))
        lo, hi = rule.band(target)
        actual = metrics.get(k)
        if actual is None or (isinstance(actual, float) and math.isnan(actual)):
            rows.append(CheckRow(k, target, float("nan"), False, rule.mode,
                                 rule.tol, rule.kind, lo, hi))
            continue
        ok = lo <= actual <= hi
        rows.append(CheckRow(k, target, actual, ok, rule.mode,
                             rule.tol, rule.kind, lo, hi))
    return rows


def cost(rows: list[CheckRow]) -> tuple[int, float]:
    """(未达标项数, 离目标中心的总归一化距离)——越小越好。

    第一关键字是判定结果，第二关键字是「有多居中」。
    两者必须分开：用 deviation 排序会让所有合格候选同分（都 0），
    搜索就退化成了「找到一个能用的就收工」。
    """
    bad = sum(0 if r.ok else 1 for r in rows)
    err = sum(min(r.center_dev(), 5.0) for r in rows)
    return bad, err
