"""ngspice 仿真内核封装。

设计取舍（踩过的坑）：
  1. ngspice batch 模式必须有 .control 块，只有 .meas 会报
     "no .plot/.print lines in batch mode" 而静默不跑 → 统一注入 .control。
  2. 网表表达式里 `pi` 不被识别 → 所有参数在 Python 侧算成纯数字再写入。
  3. `.meas ... FIND vdb(x) AT=` 的解析不稳定 → 不做 .meas，指标全部从
     ASCII rawfile 波形在 Python 侧计算。

结论：ngspice 只干一件事——把波形算出来。判定与指标归 Python。
这样上层 AI 出错时，物理结果依然是可信的。
"""

from __future__ import annotations

import math
from array import array
import os
import re
import subprocess
import tempfile
import time
from dataclasses import dataclass, field

def _default_ngspice() -> str:
    """优先使用仓库自带的 ngspice（vendor/ngspice/bin），找不到再退回 PATH。

    自带一份是为了「开箱即跑」：Windows 上没有 pkg/apt，PATH 里也没有 ngspice，
    而 vendor 目录里连依赖 DLL 都齐了，直接调用即可。

    ⚠ 必须**按平台挑**并**验证可执行**，不能只看文件存在：
    vendor 里放的是 Windows 的 .exe + .dll，仓库又会在手机/电脑之间同步。
    如果只判断 os.path.exists，Android/Linux 上会选中那个 .exe，
    然后在 subprocess 里炸 `PermissionError: [Errno 13]` ——
    表现是「所有仿真全挂」，但错误信息指向一个看起来存在的文件，很难联想到平台问题。
    """
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    is_win = os.name == "nt"
    # Windows 只认 .exe；其它平台只看无扩展名的可执行文件
    names = ("ngspice_con.exe", "ngspice.exe") if is_win else ("ngspice_con", "ngspice")
    for name in names:
        cand = os.path.join(root, "vendor", "ngspice", "bin", name)
        if not os.path.isfile(cand):
            continue
        # 非 Windows 还要确认有执行位（从 FAT/sdcard 拷过来的文件常常没有）
        if is_win or os.access(cand, os.X_OK):
            return cand
    return "ngspice"


NGSPICE = os.environ.get("NGSPICE_BIN") or _default_ngspice()


def sim_workers() -> int:
    """并行仿真线程数。

    ngspice 是独立子进程（每次 run() 一个临时目录），线程池只负责等待，
    GIL 不构成瓶颈，多核直接受益。上限 4：手机温控 + 每个子进程十几 MB 内存。
    环境变量 CC_SIM_WORKERS 可显式覆盖（设 1 即回退纯串行）。
    """
    env = os.environ.get("CC_SIM_WORKERS")
    if env:
        try:
            return max(1, int(env))
        except ValueError:
            pass
    return max(1, min(4, (os.cpu_count() or 2) // 2))

_RE_ERR_FATAL = re.compile(
    r"(singular matrix|no convergence|doAnalyses: not found|incomplete or empty netlist|"
    r"unknown subckt|unknown device|fatal)",
    re.I,
)


class SimError(RuntimeError):
    """仿真失败，携带原始网表与输出，供上层自纠。"""

    def __init__(self, message: str, netlist: str, raw_output: str = ""):
        super().__init__(message)
        self.netlist = netlist
        self.raw_output = raw_output


@dataclass
class Wave:
    """一条复数波形：x 轴 + 复数样本。AC 分析 x=freq，TRAN 分析 x=time（虚部为 0）。"""

    x: list[float] = field(default_factory=list)
    y: list[complex] = field(default_factory=list)
    # 派生数组缓存（首算后复用）：一次 extract 里 db()/real() 会被多个指标函数
    # 各调一遍（_find_f3db/_attenuation_at/_db_at…），×40 候选 ×20 次蒙特卡洛
    # 全量重算是纯浪费。调用方约定只读不写（项目内已核对无原地修改）。
    _db: list[float] | None = field(default=None, repr=False, compare=False)
    _mag: list[float] | None = field(default=None, repr=False, compare=False)
    _real: list[float] | None = field(default=None, repr=False, compare=False)
    _phase: list[float] | None = field(default=None, repr=False, compare=False)

    def mag(self) -> list[float]:
        if self._mag is None:
            self._mag = [abs(v) for v in self.y]
        return self._mag

    def db(self) -> list[float]:
        if self._db is None:
            out = []
            for v in self.y:
                m = abs(v)
                out.append(20.0 * math.log10(m) if m > 0 else -300.0)
            self._db = out
        return self._db

    def real(self) -> list[float]:
        if self._real is None:
            self._real = [v.real for v in self.y]
        return self._real

    def phase_deg(self) -> list[float]:
        if self._phase is None:
            self._phase = [math.degrees(math.atan2(v.imag, v.real)) for v in self.y]
        return self._phase


@dataclass
class SimResult:
    waves: dict[str, Wave] = field(default_factory=dict)
    netlist: str = ""
    stdout: str = ""
    elapsed_ms: float = 0.0
    warnings: list[str] = field(default_factory=list)

    @property
    def nodes(self) -> list[str]:
        return sorted(self.waves)

    def __contains__(self, name: str) -> bool:
        return name.lower() in self.waves


#: 用二进制 rawfile 解析（默认开）。ASCII 只有 ~10 位有效数字，且 12MB 文本要
#: 拆成 50 万+ 字符串再逐个 float()——实测解析占总耗时的 **70%**。
#: 二进制是 float64 原值（更快**更准**），解析交给 array("d") 一次读完。
#: 环境变量 CCL_RAW_ASCII=1 可强制退回 ASCII（出问题时的手动开关）。
def _use_binary_raw() -> bool:
    return os.environ.get("CCL_RAW_ASCII", "") not in ("1", "true", "yes")


def _parse_binary_raw(path: str) -> dict[str, Wave] | None:
    """解析 ngspice `set filetype=binary` 的 rawfile。

    格式：纯 ASCII 头部（`No. Variables:` / `No. Points:` / `Flags:` / `Variables:` 表）
    + 一行 `Binary:\n`，之后是原生 double 序列（复数则是实部/虚部交替）。
    解析失败一律返回 None，由调用方回退 ASCII —— 可视化数据不能决定仿真成败。
    """
    try:
        with open(path, "rb") as f:
            head = b""
            while not head.endswith(b"Binary:\n"):
                ch = f.read(1)
                if not ch:
                    return None
                head += ch
                if len(head) > (1 << 20):     # 头部不可能这么大 → 不是二进制格式
                    return None
            meta = head.decode("ascii", "replace")
            n_vars = 0
            n_pts = 0
            flags = ""
            for ln in meta.splitlines():
                if ln.startswith("No. Variables:"):
                    n_vars = int(ln.split(":", 1)[1])
                elif ln.startswith("No. Points:"):
                    n_pts = int(ln.split(":", 1)[1])
                elif ln.startswith("Flags:"):
                    flags = ln.split(":", 1)[1].strip().lower()
            if not n_vars or not n_pts:
                return None
            names: list[str] = []
            for ln in meta.rsplit("Variables:\n", 1)[-1].splitlines():
                if not ln.strip():
                    continue
                parts = ln.split()
                if len(parts) >= 2:
                    names.append(parts[1].strip().lower())
            per = 2 if "complex" in flags else 1
            need = n_vars * n_pts * per * 8
            raw = f.read(need)
            if len(raw) < need:
                return None
    except Exception:
        return None

    a = array("d")
    a.frombytes(raw)
    is_cx = per == 2
    is_sweep = bool(names) and names[0] in ("frequency", "time")
    if is_sweep:
        if is_cx:
            xaxis = [a[k * n_vars * 2] for k in range(n_pts)]
        else:
            xaxis = [a[k * n_vars] for k in range(n_pts)]
    else:
        # `.op` 的 plot 没有独立横轴（第 0 列就是变量本身），与 ASCII 解析口径保持一致
        xaxis = [float(k) for k in range(n_pts)]

    waves: dict[str, Wave] = {}
    for vi, name in enumerate(names):
        if is_sweep and vi == 0:
            continue
        if is_cx:
            ys = [complex(a[(k * n_vars + vi) * 2], a[(k * n_vars + vi) * 2 + 1])
                  for k in range(n_pts)]
        else:
            ys = [complex(a[k * n_vars + vi], 0.0) for k in range(n_pts)]
        waves[name] = Wave(x=list(xaxis), y=ys)
    return waves


def _parse_ascii_raw(path: str) -> dict[str, Wave]:
    """解析 ngspice ASCII rawfile → {变量名: Wave}。"""
    with open(path, "r", errors="replace") as f:
        lines = f.read().splitlines()

    try:
        i_var = lines.index("Variables:")
        i_val = lines.index("Values:")
    except ValueError:
        return {}

    n_vars = 0
    for ln in lines[:i_var]:
        if ln.startswith("No. Variables:"):
            n_vars = int(ln.split(":", 1)[1])

    names: list[str] = []
    for ln in lines[i_var + 1 : i_var + 1 + n_vars]:
        parts = ln.split()
        if len(parts) >= 2:
            names.append(parts[1].strip().lower())

    # 值区：每条记录以「序号」开头，共 n_vars 个数值
    tokens: list[str] = []
    for ln in lines[i_val + 1 :]:
        s = ln.strip()
        if not s:
            continue
        parts = s.split()
        if parts[0].isdigit() and not s.startswith((",", "-")):
            parts = parts[1:]
        tokens.extend(t.rstrip(",") for t in parts)

    samples: list[complex] = []
    for t in tokens:
        try:
            if "," in t:
                re_, im_ = t.split(",")
                samples.append(complex(float(re_), float(im_)))
            else:
                samples.append(complex(float(t), 0.0))
        except ValueError:
            continue

    n_pts = len(samples) // n_vars if n_vars else 0
    waves: dict[str, Wave] = {}
    if not n_pts:
        return waves
    # 只有 AC（frequency）/ TRAN（time）才有独立横轴；`.op` 的 plot 没有横轴，
    # 第 0 列就是一个普通变量（通常是 v(in)）。早期实现无条件把第 0 列当横轴，
    # 导致 .op 结果里第一个变量凭空消失——看起来正常，其实是错的。
    is_sweep = bool(names) and names[0] in ("frequency", "time")
    if is_sweep:
        xaxis = [samples[k * n_vars].real for k in range(n_pts)]
    else:
        xaxis = [float(k) for k in range(n_pts)]  # 单点（op）或点序列
    for vi, name in enumerate(names):
        if is_sweep and vi == 0:
            continue
        waves[name] = Wave(x=list(xaxis), y=[samples[k * n_vars + vi] for k in range(n_pts)])
    return waves


#: 哪些器件类型值得保存「支路量」，以及用哪个参数名取电流。
#: 电阻/电容/电感是 i；二极管/BJT/MOS 是 id/ic/id（ngspice 里各自不同）。
_SAVE_PARAM = {
    "R": "i", "C": "i", "L": "i",
    "D": "id", "Q": "ic", "M": "id", "J": "id",
    # 开关本身也有支路电流（@sw1[i]）。不给它保存的话，动画里「开关这一段没有电流」
    # 就只能靠相邻元件推断——那是猜，不是数据。
    "S": "i",
}


_RE_ANALYSIS_CARD = re.compile(r"^\s*\.(ac|op|tran|dc)\b", re.I | re.M)


def _analysis_kind(deck: str) -> str:
    """从网表里认出分析类型（多张卡时以最后一张为准，与 ngspice 一致）。

    返回 "none" 表示**网表里还没有分析卡** —— 这时绝不能下发 save：
    调用方（ccl/runner）通常先 `to_spice()` 拿到器件行、再 re-tune 分析卡，
    所以 sim.run 收到「只有器件、没有卡」的网表是正常中间态。
    早先这里默认返回 "op"，于是交流电路也被下了 save，直接崩（实测回归）。
    """
    kinds = [m.group(1).lower() for m in _RE_ANALYSIS_CARD.finditer(deck)]
    if not kinds:
        return "none"
    last = kinds[-1]
    return last if last in ("ac", "op", "dc") else "tran"


def _save_devices(deck: str) -> str:
    """生成 save 语句，把每个器件的支路电流也存进 rawfile。

    为什么需要：`write all` 只给节点电压和电源电流，**不含器件内部量**。
    而「让电路动起来」（LED 按电流发光、电阻按功耗发热、晶体管按 id 显示导通）
    全部依赖每个器件真实流过的电流。没有这些数据，动画就只能靠编。

    实测：显式 `save all @r1[i] @d1[id]` 之后，rawfile 里会出现
    `i(@r1[i]) = 3.094mA`、`i(@d1[id]) = 3.094mA`，全部来自真求解。

    只挑**网表里真实存在**的位号，避免 ngspice 因未知器件报错。
    """
    kind = _analysis_kind(deck)
    # ⚠ **交流分析一律不做 save**：AC 是频域，根本没有「器件支路电流」这个量。
    # 实测（逐个隔离验证过）：
    #   save all @r1[i]  → ngspice 报 "vector @r1[i] is not available"，
    #                      write 失败 → 「仿真未产生任何波形数据」
    #   save all @c1[i]  → 同上
    # 也就是说**连电阻的电流在 AC 下也取不到**。一旦下发 save，原本能跑的
    # 交流电路会整个崩掉（这个回归是我引入并被 tests_api 抓到的）。
    # 结论：只有 op / tran / dc 才保存器件量，AC 保持原样。
    # AC 没有支路电流；"none" 表示分析卡还没加进来，同样不下发
    if kind in ("ac", "none"):
        return ""
    refs: list[str] = []
    in_subckt = False
    for raw in deck.splitlines():
        s = raw.strip()
        if not s or s.startswith(("*", "+")):
            continue
        low = s.lower()
        # ⚑ 必须跳过 `.subckt` ~ `.ends` 之间的器件：那些是**子电路内部**的元件，
        # ngspice 的 `@rin[i]` 在顶层命名空间里根本不存在。
        # 实测事故（我引入的崩溃回归）：运放宏模型内部有 R0/C0，save 了 `@c0[i]` →
        #   "Warning from checkvalid: vector @c0[i] is not available" →
        #   "Error during 'write': no writable vector found" → 整个仿真失败。
        # 于是**任何含 c.OpAmp() 的电路在 op/tran/dc 下 100% 跑不了**，
        # 而项目自带的运放 topology 只做 .ac（不 save），测试全绿没抓到。
        if low.startswith(".subckt"):
            in_subckt = True
            continue
        if low.startswith(".ends"):
            in_subckt = False
            continue
        if in_subckt:
            continue
        if s.startswith("."):
            continue
        kind_c = s[0].upper()
        if kind_c not in _SAVE_PARAM:
            continue
        parts = s.split()
        if len(parts) < 2:
            continue
        ref = parts[0].lower()
        refs.append(f"@{ref}[{_SAVE_PARAM[kind_c]}]")
    if not refs:
        return ""
    # ngspice 对单个 save 行的长度没有硬限制，但拆成多行更稳（也更好读日志）
    return "save all " + " ".join(refs) + "\n"


def branch_currents(result: "SimResult", at_index: int = 0) -> dict[str, float]:
    """从仿真结果里抽出「每个器件的电流」（安培）。取不到的不放进去，不编。

    `at_index` 选择时间点：0 = 起始点（op 只可能有一个点）；`-1` = 末点。
    ⚑ 必须能和调用方取电压的时刻**对齐**：早先这里写死取 `ys[0]`，
    而 `collect_live` 的电压已改成末点 → 功耗算成了 |I(t=0)·V(t末点)|，
    没有物理意义（实测 PULSE 电路报 R1 0A/0W，真值 11.4mA/28mW、
    同一份 live 里 V 却是 2.5V —— 电压和电流来自两个不同时刻）。
    """
    out: dict[str, float] = {}
    for name, w in (result.waves or {}).items():
        # rawfile 里的变量名形如 i(@r1[i]) / i(@d1[id]) —— 注意结尾是 ") 不是 "]"
        # （第一版按 "] 结尾"判断，结果一个都没解析出来）
        if not (name.startswith("i(@") and name.endswith(")")):
            continue
        try:
            ref = name[3: name.index("[")]        # @r1
        except ValueError:
            continue
        ys = w.y or []
        if not ys:
            continue
        k = at_index if -len(ys) <= at_index < len(ys) else 0
        out[ref] = abs(complex(ys[k]).real)
    return out


def run(netlist: str, *, timeout_s: float = 60.0) -> SimResult:
    """执行网表。自动注入 .control 保证波形落盘。失败抛 SimError。"""
    if ".end" not in netlist.lower():
        raise SimError("网表缺少 .end", netlist)

    t0 = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="ccsim_") as tmp:
        def build(save: str) -> str:
            head, sep, tail = netlist.rpartition(".end")
            _ft = "binary" if _use_binary_raw() else "ascii"
            return (f"{head}{sep}\n.control\nset filetype={_ft}\n"
                    f"{save}run\nwrite c.raw all\n.endc\n.end\n{tail}")

        has_control = ".control" in netlist.lower()
        save = "" if has_control else _save_devices(netlist)
        deck = netlist if has_control else build(save)
        with open(os.path.join(tmp, "c.cir"), "w") as f:
            f.write(deck)

        def exec_ngspice():
            return subprocess.run(
                [NGSPICE, "-b", "c.cir"],
                cwd=tmp,
                capture_output=True,
                text=True,
                timeout=timeout_s,
            )

        try:
            proc = exec_ngspice()
        except FileNotFoundError:
            raise SimError("找不到 ngspice，请先执行 pkg install ngspice", netlist)
        except subprocess.TimeoutExpired:
            raise SimError(f"仿真超时（>{timeout_s}s），电路可能不收敛", netlist)

        # ⚑ 降级保险：**可视化用的 save 绝不能决定仿真的成败**。
        # ngspice 对某些器件/分析组合会在 save 时报
        # "vector @xx[i] is not available" → `write` 失败 → 看起来像"电路跑不了"，
        # 实际是"取不到某个器件电流"。真出这种情况，丢掉 save 重跑一次：
        # 电路结果仍然正确，只是没有器件级数据（界面就不显示工作态）。
        if save:
            raw_p = os.path.join(tmp, "c.raw")
            bad = (not os.path.exists(raw_p)) or os.path.getsize(raw_p) == 0
            txt = ((proc.stdout or "") + (proc.stderr or "")).lower()
            if bad or "no writable vector found" in txt:
                deck = build("")
                with open(os.path.join(tmp, "c.cir"), "w") as f:
                    f.write(deck)
                try:
                    proc2 = exec_ngspice()
                    if proc2.returncode == 0 or os.path.exists(raw_p) and os.path.getsize(raw_p) > 0:
                        proc = proc2
                except Exception:
                    pass

        stdout = (proc.stdout or "") + (proc.stderr or "")
        elapsed = (time.perf_counter() - t0) * 1000

        raw_path = os.path.join(tmp, "c.raw")
        waves: dict[str, Wave] = {}
        if os.path.exists(raw_path):
            if _use_binary_raw():
                waves = _parse_binary_raw(raw_path) or {}
            if not waves:
                # 回退 ASCII（老 ngspice / 格式变动 / 我们自己解析出错都走这里）
                waves = _parse_ascii_raw(raw_path)

        fatal = [ln.strip() for ln in stdout.splitlines() if _RE_ERR_FATAL.search(ln)]
        warnings = [
            ln.strip()
            for ln in stdout.splitlines()
            if ln.strip().lower().startswith(("warning", "note:")) and "no value" not in ln.lower()
        ]

        # `write c.raw all` 在没有任何器件时会生成一条名为 all 的伪向量
        # （y 值恰好等于频率轴），上层会把它当成真实波形，丢掉「网表错了」这条线索（B8）
        ghost = set(waves) == {"all"}
        if fatal or not waves or ghost:
            detail = "\n".join(fatal[:6]) or (
                "网表里没有可仿真的器件（或器件名被当成注释），仿真器只回了一条伪向量" if ghost
                else "仿真未产生任何波形数据")
            raise SimError(f"仿真失败：{detail}", netlist, stdout[-3000:])

        return SimResult(
            waves=waves, netlist=deck, stdout=stdout, elapsed_ms=elapsed, warnings=warnings
        )


def version() -> str:
    try:
        p = subprocess.run([NGSPICE, "-v"], capture_output=True, text=True, timeout=10)
        m = re.search(r"ngspice-([\d.]+)", (p.stdout or "") + (p.stderr or ""))
        return m.group(1) if m else "unknown"
    except Exception:
        return "not-installed"
