"""设计闭环：需求 → 拓扑 → 数值寻优 → 仿真验证 → 判定 → 评审。

分工原则（本项目的核心思想）：
    语言理解 & 解释  →  LLM
    参数寻优 & 指标计算 → 数值搜索 + ngspice
    判定              → 确定性代码

为什么不让 LLM 直接给元件值？因为它会给出「1kΩ 和 2.2kΩ 组成 3.2kΩ」
这种看着合理、实际买不到的答案，而一次仿真只要 60ms——用搜索比用猜快且准。
"""

from __future__ import annotations

import itertools
import math
import re
import time
from dataclasses import dataclass, field

from . import elements as E
from . import llm as L
from . import sim
from . import topologies as T
from . import tolerance as MC
from .judge import CheckRow, check, cost  # noqa: F401  (对外保持同名导出)

LABEL_ALIAS = {
    "截止频率": "fc", "fc": "fc", "带宽": "bw", "bw": "bw", "中心频率": "f0",
    "f0": "f0", "品质因数": "q", "q": "q", "增益": "gain_lin", "gain": "gain_lin",
    "增益db": "gain_db", "衰减": "atten_db", "相位裕度": "pm", "输出电压": "vout",
    "功耗": "power", "纹波": None,
    # ⚑ 这三个以前没别名 → 模型就算返回了也映射不进指标表。
    # 实测后果：「5V分压到1.8V，输出阻抗小于100Ω」→ spec 只有 {vout}，
    # 实际 rout=2304Ω（超 23 倍）却判 passed=True。
    "输出阻抗": "rout", "rout": "rout", "阻抗": "rout", "输出电阻": "rout",
    "输出电流": "iout", "iout": "iout", "电流": "iout", "带载": "iout",
    "共模抑制比": "cmrr_db", "共模抑制": "cmrr_db", "cmrr": "cmrr_db",
    "cmrr_db": "cmrr_db", "共模抑制比db": "cmrr_db",
}

SI = {"p": 1e-12, "n": 1e-9, "u": 1e-6, "µ": 1e-6, "m": 1e-3, "k": 1e3,
      "K": 1e3, "M": 1e6, "G": 1e9}

# 非指标型设计选择（滤波器阶数/响应类型/通带波纹）的别名。
# 它们由 topology.design_keys 声明后才被放行到 design()，不参与判定。
DESIGN_ALIAS = {
    "阶数": "order", "滤波阶数": "order", "滤波器阶数": "order", "order": "order", "n": "order",
    "类型": "kind", "响应类型": "kind", "滤波器类型": "kind", "响应": "kind",
    "kind": "kind", "type": "kind", "filter_type": "kind",
    "波纹": "ripple_db", "通带波纹": "ripple_db", "波纹db": "ripple_db",
    "ripple": "ripple_db", "ripple_db": "ripple_db",
}


def parse_quantity(s: str) -> tuple[float, str] | None:
    """解析 '1kHz' / '10k' / '2.2uF' / '20dB' → (数值, 单位)。"""
    m = re.search(r"([-+]?\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*([a-zA-ZΩ°]*)", s)
    if not m:
        return None
    num = float(m.group(1))
    mul = SI.get(m.group(2), 1.0)
    unit = m.group(3).lower()
    return num * mul, unit


# --------------------------------------------------------------------------
# 判定
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# 候选参数搜索
# --------------------------------------------------------------------------
def _neighborhood(v0: float, series: str, k: int = 5) -> list[float]:
    """在 v0 的 ±1 倍频程内生成 E 系列候选（按离 v0 的距离排序）。

    只用 snap_pair 的「下/近/上」三个值太粗：电容在 10n/12n 之间没有中间档，
    导致 1kHz 目标只能给出 934Hz 或 1142Hz，白白浪费 12% 余量。
    取邻域能把 12n/15n/18n 等档位都纳入搜索。
    """
    if v0 <= 0:
        return [v0]
    base = E.SERIES.get(series, E.E24)
    lo, hi = v0 / 2.0, v0 * 2.0
    cands: list[float] = []
    # ⚑ 十倍频窗口必须**按 v0 动态算**，不能写死。
    # 早先写的是 `range(-3, 7)`，只覆盖 1e-3 ~ 1e7 —— 而电容全在 1e-12 ~ 1e-6，
    # 完全落在窗口外 → cands 为空 → 退回 snap_pair 只给 1 档。
    # 实测后果：10nF / 100nF / 1µF 的候选都只有 **1 个**（电阻有 5 个），
    # 等于参数化设计在**电容这一维上完全没有自由度**，只能靠电阻硬凑，
    # 设计点被迫贴着规格边界（目标 1777Hz 时误差 1.578%，而全 E24×E12 穷举能到 0.040%）。
    d0 = int(math.floor(math.log10(v0)))
    for decade in range(d0 - 2, d0 + 3):        # ±2 个十倍频足够覆盖 lo..hi
        for m in base:
            try:
                v = m * (10.0 ** decade)
            except OverflowError:
                continue
            if lo <= v <= hi:
                cands.append(v)
    if not cands:
        return E.snap_pair(v0, series)
    cands.sort(key=lambda v: abs(math.log(v / v0)))
    if len(cands) <= k:
        return cands
    # 取「离初值最近的 k 个」。
    # 试过改成「在 ±1 倍频程上均匀铺开」，实测反而更差：铺开会把靠近初值的档位
    # （如 R=9.76k）挤出候选，而跨方向补偿所需的档位（如 R=8.87k）又落不进来，
    # 两头不讨好。保持近端密集 —— 补偿交给「多跑几档」而不是「铺得更开」。
    return cands[:k]


def _candidates(topo: T.Topology, base: dict[str, float], per_param: int = 0,
                budget: int = 48) -> list[dict[str, float]]:
    """围绕解析初值，为每个 E 系列参数生成邻域候选，按「离初值多远」截断。

    inactive_params(base) 声明的参数（如 order=2 时综合滤波器的后两级）
    固定取初值、不展开邻域：它们对当前设计选择完全不起作用，展开只会
    让组合数按 3^n 爆炸（order=2 的 9 参数网格 3⁹=19683 组合里 99.6% 无效）。
    """
    inactive = topo.inactive_params(base)
    # ⚑ 每轴给几档必须**按有效轴数自适应**，不能一律 3。
    # 实测：RC 低通只有 R/C 两个轴，每轴 3 档 → 总共只跑 **9 次仿真**，
    # 于是 fc 只能落到 E24 电容步进（~10%）的 2~3% 误差上；
    # 而 `budget` 是按「总组合数」兜底的，轴少时完全有余量多试几档。
    # 轴多时仍然压到 3（组合数爆炸），无轴变化时退回 1。
    # 每轴候选数保持 3。试过按轴数自适应放宽到 5（RC 低通 9→25 次仿真），
    # 实测精度一点没变、耗时翻倍 —— 说明这类电路的误差不是候选太少造成的。
    # 保持 3 是“够用且不白花钱”的选择。
    if per_param <= 0:
        per_param = 3
    axes: list[list[tuple[float, float]]] = []  # (值, 距离)
    for p in topo.params:
        v0 = base.get(p.name)
        if v0 is None:
            raise KeyError(p.name)
        if not p.series or p.name in inactive:
            axes.append([(v0, 0.0)])
            continue
        opts = _neighborhood(v0, p.series, per_param)
        opts = list(dict.fromkeys(opts))
        axes.append([(v, abs(math.log(max(v, 1e-15) / max(v0, 1e-15)))) for v in opts])

    combos = []
    for combo in itertools.product(*axes):
        vals = tuple(c[0] for c in combo)
        dist = sum(c[1] for c in combo)
        combos.append((dist, dict(zip((p.name for p in topo.params), vals))))
    combos.sort(key=lambda x: x[0])
    return [c[1] for c in combos[:budget]]


@dataclass
class Session:
    request: str
    topology: str = ""
    topology_name: str = ""
    spec: dict[str, float] = field(default_factory=dict)
    best: T.Design | None = None
    tries: list[T.Design] = field(default_factory=list)
    rows: list[CheckRow] = field(default_factory=list)
    review: str = ""
    reason: str = ""
    caveat: str = ""
    plan_source: str = "rule"
    total_sims: int = 0
    total_ms: float = 0.0
    mc: "MC.MCResult | None" = None
    feasibility: object = None      # feasibility.Verdict
    conflicts: list = field(default_factory=list)  # verify.Conflict
    error: str = ""

    @property
    def blocked(self) -> bool:
        """物理上做不到（feasibility 判了 hard）。"""
        return bool(self.feasibility is not None
                    and getattr(self.feasibility, "hard", None))

    @property
    def trustworthy(self) -> bool:
        """结果能不能被信任地宣布达标。

        光看指标达标是不够的：如果「用户说的数」和「系统设计的数」对不上，
        或者需求本身物理不可行，那就绝不能标成成功——否则用户拿着错答案去打样。
        """
        return not self.conflicts and not self.blocked

    @property
    def passed(self) -> bool:
        return bool(self.rows) and all(r.ok for r in self.rows) and self.trustworthy


# --------------------------------------------------------------------------
# 规则解析（无 Key 兜底 / LLM 失败时的降级路径）
# --------------------------------------------------------------------------
#: 阶数的中文数字（「四阶」「三階」都覆盖不到，只处理简体常用写法）
CN_NUM = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8}

#: 滤波器响应类型关键词 → kind。前 3 条是英文（含常见简写），其余是中文说法。
KIND_WORDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("butterworth", ("butterworth", "butter", "巴特沃斯", "巴特沃", "最大平坦幅度")),
    ("chebyshev", ("chebyshev", "cheby", "切比雪夫", "雪夫", "等波纹")),
    ("bessel", ("bessel", "贝塞尔", "线性相位", "最平坦群延迟")),
)


def parse_order(text: str) -> int | None:
    """从「4阶」「四阶」「6 阶」「order=4」里解析阶数（阿拉伯数字与中文数字都认）。"""
    m = re.search(r"(\d+)\s*阶", text)
    if m:
        return int(m.group(1))
    m = re.search(r"([一二两三四五六七八])\s*阶", text)
    if m:
        return CN_NUM[m.group(1)]
    m = re.search(r"order\s*[=＝:：]?\s*(\d+)", text, re.I)
    if m:
        return int(m.group(1))
    return None


def parse_kind(text: str) -> str | None:
    low = text.lower()
    for kind, words in KIND_WORDS:
        if any(w in low for w in words):
            return kind
    return None


def parse_ripple_db(text: str) -> float | None:
    """「0.5dB 波纹」「通带波纹 1dB」→ 波纹值。"""
    m = re.search(r"(\d+(?:\.\d+)?)\s*d\s*b\s*(?:的)?\s*(?:通带)?\s*(?:波纹|纹波)", text, re.I)
    if m is None:
        m = re.search(r"(?:通带)?\s*(?:波纹|纹波)[^。；;，,\d]{0,6}?(\d+(?:\.\d+)?)\s*d\s*b", text, re.I)
    return float(m.group(1)) if m else None


def parse_rules(text: str) -> dict:
    t = text.replace("Ｋ", "k").replace("Ｈ", "H")
    low = t.lower()
    caveat = ""

    # 综合型低通：说了「几阶」或说了响应类型（Butterworth/Chebyshev/Bessel）就该走综合，
    # 而不是退回「给定元件值」的 sallen_key_lowpass。注意三点：
    #   1) 只在**低通**语境下抢路由（高通/带通仍交给下面的分支，它们各自有专门拓扑）；
    #   2) 阶数 ≥3 时没有任何固定元件值可用，必须综合；
    #   3) 「二阶低通（不带响应类型）」保持原有行为，落到 sallen_key_lowpass，避免回归。
    want_kind = parse_kind(t)
    want_order = parse_order(t)
    is_low = ("低通" in t or "滤波" in t) and "高通" not in t and "带通" not in t and "带阻" not in t
    goto_synth = is_low and (want_kind is not None or (want_order is not None and want_order >= 3))

    # 高通综合：只有**三阶及以上**才走 filter_highpass_synth。
    # 二阶高通继续用 sallen_key_highpass —— 那是真正的二阶 Sallen-Key，
    # 过渡带比「两个一阶串联」更陡；级联综合的滚降虽然也是 40dB/dec，
    # 但形状不是 Butterworth。保持既有行为优先（tests 里有对应用例）。
    is_high = "高通" in t and "低通" not in t and "带通" not in t and "带阻" not in t
    goto_hp_synth = is_high and want_order is not None and want_order >= 3

    # 带通综合：显式给了阶数或响应类型时走 filter_bandpass_synth；
    # 只说「做个带通 1kHz」时仍落 rlc_bandpass —— 那是真谐振结构，
    # 窄带（Q>1）反而更合适，不该被级联方案抢走。
    is_band = "带通" in t and "低通" not in t and "高通" not in t and "带阻" not in t
    goto_bp_synth = is_band and (want_order is not None or want_kind is not None)

    # 顺序即优先级：越具体的结构越要先匹配，否则「二阶高通」会被「高通」抢走、
    # 「差分放大」会被「放大」抢走。
    low_nospace = low.replace(" ", "").replace("－", "-")
    # 「12V 转/降/分 3.3V」没有「分压」二字，但语义就是分压（否则会落到 rc_lowpass 变成空设计）
    _volts = re.findall(r"(\d+(?:\.\d+)?)\s*[vV](?![a-zA-Z])", t)
    _two_v = len(_volts) >= 2 and re.search(
        r"\d+(?:\.\d+)?\s*[vV]\s*(?:转|降|分|变|弄|衰减)\s*(?:到|成|为|至)?", t)
    if goto_synth:
        topo = "filter_lowpass_synth"
    elif goto_hp_synth:
        topo = "filter_highpass_synth"
    elif goto_bp_synth:
        topo = "filter_bandpass_synth"
    elif any(w in t for w in ("陷波", "带阻", "notch", "工频干扰")):
        # 陷波/带阻：Twin-T。必须排在「带通」之后但排在低通兜底之前，
        # 且和带通互斥（带通放行 f0，陷波掐掉 f0，方向相反，选错等于没滤）。
        topo = "twin_t_notch"
    elif "sallen" in low_nospace or "萨伦" in t:
        topo = ("sallen_key_highpass" if "高通" in t else "sallen_key_lowpass")
    elif "二阶" in t and "高通" in t:
        topo = "sallen_key_highpass"
    elif "有源" in t and "高通" in t and "低通" not in t:
        topo = "sallen_key_highpass"
    elif "差分" in t or "减法" in t or "仪表" in t or "共模" in t or "cmrr" in low:
        topo = "difference_amp"
    elif "二阶" in t and "低通" in t:
        topo = "sallen_key_lowpass"
    elif "高通" in t:
        topo = "rc_highpass"
    elif "带通" in t or "谐振" in t:
        topo = "rlc_bandpass"
    elif "分压" in t or _two_v:
        topo = "divider"
    elif "反相" in t:
        topo = "opamp_inverting"
    elif "低通" in t or "滤波" in t:
        topo = "rc_lowpass"
    elif "放大" in t or "增益" in t or "运放" in t:
        topo = "opamp_noninverting"
    else:
        topo = "rc_lowpass"


    spec: dict[str, float] = {}

    # 频率
    fm = re.search(r"(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*(?:hz|赫兹|赫)", t, re.I)
    if fm:
        val, _ = parse_quantity(fm.group(0))
        if topo == "rlc_bandpass":
            spec["f0"] = val
        else:
            spec["fc"] = val

    # 陷波：用 f0（不是 fc）
    if topo == "twin_t_notch":
        if "fc" in spec:
            spec["f0"] = spec.pop("fc")

    # 带通要的是 (中心频率, 带宽) 一对，不是单个 fc。
    # 只抓「第一个 Hz 数字」会把 1kHz 当 fc、而「带宽 800Hz」完全丢掉，
    # 结果 design() 拿不到 bw、只好按默认带宽算，或者干脆报「做不到」。
    # ⚑ 带宽解析必须对**所有**带通生效：实测「RLC带通 1kHz 带宽500Hz」默认路由到
    # rlc_bandpass，而 bw 只在这个 filter_bandpass_synth 分支里解析 → bw 被整个丢掉
    # → design() 退回默认 Q=5 → 实测 bw=172Hz（目标 500，窄 2.9 倍）却判 passed=True。
    # 原注释写的就是「『带宽 800Hz』完全丢掉」——补丁打在了错的分支上。
    if "bandpass" in topo:
        _num = r"(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*(?:hz|赫兹|赫)"
        mf0 = re.search(r"(?:中心频率|中心|f0)\s*(?:为|是|=|:|：)?\s*" + _num, t, re.I)
        mbw = re.search(r"(?:带宽|bw|bandwidth)\s*(?:为|是|=|:|：|约)?\s*" + _num, t, re.I)
        if mf0:
            spec["f0"], _ = parse_quantity(mf0.group(1) + mf0.group(2) + "Hz")
        elif "fc" in spec:
            spec["f0"] = spec.pop("fc")     # 没写「中心」时，第一个频率当中心
        if mbw:
            spec["bw"], _ = parse_quantity(mbw.group(1) + mbw.group(2) + "Hz")

    # 增益
    gm = re.search(r"(\d+(?:\.\d+)?)\s*(?:倍|×|x(?![a-z]))", t, re.I)
    gdb = re.search(r"(\d+(?:\.\d+)?)\s*db", t, re.I)

    # 阻带衰减：「衰减/抑制 X dB」「X dB @N倍fc」「N倍频率处挡掉 X dB」
    # 语义和增益完全相反，必须抢在 gdb 之前识别，否则 60dB 衰减会被当成 60dB 增益（B6）
    atten_m = re.search(r"(?:衰减|抑制|挡掉|滤除|压制)\D{0,8}?(\d+(?:\.\d+)?)\s*db", t, re.I)
    if not atten_m:
        atten_m = re.search(r"(\d+(?:\.\d+)?)\s*db\s*(?:@|at|的)?\s*(\d+(?:\.\d+)?)\s*倍", t, re.I)
    if atten_m:
        spec["atten_db"] = float(atten_m.group(1))
        gdb = None
        gm = None     # 「10 倍」在「衰减60dB@10倍fc」里是频率比，不是增益  # 已消费，不得再当增益
    # 陷波的「凹陷深度 X dB」是「要挖多深」，不是增益。
    # 不单独识别的话会被通用 dB 规则抓成「增益 95dB」，然后拿 −0.01dB 去比对，
    # 报一个看起来像失败的错判（实测过）。
    dm = re.search(r"(?:凹陷深度|凹陷|陷波深度|notch\s*depth|深度)\D{0,6}?(\d+(?:\.\d+)?)\s*db", t, re.I)
    if dm and topo == "twin_t_notch":
        spec["depth_db"] = float(dm.group(1))
        gdb = None
        gm = None
    # 陷波里「衰减 X dB」说的是凹陷深度（这一步必须放在衰减解析**之后**：
    # 早先放在前面，atten_db 那时还没解析出来，映射就落空了）
    if topo == "twin_t_notch" and "atten_db" in spec and "depth_db" not in spec:
        spec["depth_db"] = spec.pop("atten_db")
    # 共模抑制比：先单独抓「共模抑制 80dB」这类说法，否则会被当成增益
    cm = re.search(r"(?:共模|cmrr)[^。；;，,0-9]{0,6}?(\d+(?:\.\d+)?)\s*db", t, re.I)
    if cm and topo == "difference_amp":
        spec["cmrr_db"] = float(cm.group(1))
    if gm:
        spec["gain_lin"] = float(gm.group(1))
    elif gdb and "cmrr_db" not in spec:
        spec["gain_db"] = float(gdb.group(1))
    elif topo.startswith("opamp") or topo == "difference_amp":
        spec["gain_lin"] = 10.0

    # 分压输入电压
    if topo == "divider":
        vm = re.search(r"(\d+(?:\.\d+)?)\s*v(?![a-z])", t, re.I)
        vin = float(vm.group(1)) if vm else 5.0
        # 「把12V分压到3.3V」这类说法以前完全匹配不到，退回「一半」给出 6V 还自称达标（B7）。
        # 目标电压有多个句式，逐个试；全部电压里最后一个通常就是目标。
        om = None
        for pat in (
            r"(?:分压|降压|降|衰减|转换|变|弄)\s*(?:到|成|为|至)\s*(\d+(?:\.\d+)?)\s*v",
            r"(?:输出|得到|要|需要)\s*(?:电压)?\s*(?:为|是|到|:)?\s*(\d+(?:\.\d+)?)\s*v",
            r"(\d+(?:\.\d+)?)\s*v\s*(?:给|供|送|接)",
        ):
            om = re.search(pat, t, re.I)
            if om:
                break
        if om:
            spec["vout"] = float(om.group(1))
        elif "一半" in t or "1/2" in t or "半" in t:
            spec["vout"] = vin / 2
        else:
            # 兜底：取文本里所有电压的最后一个（「把 A 分压到 B」中 B 在后）
            allv = [float(x) for x in re.findall(r"(\d+(?:\.\d+)?)\s*v(?![a-z])", t, re.I)]
            spec["vout"] = allv[-1] if len(allv) >= 2 else vin / 2
        # 分压的 Vin 塞进 spec 之外，由 design 读取
        spec["__Vin"] = vin

    # Q
    # ⚑ 中文习惯写法通常不带等号：「品质因数5」「阻尼比0.5」。
    # 早先只认 `q=5`，于是「二阶低通 1kHz，品质因数5」的 q 被丢掉、按 0.707 造，
    # 实测 Q=0.677、峰化 0dB（Q=5 应 +14dB），却判 passed=True。
    qm = re.search(
        r"(?:品质因数|品质因子|阻尼比|阻尼系数|q)\s*(?:为|是|取|=|＝|:|：)?\s*(\d+(?:\.\d+)?)",
        t, re.I)
    if qm and topo in ("rlc_bandpass", "sallen_key_lowpass", "sallen_key_highpass"):
        spec["q"] = float(qm.group(1))

    # 综合型低通的「设计选择」：阶数 / 响应类型 / 波纹。
    # 它们不是可判定指标（不进 METRICS），但 design() 必须拿到——
    # 由 Topology.design_keys 声明后放行，判定表会自动忽略它们。
    if topo == "filter_lowpass_synth":
        # 「0.5dB 波纹」会被上面的通用 dB 规则抓成「增益 0.5dB」——滤波器是单位增益，
        # 用户写的 dB 数几乎总是波纹/衰减。原话没提「增益」就别把它当指标判。
        if "增益" not in t and "gain" not in low:
            spec.pop("gain_db", None)
            spec.pop("gain_lin", None)
        order = want_order or 2
        if order not in (2, 4, 6):
            # 只支持 2/4/6 阶（每级一个二阶节，Sallen-Key 造不出奇数阶的单极点节）。
            # 往**上**取：用户要 3 阶是要「更陡」，给他 2 阶等于偷工减料。
            near = min((k for k in (2, 4, 6) if k >= order), default=6)
            caveat = f"只支持 2/4/6 阶有源低通综合，{order} 阶已按 {near} 阶设计"
            order = near
        spec["order"] = float(order)
        spec["kind"] = want_kind or "butterworth"
        rp = parse_ripple_db(t)
        if rp is not None:
            spec["ripple_db"] = rp
            # Chebyshev（偶次阶）的通带波纹恰好等于峰化（直流落在波纹谷底），
            # 所以把用户的波纹要求同时挂到 peaking_db 上参与判定：
            # 否则「波纹 0.5dB」只是一句无人验证的话，Q 做偏了报告照样说达标。
            spec["peaking_db"] = rp
        elif want_kind == "chebyshev":
            caveat = (caveat + "；" if caveat else "") + "未指定 Chebyshev 通带波纹，按 0.5dB 设计"
        # 「最平坦通带」是 Butterworth / Bessel 的定义性质，等价于把峰化规格定在 0dB
        # （判定规则是 max "不高于 目标+0.6dB"）。不写进去的话搜索只会盯 fc，
        # 通带会悄悄长出 0.4dB 的鼓包，而报告依然说「全部达标」。
        if want_kind in ("butterworth", "bessel") and "peaking_db" not in spec:
            spec["peaking_db"] = 0.0

    if topo == "filter_bandpass_synth":
        # 带通是「每侧 N 级 → 总阶数 2N」，必须偶数；奇数额向往上取。
        order = want_order or 2
        if order % 2:
            # 带通是「每侧 N 级」，总阶数只能是偶数。奇数额向往上取（宁多不少）。
            caveat = (caveat + "；" if caveat else "") + \
                f"级联带通只能做偶数阶，{order} 阶已按 {order + 1} 阶设计"
            order += 1
        order = max(2, min(order, 6))
        spec["order"] = float(order)
        # 级联带通有固有插损（实测宽带的 0.01dB，窄带的几 dB），
        # 用户没明说「增益」时不要把 dB 数当成输出增益去判。
        if "增益" not in t and "gain" not in low:
            spec.pop("gain_db", None)
            spec.pop("gain_lin", None)
        # Q 超过该阶数的结构上限时，先说清楚做不到（design 也会拒，但提示要提前）。
        _q = spec.get("q")
        if _q:
            try:
                from .topologies import FilterBandpassSynth as _FBS
                _qmax = _FBS.q_max(max(1, order // 2))
                if float(_q) > _qmax * (1 + 1e-6):
                    caveat = (f"级联 RC 带通的 Q 上限是 {_qmax:.2f}（每侧 {order // 2} 级），"
                              f"要求 Q={float(_q):g} 做不到；窄带请改用 RLC 串联带通或 MFB 带通。")
            except Exception:
                pass

    # ⚑ 分压拓扑声明了 4 个指标（vout/iout/power/rout），judge 也有 4 条规则，
    # 但这里一直没有它们的解析分支 —— 用户写进需求里的量化约束在进判定表之前就蒸发了。
    # 实测：「5V分压到1.8V，输出阻抗小于100Ω」→ spec 只有 {vout}，
    # 实际 rout=2304Ω（超 23 倍）却判 passed=True，评审写「设计全部指标达标」。
    _um = r"(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)"
    _LIM = r"(?:小于|低于|不超过|不大于|≤|<|至少|大于|高于|不小于|≥|>)"
    if "divider" in topo or topo == "divider":
        mo = re.search(_LIM + r"\s*" + _um + r"\s*(?:欧|Ω|ohm|欧姆)", t, re.I)
        if mo:
            spec["rout"], _ = parse_quantity(mo.group(1) + mo.group(2) + "")
        mi = re.search(_LIM + r"\s*" + _um + r"\s*(?:ma|毫安|a|安)", t, re.I)
        if mi:
            spec["iout"], _ = parse_quantity(mi.group(1) + mi.group(2) + "A")
        mp = re.search(_LIM + r"\s*" + _um + r"\s*(?:mw|毫瓦|w|瓦)", t, re.I)
        if mp:
            spec["power"], _ = parse_quantity(mp.group(1) + mp.group(2) + "W")

    # ── 总闸：需求里出现了量化指标，却没进判定表 → 必须让用户知道 ──
    # 这条防的是「静默放过」这一整类：词表漏一个词，用户就拿到一个盖着
    # 「✅ 全部指标达标」印章的错答案。宁可多提醒，也不能悄悄丢。
    _dropped = _check_metric_coverage(t, spec)
    if _dropped:
        caveat = (caveat + "；" if caveat else "") + \
            "需求里这些量化指标没有被判定（本工具暂不支持或词表没覆盖）：" + "、".join(_dropped)

    return {
        "topology": topo,
        "spec": spec,
        "reason": "按关键词规则匹配（未启用大模型）",
        "caveat": caveat,
        "unparsed_metrics": _dropped,
    }


#: 关键词 → 它对应的判定键。用于「用户提了但没被解析」的自检。
#: 只列**词义明确**的，避免把「12V 输入」这类当成被丢掉的指标。
_METRIC_WORDS: tuple[tuple[str, str], ...] = (
    (r"输出阻抗|输出电阻|带载能力|rout", "rout"),
    (r"输出电流|iout", "iout"),
    (r"功耗|功率", "power"),
    (r"带宽", "bw"),
    (r"品质因数|品质因子|阻尼比|阻尼系数", "q"),
    (r"截止频率|中心频率|频率", None),      # 频率键因拓扑而异，单独判
    (r"增益", None),
    (r"衰减|抑制", "atten_db"),
    (r"相位裕度|pm", "pm"),
    (r"共模抑制|cmrr", "cmrr_db"),
    (r"纹波", "ripple_db"),
)


def _check_metric_coverage(text: str, spec: dict) -> list[str]:
    """需求里提到的量化指标，有没有进 spec？（没进就返回它的说法，供上层提醒）

    为什么需要：这个项目的判定只看 `spec` 里的键。上游词表只要漏一个词
    （实测漏过 `输出阻抗`/`输出电流`/`功耗`、`带宽` 打错分支、`品质因数5` 无等号），
    用户就会拿到一个「全部指标达标」的错答案，而且**没有任何提示**。
    与其逐个补词表（永远补不完），不如在这里统一兜底自检。
    """
    out: list[str] = []
    for pat, key in _METRIC_WORDS:
        m = re.search(pat, text, re.I)
        if not m:
            continue
        near = text[max(0, m.start() - 12): m.end() + 18]
        # 语句附近必须带数字才算"量化要求"，否则只是顺口提一句
        if not re.search(r"\d", near):
            continue
        if key is None:
            continue          # 频率/增益：键名随拓扑变，交给各自的解析分支
        if key not in spec:
            out.append(f"{m.group(0)}（应为 {key}）")
    return out


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def taxonomy_text() -> str:
    lines = ["可用电路拓扑清单："]
    for item in T.catalog():
        keys = ", ".join(f"{m['key']}({m['label']}/{m['unit']})" for m in item["metrics"])
        lines.append(f"- id={item['id']}  名称={item['name']}\n  说明：{item['summary']}\n  可用指标：{keys}")
    return "\n".join(lines)


def _normalize_spec(topo: T.Topology, raw: dict) -> tuple[dict[str, float], float]:
    """把 LLM/规则给的 spec 规范化：映射别名、过滤不支持的指标、提取隐藏参数。"""
    spec: dict[str, float] = {}
    extra: dict[str, float] = {}
    designs: dict[str, float] = {}
    for k, v in (raw or {}).items():
        key = str(k).strip().lower()
        if key.startswith("__"):
            extra[key[2:]] = v
            continue
        # 非指标型的设计选择（滤波器阶数/类型/波纹）：只放行拓扑自己声明过的键，
        # 免得脏键混进判定表或报告。judge.check 会忽略 METRICS 之外的键。
        dkey = DESIGN_ALIAS.get(key, key)
        if dkey in topo.design_keys:
            designs[dkey] = v
            continue
        key = LABEL_ALIAS.get(k, LABEL_ALIAS.get(key, key))
        if not key or key not in T.METRICS:
            continue
        try:
            spec[key] = float(v)
        except (TypeError, ValueError):
            continue
    # 目标拓扑没做的指标不要瞎比
    allowed = set(topo.metrics_keys)
    spec = {k: v for k, v in spec.items() if k in allowed}
    spec.update(designs)
    return spec, extra.get("Vin") or extra.get("vin")


_SYNTH_IDS = ("filter_lowpass_synth", "filter_highpass_synth", "filter_bandpass_synth")


def prefer_synth_topology(request: str) -> str | None:
    """需求里**显式写了阶数或响应类型**时，规则层认定的综合拓扑。

    阶数、Butterworth/Chebyshev/Bessel 这些是可以用正则确定判断的**事实**，
    不该交给温度>0 的模型自由裁定。实测教训：需求「四阶带通滤波器，中心频率
    1kHz，带宽 800Hz」，模型选了单级 RLC 串联带通（它给出的选型理由里甚至在
    描述级联结构，前后自相矛盾），结果中心频率偏 59%、带宽超 950Hz。

    返回 None 表示「需求没到能强制综合的程度」——这时尊重模型的选择。
    """
    try:
        plan = parse_rules(request)
    except Exception:
        return None
    tid = plan.get("topology") or ""
    if tid not in _SYNTH_IDS:
        return None
    # ⚑ 带通的一个**误杀**：级联 RC（先升后降）没有谐振，Q 顶到 0.5 就是天花板。
    # 实测：「二阶带通，中心频率 100kHz，带宽 20kHz」（Q=5）会路由到级联综合 →
    # 被物理闸门拒绝；但同一份需求换成「RLC 带通…Q=5」**能成功**
    # （L=0.3mH、R=33Ω）。也就是说工具明明做得到，却因为选了自己做不到的结构
    # 而说「不可能」——这是最贵的一类错误。
    # 这里改成：Q 超上限时直接选无源的 rlc_bandpass（真谐振，Q 由 R 定）。
    if tid == "filter_bandpass_synth":
        try:
            from .topologies import FilterBandpassSynth as _FBS
        except Exception:
            _FBS = None
        if _FBS is not None:
            spec = plan.get("spec") or {}
            f0 = spec.get("f0") or spec.get("fc")
            bw = spec.get("bw")
            try:
                q = float(f0) / float(bw) if (f0 and bw) else spec.get("q")
            except (TypeError, ValueError, ZeroDivisionError):
                q = None
            order = synth_order_for(tid, request) or 2
            n = max(1, int(round(order / 2.0)))
            if q is not None:
                try:
                    qmax = _FBS.q_max(n)
                except Exception:
                    qmax = 0.5
                # 只在**阶数也允许**时改走 RLC：`rlc_bandpass` 是单节二阶谐振，
                # 用户要 4/6 阶时它给不出更陡的裙边，直接换过去等于用错阶数答非所问
                # （宁可保留级联综合那条信息完整的拒绝，也不偷偷降阶）。
                if float(q) > qmax * (1.0 + 1e-6) + 1e-9 and order <= 2:
                    return "rlc_bandpass"
    return tid


def synth_order_for(topology_id: str, request: str) -> float | None:
    """综合拓扑该用几阶（由原话里的阶数规范化到该拓扑允许的取值）。"""
    o = parse_order(request) or 0
    if topology_id == "filter_bandpass_synth":
        if not o:
            return None
        if o % 2:            # 带通是「每侧 N 级」→ 总阶数必须偶数
            o += 1
        return float(max(2, min(o, 6)))
    if topology_id == "filter_lowpass_synth":
        if not o:
            return None
        return float(min((k for k in (2, 4, 6) if k >= o), default=6))
    if topology_id == "filter_highpass_synth":
        if not o:
            return None
        return float(max(1, min(o, 3)))
    return None


def run(request: str, *, budget: int = 40, use_llm: bool = True,
        progress=None) -> Session:
    """完整设计闭环。progress(stage, payload) 用于前端流式反馈。"""
    sess = Session(request=request)

    def emit(stage: str, **kw):
        if progress:
            progress(stage, {"session": sess, **kw})

    # ---- 阶段 0：能力边界（早于一切解析）----
    # 本工具没做的电路类别必须当场拒绝，不能兜底成最接近的拓扑。
    # 实测事故：要「Buck 降压 5V」→ 给了电阻分压 → 报告写「✅ 全部达标，可直接打样」；
    # 要「50Hz 陷波」→ 给了 RLC **带通**（方向相反，50Hz 原样通过）。
    # 放在这里还有一个好处：省掉一次模型调用（这类需求本来就没法做）。
    from . import scope as _SC
    _lim = _SC.detect(request)
    if _lim:
        from . import feasibility as _F0
        _v = _F0.Verdict()
        _v.add(*_lim)
        sess.feasibility = _v
        sess.error = f"{_lim[0].title}。{_lim[0].evidence}建议：{_lim[0].suggestion}"
        return sess

    # ---- 阶段 1：理解需求 ----
    emit("understand")
    plan: dict
    client = L.LLM()
    if use_llm and client.available():
        try:
            plan = L.plan(client, request, taxonomy_text())
            sess.plan_source = "llm"
        except L.LLMError as e:
            plan = parse_rules(request)
            plan["caveat"] = f"大模型调用失败（{e}），已降级为规则解析"
            sess.plan_source = "rule"
    else:
        plan = parse_rules(request)
        sess.plan_source = "rule"

    tid = plan.get("topology") or "rc_lowpass"
    try:
        topo = T.get(tid)
    except KeyError:
        topo = T.get("rc_lowpass")

    # 确定性语义兜底：大模型在 temperature>0 时对同一句话会给出不同拓扑
    # （实测「把12V分压到3.3V给STM32的ADC采样」一次 divider、一次 rc_lowpass）。
    # 只有在「语义唯一指向某个拓扑」时才覆盖模型的选择，避免误改模糊需求。
    try:
        from . import verify as _VF2
        _want = _VF2.expect_topology(request)
        if _want and len(_want) == 1:
            _forced = next(iter(_want))
            if topo.id != _forced:
                _old = topo.name
                topo = T.get(_forced)
                sess.caveat = (
                    sess.caveat + f"；原判为「{_old}」，按需求语义改为「{topo.name}」"
                ).strip("；")
    except Exception as _e:
        print(f"[gate] 拓扑语义兜底异常：{type(_e).__name__}: {_e}", file=__import__("sys").stderr)

    # 显式阶数/响应类型 → 强制综合拓扑（确定性事实，模型说了不算）
    _notes: list[str] = []
    _synth = prefer_synth_topology(request)
    if _synth and topo.id != _synth:
        _old_name = topo.name
        topo = T.get(_synth)
        _notes.append(f"原判为「{_old_name}」，但需求写明了阶数/响应类型，已改用「{topo.name}」")

    sess.topology, sess.topology_name = topo.id, topo.name
    sess.reason = (plan.get("reason") or "").strip()
    sess.caveat = (plan.get("caveat") or "").strip()
    # ⚠ 这里不能只用 plan.caveat 覆盖：上面几道确定性兜底的说明会被无声吃掉。
    if _notes:
        sess.caveat = "；".join([x for x in [sess.caveat, *_notes] if x])

    spec, vin = _normalize_spec(topo, plan.get("spec") or {})

    # 滤波器综合的「设计选择」是确定性的（阶数、响应类型、波纹都能从原话里正则出来），
    # 而大模型经常漏填或换个键名返回。所以缺什么就用规则补什么，已有的值不动。
    if topo.id in _SYNTH_IDS:
        if "order" not in spec:
            _o = synth_order_for(topo.id, request)
            if _o:
                spec["order"] = _o
        if "kind" not in spec:
            _k = parse_kind(request)
            if _k:
                spec["kind"] = _k
        if "ripple_db" not in spec:
            _rp = parse_ripple_db(request)
            if _rp is not None:
                spec["ripple_db"] = _rp

    # 用户确实没给指标时，给一个有意义的默认值，避免空转
    if not spec:
        if topo.id == "rlc_bandpass":
            spec = {"f0": 100e3}
        elif topo.id == "divider":
            spec = {"vout": 2.5}
            vin = vin or 5.0
        elif topo.id.startswith("opamp") or topo.id == "difference_amp":
            spec = {"gain_lin": 10.0}
        elif topo.id.startswith("sallen") or topo.id == "filter_lowpass_synth":
            spec = {"fc": 1e3}
        else:
            spec = {"fc": 1e3}
    sess.spec = spec

    # ---- 阶段 2：解析初值 ----
    emit("design")
    design_spec = dict(spec)
    if vin:
        design_spec["Vin"] = float(vin)
    if topo.id == "divider":
        if not vin:
            # 大模型只回了 vout、没回输入电压时，绝不能默默按 5V 设计：
            # 用户明明说「12V 分压到 3.3V」，按 5V 算出的电阻比会给出 7.9V（实测踩到）。
            # 从原文里把电压抽出来，取最大的那个当输入。
            try:
                from . import verify as _VF
                _vs = _VF.volts(request)
                if _vs:
                    vin = max(_vs)
                    sess.caveat = (sess.caveat + f"；输入电压取自原文 {vin:g}V").strip("；")
            except Exception:
                pass
        if "Vin" not in design_spec:
            design_spec["Vin"] = float(vin) if vin else 5.0
        if not vin:
            design_spec["Vin"] = 5.0
            sess.caveat = (sess.caveat + "；未识别到输入电压，按 5V 处理").strip("；")
    if topo.id == "rlc_bandpass" and "f0" not in design_spec:
        design_spec["f0"] = 100e3
    if topo.id.startswith("sallen") and "fc" not in design_spec:
        design_spec["fc"] = 1e3
    if topo.id in ("rc_lowpass", "rc_highpass") and "fc" not in design_spec:
        design_spec["fc"] = 1e3
    # 滤波器综合的默认设计选择：用户没说就取最常见的，且不写进判定表
    if topo.id == "filter_lowpass_synth":
        design_spec.setdefault("fc", 1e3)
        design_spec.setdefault("order", 2)
        design_spec.setdefault("kind", "butterworth")
        design_spec.setdefault("ripple_db", 0.5)

    # 综合拓扑：design() 之前先做物理预判。
    # 否则「四阶带通 Q=1.25」会走到 design() 抛异常，报告头条变成
    # 「无法由目标指标推出初始参数」——用户看不出这是物理限制还是程序 bug。
    if topo.id in _SYNTH_IDS:
        try:
            from . import feasibility as _F0
            _q0 = design_spec.get("q")
            if _q0 is None and design_spec.get("bw"):
                _f0v = design_spec.get("f0") or design_spec.get("fc")
                if _f0v:
                    _q0 = float(_f0v) / float(design_spec["bw"])
            _v0 = _F0.evaluate(
                topo.id, dict(design_spec),
                order=int(design_spec.get("order") or 2), q=_q0)
            if getattr(_v0, "hard", None):
                sess.feasibility = _v0
                _i = _v0.issues[0]
                sess.error = f"{_i.title}。{_i.evidence}建议：{_i.suggestion}"
                return sess
        except Exception:
            pass

    try:
        base = topo.design(design_spec)
    except Exception as e:
        # 兜底：design 自己也会拒（例如 Q 超上限），把它的话原样带出来
        sess.error = f"做不到这个指标：{e}"
        return sess

    # 分压需要把 Vin 带进参数
    if topo.id == "divider":
        base["Vin"] = float(design_spec.get("Vin", 5.0))

    # ---- 阶段 2.5：物理可行性 + 语义对账（独立于解析逻辑的闸门）----
    try:
        from . import feasibility as _F
        from . import understand as _U
        from . import verify as _VF

        _stop = _U.detect_stopband(request)
        _q = _U.detect_q(request) if _U.detect_q(request) is not None else spec.get("q")
        _order = max(_U.detect_order(request),
                     2 if topo.id.startswith("sallen") else 1)
        _gain = spec.get("gain_lin")
        if _gain is None and spec.get("gain_db") is not None:
            _gain = 10 ** (spec["gain_db"] / 20.0)
        sess.feasibility = _F.evaluate(
            topo.id, {**spec, **({"Vin": float(vin)} if vin else {})},
            order=_order, q=_q, stopband=_stop,
        )
        # 「升压 / boost」：本项目没有开关电源拓扑，必须当场说清，不能拿分压硬算
        if re.search(r"升压|boost|提高电压|升到\s*\d|升到\s*[一二三四五六七八九十]", request,  re.I):
            sess.feasibility.add(_F.Issue(
                code="no_boost",
                title="本工具没有升压（Boost）拓扑",
                evidence="现有拓扑全部是无源衰减或有源线性电路，输出电压不会高于输入（线性区）。"
                         "把电压升上去必须用开关电源（Boost/Buck-Boost）或电荷泵。",
                suggestion="改用 Boost 变换器方案；若只是需要更高的摆幅，可用变压器或运放+高压供电。",
            ))
        sess.conflicts = _VF.verify(
            request, topo.id, {**spec, **({"__Vin": float(vin)} if vin else {})}
        )
    except Exception as _e:  # 闸门本身不许把主流程搞挂，但也不许静默吞错
        import sys as _sys
        print(f"[gate] 可行性/对账闸门异常（已跳过）：{type(_e).__name__}: {_e}", file=_sys.stderr)

    if sess.blocked:
        _why = "；".join(i.title for i in sess.feasibility.hard)
        sess.caveat = (sess.caveat + "；物理不可行：" + _why).strip("；")
    if sess.conflicts:
        _why = "；".join(c.message for c in sess.conflicts)
        sess.caveat = (sess.caveat + "；需求与设计不一致：" + _why).strip("；")

    # ---- 阶段 3：候选搜索 + 仿真 ----
    cands = _candidates(topo, base, budget=budget)
    best: T.Design | None = None
    best_cost = (10**6, float("inf"))
    TIME_BUDGET_MS = 8000.0
    failures = 0

    def _try_build(params: dict[str, float]):
        """worker：只捕 SimError（与串行版一致，其它异常照常向上传播）。"""
        try:
            return topo.build(params)
        except sim.SimError:
            return None

    # 仿真 = ngspice 子进程（build → sim.run，独立临时目录，无共享状态），
    # 线程池只负责等待，GIL 不构成瓶颈。按批并行、按序判定：
    # 「最优 = 第一个正中目标的候选」这类提前收工语义保持不变，
    # 只是每批最多多跑 workers-1 个候选。
    workers = sim.sim_workers()
    pool = None
    if workers > 1 and len(cands) > 1:
        from concurrent.futures import ThreadPoolExecutor
        pool = ThreadPoolExecutor(max_workers=workers)
    wall0 = time.perf_counter()
    try:
        for start in range(0, len(cands), workers):
            chunk = cands[start:start + workers]
            if pool:
                built = list(pool.map(_try_build, chunk))
            else:
                built = [_try_build(c) for c in chunk]
            hit_center = False
            for j, d in enumerate(built):
                i = start + j
                if d is None:
                    failures += 1
                    continue
                d.iteration = i + 1
                sess.tries.append(d)
                sess.total_sims += 1
                sess.total_ms += d.elapsed_ms
                rows = check(spec, d.metrics, topo.spec_overrides)
                cc = cost(rows)
                if cc < best_cost:
                    best_cost, best = cc, d
                    sess.rows = rows
                emit("simulate", done=i + 1, total=len(cands), cost=cc)
                # 只有「全部合格且几乎正压在目标中心」才提前收工；否则继续遍历，挑最居中的那个。
                # 时间预算对达标与否**都**生效：不达标时预算照样停——继续跑也只是烧时间，
                # 拿不到更好的结果（曾经写在 cc[0]==0 里，不达标时 40 候选全跑，
                # 差分放大 40×3=120 次串行仿真能拖到十几秒）。
                if cc[0] == 0 and cc[1] < 1e-3:
                    hit_center = True
            # 预算按**墙钟**判：并行下 total_ms 是累计 CPU 时间，会低估用户等待时长。
            if hit_center or (time.perf_counter() - wall0) * 1000.0 > TIME_BUDGET_MS:
                break
    finally:
        if pool:
            pool.shutdown(wait=True)

    if best is None:
        sess.error = f"全部 {len(cands)} 个候选均仿真失败"
        return sess
    sess.best = best

    if failures:
        sess.caveat = (sess.caveat + f"（{failures} 个候选参数组合不收敛，已跳过）").strip()

    # ---- 阶段 4：容差分析（蒙特卡洛）----
    emit("tolerance")
    try:
        # 容差可被规格覆盖（0.1% 精密电阻 vs 1% 金属膜，成品率能差 40 个点）。
        # 优先用用户原话里的线索，其次看 spec 里的 tol_* / precision 键。
        tol_override = MC.tol_from_text(request)
        tol_override.update(MC.tol_from_spec(spec))
        sess.mc = MC.monte_carlo(
            topo, best.params, spec, runs=20,
            preset=None if tol_override else "standard",
            tol_overrides=tol_override or None,
        )
    except Exception:
        sess.mc = None

    # ---- 阶段 5：LLM 评审 / 规则评审 ----
    emit("review")
    if use_llm and client.available():
        payload = {
            "需求原文": request,
            "拓扑": topo.name,
            # spec 里可能带非指标的设计选择（阶数/类型/波纹），词表里没有它们，别炸
            "设计规格": {(T.METRICS[k].label if k in T.METRICS else k): f"{v}"
                       for k, v in spec.items()},
            "实际元件": {k: v for k, v in best.human_params(topo)},
            # extract() 会额外返回**诊断键**（如 slope_db_dec / f_low），
            # 它们不在 METRICS 词表里。这里必须和上面"设计规格"一样做保护，
            # 否则一加诊断量就 KeyError（实测：带通加了 f_low/f_high 直接崩）。
            "仿真指标": {
                (T.METRICS[k].label if k in T.METRICS else k):
                    (T.fmt_value(v, T.METRICS[k].unit) if k in T.METRICS else f"{v}")
                for k, v in best.metrics.items()
            },
            "是否达标": sess.passed,
            "未达标项": [
                f"{r.label}: 目标 {T.fmt_value(r.target, r.unit)} 实测 {T.fmt_value(r.actual, r.unit)}"
                for r in sess.rows
                if not r.ok
            ],
            "尝试次数": sess.total_sims,
        }
        try:
            sess.review = L.review(client, payload)
        except L.LLMError as e:
            sess.review = f"（评审生成失败：{e}）"
    else:
        sess.review = _rule_review(sess, topo)

    emit("done")
    return sess


def _rule_review(s: Session, topo: T.Topology) -> str:
    """无大模型时的确定性评审。宁可模板化，也不要空白。"""
    assert s.best is not None
    parts: list[str] = []
    fails = [r for r in s.rows if not r.ok]

    if not fails:
        parts.append(
            f"设计全部指标达标：在 {s.total_sims} 组候选参数中筛出最优解，"
            f"仿真验证与目标偏差均在容差内。"
        )
    else:
        desc = "；".join(
            f"{r.label} 目标 {T.fmt_value(r.target, r.unit)}、实测 {T.fmt_value(r.actual, r.unit)}"
            for r in fails
        )
        # ⚑ 不要把「元件被量程钳住」说成「纯 E 系列无解」。
        # 实测事故：RLC 带通 1kHz 因为电容写死 10nF、电感被压到量程上限，
        # f0 报成 1591.55Hz（+59%），报告却断言「已遍历 9 组…纯 E 系列无解，
        # 需要 E96/E192」——方向完全错了（真正缺的是大一个十倍频的电容），
        # 而实测纯 E12/E24 穷举有 15 组达标。用户会照这个建议去买精密电阻，钱花了问题还在。
        _clamped = [w for w in (getattr(s.best, "warnings", None) or []) if "超出量程" in w]
        if _clamped:
            parts.append(
                f"有 {len(fails)} 项未达标（{desc}）。原因是**需求超出了本拓扑的元件量程**："
                + "；".join(_clamped)
                + "。这不是「标准件凑不出来」，而是该结构本身就够不到——"
                "需要换拓扑、或改用更大/更小的电感电容（例如 RLC 带通在低频端需要更大的 C）。"
            )
        else:
            parts.append(
                f"有 {len(fails)} 项未达标（{desc}）。已遍历 {s.total_sims} 组标准件组合，"
                f"说明落在纯 E 系列可选值上无解——实际工程中需要改用更精密的系列（E96/E192）、"
                f"并联组合，或换拓扑。"
            )

    comps = "、".join(f"{k} {v}" for k, v in s.best.human_params(topo) if "GBW" not in k and "开环" not in k)
    parts.append(f"当前方案：{comps}。元件已吸附到可采购的标准值，因此实测值与理论值存在偏差，这是正常的。")

    if s.mc and not math.isnan(s.mc.yield_pct):
        y = s.mc.yield_pct
        # 只有电路里真有运放参数时才提 GBW/A0（纯 RC 电路报告里印「运放 GBW ±20%」是误导）
        _pk = set((getattr(s.best, "params", None) or {}).keys())
        _sect = {k for k in ("R", "C", "L", "GBW", "A0") if k in _pk}
        base = (f"容差分析（{s.mc.runs} 次蒙特卡洛，"
                f"{s.mc.tol_summary(_sect or None)}）：成品率 {y:.0f}%。")
        if y >= 95:
            parts.append(base + "批次一致性良好，按本工具的仿真口径可以落地"
                         "（该结论只覆盖元件容差，不含寄生/温度/运放真实极限）。")
        elif y >= 70:
            parts.append(base + "有余量不足的风险，量产前建议收紧关键元件容差或放宽规格。")
        else:
            parts.append(
                base + "成品率偏低，说明设计点过于贴近规格边界——"
            "建议把标称值往容差中心拉，或换用 0.1% 电阻/1% 电容。"
            )
    return "\n\n".join(parts)


def diagnose() -> dict:
    """环境自检。"""
    cfg = L.load_config()
    return {
        "ngspice": sim.version(),
        "topologies": len(T.REGISTRY),
        "llm_configured": bool(cfg["key"]),
        "llm_base": cfg["base"],
        "llm_model": cfg["model"],
    }
