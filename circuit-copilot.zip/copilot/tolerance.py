"""容差分析（蒙特卡洛）。

为什么必须有这个：
    教科书上的设计都是「理想元件」。真实现场是电阻 ±1%、电容 ±5%（薄膜）
    或 ±10%（陶瓷）、电感 ±10%。一个在标称值上完美达标的设计，
    可能有一半的产品落在规格外。

    一次仿真 60ms，跑 20 次只要 1.2 秒——没有理由不算。

输出：每个指标的分布（min/均值/max/p5/p95）+ 成品率（达标概率）。

容差是「可被规格覆盖」的：
    同一份拓扑，用 0.1% 精密电阻和用 1% 金属膜电阻，成品率能差出 40 个点。
    所以 monte_carlo() 支持三层叠加——预设（standard/precision）→ 显式 tol
    → 按元件名/种类的逐项覆盖；agent 还会从用户原话（「0.1% 电阻」）里提取。
"""

from __future__ import annotations

import math
import random
import re
from dataclasses import dataclass, field

from . import sim
from . import topologies as T
from .judge import check

# 默认容差（相对误差，1σ）：金属膜电阻 1%、薄膜电容 5%、电感 10%
DEFAULT_TOL = {
    "R": 0.01,   # 金属膜 1%
    "C": 0.05,   # 薄膜 5%
    "L": 0.10,   # 电感 10%
    "GBW": 0.20,  # 运放 GBW 批次离散大
    "A0": 0.50,
    # ⚑ Vin 原来写 0.0 —— 等于假设电源电压绝对理想。分压器的 vout 正比于 Vin，
    # 把 Vin 当恒定值会让成品率系统性乐观：实测 12V→3.3V 分压器
    # 98.3%（Vin 理想）→ 53.3%（Vin ±2%）→ 25.0%（±5%）。
    # 报告却写「批次一致性良好可落地」。取 1% 是常见稳压/适配器档次，
    # 并且会在 tol_summary 里**明确列出**（不再静默假设）。
    "Vin": 0.01,
}

# 采购档次预设：报告里说什么档次，就按什么档次算
TOL_PRESETS: dict[str, dict[str, float]] = {
    "standard": {"R": 0.01, "C": 0.05, "L": 0.10, "GBW": 0.20},
    "precision": {"R": 0.001, "C": 0.01, "L": 0.02, "GBW": 0.20},  # 0.1% 电阻 / 1% 电容
    "tight": {"R": 0.0005, "C": 0.005, "L": 0.01, "GBW": 0.10},
}

_KIND_LABEL = {
    "R": "电阻", "C": "电容", "L": "电感",
    "GBW": "运放 GBW", "A0": "开环增益", "Vin": "输入电压",
}

_UNIT_MUL = {"%": 0.01, "‰": 0.001}


def _as_fraction(v) -> float | None:
    """把 0.001 / 0.1 / "0.1%" / "1%" 统一成相对容差（0.001 / 0.001 / 0.001 / 0.01）。

    数值约定：<1 当作比例，1~100 当作百分数（人人都写「1% 电阻」而不是「0.01」）。
    """
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        f = float(v)
        if not math.isfinite(f) or f < 0:
            return None
        if f < 1.0:
            return f
        return f / 100.0 if f <= 100.0 else None
    m = re.fullmatch(r"\s*([\d.]+)\s*([%‰]?)\s*", str(v))
    if not m:
        return None
    num = float(m.group(1))
    return num * _UNIT_MUL.get(m.group(2), 0.01 if num > 1 else 1.0)


def resolve_tol(
    *,
    preset: str | None = None,
    tol: dict[str, float] | None = None,
    overrides: dict[str, float] | None = None,
) -> dict[str, float]:
    """三层叠加出最终容差表：默认 → 预设 → 显式 → 逐项覆盖。"""
    out = dict(DEFAULT_TOL)
    if preset:
        out.update(TOL_PRESETS.get(str(preset).lower(), {}))
    if tol:
        # 曾用 float(v) 取值，导致 "0.1%" 这种合法写法直接 ValueError（B5）
        for k, v in tol.items():
            f = _as_fraction(v)
            if f is not None:
                out[str(k)] = f
    if overrides:
        for k, v in overrides.items():
            f = _as_fraction(v)
            if f is not None:
                out[str(k)] = f
    return out


def tol_from_spec(spec: dict | None) -> dict[str, float]:
    """从规格里提取容差覆盖项。

    支持三种写法（键名大小写不敏感）：
        tol_R: 0.001          # 按种类
        tol_R1: 0.001         # 按具体元件名
        precision: "precision" | 0.001   # 档次预设
    """
    out: dict[str, float] = {}
    for k, v in (spec or {}).items():
        key = str(k).strip()
        low = key.lower()
        if low.startswith("tol_") and len(key) > 4:
            f = _as_fraction(v)
            if f is not None:
                out[key[4:]] = f
        elif low in ("precision", "grade", "tol_preset"):
            if isinstance(v, str) and v.strip().lower() in TOL_PRESETS:
                out.update(TOL_PRESETS[v.strip().lower()])
            else:
                f = _as_fraction(v)
                if f is not None:
                    out.update({"R": f, "C": min(f * 10, 0.2)})
    return out


def tol_from_text(text: str) -> dict[str, float]:
    """从用户原话里捞容差线索：「0.1% 电阻」「精密电阻」「5% 陶瓷电容」。

    只在用户明说时才覆盖——没提到就沿用默认档，绝不擅自猜测。
    """
    if not text:
        return {}
    out: dict[str, float] = {}
    # ⚑ 每个百分数**只能分给一个元件**。早先按元件分别匹配，于是
    # 「电阻 1% 电容 5%」里的 1% 同时被认成电容的容差（「1% 电容」匹配上了），
    # 结果 `tol_from_text` 返回 {'R':0.01,'C':0.01} —— C=5% 的真实成品率 80%
    # 被报成 100%（虚高 20~25 点），而且这是**主路径**，每条请求都走。
    # 做法：把「元件词」和「百分数」都定位，按中文习惯「词在数字前」就近配对，
    # 一个数字用掉一次，配过的元件不重复配。
    words = [("R", "电阻"), ("C", "电容"), ("L", "电感")]
    used_pct: set[int] = set()
    used_kind: set[str] = set()
    pcts = [(m.start(), m.group(1)) for m in re.finditer(r"([\d.]+)\s*[%％]", text)]
    for kind, word in words:
        for wm in re.finditer(word, text):
            # 先看这个词**前面**最近的一个百分数（「电阻 1%」）
            best = None
            for pos, num in pcts:
                if pos in used_pct or kind in used_kind:
                    continue
                if 0 <= wm.start() - pos <= 14:      # 词在数字后（常见写法）
                    if best is None or pos > best[0]:
                        best = (pos, num)
            if best is None:
                # 再看词**后面**最近的一个百分数（「5% 陶瓷电容」）
                for pos, num in pcts:
                    if pos in used_pct or kind in used_kind:
                        continue
                    if 0 <= pos - wm.end() <= 14:
                        if best is None or pos < best[0]:
                            best = (pos, num)
            if best is not None:
                f = _as_fraction(best[1] + "%")
                if f is not None:
                    out.setdefault(kind, f)
                    used_pct.add(best[0])
                    used_kind.add(kind)
    if "精密电阻" in text or "0.1%电阻" in text.replace(" ", ""):
        out.setdefault("R", 0.001)
    if "匹配电阻" in text or "电阻阵列" in text:
        out.setdefault("R", 0.001)
    return out


@dataclass
class MetricDist:
    """单个指标在蒙特卡洛样本里的分布。样本少/含 NaN 时所有统计量都不会炸。"""

    key: str
    values: list[float] = field(default_factory=list)

    @property
    def label(self) -> str:
        return T.METRICS[self.key].label

    @property
    def unit(self) -> str:
        return T.METRICS[self.key].unit

    @property
    def n(self) -> int:
        """有效样本数（剔除 NaN/Inf）。"""
        return len(self._valid())

    def _valid(self) -> list[float]:
        return [float(v) for v in self.values if isinstance(v, (int, float)) and math.isfinite(v)]

    def _pct(self, p: float) -> float:
        vs = sorted(self._valid())
        if not vs:
            return float("nan")
        if len(vs) == 1:
            return vs[0]
        k = (len(vs) - 1) * min(max(p, 0.0), 1.0)
        lo, hi = int(math.floor(k)), int(math.ceil(k))
        return vs[lo] + (vs[hi] - vs[lo]) * (k - lo)

    @property
    def lo(self) -> float: return self._pct(0.0)
    @property
    def hi(self) -> float: return self._pct(1.0)
    @property
    def p5(self) -> float: return self._pct(0.05)
    @property
    def p50(self) -> float: return self._pct(0.50)
    @property
    def p95(self) -> float: return self._pct(0.95)
    @property
    def mean(self) -> float:
        vs = self._valid()
        return sum(vs) / len(vs) if vs else float("nan")
    @property
    def sigma(self) -> float:
        vs = self._valid()
        if len(vs) < 2:
            return float("nan")
        m = sum(vs) / len(vs)
        return math.sqrt(sum((v - m) ** 2 for v in vs) / (len(vs) - 1))

    @property
    def spread_pct(self) -> float:
        """5%~95% 分布宽度相对均值的百分比——判断「飘得厉害不厉害」最直观。"""
        m = self.mean
        if not math.isfinite(m) or m == 0:
            return float("nan")
        return 100.0 * (self.p95 - self.p5) / abs(m)


@dataclass
class MCResult:
    runs: int = 0
    ok_runs: int = 0
    dists: dict[str, MetricDist] = field(default_factory=dict)
    failures: int = 0
    tol: dict[str, float] = field(default_factory=dict)
    fail_by_metric: dict[str, int] = field(default_factory=dict)  # 哪个指标把成品率拉下来了
    preset: str = ""

    @property
    def yield_pct(self) -> float:
        """成品率。分母 = 成功 + 未收敛：扰动落到不收敛区的样本物理上
        大概率超标，把它们剔出分母会系统性高估成品率。"""
        denom = self.runs + self.failures
        return 100.0 * self.ok_runs / denom if denom else float("nan")

    def tol_summary(self, sections: set[str] | None = None) -> str:
        """「电阻 ±1% · 电容 ±5%」——报告与评审共用，避免各写一套。

        `sections` 为电路里真实出现的器件族（如 {"R","C"}）：没装的器件就不该印进
        容差表（早先一个纯 RC 电路的报告也写「运放 GBW ±20% · 开环增益 ±50%」）。
        """
        parts = []
        for k, v in self.tol.items():
            if sections is not None and k not in sections and k != "Vin":
                continue
            if v and v > 0:
                s = f"{v * 100:.4g}%".replace(".0%", "%")
                parts.append(f"{_KIND_LABEL.get(k, k)} ±{s}")
        return " · ".join(parts) if parts else "按标称值（无扰动）"

    def weakest(self) -> tuple[str, int] | None:
        """最拖后腿的指标 (key, 失败次数)。"""
        if not self.fail_by_metric:
            return None
        k = max(self.fail_by_metric, key=lambda x: self.fail_by_metric[x])
        return (k, self.fail_by_metric[k]) if self.fail_by_metric[k] > 0 else None

    def verdict(self) -> str:
        """一句人话结论。阈值是工程经验，不是随口说的。"""
        if not self.runs:
            return "所有扰动样本都仿真失败，无法给出容差结论（检查是否落在收敛边界上）。"
        y = self.yield_pct
        if math.isnan(y):
            return "容差样本不足，无法给出结论。"
        weak = self.weakest()
        weak_txt = ""
        total = self.runs + self.failures  # 显示口径与 yield_pct 分母一致
        if weak:
            k, cnt = weak
            label = T.METRICS[k].label if k in T.METRICS else k
            weak_txt = f"短板是「{label}」（{cnt}/{total} 次落在规格外）。"
        if y >= 95:
            return (f"成品率 {y:.0f}%（{self.ok_runs}/{total}）≥95%，批次一致性良好，"
                    f"按本工具的仿真口径可以落地。{weak_txt}"
                    f"注意：这是**纯元件容差**的结论，不含寄生、温度、以及运放真实极限"
                    f"（详见报告「落地前必须确认」）。")
        if y >= 70:
            return (
                f"成品率 {y:.0f}%（{self.ok_runs}/{total}）落在 70~95%，量产前需收紧关键元件容差"
                f"或给规格留裕量。{weak_txt}"
            )
        return (
            f"成品率只有 {y:.0f}%（{self.ok_runs}/{total}）<70%，说明设计点贴规格边界——"
            f"标称值再准也救不了，应把设计中心往容差分布中心拉，或改用更紧的元件。{weak_txt}"
        )


def _param_kind(topo: T.Topology, name: str) -> str:
    for p in topo.params:
        if p.name == name:
            return p.kind
    return name


def monte_carlo(
    topo: T.Topology,
    params: dict[str, float],
    spec: dict[str, float],
    *,
    runs: int = 20,
    tol: dict[str, float] | None = None,
    tol_overrides: dict[str, float] | None = None,
    preset: str | None = None,
    seed: int = 20260101,
) -> MCResult:
    """对元件值做高斯扰动，统计指标分布与成品率。

    tol           显式容差表（叠加在默认/预设之上，可只给关心的种类）
    tol_overrides 逐项覆盖，键可以是元件种类（R/C/L/GBW）或具体参数名（R1/C2）
    preset        "standard" / "precision" / "tight"
    """
    # tol= 是**编程接口**，一律按原始相对比例解释（0.01 = 1%，3.0 = 300%）。
    # 曾经走 resolve_tol 的百分号约定，导致 tol={"C": 3.0} 被理解成 3% 而不是 300%，
    # 「元件离谱时成品率不该还高」这条断言被喂了一个温和扰动而假通过。
    # 面向用户的百分号写法请走 tol_overrides= / tol_from_text()。
    eff = dict(DEFAULT_TOL)
    if preset:
        eff.update(TOL_PRESETS.get(str(preset).lower(), {}))
    if tol:
        eff.update({str(k): float(v) for k, v in tol.items()})
    if tol_overrides:
        for k, v in tol_overrides.items():
            f = _as_fraction(v)
            if f is not None:
                eff[str(k)] = f
    rng = random.Random(seed)
    res = MCResult(runs=0, tol=eff, preset=(preset or ""))

    kinds = {n: _param_kind(topo, n) for n in params}
    # 规格里的指标 + 拓扑声明的全部指标都要统计：
    # 报告里除了「达标没有」，更该看出「哪个指标自身就飘得厉害」。
    tracked: list[str] = []
    for k in list(spec.keys()) + list(topo.metrics_keys):
        if k in T.METRICS and k not in tracked:
            tracked.append(k)

    # 扰动样本全部先在主线程生成：rng 的调用顺序与串行版逐位一致，
    # 同一个 seed 给出完全相同的样本表（可复现性不因并行而破坏）。
    samples: list[dict[str, float]] = []
    for _ in range(max(int(runs), 0)):
        perturbed = {}
        for name, v in params.items():
            t = eff.get(name, eff.get(kinds[name], 0.0))
            if not t or t <= 0:
                perturbed[name] = v
            else:
                perturbed[name] = v * (1.0 + rng.gauss(0.0, t))
        samples.append(perturbed)

    # 仿真是 ngspice 子进程（build → sim.run，各自独立临时目录、无共享状态），
    # 线程池并行等待即可，GIL 不构成瓶颈。
    def _one(p: dict[str, float]):
        try:
            return topo.build(p)
        except (sim.SimError, KeyError, ValueError, ZeroDivisionError):
            return None
        except Exception:  # 数值极端时拓扑内部可能抛别的异常，别让它毁了整次分析
            return None

    workers = sim.sim_workers()
    if workers > 1 and len(samples) > 1:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=workers) as pool:
            designs = list(pool.map(_one, samples))
    else:
        designs = [_one(p) for p in samples]

    # 聚合按样本顺序做，dists.values 的顺序与串行版一致。
    for d in designs:
        if d is None:
            res.failures += 1
            continue
        res.runs += 1
        rows = check(spec, d.metrics, topo.spec_overrides)
        if all(r.ok for r in rows):
            res.ok_runs += 1
        else:
            for r in rows:
                if not r.ok:
                    res.fail_by_metric[r.key] = res.fail_by_metric.get(r.key, 0) + 1
        for k in tracked:
            m = d.metrics.get(k)
            if m is None:
                continue
            res.dists.setdefault(k, MetricDist(k)).values.append(float(m))

    return res
