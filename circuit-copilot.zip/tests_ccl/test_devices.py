"""器件库（M1 无源件/源 + M2 半导体/激励）：**用解析式核对物理量**。

这一层的规矩：每条用例都必须把一个**解析式**或**物理区间**算出来与实测比，
不允许出现「跑通了就算过」。因为 ngspice 对一份语法合法但参数错的网表，
照样会给你一个看起来合理的数字 —— 只有解析式能抓出「1M 当毫」「端子接反」
「模型卡写错」这一类静默错误。

具体核对（对应 CONTRACT 的 M1/M2 验收数字）：
  RC 低通 fc = 1/(2πRC)               ← 误差 < 1%
  电阻分压 = Vin·R2/(R1+R2)           ← 误差 < 0.1%
  同相/反相增益                        ← 10 ±1%
  1N4148 正向压降                      ← 0.5~0.8 V，且与 Shockley+Rs 解析解 <1%
  2N3904 Vbe / 放大区 / β              ← 0.55~0.78 V、Vce 在放大区、β 100~600
  M2N7002 饱和/线性电流                ← Level-1 公式，误差 <15%
  PULSE+RC 在 t=τ                      ← 63.2%（±2%）
  LC 谐振 f0 = 1/(2π√(LC))             ← 误差 <1%
"""

import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import (  # noqa: E402
    case,
    close,
    close_abs,
    between_ratio,
    in_range,
    is_true,
    raises,
)

from ccl.core import GND, Circuit  # noqa: E402
from ccl.devices import MODEL_CARDS  # noqa: E402
from ccl.errors import CCLConfigError  # noqa: E402

TAU = 2 * math.pi
# ngspice 默认温度 27°C 的热电压 kT/q（Shockley 解析核对用）
VT_27C = 1.380649e-23 * 300.15 / 1.602176634e-19


# --------------------------------------------------------------------------
# 小工具
# --------------------------------------------------------------------------
# 模型卡里的数写成 SPICE 记数法（2.52n / 6.734f / 80m），解析时必须带后缀换算，
# 否则 Is=6.734f 会被读成 6.734 —— 后面所有 Shockley 反推都会离谱（踩过）。
_SI = {"f": 1e-15, "p": 1e-12, "n": 1e-9, "u": 1e-6, "µ": 1e-6,
       "m": 1e-3, "k": 1e3, "K": 1e3, "meg": 1e6, "MEG": 1e6, "M": 1e6,
       "g": 1e9, "G": 1e9, "t": 1e12}


def _spice_num(tok: str) -> float:
    """把 "2.52n" / ".568" / "1e-14" 这类 SPICE 数换算成 float。"""
    import re

    m = re.fullmatch(r"([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)(meg|MEG|[fpnumkKMGT])?", tok.strip())
    if not m:
        raise H.Fail(f"无法解析模型卡里的数值 {tok!r}")
    return float(m.group(1)) * _SI.get(m.group(2) or "", 1.0)


def _card_param(model: str, key: str) -> float:
    """从内置模型卡里取一个参数（如 M2N7002 的 Kp / Vto）。

    刻意从 MODEL_CARDS 读、而不是在测试里硬编码：模型卡要是被人改了，
    解析式必须跟着变，测试才会红 —— 否则测试会和错的模型卡一起"通过"。
    """
    import re

    card = MODEL_CARDS.get(model)
    if not card:
        raise H.Fail(f"MODEL_CARDS 里没有 {model!r}，无法做解析式核对")
    m = re.search(r"\b" + re.escape(key) + r"\s*=\s*([-+0-9.eE]+(?:meg|MEG|[fpnumkKMGT])?)", card[1])
    if not m:
        raise H.Fail(f"模型卡 {model} 里没有参数 {key}")
    return _spice_num(m.group(1))


def _op(c: Circuit):
    H.need_ngspice()
    return c.op()


def _v(sol, node: str) -> float:
    """读工作点电压（.op 只有单点，x=0）。"""
    return float(sol.value_at(node, 0.0))


def _shockley_vd(i_a: float, *, n: float, Is: float, Rs: float) -> float:
    """二极管解析正向压降：Vd = n·Vt·ln(I/Is) + I·Rs。"""
    return n * VT_27C * math.log(i_a / Is) + i_a * Rs


def _solve_diode(v_in: float, r_series: float, *, n: float, Is: float, Rs: float) -> tuple:
    """解 I = (Vin − Vd(I))/Rs 的定点迭代，返回 (Vd, I)。"""
    i = (v_in - 0.65) / r_series
    for _ in range(200):
        vd = _shockley_vd(i, n=n, Is=Is, Rs=Rs)
        i = (v_in - vd) / r_series
    return _shockley_vd(i, n=n, Is=Is, Rs=Rs), i


# ==========================================================================
# 无源件与源（M1）
# ==========================================================================
@case(group="M1 无源件")
def test_rc_lowpass_fc_analytic():
    """★M1 验收 1：RC 低通 −3dB 频率必须等于 1/(2πRC)，误差 <1%。

    这是全库最基础的一条物理规律。它同时守住两件事：
      - 数值格式化没把电容值写错量级（100nF 写成 1e-7 还是 1e-9 差 100 倍）
      - Solution.f3db 的插值算法是对的（不插值会差到 0.3%）
    """
    for r, c in ((1.6e3, 100e-9), (1e3, 159.154943091895e-9), (10e3, 10e-9),
                 (100.0, 1e-6), (1e3, 1e-9), (1e6, 1e-12)):
        ckt = Circuit(f"rc_{r:g}")
        ckt.V("in", GND, ac=1)
        ckt.R("in", "out", r)
        ckt.C("out", GND, c)
        H.need_ngspice()
        sol = ckt.ac(c / 1e3, max(1.0, 1.0 / (TAU * r * c) * 100), 200)
        f3 = sol.f3db("out")
        want = 1.0 / (TAU * r * c)
        close(f3, want, 0.01, what=f"RC={r:g}Ω/{c:g}F 的 −3dB 频率")


@case(group="M1 无源件")
def test_resistor_divider_analytic():
    """电阻分压 Vout = Vin·R2/(R1+R2)：核对无源网络与源的 DC 工作点。

    防的是：源的 DC 值没进网表（V1 写成 AC 1 却漏了 DC），或电阻值被写错量级。
    """
    for r1, r2, vin in ((1e3, 1e3, 10.0), (9e3, 1e3, 5.0), (1e3, 9e3, 5.0), (470.0, 4700.0, 12.0)):
        ckt = Circuit("div")
        ckt.V("in", GND, dc=vin)
        ckt.R("in", "out", r1)
        ckt.R("out", GND, r2)
        v = _v(_op(ckt), "out")
        close(v, vin * r2 / (r1 + r2), 1e-3, what=f"分压 {r1:g}/{r2:g} @ {vin}V")


@case(group="M1 源与运放")
def test_noninv_amp_gain_and_bandwidth():
    """★M1 验收 2：同相放大增益 10 ±1%，闭环带宽落在 GBW/10 的 0.7~1.1 倍。

    增益核对的是反馈电阻比；带宽核对的是运放宏模型的单极点（A0·fp = GBW）。
    第二条特别防「用理想 VCVS 代替单极点模型」—— 那样带宽会是无穷大，
    历史上因此算出过 CMRR=165dB 这种物理不可能的结论。
    """
    H.need_ngspice()
    c = Circuit("noninv")
    c.V("src", GND, ac=1)
    c.R("sum", GND, 1e3)
    c.R("out", "sum", 9e3)
    c.OpAmp("src", "sum", "out", gbw=1.3e6, a0=1e5)
    sol = c.ac(1, 1e7, 300)
    g = abs(sol.value_at("out", 1.0))
    close(g, 10.0, 0.01, what="同相放大增益 (1 + 9k/1k)")
    bw = sol.f3db("out")
    between_ratio(bw, 1.3e6 / 10.0, 0.7, 1.1, what="闭环带宽 vs GBW/增益")


@case(group="M1 源与运放")
def test_inv_amp_gain():
    """★M1 验收 3：反相放大 |增益| = R2/R1 = 10 ±1%，且相位反相（负号）。

    只核对幅度是不够的：反相放大把两个输入端接反了照样给出 10 倍，
    所以顺带核对低频相位 ≈ 180°。
    """
    H.need_ngspice()
    c = Circuit("inv")
    c.V("src", GND, ac=1)
    c.R("src", "sum", 1e3)
    c.R("out", "sum", 10e3)
    c.OpAmp(GND, "sum", "out", gbw=1.3e6)
    sol = c.ac(1, 1e5, 200)
    g = abs(sol.value_at("out", 1.0))
    close(g, 10.0, 0.01, what="反相放大 |增益| (10k/1k)")
    ph = sol.phase("out")[0]
    close_abs(ph, 180.0, 2.0, what="反相放大的低频相位（度）")


@case(group="M1 无源件")
def test_inductor_lc_resonance():
    """L 的核对：串联 LC 谐振 f0 = 1/(2π√(LC))，且谐振点 |H|≈1。

    防的是：电感值进了网表但单位错了（1mH 写成 1e-3 vs 1e-9 差 10⁶ 倍的时间常数）。
    """
    H.need_ngspice()
    f0, cval, r = 100e3, 10e-9, 10.0
    L = 1.0 / ((TAU * f0) ** 2 * cval)
    c = Circuit("rlc")
    c.V("src", GND, ac=1)
    c.L("src", "n1", L)
    c.C("n1", "out", cval)
    c.R("out", GND, r)
    sol = c.ac(1e3, 1e7, 800)
    mags, xs = sol.mag("out"), sol.x
    i_peak = mags.index(max(mags))
    close(xs[i_peak], f0, 0.01, what="串联 RLC 的谐振频率")
    close(max(mags), 1.0, 0.02, what="谐振点 |H|（= R/(R+j0) = 1）")


# ==========================================================================
# M2：二极管
# ==========================================================================
@case(group="M2 二极管")
def test_diode_forward_shockley():
    """★1N4148 正向压降：0.5~0.8 V，且与 Shockley+Rs 解析解一致（<1%）。

    解析式：Vd = n·Vt·ln(I/Is) + I·Rs，其中 I = (Vin − Vd)/R。
    这不是"随便断言一个范围"：三个不同工作电流（0.45mA / 4.3mA / 42mA）都要
    同时对上，才能证明模型卡（Is / N / Rs）真的被写进了网表。
    """
    H.need_ngspice()
    n, Is, Rs = _card_param("D1N4148", "N"), _card_param("D1N4148", "Is"), _card_param("D1N4148", "Rs")
    for r_ser, vin in ((1e3, 1.0), (1e3, 5.0), (100.0, 5.0)):
        c = Circuit("d_fwd")
        c.V("in", GND, dc=vin)
        c.R("in", "a", r_ser)
        c.D("a", GND, "D1N4148")
        vd = _v(_op(c), "a")
        i_meas = (vin - vd) / r_ser
        vd_theory, i_theory = _solve_diode(vin, r_ser, n=n, Is=Is, Rs=Rs)
        in_range(vd, 0.50, 0.80, what=f"1N4148 正向压降 @ I={i_meas * 1e3:.3f}mA")
        close(vd, vd_theory, 0.01, what=f"Vd vs Shockley 解析解（Vin={vin}V, R={r_ser:g}Ω）")
        close(i_meas, i_theory, 0.01, what="正向电流 vs 解析解", note="I=(Vin−Vd)/R 自洽")


@case(group="M2 二极管")
def test_diode_reverse_leakage():
    """1N4148 反向：漏电 ≈0（|I| < 10nA），压降≈电源值。

    防的是：端子顺序搞反（阳极/阴极对调），那样"反向"就成了正向，
    会看到毫安级电流而这只靠"跑通了"是看不出来的。
    """
    H.need_ngspice()
    c = Circuit("d_rev")
    c.V("in", GND, dc=-5.0)
    c.R("in", "a", 1e3)
    c.D("a", GND, "D1N4148")
    vd = _v(_op(c), "a")
    i = (-5.0 - vd) / 1e3
    is_true(abs(i) < 1e-8, f"反向漏电应 ≈0（<10nA），实测 {i * 1e9:.3f} nA")
    close_abs(vd, -5.0, 0.01, what="反向时二极管几乎承受全部电压（阳极 ≈ −5V）")


@case(group="M2 二极管")
def test_diode_terminal_order_matters():
    """端子顺序 a(阳)→k(阴) 接反 → 电流几乎为零。

    这是 a/k 顺序的物理证据：接反了电路看着正常、仿真也不报错，
    只是整流方向整个反了。所以必须用"电流接近 0"来钉住顺序。
    """
    H.need_ngspice()
    good = Circuit("good")
    good.V("in", GND, dc=5.0)
    good.R("in", "a", 1e3)
    good.D("a", GND, "D1N4148")          # 正确：a 端接高电位，k 接地
    i_good = (5.0 - _v(_op(good), "a")) / 1e3

    bad = Circuit("bad")
    bad.V("in", GND, dc=5.0)
    bad.R("in", "a", 1e3)
    bad.D(GND, "a", "D1N4148")           # 接反
    i_bad = (5.0 - _v(_op(bad), "a")) / 1e3

    is_true(i_good > 1e-3, f"正向应有 mA 级电流，实测 {i_good * 1e3:.3f} mA")
    is_true(abs(i_bad) < 1e-8, f"接反后电流应 ≈0，实测 {i_bad * 1e9:.3f} nA")


# ==========================================================================
# M2：三极管
# ==========================================================================
@case(group="M2 三极管")
def test_bjt_bias_region():
    """★2N3904 共射偏置：Vbe 0.55~0.78 V、工作在放大区、β 在 100~600。

    三个量一起核对才有意义：
      - Vbe 太低 → 截止；太高 → 说明模型参数离谱
      - Vce 落在 (0.2, Vcc−0.1) → 放大区（饱和时 Vce<0.3、截止时 Vce≈Vcc）
      - β = Ic/Ib 必须在 100~600 量级（模型卡 Bf=416，实测会略低因为高注入）
    顺带用 Shockley 反推 Vbe，确认模型卡（Is / Bf）真被用上了。
    """
    H.need_ngspice()
    c = Circuit("bjt")
    c.V("vcc", GND, dc=5.0)
    c.R("vcc", "b", 100e3)
    c.R("vcc", "c", 100.0)
    c.Q("c", "b", GND, "Q2N3904")
    sol = _op(c)
    vb, vc = _v(sol, "b"), _v(sol, "c")
    ib = (5.0 - vb) / 100e3
    ic = (5.0 - vc) / 100.0
    in_range(vb, 0.55, 0.78, what="2N3904 的 Vbe")
    in_range(vc, 0.2, 4.9, what="2N3904 的 Vce（放大区）")
    beta = ic / ib
    in_range(beta, 100.0, 600.0, what="β = Ic/Ib")
    # Shockley 反推：Vbe ≈ Vt·ln(Ic/Is) + Ib·Rb
    Is = _card_param("Q2N3904", "Is")
    Rb = _card_param("Q2N3904", "Rb")
    vbe_theory = VT_27C * math.log(ic / Is) + ib * Rb
    close_abs(vb, vbe_theory, 0.02, what="Vbe vs Vt·ln(Ic/Is) 反推值")


@case(group="M2 三极管")
def test_bjt_terminal_order_in_netlist():
    """三极管网表必须是 `Q<位号> 集电极 基极 发射极 模型`（c/b/e 顺序）。

    防的是：Q 的端子顺序写错（SPICE 是 C-B-E，很多人以为是 B-C-E）。
    接反会跑出一个"看着正常"的反向放大区，所有数字都不可信。
    """
    c = Circuit("q")
    c.V("vcc", GND, dc=5.0)
    c.R("vcc", "b", 100e3)
    c.R("vcc", "c", 100.0)
    c.Q("c", "b", GND, "Q2N3904")
    net = c.to_spice(".op")
    line = next(ln for ln in net.splitlines() if ln.startswith("Q1 "))
    fields = line.split()
    is_true(fields[1] == "c" and fields[2] == "b" and fields[3] == "0",
            f"Q1 行的节点顺序必须是 c b e(=0)，实测 {fields[1:4]}")
    is_true(fields[4] == "Q2N3904", f"末位应是模型名，实测 {fields[4]!r}")


# ==========================================================================
# M2：MOSFET（Level-1 解析式）
# ==========================================================================
@case(group="M2 MOSFET")
def test_mosfet_saturation_analytic():
    """★M2N7002 饱和电流 = 0.5·Kp·(Vgs−Vto)²·(1+λ·Vds)，误差 <15%。

    这条是把 Level-1（Shichman-Hodges）公式当"标准答案"来核对仿真：
    只要模型卡里 Kp/Vto/Lambda 有一个被改动或没写进网表，这里立刻超差。
    Vds 由电源钳在 5V（> Vov=2.9V）→ 处于饱和区。
    """
    H.need_ngspice()
    Kp = _card_param("M2N7002", "Kp")
    Vto = _card_param("M2N7002", "Vto")
    lam = _card_param("M2N7002", "Lambda")
    for vgs in (5.0, 4.0):
        c = Circuit("mos_sat")
        c.V("vdd", GND, dc=5.0, ref="VDD")
        c.V("vg", GND, dc=vgs, ref="VG")
        c.M("vdd", "vg", GND, GND, "M2N7002")
        sol = _op(c)
        vds = _v(sol, "vdd")
        i_d = abs(float(sol.value_at("i(vdd)", 0.0)))
        vov = vgs - Vto
        is_true(vds > vov, f"Vds={vds:.3f}V 应大于 Vov={vov:.3f}V 才是饱和区")
        theory = 0.5 * Kp * vov ** 2 * (1 + lam * vds)
        close(i_d, theory, 0.15, what=f"M2N7002 饱和电流 @ Vgs={vgs:g}V")


@case(group="M2 MOSFET")
def test_mosfet_linear_analytic():
    """M2N7002 线性区电流 = Kp·[(Vov·Vds) − Vds²/2]·(1+λ·Vds)，误差 <15%。

    和饱和区一起核对才能说明「工作区判据」是对的（Vds<Vov → 线性）。
    这里用电源把 Vds 钳在 0.5V（Vov=2.9V，稳在线性区）。
    """
    H.need_ngspice()
    Kp = _card_param("M2N7002", "Kp")
    Vto = _card_param("M2N7002", "Vto")
    lam = _card_param("M2N7002", "Lambda")
    vds_target, vgs = 0.5, 5.0
    c = Circuit("mos_lin")
    c.V("vdd", GND, dc=vds_target, ref="VDD")
    c.V("vg", GND, dc=vgs, ref="VG")
    c.M("vdd", "vg", GND, GND, "M2N7002")
    sol = _op(c)
    vds = _v(sol, "vdd")
    i_d = abs(float(sol.value_at("i(vdd)", 0.0)))
    vov = vgs - Vto
    is_true(vds < vov, f"Vds={vds:.3f}V 应小于 Vov={vov:.3f}V 才是线性区")
    theory = Kp * (vov * vds - vds ** 2 / 2.0) * (1 + lam * vds)
    close(i_d, theory, 0.15, what="M2N7002 线性区电流")


@case(group="M2 MOSFET")
def test_mosfet_cutoff():
    """M2N7002 截止（Vgs=0 < Vto=2.1）：几乎不导电，漏极被上拉电阻拉到 Vdd。

    防的是：Vto 被写成 0 或负数（那样 Vgs=0 也会有大电流），
    这种错误在饱和区公式里可能被 λ 项掩盖，只有截止测试能抓出来。
    """
    H.need_ngspice()
    c = Circuit("mos_off")
    c.V("vdd", GND, dc=5.0)
    c.R("vdd", "d", 1e3)
    c.M("d", GND, GND, GND, "M2N7002")
    vd = _v(_op(c), "d")
    is_true(vd > 4.99, f"截止时 Vd 应≈5V（无电流），实测 {vd:.4f}V")


@case(group="M2 MOSFET")
def test_mosfet_bulk_defaults_to_source():
    """bulk 省略时必须接到源极（网表 `M1 d g s s model`）。

    防的是：漏了第 4 个节点 → ngspice 把模型名当 bulk 节点，
    整个器件行错位一格，得到的电流和公式完全对不上。
    """
    c = Circuit("m")
    c.V("vdd", GND, dc=5.0)
    c.V("vg", GND, dc=5.0)
    c.M("vdd", "vg", GND, None, "M2N7002")
    net = c.to_spice(".op")
    line = next(ln for ln in net.splitlines() if ln.startswith("M1 "))
    parts = line.split()
    is_true(len(parts) == 6, f"M1 行应有 位号+4 节点+模型 = 6 列，实测 {parts}")
    is_true(parts[3] == parts[4] == "0",
            f"bulk 省略时应等于源极节点 0，实测 d/g/s/b = {parts[2:5]}")


# ==========================================================================
# M2：时域激励
# ==========================================================================
@case(group="M2 激励")
def test_pulse_rc_tau():
    """★PULSE + RC 阶跃：t=τ 时为 63.2%，t=5τ 时为 99.3%（误差 <3% / <2%）。

    这是瞬态通路（.tran + PULSE 源 + ASCII rawfile 解析 + Python 侧插值）的
    端到端核对。τ 时刻的值只由 R·C 决定，任何一环把量级写错都会立刻偏离。
    """
    H.need_ngspice()
    r, cval = 1e3, 100e-9
    tau = r * cval
    c = Circuit("pulse_rc")
    c.PULSE("in", GND, v1=0, v2=5, td=0, tr=1e-9, tf=1e-9, pw=1e-3, per=2e-3)
    c.R("in", "out", r)
    c.C("out", GND, cval)
    sol = c.tran(1e-6, 500e-6)
    v_tau = sol.value_at("out", tau)
    v_5tau = sol.value_at("out", 5 * tau)
    close(v_tau, 5 * (1 - math.exp(-1)), 0.03, what="t=τ 时输出（解析 0.6321×5V）")
    close(v_5tau, 5 * (1 - math.exp(-5)), 0.02, what="t=5τ 时输出（解析 0.9933×5V）")
    is_true(v_5tau > v_tau, "5τ 必须高于 τ（单调上升），否则时间轴反了")


@case(group="M2 激励")
def test_sin_amplitude_and_period():
    """PULSE/SIN 的 SIN 源：幅度 ±2V、周期 1ms（峰值出现在 T/4、3T/4…）。

    防的是：SIN 的 (VO VA FREQ) 参数顺序写错 —— 幅度和频率互换后
    "波形看着正常"（就是个正弦），只有量出来的幅度/周期能分辨。
    """
    H.need_ngspice()
    c = Circuit("sin")
    c.SIN("in", GND, vo=0.0, va=2.0, freq=1e3)
    c.R("in", GND, 1e3)
    sol = c.tran(1e-6, 3e-3)
    t_period = 1e-3
    for t, want in ((t_period / 4, 2.0), (3 * t_period / 4, -2.0), (5 * t_period / 4, 2.0)):
        v = sol.value_at("in", t)
        close_abs(v, want, 0.05, what=f"SIN 在 t={t * 1e3:.2f}ms 的瞬时值")


# ==========================================================================
# 参数校验（坏参数必须在建电路时就被拦住）
# ==========================================================================
@case(group="参数校验")
def test_passive_value_validation():
    """R/C/L 的值必须为正的有限数；未知关键字必须报错。

    防的是：负电阻造出"负阻振荡器"、0 电阻让矩阵奇异，或者把我拼错的参数名
    静默吞掉（`resitance=1e3` 被忽略 → 元件值缺省 → 电路完全是另一回事）。
    """
    c = Circuit("t")
    for fn in (c.R, c.C, c.L):
        raises(CCLConfigError, fn, "in", GND, 0, what=f"{fn.__name__} 值 = 0")
        raises(CCLConfigError, fn, "in", GND, -1e3, what=f"{fn.__name__} 负值")
        raises(CCLConfigError, fn, "in", GND, "abc", what=f"{fn.__name__} 非数字")
        raises(CCLConfigError, fn, "in", GND, float("inf"), what=f"{fn.__name__} inf")
    raises(CCLConfigError, c.R, "in", GND, 1e3, resitance=1e3, what="拼错的关键字")


@case(group="参数校验")
def test_source_validation():
    """独立源的 dc/ac 必须是有限数，ac 不能为负（相位要用复数幅度，另说）。"""
    c = Circuit("t")
    raises(CCLConfigError, c.V, "in", GND, dc="abc", what="dc 非数字")
    raises(CCLConfigError, c.V, "in", GND, ac=-1.0, what="ac 为负")
    raises(CCLConfigError, c.V, "in", GND, ac=float("nan"), what="ac 为 nan")
    raises(CCLConfigError, c.V, "in", GND, ac=1.0, bogus=2, what="源的不认识参数")


@case(group="参数校验")
def test_pulse_and_sin_validation():
    """PULSE/SIN 的参数约束：脉宽<周期、上升沿>0、频率>0、幅度>=0。

    防的是：pw>=per（ngspice 直接算不出脉冲，或给出恒定值）与 tr=0
    （理想边沿在数值上无解，实测会不收敛）。
    """
    c = Circuit("t")
    raises(CCLConfigError, c.PULSE, "a", GND, per=1e-3, pw=1e-3, what="pw == per")
    raises(CCLConfigError, c.PULSE, "a", GND, tr=0, what="tr = 0")
    raises(CCLConfigError, c.PULSE, "a", GND, tf=-1e-9, what="tf 为负")
    raises(CCLConfigError, c.SIN, "a", GND, freq=0, what="freq = 0")
    raises(CCLConfigError, c.SIN, "a", GND, va=-1, what="幅度为负")
    raises(CCLConfigError, c.PULSE, "a", GND, foo=1, what="PULSE 不认识参数")


@case(group="参数校验")
def test_modeled_device_validation():
    """半导体器件的模型名与专用参数校验。

    防的是：
      - 模型名以数字开头（SPICE 硬限制：1N4148 必须写成 D1N4148）
      - 自定义模型不给 model_params → 网表里出现一个空模型卡，ngspice 静默用默认参数
      - 二极管 area<=0 → 电流为负或除零
    """
    c = Circuit("t")
    raises(CCLConfigError, c.D, "a", GND, "1N4148", what="模型名以数字开头")
    # 自定义模型不给参数：错误是**延迟**到编译期才报的（器件构造时还不知道
    # 自己会不会被用上）。这里必须验证它最终**会被**拦住，否则网表里会出现
    # 一个空模型卡，ngspice 静默用默认参数。
    c2 = Circuit("custom")
    c2.V("in", GND, dc=1)
    c2.D("a", GND, "MYDIODE")
    c2.R("a", "in", 1e3)
    from ccl.compile import compile_circuit
    from ccl.errors import CCLNetlistError

    raises(CCLNetlistError, compile_circuit, c2, ".op", what="自定义模型不给参数就编译")
    raises(CCLConfigError, c.D, "a", GND, "D1N4148", area=0.0, what="area = 0")
    raises(CCLConfigError, c.Q, "c", "b", GND, "2N3904", what="三极管模型名以数字开头")
    raises(CCLConfigError, c.M, "d", "g", GND, None, "M2N7002", bogus=1, what="MOS 不认识参数")
    # 合法用法不能被误杀
    d = c.D("a", GND, "MYDIODE", model_params={"Is": "1e-14", "N": "1.8"})
    is_true(d.model == "MYDIODE", f"自定义模型名应保留，实测 {d.model!r}")
    is_true("Is=1e-14" in d.model_card(), f"自定义模型卡应含给定参数，实测 {d.model_card()!r}")


@case(group="参数校验")
def test_opamp_requires_positive_gbw_a0():
    """运放的 gbw/a0 必须 > 0；且两个参数不同的运放不能共用同一个宏模型名。"""
    c = Circuit("t")
    raises(CCLConfigError, c.OpAmp, "a", "b", GND, gbw=0, what="gbw = 0")
    raises(CCLConfigError, c.OpAmp, "a", "b", GND, a0=-1e5, what="a0 为负")
    c.OpAmp("a", "b", GND, gbw=1.3e6, a0=1e5)
    c.OpAmp("a", "b", GND, gbw=1e6, a0=1e5)
    subs = {comp.subckt for comp in c.components if comp.kind == "X"}
    is_true(len(subs) == 2, f"不同参数的运放应有不同的宏模型名，实测 {subs}")


if __name__ == "__main__":
    sys.exit(H.main("test_devices", "test_devices：M1/M2 器件解析式核对"))
