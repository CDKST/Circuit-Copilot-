"""规格断言机制：expect / verify / assert_ok —— 容差语义与方向语义。

这一层是「代码即测试」的核心价值：把「这个滤波器必须在 1kHz −3dB」写进代码，
改一个电阻几十条规格自动重跑。所以要防的不是「函数能不能调用」，
而是**容差语义被写错**导致断言形同虚设：

  ★ 回归 A（相对容差）：`expect("fc","out",1000,tol=0.10)` 的合格区间是
    900~1100 Hz。若把相对容差当绝对容差（±0.1 Hz），一个完全合格的 990Hz
    设计会被判失败 —— 这是 CONTRACT 的 D 系列教训。
  ★ 回归 B（方向语义）：`mode="min"` 表示「不低于」。带宽要求 100kHz 以上时，
    实测 997kHz 是**完全合格**的；当成「约等于 100kHz」会算出 897% 偏差、
    判失败，还逼着把电路改小到 99.75kHz —— 反而真的不达标（实测踩到过）。
  ★ 回归 C（dB 绝对容差）：`peak_db` 的 tol=0.5 是 ±0.5 dB，不是 ±50%。
  ★ 已知缺陷 D：低通电路的 `bw`（带宽）当前测不出来（见文件末尾的 known_bug）。
"""

import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, close_abs, in_range, is_false, is_true  # noqa: E402

from ccl.assertions import Expect, evaluate  # noqa: E402
from ccl.blocks import BLOCKS  # noqa: E402
from ccl.core import GND, Circuit  # noqa: E402
from ccl.errors import CCLAssertionError  # noqa: E402

TAU = 2 * math.pi


def _rc(fc: float, *, c: float = 100e-9, name: str = "rc") -> Circuit:
    """按目标截止频率反算 R 做一个 RC 低通（fc = 1/(2πRC)）。"""
    ckt = Circuit(name)
    ckt.V("in", GND, ac=1)
    ckt.R("in", "out", 1.0 / (TAU * fc * c))
    ckt.C("out", GND, c)
    return ckt


def _sallen_key(q: float, fc: float = 10e3):
    """在顶层电路里实例化一个 Sallen-Key 低通，返回 (solution, 节点名)。"""
    blk = BLOCKS["sallen_key_lowpass"](fc=fc, q=q)
    top = Circuit("sk")
    top.V("src", GND, ac=1)
    top.use_ports(blk, {"in": "src", "out": "y"}, prefix="K")
    return blk, top.ac(10, 1e6, 400), "y"


# ==========================================================================
# 基本行为
# ==========================================================================
@case(group="基本行为")
def test_qualified_circuit_passes():
    """合格的 RC 低通：fc / gain / peak_db 三条规格全部通过，且结果条数对。

    防的是：verify() 静默漏跑某些指标（结果列表少一条也没人发现）。
    """
    H.need_ngspice()
    c = _rc(1e3)
    c.expect("fc", "out", 1e3, tol=0.05).expect("gain", "out", 1.0, tol=0.02)
    c.expect("peak_db", "out", 0.5, mode="max", tol=0.5)
    rep = c.verify(ac=(1, 1e5, 200))
    is_true(rep.passed, f"合格电路应全部通过，实测：\n{rep}")
    is_true(len(rep.results) == 3, f"应有 3 条核对结果，实测 {len(rep.results)}")
    is_true(all(r.ok for r in rep.results), f"每条都应 ok，实测 {[(r.expect.kind, r.actual) for r in rep.results]}")


@case(group="基本行为")
def test_bad_circuit_caught_with_numbers():
    """不合格电路必须被抓，且失败消息里带**目标值与实测值**。

    防的是：报错只说"未达标"，用户还得自己去翻仿真结果才知道差多少。
    """
    H.need_ngspice()
    c = _rc(1e3).with_(C1=10e-9)          # 电容小 10 倍 → fc 高 10 倍（10 kHz）
    c.expect("fc", "out", 1e3, tol=0.05)
    rep = c.verify(ac=(1, 1e5, 200))
    is_false(rep.passed, "电容改小 10 倍后截止频率不达标，必须被判失败")
    r = rep.results[0]
    close(r.actual, 1e4, 0.15, what="实测 f3db（应 ≈10 kHz）")
    msg = r.message()
    is_true("1000" in msg, f"失败消息应给出目标值（1000/1e+03），实测：{msg}")
    is_true("1e+04" in msg or "10000" in msg,
            f"失败消息应给出实测值（≈1e+04 Hz），实测：{msg}")
    is_true("❌" in msg, f"失败消息应带 ❌ 标记，实测：{msg}")


@case(group="基本行为")
def test_assert_ok_raises_with_comparison():
    """assert_ok() 不通过时抛 CCLAssertionError，消息里是逐项对比表。

    防的是：assert_ok 静默返回（那样 CI 永远绿）。
    """
    H.need_ngspice()
    c = _rc(1e3)
    c.expect("fc", "out", 1e4, tol=0.05)     # 故意差 10 倍
    try:
        c.assert_ok(ac=(1, 1e5, 200))
    except CCLAssertionError as e:
        text = str(e)
        is_true("未达标" in text, f"异常消息应说明有几项未达标，实测：{text[:80]}")
        is_true("1e+04" in text or "10000" in text,
                f"异常消息应给出目标值（1e+04 Hz），实测：{text[:160]}")
    else:
        raise H.Fail("assert_ok() 在规格不达标时没有抛 CCLAssertionError")


# ==========================================================================
# ★容差语义
# ==========================================================================
@case(group="容差语义")
def test_relative_tolerance_band():
    """★回归 A：相对容差 tol=0.10 的合格区间是 target×[0.9, 1.1]，不是 ±0.1。

    用三个设计直接验证区间边界：
        990 Hz  （−1%）→ 必须通过
        890 Hz  （−11%）→ 必须失败
        1040 Hz （+4%）→ 必须通过
    若把相对容差误当绝对容差，990Hz 会被判失败（历史上真出过）。
    """
    H.need_ngspice()
    e = Expect("fc", "out", 1000.0, 0.10, "eq")
    lo, hi = e.band()
    close(lo, 900.0, 1e-12, what="tol=0.10 的下界")
    close(hi, 1100.0, 1e-12, what="tol=0.10 的上界")

    for design_fc, should_pass in ((990.0, True), (1040.0, True), (890.0, False), (1150.0, False)):
        c = _rc(design_fc)
        c.expect("fc", "out", 1000.0, tol=0.10)
        rep = c.verify(ac=(1, 1e5, 300))
        got = rep.results[0].actual
        is_true(rep.passed == should_pass,
                f"设计 {design_fc:g}Hz 对「1000Hz ±10%」应{'通过' if should_pass else '失败'}，"
                f"实测 f3db={got:.1f}Hz → {'通过' if rep.passed else '失败'}")


@case(group="容差语义")
def test_db_uses_absolute_tolerance():
    """★回归 C：dB 类指标（peak_db / gain_db）用**绝对**容差：tol=0.5 → ±0.5dB。

    防的是：把 tol 当成百分比 → ±0.5% 变成 ±0.005dB（过严，正常电路全红），
    或者反过来 ±50%（过松，6dB 的峰化也放过）。
    """
    H.need_ngspice()
    e = Expect("peak_db", "out", 0.5, 0.5, "max")
    lo, hi = e.band()
    is_true(lo == -math.inf, f"mode=max 的下界应是 −∞，实测 {lo}")
    close(hi, 1.0, 1e-12, what="0.5dB ± 0.5dB 的上界")

    # Q=2 → 峰化 ≈ 6.47dB，必须被判失败（若 tol 被当成百分比就会放过它）
    blk, sol, node = _sallen_key(q=2.0)
    blk.expect("peak_db", node, 0.5, mode="max", tol=0.5)
    rep = evaluate(blk.expectations, blk, ac_sol=sol)
    peak = rep.results[0].actual
    in_range(peak, 5.5, 7.5, what="Q=2 二阶低通的通带峰化（解析 20·log10(2)=6.02dB 量级）")
    is_false(rep.passed, f"峰化 {peak:.2f}dB 超过 1.0dB 上限，必须判失败")

    # Q=0.7071（最大平坦）→ 峰化 ≈ 0dB，必须通过
    blk2, sol2, node2 = _sallen_key(q=0.7071)
    blk2.expect("peak_db", node2, 0.5, mode="max", tol=0.5)
    rep2 = evaluate(blk2.expectations, blk2, ac_sol=sol2)
    is_true(rep2.passed, f"最大平坦（峰化 {rep2.results[0].actual:.3f}dB）必须通过")


@case(group="容差语义")
def test_mode_min_direction():
    """★回归 B：mode="min" 是「不低于」，远超要求必须合格。

    用截止频率做核对（`fc` 是这一层能可靠测量的指标）：
        floor = 100 kHz, tol = 0.02
        实测 997 kHz → 必须通过（曾因按"约等于"判而被算成 897% 偏差）
        实测  85 kHz → 必须失败（比下限低 >2%）
    """
    H.need_ngspice()
    e = Expect("fc", "out", 100e3, 0.02, "min")
    lo, hi = e.band()
    close(lo, 100e3 * 0.98, 1e-12, what="min 模式的下界")
    is_true(hi == math.inf, f"min 模式的上界应是 +∞，实测 {hi}")

    c = _rc(9.97e5)
    c.expect("fc", "out", 100e3, tol=0.02, mode="min")
    rep = c.verify(ac=(10, 5e6, 300))
    got = rep.results[0].actual
    close(got, 9.97e5, 0.05, what="实测 f3db")
    is_true(rep.passed, f"997kHz 远高于 100kHz 下限，必须通过（实测 {got:.0f}Hz）")

    c2 = _rc(8.5e4)
    c2.expect("fc", "out", 100e3, tol=0.02, mode="min")
    is_false(c2.verify(ac=(10, 5e6, 300)).passed,
             "85kHz 低于 100kHz 下限，必须判失败")


@case(group="容差语义")
def test_mode_max_direction():
    """mode="max" 是「不高于」：要求 ≤5kHz 时 3kHz 合格、8kHz 不合格。

    与 min 配对，防「方向搞反」—— 那会让一个超标的电路被判合格。
    """
    H.need_ngspice()
    ok_c = _rc(3e3)
    ok_c.expect("fc", "out", 5e3, tol=0.02, mode="max")
    is_true(ok_c.verify(ac=(10, 5e5, 300)).passed, "3kHz 满足「不超过 5kHz」，应通过")

    bad_c = _rc(8e3)
    bad_c.expect("fc", "out", 5e3, tol=0.02, mode="max")
    is_false(bad_c.verify(ac=(10, 5e6, 300)).passed, "8kHz 超过「不超过 5kHz」，应失败")


# ==========================================================================
# 各指标的实际测量值（解析式核对）
# ==========================================================================
@case(group="指标核对")
def test_gain_and_gain_db():
    """gain（线性倍数）与 gain_db 都要对：单位增益低通 = 1.0 倍 / 0.0 dB。

    防的是：gain 取成了 dB、或 gain_db 取成了绝对值（两者混用会让
    「增益 10 倍」和「增益 20dB」互相判错）。
    """
    H.need_ngspice()
    c = _rc(1e3)
    c.expect("gain", "out", 1.0, tol=0.01).expect("gain_db", "out", 0.0, tol=0.1)
    rep = c.verify(ac=(1, 1e5, 100))
    g, gdb = rep.results[0].actual, rep.results[1].actual
    close(g, 1.0, 0.01, what="通带线性增益")
    close_abs(gdb, 0.0, 0.1, what="通带增益（dB）")
    is_true(rep.passed, f"两条规格都应通过，实测：\n{rep}")


@case(group="指标核对")
def test_value_at_measurement():
    """value_at：在 fc 处的幅值必须是通带的 1/√2（−3dB 的定义）。

    防的是：value_at 用线性插值读对数频率轴（会差几个百分点），
    或者 at= 参数被忽略（永远读第一个点）。
    """
    H.need_ngspice()
    fc = 1e3
    c = _rc(fc)
    c.expect("value_at", "out", 1.0 / math.sqrt(2), tol=0.02, at=fc)
    rep = c.verify(ac=(1, 1e5, 300))
    close(rep.results[0].actual, 1.0 / math.sqrt(2), 0.02,
          what="fc 处幅值（解析 0.7071×通带）")
    is_true(rep.passed, f"value_at 规格应通过，实测：\n{rep}")


@case(group="指标核对")
def test_voltage_and_power_measurement():
    """v（节点电压）与 p（电阻功耗）都要对上解析式。

    防的是：p 用错公式（比如把 R 当分母以外的值），或者 p 读错节点导致
    接地电阻的功耗永远算成 0（那正是地节点特判的同一个坑）。
    """
    H.need_ngspice()
    c = Circuit("bjt")
    c.V("vcc", GND, dc=5.0)
    c.R("vcc", "b", 100e3)
    c.R("vcc", "c", 100.0)
    c.Q("c", "b", GND, "Q2N3904")
    c.expect("v", "b", 0.718, tol=0.05)
    c.expect("p", "R2", 0.005, tol=0.5, mode="max")
    rep = c.verify()
    v_b, p_r2 = rep.results[0].actual, rep.results[1].actual
    in_range(v_b, 0.55, 0.78, what="Vbe")
    # P = (Vcc − Vc)²/R，用实测电压反算，必须与 p 指标的自算值一致
    sol = c.op()
    vc = float(sol.value_at("c", 0.0))
    close(p_r2, (5.0 - vc) ** 2 / 100.0, 0.01, what="R2 功耗 vs (Vcc−Vc)²/R 解析式")
    is_true(rep.passed, f"工作点规格应通过，实测：\n{rep}")


@case(group="指标核对")
def test_q_measurement():
    """q 指标：Sallen-Key 的 Q 是 |H(f0)|/|H(通带)|，f0 取相位 −90° 交点。

    Q=2 → 实测 ≈2；Q=0.7071 → 实测 ≈0.71。
    防的是：用「f0/−3dB 带宽」算 Q —— Q≤0.707 时那个方法直接失效（没有峰化）。
    """
    H.need_ngspice()
    for q_design, tol in ((2.0, 0.10), (0.7071, 0.10)):
        blk, sol, node = _sallen_key(q=q_design)
        blk.expect("q", node, q_design, tol=tol)
        rep = evaluate(blk.expectations, blk, ac_sol=sol)
        close(rep.results[0].actual, q_design, tol, what=f"实测 Q（设计 Q={q_design}）")
        is_true(rep.passed, f"Q={q_design} 的规格应通过，实测：\n{rep}")


# ==========================================================================
# 测不到就判未达标（绝不编数据）
# ==========================================================================
@case(group="测不到")
def test_missing_analysis_is_not_pass():
    """缺分析时指标判「测不到」（NaN → 未达标），绝不编一个数。

    防的是：没有 op 结果却把 v 指标判成通过 —— 那等于什么都没核对。
    """
    H.need_ngspice()
    c = _rc(1e3)
    c.expect("v", "b", 0.7, tol=0.1)          # 工作点类指标
    ac_sol = c.ac(1, 1e5, 50)
    rep = evaluate(c.expectations, c, ac_sol=ac_sol, op_sol=None)
    r = rep.results[0]
    is_true(r.actual != r.actual or r.actual is None, f"缺 op 时实测值应是 NaN，实测 {r.actual!r}")
    is_false(rep.passed, "缺分析时整条规格必须判未达标")
    is_true("测不到" in r.message(), f"消息应说明「测不到」，实测：{r.message()}")


@case(group="测不到")
def test_unknown_node_is_not_pass():
    """规格指向不存在的节点 → 未达标（不是抛异常、也不是通过）。"""
    H.need_ngspice()
    c = _rc(1e3)
    ac_sol = c.ac(1, 1e5, 50)
    e = [Expect("fc", "no_such_node", 1e3, 0.05, "eq")]
    rep = evaluate(e, c, ac_sol=ac_sol)
    is_false(rep.passed, "指向不存在节点的规格必须判未达标")
    is_true(rep.results[0].actual != rep.results[0].actual, "实测值应是 NaN")


# ==========================================================================
# Report / table
# ==========================================================================
@case(group="报告")
def test_report_table_and_str():
    """Report.table() 的字段必须齐全（Web 端直接吃这份结构），__str__ 带结论。

    防的是：Web/API 依赖的字段被改名或删掉 → 前端静默显示空白。
    """
    H.need_ngspice()
    c = _rc(1e3)
    c.expect("fc", "out", 1e3, tol=0.05).expect("gain", "out", 1.0, tol=0.02)
    rep = c.verify(ac=(1, 1e5, 100))
    rows = rep.table()
    is_true(len(rows) == 2, f"table 应有 2 行，实测 {len(rows)}")
    for key in ("label", "kind", "node", "mode", "target", "unit", "actual", "ok"):
        is_true(key in rows[0], f"table 缺少字段 {key!r}，实测 {sorted(rows[0])}")
    is_true(rows[0]["unit"] == "Hz", f"fc 的单位应是 Hz，实测 {rows[0]['unit']!r}")
    is_true("全部通过" in str(rep), f"全通过时 __str__ 应给出正结论，实测 {str(rep)[:40]!r}")
    is_true(rep.elapsed_ms > 0, f"Report 应记录耗时，实测 {rep.elapsed_ms}")


# ==========================================================================
# 已知缺陷（断言保持严格，代码当前不满足）
# ==========================================================================
@case(group="测不到")
def test_bw_measurable_for_lowpass():
    """★回归（曾经真出过）：低通电路的 bw（−3dB 带宽）必须可测，且 ≈ f3db。

    这道防线原来漏了：`_measure("bw")` 用「峰值两侧各找 −3dB」，而单极点低通的
    峰值就落在扫描起点 → 低频侧恒为 None → 带宽永远是 NaN（"测不到"）。
    同一算法在 `ccl/ai/spec_check.py::_measure_bw` 里早已修过（峰在起点时只算
    高频侧），当时两处实现不一致 —— 属于漏改。

    为什么这条要紧：需求常写「带宽 100kHz 以上」，而 mode="min" 的全部意义
    建立在「能测出带宽」之上。测不到 → 判未达标 → 一个完全合格的电路被判失败。

    期望：1kHz 一阶低通的带宽 = f3db − 0 ≈ 1kHz。
    """
    H.need_ngspice()
    c = _rc(1e3)
    c.expect("bw", "out", 1e3, tol=0.10)
    rep = c.verify(ac=(1, 1e5, 300))
    r = rep.results[0]
    is_true(r.actual == r.actual,
            f"低通的带宽应可测（≈{c.ac(1, 1e5, 100).f3db('out'):.0f}Hz），实测 {r.actual!r}（NaN=测不到）")
    close(r.actual, 1e3, 0.10, what="1kHz 一阶低通的 −3dB 带宽")
    is_true(rep.passed, f"该规格应通过，实测：\n{rep}")


@case(group="指标核对")
def test_bw_bandpass_and_min_mode():
    """带通电路的 bw 是可测的（峰值在中间，两侧都能找到 −3dB），并核对 f0/Q。

    这条同时验证 mode="min" 在 bw 上的方向语义：下限 9kHz 通过、12kHz 不通过。
    与上面那条 known_bug 配对 —— 说明「算法本身有低通特例没处理」，不是"不会算"。
    """
    H.need_ngspice()
    f0, q = 100e3, 10.0
    blk = BLOCKS["rlc_bandpass"](f0=f0, q=q)
    top = Circuit("bp")
    top.V("src", GND, ac=1)
    top.use_ports(blk, {"in": "src", "out": "y"}, prefix="B")
    sol = top.ac(1e3, 1e7, 600)

    blk.expect("bw", "y", f0 / q, tol=0.25)
    rep = evaluate(blk.expectations, blk, ac_sol=sol)
    got = rep.results[0].actual
    close(got, f0 / q, 0.25, what="带通带宽（解析 f0/Q = 10kHz）")

    # 方向语义：min 下限 9kHz 应通过；下限 12kHz 应失败
    blk2 = BLOCKS["rlc_bandpass"](f0=f0, q=q)
    blk2.expect("bw", "y", 9e3, tol=0.02, mode="min")
    is_true(evaluate(blk2.expectations, blk2, ac_sol=sol).passed,
            "实测 10kHz 满足「≥9kHz」下限，应通过")
    blk3 = BLOCKS["rlc_bandpass"](f0=f0, q=q)
    blk3.expect("bw", "y", 12e3, tol=0.02, mode="min")
    is_false(evaluate(blk3.expectations, blk3, ac_sol=sol).passed,
             "实测 10kHz 不满足「≥12kHz」下限，应失败")


if __name__ == "__main__":
    sys.exit(H.main("test_assertions", "test_assertions：规格断言机制"))
