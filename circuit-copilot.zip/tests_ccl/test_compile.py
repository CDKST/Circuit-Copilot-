"""网表编译层：数值格式化、.model 输出、位号 SPICE 化、结构合法性。

这一层是「数字写错也照样跑通」的重灾区：ngspice 拿到一份语法合法的网表就会
给你一个**看起来合理**的结果，所以这里的用例全部拿**真跑出来的物理量**核对，
不做字符串比对。

★ 本文件最重要的三条回归（防复活）：
  1. `1M` 在网表里必须是纯十进制 —— ngspice 里大写 M 是**毫**，差 10⁹ 倍
  2. 位号必须过 netlist_ref() —— 内联产生的 `U1.R1` 首字母是 U，ngspice 当另一种器件
  3. `.control` 必须被编译期拒收 —— 手写一份会让波形根本不落盘
"""

import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, close_abs, is_false, is_true, raises  # noqa: E402

from ccl.compile import (  # noqa: E402
    NetlistRefError,
    compile_circuit,
    netlist_ref,
)
from ccl.core import GND, Circuit, Component, Pin  # noqa: E402
from ccl.errors import (  # noqa: E402
    CCLConfigError,
    CCLNetlistError,
    NodeError,
    RefError,
)
from ccl.format import fmt_value  # noqa: E402


# --------------------------------------------------------------------------
# 小工具
# --------------------------------------------------------------------------
def _rc(**kw) -> Circuit:
    c = Circuit(kw.pop("name", "rc"))
    c.V("in", GND, ac=kw.pop("ac", 1.0), dc=kw.pop("dc", 0.0))
    c.R("in", "out", kw.pop("r", 1.6e3))
    c.C("out", GND, kw.pop("c", 100e-9))
    return c


def _op_voltage(netlist: str, node: str) -> float:
    """把编译产物直接交给 ngspice 跑 .op（不经 runner），读回节点电压。"""
    from copilot import sim

    res = sim.run(netlist)
    key = f"v({node})".lower()
    if key not in res.waves:
        raise H.Fail(f"仿真结果里没有 {key}，实际有 {sorted(res.waves)}")
    return res.waves[key].y[0].real


def _device_lines(netlist: str) -> list[str]:
    """取出网表的「器件行」区（标题之后、第一条 '.' 指令之前）。"""
    out = []
    for line in netlist.splitlines()[1:]:
        if line.startswith("."):
            break
        if line.startswith("*"):
            continue
        if line.strip():
            out.append(line)
    return out


# ==========================================================================
# 数值格式化 —— 本模块的核心
# ==========================================================================
@case(group="数值格式化")
def test_one_meg_never_uses_suffix():
    """★回归：1e6 必须格式化成纯十进制 "1000000"，绝不能输出 "1M"/"1MEG"/"1e6"。

    为什么这条最重要：ngspice 里 `1M` 解析成 **1e-3**（毫），不是兆。
    用户想写 1MΩ 写成 `1M`，电路静默地差了 10⁹ 倍 —— 而且仿真成功、波形正常、
    只是所有结果都错。所以 fmt_value 统一输出不带单位后缀的纯十进制。
    """
    for v, want in (
        (1e6, "1000000"), (1e-6, "0.000001"), (1e-7, "0.0000001"),
        (4700.0, "4700"), (1.6e3, "1600"), (100e-9, "0.0000001"),
        (1e3, "1000"), (0.5, "0.5"), (1e12, "1000000000000"),
    ):
        got = fmt_value(v)
        is_true(got == want, f"fmt_value({v!r}) 期望 {want!r}，实测 {got!r}")

    # 任何字母后缀都不许出现（e/E 只允许出现在「纯十进制太长」的指数回退里）
    for v in (1e6, 1e-7, 4700.0, 1e-3, 2.2e3, 1e9):
        tok = fmt_value(v)
        is_false(any(ch.isalpha() for ch in tok),
                 f"fmt_value({v!r}) = {tok!r} 含字母 —— 网表里一旦出现便可能有毫/兆歧义")


@case(group="数值格式化")
def test_ngspice_actually_reads_1M_as_milli():
    """★回归（物理证据）：手写网表里 `1M` 真的是「毫」，`1meg` 才是兆。

    这条用例的意义是「把坑本身钉死」：它证明 test_one_meg_never_uses_suffix
    不是洁癖，而是真实的物理后果。用同一个分压电路，换一个电阻 token：

        R1 = 1000000  → v(m) = 0.5      （兆，正确）
        R1 = 1meg     → v(m) = 0.5      （兆，正确）
        R1 = 1M       → v(m) ≈ 1.0      （毫！下半臂 1MΩ 被 1mΩ 按在地上）
    """
    H.need_ngspice()

    def divider(r1_tok: str) -> float:
        deck = (
            "* m trap\n"
            "V1 in 0 dc 1\n"
            f"R1 in m {r1_tok}\n"
            "R2 m 0 1000000\n"
            ".op\n"
            ".control\nset filetype=ascii\nop\nwrite c.raw all\n.endc\n.end\n"
        )
        return _op_voltage(deck, "m")

    v_plain = divider("1000000")
    v_meg = divider("1meg")
    v_M = divider("1M")
    v_m = divider("1m")
    close(v_plain, 0.5, 1e-6, what="R1=1000000 时的分压比")
    close(v_meg, 0.5, 1e-6, what="R1=1meg 时的分压比")
    is_true(v_M > 0.99, f"R1=1M 时必须看到「毫」的效果（v(m)→1.0），实测 {v_M:.6f}")
    close(v_M, v_m, 1e-9, what="1M 与 1m 在 ngspice 里应完全等价")


@case(group="数值格式化")
def test_compiled_meg_ohm_divider_is_physical():
    """★回归（端到端）：ccl 编出来的 1MΩ 分压器，跑出的电压必须等于解析式 0.5V。

    上面两条核对的是 fmt_value 与 ngspice 的行为，这一条核对的是**整条链路**：
    用户写 1e6 → 网表 → 仿真 → 结果。任何一环退回后缀写法，这里立刻掉到 ≈1.0V。
    """
    H.need_ngspice()
    c = Circuit("div_1meg")
    c.V("in", GND, dc=1.0)
    c.R("in", "m", 1e6)
    c.R("m", GND, 1e6)
    net = compile_circuit(c, ".op")
    is_true("R1 in m 1000000" in net, f"网表里 1MΩ 应写成 1000000，实测器件行：{_device_lines(net)}")
    v = _op_voltage(net, "m")
    close(v, 0.5, 1e-6, what="1MΩ/1MΩ 分压器输出（解析式 0.5V）")


@case(group="数值格式化")
def test_fmt_value_edge_cases():
    """fmt_value 的边界：0 / -0 / nan / inf / 空串 / 空白 / 次正规数 / 指数回退。

    防的是「静默的错误答案」：
      - nan/inf 写进网表 → ngspice 当语法错或算出莫名结果 → 表现成 no convergence
      - |v|<1e-320 → ngspice 的 double 直接归零 → 电路里一个元件凭空消失
    """
    is_true(fmt_value(0) == "0", f"fmt_value(0) 应为 '0'，实测 {fmt_value(0)!r}")
    is_true(fmt_value(0.0) == "0" and fmt_value(-0.0) == "0",
            f"±0.0 都应输出 '0'（不能是 '-0'），实测 {fmt_value(0.0)!r} / {fmt_value(-0.0)!r}")

    for bad in (float("nan"), float("inf"), float("-inf")):
        raises(CCLConfigError, fmt_value, bad, what=f"fmt_value({bad!r})")
    for bad in ("", "   ", "a b", "1 0"):
        raises(CCLConfigError, fmt_value, bad, what=f"fmt_value({bad!r})")
    # 低于 ngspice 的 double 表示下限：宁可报错，也不写一个会被解析成 0 的数
    for tiny in (5e-324, 1e-321):
        raises(CCLConfigError, fmt_value, tiny, what=f"fmt_value({tiny!r})")

    # 纯十进制过长 → 指数形式回退，但仍是合法 token
    tok = fmt_value(1e-40)
    is_true("e" in tok.lower(), f"1e-40 应回退到指数形式，实测 {tok!r}")
    is_true(len(fmt_value(1e-7)) <= 32, f"普通量级应保持纯十进制，实测 {fmt_value(1e-7)!r}")
    # 非数字 token（子电路名、{param}）原样通过
    is_true(fmt_value("OPA") == "OPA", "非数字 token 必须原样通过")
    is_true(fmt_value("  1e3  ") == "1000", f"带空白的数字字符串应归一化，实测 {fmt_value('  1e3  ')!r}")


# ==========================================================================
# 网表结构
# ==========================================================================
@case(group="网表结构")
def test_netlist_shape():
    """网表结构：标题行 / 器件行 / 指令 / 分析卡 / .end，顺序固定且不含 .control。

    防的是：注入 .control 让 copilot.sim 不再注入自己的控制块 → 波形不落盘 →
    用户在离现场几十行远的地方看到「仿真未产生有效波形」。
    """
    c = _rc()
    c.directive(".model DX D(Is=1e-14)")
    c.directive(".param VDD=5")
    net = compile_circuit(c, ".tran 1u 1m", title="形状 测试")
    lines = net.splitlines()
    is_true(lines[0].startswith("* "), f"第一行必须是 '*' 开头的标题，实测 {lines[0]!r}")
    is_true("形状 测试" in lines[0], f"标题应使用传入的 title，实测 {lines[0]!r}")
    is_true(lines[-1] == ".end", f"最后一行必须是 .end，实测 {lines[-1]!r}")
    is_true(net.endswith("\n"), "网表必须以换行结尾（否则 .end 会被拼到下一行）")
    is_false(".control" in net.lower(), "编译产物里绝不能出现 .control")
    is_true(net.index("\nR1 ") < net.index(".model"), "器件行必须在 directives 之前")
    is_true(net.index(".tran") > net.index(".param"), "分析卡必须在 directives 之后")
    is_true(len(_device_lines(net)) == 3, f"应有 3 个器件行，实测 {_device_lines(net)}")


@case(group="网表结构")
def test_title_line_rules():
    """标题行：不传 title 用 circuit.name；多行/空白压缩；已有 '*' 不重复加。

    防的是：标题里带换行，把第一行拆成两行 —— SPICE 的第一行永远是标题，
    第二行会被当成器件行，报出一条谁也看不懂的错。
    """
    c = _rc(name="rc_lp")
    is_true(compile_circuit(c, ".op").splitlines()[0] == "* rc_lp",
            f"默认标题应为 '* rc_lp'，实测 {compile_circuit(c, '.op').splitlines()[0]!r}")
    multi = compile_circuit(c, ".op", title="第一行\n第二行")
    is_true(len(multi.splitlines()[0].split()) >= 3 and "\n" not in multi.splitlines()[0],
            f"多行标题必须被压成一行，实测 {multi.splitlines()[0]!r}")
    starred = compile_circuit(c, ".op", title="* 已有星号")
    is_false(starred.splitlines()[0].startswith("* *"),
             f"标题已有 '*' 时不应再加一个，实测 {starred.splitlines()[0]!r}")


# ==========================================================================
# 位号 SPICE 化（D5）
# ==========================================================================
@case(group="位号 netlist_ref")
def test_netlist_ref_mapping():
    """★回归：位号写进网表前必须过 netlist_ref()，保证首字母是器件类型字母。

    为什么要这样：ngspice 按**行首字符**决定器件类型。内联运放产生的 `U1.R1`
    首字母是 U，被当成「U 型器件（均匀 RC 线）」→ 把 "1k" 当模型名 → unknown model。
    换成下划线 `U1_R1` **治不了病**（首字母仍是 U），必须补成 `R.U1.R1`。
    """
    cases = [("R", "R1", "R1"), ("R", "U1.R1", "R.U1.R1"), ("C", "U1.U2.C3", "C.U1.U2.C3"),
             ("X", "X1", "X1"), ("R", "U1 R1", "R.U1_R1"), ("D", "U1.D1", "D.U1.D1")]
    for kind, ref, want in cases:
        comp = Component(kind=kind, ref=ref, pins=[Pin("a", "n1"), Pin("b", GND)])
        got = netlist_ref(comp)
        is_true(got == want, f"netlist_ref({kind},{ref!r}) 期望 {want!r}，实测 {got!r}")
        is_true(got[0].upper() == kind[0].upper(),
                f"网表位号首字母必须是 {kind[0]!r}，实测 {got!r}")


@case(group="位号 netlist_ref")
def test_inlined_circuit_refs_are_legal():
    """内联子电路编出来的每一条器件行，首字母都必须是器件类型字母（D5 不变量）。

    防的是：只对「第一层」内联做转换，多层嵌套时 `U1.U2.R3` 漏掉前缀。
    """
    inner = Circuit("inner")            # a → b → out
    inner.R("a", "b", 1e3)
    inner.R("b", "out", 1e3)
    mid = Circuit("mid")                # a → b → c → out（c 之后接内联的 inner）
    mid.R("a", "b", 1e3)
    mid.R("b", "c", 1e3)
    mid.use(inner, maps={"a": "c", "out": "out"})
    top = Circuit("top")                # in(=mid.a) → … → y(=mid.out)，y 对地下拉
    top.V("in", GND, dc=1)
    top.use(mid, maps={"a": "in", "out": "y"})
    top.R("y", GND, 1e3)
    net = compile_circuit(top, ".op")
    lines = [ln for ln in net.splitlines() if ln.strip() and not ln.startswith(("*", "."))]
    is_true(len(lines) >= 4, f"应至少有 4 条器件行，实测 {lines}")
    bad = [ln.split()[0] for ln in lines if ln.split()[0][0].upper() not in "RCLVIDQMXE"]
    is_false(bad, f"这些网表位号首字母不是器件类型字母：{bad}")
    raw = [c.ref for c in top.components]
    is_true(any(r.count(".") >= 2 for r in raw), f"应存在多层前缀位号，实测 {raw}")


@case(group="位号 netlist_ref")
def test_netlist_ref_collision_detected():
    """两个不同的 comp.ref 若映射成同一个网表位号，必须报错，不能静默合并。

    防的是：`R.U1.R1`（用户自己写的）与内联产生的 `U1.R1` 撞车，
    网表里两行同位号 → ngspice 只认一行，一台器件静默消失。
    """
    c = Circuit("collide")
    c.V("in", GND, ac=1)
    c.components.append(Component(kind="R", ref="U1.R1",
                                  pins=[Pin("a", "in"), Pin("b", GND)], value=1e3))
    c.components.append(Component(kind="R", ref="R.U1.R1",
                                  pins=[Pin("a", "in"), Pin("b", GND)], value=2e3))
    e = raises(NetlistRefError, compile_circuit, c, ".op", what="网表位号撞车")
    is_true("R.U1.R1" in str(e), f"报错应点名撞车的位号，实测：{e}")


# ==========================================================================
# .model / 子电路
# ==========================================================================
@case(group="模型与子电路")
def test_model_cards_emitted_and_runnable():
    """M2 器件的 .model 卡必须进网表，而且真的能被 ngspice 跑出工作点。

    防的是：只把器件名写进网表却忘了 .model 行 —— ngspice 报 unknown model，
    或者更糟：模型名恰好和别的东西撞上，跑出一个假结果。
    """
    H.need_ngspice()
    c = Circuit("models")
    c.V("vcc", GND, dc=5)
    c.R("vcc", "a", 1e3)
    c.D("a", GND, "D1N4148")
    c.R("vcc", "b", 100e3)
    c.R("vcc", "cc", 100)
    c.Q("cc", "b", GND, "Q2N3904")
    c.M("vcc", "vcc", GND, GND, "M2N7002")
    net = compile_circuit(c, ".op")
    for model in ("D1N4148", "Q2N3904", "M2N7002"):
        is_true(f".model {model} " in net, f"网表里缺少 .model {model} 行")
    is_true(".model D1N4148 D(" in net, "二极管模型类型应为 D")
    is_true(".model Q2N3904 NPN(" in net, "三极管模型类型应为 NPN")
    is_true(".model M2N7002 NMOS(" in net, "MOSFET 模型类型应为 NMOS")
    v = _op_voltage(net, "a")
    close_abs(v, 0.653, 0.15, what="含三种半导体的电路能跑出工作点（1N4148 阳极电平）")


@case(group="模型与子电路")
def test_opamp_subckt_injected():
    """运放宏模型的 .subckt 必须自动进网表（器件 directives() → 编译层收集）。

    防的是：只写 X1 … OPA 而没有 .subckt 定义 → unknown subckt，
    报错完全指不到「运放没带模型」这件事。
    """
    H.need_ngspice()
    c = Circuit("amp")
    c.V("in", GND, ac=1)
    c.R("sum", GND, 1e3)
    c.R("out", "sum", 9e3)
    c.OpAmp("in", "sum", "out", gbw=1.3e6, a0=1e5)
    net = compile_circuit(c, ".ac dec 50 1 1e6")
    is_true(".subckt " in net and ".ends" in net, "运放的 .subckt/.ends 必须进网表")
    op = c.find("X1")
    is_true(op.model in net, f"X 实例行应引用宏模型名 {op.model!r}")
    # 只验证「有 .subckt」还不够：必须真跑一次，确认增益是对的（1+R2/R1 = 10）
    from copilot import sim

    res = sim.run(net)
    gain = abs(res.waves["v(out)"].y[0])
    close(gain, 10.0, 0.01, what="同相放大增益（R1=1k, R2=9k）")


@case(group="模型与子电路")
def test_x_instance_port_count_checked():
    """X 实例的节点数必须与 .subckt 声明的端口数一致，否则立刻报错。

    防的是：少接一个端口 → ngspice 把下一个 token 当节点 → 错位一格，
    所有端子整体偏移，仿真照样跑通但电路完全是另一回事。
    """
    c = Circuit("xbad")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e3)
    c.directive(".subckt SUB a b\nR1 a b 1000\n.ends")
    c.add(Component(kind="X", ref="X1", value="SUB",
                    pins=[Pin("p1", "in"), Pin("p2", "out"), Pin("p3", GND)]))
    e = raises(CCLNetlistError, compile_circuit, c, ".op", what="X 实例端口数不符")
    is_true("2" in str(e) and "3" in str(e), f"报错应给出声明端口数与实际节点数，实测：{e}")


# ==========================================================================
# 错误路径
# ==========================================================================
@case(group="错误路径")
def test_validation_errors_are_dual_typed():
    """编译期的节点/位号错误必须同时是 CCLNetlistError 和 NodeError/RefError（D4）。

    防的是：调用方写 `except NodeError` 结果捕不到（或反过来），
    于是错误在两层之间裸奔成 traceback。
    """
    c = Circuit("dang")
    c.V("in", GND, dc=1)
    c.R("in", "out", 1e3)
    c.C("out", "nowhere", 1e-9)
    e = raises(CCLNetlistError, compile_circuit, c, ".op", what="悬空节点")
    is_true(isinstance(e, NodeError), f"应同时是 NodeError，实测 {type(e).__mro__[:3]}")
    is_true(getattr(e, "node", None) == "nowhere", f"异常应带 .node='nowhere'，实测 {getattr(e, 'node', None)!r}")
    is_true(getattr(e, "ref", None) == "C1", f"异常应带 .ref='C1'，实测 {getattr(e, 'ref', None)!r}")

    c2 = Circuit("dup")
    c2.V("in", GND, dc=1)
    c2.components.append(Component(kind="R", ref="R1", pins=[Pin("a", "in"), Pin("b", GND)], value=1e3))
    c2.components.append(Component(kind="R", ref="R1", pins=[Pin("a", "in"), Pin("b", GND)], value=2e3))
    e2 = raises(CCLNetlistError, compile_circuit, c2, ".op", what="重复位号（绕过 add）")
    is_true(isinstance(e2, RefError), f"应同时是 RefError，实测 {type(e2).__mro__[:3]}")
    is_true("R1" in str(e2), f"报错应点名 R1，实测：{e2}")


@case(group="错误路径")
def test_empty_and_nan_rejected():
    """空电路、nan 参数、未知参数名都必须编译失败并指明位置。

    防的是：空网表让 ngspice 回一条伪向量；nan 参数让仿真给出无意义结果。
    """
    e = raises(CCLNetlistError, compile_circuit, Circuit("empty"), ".op", what="空电路")
    is_true("没有任何器件" in str(e), f"报错应说明没有器件，实测：{e}")

    # nan 在 devices 层就被拦了（器件构造时校验），这里绕过构造直接塞进 value，
    # 模拟「别处来的 Circuit / 用户手工改过 value」—— 编译层必须也兜住。
    c = Circuit("nan")
    c.V("in", GND, dc=1)
    r = c.R("in", GND, 1e3)
    r.value = float("nan")
    e2 = raises(CCLNetlistError, compile_circuit, c, ".op", what="nan 阻值")
    is_true(getattr(e2, "ref", None) == "R1", f"报错应带 ref=R1，实测 {getattr(e2, 'ref', None)!r}")

    raises(CCLConfigError, Circuit("x").R, "a", GND, 1e3, bogus=1, what="器件未知关键字")


@case(group="错误路径")
def test_value_token_whitespace_rejected():
    """器件给出的值 token 内部含空白必须报错（防把网表行拆错列）。

    防的是：像 `PULSE(0 5 0 1n …)` 这样带空格的 token —— 网表会多出几列，
    ngspice 读到的是错位的节点/值，错误信息完全指不到源头。
    （M2 因此把 PULSE/SIN 统一改成逗号分隔，见 CONTRACT。）
    """

    class BadTok(Component):
        def value_tokens(self):
            return ["1 0"]

    c = Circuit("tok")
    c.V("in", GND, dc=1)
    c.add(BadTok(kind="R", ref="RX", pins=[Pin("a", "in"), Pin("b", GND)]))
    e = raises(CCLNetlistError, compile_circuit, c, ".op", what="值 token 含空白")
    is_true("空白" in str(e), f"报错应说明值字段含空白，实测：{e}")

    class EmptyTok(Component):
        def value_tokens(self):
            return []

    c2 = Circuit("tok2")
    c2.V("in", GND, dc=1)
    c2.add(EmptyTok(kind="R", ref="RY", pins=[Pin("a", "in"), Pin("b", GND)]))
    e2 = raises(CCLNetlistError, compile_circuit, c2, ".op", what="值 token 为空")
    is_true("数值" in str(e2) or "模型" in str(e2), f"报错应说明缺值字段，实测：{e2}")


@case(group="错误路径")
def test_analysis_card_validation():
    """分析卡必须 '.' 开头，且不能夹带 .end；analysis=None 时不输出任何分析卡。

    防的是：把 ".ac dec 200 1 1meg" 写成 "ac dec …"，ngspice 把它当器件行，
    静默不跑任何分析 → 「仿真未产生有效波形」。
    """
    c = _rc()
    raises(CCLNetlistError, compile_circuit, c, "ac dec 10 1 1k", what="分析卡不以 . 开头")
    raises(CCLNetlistError, compile_circuit, c, ".op\n.end", what="分析卡含 .end")
    net = compile_circuit(c, None)
    is_false(".ac" in net or ".op" in net or ".tran" in net, f"analysis=None 时不应有分析卡：{net}")


@case(group="错误路径")
def test_control_block_rejected_everywhere():
    """★回归（D1）：`.control` 出现在 directives / 器件 directives / 分析卡里都要拒收。

    为什么必须硬拦：copilot.sim 靠「网表里有没有 .control」决定要不要注入
    `set filetype=ascii / run / write c.raw all`。手写一份 → 波形不落盘 →
    上层拿到空波形 → 报「仿真未产生有效波形」，而错处完全不在这句话附近。
    """
    c = _rc()
    c.directive(".control")
    e = raises(CCLNetlistError, compile_circuit, c, ".op", what="directive 里含 .control")
    is_true("不要手写" in str(e) and "c.ac()" in str(e),
            f"报错应给出可操作的修法（用 c.ac()），实测：{e}")

    c2 = _rc()
    c2.directive(".subckt D a b\n.control\nrun\n.endc\n.ends")
    raises(CCLNetlistError, compile_circuit, c2, ".op", what="多行指令块里夹带 .control")

    class Evil(Component):
        def value_tokens(self):
            return ["1000"]

        def directives(self):
            return [".control\nrun\n.endc"]

    c3 = _rc()
    c3.add(Evil(kind="R", ref="R9", pins=[Pin("a", "in"), Pin("b", GND)]))
    raises(CCLNetlistError, compile_circuit, c3, ".op", what="器件 directives() 里含 .control")

    raises(CCLNetlistError, compile_circuit, _rc(), ".control\nrun\n.endc",
           what="分析卡位置塞 .control")

    # 合法指令不能被误伤
    c4 = _rc()
    c4.directive(".model DX D(Is=1e-14)")
    c4.directive(".param VP=1.5")
    net = compile_circuit(c4, ".op")
    is_true(".model DX" in net and ".param VP=1.5" in net, "合法的 .model/.param 不能被 .control 检查误伤")


@case(group="错误路径")
def test_compile_rejects_non_circuit():
    """编译入口传错类型要报清晰的错，而不是 AttributeError。"""
    e = raises(CCLNetlistError, compile_circuit, {"not": "a circuit"}, ".op", what="传 dict")
    is_true("Circuit" in str(e), f"报错应说明需要 Circuit，实测：{e}")


# ==========================================================================
# params / 端到端
# ==========================================================================
@case(group="params 与端到端")
def test_params_key_value_output():
    """params 输出成 key=value，且器件自己已写过的键不再重复写（D3）。

    防的是：同一个参数写两遍 `R1 in 0 1000 temp=27 temp=27` —— ngspice 报
    duplicate parameter，或者取到一个不确定的值。
    """
    c = Circuit("p")
    c.V("in", GND, dc=1)
    r = c.R("in", GND, 1e3)
    r.params["temp"] = 27.0
    net = compile_circuit(c, ".op")
    is_true("R1 in 0 1000 temp=27" in net, f"params 应输出成 key=value，实测器件行：{_device_lines(net)}")

    class SelfParam(Component):
        def value_tokens(self):
            return ["1000", "tc=0.5"]

    c2 = Circuit("p2")
    c2.V("in", GND, dc=1)
    c2.add(SelfParam(kind="R", ref="R1", pins=[Pin("a", "in"), Pin("b", GND)],
                     params={"tc": 0.5}))
    net2 = compile_circuit(c2, ".op")
    is_true(net2.count("tc=") == 1, f"器件已写过的参数不应重复输出，实测：{_device_lines(net2)}")


@case(group="params 与端到端")
def test_compiled_netlist_runs_without_runner():
    """★M1 验收 6：编译产物不经 runner 也能被 ngspice 直接跑通。

    防的是：网表里偷偷依赖 runner 注入的东西（分析卡、控制块）。
    这条是「编译层与仿真层解耦」的守护。
    """
    H.need_ngspice()
    c = _rc(r=1e3, c=159.154943091895e-9)      # fc = 1 kHz
    net = compile_circuit(c, ".ac dec 200 1 100meg")
    from copilot import sim

    res = sim.run(net)
    waves = {k: v for k, v in res.waves.items()}
    is_true("v(out)" in waves, f"应能读到 v(out)，实测波形 {sorted(waves)}")
    db = waves["v(out)"].db()
    ref = db[0]
    target = ref - 3.0103
    f3 = None
    for i in range(1, len(db)):
        if db[i] <= target:
            f0, f1 = math.log10(waves["v(out)"].x[i - 1]), math.log10(waves["v(out)"].x[i])
            t = (db[i - 1] - target) / (db[i - 1] - db[i])
            f3 = 10 ** (f0 + t * (f1 - f0))
            break
    close(f3, 1e3, 0.01, what="直接从编译产物读出的 −3dB 频率（理论 1 kHz）")


@case(group="params 与端到端")
def test_pulse_and_sin_tokens_have_no_space():
    """★M2 硬约束：PULSE/SIN 的 token 必须是逗号分隔、不含空白，且能被 ngspice 解析。

    防的是：有人为了好看把 `PULSE(0,5,…)` 改回空格形式 —— 会撞上编译层
    「token 不得含空白」的保护，一秒钟内整条激励链全挂。
    """
    H.need_ngspice()
    c = Circuit("stim")
    c.PULSE("a", GND, v1=0, v2=5, td=0, tr=1e-9, tf=1e-9, pw=1e-3, per=2e-3)
    c.SIN("b", GND, vo=0, va=1, freq=1e3)
    c.R("a", GND, 1e3)
    c.R("b", GND, 1e3)
    net = compile_circuit(c, ".tran 1u 100u")
    pulse_tok = next(t for ln in net.splitlines() if "PULSE" in ln for t in ln.split() if t.startswith("PULSE"))
    sin_tok = next(t for ln in net.splitlines() if "SIN(" in ln for t in ln.split() if t.startswith("SIN"))
    is_true("," in pulse_tok, f"PULSE 参数应用逗号分隔，实测 {pulse_tok!r}")
    is_false(any(ch.isspace() for ch in pulse_tok), f"PULSE token 不能含空白，实测 {pulse_tok!r}")
    is_false(any(ch.isspace() for ch in sin_tok), f"SIN token 不能含空白，实测 {sin_tok!r}")
    from copilot import sim

    res = sim.run(net)              # 跑得通 = token 被正确解析
    is_true("v(a)" in res.waves, f"含 PULSE 的网表应能跑，实测波形 {sorted(res.waves)}")


if __name__ == "__main__":
    sys.exit(H.main("test_compile", "test_compile：网表编译"))
