"""电路图渲染（`web/ide/schematic.js`）：从 Python 侧调用并核对 SVG 几何。

`schematic.js` 是 **ES module（纯字符串拼接、不碰 DOM）**，项目里没有
`package.json type=module`，所以 `import` 它会当成 CJS 报 SyntaxError。
本文件的做法（沿用 `tests_ui/schematic_selfcheck.mjs` 的可靠路径）：

    1. 读源码 → base64 → `import('data:text/javascript;base64,...')`
       （等价于浏览器的 <script type="module">，测的是同一份源码）
    2. 用一次 `node --input-type=module -e <driver>` 把需要的电路**全部**渲染出来，
       SVG 字符串走 stdout 回 Python
    3. 断言全部在 Python 侧做（本套件只有一种断言风格：期望值 vs 实测值）

没装 node 时整组 Skip（不是失败）—— 但会写进汇总，不会被静默忽略。

## 这一层防什么

  · **布局顺序**：源必须画在最左（V1.x < R1.x < C1.x）。顺序错了图还能看，
    但读者会沿着信号流读错方向。
  · **符号降级**：未知 kind 不许抛异常（代码跑不通时面板会整块崩），
    必须降级成方框且位号仍然显示。
  · **空电路**：返回空态提示、**不产出 `<svg>`**（一个空壳 SVG 会盖掉提示文字）。
  · **连接正确性（最重要）**：把 SVG 里带 `data-net` 的线段按「电路图阅读规则」
    重建连通性 —— **只认共享端点**（L 角 / T 型接点），纯十字交叉不算连通
    （没有实心圆点的交叉就是不连接，这是电路图通用约定）。然后断言：
      ① 没有悬空引脚（每个引脚都落在某条线上）
      ② 同一个几何连通块里不出现两个不同网络（那是「接错了」）
      ③ 同一网络的所有引脚都在同一个连通块里（那是「线断了」）
    契约里写得很直白：**丑可以接受，接错不行。**

反推器自己也有一条用例（`test_connectivity_analyzer_rules`）：拿人工构造的两段线
验证「十字交叉不算连通、T 型接点算连通」。否则上面那三条可能因为「什么都算连通」
而全部空过 —— 这种测试比没有测试更危险。
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import Fail, case, is_true, skip  # noqa: E402

SCHEMATIC_SRC = os.path.join(_ROOT, "web", "ide", "schematic.js")

# --------------------------------------------------------------------------
# 被测电路（喂给 renderSchematic 的普通对象，字段与 ccl 序列化后一致）
# --------------------------------------------------------------------------
def _circuit(name, nodes, comps):
    return {
        "name": name,
        "nodes": nodes,
        "components": [
            {"ref": r, "kind": k, "value_text": v, "pins": list(p), "pin_nodes": dict(pn)}
            for (r, k, v, p, pn) in comps
        ],
    }


# 1. RC 低通：3 元件，源在左，信号 in → out
RC = _circuit("rc_lowpass", ["in", "0", "out"], [
    ("V1", "V", "AC 1V", ["a", "b"], {"a": "in", "b": "0"}),
    ("R1", "R", "1.6kΩ", ["a", "b"], {"a": "in", "b": "out"}),
    ("C1", "C", "100nF", ["a", "b"], {"a": "out", "b": "0"}),
])

# 2. 级联：RC + 同相放大，6 元件（含内联位号 U1.R1 与运放 U2.X1）
CASCADE = _circuit("two_stage", ["src", "0", "n1", "U2.sum", "y"], [
    ("V1", "V", "AC 1V", ["a", "b"], {"a": "src", "b": "0"}),
    ("U1.R1", "R", "1.59kΩ", ["a", "b"], {"a": "src", "b": "n1"}),
    ("U1.C1", "C", "100nF", ["a", "b"], {"a": "n1", "b": "0"}),
    ("U2.R1", "R", "1kΩ", ["a", "b"], {"a": "U2.sum", "b": "0"}),
    ("U2.R2", "R", "9kΩ", ["a", "b"], {"a": "y", "b": "U2.sum"}),
    ("U2.X1", "X", "OPA_100000_1p3e06", ["inp", "inn", "out"],
     {"inp": "n1", "inn": "U2.sum", "out": "y"}),
])

# 3. 三引脚网络：out 同时接 R1 / C1 / R2 → 母线上必须有实心圆点
THREE_PIN = _circuit("rc_three_pin", ["in", "0", "out"], [
    ("V1", "V", "AC 1V", ["a", "b"], {"a": "in", "b": "0"}),
    ("R1", "R", "1.6kΩ", ["a", "b"], {"a": "in", "b": "out"}),
    ("C1", "C", "100nF", ["a", "b"], {"a": "out", "b": "0"}),
    ("R2", "R", "1kΩ", ["a", "b"], {"a": "out", "b": "0"}),
])

# 4. 未知 kind：Z9 不在 9 种符号里（R/C/L/V/I/D/Q/M/X）
UNKNOWN_KIND = _circuit("weird", ["in", "0", "out"], [
    ("V1", "V", "DC 1V", ["a", "b"], {"a": "in", "b": "0"}),
    ("Z9", "Z", "MYSTERY", ["a", "b"], {"a": "in", "b": "out"}),
    ("C1", "C", "10nF", ["a", "b"], {"a": "out", "b": "0"}),
])

# 空电路的四种「空」写法（面板可能传任何一种）
EMPTY_VARIANTS = {
    "null": None,
    "empty_obj": {},
    "empty_components": {"components": []},
    "named_empty": {"name": "empty", "nodes": [], "components": []},
}

# 连接性反推要覆盖的拓扑（至少 RC 与级联；分压器顺带一起）
NET_CASES = {"rc": RC, "cascade": CASCADE, "three_pin": THREE_PIN}

# --------------------------------------------------------------------------
# node 侧 driver（写死在这里，不落盘：tests_ccl/ 只留测试文件）
# --------------------------------------------------------------------------
_NODE_DRIVER = r"""
import fs from 'node:fs';
const src = fs.readFileSync(process.env.CCL_SCHEMATIC_SRC, 'utf8');
const mod = await import('data:text/javascript;base64,'
  + Buffer.from(src, 'utf8').toString('base64'));
const payload = JSON.parse(fs.readFileSync(0, 'utf8'));
const out = { node: process.version, cases: {}, empty: {}, exports: Object.keys(mod) };
for (const [name, circ] of Object.entries(payload.cases || {})) {
  try {
    out.cases[name] = { ok: true, svg: mod.renderSchematic(circ, payload.opts || {}) };
  } catch (e) {
    out.cases[name] = { ok: false, error: String((e && e.message) || e) };
  }
}
for (const [name, val] of Object.entries(payload.empty || {})) {
  try {
    out.empty[name] = { ok: true, html: mod.schematicOrEmpty(val) };
  } catch (e) {
    out.empty[name] = { ok: false, error: String((e && e.message) || e) };
  }
}
process.stdout.write(JSON.stringify(out));
"""

_RENDER: dict = {}


def _render_all() -> dict:
    """调一次 node，把全部电路渲染成 SVG（结果缓存，后续用例共用）。"""
    if _RENDER:
        return _RENDER
    node = shutil.which("node") or shutil.which("nodejs")
    if not node:
        skip("环境里没有 node，跳过电路图渲染的断言（纯 Node 侧自测不参与本套件）")
    if not os.path.isfile(SCHEMATIC_SRC):
        raise Fail(f"找不到 {SCHEMATIC_SRC}（电路图渲染的源码不在了，这不是环境问题）")

    payload = {
        "cases": dict(NET_CASES, unknown_kind=UNKNOWN_KIND),
        "empty": EMPTY_VARIANTS,
        "opts": {"theme": "dark"},
    }
    env = dict(os.environ)
    env["CCL_SCHEMATIC_SRC"] = SCHEMATIC_SRC
    try:
        proc = subprocess.run(
            [node, "--input-type=module", "-e", _NODE_DRIVER],
            input=json.dumps(payload), capture_output=True, text=True,
            env=env, cwd=_ROOT, timeout=180,
        )
    except subprocess.TimeoutExpired:
        raise Fail("渲染电路图超时（node 180s 没返回）—— schematic.js 里可能有无限循环") from None
    if proc.returncode != 0:
        raise Fail(
            f"node 渲染失败（退出码 {proc.returncode}）："
            f"{(proc.stderr or proc.stdout or '').strip().splitlines()[-1:]}"
        )
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        raise Fail(
            f"node 的输出不是 JSON：{proc.stdout[:200]!r}（stderr：{proc.stderr[:200]!r}）"
        ) from None
    _RENDER.update(data)
    return _RENDER


def _svg(name: str) -> str:
    """取某个电路的 SVG；渲染抛异常直接判失败（除了 unknown-kind 那条专门测它）。"""
    data = _render_all()
    got = data["cases"].get(name)
    if got is None:
        raise Fail(f"node 侧没有返回电路 {name!r} 的渲染结果（driver 与用例不一致？）")
    if not got.get("ok"):
        raise Fail(f"渲染电路 {name!r} 抛了异常：{got.get('error')!r}")
    return got["svg"]


# --------------------------------------------------------------------------
# SVG 解析小工具（只认本项目约定的 data-* 属性）
# --------------------------------------------------------------------------
_ATTR = re.compile(r'([a-zA-Z_:][-a-zA-Z0-9_:.]*)="([^"]*)"')
_LINE = re.compile(r"<line\s+([^>]*?)/>")
_G_OPEN = re.compile(r"<g\s+([^>]*?)>")


def _attrs(text: str) -> dict:
    return {m.group(1): m.group(2) for m in _ATTR.finditer(text)}


def _count(svg: str, tag: str) -> int:
    return len(re.findall(r"<" + tag + r"[\s>/]", svg))


def _groups(svg: str) -> dict[str, dict]:
    """按 data-ref 取每个元件的 <g> 属性（含 data-x / data-mode / data-pins）。"""
    out: dict[str, dict] = {}
    for m in _G_OPEN.finditer(svg):
        a = _attrs(m.group(1))
        if "data-ref" in a:
            out[a["data-ref"]] = a
    return out


def _lines(svg: str) -> list[dict]:
    """所有 <line> 的几何 + 属性（含装饰线，data-net 可能为空）。"""
    segs = []
    for m in _LINE.finditer(svg):
        a = _attrs(m.group(1))
        try:
            seg = {"net": a.get("data-net", ""),
                   "x1": float(a["x1"]), "y1": float(a["y1"]),
                   "x2": float(a["x2"]), "y2": float(a["y2"])}
        except (KeyError, ValueError):
            continue
        segs.append(seg)
    return segs


def _pins(svg: str) -> list[dict]:
    """每个元件声明的引脚落点：`data-pins="net@x,y net@x,y"`。"""
    pins = []
    for ref, a in _groups(svg).items():
        for tok in (a.get("data-pins") or "").split(" "):
            if not tok:
                continue
            if "@" not in tok or "," not in tok:
                raise Fail(f"元件 {ref} 的 data-pins 格式异常：{tok!r}")
            net, xy = tok.rsplit("@", 1)
            x, y = xy.split(",", 1)
            pins.append({"ref": ref, "net": net, "x": float(x), "y": float(y)})
    return pins


def _dist_to_seg(px: float, py: float, s: dict) -> float:
    dx, dy = s["x2"] - s["x1"], s["y2"] - s["y1"]
    len2 = dx * dx + dy * dy
    t = 0.0 if len2 == 0 else ((px - s["x1"]) * dx + (py - s["y1"]) * dy) / len2
    t = max(0.0, min(1.0, t))
    return ((px - (s["x1"] + t * dx)) ** 2 + (py - (s["y1"] + t * dy)) ** 2) ** 0.5


_ON_TOL = 0.6      # 与 schematic.js 自测同一容差（viewBox 单位，坐标都被 f() 取到 0.1）


def _on_seg(px: float, py: float, s: dict) -> bool:
    return _dist_to_seg(px, py, s) <= _ON_TOL


def reverse_engineer(svg: str) -> dict:
    """按**电路图阅读规则**从 SVG 几何反推连通性。

    规则（与 `web/ide/CONTRACT_SCHEMATIC.md` 一致）：
      · 两条走线只在「一方的端点落在另一方身上」时连通（L 角、T 型接点）
      · 纯十字交叉（交点落在两者内部）**不连通** —— 那要靠实心圆点标注，
        但圆点属于「画法」，这里只核对几何不误导
      · 网络归属只认 data-net（母线 + 引脚短线都带它）

    返回 {"segs","pins","groups","floating","mixed","split"}；后三个都是
    「必须为空」的违规清单，所以失败时能直接说清是哪一类错。
    """
    segs = [s for s in _lines(svg) if s["net"]]
    pins = _pins(svg)

    parent = list(range(len(segs)))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i: int, j: int) -> None:
        a, b = find(i), find(j)
        if a != b:
            parent[a] = b

    for i in range(len(segs)):
        for j in range(i + 1, len(segs)):
            a, b = segs[i], segs[j]
            joined = any(_on_seg(x, y, b) for x, y in ((a["x1"], a["y1"]), (a["x2"], a["y2"])))
            if not joined:
                joined = any(_on_seg(x, y, a) for x, y in ((b["x1"], b["y1"]), (b["x2"], b["y2"])))
            if joined:
                union(i, j)

    # 引脚贴回几何连通块
    pin_owner: list[int] = []
    floating: list[str] = []
    for p in pins:
        owner = -1
        for i, s in enumerate(segs):
            if _on_seg(p["x"], p["y"], s):
                if owner < 0:
                    owner = i
                else:
                    union(owner, i)
        if owner < 0:
            floating.append(f"{p['ref']}.{p['net']}@({p['x']:g},{p['y']:g})")
            pin_owner.append(-1)
        else:
            pin_owner.append(find(owner))
    pin_owner = [(-1 if o < 0 else find(o)) for o in pin_owner]

    groups: dict[int, dict] = {}
    for i, s in enumerate(segs):
        groups.setdefault(find(i), {"nets": set(), "pins": []})["nets"].add(s["net"])
    for i, p in enumerate(pins):
        if pin_owner[i] < 0:
            continue
        g = groups.setdefault(pin_owner[i], {"nets": set(), "pins": []})
        g["nets"].add(p["net"])
        g["pins"].append(p)

    mixed = ["+".join(sorted(g["nets"])) for g in groups.values() if len(g["nets"]) > 1]

    by_net: dict[str, set] = {}
    for i, p in enumerate(pins):
        key = "float" if pin_owner[i] < 0 else str(pin_owner[i])
        by_net.setdefault(p["net"], set()).add(key)
    split = [f"{net} 分散在 {len(blks)} 个连通块" for net, blks in by_net.items() if len(blks) > 1]

    return {"segs": len(segs), "pins": len(pins), "groups": len(groups),
            "floating": floating, "mixed": mixed, "split": split}


# ==========================================================================
# 布局与符号
# ==========================================================================
@case(group="布局与符号")
def test_rc_lowpass_layout_and_wires():
    """RC 低通：完整 `<svg>`、3 个 data-ref、源在左（V1.x < R1.x < C1.x）、走线全正交。

    防的是：把元件按「器件加入顺序」而不是信号流排列（读者会读反），
    以及画出斜线连接（契约：**只用正交走线**，斜线在电路图上读不出是连接）。
    """
    svg = _svg("rc")
    is_true(svg.startswith("<svg") and svg.endswith("</svg>"),
            f"应产出完整的 <svg> 根元素，实测开头 {svg[:40]!r} / 结尾 {svg[-20:]!r}")

    groups = _groups(svg)
    refs = sorted(groups)
    is_true(refs == ["C1", "R1", "V1"], f"应恰好 3 个 data-ref：V1/R1/C1，实测 {refs}")

    xs = {}
    for ref in ("V1", "R1", "C1"):
        raw = groups[ref].get("data-x")
        is_true(raw is not None, f"{ref} 缺少 data-x（几何断言无从下手）")
        xs[ref] = float(raw)
    is_true(xs["V1"] < xs["R1"], f"源应在左：期望 V1.x < R1.x，实测 V1.x={xs['V1']:g} R1.x={xs['R1']:g}")
    is_true(xs["R1"] < xs["C1"], f"信号从左到右：期望 R1.x < C1.x，实测 R1.x={xs['R1']:g} C1.x={xs['C1']:g}")

    lines = _lines(svg)
    is_true(len(lines) > 0, "没有任何 <line>（几何一团空）")
    diag = [s for s in lines
            if abs(s["x1"] - s["x2"]) > 0.01 and abs(s["y1"] - s["y2"]) > 0.01]
    is_true(not diag,
            f"所有走线必须正交（水平/垂直），实测 {len(diag)} 条斜线：{diag[:3]}")

    # 一端接地的元件应竖画（V1 / C1 都有一端接 0），两端都不接地的 R1 横放
    is_true(groups["V1"].get("data-mode") == "v",
            f"V1（下端接 GND）应竖画，实测 data-mode={groups['V1'].get('data-mode')!r}")
    is_true(groups["C1"].get("data-mode") == "v",
            f"C1（下端接 GND）应竖画，实测 data-mode={groups['C1'].get('data-mode')!r}")
    is_true(groups["R1"].get("data-mode") == "h",
            f"R1（两端都不接地）应横画，实测 data-mode={groups['R1'].get('data-mode')!r}")
    is_true(_count(svg, "text") >= 6,
            f"至少 6 个 <text>（3 位号 + 3 值 + GND），实测 {_count(svg, 'text')}")


@case(group="布局与符号")
def test_cascade_six_components():
    """级联（6 元件，含内联位号 U1.R1 与运放 U2.X1）：6 个 data-ref，位号出现在文本里。

    防的是：内联位号（`U1.R1`）在图上被截断或转义（比如把点当成属性分隔），
    以及运放被画成方框（三角形是运放的电路图记法，方框会和未知器件混淆）。
    """
    svg = _svg("cascade")
    groups = _groups(svg)
    is_true(len(groups) == 6, f"应有 6 个元件分组，实测 {len(groups)}：{sorted(groups)}")
    for ref in ("V1", "U1.R1", "U1.C1", "U2.R1", "U2.R2", "U2.X1"):
        is_true(ref in groups, f"缺少元件分组 {ref}，实测 {sorted(groups)}")
    is_true("U2.X1" in svg, "位号 U2.X1 必须出现在 SVG 文本里")

    # 运放画成三角形（3 个顶点的 polygon）
    x1 = _g_inner(svg, "U2.X1")
    tri = re.search(r'<polygon points="([^"]+)"', x1 or "")
    is_true(tri is not None, f"运放 U2.X1 内部没有 <polygon>（三角形），实测片段：{(x1 or '')[:80]!r}")
    n_pts = len(tri.group(1).split())
    is_true(n_pts == 3, f"运放三角形应是 3 顶点多边形，实测 {n_pts} 顶点")


@case(group="布局与符号")
def test_three_pin_net_has_junction_dot():
    """三引脚网络（out 接 R1/C1/R2）：必须出现 `data-junction="1"` 的实心圆点。

    防的是：T 型接点没有圆点标注 —— 按电路图约定，没有圆点的十字/t 型交叉
    就是「不连接」，于是同一根母线看起来像两条互不相干的线，读者会读成开路。
    """
    svg = _svg("three_pin")
    dots = len(re.findall(r'data-junction="1"', svg))
    is_true(dots >= 1,
            f"三引脚网络的母线上应有实心圆点（data-junction=\"1\"），实测 {dots} 个")
    is_true(_count(svg, "circle") >= dots,
            f"圆点数 {dots} 不该超过 <circle> 总数 {_count(svg, 'circle')}")


@case(group="布局与符号")
def test_unknown_kind_degrades_to_rect():
    """未知 kind（Z9）：不抛异常、降级成矩形、位号仍然显示。

    防的是：一个没见过的器件把整张图打成异常 —— 面板拿到空字符串，
    用户看到的是「图突然没了」，而且没有任何线索说明是哪个器件的问题。
    """
    data = _render_all()
    got = data["cases"]["unknown_kind"]
    is_true(got.get("ok"), f"未知 kind 不该抛异常，实测抛出：{got.get('error')!r}")
    svg = got["svg"]
    groups = _groups(svg)
    is_true("Z9" in groups, f"未知 kind 也要有 data-ref 分组，实测 {sorted(groups)}")
    z9 = groups["Z9"]
    is_true(z9.get("data-kind") == "Z",
            f"Z9 的 data-kind 应保留原 kind 'Z'，实测 {z9.get('data-kind')!r}")
    inner = _g_inner(svg, "Z9") or ""
    is_true("<rect" in inner, f"未知 kind 应降级成方框（<rect>），实测片段 {inner[:80]!r}")
    is_true("Z9" in svg, "位号 Z9 仍然必须显示（否则用户不知道图上那是什么）")


@case(group="布局与符号")
def test_empty_circuit_state():
    """空电路（null / {} / {components:[]} / 具名空）：给空态文字，且**不含 `<svg>`**。

    防的是：返回一个空壳 `<svg>`（面板上是一块空白，提示文字被盖掉），
    或者干脆抛异常。四种「空」的写法都必须走到同一个空态。
    """
    data = _render_all()
    empty = data.get("empty") or {}
    is_true(set(empty) == set(EMPTY_VARIANTS),
            f"node 侧应对 4 种空电路都返回结果，实测 {sorted(empty)}")
    for name in EMPTY_VARIANTS:
        got = empty[name]
        is_true(got.get("ok"), f"空电路 {name} 不该抛异常，实测 {got.get('error')!r}")
        html = got["html"]
        is_true("<svg" not in html, f"空电路 {name} 不该产出 <svg>，实测 {html[:80]!r}")
        is_true("还没有元件" in html, f"空电路 {name} 应有「还没有元件」提示，实测 {html[:120]!r}")


def _g_inner(svg: str, ref: str) -> str | None:
    """取某个 data-ref 的 <g>…</g> 内部（本项目不嵌套同名 g，够用）。"""
    pat = re.compile(r'<g[^>]*data-ref="' + re.escape(ref) + r'"[^>]*>(.*?)</g>', re.S)
    m = pat.search(svg)
    return m.group(1) if m else None


# ==========================================================================
# 连接性反推（底线）
# ==========================================================================
@case(group="连接性")
def test_connectivity_analyzer_rules():
    """先验证**反推器自己**：十字交叉不算连通、T 型接点算连通。

    为什么必须先测工具：下面两条「连接一致」的用例，如果反推器把所有线段都
    合并成一个连通块，它们会**全部空过**（既没有悬空、也没有串网、也没有断线）。
    那种测试比没有测试更危险。所以这里拿人工构造的 SVG 断言：
      · 两条线在内部十字交叉 → 2 个独立连通块
      · 一条线的端点落在另一条线上（T 型）→ 1 个连通块
    """
    cross = (
        '<svg>'
        '<line x1="0" y1="50" x2="100" y2="50" data-net="A"/>'
        '<line x1="50" y1="0" x2="50" y2="100" data-net="B"/>'
        '</svg>'
    )
    r = reverse_engineer(cross)
    is_true(r["segs"] == 2, f"十字交叉用例应有 2 段线，实测 {r['segs']}")
    is_true(r["groups"] == 2,
            f"纯十字交叉**不算**连通：期望 2 个连通块，实测 {r['groups']}")

    tee = (
        '<svg>'
        '<line x1="0" y1="50" x2="100" y2="50" data-net="A"/>'
        '<line x1="50" y1="50" x2="50" y2="100" data-net="A"/>'
        '</svg>'
    )
    r = reverse_engineer(tee)
    is_true(r["groups"] == 1,
            f"端点落在对方身上（T 型接点）算连通：期望 1 个连通块，实测 {r['groups']}")

    # 串联/断线也必须能分辨：引脚落在孤立的另一段线上 → 同一网络两块
    broken = (
        '<svg>'
        '<g data-ref="R1" data-pins="A@0,50 A@50,50"><line x1="0" y1="50" x2="20" y2="50" data-net="A"/></g>'
        '<g data-ref="R2" data-pins="A@80,50 A@100,50"><line x1="80" y1="50" x2="100" y2="50" data-net="A"/></g>'
        '</svg>'
    )
    r = reverse_engineer(broken)
    is_true(len(r["split"]) == 1,
            f"同一网络落在两个互不连接的线段上应被报为断线，实测 split={r['split']}")
    is_true(len(r["floating"]) == 1,
            f"引脚 @50,50 不在任何线上，应被报为悬空，实测 floating={r['floating']}")


@case(group="连接性")
def test_connectivity_rc_and_cascade():
    """连接性反推：RC / 级联 / 三引脚 —— 无悬空引脚、无串网、无断线。

    这是整套电路图用例的底线（契约：**丑可以接受，接错不行**）：

      ① 每个引脚都落在某条线上（悬空 → 图上看不出这根线接去哪）
      ② 同一个几何连通块里不出现两个不同网络（串网 → 短路，最严重的错法）
      ③ 同一网络的所有引脚都在同一个连通块里（断线 → 看起来开路）

    先断言段数/引脚数都 > 0，否则「零违规」是空过。
    """
    for name in ("rc", "cascade", "three_pin"):
        svg = _svg(name)
        r = reverse_engineer(svg)
        is_true(r["segs"] >= 3, f"[{name}] 带 data-net 的走线段太少（{r['segs']}），反推没有意义")
        is_true(r["pins"] >= 4, f"[{name}] 解析出的引脚太少（{r['pins']}），反推没有意义")
        is_true(not r["floating"],
                f"[{name}] 有悬空引脚（没落在任何走线上）：{r['floating']}")
        is_true(not r["mixed"],
                f"[{name}] 同一个连通块里出现了多个网络（串网/短路）：{r['mixed']}")
        is_true(not r["split"],
                f"[{name}] 同一网络被画断在多个连通块里（断线）：{r['split']}")
        is_true(r["groups"] >= 2,
                f"[{name}] 连通块只有 {r['groups']} 个，说明反推把所有线合并了（用例失去意义）")


if __name__ == "__main__":
    sys.exit(H.main("test_schematic", "test_schematic：电路图渲染"))


# --------------------------------------------------------------------------
# 导线电流：`netCurrentSeries()`（KCL 残差 vs 单条支路）
#
# ⚑ 这一组**真的调用 JS 函数**，不是文本断言：把后端会发出的 timeline 形状喂给
# `timelineIndex()` + `netCurrentSeries()`，看它返回什么。文本断言只能证明源码里
# 「有个像样的注释」，只有真调用才能证明它算出来的数是对的。
# --------------------------------------------------------------------------
_NET_CURRENT_DRIVER = r"""
import fs from 'node:fs';
const src = fs.readFileSync(process.env.CCL_SCHEMATIC_SRC, 'utf8');
const mod = await import('data:text/javascript;base64,'
  + Buffer.from(src, 'utf8').toString('base64'));
const payload = JSON.parse(fs.readFileSync(0, 'utf8'));
const out = {};
for (const [name, c] of Object.entries(payload.cases || {})) {
  try {
    const idx = mod.timelineIndex(c.timeline);
    const res = {};
    for (const [net, list] of c.nets) {
      res[net] = mod.netCurrentSeries(list, idx, net, idx.t.length);
    }
    out[name] = { ok: true, tLen: idx.t.length, res };
  } catch (e) {
    out[name] = { ok: false, error: String((e && e.message) || e) };
  }
}
process.stdout.write(JSON.stringify(out));
"""


def _tl(series: dict, n: int = 3) -> dict:
    """按 `collect_timeline()` 的形状造一条时间序列（t/dt/series）。"""
    return {"t": [i * 1e-3 for i in range(n)], "dt": 1e-3, "series": series}


# 5V/220Ω/LED 回路：三个器件**串联**，电流完全相同（真实解）。
_LOOP_I = 0.01941
_NET_CASES = {
    # 一个网络两端的支路电流互为反号 → 求和恰好是 0（这就是 KCL 残差）
    "series_loop": {
        "timeline": _tl({
            "v1": {"current": [0.0, _LOOP_I, _LOOP_I]},
            "r1": {"current": [0.0, _LOOP_I, _LOOP_I]},
            "d1": {"current": [0.0, _LOOP_I, _LOOP_I]},
        }),
        "nets": [["src", [["V1", 1], ["R1", -1]]],
                 ["mid", [["R1", 1], ["D1", -1]]]],
    },
    # 并联网络：两条支路电流差一个量级。求和 = 0.023（KCL 不允许），取单条 = 0.020
    "parallel": {
        "timeline": _tl({
            "r1": {"current": [0.0, 0.003, 0.003]},
            "r2": {"current": [0.0, 0.020, 0.020]},
        }),
        "nets": [["p", [["R1", 1], ["R2", 1]]]],
    },
    # 一个支路没有数据 → 跳过它，别把整个网络丢掉
    "partial_missing": {
        "timeline": _tl({
            "r1": {"current": [0.0, 0.003, 0.003]},
        }),
        "nets": [["pm", [["R1", 1], ["X9", 1]]]],
    },
    # 一条都没有数据 → 必须返回 null（契约：没数据不画）
    "all_missing": {
        "timeline": _tl({
            "r1": {"current": [0.0, 0.003, 0.003]},
        }),
        "nets": [["am", [["X9", 1], ["X8", -1]]]],
    },
}

_NET_CURRENT: dict = {}


def _net_currents() -> dict:
    """跑一次 node，算出全部网络电流（缓存，后续用例共用）。"""
    if _NET_CURRENT:
        return _NET_CURRENT
    node = shutil.which("node") or shutil.which("nodejs")
    if not node:
        skip("环境里没有 node，跳过导线电流的 JS 断言")
    if not os.path.isfile(SCHEMATIC_SRC):
        raise Fail(f"找不到 {SCHEMATIC_SRC}（电路图渲染的源码不在了，这不是环境问题）")
    env = dict(os.environ)
    env["CCL_SCHEMATIC_SRC"] = SCHEMATIC_SRC
    try:
        proc = subprocess.run(
            [node, "--input-type=module", "-e", _NET_CURRENT_DRIVER],
            input=json.dumps({"cases": _NET_CASES}), capture_output=True,
            text=True, env=env, cwd=_ROOT, timeout=120,
        )
    except subprocess.TimeoutExpired:
        raise Fail("算网络电流超时（node 120s 没返回）") from None
    if proc.returncode != 0:
        raise Fail(f"node 调用 netCurrentSeries 失败（退出码 {proc.returncode}）："
                   f"{(proc.stderr or proc.stdout or '').strip().splitlines()[-1:]}")
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        raise Fail(f"node 的输出不是 JSON：{proc.stdout[:200]!r}"
                   f"（stderr：{proc.stderr[:200]!r}）") from None
    for name, got in data.items():
        if not got.get("ok"):
            raise Fail(f"网络 {name!r} 算电流时抛异常：{got.get('error')!r}")
    _NET_CURRENT.update(data)
    return _NET_CURRENT


def _net_series(case: str, net: str):
    got = _net_currents()[case]["res"].get(net)
    is_true(got is not None, f"[{case}/{net}] netCurrentSeries 返回了 null（应给出一条电流序列）")
    is_true(isinstance(got, list), f"[{case}/{net}] 应返回数组，实际 {type(got).__name__}")
    return got


def _peak_of(arr) -> float:
    return max(abs(v) for v in arr) if arr else 0.0


@case(group="导线电流")
def test_net_current_is_single_branch_not_kcl_sum():
    """★回归：一个网络的电流必须是**某一条支路**的电流，不是各支路之和。

    事故现场：`netCurrentSeries()` 曾把网络内所有支路电流相加 —— 那就是 KCL
    残差，正确解里恒等于 0。实测 5V/220Ω/LED 电路：支路 19.41mA，求和后网络
    基准是 2.84e-7 A（纯数值噪声，还被归一化成满亮）；另两个电路里内部网络的
    峰值正好 0.0 → 被 `peak<=0` 丢弃 → **一条导线都不流动**。

    这里喂的是**真实串联回路**的形状（三条支路电流完全相同，求和必然为 0）：
    求和实现会返回全 0（或直接 null），取单条实现会返回 ±19.41mA。
    """
    for net in ("src", "mid"):
        ser = _net_series("series_loop", net)
        peak = _peak_of(ser)
        is_true(peak >= 0.9 * _LOOP_I,
                f"[{net}] 网络电流峰值应≈{_LOOP_I * 1e3:.2f}mA（单条支路），"
                f"实测 {peak * 1e3:.6f}mA —— 全 0 说明又被写成了「各支路求和」")
        # 符号：sgn=+1 的支路注入本网络 → series = -I（负号来自「注入」约定）
        is_true(ser[1] < 0 and ser[2] < 0,
                f"[{net}] 电流方向（符号）不对：{ser}")


@case(group="导线电流")
def test_net_current_picks_one_branch_when_parallel():
    """★回归：并联网络取**单条**支路（这里取绝对值最大的），不是求和。

    判据用的是「求和 ≠ 取最大」：两条并联支路 3mA 与 20mA，求和得 23mA、
    取单条得 20mA。这两个数必须能区分开，否则用例抓不到「求和」的写法。
    """
    ser = _net_series("parallel", "p")
    peak = _peak_of(ser)
    close_abs_js(peak, 0.020, 1e-6,
                 "[p] 并联网络应取单条支路（20mA），不是求和（23mA）")


def close_abs_js(actual: float, theory: float, tol: float, what: str) -> None:
    """绝对容差比较（JS 侧浮点，不要相对误差那一套）。"""
    d = abs(actual - theory)
    is_true(d <= tol, f"{what}：期望 {theory:.6g} / 实测 {actual:.6g} / 偏差 {d:.6g}")


@case(group="导线电流")
def test_net_current_missing_branch_handling():
    """契约：**一条支路没数据 → 跳过它**（别用别的支路凑一个错数给整条网络收尸）；
    **全都没数据 → 返回 null**（没数据不画，绝不填 0）。

    早先的实现是「有一个端点没数据就整条网络返回 null」，于是并联支路里只要
    有一条取不到电流（例如开关在 .op 下），整段导线就永远不流动。
    """
    ser = _net_series("partial_missing", "pm")
    close_abs_js(_peak_of(ser), 0.003, 1e-9,
                 "[pm] 只有 R1 有数据时应取 R1 的电流")
    got = _net_currents()["all_missing"]["res"].get("am")
    is_true(got is None, f"[am] 全部支路都没数据时必须返回 null，实际 {got!r}")
