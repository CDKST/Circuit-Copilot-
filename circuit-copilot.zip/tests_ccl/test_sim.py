"""仿真入口与结果对象：runner（ac/op/tran）+ Solution（指标/节点名/地节点）。

这一层防的是「拿到了一堆波形，却读错了」：

  - 节点名大小写/包裹写法必须都命中（`out` / `V(out)` / `OUT`）
  - 找不到节点时必须**列出可用节点**（只报「不存在」的库最让人抓狂）
  - 扫频范围没覆盖转折点时必须返回 None，**不许编一个数**
  - 地节点在 SPICE 输出里根本没有波形 —— 任何取地电位的代码必须特判，
    否则接地器件的检查会被静默跳过（这是 M3 的一个真 bug，见 test_lint）
  - 仿真失败必须保留网表与原始输出（自纠全靠这两个字段）
"""

import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, close_abs, is_false, is_true, raises  # noqa: E402

from ccl.core import GND, Circuit  # noqa: E402
from ccl.errors import (  # noqa: E402
    CCLConfigError,
    CCLConvergenceError,
    CCLNetlistError,
    NodeError,
)
from ccl.runner import simulate  # noqa: E402

TAU = 2 * math.pi


def _rc(r=1.6e3, c=100e-9) -> Circuit:
    ckt = Circuit("rc")
    ckt.V("in", GND, ac=1)
    ckt.R("in", "out", r)
    ckt.C("out", GND, c)
    return ckt


# ==========================================================================
# AC 分析
# ==========================================================================
@case(group="ac")
def test_ac_solution_shape():
    """AC 结果的基本契约：kind / 频率轴 / 节点名 / 计时。

    防的是：分析卡里的点数被忽略（波形只有几个点，指标全靠插值瞎猜），
    或者 elapsed_ms 恒为 0（性能退化看不见）。
    """
    H.need_ngspice()
    sol = _rc().ac(1, 1e5, 100)
    is_true(sol.kind == "ac", f"kind 应为 'ac'，实测 {sol.kind!r}")
    is_true(len(sol.x) > 100, f"dec=100 从 1Hz 扫到 100kHz 应有 >100 点，实测 {len(sol.x)}")
    close(sol.x[0], 1.0, 1e-6, what="频率轴起点")
    close(sol.x[-1], 1e5, 1e-6, what="频率轴终点")
    is_true(sol.elapsed_ms > 0, f"elapsed_ms 应 > 0，实测 {sol.elapsed_ms}")
    is_true("out" in sol.node_names(), f"节点名里应有 out，实测 {sol.node_names()}")
    is_true(len(sol.netlist) > 0, "结果里应保留实际网表（自纠要用）")


@case(group="ac")
def test_node_name_variants():
    """`out` / `V(out)` / `OUT` 必须指向同一条波形（用户会各种写法）。

    防的是：只有小写一种写法能用 → 用户从 ngspice 文档里抄来的 `v(out)`
    直接查不到，而报错又没说"可以不加 v()"。
    """
    H.need_ngspice()
    sol = _rc().ac(1, 1e5, 50)
    base = sol.f3db("out")
    for name in ("V(out)", "v(OUT)", "OUT", " Out "):
        got = sol.f3db(name)
        close(got, base, 1e-9, what=f"f3db({name!r}) 与 f3db('out')")


@case(group="ac")
def test_unknown_node_lists_candidates():
    """不存在的节点必须抛 NodeError，且**列出可用节点名**。

    防的是：报错只说「没有这个节点」，用户面对 20 个节点无从下手 ——
    这类库最典型的挫败感来源。
    """
    H.need_ngspice()
    sol = _rc().ac(1, 1e5, 20)
    e = raises(NodeError, sol.v, "nope", what='v("nope")')
    is_true("out" in str(e) and "in" in str(e), f"报错应列出可用节点，实测：{e}")
    is_true("i(v1)" in str(e), f"报错应提示电流要写 i(...)，实测：{e}")
    is_false(sol.has_node("nope"), "has_node 对不存在的节点应返回 False")


@case(group="ac")
def test_current_wave_analytic():
    """电流波形 i(v1) 必须对上 |I| = |V| / |R + 1/(jωC)| —— 用解析式核对。

    防的是：只校验「有波形」而不管数值。源电流写错（比如把 AC 幅度丢掉当 0）
    时波形依然存在，只是恒为 0。
    """
    H.need_ngspice()
    r, c = 1.6e3, 100e-9
    sol = _rc(r, c).ac(1, 1e6, 300)
    is_true(sol.has_node("i(v1)"), f"应有 i(v1) 波形，实测 {sol.all_node_names()}")
    for f in (1e3, 1e5):
        i_meas = float(sol.value_at("i(v1)", f))
        i_theory = 1.0 / math.hypot(r, 1.0 / (TAU * f * c))
        close(i_meas, i_theory, 0.01, what=f"源电流 @ {f:g}Hz（解析 |V|/|Z|）")


@case(group="ac")
def test_f3db_covered_is_correct():
    """扫频覆盖了转折点时，f3db 必须给出正确的数（不能为了省事一律返回 None）。

    与下面那条 known_bug 用例配对：一条守「测到就要准」，一条守「没测到别编」。
    """
    H.need_ngspice()
    c = Circuit("slow")                     # fc = 1/(2π·1.6k·100µ) ≈ 0.995 Hz
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-6)
    sol = c.ac(1e-2, 1e3, 100)
    close(sol.f3db("out"), 1.0 / (TAU * 1.6e3 * 100e-6), 0.02, what="覆盖后的 f3db")


@case(group="ac")
def test_f3db_uncovered_returns_none():
    """★回归（曾经真出过）：扫频没覆盖转折点 → f3db 必须返回 None，不许编一个数。

    这道防线原来漏了：1Hz 低通从 100Hz 起扫时，f3db 会返回「区间内最高点 −3dB」
    的第一次穿越（≈141Hz）—— 一个物理上毫无意义的数。后果是所有基于 f3db 的
    规格断言都在假数据上"通过"（Solution.f3db 的 docstring 本来就承诺返回 None）。

    现在实现里加了「参考点附近必须有平坦段」的判据。这条用例盯住它别退回去。
    """
    H.need_ngspice()
    c = Circuit("slow")                     # fc ≈ 0.995 Hz
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-6)
    sol = c.ac(100, 1e6, 50)                # 从 100Hz 起扫：转折点在扫频范围之外
    got = sol.f3db("out")
    is_true(got is None,
            f"扫频未覆盖 −3dB 点时应返回 None，实测 {got!r}（真实的 fc ≈ 0.995Hz，"
            f"扫频从 100Hz 起）")


@case(group="ac")
def test_interpolation_accuracy_vs_points():
    """点的密度不该改变结论：60 点与 400 点算出的 f3db 差 <0.5%。

    防的是：指标直接用"最近的采样点"（不插值）。200 点/十倍频时误差可达 0.3%，
    60 点时能到 1.5% —— 于是「1kHz ±1%」这种断言会因为扫点密度而随机红。
    """
    H.need_ngspice()
    c = _rc()
    f60 = c.ac(1, 1e5, 60).f3db("out")
    f400 = c.ac(1, 1e5, 400).f3db("out")
    close(f60, f400, 0.005, what="60 点与 400 点算出的 f3db")


# ==========================================================================
# 工作点（op）
# ==========================================================================
@case(group="op")
def test_op_axis_and_values():
    """.op 没有真正的横轴：x 必须被填成 [0.0]，value_at(node, 0) 取直流电平。

    防的是：op 结果第一个变量被当成频率轴吞掉（历史上真发生过），
    于是 v(in) 凭空消失，看起来正常其实少了数据。
    """
    H.need_ngspice()
    c = Circuit("div")
    c.V("in", GND, dc=9.0)
    c.R("in", "a", 1e3)
    c.R("a", "b", 1e3)
    c.R("b", GND, 1e3)
    sol = c.op()
    is_true(sol.kind == "op", f"kind 应为 'op'，实测 {sol.kind!r}")
    is_true(all(v == 0.0 for v in sol.x), f"op 的横轴应全为 0，实测 {sol.x[:3]}")
    close(sol.value_at("in", 0.0), 9.0, 1e-6, what="v(in) 直流电平")
    close(sol.value_at("a", 0.0), 6.0, 1e-6, what="v(a)（9V 经 1k/1k 分压）")
    close(sol.value_at("b", 0.0), 3.0, 1e-6, what="v(b)（再分压一次）")


@case(group="op")
def test_ground_has_no_wave_in_raw_output():
    """★回归前提：SPICE 输出里**没有** 0 号节点的波形，所以取地电位必须特判。

    这条用例钉的是「坑本身」：`value_at("0", 0)` 会抛 NodeError（不是返回 0.0）。
    凡是要读接地器件电位的代码（电阻功耗、BJT/MOS 工作区检查）都必须先把
    地节点映射成 0V —— 否则整个检查会被静默跳过（M3 的真 bug，见 test_lint
    的 test_resistor_power_excludes_ground_silently 反向验证）。
    """
    H.need_ngspice()
    sol = _rc().op()
    is_false(sol.has_node("0"), f'仿真结果里不该有 "0" 波形，实测节点 {sol.all_node_names()}')
    raises(NodeError, sol.value_at, "0", 0.0, what='value_at("0", 0)')
    # 库里的正确做法：ccl.lint._volt() 特判地把地映射成 0.0
    from ccl.lint import _volt

    close(_volt(sol, "0"), 0.0, 1e-12, what='lint._volt(sol, "0")（必须是 0.0，不是 None）')
    is_true(_volt(sol, "GND") == 0.0, 'lint._volt(sol, "GND") 也应为 0.0')


# ==========================================================================
# 瞬态（tran）
# ==========================================================================
@case(group="tran")
def test_tran_axis_and_clamp():
    """瞬态：时间轴从 0 起、点足够密；value_at 超出范围时钳到端点。

    防的是：时间轴错（起点不是 0 会让"t=τ"读错位置），
    以及越界取值时返回 NaN 而不是端点（下游全部变成 NaN）。
    """
    H.need_ngspice()
    c = Circuit("p")
    c.PULSE("in", GND, v1=0, v2=5, td=0, tr=1e-9, tf=1e-9, pw=1e-3, per=2e-3)
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)
    sol = c.tran(1e-6, 500e-6)
    is_true(sol.kind == "tran", f"kind 应为 'tran'，实测 {sol.kind!r}")
    close(sol.x[0], 0.0, 1e-12, what="时间轴起点")
    is_true(len(sol.x) > 100, f"应有一百点以上，实测 {len(sol.x)}")
    v_end = sol.value_at("out", 10.0)          # 远超 t_stop
    close_abs(v_end, sol.value_at("out", sol.x[-1]), 1e-9,
              what="超出范围时应钳到最后一个点")
    close_abs(sol.value_at("out", -1.0), sol.value_at("out", 0.0), 1e-9,
              what="早于起点时应钳到第一个点")


# ==========================================================================
# 错误路径
# ==========================================================================
@case(group="错误路径")
def test_runner_argument_validation():
    """分析参数必须校验：f_stop>f_start、points>0、t_stop>t_step。

    防的是：把 stop 写在 start 前面（ngspice 可能静默不跑或只跑一个点）。
    """
    c = _rc()
    raises(CCLConfigError, c.ac, 1e5, 1.0, 10, what="f_stop < f_start")
    raises(CCLConfigError, c.ac, 1.0, 1e5, 0, what="points = 0")
    raises(CCLConfigError, c.ac, -1.0, 1e5, 10, what="负的 f_start")
    raises(CCLConfigError, c.tran, 1e-3, 1e-4, what="t_stop < t_step")


@case(group="错误路径")
def test_missing_analysis_card():
    """网表里没有分析卡必须报错，绝不能"跑一下"就给个空结果。

    防的是：ngspice 对没有分析卡的网表会回一条名为 all 的伪向量，
    上层把它当真实波形 → 用户看到一条假曲线。
    """
    H.need_ngspice()
    net = "* no analysis\nV1 in 0 dc 1\nR1 in 0 1000\n.end\n"
    e = raises(CCLNetlistError, simulate, _rc(), net, what="无分析卡的网表")
    is_true("分析卡" in str(e), f"报错应说明缺分析卡，实测：{e}")


@case(group="错误路径")
def test_sim_error_keeps_netlist_and_output():
    """仿真失败必须抛 CCLConvergenceError，并保留网表 + 原始输出。

    防的是：只抛一句「仿真失败」—— 自纠（AI 修复、人工排查）全靠
    `.netlist` 与 `.output` 这两个字段，丢了就只能重新猜。
    """
    H.need_ngspice()
    bad = ("* unknown subckt\nV1 in 0 dc 1\nR1 in out 1000\nC1 out 0 1u\n"
           "X1 in out UNKNOWNSUB\n.op\n.end\n")
    e = raises(CCLConvergenceError, simulate, _rc(), bad, what="未知子电路")
    is_true(len(e.netlist) > 0, "异常里应保留网表")
    is_true(len(e.output) > 0, "异常里应保留 ngspice 原始输出")
    is_true("unknown subckt" in (e.output + str(e)).lower(),
            f"原始输出里应能看到 ngspice 的原话，实测：{e.output[:120]!r}")


@case(group="错误路径")
def test_validate_runs_before_simulate():
    """check=True（默认）时，结构错误必须在起 ngspice 之前就报出来。

    防的是：把明显悬空的电路送去跑仿真，用户拿到一句「no convergence」，
    而真正的问题（少接一根线）一句话都没提到。
    """
    H.need_ngspice()
    c = Circuit("dang")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e3)
    c.C("out", "nowhere", 1e-9)
    raises(NodeError, c.ac, 1, 1e5, 10, what="悬空电路的 ac()（check=True）")


# ==========================================================================
# 展示类 API（不崩 + 有内容）
# ==========================================================================
@case(group="展示")
def test_summary_and_plot():
    """summary()/plot() 必须有内容且不崩（报告与 Web 都直接调它们）。

    防的是：数据点极少时 plot 除零崩溃（ymax==ymin），
    那会在生成报告这一步把整个请求打成 500。
    """
    H.need_ngspice()
    ac = _rc().ac(1, 1e5, 50)
    text = ac.summary("out")
    is_true("dB" in text and "out" in text, f"AC summary 应给出增益/带宽，实测 {text!r}")
    art = ac.plot("out")
    is_true(len(art.splitlines()) > 5, f"plot 应返回一幅多行 ASCII 图，实测 {len(art.splitlines())} 行")
    is_true("*" in art, "plot 里应有波形点")

    op = Circuit("d")
    op.V("in", GND, dc=3.0)
    op.R("in", GND, 1e3)
    o = op.op()
    is_true("工作点" in o.summary(), f"OP summary 应说明是工作点，实测 {o.summary()[:40]!r}")


if __name__ == "__main__":
    sys.exit(H.main("test_sim", "test_sim：runner / Solution"))

@case(group="dc")
def test_descending_sweep_value_at_is_correct():
    """回归：直流扫描**降序**时 value_at 必须真的插值，不能退化成端点值。

    曾经真出过：`.dc V1 5 -5 -1` 的 x 是 [5,4,...,-5]，而插值函数假设升序，
    于是 value_at(5)/value_at(0)/value_at(-5) 全都返回第一个点的 2.5V。
    这种错不会报错，只会静默给出错误读数。
    """
    H.need_ngspice()
    c = Circuit("desc_div")
    c.V("in", GND, dc=0)
    c.R("in", "o", 1e3)
    c.R("o", GND, 1e3)
    sol = c.dc("V1", 5, -5, -1)
    is_true(len(sol.x) == 11, f"降序扫描应有 11 点，实测 {len(sol.x)}")
    is_true(sol.x[0] > sol.x[-1], "扫描轴应确实是降序")
    for x in (5.0, 2.5, 0.0, -2.5, -5.0):
        got = sol.value_at("o", x)
        close(got, x * 0.5, 0.005, what=f"降序扫描 value_at({x})")


# ==========================================================================
# 器件电流保存（可视化用）不能破坏仿真本身
# ==========================================================================
@case(group="器件电流")
def test_save_devices_never_breaks_analysis():
    """★回归：`save @dev[i]` 曾在 AC 分析下把整个仿真搞崩。

    事故现场（用户实测报的错）：
        CCLConvergenceError: 电路 'rc_checked' 仿真失败：仿真未产生任何波形数据

    根因：`write all` 不含器件内部量，为做「LED 按电流发光」加了自动 save。
    但 **AC 是频域，没有器件支路电流** —— 连 `@r1[i]` 都取不到：
        save all @r1[i]  →  "vector @r1[i] is not available"
                        →  write 失败 →  "仿真未产生任何波形数据"
    于是原本能跑的交流电路全崩。

    这条用例把「四种分析都能跑」钉死。谁再往 save 里加东西，先过这关。
    """
    H.need_ngspice()
    from ccl import Circuit, GND

    def mk(name="rc"):
        c = Circuit(name)
        c.V("in", GND, dc=5, ac=1)
        c.R("in", "out", 1.6e3)
        c.C("out", GND, 100e-9)
        return c

    # 四种分析全部必须能跑
    sol = mk().ac(1, 1e5, 100)
    is_true(abs(sol.f3db("out") - 994.7) < 5, f"ac f3db = {sol.f3db('out')}")
    mk().op()
    mk().tran(1e-6, 5e-3)
    mk().dc("V1", 0, 5, 0.5)

    # 带 c.expect 的完整核对链路也要能跑（用户报错时用的就是这种电路）
    c = mk("rc_checked")
    c.expect("fc", "out", 1000, tol=0.05)
    rep = c.verify()
    is_true(rep.passed, f"带断言的电路应通过，实际 {[str(r) for r in rep.results]}")


@case(group="器件电流")
def test_branch_currents_are_physically_consistent():
    """op 分析下取到的器件电流必须自洽：串联电路两支路相同，且满足 KVL。"""
    H.need_ngspice()
    from ccl import Circuit, GND
    from copilot import sim as S

    c = Circuit("led")
    c.V("vcc", GND, dc=5)
    c.R("vcc", "a", 1e3)
    c.D("a", GND, "D1N4148")
    sol = c.op()
    cur = S.branch_currents(sol)
    is_true("r1" in cur and "d1" in cur, f"应取到 r1/d1 电流，实际 {sorted(cur)}")
    is_true(abs(cur["r1"] - cur["d1"]) / max(cur["r1"], 1e-12) < 0.01,
            f"串联电路电流应相同：r1={cur['r1']:.6g} d1={cur['d1']:.6g}")
    vd = sol.value_at("a", 0.0)
    expect_i = (5.0 - vd) / 1e3
    is_true(abs(cur["r1"] - expect_i) / max(expect_i, 1e-12) < 0.01,
            f"电流应满足 (5−{vd:.3f})/1k = {expect_i*1000:.3f}mA，实测 {cur['r1']*1000:.3f}mA")


@case(group="器件电流")
def test_ac_has_no_branch_currents():
    """AC 分析不提供器件电流——这是物理事实，不是缺陷。界面据此不显示工作态。"""
    H.need_ngspice()
    from ccl import Circuit, GND
    from copilot import sim as S

    c = Circuit("rc")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-9)
    sol = c.ac(1, 1e5, 100)
    cur = S.branch_currents(sol)
    is_true(not cur, f"AC 不应有器件支路电流，实际取到 {sorted(cur)}")


@case(group="开关器件")
def test_switch_opens_and_closes():
    """开关必须真的断开/闭合：靠控制电压，不是靠改代码文本。

    用**瞬态**分析（不是 op）：⚑ ngspice 的 S 元件在 `.op` 下 `@sw1[i]` 恒为
    ~0（实测 1.9e-13），但 `.tran` 下能取到真实电流（22.5mA，与串联电阻一致）。
    所以动画（瞬态）能画开关这段导线，而工作点分析的开关电流只能当「无数据」。
    """
    H.need_ngspice()
    from ccl import Circuit, GND
    from copilot import sim as S

    def mk(vctl):
        c = Circuit("sw")
        c.V("vcc", GND, dc=5)
        c.V("ctl", GND, dc=vctl)
        c.R("vcc", "a", 220)
        c.SW("a", "k", "ctl")
        c.D("k", GND, "D1N4148")
        c.R("k", GND, 100e3)
        return c

    on = mk(5).tran(1e-6, 2e-4)
    off = mk(0).tran(1e-6, 2e-4)
    w_on = on.waves.get("i(@sw1[i])")
    w_off = off.waves.get("i(@sw1[i])")
    is_true(w_on is not None, "瞬态下应能取到开关电流 @sw1[i]")
    i_on = max(abs(v) for v in w_on.y)
    i_off = max(abs(v) for v in w_off.y)
    is_true(i_on > 0.010, f"闭合时应≈19mA，实测 {i_on*1000:.3f}mA")
    is_true(i_off < 1e-6, f"断开时应<1µA，实测 {i_off*1000:.6f}mA")
    # 与串联电阻的电流必须一致（同一个支路）
    w_r1 = on.waves.get("i(@r1[i])")
    is_true(w_r1 is not None and abs(max(abs(v) for v in w_r1.y) - i_on) / i_on < 0.01,
            "开关电流应与串联电阻电流一致")


@case(group="器件电流")
def test_binary_raw_matches_ascii():
    """★二进制 rawfile 必须与 ASCII 逐点一致（它是纯性能优化，不许改变数值）。

    为什么要常驻：这条改的是**底层取数路径**，一旦二进制解析错位（寄存器顺序/复数
    交错/`.op` 无横轴这些分支），所有指标都会错，而且错得很像真的。
    用同一份网表跑两遍（`CCL_RAW_ASCII=1` 强制 ASCII），逐点比对。
    """
    H.need_ngspice()
    import os as _os
    from ccl import Circuit, GND

    def mk():
        c = Circuit("ladder")
        c.PULSE("in", GND, v1=0, v2=5, td=0, pw=5e-3, per=10e-3)
        prev = "in"
        for i in range(4):
            n1, n2 = f"n{i}a", f"n{i}b"
            c.R(prev, n1, 1e3); c.C(n1, GND, 4.7e-9)
            c.R(n1, n2, 1e3);   c.C(n2, GND, 4.7e-9)
            prev = n2
        c.R(prev, GND, 220)
        return c

    old = _os.environ.pop("CCL_RAW_ASCII", None)
    try:
        sol_bin = mk().tran(1e-6, 2e-3)          # 默认走二进制
        _os.environ["CCL_RAW_ASCII"] = "1"
        sol_asc = mk().tran(1e-6, 2e-3)          # 强制 ASCII
    finally:
        _os.environ.pop("CCL_RAW_ASCII", None)
        if old is not None:
            _os.environ["CCL_RAW_ASCII"] = old

    is_true(len(sol_bin.x) == len(sol_asc.x),
            f"点数应一致：{len(sol_bin.x)} vs {len(sol_asc.x)}")
    keys = [k for k in sol_asc.waves if k in sol_bin.waves]
    is_true(len(keys) >= 10, f"应至少比 10 条波形，实际 {len(keys)}")
    worst, worst_where = 0.0, None
    for k in keys:
        ya, yb = sol_asc.waves[k].y, sol_bin.waves[k].y
        is_true(len(ya) == len(yb), f"{k} 长度应一致")
        for i in range(len(ya)):
            d = abs(ya[i] - yb[i])
            if d > worst:
                worst, worst_where = d, (k, i, abs(ya[i]))
    # ASCII 只有 ~10 位有效数字，二进制是 float64 原值 → 差异应在 1e-12 量级
    is_true(worst < 1e-12 * max(1.0, (worst_where[2] if worst_where else 1.0)),
            f"两种格式最大偏差应 <1e-12 相对量级，实际 {worst:.3e} @ {worst_where}")

    # `.op` 没有独立横轴，也必须两边一致（历史上这里错位过一次）
    o_bin = mk_op = None
    c1 = Circuit("op1"); c1.V("v", GND, dc=5); c1.R("v", "a", 1e3); c1.R("a", GND, 1e3)
    o_bin = c1.op()
    _os.environ["CCL_RAW_ASCII"] = "1"
    try:
        c2 = Circuit("op2"); c2.V("v", GND, dc=5); c2.R("v", "a", 1e3); c2.R("a", GND, 1e3)
        o_asc = c2.op()
    finally:
        _os.environ.pop("CCL_RAW_ASCII", None)
    is_true(abs(o_bin.value_at("a", 0.0) - o_asc.value_at("a", 0.0)) < 1e-12,
            f"op 节点电压应一致：{o_bin.value_at('a', 0.0)} vs {o_asc.value_at('a', 0.0)}")
