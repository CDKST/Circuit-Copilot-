"""回归钉：把刚修好的一批 bug 逐条钉死，确保它们不会悄悄复发。

## 这个文件为什么存在

修 bug 的提交往往只带「修好了」的结论，不带**能抓住它复发的断言**。等下一次
重构（尤其是「顺手优化一下」）碰到同一段代码，同样的坑会原样回来，而且没人
知道曾经踩过。所以这里每条用例都对应一条**已发生的故障现场**，注释里写明
「修复前的实测现象」，方便后人判断自己手里的改动是不是又把它拆了。

用例与故障现场的对应（编号沿用修复清单）：

  1. `_save_devices` 把 `.subckt` 内部器件也 save → 含运放的电路 op/tran/dc 全崩
  2. save 失败没有降级重试 → 「取不到某个器件电流」被当成「电路跑不了」
  3. 开关 model 名不含 Vt → 两个开关阈值互相偷换
  4. PULSE/SIN 驱动开关时走了「改控制源 DC」那条路 → 点了开关毫无反应
  5. Vt 强制判据依赖 `op()` 量出的 V(ctrl) → 对时变控制完全失效
  6. `collect_live` 取 t=0 → 图例显示「0/N 个器件导通」
  7. 三端器件（Q/M）给了「前两个引脚之差」当电压 → 功耗差 20 倍
  8. `collect_timeline` 均匀抽点 → 窄脉冲被抽没（峰值 11.4mA → 0）
  9. 面板 `_downsample` 均匀抽点 → 50ns 窄脉冲 4.76mA → 0（面板画一条平线）
 10. `_current_key` 认不出 `i(v1)` → 挂着电源的那几段导线永远不流动
 11. `netCurrentSeries` 把支路电流求和 → 恒为 KCL 残差 ≈ 0（JS 侧，见
     `tests_api/test_ui_contract.py` 与 `tests_ccl/test_schematic.py`）

第 11 条是 JS，不在这里；本文件只管 ccl / copilot / web.ccl_api 的 Python 侧。

## 一条用例是「已知缺陷」时怎么办

见 `_harness.py` 的 known_bug 纪律：断言保持严格 + 打标记，不把断言放宽到刚好通过。
本文件里 `test_live_current_is_taken_at_snapshot_time` 就是这种：
`collect_live()` 的电压取末点、电流仍取 `t=0`（`branch_currents()` 取 `ys[0]`），
同一份快照里两个量来自不同时刻 —— 这是**修复没做全**的部分，如实标记。
"""

from __future__ import annotations

import math
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, in_range, is_true  # noqa: E402

from ccl.core import GND, Circuit  # noqa: E402


# ==========================================================================
# 小工具
# ==========================================================================
_RE_SW_MODEL = re.compile(r"^\.model\s+(\S+)\s+SW\((.*)\)\s*$", re.I | re.M)


def _switch_models(netlist: str) -> list[tuple[str, str]]:
    """网表里所有开关 `.model`：(模型名, 参数串)。顺序即网表顺序。"""
    return [(m.group(1), m.group(2)) for m in _RE_SW_MODEL.finditer(netlist)]


def _peak(wave) -> float:
    """一条波形的峰值绝对值；波形为空直接判失败（不许「没数据」当 0 混过去）。"""
    is_true(wave is not None, "波形不存在（None）—— 拿不到数据不能当 0 处理")
    ys = getattr(wave, "y", None) or []
    is_true(len(ys) > 0, "波形里一个点都没有")
    return max(abs(complex(v).real) for v in ys)


def _led_peak(circuit, tstep: float, tstop: float, ref: str = "d1") -> float:
    """跑一次瞬态，返回某个器件支路电流的峰值（安培）。"""
    sol = circuit.tran(tstep, tstop)
    key = f"i(@{ref}[id])" if ref.startswith("d") else f"i(@{ref}[i])"
    w = sol.waves.get(key)
    if w is None:                      # 二极管用 id，其它器件用 i
        w = sol.waves.get(f"i(@{ref}[i])")
    return _peak(w)


# ==========================================================================
# 1. save 必须跳过 .subckt 内部器件
# ==========================================================================
def _opamp_circuit() -> Circuit:
    """同相放大 ×2（Rf=Rg=10k）：运放宏模型内部有 R0/C0，正是当年崩掉的那类电路。"""
    c = Circuit("opamp_follower")
    c.V("in", GND, dc=0.5)
    c.OpAmp(inp="in", inn="fb", out="out", gbw=1.3e6, a0=1e5)
    c.R("out", "fb", 10e3)
    c.R("fb", GND, 10e3)
    return c


@case(group="① save 跳过子电路")
def test_save_devices_skips_subckt_internals():
    """★回归：`_save_devices` 不许给 `.subckt` 内部器件下发 save。

    事故现场：运放宏模型（`OPA_...`）内部有 `Rin/E0/R0/C0/Rout`，旧的
    `_save_devices` 只跳过 `.` 开头的行，于是 `.subckt` 里面的 R0/C0 也被
    `save all @r0[i] @c0[i]`。ngspice 在**顶层命名空间**里根本没有这两个向量：

        Warning from checkvalid: vector @c0[i] is not available
        Error during 'write': no writable vector found

    → `write c.raw all` 失败 → 整个仿真失败。于是**任何含 `c.OpAmp()` 的电路
    在 op/tran/dc 下 100% 跑不了**（项目自带运放 topology 只做 .ac，不 save，
    所以测试全绿没抓到）。

    这条用例直接钉住 save 行的内容：子电路内部器件一个都不许出现。
    """
    from copilot import sim as S

    net = _opamp_circuit().to_spice(analysis=".op")
    save = S._save_devices(net)
    is_true(save != "", f"这份网表应该下发 save（有顶层 R），实际拿到 {save!r}")

    # 子电路内部这几个器件绝不许出现（它们只在 .subckt 里有意义）
    for bad in ("@r0[i]", "@c0[i]", "@rin[i]", "@rout[i]"):
        is_true(bad not in save,
                f"save 行里出现了子电路内部器件的 {bad}：{save.strip()!r}\n"
                "      （ngspice 顶层没有这个向量 → write 失败 → 整个仿真失败）")

    # 顶层器件必须还在（别为了躲崩溃把 save 全丢掉）
    for good in ("@r1[i]", "@r2[i]"):
        is_true(good in save, f"save 行里缺了顶层器件 {good}：{save.strip()!r}")


@case(group="① save 跳过子电路")
def test_opamp_circuit_runs_in_op_tran_dc():
    """★回归：含 `c.OpAmp()` 的电路在 op / tran / dc 三种分析下都必须能跑完。

    这是用户实测报的那条崩溃（`vector @c0[i] is not available`）。断言不止
    「没抛异常」，还要给出**物理上正确**的结果：同相 ×2，输入 0.5V → 输出 1.0V。
    """
    H.need_ngspice()

    # op
    s_op = _opamp_circuit().op()
    v_out = float(s_op.value_at("out", 0.0))
    close(v_out, 1.0, 0.01, "op 下运放同相 ×2 的输出电压")

    # tran：末点应稳到同样的值（模型无饱和，纯线性）
    s_tr = _opamp_circuit().tran(1e-6, 2e-3)
    v_end = float(s_tr.value_at("out", s_tr.x[-1]))
    close(v_end, 1.0, 0.01, "tran 末点的输出电压")

    # dc：传输特性必须是斜率 2 的直线
    s_dc = _opamp_circuit().dc("V1", 0, 1, 0.25)
    for x in (0.25, 0.5, 1.0):
        close(float(s_dc.value_at("out", x)), 2.0 * x, 0.01,
              f"dc 扫描 vin={x}V 时的输出电压")


# ==========================================================================
# 2. save 失败要降级重试；正常电路不能因此丢设备电流
# ==========================================================================
@case(group="② save 降级重试")
def test_save_failure_degrades_instead_of_failing():
    """★回归：save 出问题时，必须丢掉 save 重跑，而不是让仿真失败。

    怎么构造：把 `_save_devices` 换成一个必然失败的 save 行（`@zz99[i]` 这个
    向量不存在）。修复前：`write c.raw all` 失败 → 没有 rawfile → `SimError`
    （用户看到的是「电路跑不了」，其实是「取不到某个器件电流」）。
    修复后：自动丢掉 save 重跑一次，电路结果照旧正确，只是没有器件级数据。

    注意断言的是**降级不等于静默错误**：拿不到支路电流时必须是「没有」，
    而不是编一个 0 出来。
    """
    H.need_ngspice()
    from copilot import sim as S

    net = _opamp_circuit().to_spice(analysis=".op")
    orig = S._save_devices
    try:
        S._save_devices = lambda deck: "save all @zz99[i]\n"
        res = S.run(net)                    # 修复前这里抛 SimError
    finally:
        S._save_devices = orig

    is_true(res is not None, "降级重跑没有返回结果")
    is_true("v(out)" in res.waves,
            f"降级后仍应有节点电压波形，实际只有 {sorted(res.waves)[:8]}")
    cur = S.branch_currents(res)
    is_true(cur == {},
            f"丢掉 save 之后不该有器件电流（不许编 0），实际拿到 {cur}")
    close(complex(res.waves["v(out)"].y[0]).real, 1.0, 0.01,
          "降级重跑后的输出电压（电路结果必须仍然正确）")


@case(group="② save 降级重试")
def test_normal_run_keeps_device_currents():
    """★回归：降级逻辑不能把正常电路的 save 弄丢。

    降级是「保险」，最容易写坏的方式是**太敏感**：只要 rawfile 大小/文本里出现
    一点意外就丢掉 save 重跑，于是正常电路再也没有器件电流（界面不显示工作态，
    而且没人会注意到）。所以这条用例钉住正常路径：器件电流必须还在，而且对得上
    欧姆定律。
    """
    H.need_ngspice()
    from copilot import sim as S

    c = Circuit("led")
    c.V("vcc", GND, dc=5)
    c.R("vcc", "a", 220)
    c.D("a", GND, "D1N4148")
    sol = c.op()
    cur = S.branch_currents(sol)
    is_true("r1" in cur and "d1" in cur,
            f"正常电路必须取到 r1/d1 的支路电流，实际 {sorted(cur)}")
    # 串联电路：电阻电流 == 二极管电流
    close(cur["r1"], cur["d1"], 1e-3, "串联电路 R1 与 D1 的电流")
    # 欧姆定律：I = (5 − Vd) / 220
    vd = float(sol.value_at("a", 0.0))
    close(cur["r1"], (5.0 - vd) / 220.0, 0.01, "R1 电流（欧姆定律）")
    in_range(cur["r1"] * 1e3, 15.0, 22.0, "LED 回路电流（mA）")


# ==========================================================================
# 3. 开关 model 名必须含 Vt
# ==========================================================================
def _two_switch_circuit() -> Circuit:
    """两个开关 ron/roff 完全相同、只有 Vt 不同（2.5V vs 4.0V），控制端都是 3V。"""
    c = Circuit("two_switches")
    c.V("vcc", GND, dc=5)
    c.V("ctl", GND, dc=3)
    c.R("vcc", "a", 1e3)
    c.SW("a", GND, "ctl", on_voltage=2.5, ref="SW1")     # 3V > 2.5V → 闭合
    c.R("vcc", "b", 1e3)
    c.SW("b", GND, "ctl", on_voltage=4.0, ref="SW2")     # 3V < 4.0V → 断开
    return c


@case(group="③ 开关 model 名含 Vt")
def test_switch_model_names_include_vt():
    """★回归：ron/roff 相同但 Vt 不同的两个开关，必须生成**两条不同名**的 `.model`。

    事故现场：model 名只由 (ron, roff) 派生 → 两个开关撞名，网表里两条同名
    不同 Vt 的 `.model`。ngspice 对同名 model 的重复声明**不报错、静默只认
    后一份**（实测过 Ron 被偷换成 100Ω）。结果：3V 控制下 Vt=4 的那个也导通了。
    """
    H.need_ngspice()
    models = _switch_models(_two_switch_circuit().to_spice())
    is_true(len(models) == 2,
            f"两个参数不同的开关必须各写一条 .model，实际 {len(models)} 条：{models}")
    names = [n for n, _ in models]
    is_true(names[0] != names[1],
            f"两条 .model 的名字必须不同（含 Vt），实际都是 {names[0]!r}")
    body = " ".join(p for _, p in models)
    for vt in ("2.5", "4"):
        is_true(f"Vt={vt}" in body,
                f"网表里找不到 Vt={vt} 的开关模型：{models}")


@case(group="③ 开关 model 名含 Vt")
def test_switches_with_same_params_share_one_model():
    """反面约束：参数**完全相同**的开关仍应复用同一个 model 名（网表只留一条）。

    这条防的是「把名字改成每次唯一」这种矫枉过正 —— 那会在 35 器件电路里刷出
    几十条一模一样的 `.model`，网表噪音大到没法读，而且掩盖真正不同的那几条。
    """
    c = Circuit("same_switches")
    c.V("vcc", GND, dc=5)
    c.V("ctl", GND, dc=5)
    c.R("vcc", "a", 1e3)
    c.SW("a", GND, "ctl")
    c.R("vcc", "b", 1e3)
    c.SW("b", GND, "ctl")
    models = _switch_models(c.to_spice())
    is_true(len(models) == 1,
            f"参数相同的两个开关应共用一条 .model，实际 {len(models)} 条：{models}")


@case(group="③ 开关 model 名含 Vt")
def test_two_switches_switch_independently_at_3v():
    """★回归：控制端 3V 时，Vt=2.5 的闭合、Vt=4.0 的断开（阈值不许互相偷换）。

    实测判据（修复后）：闭合支路的节点电压 ≈ 0（被开关短到地），断开支路的
    节点电压 ≈ 5V（等于电源）。修复前两者一起导通 → `v(a) == v(b) ≈ 0`，灯和
    电阻状态全错。
    """
    H.need_ngspice()
    sol = _two_switch_circuit().op()
    v_a = abs(float(sol.value_at("a", 0.0)))
    v_b = abs(float(sol.value_at("b", 0.0)))
    in_range(v_a, 0.0, 0.05, "Vt=2.5 的开关在 3V 控制下应闭合 → v(a)≈0")
    close(v_b, 5.0, 0.01, "Vt=4.0 的开关在 3V 控制下应断开 → v(b)≈5V")
    is_true(v_b - v_a > 4.0,
            f"两个开关的状态必须不同（一个闭合一个断开），实测 v(a)={v_a:.6g} v(b)={v_b:.6g}")


# ==========================================================================
# 4. PULSE/SIN 驱动开关：不许走「改控制源 DC」那条路
# ==========================================================================
def _pulse_driven_switch() -> Circuit:
    """PULSE 驱动开关（瞬态里最常见的接法）：5V → 220Ω → SW1 → LED。"""
    c = Circuit("pulse_switch")
    c.PULSE("ctl", GND, v1=0, v2=5, td=0, tr=1e-7, tf=1e-7, pw=5e-3, per=10e-3)
    c.V("vcc", GND, dc=5)
    c.R("vcc", "a", 220)
    c.SW("a", "k", "ctl", ref="SW1")
    c.D("k", GND, "D1N4148")
    return c


@case(group="④ PULSE 驱动开关")
def test_pulse_driven_switch_not_forced_via_source_dc():
    """★回归：控制源是 PULSE 时，`apply_switch_states` 必须走 **Vt** 这条路。

    事故现场：`_find_ctrl_source` 只按 `kind == 'V'` 认控制源，而 PULSE 源的
    KIND 也是 'V'。于是 apply 回报 `{"SW1": "source"}` 并去改 `comp.dc` ——
    可 PULSE 的网表是 `PULSE(0 5 ...)`，**根本没有 dc 这个位置**，改 `comp.dc`
    之后网表一个字节都不会变。用户点开关什么都不会发生。
    """
    H.need_ngspice()
    from ccl.runner import apply_switch_states

    c = _pulse_driven_switch()
    how = apply_switch_states(c, {"SW1": "off"})
    is_true(how.get("SW1") == "vt",
            f"PULSE 驱动的开关只能走 vt 强制，实际 {how}"
            "（走 source 等于什么都没改：PULSE 源没有 dc 位）")
    from ccl.devices import Switch
    sw = next(x for x in c.components if isinstance(x, Switch))
    is_true(abs(float(sw.on_voltage)) > 100.0,
            f"走 vt 强制时阈值必须被推到控制电压到不了的量级，实际 Vt={sw.on_voltage!r}")


@case(group="④ PULSE 驱动开关")
def test_pulse_driven_switch_on_off_changes_led_current():
    """★回归：PULSE 驱动开关时，`{'SW1': 'off'}` 必须真的断电、`'on'` 必须真的导通。

    修复前实测：on / off 的瞬态峰值**完全相同**（0.0222758A），也就是开关根本没被
    切开。修复后：off ≈ 0（只剩 roff 的漏电流），on ≈ 19mA（5V/220Ω/LED）。
    """
    H.need_ngspice()
    from ccl.runner import apply_switch_states

    c_off = _pulse_driven_switch()
    apply_switch_states(c_off, {"SW1": "off"})
    i_off = _led_peak(c_off, 1e-7, 1e-3)

    c_on = _pulse_driven_switch()
    apply_switch_states(c_on, {"SW1": "on"})
    i_on = _led_peak(c_on, 1e-7, 1e-3)

    is_true(i_off < 1e-6, f"关掉之后 LED 电流应≈0，实测 {i_off * 1e3:.6f}mA")
    in_range(i_on * 1e3, 17.0, 21.0, "打开之后 LED 峰值电流（mA）")
    is_true(i_on > i_off * 1000,
            f"on/off 必须明显不同（修复前两者峰值一样）：on={i_on * 1e3:.4f}mA "
            f"off={i_off * 1e3:.6f}mA")


# ==========================================================================
# 5. Vt 强制判据与控制波形无关（±1000V），且旧 model 卡必须被清掉
# ==========================================================================
@case(group="⑤ Vt 判据与控制波形无关")
def test_switch_force_uses_fixed_vt_regardless_of_waveform():
    """★回归：强制通断只许把 Vt 推到 ±1000V，不许先跑一次 `op()` 量 V(ctrl)。

    旧实现：`circuit.op()` 量出 t=0 的 V(ctrl)，再把 Vt 放到它另一侧（±1V）。
    对 PULSE 驱动完全失效 —— t=0 时 V(ctrl)=0，want_off 得到 Vt≈1，脉冲升到 5V
    时 5 > 1 仍然闭合。另外它还白跑一次 ngspice。

    断言：两种状态下 Vt 都必须是**固定**的 ±1000（与控制波形、与电路状态无关）。
    """
    H.need_ngspice()
    from ccl.runner import apply_switch_states
    from ccl.devices import Switch

    for want, vt in (("on", -1000.0), ("off", 1000.0)):
        c = _pulse_driven_switch()
        # 先跑一次真仿真：让 circuit.directives 里留下“旧 Vt=2.5”的那条 model 卡，
        # 这正是历史 bug 里“新旧两条 model 并存”的现场。
        c.tran(1e-7, 1e-4)
        apply_switch_states(c, {"SW1": want})
        sw = next(x for x in c.components if isinstance(x, Switch))
        close(float(sw.on_voltage), vt, 0.0,
              f"want_{want} 时强制阈值必须正好是 {vt:g}V（与波形无关）")


@case(group="⑤ Vt 判据与控制波形无关")
def test_switch_state_change_leaves_exactly_one_model_card():
    """★回归：改完开关状态后，网表里只许剩**一条**开关 `.model`（旧卡必须清掉）。

    现场：`_drop_stale_switch_directives` 早先用「改完之后的新名字」去匹配旧行，
    方向反了 → 一条都删不掉。于是改 off 之后网表里同时躺着 `Vt=2.5` 和 `Vt=1000`
    两条卡。名字不同虽然不会互相覆盖，但「到底按哪个 Vt 算」变得不可查，
    而且一条没人引用的 model 是纯噪音。
    """
    H.need_ngspice()
    from ccl.runner import apply_switch_states

    c = _pulse_driven_switch()
    c.tran(1e-7, 1e-4)                     # 让 directives 里留下旧的 Vt=2.5
    before = _switch_models(c.to_spice())
    is_true(len(before) == 1,
            f"改状态之前应只有一条开关 .model，实际 {before}")

    apply_switch_states(c, {"SW1": "off"})
    after = _switch_models(c.to_spice())
    is_true(len(after) == 1,
            f"改完状态后必须只剩一条开关 .model，实际 {len(after)} 条：{after}")
    name, params = after[0]
    is_true("Vt=1000" in params and "Vt=2.5" not in params,
            f"留下的那条必须是强制后的（Vt=1000），实际 {name} {params}")


# ==========================================================================
# 6. collect_live 取末点（tran/dc），不是 t=0
# ==========================================================================
def _pulse_rc_circuit() -> Circuit:
    """PULSE 0→5V，脉宽 5ms；tran 只跑到 1ms，所以**末点处于高电平**。"""
    c = Circuit("pulse_rc")
    c.PULSE("in", GND, v1=0, v2=5, td=0, tr=1e-6, tf=1e-6, pw=5e-3, per=10e-3)
    c.R("in", "a", 220)
    c.R("a", GND, 220)
    return c


@case(group="⑥ live 取末点")
def test_live_snapshot_uses_last_time_point():
    """★回归：tran 的 `live` 必须取**末点**，不是 t=0。

    事故现场：PULSE 电路在 t=0 还没通电，`live` 全是 0 → 界面图例显示
    「0/N 个器件导通」，与同一屏里正在播放的动画互相打脸。
    修复后 `live["t"]` 是最后一个时间点，电压按那一刻取值。
    """
    H.need_ngspice()
    from web import ccl_api as A

    c = _pulse_rc_circuit()
    sol = c.tran(1e-6, 1e-3)
    live = A.collect_live(c, sol, "tran")
    is_true(live is not None, "tran 分析必须给出 live")
    is_true(live.get("t") is not None,
            f"live 必须带时间戳 t（缺失说明快照还是按 t=0 取的），实际字段 {sorted(live)}")
    close(float(live["t"]), float(sol.x[-1]), 1e-9,
          "live 的时间戳必须等于时间序列末点")

    items = live["items"]
    zero = [r for r, it in items.items()
            if not it.get("voltage") and not it.get("current") and not it.get("power")]
    is_true(len(zero) < len(items),
            f"末点已通电，live 不能全是 0；实测全为 0 的器件：{zero}")
    close(float(items["r1"]["voltage"]), 2.5, 0.01,
          "末点分压器上 R1 的两端电压")


@case(group="⑥ live 取末点")
def test_live_db_snapshot_uses_last_sweep_point():
    """★回归：dc 的 `live` 也必须取扫描**末点**，不是 x=0（扫描起点输出还是 0）。"""
    H.need_ngspice()
    from web import ccl_api as A

    c = Circuit("dc_snapshot")
    c.V("in", GND, dc=0)
    c.R("in", "out", 1e3)
    c.R("out", GND, 1e3)
    sol = c.dc("V1", 0, 10, 1)
    live = A.collect_live(c, sol, "dc")
    is_true(live.get("t") is not None,
            f"live 必须带时间戳 t（缺失说明快照还是按 x=0 取的），实际字段 {sorted(live)}")
    close(float(live["t"]), 10.0, 1e-9, "dc 下 live 的时间戳应等于扫描末点")
    close(float(live["items"]["r1"]["voltage"]), 5.0, 0.01,
          "扫描到 10V 时 R1 两端电压（分压 5V）")


@case(group="⑥ live 取末点")
def test_live_current_and_voltage_share_the_same_time_point():
    """★回归：`live` 的**电流**必须和它的**电压**取自同一时刻（都是末点）。

    事故现场（两段）：`collect_live()` 早先电压取 `t=0`；后来改成取末点，但
    `branch_currents()` 仍写死取 `ys[0]` → 同一份快照里 V 来自末点、I 来自 t=0，
    `power = |I(t=0)·V(t末点)|` 没有物理意义。实测 PULSE 电路报
    「R1 两端 2.5V / 电流 0A / 功耗 0W」，真值 11.4mA / 28mW。

    这条用例同时钉住自洽性：**功耗必须等于 |I·V|**（I、V 都是 live 自己给的
    数）。任何一端的时间点被改回去，这个乘积就对不上。
    """
    H.need_ngspice()
    from web import ccl_api as A

    c = _pulse_rc_circuit()
    sol = c.tran(1e-6, 1e-3)
    live = A.collect_live(c, sol, "tran")
    it = live["items"]["r1"]
    i_end = float(sol.value_at("in", sol.x[-1])) / 440.0    # 末点：5V / (220+220)
    is_true(it["current"] is not None, "R1 应该有电流数据")
    close(float(it["current"]), i_end, 0.01,
          "live 的 R1 电流必须取末点（与 live 的电压同一时刻）")
    close(float(it["power"]), abs(float(it["current"]) * float(it["voltage"])), 1e-6,
          "live 的功耗必须自洽：|I·V|（两个数来自同一时刻才成立）")


# ==========================================================================
# 7. 三端器件的 voltage / power 必须是 None（Q / M）
# ==========================================================================
@case(group="⑦ 三端器件无 V/P")
def test_three_terminal_devices_report_no_voltage_or_power():
    """★回归：Q/M 的 `voltage`/`power` 必须是 None，`current` 仍是真实值。

    事故现场：取「第一个引脚 − 第二个引脚」当电压，对三端器件只是**任意一对
    引脚**之差。实测 BJT 得 Vcb=1.008V（真实 Vce=1.706V）、功耗 3.32mW（真实
    5.63mW）；MOSFET 得 Vdg=4.767V（真实 Vds=0.233V）、功耗差 **20 倍**。
    与其给一个「看起来像对」的错数，不如不给。
    """
    H.need_ngspice()
    from web import ccl_api as A

    # BJT：共射
    c_bjt = Circuit("ce_amp")
    c_bjt.V("vcc", GND, dc=5)
    c_bjt.R("vcc", "c", 1e3)
    c_bjt.Q("c", "b", GND, "Q2N3904")
    c_bjt.R("vcc", "b", 100e3)
    live_bjt = A.collect_live(c_bjt, c_bjt.op(), "op")
    q1 = live_bjt["items"]["q1"]
    is_true(q1["voltage"] is None, f"BJT 的 voltage 必须是 None，实测 {q1['voltage']!r}")
    is_true(q1["power"] is None, f"BJT 的 power 必须是 None，实测 {q1['power']!r}")
    is_true(q1["current"] is not None and abs(q1["current"]) > 1e-3,
            f"BJT 的电流必须是真实值（mA 级），实测 {q1['current']!r}")

    # MOSFET：共源，栅极 3V
    c_mos = Circuit("cs_amp")
    c_mos.V("vdd", GND, dc=5)
    c_mos.R("vdd", "d", 1e3)
    c_mos.M("d", "g", GND, model="M2N7002")
    c_mos.V("g", GND, dc=3)
    live_mos = A.collect_live(c_mos, c_mos.op(), "op")
    m1 = live_mos["items"]["m1"]
    is_true(m1["voltage"] is None, f"MOSFET 的 voltage 必须是 None，实测 {m1['voltage']!r}")
    is_true(m1["power"] is None, f"MOSFET 的 power 必须是 None，实测 {m1['power']!r}")
    is_true(m1["current"] is not None and abs(m1["current"]) > 1e-3,
            f"MOSFET 的电流必须是真实值（mA 级），实测 {m1['current']!r}")

    # 两端器件必须照旧有电压和功耗（别把这条修成「全都不给」）
    for ref in ("r1", "r2"):
        it = live_bjt["items"][ref]
        is_true(it["voltage"] is not None and it["voltage"] > 0,
                f"两端器件 {ref} 必须仍有电压，实测 {it['voltage']!r}")
        is_true(it["power"] is not None and it["power"] > 0,
                f"两端器件 {ref} 必须仍有功耗，实测 {it['power']!r}")

    # 二极管（两端）同理：电压、功耗都要有，而且功率必须能对上 I·V
    c_led = Circuit("led_2pin")
    c_led.V("vcc", GND, dc=5)
    c_led.R("vcc", "a", 220)
    c_led.D("a", GND, "D1N4148")
    live_led = A.collect_live(c_led, c_led.op(), "op")
    d1 = live_led["items"]["d1"]
    in_range(float(d1["voltage"]), 0.5, 0.85, "两端器件 D1 的正向压降（V）")
    is_true(d1["power"] is not None and d1["power"] > 0,
            f"两端器件 D1 必须仍有功耗，实测 {d1['power']!r}")
    close(float(d1["power"]), abs(d1["current"] * d1["voltage"]), 1e-6,
          "D1 的功耗必须等于 |I·V|")


# ==========================================================================
# 8. collect_timeline 保峰降采样
# ==========================================================================
def _narrow_pulse_circuit(pw: float, tr: float, td: float = 1e-6) -> Circuit:
    """一个极窄的脉冲（10 万点里只有二三十个非零点）—— 均匀抽点必丢。"""
    c = Circuit(f"narrow_{pw:g}")
    c.PULSE("in", GND, v1=0, v2=5, td=td, tr=tr, tf=tr, pw=pw, per=100e-3)
    c.R("in", "a", 220)
    c.R("a", GND, 220)
    return c


@case(group="⑧ timeline 保峰")
def test_timeline_preserves_narrow_pulse_peak():
    """★回归：`collect_timeline` 的降采样必须保峰（min/max 包络），不能均匀取点。

    事故现场：10ns 步长 / 1ms 总长（10 万点）里一个 2µs 的脉冲，均匀抽 400 点后
    **一个非零点都不剩**（原始 228 个非零点 → 0 个），峰值 11.36mA → 0。
    动画会显示「电路从没动过」。

    判据：降采样后峰值 ≥ 原始的 90%（min/max 包络理论上是 100%）。
    """
    H.need_ngspice()
    from web import ccl_api as A

    for pw, tr in ((2e-6, 1e-7), (0.2e-6, 1e-8)):
        c = _narrow_pulse_circuit(pw, tr)
        sol = c.tran(1e-8, 1e-3)
        raw_peak = _peak(sol.waves["i(@r1[i])"])
        in_range(raw_peak * 1e3, 10.0, 12.0, f"pw={pw:g}s 的原始峰值电流（mA）")

        tl = A.collect_timeline(c, sol)
        cur = tl["series"]["r1"]["current"]
        kept = max(abs(v) for v in cur)
        is_true(kept >= 0.9 * raw_peak,
                f"pw={pw:g}s：降采样后峰值丢太多 —— 原始 {raw_peak * 1e3:.4f}mA，"
                f"保留 {kept * 1e3:.4f}mA（要求 ≥90%）")


@case(group="⑧ timeline 保峰")
def test_timeline_series_aligned_with_time_axis():
    """★回归：`series[*].current/voltage` 的长度必须与 `t` 一致。

    降采样是**一组下标**抽所有波形：t 和各条曲线必须用同一组下标，否则图上的
    时刻和数值会错位（各抽各的 → 曲线右移/左移若干点，看起来像相位错了）。
    """
    H.need_ngspice()
    from web import ccl_api as A

    c = _narrow_pulse_circuit(2e-6, 1e-7)
    sol = c.tran(1e-8, 1e-3)
    tl = A.collect_timeline(c, sol)
    n_t = len(tl["t"])
    is_true(n_t > 0, "时间轴是空的")
    is_true(n_t <= 401, f"降采样后点数应该被压到 400 附近，实际 {n_t}")
    for ref, ser in tl["series"].items():
        for field in ("current", "voltage"):
            arr = ser.get(field)
            if arr is None:
                continue
            is_true(len(arr) == n_t,
                    f"series[{ref}].{field} 长度 {len(arr)} ≠ t 长度 {n_t}（会错位）")
    # t 必须单调递增（乱序的画不出波形）
    for a, b in zip(tl["t"], tl["t"][1:]):
        is_true(b >= a, f"时间轴不是单调递增的：{a} → {b}")


# ==========================================================================
# 9. 面板 _downsample 也保峰
# ==========================================================================
@case(group="⑨ 面板保峰降采样")
def test_panel_downsample_preserves_narrow_pulse():
    """★回归：`web.ccl_api._downsample` 必须保峰（每桶取 min/max）。

    事故现场：50ns 窄脉冲（10 万点）经均匀抽 400 点后峰值从 4.76mA 变成 **0**，
    面板上是一条平线 —— 这是**显示错误**，用户会以为电路没工作。
    """
    from web.ccl_api import _downsample

    n = 100_000
    xs = [i * 1e-9 for i in range(n)]          # 1ns 步长
    ys = [0.0] * n
    # ⚑ 起点**故意不落在**旧的「每 250 点取一个」网格上（50000/250 正好整除，
    #   那样旧的均匀抽点会恰好命中峰值，用例就会假绿）。50013 谁都不挨着。
    for k in range(50_013, 50_063):            # 50ns 的窄脉冲
        ys[k] = 4.76e-3

    xo, yo = _downsample(xs, ys, 400)
    is_true(len(xo) == len(yo), f"x/y 长度必须一致：{len(xo)} vs {len(yo)}")
    is_true(0 < len(yo) <= 401, f"点数应压到 400 附近，实际 {len(yo)}")
    close(max(yo), 4.76e-3, 0.10, "窄脉冲经降采样后的峰值（要求 ≥90% 保留）")
    is_true(min(yo) == 0.0, "脉冲之外的零值必须保留（包络的两端）")

    # 端点必须保留（否则波形图两头会被「截掉一截」）
    is_true(xo[0] == xs[0], f"首个时间点必须保留，实际 {xo[0]!r}")
    is_true(xo[-1] == xs[-1], f"末个时间点必须保留，实际 {xo[-1]!r}")
    for a, b in zip(xo, xo[1:]):
        is_true(b >= a, f"时间轴必须单调递增：{a} → {b}")


@case(group="⑨ 面板保峰降采样")
def test_panel_downsample_short_series_untouched():
    """短序列（点数已经 ≤ n）必须原样返回，不能被「降采样」改写。"""
    from web.ccl_api import _downsample

    xs = [0.0, 1e-6, 2e-6]
    ys = [1.0, 2.0, 3.0]
    xo, yo = _downsample(xs, ys, 400)
    is_true(xo == xs and yo == ys,
            f"短序列必须原样返回，实际 {xo!r} / {yo!r}")


# ==========================================================================
# 10. _current_key 能取到电压源的 i(v1)
# ==========================================================================
@case(group="⑩ 电压源支路电流")
def test_voltage_source_current_is_collected():
    """★回归：电压源的支路电流在 rawfile 里叫 `i(v1)`，`_current_key` 必须认得出。

    事故现场：只认 `i(@v1[i])` 这种形式（那是 save 出来的），而电压源的电流
    **本来就有**、不需要 save，名字是 `i(v1)`。认不出来 → 挂着电源的那几段导线
    永远没有电流数据 → 「电流沿导线流动」在那几段永远是空的。
    """
    H.need_ngspice()
    from web.ccl_api import _current_key, collect_timeline

    c = _pulse_rc_circuit()
    sol = c.tran(1e-6, 1e-3)
    key = _current_key("v1", sol.waves)
    is_true(key is not None,
            "应能从波形里认出电压源 V1 的电流：rawfile 里它就叫 i(v1)"
            f"（现有波形：{sorted(sol.waves)}）")
    is_true(str(key).lower() == "i(v1)", f"电压源电流的 key 应该是 i(v1)，实际 {key!r}")

    tl = collect_timeline(c, sol)
    ser = tl["series"].get("v1")
    is_true(ser is not None, f"timeline 的 series 里必须有 v1，实际 {sorted(tl['series'])}")
    cur = ser.get("current")
    is_true(isinstance(cur, list) and cur,
            f"v1 必须有电流序列，实际 {cur!r}")
    is_true(max(abs(v) for v in cur) > 1e-3,
            f"v1 的电流不能全是 0，实际峰值 {max(abs(v) for v in cur):.6g}A")
