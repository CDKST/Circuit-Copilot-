"""静态检查（ccl.lint）与工作点检查：电路"立不立得住"。

lint 是「代码即测试」的地基：不用仿真、不用大模型，就能判掉一大半错电路。
这里的用例分两类：

  静态（只看结构）：空电路 / 无地 / 悬空 / 无直流通路 / 电压源冲突 /
                    参数越界 / 无 AC 激励 / 孤立子网络
  工作点（要 .op）：节点电压发散 / 电阻过载 / BJT 饱和·截止 / MOS 截止·线性

★ 本文件最重要的一条回归：**地节点电压必须是 0，不是 None**。
  SPICE 输出里根本没有 "0" 号节点的波形，`solution.value_at("0", 0)` 会抛错；
  若 lint 内部不特判，所有接地器件的功耗/工作区检查会被**静默跳过** ——
  lint 返回空列表，用户以为电路没问题。
"""

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, in_range, is_false, is_true, raises  # noqa: E402

from ccl import lint as L  # noqa: E402
from ccl.blocks import BLOCKS, catalog  # noqa: E402
from ccl.core import GND, Circuit  # noqa: E402


def _levels(issues) -> list[str]:
    return [i.level for i in issues]


def _codes(issues) -> list[str]:
    return [i.code for i in issues]


def _find(issues, *, code: str | None = None, ref: str | None = None):
    for i in issues:
        if code is not None and i.code != code:
            continue
        if ref is not None and i.ref != ref:
            continue
        return i
    return None


# ==========================================================================
# 静态检查
# ==========================================================================
@case(group="静态检查")
def test_empty_circuit():
    """空电路必须报 error（没有器件就没有电路）。"""
    iss = L.lint(Circuit("empty"))
    err = [i for i in iss if i.level == "error"]
    is_true(err and "空" in err[0].title, f"空电路应报 error，实测 {[i.title for i in iss]}")


@case(group="静态检查")
def test_no_ground():
    """没有地必须报 error 并指向 GND。

    防的是：SPICE 因为缺参考地直接 singular matrix，而报错完全不提"接地"。
    """
    c = Circuit("nognd")
    c.R("a", "b", 1e3)
    c.R("b", "c", 1e3)
    c.R("c", "a", 1e3)
    iss = L.lint(c)
    hit = _find(iss, ref="GND")
    is_true(hit is not None and hit.level == "error", f"应报「没有地节点」error，实测 {[i.title for i in iss]}")


@case(group="静态检查")
def test_floating_node_points_to_node():
    """悬空节点：error 级，ref 必须是被悬空的节点名。

    防的是：报错只说「有悬空节点」而不说哪个 —— 用户要把整份电路重看一遍。
    """
    c = Circuit("dang")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e3)
    c.C("out", "nowhere", 1e-9)
    iss = L.lint(c)
    hit = _find(iss, ref="nowhere")
    is_true(hit is not None and hit.level == "error", f"应报悬空节点 nowhere，实测 {[(i.level, i.ref) for i in iss]}")
    is_true("nowhere" in hit.detail, f"详情里应点名节点，实测 {hit.detail}")


@case(group="静态检查")
def test_dc_path_blocked_by_capacitor():
    """电容隔直导致节点没有直流通路 → error，且提示「都是隔直器件」。

    这是 SPICE 最常见又最难查的「莫名其妙跑不动」：报 singular matrix
    却不说哪个节点。必须在 Python 侧提前指到节点。
    """
    # 情形 1：节点上全是电容（纯隔直）→ 报错 + 解释原因
    c = Circuit("dcblock")
    c.V("in", GND, ac=1)
    c.C("in", "n1", 1e-6)
    c.C("n1", GND, 1e-6)
    iss = L.lint(c)
    hits = [i for i in iss if "直流通路" in i.title]
    is_true(len(hits) >= 1, f"应报没有直流通路，实测 {[i.title for i in iss]}")
    is_true(any("隔直" in i.detail for i in hits),
            f"全是隔直器件时详情应解释原因，实测 {[i.detail[:60] for i in hits]}")

    # 情形 2：隔直器件 + 电阻凑成的死岛 → 仍然必须报（只是不给"全隔直"的解释）
    c2 = Circuit("dcblock2")
    c2.V("in", GND, ac=1)
    c2.C("in", "n1", 1e-6)
    c2.R("n1", "n2", 1e3)
    c2.C("n2", GND, 1e-6)
    refs = {i.ref for i in L.lint(c2) if "直流通路" in i.title}
    is_true({"n1", "n2"} <= refs, f"应点名节点 n1/n2，实测 {refs}")


@case(group="静态检查")
def test_voltage_source_conflicts():
    """电压源：不同电压并联 = error；同电压并联 = warn；两端同节点 = error。

    防的是：两个理想源抢同一对节点的电压 → 方程无解或无限电流，
    而 ngspice 的报错只提 singular matrix / no convergence。
    """
    diff = Circuit("vp")
    diff.V("a", GND, dc=1)
    diff.V("a", GND, dc=2)
    diff.R("a", GND, 1e3)
    hit = _find(L.lint(diff), ref="V1,V2")
    is_true(hit is not None and hit.level == "error", f"不同电压并联应 error，实测 {[i.title for i in L.lint(diff)]}")

    same = Circuit("vp2")
    same.V("a", GND, dc=1)
    same.V("a", GND, dc=1)
    same.R("a", GND, 1e3)
    hit2 = _find(L.lint(same), ref="V1,V2")
    is_true(hit2 is not None and hit2.level == "warn", f"同电压并联应 warn，实测 {[i.title for i in L.lint(same)]}")

    short = Circuit("self")
    short.V("a", "a", dc=1)
    short.R("a", GND, 1e3)
    hit3 = _find(L.lint(short), ref="V1")
    is_true(hit3 is not None and hit3.level == "error", f"源两端接同一节点应 error，实测 {[i.title for i in L.lint(short)]}")


@case(group="静态检查")
def test_params_out_of_range():
    """参数越界：R/C/L 的值被手工改成 0/负/None 也要查出来。

    devices 层已经拦了构造期的坏值，但 lint 必须能检查**任何** Circuit
    （别处来的、用户手工改过 value 的）。
    """
    c = Circuit("bad")
    c.V("in", GND, dc=1)
    r = c.R("in", GND, 1e3)
    r.value = -5.0
    hit = _find(L.lint(c), ref="R1")
    is_true(hit is not None and hit.level == "error", f"负阻值应报 error，实测 {[i.title for i in L.lint(c)]}")

    r.value = None
    hit2 = _find(L.lint(c), ref="R1")
    is_true(hit2 is not None, "空阻值（None）也应报出来")

    r.value = 1e12                     # 超出 1mΩ~10GΩ 的合理范围
    hit3 = _find(L.lint(c), ref="R1")
    is_true(hit3 is not None and "范围" in hit3.detail, f"1TΩ 应报超出合理范围，实测 {hit3.detail if hit3 else None}")


@case(group="静态检查")
def test_no_ac_excitation():
    """有源但都没设 ac 幅度 → warn（AC 分析所有波形恒为 0）。

    防的是：用户忘了 `ac=1`，扫出一条全零曲线，然后以为"电路坏了"。
    """
    c = Circuit("noac")
    c.V("in", GND, dc=1)
    c.R("in", GND, 1e3)
    hit = _find(L.lint(c), ref="V1")
    is_true(hit is not None and "AC 激励" in hit.title, f"应报没有 AC 激励，实测 {[i.title for i in L.lint(c)]}")
    # 设了 ac 就不该报
    c2 = Circuit("ok")
    c2.V("in", GND, ac=1)
    c2.R("in", GND, 1e3)
    is_false(any("AC 激励" in i.title for i in L.lint(c2)),
             f"有 ac=1 的源不该报缺少激励，实测 {[i.title for i in L.lint(c2)]}")


@case(group="静态检查")
def test_isolated_subnetwork():
    """与主电路不连通的孤立子网络 → warn（多半是漏接一根线）。

    防的是：两块互不相连的电路各自求解，仿真"成功"但结果毫无意义。
    """
    c = Circuit("iso")
    c.V("in", GND, dc=1)
    c.R("in", GND, 1e3)
    c.R("x", "y", 1e3)
    c.R("x", "y", 2e3)
    iss = L.check_isolated_subnets(c)
    is_true(any("孤立" in i.title for i in iss), f"应报孤立子网络，实测 {[i.title for i in iss]}")
    # 正常电路不该报
    ok = Circuit("ok")
    ok.V("in", GND, dc=1)
    ok.R("in", GND, 1e3)
    is_false(L.check_isolated_subnets(ok), "正常电路不该报孤立子网络")


# ==========================================================================
# 工作点检查
# ==========================================================================
@case(group="工作点检查")
def test_resistor_power_ground_zero_regression():
    """★回归：接地电阻的功耗必须真的被算出来（地节点特判 = 0V，不是 None）。

    这是 M3 的一个真 bug：SPICE 输出里没有 "0" 号波形，`value_at("0", 0)`
    抛 NodeError；如果 _volt() 不特判地节点，check_resistor_power 里的
    `if va is None or vb is None: continue` 会**静默跳过每一颗接地电阻**。

    这里用两件事把它钉死：
      1. 10V / 10Ω 必须报 10W 的 error（数值来自 P=V²/R，不是"有没有报"）
      2. 造一个"不特判地节点"的假 Solution，验证那样会**一条都查不出来**
         —— 证明这个特判不是装饰品
    """
    H.need_ngspice()
    c = Circuit("hot")
    c.V("v", GND, dc=10.0)
    c.R("v", GND, 10.0, ref="RLOAD")       # 10W → error
    c.R("v", GND, 200.0, ref="RWARN")      # 0.5W → warn
    iss = L.lint(c, c.op())

    err = _find(iss, code="resistor_power", ref="RLOAD")
    is_true(err is not None and err.level == "error",
            f"10V/10Ω 应报 10W 超限 error，实测 {[(i.code, i.ref, i.level) for i in iss]}")
    in_range(float(err.title.split("功耗")[1].split("W")[0]), 9.9, 10.1,
             what="RLOAD 的功耗数值（解析式 P=V²/R=10W）")

    warn = _find(iss, code="resistor_power", ref="RWARN")
    is_true(warn is not None and warn.level == "warn",
            f"10V/200Ω=0.5W 应报 warn，实测 {[(i.code, i.ref, i.level) for i in iss]}")

    # 反面证明：把 _volt 换成"不特判地节点"的版本，同样的电路**一条都查不出来**。
    # 这就证明那个 `if n in ("0", "GND"): return 0.0` 不是装饰品 ——
    # 少了它，所有接地器件的功耗/工作区检查会被静默跳过，lint 返回空列表，
    # 用户会以为电路完全没问题。（只在内存里临时替换，跑完立刻还原。）
    sol = c.op()
    origin = L._volt

    def naive_volt(solution, node):
        try:
            v = float(solution.value_at(node, 0.0))
            return v
        except Exception:      # noqa: BLE001 —— SPICE 输出里没有 "0" 波形
            return None

    L._volt = naive_volt
    try:
        skipped = L.check_resistor_power(c, sol)
    finally:
        L._volt = origin
    is_false(skipped,
             f"若 _volt 不特判地节点，接地电阻的功耗检查会一条都查不出来（实测 {len(skipped)} 条）"
             f"—— 这正是 _volt() 必须把 GND 映射成 0.0V 的原因")


@case(group="工作点检查")
def test_bjt_regions():
    """BJT 工作区判定：放大 → info，饱和 → warn，截止 → warn，且给出 Vbe/Vce 数字。

    防的是：把饱和当成放大（偏置算错时最常见），用户以为在放大其实已经削顶。
    """
    H.need_ngspice()

    def build(rc, rb, *, base_to_gnd=False):
        c = Circuit("q")
        c.V("vcc", GND, dc=5.0)
        c.R("vcc", "c", rc)
        if base_to_gnd:
            c.R("b", GND, 1e3)
        else:
            c.R("vcc", "b", rb)
        c.Q("c", "b", GND, "Q2N3904")
        return c, L.lint(c, c.op())

    _, active = build(100.0, 100e3)
    hit = _find(active, code="bjt_active")
    is_true(hit is not None and hit.level == "info", f"正常偏置应判放大区，实测 {[(i.code, i.level) for i in active]}")

    _, saturated = build(1e6, 10e3)
    hits = _find(saturated, code="bjt_saturated")
    is_true(hits is not None and hits.level == "warn",
            f"大集电极电阻应判饱和，实测 {[(i.code, i.level) for i in saturated]}")

    _, cutoff = build(1e3, 100e3, base_to_gnd=True)
    hitc = _find(cutoff, code="bjt_cutoff")
    is_true(hitc is not None and hitc.level == "warn",
            f"基极接地应判截止，实测 {[(i.code, i.level) for i in cutoff]}")


@case(group="工作点检查")
def test_mos_regions():
    """MOSFET 工作区判定：截止 → warn，饱和 → info，线性 → info。

    判据来自模型卡的 Vto（不是硬编码常数），所以换模型卡时判定会跟着变。
    """
    H.need_ngspice()

    def build(vg, *, rdrain=None):
        c = Circuit("m")
        c.V("vdd", GND, dc=5.0)
        c.V("vg", GND, dc=vg)
        if rdrain is None:
            c.M("vdd", "vg", GND, GND, "M2N7002")
        else:
            c.R("vdd", "d", rdrain)
            c.M("d", "vg", GND, GND, "M2N7002")
        return c, L.lint(c, c.op())

    _, off = build(0.0, rdrain=1e3)
    is_true(_find(off, code="mos_off") is not None, f"Vgs=0 应判截止，实测 {[(i.code, i.level) for i in off]}")
    _, sat = build(5.0)
    hit = _find(sat, code="mos_sat")
    is_true(hit is not None and hit.level == "info", f"Vgs=5,Vds=5 应判饱和区，实测 {[(i.code, i.level) for i in sat]}")
    _, lin = build(5.0, rdrain=1e3)
    hit2 = _find(lin, code="mos_linear")
    is_true(hit2 is not None and hit2.level == "info", f"小 Vds 应判线性区，实测 {[(i.code, i.level) for i in lin]}")


@case(group="工作点检查")
def test_node_level_divergence():
    """节点电压 |V| > 1kV → error（接错或未收敛）。

    防的是：把 2000V 当成正常结果继续往下算指标，报告里给出一堆无意义的数。
    """
    H.need_ngspice()
    c = Circuit("hv")
    c.V("v", GND, dc=2000.0)
    c.R("v", GND, 1e6)
    sol = c.op()
    iss = L.lint(c, sol)
    hit = _find(iss, code="node_level")
    is_true(hit is not None and hit.level == "error", f"2000V 应报节点电压异常，实测 {[(i.code, i.level) for i in iss]}")


@case(group="工作点检查")
def test_no_solution_no_crash():
    """没给 solution 时，工作点检查必须安静返回空列表（不是崩，也不是瞎报）。

    防的是：静态检查被 solution=None 拖崩 —— 那样 lint 就只能在仿真之后用，
    而它的价值恰恰是"仿真之前就能判"。
    """
    c = Circuit("d")
    c.V("in", GND, dc=1)
    c.R("in", GND, 1e3)
    is_true(L.check_solution(c, None) == [], "check_solution(c, None) 应返回空列表")
    is_true(isinstance(L.lint(c), list), "lint(c)（不给 solution）应正常返回列表")


# ==========================================================================
# 端口放行（blocks 全靠这条）
# ==========================================================================
@case(group="端口放行")
def test_blocks_lint_clean():
    """★9 个 block 单独 lint 必须零 error（已声明端口不算悬空、不算无直流通路）。

    防的是：每个子电路单独检查都刷一堆假错误 —— 假错误比漏报更伤信任，
    用户会开始无视所有 lint 结论（而它们本来是能救命的）。
    """
    kwargs = {
        "rc_lowpass": dict(fc=1e3), "rc_highpass": dict(fc=1e3), "divider": dict(ratio=0.5),
        "rlc_bandpass": dict(f0=100e3, q=10), "noninv_amp": dict(gain=10),
        "inv_amp": dict(gain=10), "sallen_key_lowpass": dict(fc=10e3, q=0.7071),
        "bjt_ce_bias": dict(rc=100, rb=100e3), "emitter_follower": dict(rb=100e3, re=1e3),
        "sallen_key_highpass": dict(fc=5e3, q=0.707), "difference_amp": dict(gain=10),
        "twin_t_notch": dict(f0=50),
    }
    for name in kwargs:
        ckt = BLOCKS[name](**kwargs[name])
        iss = ckt.lint()
        errs = [i for i in iss if i.level == "error"]
        is_false(errs, f"{name} 单独 lint 不该有 error，实测 {[(i.title, i.ref) for i in errs]}")
    # 与 test_blocks 的名单口径一致：比对 BLOCKS 与 catalog 是否同步，
    # 而不是钉死一个数字（加块不该让测试变红）
    is_true({b["name"] for b in catalog()} == set(BLOCKS),
            f"catalog() 与 BLOCKS 不一致：catalog 多 {set(b['name'] for b in catalog()) - set(BLOCKS)}，"
            f"少 {set(BLOCKS) - {b['name'] for b in catalog()}}")


@case(group="端口放行")
def test_port_ignored_in_floating_and_dc_path():
    """已声明端口：既不报悬空，也不报无直流通路（通路交给外部负责）。

    这条单独拆出来，因为它是「端口」这个概念的全部意义所在。
    """
    c = Circuit("blk")
    c.R("in", "n1", 1e3)
    c.C("n1", "out", 1e-9)          # n1 上只有 R 与 C，直流上到不了地
    c.R("n1", GND, 1e6)
    c.ports = {"in": "in", "out": "out"}
    iss = c.lint()
    is_false([i for i in iss if i.level == "error"],
             f"端口 in/out 不该被报错，实测 {[(i.title, i.ref) for i in iss if i.level == 'error']}")
    # 去掉端口声明，同样的电路就该报 in/out 悬空
    c.ports = {}
    iss2 = c.lint()
    refs = {i.ref for i in iss2 if "悬空" in i.title}
    is_true({"in", "out"} <= refs, f"去掉端口声明后应报 in/out 悬空，实测 {refs}")


# ==========================================================================
# 汇总行为
# ==========================================================================
@case(group="汇总行为")
def test_ordering_dedup_include_info():
    """汇总：按 error→warn→info 排序、按 (code, ref) 去重、include_info=False 去掉 info。

    防的是：同一颗器件刷 5 条一样的错误（把真正的关键信息淹掉）。
    """
    H.need_ngspice()
    c = Circuit("q")
    c.V("vcc", GND, dc=5.0)
    c.R("vcc", "b", 100e3)
    c.R("vcc", "c", 100.0)
    c.Q("c", "b", GND, "Q2N3904")
    iss = L.lint(c, c.op())
    order = {"error": 0, "warn": 1, "info": 2}
    ranks = [order[i.level] for i in iss]
    is_true(ranks == sorted(ranks), f"应按 error→warn→info 排序，实测 {[(i.level, i.code) for i in iss]}")
    keys = [(i.code, i.ref) for i in iss]
    is_true(len(keys) == len(set(keys)), f"不应有重复的 (code, ref)，实测 {keys}")
    no_info = L.lint(c, c.op(), include_info=False)
    is_false([i for i in no_info if i.level == "info"], f"include_info=False 时应去掉 info，实测 {_levels(no_info)}")


@case(group="汇总行为")
def test_issue_validation_and_str():
    """Issue 的 level 只接受 error/warn/info，str() 带中文级别与位号。

    防的是：有人加了个 "critical" 级别 → 排序里 rank=3，永远沉在最后，
    等于静默丢掉了最严重的问题。
    """
    raises(ValueError, L.Issue, "critical", "标题", "详情", what="非法 level")
    ok = L.Issue("error", "悬空节点", "节点 x 只连一个引脚", "x", "floating")
    is_true("错误" in str(ok) and "x" in str(ok), f"str 应含级别与位号，实测 {ok}")
    d = ok.as_dict()
    is_true(d["code"] == "floating" and d["ref"] == "x", f"as_dict 字段应齐全，实测 {d}")


if __name__ == "__main__":
    sys.exit(H.main("test_lint", "test_lint：静态检查与工作点检查"))
