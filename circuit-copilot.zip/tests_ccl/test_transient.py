"""瞬态指标：rise_time / fall_time / overshoot_pct / settling_time / steady_state。

这一层防的是「波形有了，指标是编的」。四个指标全都是**一个数字**，用户看到
「上升时间 219µs」不会去核对它是怎么算出来的 —— 所以这里每条都用解析式钉住：

  - RC 一阶阶跃：10%~90% 上升时间 = ln(9)·τ = **2.197τ**；
    建立时间（±2% 带）= ln(50)·τ = **3.912τ**；稳态 = 阶跃幅度。
  - 二阶 Sallen-Key：超调 = `exp(−πζ/√(1−ζ²))·100`，**ζ = 1/(2Q)**。
    契约初稿曾把「16.3%」标成 Q=2 的值（那其实是 Q=1），所以专门有一条用例
    把「Q=2 ≈ 44.4% / Q=1 ≈ 16.3%」钉死 —— 抄错公式的实现在这两条上互换角色，
    一测就能看出来。
  - steady_state 是**末 10% 时间窗的均值**，不是末点。构造一个仍在上升的波形
    （t_stop = 1τ），末点与窗口均值差 3%：只断言「约等于末点」的实现在这里必挂。
  - 测不到就必须 None：纯正弦、op / ac / dc 结果上调用这些方法，一律不许编数。

口径限制（写在 `ccl/CONTRACT.md`，不是 bug，但仍然要有用例守住边界）：
  · 多周期脉冲串的末段落在低相位 → 四个指标全 None（为了不误报纯正弦）
  · t_stop 太短（如只跑 1τ）时高电平取自末段均值 → rise_time 量的是「这段爬了
    多少」，比真值小。用例里用「同一口径的解析式」核对，证明偏差来自口径而非实现。
"""

from __future__ import annotations

import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, is_true  # noqa: E402

from ccl.blocks import sallen_key_lowpass  # noqa: E402
from ccl.core import GND, Circuit  # noqa: E402

# 一阶 RC：τ = R·C = 1k · 100n = 100µs
R_OHM = 1e3
C_FARAD = 100e-9
TAU = R_OHM * C_FARAD

# 10%~90% 上升时间 / ±2% 建立时间的解析系数（一阶系统）
RISE_COEF = math.log(9.0)        # 2.1972
SETTLE_COEF = math.log(1 / 0.02)  # 3.9120（|v−A|/A = 2% → e^{−t/τ}=0.02）


# 同一条波形常被几条用例同时用（rise/steady/settling/口径…），缓存一下：
# 一条用例只读不写，重复起 ngspice 纯属浪费（每个 Sallen-Key 仿真约 0.3s）。
_SIM_CACHE: dict[tuple, object] = {}


def _cached(key: tuple, build):
    if key not in _SIM_CACHE:
        _SIM_CACHE[key] = build()
    return _SIM_CACHE[key]


def _rc_step(v1: float = 0.0, v2: float = 5.0, t_stop: float = 5e-3,
             t_step: float = 1e-6, **pulse_kw):
    """RC 阶跃响应（带缓存）。

    ⚠️ 必须用**单次阶跃**：默认 PULSE 是 pw=500µs / per=1ms 的多周期方波，
    t_stop=5ms 时末段落在低相位 → 指标全 None（见 test_default_pulse_breaks_metrics）。
    所以这里把 pw 放大到比 t_stop 还长，保证整个过程只有一个上升沿。
    """
    kw = dict(v1=v1, v2=v2, td=0.0, tr=1e-9, tf=1e-9, pw=10e-3, per=20e-3)
    kw.update(pulse_kw)

    def build():
        c = Circuit("rc_step")
        c.PULSE("in", GND, **kw)
        c.R("in", "out", R_OHM)
        c.C("out", GND, C_FARAD)
        return c.tran(t_step, t_stop)

    return _cached(("rc", t_step, t_stop, tuple(sorted(kw.items()))), build)


def _rc_analytic(t: float, amp: float = 5.0) -> float:
    """一阶阶跃的解析解 v(t) = A·(1 − e^{−t/τ})。"""
    return amp * (1.0 - math.exp(-t / TAU))


def _tail_mean_analytic(t_stop: float, tail: float, amp: float = 5.0) -> float:
    """末 tail 比例时间窗内解析解的**均值**（steady_state 的口径就是这个）。

    ∫A(1−e^{−t/τ})dt / (t2−t1) = A·[1 − τ(e^{−t1/τ} − e^{−t2/τ})/(t2−t1)]
    """
    t1 = (1.0 - tail) * t_stop
    t2 = t_stop
    return amp * (1.0 - TAU * (math.exp(-t1 / TAU) - math.exp(-t2 / TAU)) / (t2 - t1))


def _sallen_key(q: float, fc: float = 1e3, t_stop: float = 5e-3):
    """Sallen-Key 低通（单位阶跃 0→1V）的瞬态响应（带缓存）。"""

    def build():
        c = Circuit(f"sk_q{q:g}")
        c.PULSE("in", GND, v1=0.0, v2=1.0, td=0.0, tr=1e-9, tf=1e-9,
                pw=50e-3, per=100e-3)
        c.use_ports(sallen_key_lowpass(fc=fc, q=q), {"in": "in", "out": "out"})
        return c.tran(1e-6, t_stop)

    return _cached(("sk", q, fc, t_stop), build)


def _overshoot_theory(q: float) -> float:
    """二阶欠阻尼阶跃超调：exp(−πζ/√(1−ζ²))·100，ζ = 1/(2Q)。

    契约初稿把 16.3%（=Q=1）写成了 Q=2 的值 —— 所以这个函数和对应的用例
    是同一条纪律的一部分：公式与实现必须同一个口径。

    ⚠️ 只对 **ζ < 1（Q > 0.5）** 成立：Q=0.5 恰好是**临界阻尼**（ζ=1），
    分母 √(1−ζ²)=0，理论超调是 0（不振荡）。Q<0.5 过阻尼，同样没有超调。
    """
    zeta = 1.0 / (2.0 * q)
    if zeta >= 1.0:
        return 0.0                       # 临界/过阻尼：没有超调
    return math.exp(-math.pi * zeta / math.sqrt(1.0 - zeta * zeta)) * 100.0


# ==========================================================================
# 一阶 RC 阶跃
# ==========================================================================
@case(group="一阶 RC 阶跃")
def test_rc_step_metrics_match_analytic():
    """RC 阶跃（τ=100µs）：rise=2.197τ / steady=5V / overshoot≈0 / settling=3.912τ。

    一条用例把四个指标全钉在解析式上（t_stop=5ms=50τ，早已稳住）：

      10%→90% 上升时间  = ln(9)·τ   = 219.72µs
      稳态值            = 幅度 5V   （末段均值，±1%）
      超调              = 0        （一阶系统没有超调，实测应 ~1e-14%）
      建立时间(±2%)     = ln(50)·τ  = 391.20µs

    防的是：这四个数里任意一个被换成「取最近采样点」「取末点」「峰值减起点」
    之类看似合理的近似 —— 那种实现单项误差就可能到 10%，而报告里只有一句话。
    """
    H.need_ngspice()
    sol = _rc_step()
    is_true(sol.kind == "tran", f"kind 应为 'tran'，实测 {sol.kind!r}")

    rt = sol.rise_time("out")
    is_true(rt is not None, "单次上升阶跃的 rise_time 不该是 None")
    close(rt, RISE_COEF * TAU, 0.05,
          what=f"rise_time（解析 ln(9)·τ = {RISE_COEF * TAU * 1e6:.2f}µs）",
          note=f"τ = {TAU * 1e6:g}µs")

    ss = sol.steady_state("out")
    is_true(ss is not None, "steady_state 不该是 None")
    close(ss, 5.0, 0.01, what="steady_state（阶跃幅度 5V）")
    is_true(isinstance(ss, float), f"steady_state 应返回 float，实测 {type(ss).__name__}")

    ov = sol.overshoot_pct("out")
    is_true(ov is not None, "一阶系统 overshoot_pct 应返回 0.0（不是 None）")
    is_true(ov < 1.0, f"一阶 RC 没有超调，overshoot_pct 应 <1%，实测 {ov:.6g}%")

    st = sol.settling_time("out")
    is_true(st is not None, "建立完成的波形 settling_time 不该是 None")
    close(st, SETTLE_COEF * TAU, 0.03,
          what=f"settling_time（±2% 带 → 解析 ln(50)·τ = {SETTLE_COEF * TAU * 1e6:.2f}µs）")
    is_true(0 < st < 5e-3, f"settling_time 应落在记录范围内，实测 {st:.6g}s")

    ft = sol.fall_time("out")
    is_true(ft is None, f"纯上升阶跃没有下降沿，fall_time 应为 None，实测 {ft!r}")


@case(group="一阶 RC 阶跃")
def test_default_pulse_breaks_metrics():
    """★口径限制：默认 PULSE（多周期方波）在 t_stop=5ms 时四个指标全 None。

    这条是**反证**：它证明上面那些用例必须写 `pw=10e-3` 之类的单次阶跃参数，
    不是随手抄的。同时钉住「测不到就 None」的行为：末段落在低相位时，
    steady_state 拿到的是低相位窗口均值（≈1.1V），而不是高电平 5V ——
    谁要是把 `_step_levels` 的「末段安静/有平台」判据放宽，这条会说话。
    """
    H.need_ngspice()
    c = Circuit("default_pulse")
    c.PULSE("in", GND)                    # 默认 pw=500µs / per=1ms
    c.R("in", "out", R_OHM)
    c.C("out", GND, C_FARAD)
    sol = c.tran(1e-6, 5e-3)              # 5 个周期，末段在低相位

    is_true("PULSE" in sol.netlist.upper(), "网表里应有 PULSE 源（用例前提）")
    for name in ("rise_time", "fall_time", "overshoot_pct", "settling_time"):
        got = getattr(sol, name)("out")
        is_true(got is None,
                f"多周期脉冲串的 {name} 应为 None（末段落在低相位 → 不是可测的单次阶跃），"
                f"实测 {got!r}")
    ss = sol.steady_state("out")
    is_true(ss is not None, "steady_state 仍应给数（它就是末段窗口均值）")
    is_true(ss < 2.0,
            f"末段落在低相位 → steady_state 应是窗口均值而非高电平 5V，实测 {ss:.6g}V")


# ==========================================================================
# 二阶 Sallen-Key 超调
# ==========================================================================
@case(group="二阶超调")
def test_sallen_key_overshoot_matches_formula():
    """Sallen-Key 阶跃：Q=0.707/1/2 的超调对上 `exp(−πζ/√(1−ζ²))·100`（ζ=1/(2Q)）。

    实测 4.34% / 16.34% / 44.45%，理论 4.32% / 16.30% / 44.43%，误差 <5%
    （残差来自运放有限增益/带宽与采样密度，属电路非理想，不是指标算错）。

    防的是：overshoot 用「峰值/稳态」而不是「(峰值−稳态)/稳态」——
    那样 Q=0.707 会得到 104% 这种荒谬值；也是防「ζ 与 Q 抄反」。
    """
    H.need_ngspice()
    for q in (0.707, 1.0, 2.0):
        sol = _sallen_key(q)
        ov = sol.overshoot_pct("out")
        is_true(ov is not None, f"Q={q} 的 overshoot_pct 不该是 None")
        theory = _overshoot_theory(q)
        close(ov, theory, 0.05,
              what=f"Q={q} 的超调（ζ=1/(2Q)·理论值）",
              note=f"实测 {ov:.4f}% / 理论 {theory:.4f}%")
        # 稳态必须是 1V（阶跃幅度），超调是相对它的百分比
        close(sol.steady_state("out"), 1.0, 0.02,
              what=f"Q={q} 的 steady_state（1V 阶跃）")


@case(group="二阶超调")
def test_q2_is_44_percent_not_16():
    """★回归：Q=2 的超调是 ≈44.4%，Q=1 才是 ≈16.3%（契约初稿曾标反）。

    这条用例存在的唯一理由：`ccl/CONTRACT.md` 初稿把「16.3%」写成了 Q=2 的值。
    如果有人照着初稿「修正」实现（或反过来写死一张错表），Q=1 与 Q=2 的结果会
    互换角色 —— 所以这里不光核对公式，还把两个档位的**数量级区间**分别钉住：
    Q=1 落在 15~18%，Q=2 落在 42~47%，并且 Q=2 必须明显大于 Q=1。
    """
    H.need_ngspice()
    ov1 = _sallen_key(1.0).overshoot_pct("out")
    ov2 = _sallen_key(2.0).overshoot_pct("out")
    is_true(ov1 is not None and ov2 is not None,
            f"Q=1 / Q=2 的 overshoot_pct 都不该是 None，实测 {ov1!r} / {ov2!r}")
    H.in_range(ov1, 15.0, 18.0, what="Q=1 的超调（理论 16.30%，16.3% 是 Q=1 不是 Q=2）")
    H.in_range(ov2, 42.0, 47.0, what="Q=2 的超调（理论 44.43%）")
    is_true(ov2 > ov1 + 20.0,
            f"Q 越大超调越大：实测 Q=1 → {ov1:.3f}%、Q=2 → {ov2:.3f}%"
            f"（期望相差 >20 个百分点；若两者接近，说明公式里的 Q 档位串了）")


@case(group="二阶超调")
def test_overshoot_grows_with_q():
    """超调必须随 Q 单调增长（0.6→0.707→1→2）：曲线形状的定性物理约束。

    防的是：把 Q 传错位置（比如把 ζ 当 Q 传进去 → 曲线反着走）。
    公式核对用的是定点，这条用**排序**——两者一起才能排除「某一档碰巧对」。

    起点取 Q=0.6（ζ=0.833，理论 0.88%）而不是 Q=0.5：**Q=0.5 是临界阻尼**
    （ζ=1），理论超调就是 0，拿它当单调性起点会把「实现正确」误判成失败
    （实测确实返回 0.0 —— 与理论一致）。这一点本身也是口径的一部分。
    """
    H.need_ngspice()
    got = []
    for q in (0.6, 0.707, 1.0, 2.0):
        ov = _sallen_key(q).overshoot_pct("out")
        is_true(ov is not None, f"Q={q} 的 overshoot_pct 不该是 None")
        got.append((q, ov))
    for (q1, o1), (q2, o2) in zip(got, got[1:]):
        is_true(o2 > o1,
                f"超调应随 Q 单调增长：Q={q1} → {o1:.4f}%，Q={q2} → {o2:.4f}%")
    # 单调性的首档也要对上理论（Q=0.6 → 0.88%），否则「排序对但整体偏移」抓不到
    close(got[0][1], _overshoot_theory(0.6), 0.05,
          what="Q=0.6 的超调（理论 0.88%）")
    # 临界阻尼 Q=0.5：不振荡 → 超调必须是 0（不是 None，也不是几十分之一）
    crit = _sallen_key(0.5).overshoot_pct("out")
    is_true(crit is not None, "Q=0.5（临界阻尼）仍应返回 0.0 而不是 None")
    is_true(crit < 1.0,
            f"Q=0.5 是临界阻尼（ζ=1），超调应为 0，实测 {crit:.4f}%")


# ==========================================================================
# steady_state 的口径
# ==========================================================================
@case(group="steady_state 口径")
def test_steady_state_is_tail_mean_not_last_sample():
    """★回归：steady_state 必须是**末 10% 窗口的均值**，不是末点。

    做法：只跑 1τ 就停（波形还在爬），此时
        末点 v(τ)        = 5·(1−e⁻¹)  = 3.1606V
        末 10% 窗均值    = 3.0655V（解析式：`_tail_mean_analytic`）
    两者差 3.1%（>1%），所以「取末点」的实现会立刻被抓到。
    同时把窗口均值对上解析式（±0.5%），证明它真的按时间窗积分/平均，
    而不是「取末点再乘个系数」。

    为什么这个区别重要：末点会被最后一步的积分抖动带偏，多周期波形里更会
    随机落在上升/下降相位上 —— 稳态值随后进所有断言，误差会被放大成
    「设计不达标」的误判。
    """
    H.need_ngspice()
    sol = _rc_step(t_stop=TAU)            # 记录只覆盖 0 → 1τ
    last = float(sol.v("out").real()[-1])
    ss = sol.steady_state("out")
    is_true(ss is not None, "steady_state 不该是 None")
    theory = _tail_mean_analytic(TAU, 0.10)

    close(ss, theory, 0.005,
          what=f"steady_state（末 10% 窗的解析均值 {theory:.6f}V）",
          note="取末点的实现会给出 3.1606V")
    gap = abs(last - ss) / abs(ss)
    is_true(gap > 0.01,
            f"steady_state 必须区别于末点值，却被查出来相等："
            f"末点 {last:.6f}V / steady_state {ss:.6f}V（相对差 {gap * 100:.3f}%，"
            f"期望 >1% —— 说明实现取的是末点而不是窗口均值）")
    # 末点本身当然还是解析解（用例前提：波形没跑错）
    close(last, _rc_analytic(TAU), 0.01, what=f"末点 v(1τ)（解析 {_rc_analytic(TAU):.6f}V）")


@case(group="steady_state 口径")
def test_steady_state_tail_window_is_honoured():
    """`tail` 参数必须真的改窗口：tail=0.5 与 tail=0.1 给出不同的数。

    仍然只跑 1τ（波形还在爬），两档的解析均值差别很大：
        tail=0.1 → [0.9τ, 1τ] 均值 = 3.0655V
        tail=0.5 → [0.5τ, 1τ] 均值 = 2.6135V
    防的是：tail 参数被忽略（恒用 0.1），或者窗口按**点数**而不是按时间比例切
    （自适应步长下点数密度不均匀，按点数切出来的窗口并不是最后 10% 的时间）。
    """
    H.need_ngspice()
    sol = _rc_step(t_stop=TAU)
    s10 = sol.steady_state("out", tail=0.10)
    s50 = sol.steady_state("out", tail=0.50)
    is_true(s10 is not None and s50 is not None,
            f"tail=0.1 / 0.5 都应给出数值，实测 {s10!r} / {s50!r}")
    close(s10, _tail_mean_analytic(TAU, 0.10), 0.01,
          what="steady_state(tail=0.1)（解析 [0.9τ,1τ] 均值）")
    close(s50, _tail_mean_analytic(TAU, 0.50), 0.02,
          what="steady_state(tail=0.5)（解析 [0.5τ,1τ] 均值）")
    is_true(s50 < s10 * 0.95,
            f"tail 窗口变宽后均值应明显更小（波形还在爬）："
            f"tail=0.5 → {s50:.6f}V，tail=0.1 → {s10:.6f}V")

    # 参数校验：tail 越界必须报错，不许静默按某个默认值算
    from ccl.errors import CCLConfigError

    H.raises(CCLConfigError, sol.steady_state, "out", 0.0, what="tail=0")
    H.raises(CCLConfigError, sol.steady_state, "out", 1.5, what="tail=1.5")


# ==========================================================================
# 测不到就 None
# ==========================================================================
@case(group="测不到就 None")
def test_sine_has_no_step_metrics():
    """纯正弦：rise/fall/overshoot/settling 全 None（不许把正弦当阶跃）。

    防的是：任何有起伏的波形都被当成阶跃。纯正弦的「第一次穿过 90% 电平」
    完全无意义；如果实现里只按电平穿越判定，正弦会给出一个看起来很像样的
    上升时间（甚至 0），而它描述的是一个不存在的阶跃。
    """
    H.need_ngspice()
    c = Circuit("sine")
    c.SIN("in", GND, vo=0.0, va=1.0, freq=1e3)
    c.R("in", "out", R_OHM)
    c.C("out", GND, C_FARAD)
    sol = c.tran(1e-6, 5e-3)

    for name in ("rise_time", "fall_time", "overshoot_pct", "settling_time"):
        got = getattr(sol, name)("out")
        is_true(got is None, f"纯正弦的 {name} 应为 None，实测 {got!r}")
    # steady_state 在正弦上仍然给数（末段均值）—— 这本身无物理意义，
    # 但契约要求它不返回 None（它是「窗口均值」这个纯数学量），这里只记录不断言值。
    ss = sol.steady_state("out")
    is_true(ss is not None and math.isfinite(float(ss)),
            f"steady_state 在正弦上仍是有限数（末段均值），实测 {ss!r}")


@case(group="测不到就 None")
def test_op_ac_dc_have_no_time_metrics():
    """op / ac / dc 结果上没有时间轴：四个时间类指标全 None，ac/dc 的 steady_state 也 None。

    防的是：拿 ac 的频域波形去算「上升时间」（x 是频率，算出来的单位是 Hz 却被
    当成秒上报），或者 op 的单点被当成「稳态值」之外还能测上升时间。
    契约里 op 是特例：唯一那个点就是它的 steady_state（工作点）—— 这条也一起核对。
    """
    H.need_ngspice()
    c = Circuit("div")
    c.V("in", GND, dc=3.0)
    c.R("in", "out", 1e3)
    c.R("out", GND, 1e3)

    op = c.op()
    for name in ("rise_time", "fall_time", "overshoot_pct", "settling_time"):
        got = getattr(op, name)("out")
        is_true(got is None, f"op 结果的 {name} 应为 None，实测 {got!r}")
    close(op.steady_state("out"), 1.5, 1e-6,
          what="op 的 steady_state（就是工作点本身：3V 分压 → 1.5V）")

    ac = c.ac(1, 1e6, 20)
    for name in ("rise_time", "fall_time", "overshoot_pct", "settling_time", "steady_state"):
        got = getattr(ac, name)("out")
        is_true(got is None, f"ac 结果的 {name} 应为 None（没有时间轴），实测 {got!r}")

    dc = c.dc("V1", 0, 5, 1)
    for name in ("rise_time", "fall_time", "overshoot_pct", "settling_time", "steady_state"):
        got = getattr(dc, name)("out")
        is_true(got is None, f"dc 扫描结果的 {name} 应为 None（没有时间轴），实测 {got!r}")


# ==========================================================================
# 下降沿
# ==========================================================================
@case(group="下降沿")
def test_falling_step_measures_fall_time():
    """5V→0V 下降阶跃：fall_time ≈ 2.197τ，而 rise_time 必须是 None。

    防的是：只实现上升沿，下降沿直接返回上升沿的数（或 None）。
    这里还有一个陷阱要钉住：稳态值 ≈0V 时**超调百分比没有意义**
    （分母是 0），必须返回 None 而不是除出个天文数字。
    """
    H.need_ngspice()
    sol = _rc_step(v1=5.0, v2=0.0, t_stop=2e-3)
    ft = sol.fall_time("out")
    is_true(ft is not None, "下降阶跃的 fall_time 不该是 None")
    close(ft, RISE_COEF * TAU, 0.05,
          what=f"fall_time（解析 ln(9)·τ = {RISE_COEF * TAU * 1e6:.2f}µs）")
    rt = sol.rise_time("out")
    is_true(rt is None, f"纯下降波形没有上升沿，rise_time 应为 None，实测 {rt!r}")
    close(sol.steady_state("out"), 0.0, 1e-3, what="下降阶跃的稳态值（0V）")
    ov = sol.overshoot_pct("out")
    is_true(ov is None,
            f"稳态≈0V 时超调百分比无意义，应返回 None，实测 {ov!r}")


# ==========================================================================
# 口径限制（不是 bug）
# ==========================================================================
@case(group="口径限制")
def test_short_record_rise_time_follows_documented_rule():
    """t_stop=1τ 时 rise_time 明显小于 2.197τ —— 但符合**文档写明的口径**。

    这不是 bug，是 `ccl/CONTRACT.md`「已知限制 2」写清楚的事：高电平取自
    末段均值，只跑 1τ 时它只有 3.0655V，于是 10%/90% 电平变成 0.3066/2.759V，
    量到的是「这段爬了多少」（73.92µs），而不是器件真实上升时间（219.72µs）。

    这条用例的价值：用**同一口径的解析式**核对，证明偏差来自口径而不是实现算错——
        低电平 0 → 高电平 S（末段均值）
        t_lo = −τ·ln(1 − 0.1·S/A)，t_hi = −τ·ln(1 − 0.9·S/A)，rise = t_hi − t_lo
    这样可以防止有人为了「让 1τ 下也给出 219.7µs」去偷偷改口径（那会破坏
    Q=1 那些用例，并且违背契约）。
    """
    H.need_ngspice()
    amp = 5.0
    sol = _rc_step(t_stop=TAU)
    rt = sol.rise_time("out")
    is_true(rt is not None, "1τ 记录内仍应测出一个上升时间（不是 None）")
    s_end = sol.steady_state("out")            # 末段均值，口径里就是「高电平」
    t_lo = -TAU * math.log(1 - 0.1 * s_end / amp)
    t_hi = -TAU * math.log(1 - 0.9 * s_end / amp)
    close(rt, t_hi - t_lo, 0.03,
          what=(f"1τ 记录内的 rise_time（同一口径的解析值 {(t_hi - t_lo) * 1e6:.2f}µs；"
                f"高电平取末段均值 {s_end:.4f}V）"),
          note=f"器件真实上升时间是 {RISE_COEF * TAU * 1e6:.2f}µs，记录太短测不到")
    is_true(rt < 0.5 * RISE_COEF * TAU,
            f"t_stop=1τ 时 rise_time 应明显小于真值 {RISE_COEF * TAU * 1e6:.1f}µs"
            f"（口径限制），实测 {rt * 1e6:.2f}µs")


if __name__ == "__main__":
    sys.exit(H.main("test_transient", "test_transient：瞬态指标"))

@case(group="口径限制")
def test_high_q_overshoot_needs_long_enough_window():
    """回归：高 Q 时**测量窗口太短会把超调算小**。

    `overshoot_pct` 的分母是 `steady_state`（末 10% 窗均值）。Q=5 的振铃很长，
    若 t_stop 太短，窗口落在振铃里 → 稳态被低估 → 超调被低估。

    实测（fc=1kHz, Q=5）：t_stop=5ms → 70.29%（稳态估 5.0799V，还在振铃）；
    t_stop=9ms → 72.95%（稳态 5.0018V，已稳）。理论 72.92%。

    这不是 bug，是口径限制——但必须被钉住，否则有人会以为指标算错，
    或者反过来用短窗口得到一个「看起来合格」的假结论。
    """
    H.need_ngspice()

    def ov_at(t_stop):
        c = Circuit("sk_q5_window")
        c.PULSE("in", GND, v1=0, v2=5, pw=10e-3, per=20e-3)
        c.use_ports(sallen_key_lowpass(fc=1e3, q=5), {"in": "in", "out": "out"})
        sol = c.tran(1e-6, t_stop)
        return sol.overshoot_pct("out"), sol.steady_state("out")

    short_ov, short_ss = ov_at(5e-3)
    long_ov, long_ss = ov_at(9e-3)

    # 窗口太短 → 稳态未收敛 → 超调被低估
    is_true(short_ov < long_ov - 1.0,
            f"短窗口的超调应明显小于长窗口：5ms={short_ov:.2f}% vs 9ms={long_ov:.2f}%")
    is_true(abs(short_ss - 5.0) > abs(long_ss - 5.0),
            f"短窗口的稳态估计应更偏：5ms={short_ss:.4f}V vs 9ms={long_ss:.4f}V")

    # 窗口足够长 → 对上解析式 exp(-πζ/√(1-ζ²))，ζ=1/(2Q)=0.1
    zeta = 1 / (2 * 5.0)
    theory = math.exp(-math.pi * zeta / math.sqrt(1 - zeta * zeta)) * 100
    close(long_ov, theory, 0.06, what="Q=5 超调（窗口足够长时）")
