# CCL 正式测试套件（`tests_ccl/`）

CCL（`ccl/` 代码电路库，M1~M5 + 第三轮的直流扫描/瞬态指标 + 电路图渲染）的回归测试。
**一条命令跑全部**，不依赖 pytest，只用标准库 + 已在环境里的 ngspice-47；
唯一可选的第二个外部依赖是 **node**（只给 `test_schematic.py` 用，没有就 Skip）。

```bash
cd /storage/emulated/0/文件夹/dz/circuit-copilot

python3 tests_ccl/run_all.py                     # 跑全部
python3 tests_ccl/run_all.py --only test_devices # 只跑一个（也可 --only core,devices）
python3 tests_ccl/run_all.py --list              # 看会跑哪些模块
python3 tests_ccl/run_all.py -q                  # 只打汇总
python3 tests_ccl/run_all.py --strict            # 把「已知缺陷」也计入失败（CI 用）
```

单个模块也能独立跑（调试时方便）：

```bash
python3 tests_ccl/test_devices.py
```

**退出码**：`0` 全部通过（含已记录的已知缺陷，它们不是新问题）·
`1` 有失败 / 有「已知缺陷」用例意外通过 · `2` 参数错误。

---

## 覆盖了什么

| 文件 | 用例 | 覆盖 |
|---|---|---|
| `test_core.py` | 21 | 数据模型：`Circuit`/`Component`/`Pin`、`validate`、`ports`、`use`/`use_ports`、`with_`、`sweep`、`expect` 参数校验 |
| `test_compile.py` | 21 | 网表编译：数值格式化（含 **1M=毫** 的坑）、`.model` 输出、位号 SPICE 化（`netlist_ref`）、网表结构、`.control` 拒收、各类编译期错误 |
| `test_devices.py` | 21 | M1 器件 + M2 器件（D/Q/M/PULSE/SIN），**全部用解析式核对物理量** |
| `test_sim.py` | 16 | `runner`/`Solution`：ac/op/tran、指标插值精度、节点名大小写、地节点无波形、仿真失败保留现场、降序扫描 `value_at`（Lead 补的） |
| `test_dc.py` | 11 | `.dc` 直流扫描：分压线性、**二极管伏安对肖克利方程**、**两维切段 3×6 与互换 6×3**、降序扫描、单维/两维点数保护、错误路径 |
| `test_transient.py` | 11 | 4 个瞬态指标 + `steady_state` 口径：RC 阶跃（2.197τ / 3.912τ）、**二阶超调对 `exp(−πζ/√(1−ζ²))`**、末 10% 窗均值、测不到返回 `None`、下降沿 |
| `test_lint.py` | 17 | `ccl.lint` 静态检查 + 工作点检查（BJT 饱和/截止、MOS 截止/线性、电阻过载、端口放行、**地节点特判**） |
| `test_assertions.py` | 16 | `expect`/`verify`/`assert_ok`：eq/min/max、**相对 vs 绝对容差**、方向词语义、测不到判未达标 |
| `test_blocks.py` | 17 | 9 个子电路块逐个构建 + 物理核对 + 端口组合 + 报告导出（6 章节） |
| `test_ai.py` | 18 | 沙箱隔离（攻击代码全拦）、`spec_check` 目标抽取与方向词、无 Key 时的行为 |
| `test_schematic.py` | 7 | 电路图渲染（`web/ide/schematic.js`）：布局顺序、符号降级、空态、**从 SVG 几何反推连接性**（需 node，没有则 Skip） |
| **合计** | **176** | |

跑一遍约 **15~20 秒**（大部分时间在 ngspice 上，约 4 秒花在两维扫描的 10 万点保护用例上）。

---

## 两条纪律

### 1. 物理量必须用解析式核对，不许"跑通就算过"

ngspice 对一份**语法合法但参数错**的网表，照样会给你一个看起来合理的数字。
所以这里的断言一律拿解析式/物理区间当标准答案，失败时打印 **实测值 vs 期望值**：

| 核对项 | 解析式 | 容差 |
|---|---|---|
| RC 低通截止 | `fc = 1/(2πRC)` | <1% |
| 电阻分压 | `Vout = Vin·R2/(R1+R2)` | <0.1% |
| 同相 / 反相增益 | `1+R2/R1` / `R2/R1` | ±1% |
| 运放闭环带宽 | `GBW/增益` | 0.7~1.1× |
| 1N4148 正向压降 | `Vd = n·Vt·ln(I/Is) + I·Rs` | <1%（且落在 0.5~0.8V） |
| 2N3904 偏置 | `Vbe ≈ Vt·ln(Ic/Is)`；β=Ic/Ib | Vbe 0.55~0.78V、β 100~600 |
| M2N7002 饱和电流 | `Id = ½·Kp·(Vgs−Vto)²·(1+λVds)` | <15% |
| M2N7002 线性电流 | `Id = Kp·[(Vov·Vds) − Vds²/2]·(1+λVds)` | <15% |
| PULSE+RC 阶跃 | `t=τ → 63.2%`，`t=5τ → 99.3%` | <3% / <2% |
| LC 谐振 | `f0 = 1/(2π√(LC))` | <1% |
| 稳态 / 导通电阻 / 功耗 | `P = (Va−Vb)²/R` | <1% |
| **直流传输特性** | 分压 `Vout = Vin·R2/(R1+R2)`，逐点 + 逐段斜率恒定 | <0.5% |
| **二极管伏安**（扫描版） | 由实测电流反算 `Vd = n·Vt·ln(I/Is) + I·Rs` | <1%（低电流段除外） |
| **两维扫描曲线族** | `Vout = (Vin + I·1k)/2`（用例电路的两条 KCL 联立） | <0.5% |
| **`rise_time` / `fall_time`** | 一阶 10%~90% = `ln(9)·τ = 2.197τ` | <5% |
| **`settling_time`**（±2%） | 一阶 `ln(50)·τ = 3.912τ` | <3% |
| **`overshoot_pct`** | 二阶 `exp(−πζ/√(1−ζ²))·100`，`ζ = 1/(2Q)` | <5% |
| **`steady_state`（窗口口径）** | 末 tail 窗均值 `A·[1 − τ(e^{−t₁/τ}−e^{−t₂/τ})/(t₂−t₁)]` | <0.5% |

模型参数（Kp/Vto/λ/Is/N/Rs/Bf）**从 `ccl.devices.MODEL_CARDS` 里读**，
不在测试里另抄一份 —— 否则模型卡被人改错，测试会和它一起"通过"。

### 2. `known_bug`：断言不许偷偷放宽

当断言的是「物理上应该对的东西」而代码给错时，做法是**保留严格断言 + 打标记**，
不是把容差放宽到刚好通过：

```python
@case(group="测不到", known_bug="bw-lowpass|为什么错、复现在哪")
def test_bw_measurable_for_lowpass():
    ...
```

汇总里这类用例显示 🐞 并单独计数（不算"失败"），代码修好后它会自动变成
🎉「已修复？」，提醒摘掉标记。`run_all.py` 默认退出码只看**意料之外的失败**；
CI 想更严就用 `--strict`。

---

## 关键 bug 的回归（防复活）

这些用例存在的唯一理由就是「这个坑踩过，别再踩一次」：

| 回归 | 用例 | 为什么 |
|---|---|---|
| **`1M` 在网表里必须是纯十进制** | `test_compile::test_one_meg_never_uses_suffix`、`test_ngspice_actually_reads_1M_as_milli`、`test_compiled_meg_ohm_divider_is_physical` | ngspice 里大写 `M` 是**毫**（实测 1MΩ 被当成 1mΩ，差 10⁹ 倍）；`1meg` 才是兆。三条用例分别钉住：格式化不输出后缀 / ngspice 的真实行为 / 端到端分压电压 |
| **合格设计不能被判失败（相对容差语义）** | `test_assertions::test_relative_tolerance_band` | `expect("fc",1000,tol=0.10)` 的区间是 900~1100Hz。把相对容差当绝对容差会变成 ±0.1Hz，一个合格的 990Hz 设计直接判死 |
| **方向词语义（min/max）** | `test_assertions::test_mode_min_direction` / `test_mode_max_direction`；`test_ai::test_min_semantics_against_real_simulation` | 「带宽 100kHz 以上」实测 997kHz 是**合格**的，当成"约等于"会算出 897% 偏差、把好设计逼成坏设计 |
| **地节点电压取 0（不是 None）** | `test_sim::test_ground_has_no_wave_in_raw_output`、`test_lint::test_resistor_power_ground_zero_regression` | SPICE 输出里没有 `0` 号波形。`lint._volt()` 若不特判，**所有接地器件**的功耗/工作区检查会被静默跳过（lint 返回空列表，用户以为电路没问题）。后者还会把 `_volt` 临时换成"不特判"版本，证明那样真的一条都查不出来 |
| **`.control` 不得进网表（D1）** | `test_compile::test_control_block_rejected_everywhere` | 手写 `.control` 会让 `copilot.sim` 不再注入自己的控制块 → 波形不落盘 → 报「仿真未产生有效波形」，而错处不在这句话附近。四个入口（directive / 多行块 / 器件 directives / 分析卡）逐个验 |
| **位号必须过 `netlist_ref`（D5）** | `test_compile::test_netlist_ref_mapping` / `test_inlined_circuit_refs_are_legal` | ngspice 按**行首字符**判器件类型：内联的 `U1.R1` 被当成"U 型器件"→ unknown model。换下划线**治不了病**，必须补成 `R.U1.R1` |
| **PULSE/SIN 用逗号分隔（M2 硬约束）** | `test_compile::test_pulse_and_sin_tokens_have_no_space` | 空格形式会撞上编译层「token 不得含空白」的保护 |
| **错误类双继承（D4）** | `test_compile::test_validation_errors_are_dual_typed` | 编译期错误同时是 `CCLNetlistError` 与 `NodeError`/`RefError`，调用方两种 `except` 都捕得到 |
| **端口不算悬空（误报比漏报更伤信任）** | `test_lint::test_blocks_lint_clean` / `test_port_ignored_in_floating_and_dc_path` | 9 个 block 单独 lint 必须零 error，否则用户会开始无视所有 lint 结论 |
| **无 Key 不影响核心库（M1 验收 7）** | `test_ai::test_import_ccl_ai_without_key` | 在**干净子进程**里清掉 Key 并把 `CC_HOME` 指向空目录，验证 `import ccl.ai` 成功 |
| **`f3db` 未覆盖时不许编数** | `test_sim::test_f3db_uncovered_returns_none` | 曾返回 141Hz（1Hz 低通/100Hz 起扫），让所有规格在假数据上通过 |
| **低通的 `bw` 必须可测** | `test_assertions::test_bw_measurable_for_lowpass` | 曾在低通上恒为 NaN，`mode="min"` 的带宽要求因此永远判不合格 |
| **降序扫描必须真插值** | `test_dc::test_descending_sweep_matches_ascending`（`test_sim` 那条是同一条回归的最小版） | `.dc V1 5 -5 -1` 的轴是降序，而插值假设升序 → `value_at` 对所有查询都返回端点值（5/0/−5 全给 2.5V），静默读错 |
| **两维扫描必须切段** | `test_dc::test_two_dim_curves_3x6` / `test_two_dim_swap_gives_6x3` | ngspice 两维 `.dc` 是「外层固定、内层扫完」的分段结构。不切段时 18 个点连成折返锯齿，**不报错**。互换两个维度各测一遍，才能排除「内层/外层写反也碰巧对」 |
| **点数保护不许静默截断** | `test_dc::test_step_cap_clamps_to_5000` / `test_two_dim_caps_second_dim_and_total` | 10001 点夹到 5000、两维 50 万点夹到 10 万，都要写进 `warnings`；两维点数是**乘积**，只看单维永远不超限 |
| **`steady_state` 是窗口均值不是末点** | `test_transient::test_steady_state_is_tail_mean_not_last_sample` / `test_steady_state_tail_window_is_honoured` | 只跑 1τ 时末点 3.1606V、窗均值 3.0655V（差 3.1%）。取末点会被末步抖动带偏，误差随后进所有断言 |
| **Q=2 的超调是 44.4%，16.3% 是 Q=1** | `test_transient::test_q2_is_44_percent_not_16` / `test_sallen_key_overshoot_matches_formula` | **契约初稿把 16.3% 标成了 Q=2 的值**。照着初稿「修正」实现会让 Q=1/Q=2 互换角色 —— 两条用例分别钉住公式与两档的量级区间 |
| **多周期脉冲串测不出指标（口径边界）** | `test_transient::test_default_pulse_breaks_metrics` | 默认 `PULSE` 是 pw=500µs/per=1ms，`t_stop=5ms` 时末段落在低相位 → 四个指标全 `None`。这条是**反证**：证明其它用例必须用单次阶跃，同时守住「测不到就 None」 |
| **电路图连接性（丑可以，接错不行）** | `test_schematic::test_connectivity_rc_and_cascade` + `test_connectivity_analyzer_rules` | 从 SVG 几何按「只认共享端点、十字交叉不算连通」重建连通块，断言无悬空/无串网/无断线。**反推器自己也有用例**（人造十字 vs T 型），否则反推退化成「全都连在一起」时三条断言会集体空过 |
| **未知 kind 不许把图打崩** | `test_schematic::test_unknown_kind_degrades_to_rect` / `test_empty_circuit_state` | 没见过的器件要降级成方框且位号仍显示；空电路要返回空态提示且**不含 `<svg>`**（空壳 SVG 会盖掉提示） |

---

## 曾经真出过的两个 bug（本轮已修，回归用例保留）

写这套测试的过程中实地抓到两条「静默给出错答案」的缺陷，当时都用
`known_bug` 标记（严格断言 + 记为已知缺陷）。`ccl/` 侧修好后标记已摘掉，
用例本身**没有放宽**，继续当回归用：

1. **`Solution.f3db` 在扫频未覆盖 −3dB 点时编了一个数**
   （`test_sim::test_f3db_uncovered_returns_none`）
   docstring 承诺此时返回 `None`（举的例子正是「1Hz 低通却从 100Hz 开始扫」），
   实际却返回了「区间内最高点 −3dB」的第一次穿越（1Hz 低通 / 100Hz 起扫 → 141Hz）。
   后果：所有基于 `f3db` 的规格都在一个物理上无意义的数上"通过"。
   已由「参考点附近必须存在平坦段」的判据修好。

2. **低通电路的 `bw`（−3dB 带宽）测不出来**
   （`test_assertions::test_bw_measurable_for_lowpass`）
   `ccl/assertions._measure("bw")` 用「峰值两侧各找 −3dB」，而单极点低通的峰值就在
   扫描起点 → 低频侧恒为 `None` → 返回 `NaN` → 判「测不到」。
   同一个算法在 `ccl/ai/spec_check.py::_measure_bw` 里早已修过
   （峰在起点时只算高频侧），当时两处实现不一致 —— 属于漏改。
   已按同一口径修好；带通电路的 `bw` 一直是好的（`test_bw_bandpass_and_min_mode`）。

这两条是 `known_bug` 纪律的示范：**发现问题时放宽断言 = 把 bug 焊死**。
现在的套件里没有存活的已知缺陷；将来再遇到同类情况，`@case(known_bug="…")`
的机制是现成的（`--strict` 可以把它们计入失败）。

---

## 目录约定

```
tests_ccl/
  README.md          本文件
  _harness.py        极简框架：注册 / 跑 / 计时 / PASS-FAIL-SKIP / known_bug
  run_all.py         一键入口（汇总 + 退出码 + --only）
  test_core.py       ┐
  test_compile.py    │
  test_devices.py    │ 每个文件顶部都有"这一层在防什么"的说明，
  test_sim.py        │ 每条用例的 docstring 写清"它在防什么"
  test_dc.py         │
  test_transient.py  │
  test_lint.py       │
  test_assertions.py │
  test_blocks.py     │
  test_ai.py         │
  test_schematic.py  ┘
```

`test_schematic.py` 是唯一需要 **node** 的模块（`web/ide/schematic.js` 是 ES module，
Python 导入不了）。做法：一次 `node --input-type=module -e <driver>` 把要用的电路
全部渲染成 SVG 字符串从 stdout 拿回来，**断言全部在 Python 侧做**。没有 node 时
这 6 条整组 `Skip`（退出码仍是 0），跳过原因会列进汇总 —— 不会被静默忽略。

`_harness.py` 的思路参考 `tests/_harness.py`（同一个项目、同一套纪律），但代码是
重新写的、**不 import 它**：`tests/` 属于参数化工具那条线，CCL 套件不牵动它。

## 与 `scratch_m1/` 的关系

`scratch_m1/` 是开发期的临时脚本（保留原样，只读素材）。正式套件把其中**有长期
价值**的部分收编了：

- 收编：`r3_analysis_selfcheck.py`（第三轮的 `.dc` + 瞬态指标核对 → 拆成
  `test_dc.py` / `test_transient.py`，并补上「两维互换」「末段窗均值」「Q 档位」
  这些自测里没写死的断言）、`schematic_selfcheck.mjs`（51 项渲染自测 →
  `test_schematic.py`，用 Python 重写断言并保留「几何反推连接性」那条核心检查）、
  `core_eng_selfcheck.py`（fmt/refs/errors/control/x-instance 的核对思路）、
  `dev_eng_selfcheck.py`（Solution 节点名/错误路径）、`m2_verify.py`（M2 解析式核对）、
  `m3_verify.py`（断言/lint/扫描）、`m5_verify.py`（blocks/报告）、
  `lead_acceptance.py`（M1 八条验收）、`test_ai_sandbox.py` + `test_sandbox_isolation.py`
  （沙箱攻击清单）、`test_spec_bounds.py`（方向词语义）。
- **不收编**（一次性调试残留，结论已固化进上面的用例或文档）：
  `comma_probe.py`（PULSE 逗号分隔的实测探针）、`ref_conflict.py`（位号带点的分歧判定）、
  `verify_claims.py`（lead 复核 1M/首字母两个断言）、`lint_addon.py`、
  `m2_devices_addon.py`（都是**待合并的代码片段**，内容早已并入 `ccl/lint.py`、
  `ccl/devices.py`）、`test_real_requests.py`（要真模型 Key，不适合做回归）、
  `test_repair_loop.py`（同上）、`*.txt` / `*.out`（prompt 草稿与一次性输出）。
