"""直流扫描（`.dc`）：一维传输特性 / 二极管伏安 / 两维曲线族切段 / 降序 / 点数保护 / 错误路径。

这一层防的是「扫描跑通了，但读错了、切错了、静默截断了」：

  - **传输特性**：分压器的 Vout–Vin 必须是过原点的直线（每点 Vout=Vin·0.5）。
    只断言「有 11 个点」是没用的 —— 端点值被算成常量也照样 11 个点。
  - **二极管伏安**：曲线必须对上 `Vd = n·Vt·ln(I/Is) + I·Rs`（参数从
    `ccl.devices.MODEL_CARDS` 读，不在测试里另抄一份），并且高压端增量必须
    小于低压端 —— 后者才是「指数特性」的证据（线性泄放也能单调递增）。
  - **两维切段**：ngspice 的两维 `.dc` rawfile 是「外层固定、内层扫完」的分段结构，
    按点号直接连线会画出折返锯齿。`dc_curves()` 切错段时**不会报错**，只会把
    3 条曲线画成 1 条锯齿 —— 所以必须同时核对「几条 / 每条几点 / 每条的 x 是否
    是完整的内层扫描」，并且**两个维度互换**各测一遍（只测一个方向时，实现里
    「外层/内层搞反」和「碰巧对」无法区分）。
  - **降序扫描**：`.dc V1 5 -5 -1` 的轴是降序，而插值函数假设升序 —— 曾经导致
    value_at 对所有查询都返回端点值（5/0/−5 全返回 2.5）。这个错不报错，
    只静默给出错误读数。
  - **点数保护**：请求 10001 点时必须夹到 5000 并**写进 warnings**，不许静默截断
    数据（用户会以为自己看到了全区间）。
  - **错误路径**：扫电阻位号 / 扫不存在的位号都必须抛 `CCLConfigError`，且后者
    必须**列出可用位号**（只说「不存在」的报错让人无从下手）。
"""

from __future__ import annotations

import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, is_true, raises  # noqa: E402

from ccl.core import GND, Circuit  # noqa: E402
from ccl.devices import MODEL_CARDS  # noqa: E402
from ccl.errors import CCLConfigError  # noqa: E402


# --------------------------------------------------------------------------
# 被测电路
# --------------------------------------------------------------------------
def _divider() -> Circuit:
    """1k/1k 分压：Vout = Vin·0.5（解析式唯一、无模型参数）。"""
    c = Circuit("divider")
    c.V("in", GND, dc=0)              # 自动编号 V1
    c.R("in", "out", 1e3)
    c.R("out", GND, 1e3)
    return c


def _diode_rc() -> Circuit:
    """5V 经 1k 串 D1N4148 到地：Vin 扫上去，out 就是二极管正向压降 Vd。"""
    c = Circuit("diode_iv")
    c.V("in", GND, dc=0)
    c.R("in", "out", 1e3)
    c.D("out", GND, "D1N4148")
    return c


def _two_dim() -> Circuit:
    """两维扫描用的电路：V1（内层）× I1（外层）。

        V1 in 0            ← 扫它
        R1 in-->out  1k
        R2 out-->0    1k
        I1 0-->inj        ← 往 inj 注入电流（第二个被扫量）
        R3 inj-->out 1k

    解析解（两条 KCL，测试里也用它核对曲线族）：
        inj 节点：I1 注入的电流只能走 R3 → Vinj = Vout + I1·1k
        out 节点：(Vout−Vin)/1k + Vout/1k + (Vout−Vinj)/1k = 0
        联立 → **Vout = (Vin + I1·1k) / 2**
    """
    c = Circuit("two_dim")
    c.V("in", GND, dc=0)
    c.R("in", "out", 1e3)
    c.R("out", GND, 1e3)
    c.I(GND, "inj", dc=0)
    c.R("inj", "out", 1e3)
    return c


def _two_dim_theory(vin: float, i_inj: float) -> float:
    """两维扫描电路的解析解 Vout = (Vin + I·1k)/2（见 `_two_dim()` 的推导）。"""
    return (vin + i_inj * 1e3) / 2.0


def _two_dim_min() -> Circuit:
    """同一族解析解的最简两维电路（点数保护用例专用：10 万点也只要约 2s）。

        V1 in 0 / R1 in→mid 1k / R2 mid→0 1k / I1 0→mid
        mid 节点 KCL：(Vmid−Vin)/1k + Vmid/1k = I1 → **Vmid = (Vin + I1·1k)/2**
        （与 `_two_dim()` 同一个解析式，所以 `_two_dim_theory()` 直接可用）
    """
    c = Circuit("two_dim_min")
    c.V("in", GND, dc=0)
    c.R("in", "mid", 1e3)
    c.R("mid", GND, 1e3)
    c.I(GND, "mid", dc=0)
    return c


# --------------------------------------------------------------------------
# SPICE 模型卡参数解析（二极管公式核对要用）
#
# 为什么要在测试里解析 MODEL_CARDS 而不是写死 Is=2.52n 之类：
# 模型卡被改成另一个管子时，测试必须跟着走 —— 抄一份常量会让「模型卡错、
# 测试也跟着错」静默通过。这是 README「两条纪律」第 1 条的直接应用。
# 后缀必须按 SPICE 规则解释：**m 是毫、meg 才是兆**（和网表里那个 1M 坑同源）。
# --------------------------------------------------------------------------
_SPICE_SUFFIX = (
    ("meg", 1e6), ("mil", 25.4e-6), ("t", 1e12), ("g", 1e9), ("k", 1e3),
    ("m", 1e-3), ("u", 1e-6), ("n", 1e-9), ("p", 1e-12), ("f", 1e-15),
)


def _spice_num(tok: str) -> float:
    """把 `2.52n` / `.568` / `1e-9` 这类 SPICE 数字转成 float。"""
    s = tok.strip()
    mult = 1.0
    low = s.lower()
    for suf, m in _SPICE_SUFFIX:
        if low.endswith(suf):
            mult = m
            s = s[: -len(suf)]
            break
    return float(s) * mult


def _model_params(name: str) -> dict[str, float]:
    """把 `MODEL_CARDS[name]` 的参数串解析成字典（键小写）。"""
    if name not in MODEL_CARDS:
        H.skip(f"器件库里没有模型卡 {name!r}（可用：{sorted(MODEL_CARDS)}）")
    card = MODEL_CARDS[name][1]
    out: dict[str, float] = {}
    for kv in card.replace(",", " ").split():
        if "=" not in kv:
            continue
        k, v = kv.split("=", 1)
        try:
            out[k.strip().lower()] = _spice_num(v)
        except ValueError:
            continue                      # 非数字参数（如 level=1 之类见过就算）
    return out


# ngspice 的热电压：Vt = kT/q，默认温度 27°C = 300.15K。
# ngspice 内部常数（1.3806226e-23 / 1.6021918e-19）与 CODATA 差 0.005%，
# 这个差异对 Vd 的影响 <0.01%，远在 1% 容差之内。
_K_BOLTZ = 1.380649e-23
_Q_ELEC = 1.602176634e-19
_T_DEFAULT = 300.15          # 27°C


def _vt() -> float:
    return _K_BOLTZ * _T_DEFAULT / _Q_ELEC


# ==========================================================================
# 一维扫描
# ==========================================================================
@case(group="一维扫描")
def test_divider_transfer_is_straight_line():
    """分压器扫 V1 0→10V 步 1V：11 点，每点 Vout = Vin·0.5（相对误差 <0.5%）。

    防的是：把扫描量当成普通波形，于是 out 恒为某个常量（点数照样对），
    或者 x 轴与 y 轴错位（曲线整体平移一个点）。所以既核对逐点值，
    也核对「逐段斜率恒定」—— 只有真直线才有恒定斜率。
    """
    H.need_ngspice()
    sol = _divider().dc("V1", 0, 10, 1)

    is_true(sol.kind == "dc", f"kind 应为 'dc'，实测 {sol.kind!r}")
    is_true(sol.sweep_var == "V1", f"sweep_var 应为 'V1'，实测 {sol.sweep_var!r}")
    is_true(sol.sweep_unit == "V", f"sweep_unit 应为 'V'，实测 {sol.sweep_unit!r}")
    is_true(len(sol.x) == 11, f"0→10V 步 1V 应有 11 点，实测 {len(sol.x)} 点：{sol.x[:5]}…")
    close(sol.x[0], 0.0, 1e-12, what="扫描轴起点")
    close(sol.x[-1], 10.0, 1e-12, what="扫描轴终点")

    curves = sol.dc_curves("out")
    is_true(len(curves) == 1,
            f"无第二维时 dc_curves 应只给 1 条曲线，实测 {len(curves)} 条")
    c0 = curves[0]
    is_true(len(c0["x"]) == len(c0["y"]) == 11,
            f"曲线应为 11 点且 x/y 等长，实测 x={len(c0['x'])} y={len(c0['y'])}")
    is_true(c0["label"] == "", f"无第二维时 label 应为空串，实测 {c0['label']!r}")

    worst = 0.0
    for vin, vout in zip(c0["x"], c0["y"]):
        want = vin * 0.5
        got = float(vout)
        if abs(want) < 1e-9:
            is_true(abs(got) < 1e-9, f"Vin=0 时 Vout 应为 0V，实测 {got:.6g}V")
            continue
        worst = max(worst, H.rel_err(got, want))
        if H.rel_err(got, want) > 0.005:
            raise H.Fail(
                f"分压线性超差：Vin={vin:g}V 期望 Vout={want:.6g}V / "
                f"实测 {got:.6g}V（相对误差 {H.rel_err(got, want) * 100:+.3f}%，容差 ±0.5%）"
            )

    slopes = [(c0["y"][k + 1] - c0["y"][k]) / (c0["x"][k + 1] - c0["x"][k])
              for k in range(len(c0["x"]) - 1)]
    spread = max(slopes) - min(slopes)
    is_true(spread < 1e-6,
            f"逐段斜率应恒定（真直线），实测 min={min(slopes):.6f} "
            f"max={max(slopes):.6f}，波动 {spread:.3e}")

    # 轴上的任意取值也必须对（value_at 走插值，不是取最近点）
    for vin in (2.5, 7.25):
        close(sol.value_at("out", vin), vin * 0.5, 0.005,
              what=f"value_at('out', {vin})（插值读数）")

    # 扫描量本身不该混进「可用节点」里（否则用户会以为 v-sweep 是个节点）
    bad = [n for n in sol.node_names() if "sweep" in n]
    is_true(not bad, f"可用节点里不该出现扫描量，实测多出 {bad}")


@case(group="一维扫描")
def test_diode_iv_matches_model_card_formula():
    """二极管伏安：单调递增 + 高压端增量小于低压端 + 逐点对上肖克利方程。

    防的是三件事，缺一条这个用例就等于没写：
      1. 曲线**单调不减**（数据错位/折返会破坏它）
      2. **指数特性**：高压端的每伏增量必须远小于低压端（线性电阻也单调递增，
         只测单调性抓不到「二极管被当成电阻」）
      3. **逐点数值**：给定实测电流 I，`Vd = n·Vt·ln(I/Is) + I·Rs` 必须复现
         实测的 Vd（容差 1%）。参数全部从 `ccl.devices.MODEL_CARDS['D1N4148']`
         读；另抄一份常量会让「模型卡被改错」和测试一起通过。

    低电流段（|I| < 1e-5A）不参与公式核对：ngspice 的 gmin、结电压限幅在那里
    会让集总方程有百分之几的偏差 —— 那是数值收敛的常规代价，不是缺陷。
    """
    H.need_ngspice()
    par = _model_params("D1N4148")
    for key in ("is", "rs", "n"):
        is_true(key in par, f"模型卡 D1N4148 缺少参数 {key!r}，实测参数 {sorted(par)}")
    n_ideal, i_sat, rs = par["n"], par["is"], par["rs"]
    vt = _vt()

    sol = _diode_rc().dc("V1", 0, 5, 0.05)
    curves = sol.dc_curves("out")
    is_true(len(curves) == 1, f"应只有 1 条曲线，实测 {len(curves)}")
    xs, vds = list(curves[0]["x"]), [float(v) for v in curves[0]["y"]]
    is_true(len(xs) > 50, f"0→5V 步 0.05V 应有 101 点，实测 {len(xs)}")
    close(xs[0], 0.0, 1e-12, what="扫描起点")
    close(xs[-1], 5.0, 1e-9, what="扫描终点")

    # ---- 1. 单调不减 ----
    for k in range(len(vds) - 1):
        is_true(vds[k + 1] >= vds[k] - 1e-12,
                f"Vd 应单调不减：Vin={xs[k]:g}V 时 {vds[k]:.6f}V，"
                f"Vin={xs[k + 1]:g}V 时却掉到 {vds[k + 1]:.6f}V")

    # ---- 2. 高压端增量 << 低压端增量（指数特性的证据）----
    def _delta(v_lo: float, v_hi: float) -> float:
        return float(sol.value_at("out", v_hi)) - float(sol.value_at("out", v_lo))

    d_low = _delta(0.0, 1.0)        # 低压段：二极管还没完全导通
    d_high = _delta(4.0, 5.0)       # 高压段：钳在正向压降附近
    is_true(d_high < d_low * 0.05,
            f"高压端每伏增量应远小于低压端：0→1V 增量为 {d_low:.6f}V，"
            f"4→5V 增量 {d_high:.6f}V（期望 < {d_low * 0.05:.6f}V）")
    is_true(0.5 < float(sol.value_at("out", 5.0)) < 0.8,
            f"5V 时 Vd 应落在 0.5~0.8V（1N4148 正向压降区间），"
            f"实测 {float(sol.value_at('out', 5.0)):.6f}V")

    # ---- 3. 逐点对上肖克利方程（I 由实测给，反算 Vd）----
    checked = 0
    worst = (0.0, 0.0, 0.0, 0.0)          # (相对误差, Vin, 实测Vd, 理论Vd)
    for vin, vd in zip(xs, vds):
        i_meas = abs(float(sol.value_at("i(V1)", vin)))
        if i_meas < 1e-5:            # 见 docstring：低电流段不核对
            continue
        vd_theory = n_ideal * vt * math.log(i_meas / i_sat) + i_meas * rs
        err = H.rel_err(vd, vd_theory)
        if err > worst[0]:
            worst = (err, vin, float(vd), vd_theory)
        checked += 1
    is_true(checked >= 5, f"至少应有 5 个点参与公式核对，实测只核对了 {checked} 个")
    is_true(worst[0] <= 0.01,
            f"Vd 与 n·Vt·ln(I/Is)+I·Rs 超差：Vin={worst[1]:g}V 实测 {worst[2]:.6f}V "
            f"/ 理论 {worst[3]:.6f}V（相对误差 {worst[0] * 100:+.3f}%，容差 ±1%；"
            f"参数 n={n_ideal:g} Is={i_sat:g} Rs={rs:g} 取自 MODEL_CARDS，Vt={vt * 1e3:.4f}mV）")


@case(group="一维扫描")
def test_dc_metadata_and_summary():
    """`Solution` 的直流元数据：kind/sweep_*/dc_curves/summary 都得说人话。

    防的是：扫描结果被当成普通 tran 波形（kind 错了，下游全部按时间轴解读），
    以及 summary 在直流扫描上说「增益/带宽」这种明显不对的话（面板直接显示它）。
    """
    H.need_ngspice()
    sol = _divider().dc("V1", 0, 10, 2)
    is_true(len(sol.sweep_values) >= 6,
            f"sweep_values 应有 6 点，实测 {len(sol.sweep_values)}：{sol.sweep_values}")
    close(sol.sweep_values[0], 0.0, 1e-12, what="sweep_values 首点")
    close(sol.sweep_values[-1], 10.0, 1e-9, what="sweep_values 末点")
    is_true(sol.second_var == "", f"一维扫描 second_var 应为空，实测 {sol.second_var!r}")
    is_true(sol.second_values == [], f"一维扫描 second_values 应为空，实测 {sol.second_values}")
    text = sol.summary("out")
    is_true("扫描" in text, f"summary 应说明这是扫描结果，实测 {text!r}")
    is_true("V1" in text, f"summary 应点出被扫位号 V1，实测 {text!r}")
    is_true("dB" not in text, f"直流扫描的 summary 不该谈 dB/增益，实测 {text!r}")


# ==========================================================================
# 两维扫描（曲线族切段 —— 本轮最容易错的地方）
# ==========================================================================
@case(group="两维扫描")
def test_two_dim_curves_3x6():
    """V1 内层 6 点 × I1 外层 3 点 → 3 条曲线 / 每条 6 点，且每段是完整内层扫描。

    防的是**切段 bug**：不切段时 18 个点被连成一条折返锯齿（x 会 0,1,…,5,0,1,…），
    图上是「来回画的线」，而且不会抛任何异常。所以三点一起核对：
      · 几条 / 每条几点
      · 每条的 x 必须是从 0 到 5 的完整内层扫描（单调、首尾正确）
      · 每条曲线的 y 必须对上解析解 `(Vin + I·1k)/2`，且**label 的 I 值与这条
        曲线实际用的 I 一致**（切段对但 label 错位同样是 bug）
    """
    H.need_ngspice()
    sol = _two_dim().dc("V1", 0, 5, 1, second=("I1", 0, 1e-3, 5e-4))

    is_true(len(sol.x) == 18, f"两维应共 18 点（3×6），实测 {len(sol.x)}")
    is_true(sol.second_var == "I1", f"second_var 应为 'I1'，实测 {sol.second_var!r}")
    is_true(len(sol.second_values) == 3,
            f"第二维应有 3 段，实测 {len(sol.second_values)}：{sol.second_values}")
    for k, want in enumerate((0.0, 5e-4, 1e-3)):
        close(sol.second_values[k], want, 1e-9, what=f"second_values[{k}]")
    bad = [w for w in sol.warnings if "不符" in w]
    is_true(not bad, f"点数与预期不符的告警不该出现，实测 {bad}")

    curves = sol.dc_curves("out")
    is_true(len(curves) == 3, f"应切出 3 条曲线，实测 {len(curves)} 条")
    is_true([len(c["x"]) for c in curves] == [6, 6, 6],
            f"每条曲线应 6 点，实测 {[len(c['x']) for c in curves]}")

    for k, cu in enumerate(curves):
        i_val = sol.second_values[k]
        is_true(i_val in (0.0, 5e-4, 1e-3), f"第 {k} 段对应的 I1 异常：{i_val!r}")
        want_label = "I1=0A" if i_val == 0 else ("I1=0.5mA" if i_val == 5e-4 else "I1=1mA")
        is_true(cu["label"].startswith(want_label),
                f"第 {k} 段 label 应为 {want_label!r}，实测 {cu['label']!r}")
        # 每段 x 必须是完整内层扫描（切段正确 → 不是折返锯齿）
        is_true(len(cu["x"]) == 6, f"第 {k} 段应 6 点，实测 {len(cu['x'])}")
        close(cu["x"][0], 0.0, 1e-12, what=f"第 {k} 段起始 Vin")
        close(cu["x"][-1], 5.0, 1e-9, what=f"第 {k} 段结束 Vin")
        for j in range(5):
            is_true(cu["x"][j + 1] > cu["x"][j],
                    f"第 {k} 段的 x 应单调递增（折返锯齿！）：{cu['x']}")
        # 切了段还要值对得上（标签与实际用的 I 一致）
        for vin, vout in zip(cu["x"], cu["y"]):
            close(float(vout), _two_dim_theory(vin, i_val), 0.005,
                  what=f"第 {k} 段（{cu['label']}）Vin={vin:g}V 的 Vout")


@case(group="两维扫描")
def test_two_dim_swap_gives_6x3():
    """把两维互换（I1 当内层、V1 当外层）→ 6 条曲线 / 每条 3 点。

    这条与上一条配对，防的是「内层/外层写反」或「碰巧对」：ngspice 的 .dc 卡里
    **第一个源才是内层**，写反了点数总数不变（还是 18），只是每条曲线变成 3 点、
    段数变成 6 —— 如果只测一个方向，实现里 inner/outer 装反也会全绿。
    """
    H.need_ngspice()
    sol = _two_dim().dc("I1", 0, 1e-3, 5e-4, second=("V1", 0, 5, 1))
    is_true(sol.sweep_var == "I1", f"sweep_var 应为 'I1'，实测 {sol.sweep_var!r}")
    is_true(sol.second_var == "V1", f"second_var 应为 'V1'，实测 {sol.second_var!r}")
    is_true(len(sol.x) == 18, f"两维应共 18 点，实测 {len(sol.x)}")
    is_true(len(sol.second_values) == 6,
            f"第二维应有 6 段，实测 {len(sol.second_values)}：{sol.second_values}")

    curves = sol.dc_curves("out")
    is_true(len(curves) == 6, f"应切出 6 条曲线，实测 {len(curves)} 条")
    is_true([len(c["x"]) for c in curves] == [3] * 6,
            f"每条曲线应 3 点，实测 {[len(c['x']) for c in curves]}")
    for k, cu in enumerate(curves):
        v_in = sol.second_values[k]
        for i_val, vout in zip(cu["x"], cu["y"]):
            close(float(vout), _two_dim_theory(v_in, i_val), 0.005,
                  what=f"第 {k} 段（{cu['label']}）I1={i_val * 1e3:g}mA 的 Vout")


# ==========================================================================
# 降序扫描
# ==========================================================================
@case(group="降序扫描")
def test_descending_sweep_matches_ascending():
    """`.dc V1 5 -5 -1`：value_at 在 5/0/−5 处给 2.5/0/−2.5，且与升序扫描一致。

    防的是（真出过）：插值函数假设 x 升序，而降序扫描的 x 是 5,4,…,−5，
    于是任何查询都退化成端点值 —— 5/0/−5 全返回 2.5V，静默给出错误读数。

    做法：不光核对绝对值，还把降序结果的每个点与升序扫描（`0→10` 里对应的
    Vin/2）逐点比对 —— 一旦插值退化成端点值，这两条会立刻对不上。
    （`test_sim::test_descending_sweep_value_at_is_correct` 是 Lead 加的最小回归，
    这里补上「与升序一致」和「dc_curves 自己也不折返」两层。）
    """
    H.need_ngspice()
    sol = _divider().dc("V1", 5, -5, -1)
    is_true(len(sol.x) == 11, f"5→−5 步 −1 应有 11 点，实测 {len(sol.x)}：{sol.x}")
    is_true(sol.x[0] > sol.x[-1], f"扫描轴应确实是降序，实测首尾 {sol.x[0]:g} / {sol.x[-1]:g}")
    close(sol.x[0], 5.0, 1e-12, what="降序扫描起点")
    close(sol.x[-1], -5.0, 1e-9, what="降序扫描终点")

    for vin, want in ((5.0, 2.5), (0.0, 0.0), (-5.0, -2.5), (2.5, 1.25)):
        got = float(sol.value_at("out", vin))
        close(got, want, 0.005, what=f"降序扫描 value_at('out', {vin:g})")

    curves = sol.dc_curves("out")
    is_true(len(curves) == 1, f"应只有 1 条曲线，实测 {len(curves)}")
    pairs = list(zip(curves[0]["x"], curves[0]["y"]))
    is_true(len(pairs) == 11, f"曲线应 11 点，实测 {len(pairs)}")
    for vin, vout in pairs:
        close(float(vout), vin * 0.5, 0.005, what=f"降序扫描曲线在 Vin={vin:g}V 处")

    # 与升序扫描一致（同一段 Vin 区间）
    asc = _divider().dc("V1", -5, 5, 1)
    for vin in (-5.0, -2.0, 0.0, 1.5, 5.0):
        close(float(sol.value_at("out", vin)), float(asc.value_at("out", vin)), 1e-9,
              what=f"升序/降序在同一 Vin={vin:g}V 处读数")


# ==========================================================================
# 点数保护
# ==========================================================================
@case(group="点数保护")
def test_step_cap_clamps_to_5000():
    """请求 10001 点（(10−0)/0.001）→ 夹到 5000 点，并在 warnings 里写明改了什么。

    防的是：静默截断/静默放行。10001 点并不致命，但同样的漏保护在
    「步长 1µV」这类手滑参数上会直接把 ngspice 拖死，而用户看不到任何提示。

    注意 warnings **非空**是个弱断言（ngspice 自己就带两条 Note），所以这里
    要求的是「点名了上限与步长」的那条，同时反向核对：正常小扫描不该出现该告警。
    """
    H.need_ngspice()
    sol = _divider().dc("V1", 0, 10, 0.001)
    n = len(sol.x)
    is_true(n <= 5000, f"点数应被夹到 ≤5000，实测 {n}")
    is_true(n >= 4900, f"夹紧后应接近 5000 点（不是被砍成很少），实测 {n}")
    hits = [w for w in sol.warnings if "上限" in w and "5000" in w]
    is_true(bool(hits),
            f"warnings 里应有「点数超过上限 5000」的说明，实测 warnings={sol.warnings}")
    is_true(any("步长" in w for w in hits),
            f"该告警应说明步长被放大，实测 {hits}")
    # 夹紧不等于砍掉尾巴：仍须覆盖到 stop
    close(sol.x[-1], 10.0, 1e-6,
          what="夹紧后的末点（必须仍覆盖到 10V，不能只扫一半）")

    # 反向：正常扫描不该报「上限」
    ok = _divider().dc("V1", 0, 10, 1)
    is_true(not any("上限" in w for w in ok.warnings),
            f"11 点的扫描不该有上限告警，实测 {ok.warnings}")
    is_true(len(ok.x) == 11, f"正常扫描应 11 点，实测 {len(ok.x)}")


@case(group="点数保护")
def test_two_dim_caps_second_dim_and_total():
    """两维保护：第二维 > 500 段 → 夹到 500；两维总点数 > 100000 → 减少段数。

    防的是：只保护了第一维。两维扫描的点数是**乘积**，1001×501 = 50 万点，
    ngspice 会吃掉几个 GB 内存 —— 而单看任何一维都不超 5000。所以两条上限都
    必须真的生效，并且**写进 warnings**（用户得知道自己看到的不是全分辨率）。
    """
    H.need_ngspice()
    sol = _two_dim_min().dc("V1", 0, 1000, 1, second=("I1", 0, 1e-3, 2e-6))
    n = len(sol.x)
    n_seg = len(sol.second_values)
    is_true(n_seg <= 500, f"第二维应被夹到 ≤500 段，实测 {n_seg}")
    is_true(n <= 100_000, f"两维总点数应 ≤100000，实测 {n}")
    w_text = " | ".join(sol.warnings)
    is_true("上限" in w_text, f"应有第二维上限的告警，实测 warnings={sol.warnings}")
    is_true("100000" in w_text or "段" in w_text,
            f"应有「两维总点数上限」的告警（说明减少了段数），实测 warnings={sol.warnings}")
    bad = [w for w in sol.warnings if "不符" in w]
    is_true(not bad, f"夹紧后点数应与预期一致（不该再报点数不符），实测 {bad}")

    curves = sol.dc_curves("mid")
    is_true(len(curves) == n_seg,
            f"切出的曲线数应等于实际段数 {n_seg}，实测 {len(curves)} 条")
    inner = len(curves[0]["x"]) if curves else 0
    is_true(all(len(c["x"]) == inner for c in curves),
            f"每条曲线点数应一致（{inner}），实测 {[len(c['x']) for c in curves[:6]]}…")
    is_true(inner * n_seg == n,
            f"内层 {inner} 点 × {n_seg} 段应等于总点数 {n}（切段丢了数据就是 bug）")
    # 夹紧之后数值仍须可信：抽首/中/末三段对解析解（改动点数不等于算错）
    for k in (0, n_seg // 2, n_seg - 1):
        cu = curves[k]
        for vin, vout in zip(cu["x"][:2] + cu["x"][-1:], cu["y"][:2] + cu["y"][-1:]):
            close(float(vout), _two_dim_theory(vin, sol.second_values[k]), 0.005,
                  what=f"夹紧后第 {k} 段（{cu['label']}）Vin={vin:g}V 的 Vmid")


# ==========================================================================
# 错误路径
# ==========================================================================
@case(group="错误路径")
def test_sweep_non_source_rejected():
    """扫电阻位号 → CCLConfigError，且报错要指路（直流扫描只能扫源）。

    防的是：把电阻当成可扫量递下去，ngspice 报一句难以理解的错，或者更糟 ——
    扫了「电阻某个内部变量」，用户以为扫到了阻值。报错必须明确告诉用户
    「扫参数请用 sweep / with_」。
    """
    H.need_ngspice()
    e = raises(CCLConfigError, _divider().dc, "R1", 0, 5, 1, what='dc("R1", ...)')
    text = str(e)
    is_true("R1" in text, f"报错应点出出错的位号 R1，实测：{text}")
    is_true("独立电压源" in text or "独立" in text,
            f"报错应说明必须扫独立源，实测：{text}")
    is_true("sweep" in text or "with_" in text,
            f"报错应给出替代做法（sweep / with_），实测：{text}")


@case(group="错误路径")
def test_sweep_unknown_ref_lists_available_refs():
    """扫不存在的位号 → CCLConfigError，且**报错里列出可用位号**。

    防的是：只说「没有这个位号」。用户面对一份 20 个器件的电路完全无从下手，
    这是这类库最典型的挫败感来源（`test_sim` 里 NodeError 那条同一条纪律）。
    """
    H.need_ngspice()
    c = _divider()
    refs = [x.ref for x in c.components]
    e = raises(CCLConfigError, c.dc, "V9", 0, 5, 1, what='dc("V9", ...)')
    text = str(e)
    is_true("V9" in text, f"报错应点出不存在的位号 V9，实测：{text}")
    is_true("可用位号" in text or "可用" in text,
            f"报错应提示「可用位号」，实测：{text}")
    for r in refs:
        is_true(r in text, f"报错应列出可用位号 {r}，实测：{text}")


@case(group="错误路径")
def test_sweep_argument_validation():
    """参数校验：step=0 / start==stop / 方向不一致 / 两维扫同一个源 / second 形状错。

    防的是：把非法参数递给 ngspice。最阴的是**方向不一致**（start<stop 却给负步长）：
    ngspice 可能一个点都不扫，或者扫出空结果，而上层把它当成「电路没问题」。
    """
    H.need_ngspice()
    c = _divider()
    raises(CCLConfigError, c.dc, "V1", 0, 5, 0, what="step=0")
    raises(CCLConfigError, c.dc, "V1", 2, 2, 1, what="start == stop")
    raises(CCLConfigError, c.dc, "V1", 0, 5, -1, what="升区间配负步长")
    raises(CCLConfigError, c.dc, "V1", 5, 0, 1, what="降区间配正步长")
    raises(CCLConfigError, c.dc, "", 0, 5, 1, what="空位号")
    raises(CCLConfigError, c.dc, "V1", 0, 5, 1, second=("V1", 0, 1e-3, 1e-4),
           what="两维扫同一个源")
    raises(CCLConfigError, c.dc, "V1", 0, 5, 1, second=("I1", 0, 1e-3),
           what="second 不是 4 元组")


if __name__ == "__main__":
    sys.exit(H.main("test_dc", "test_dc：直流扫描"))
