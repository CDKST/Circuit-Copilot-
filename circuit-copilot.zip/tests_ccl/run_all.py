#!/usr/bin/env python3
"""CCL 测试套件的一键入口。

    python3 tests_ccl/run_all.py                  # 跑全部
    python3 tests_ccl/run_all.py --only test_devices
    python3 tests_ccl/run_all.py --only core,devices   # 前缀匹配，逗号分隔
    python3 tests_ccl/run_all.py --list           # 只列会跑哪些模块
    python3 tests_ccl/run_all.py --strict         # 把「已知缺陷」也算失败（CI 用）

## 这个入口要解决的问题

改造前 CCL 的测试是一堆散落的手跑临时脚本（里程碑期的一次性自测，如
`m2_verify.py` / `lead_acceptance.py` / `test_ai_sandbox.py`——这些脚本已随里程碑
临时目录一并清理删除，此处仅作历史说明），命名不统一、没有统一出口、
还混着一次性的调试残留。现在只有一条命令，输出一张汇总表。

## 退出码

    0   全部通过（含已记录的已知缺陷 —— 它们不是新问题）
    1   有失败 / 有「已知缺陷」用例意外通过（说明标记该摘了）
    2   参数错误
"""

from __future__ import annotations

import argparse
import importlib
import os
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402

# 固定执行顺序：先模型/编译（快、无仿真），再器件/仿真（慢），最后 AI。
# 顺序本身有意义：前面挂了，后面的物理核对就没有讨论价值。
#
# 第三轮新增的三个模块：
#   - test_dc / test_transient 是分析层（.dc 扫描 + 4 个瞬态指标），与 test_sim 同层，
#     都依赖 runner / Solution 的契约 —— test_sim 挂了它们必然跟着挂，所以排在其后；
#   - test_schematic 是渲染层（web/ide/schematic.js），与 ccl/ 的仿真无关；它要起
#     node 子进程，放在最后，避免拖慢前面的反馈。
ORDER = [
    "test_core",
    "test_compile",
    "test_devices",
    "test_sim",
    "test_dc",
    "test_transient",
    "test_lint",
    "test_assertions",
    "test_blocks",
    "test_ai",
    # 回归钉：刚修好的一批 bug（save/子电路、开关 Vt、live 末点、保峰降采样…）。
    # 排在这里是因为它同时用到 ccl + copilot + web.ccl_api 三层，前面任何一层挂了
    # 它都会跟着红 —— 把它放最后，读报告时先看到的是根因，不是它的一串连带失败。
    "test_regressions",
    "test_schematic",
]


def discover() -> list[str]:
    """找 tests_ccl/ 下所有 test_*.py：先按 ORDER，再补上没列进去的（按字母）。"""
    found = []
    for fn in sorted(os.listdir(_HERE)):
        if fn.startswith("test_") and fn.endswith(".py"):
            found.append(fn[:-3])
    known = [m for m in ORDER if m in found]
    extra = [m for m in found if m not in known]
    return known + extra


def _norm(name: str) -> str:
    """把 --only 的写法统一成模块名：devices / test_devices / test_devices.py 都接受。"""
    n = name.strip()
    if n.endswith(".py"):
        n = n[:-3]
    return n if n.startswith("test_") else f"test_{n}"


def select(modules: list[str], only: list[str]) -> list[str]:
    if not only:
        return modules
    wanted: list[str] = []
    for raw in only:
        for part in str(raw).split(","):
            part = part.strip()
            if not part:
                continue
            exact = _norm(part)
            if exact in modules:
                wanted.append(exact)
                continue
            # 前缀匹配：--only dev 也能命中 test_devices
            hits = [m for m in modules if m.startswith(exact) or exact in m]
            if not hits:
                raise SystemExit(
                    f"❌ --only {part!r} 没有匹配到任何模块；可用：{', '.join(modules)}"
                )
            wanted.extend(hits)
    out: list[str] = []
    for m in modules:
        if m in wanted and m not in out:
            out.append(m)
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="CCL 测试套件一键入口",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--only", action="append", default=[], metavar="MODULE",
                    help="只跑指定模块（可逗号分隔、可用前缀，如 --only test_devices）")
    ap.add_argument("--list", action="store_true", help="只列出会跑的模块，不执行")
    ap.add_argument("--strict", action="store_true",
                    help="把「已知缺陷」也当作失败（默认不算，因为它们已记录在案）")
    ap.add_argument("-q", "--quiet", action="store_true", help="只打汇总，不打每条用例")
    args = ap.parse_args(argv)

    modules = discover()
    picked = select(modules, args.only)

    if args.list:
        print("会跑的模块：")
        for m in picked:
            print(f"  - {m}")
        return 0

    print("=" * 74)
    print("  CCL 测试套件（ccl/ 代码电路库）")
    print("=" * 74)
    print(f"  python {sys.version.split()[0]} · ngspice {H.ngspice_version()} · "
          f"cwd {os.path.basename(_ROOT)}")
    print(f"  模块 {len(picked)} 个：{', '.join(m[5:] if m.startswith('test_') else m for m in picked)}")

    total = H.Summary()
    t0 = time.perf_counter()
    for mod in picked:
        print(f"\n{'─' * 74}\n▶ {mod}\n{'─' * 74}")
        try:
            importlib.import_module(mod)
        except Exception:  # noqa: BLE001 —— 模块导入失败也要进汇总，不能直接崩
            import traceback

            traceback.print_exc()
            print(f"  ❌ {mod} 导入失败，本模块全部用例未执行")
            continue
        if not any(c.module == mod for c in H.CASES):
            print(f"  ⚠️ {mod} 没有注册任何用例（文件存在但没有 @case？）")
            continue
        s = H.run(mod, verbose=not args.quiet)
        total.extend(s)
        print(f"  ── {mod}: 通过 {s.passed} · 失败 {s.new_fails} · "
              f"跳过 {s.skipped} · 已知缺陷 {s.known_bug_fails} · {s.seconds:.1f}s")

    total.seconds = time.perf_counter() - t0
    print(H.report(total, "CCL 测试套件汇总"))

    code = 0 if total.ok else 1
    if args.strict and total.known_bug_fails:
        print(f"  （--strict：{total.known_bug_fails} 个已知缺陷计入失败）")
        code = 1
    print(f"\n退出码 {code}")
    return code


if __name__ == "__main__":
    sys.exit(main())
