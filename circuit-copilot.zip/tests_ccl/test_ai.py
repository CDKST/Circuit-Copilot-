"""AI 层（`ccl.ai`）：沙箱隔离、指标核对（spec_check）、无 Key 时的行为。

这一层最危险的失败模式不是"报错"，而是**看起来成功、实际错得离谱**：

  - 模型生成的代码在 exec 之前必须被 AST 拦下来（`import os`、`open`、`eval`、
    下划线属性逃逸……），否则等于把用户的机器交给模型
  - 「跑通 + 仿真收敛」不等于满足需求。需求里的数（截止频率/带宽/增益）必须
    从 prompt 抽出来与实测对账，对不上就是失败
  - 方向词必须按不等式判：「带宽 100kHz 以上」实测 997kHz 是**合格**的，
    当成「约等于」会算出 897% 偏差、把好设计逼成坏设计（实测事故）
  - 没有 API Key 时 `import ccl.ai` 绝不能失败，`generate()` 也不能崩调用方

★ 本文件的所有用例都**不依赖真实模型**：能用 `_llm=` 注入假 LLM 的都注入，
  需要的只是"确定性部分"（沙箱、指标抽取、无 Key 行为）。这样测试既快又稳。
"""

import os
import subprocess
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, in_range, is_false, is_true, raises  # noqa: E402

from ccl.ai import explain, review  # noqa: E402
from ccl.ai.generate import LLMUnavailable, generate  # noqa: E402
from ccl.ai.sandbox import ALLOWED_IMPORTS, check_source, run_source  # noqa: E402
from ccl.core import GND, Circuit  # noqa: E402

SPEC = __import__("importlib").import_module("ccl.ai.spec_check")


class DeadLLM:
    """假 LLM：永远"不可用"。用来把 AI 层里**确定性部分**单独测出来。

    真实环境里 ~/.cc/config.json 可能配着 Key（本机就配了一个指向本地代理的），
    直接调 review()/explain() 会去连网络 —— 测试必须自己把这条路堵死，
    否则测试结果取决于"今天代理通不通"。
    """

    model = "dead"

    def available(self) -> bool:
        return False

    def chat(self, *a, **k):
        raise RuntimeError("测试里不允许真的调用模型")


def _rc(fc: float, *, c: float = 100e-9) -> Circuit:
    ckt = Circuit("rc")
    ckt.V("in", GND, ac=1)
    ckt.R("in", "out", 1.0 / (2 * 3.141592653589793 * fc * c))
    ckt.C("out", GND, c)
    return ckt


# ==========================================================================
# 沙箱：静态拦截
# ==========================================================================
# 第一层（AST 静态检查）就该拦下来的：模块名、危险名字、下划线属性
ATTACKS_STATIC = [
    ("import os", "import os\nos.system('echo hi')"),
    ("import subprocess", "import subprocess\nsubprocess.run(['ls'])"),
    ("from os import path", "from os import path"),
    ("open()", "f = open('/etc/passwd')"),
    ("eval()", "x = eval('1+1')"),
    ("exec()", "exec('x=1')"),
    ("__import__", "__import__('os').system('id')"),
    ("下划线属性逃逸", "x = ().__class__.__bases__"),
    ("getattr", "getattr(1, 'x')"),
    ("把 os 当变量名", "os = 1"),
    ("相对导入", "from . import x"),
    ("写文件", "f = open('/sdcard/pwned.txt', 'w')\nf.write('x')"),
]

# 第二层（受限 __import__）拦下来的：根名 ccl 合法，但想借它摸到别的子模块
# （ccl.ai 不在预注入缓存里）。这一层是"即使 AST 被绕过也拿不到危险模块"的兜底。
ATTACKS_RUNTIME = [
    ("借 ccl 摸到 ccl.ai", "import ccl.ai"),
    ("from ccl.ai import sandbox", "from ccl.ai import sandbox"),
    ("导入缓存外的子模块", "import ccl.something_else"),
]


@case(group="沙箱拦截")
def test_sandbox_blocks_attacks_statically():
    """★第一层：攻击代码必须在 exec 之前被 AST 静态检查拦下（stage=static）。

    防的是：沙箱"加固"时反而漏掉某个入口。模型（或被注入的 prompt）只要有一个
    入口能用，整台机器就是别人的 —— 这条用例是逐个入口核对的清单。
    """
    for label, src in ATTACKS_STATIC:
        res = run_source(src, timeout_s=2.0)
        is_false(res.ok, f"攻击代码「{label}」必须被拦下，实测居然执行成功：{src!r}")
        is_true(res.stage == "static", f"「{label}」应在静态检查阶段被拦，实测 stage={res.stage!r}")
        is_true(bool(res.error), f"「{label}」应给出拦截原因，实测 {res.error!r}")


@case(group="沙箱拦截")
def test_sandbox_blocks_attacks_at_import_time():
    """★第二层：AST 放行（根名 ccl 合法）但想摸到别的子模块时，运行时导入必须拒绝。

    防的是：只靠 AST 一层。万一未来新增语法绕过 AST，白名单 __import__ 仍然是
    最后一道门 —— 它只从**预注入缓存**里取模块，摸不到 ccl.ai（那会让生成代码
    反过来调用模型），更摸不到 os/sys。
    """
    for label, src in ATTACKS_RUNTIME:
        res = run_source(src, timeout_s=2.0)
        is_false(res.ok, f"「{label}」必须被拦下，实测执行成功：{src!r}")
        is_true(res.stage in ("static", "exec"), f"「{label}」应被拦，实测 stage={res.stage!r}")
        is_true("ImportError" in (res.error or "") or "禁止" in (res.error or ""),
                f"「{label}」应报 ImportError/禁止导入，实测 {res.error!r}")


@case(group="沙箱拦截")
def test_sandbox_check_source_reports_line_numbers():
    """静态检查要回**行号**：generate() 靠它把"第 N 行 + 原文"回喂模型。

    防的是：只回一句"代码不安全"，模型没法定位，修复循环变成随机重试。
    """
    src = "import ccl\nimport os\nprint(1)\n"
    problems = check_source(src)
    is_true(bool(problems), "含 import os 的代码应有问题")
    line, msg = problems[0]
    is_true(line == 2, f"问题行号应指向第 2 行，实测 line={line}")
    is_true("os" in msg, f"问题描述应点名 os，实测 {msg!r}")
    is_false(check_source("import math\nx = math.pi\n"), "合法代码不该有问题")


@case(group="沙箱拦截")
def test_sandbox_has_no_side_effect():
    """被拦下的攻击代码绝不能产生副作用（真的写文件）。

    防的是：静态检查通过但运行时仍然执行了 —— 这条用"文件是否存在"来验证，
    比检查返回值更硬。
    """
    probe = os.path.join(tempfile.gettempdir(), "ccl_sandbox_probe.txt")
    if os.path.exists(probe):
        os.remove(probe)
    src = f"f = open({probe!r}, 'w')\nf.write('pwned')\n"
    res = run_source(src, timeout_s=2.0)
    is_false(res.ok, "写文件的代码必须被拦")
    is_false(os.path.exists(probe), f"被拦的代码不该产生文件 {probe}，但它出现了")


@case(group="沙箱拦截")
def test_sandbox_runtime_guards():
    """运行时兜底：range 上限、超时（死循环）、白名单外模块。

    静态检查是第一道闸，但"未来新增语法"或"绕不过去"的情况必须有运行时兜底。
    """
    res = run_source("r = range(10**9)", timeout_s=2.0)
    is_false(res.ok, "超长 range 必须被拦")
    is_true("range" in (res.error or ""), f"报错应说明 range 上限，实测 {res.error!r}")

    res2 = run_source("while True:\n    pass", timeout_s=1.0)
    is_false(res2.ok, "while 死循环必须被拦")
    is_true(res2.stage == "static",
            f"while 已在静态层禁止（signal 超时在子线程无效，不能依赖它），实测 stage={res2.stage!r}")


@case(group="沙箱拦截")
def test_whitelist_is_minimal():
    """导入白名单必须恰好是 {ccl, ccl.blocks, math}，**不能**含 ccl.ai。

    防的是：生成出来的代码反过来调用模型（自我递归 + 无限 API 费用），
    或者通过 ccl 的某个子模块间接拿到 IO 能力。
    """
    is_true(set(ALLOWED_IMPORTS) == {"ccl", "ccl.blocks", "math"},
            f"白名单应恰好是 ccl/ccl.blocks/math，实测 {sorted(ALLOWED_IMPORTS)}")
    is_false("ccl.ai" in ALLOWED_IMPORTS, "白名单里绝不能有 ccl.ai（否则生成代码可以反过来调模型）")


# ==========================================================================
# 沙箱：合法代码与错误定位
# ==========================================================================
@case(group="合法执行")
def test_sandbox_runs_legit_code():
    """合法生成代码：import math / ccl / ccl.blocks 都能用，能取回 Circuit，print 被捕获。

    防的是：沙箱太严把正常用法也打死（那样 AI 生成永远不可能成功）。
    """
    src = """
import math
from ccl import Circuit, GND
from ccl.blocks import BLOCKS

def build():
    c = Circuit("gen")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-9 * math.pi)
    print("built", len(c.components))
    return c
"""
    res = run_source(src)
    is_true(res.ok, f"合法代码应执行成功，实测错误：{res.error}")
    is_true(isinstance(res.circuit, Circuit), f"应取回 Circuit，实测 {type(res.circuit).__name__}")
    is_true(len(res.circuit.components) == 3, f"应建出 3 个器件，实测 {len(res.circuit.components)}")
    is_true("built 3" in res.stdout, f"stdout 应被捕获，实测 {res.stdout!r}")


@case(group="合法执行")
def test_sandbox_error_carries_line():
    """代码出错时必须回**行号 + 异常类型**（这是修复循环的全部依据）。

    三类错误各测一遍：不存在的器件方法（AttributeError）、
    器件参数被库拦住（CCLConfigError）、语法错误（SyntaxError）。
    """
    res = run_source("from ccl import Circuit\ndef build():\n    c = Circuit('x')\n"
                     "    c.NotADevice('a', 'b')\n    return c")
    is_false(res.ok, "不存在的器件方法必须失败")
    is_true(res.line == 4, f"行号应指向第 4 行，实测 line={res.line}")
    is_true("Attribute" in (res.error or ""), f"应报告 Attribute 类错误，实测 {res.error!r}")

    res2 = run_source("from ccl import Circuit, GND\ndef build():\n"
                      "    c = Circuit('x')\n    c.V('in', GND, ac=1)\n"
                      "    c.R('in', GND, -5)\n    return c")
    is_false(res2.ok, "负电阻必须失败（devices 层拦截）")
    is_true(res2.line == 5, f"行号应指向第 5 行，实测 line={res2.line}")
    is_true("CCLConfigError" in (res2.error or ""), f"应是库自己的配置错误，实测 {res2.error!r}")

    res3 = run_source("def build(:\n    pass")
    is_false(res3.ok, "语法错误必须失败")
    is_true(res3.line == 1, f"语法错误行号应为 1，实测 line={res3.line}")


@case(group="合法执行")
def test_sandbox_requires_circuit():
    """执行成功但没拿到 Circuit 必须报错（并说清应该怎么返回）。

    防的是：模型只打印了一段代码、或者 build() 返回了别的东西，
    而调用方以为"生成成功"。
    """
    res = run_source("x = 42")
    is_false(res.ok, "没返回 Circuit 必须算失败")
    is_true(res.stage == "extract", f"应在 extract 阶段报错，实测 {res.stage!r}")
    is_true("Circuit" in (res.error or ""), f"报错应说明要返回 Circuit，实测 {res.error!r}")

    res2 = run_source("def build():\n    return 42")
    is_false(res2.ok, "build() 返回非 Circuit 必须算失败")
    is_true("int" in (res2.error or ""), f"报错应点出实际返回类型，实测 {res2.error!r}")

    empty = run_source("   ")
    is_false(empty.ok, "空代码必须算失败")


# ==========================================================================
# spec_check：目标抽取与方向词
# ==========================================================================
@case(group="spec_check")
def test_target_extraction_and_direction_words():
    """需求里的指标与**方向词**必须一起抽出来（方向词丢了就是判错方向）。

        「带宽 100kHz 以上」   → bw = 1e5, min
        「截止频率不低于 5kHz」→ fc = 5e3, min
        「增益至少 20 倍」     → gain = 20, min
        「截止频率不超过 5kHz」→ fc = 5e3, max
        「1kHz 的 RC 低通」    → fc = 1e3, eq
    防的是：方向词被吞掉 → 下限被当成"约等于" → 合格设计被判失败。
    """
    cases = [
        ("同相放大 10 倍，带宽 100kHz 以上", "bw", 1e5, "min"),
        ("截止频率不低于 5kHz", "fc", 5e3, "min"),
        ("增益至少 20 倍", "gain_lin", 20.0, "min"),
        ("截止频率不超过 5kHz", "fc", 5e3, "max"),
        ("1kHz 的 RC 低通滤波器", "fc", 1e3, "eq"),
        ("二阶低通截止 10kHz Q=0.707", "fc", 1e4, "eq"),
    ]
    for text, key, value, bound in cases:
        got = [t for t in SPEC.parse_targets(text) if t.key == key]
        is_true(bool(got), f"{text!r} 应抽出 {key}，实测 {[(t.key, t.value, t.bound) for t in SPEC.parse_targets(text)]}")
        close(got[0].value, value, 1e-6, what=f"{text!r} 的 {key} 数值")
        is_true(got[0].bound == bound, f"{text!r} 的 {key} 方向应为 {bound}，实测 {got[0].bound!r}")


@case(group="spec_check")
def test_min_semantics_against_real_simulation():
    """★方向语义（真跑仿真）：下限「带宽 ≥100kHz」时，997kHz 必须合格、85kHz 不合格。

    这是实测踩到过的真事故：997kHz 被判 897% 偏差、逼着把电路改小到 99.75kHz，
    反而变成真的不达标。所以这条不只是单测字符串解析，而是走完整链路：
    需求文本 → 目标 → 真仿真 → 对账。
    """
    H.need_ngspice()
    targets = [t for t in SPEC.parse_targets("同相放大 10 倍，带宽 100kHz 以上") if t.key == "bw"]
    is_true(bool(targets), "应从需求里抽出带宽目标")

    for design_fc, should_pass in ((9.97e5, True), (3e5, True), (8.5e4, False)):
        sol = _rc(design_fc).ac(10, 5e6, 300)
        misses = SPEC.check_targets(targets, sol)
        is_true((not misses) == should_pass,
                f"带宽 {design_fc / 1e3:.1f}kHz 对「≥100kHz」应{'合格' if should_pass else '不合格'}，"
                f"实测 misses={[m.message() for m in misses]}")


@case(group="spec_check")
def test_max_and_eq_semantics():
    """上限（不超过）与约等于（eq）语义都必须准确。

        「截止频率不超过 5kHz」：3kHz 合格、8kHz 不合格
        「1kHz 的 RC 低通」    ：1.02kHz 合格、3kHz 不合格
    防的是：方向词互相污染（一个子句的"不超过"盖住另一个子句的"至少"）。
    """
    H.need_ngspice()
    fc_max = [t for t in SPEC.parse_targets("截止频率不超过 5kHz") if t.key == "fc"]
    for design_fc, should_pass in ((3e3, True), (8e3, False)):
        sol = _rc(design_fc).ac(10, 5e6, 300)
        misses = SPEC.check_targets(fc_max, sol)
        is_true((not misses) == should_pass,
                f"截止 {design_fc / 1e3:.1f}kHz 对「≤5kHz」应{'合格' if should_pass else '不合格'}，"
                f"实测 {[m.message() for m in misses]}")

    fc_eq = [t for t in SPEC.parse_targets("1kHz 的 RC 低通滤波器") if t.key == "fc"]
    for design_fc, should_pass in ((1.02e3, True), (3e3, False)):
        sol = _rc(design_fc).ac(10, 1e5, 300)
        misses = SPEC.check_targets(fc_eq, sol)
        is_true((not misses) == should_pass,
                f"截止 {design_fc:g}Hz 对「约 1kHz」应{'合格' if should_pass else '不合格'}，"
                f"实测 {[m.message() for m in misses]}")


@case(group="spec_check")
def test_repair_hint_is_actionable():
    """不达标时要给出**可操作的**修复方向（说清偏高/偏低、该往哪边改）。

    防的是：只回一句"没达标"，修复循环变成模型瞎试。
    """
    H.need_ngspice()
    targets = [t for t in SPEC.parse_targets("截止频率 1kHz") if t.key == "fc"]
    sol = _rc(1e4).ac(10, 1e6, 300)          # 实测 10kHz，比目标高 10 倍
    misses = SPEC.check_targets(targets, sol)
    is_true(bool(misses), "10kHz 对 1kHz 目标应判不达标")
    hint = SPEC.repair_hint(misses)
    is_true("偏高了" in hint or "降下来" in hint, f"提示应说明方向（偏高，需要降低），实测：{hint[:120]}")


# ==========================================================================
# 无 Key 时的行为
# ==========================================================================
@case(group="无 Key")
def test_generate_without_key_does_not_raise():
    """没有 Key 时 generate() 返回 ok=False（**不抛异常**），且不浪费调用。

    防的是：Web 端因为没配 Key 就 500 —— 核心库的正确做法是"AI 不可用"，
    "手写代码"这条路完全不受影响。
    """
    gen = generate("1kHz RC 低通", _llm=DeadLLM())
    is_false(gen.ok, "没有 Key 时 ok 应为 False")
    is_true("未配置" in (gen.error or ""), f"error 应说明未配置 Key，实测 {gen.error!r}")
    is_true(len(gen.attempts) == 0, f"没 Key 时不该有尝试记录，实测 {len(gen.attempts)}")
    is_true(gen.source == "", "没 Key 时不该有代码产出")


@case(group="无 Key")
def test_generate_strict_raises():
    """strict=True 时必须抛 LLMUnavailable（给"我要明确失败"的调用方用）。"""
    raises(LLMUnavailable, generate, "1kHz RC 低通", _llm=DeadLLM(), strict=True,
           what="strict=True 且无 Key")


@case(group="无 Key")
def test_import_ccl_ai_without_key():
    """★M1 验收 7：没有任何 Key / 没有配置文件时，`import ccl.ai` 必须成功。

    在**干净子进程**里验证（清掉 CC_LLM_KEY / DEEPSEEK_API_KEY 并把 CC_HOME
    指向空目录），因为当前 shell 的 ~/.cc/config.json 里是配了 Key 的 ——
    直接用本进程 import 会测不出"没 Key"这条路径。
    """
    env = dict(os.environ)
    for k in ("CC_LLM_KEY", "DEEPSEEK_API_KEY", "CC_LLM_BASE", "CC_LLM_MODEL"):
        env.pop(k, None)
    with tempfile.TemporaryDirectory() as tmp:
        env["CC_HOME"] = tmp
        proc = subprocess.run(
            [sys.executable, "-c", "import ccl.ai; print('imported')"],
            cwd=_ROOT, env=env, capture_output=True, text=True, timeout=120,
        )
    is_true(proc.returncode == 0,
            f"没有 Key 时 import ccl.ai 不该失败，stderr={proc.stderr[-400:]!r}")
    is_true("imported" in proc.stdout, f"应打印 imported，实测 {proc.stdout!r}")
    is_false("Traceback" in proc.stderr, f"不该有 traceback，实测 {proc.stderr[-300:]!r}")


@case(group="无 Key")
def test_review_and_explain_offline():
    """review()/explain() 在**没有模型**时也必须给出确定性的、有内容的结果。

    防的是：AI 一不可用，检查与解释就变成空列表 / 空字符串 ——
    「没有 Key 也要能用」是这套库的硬要求（静态检查住在 ccl.lint，不在 AI 包里）。
    """
    bad = Circuit("dang")
    bad.V("in", GND, ac=1)
    bad.R("in", "out", 1e3)
    bad.C("out", "nowhere", 1e-9)
    issues = review(bad, _llm=DeadLLM())
    is_true(bool(issues), "悬空电路必须被 review 查出来（不依赖模型）")
    is_true(any(i.level == "error" and "悬空" in i.title for i in issues),
            f"应有一条 error 级的悬空节点问题，实测 {[(i.level, i.title) for i in issues]}")
    is_true(any(i.ref == "nowhere" for i in issues), f"问题应指向节点 nowhere，实测 {[i.ref for i in issues]}")

    good = _rc(1e3)
    H.need_ngspice()
    text = explain(good, good.ac(1, 1e5, 100), _llm=DeadLLM())
    is_true(len(text) > 100, f"离线解释也应有实质内容，实测 {len(text)} 字")
    is_true("R1" in text, f"解释应提到具体位号，实测 {text[:80]!r}")
    is_true(("截止" in text or "特征频率" in text or "-3dB" in text),
            f"解释应指出这是有截止/转折频率的电路，实测 {text[:120]!r}")
    is_true("Hz" in text or "kHz" in text, f"解释应给出带单位的频率数字，实测 {text[:160]!r}")


@case(group="无 Key")
def test_no_key_does_not_affect_core():
    """没有 Key 时核心功能（建电路 + 仿真 + 断言）完全不受影响。

    防的是：AI 包被 import 到核心路径上，一没 Key 就连建电路都挂。
    """
    H.need_ngspice()
    c = _rc(1e3)
    c.expect("fc", "out", 1e3, tol=0.05)
    rep = c.verify(ac=(1, 1e5, 100))
    is_true(rep.passed, f"核心链（建电路→仿真→断言）不依赖任何模型，实测：\n{rep}")
    in_range(len(c.components), 3, 3, what="器件数")


if __name__ == "__main__":
    sys.exit(H.main("test_ai", "test_ai：沙箱隔离与无 Key 行为"))


# ==========================================================================
# 电压类目标（分压/输出 X 伏）—— 曾经是完全空白的一格
# ==========================================================================
@case(group="spec_check")
def test_parse_voltage_target():
    """「把 12V 分压到 3.3V」→ vout=3.3、vin=12，且不能把 12V 当成输出。"""
    ts = SPEC.parse_targets("把 12V 分压到 3.3V，给 STM32 的 ADC 采样")
    vout = [t for t in ts if t.key == "vout"]
    is_true(len(vout) == 1, f"应抽出恰好 1 个电压目标，实际 {[(t.key, t.value) for t in ts]}")
    is_true(abs(vout[0].value - 3.3) < 1e-9, f"目标电压应为 3.3V，实际 {vout[0].value}")
    is_true(vout[0].vin is not None and abs(vout[0].vin - 12) < 1e-9,
            f"输入电压应识别为 12V，实际 {vout[0].vin}")

    # 别的写法也要认
    for req, want in (("12V 转 3.3V", 3.3), ("输出 5V", 5.0)):
        ts2 = [t for t in SPEC.parse_targets(req) if t.key == "vout"]
        is_true(ts2 and abs(ts2[0].value - want) < 1e-9, f"{req} 应抽出 vout={want}")


@case(group="spec_check")
def test_straight_through_is_caught():
    """★核心：模型交「直通电路」（Vout≈Vin）必须被抓。

    真实事故：需求「把 12V 分压到 3.3V」，模型给了一个 Vout=12V 的电路
    （等于一根导线），而当时 parse_targets 不认电压目标 → 零对账 → 报 ok=True。
    用户会拿着这个去打样。这条用例把那个洞焊死。
    """
    H.need_ngspice()
    targets = SPEC.parse_targets("把 12V 分压到 3.3V，给 STM32 的 ADC 采样")

    def build(r1, r2, src_name="in"):
        c = Circuit("d")
        c.V(src_name, GND, ac=1)
        c.R(src_name, "out", r1)
        c.R("out", GND, r2)
        return c

    # 正确的分压：12→3.3 需要 R1/R2 = 12/3.3 - 1 = 2.636
    c_ok = build(26.4e3, 10e3)
    ms_ok = SPEC.check_targets(targets, c_ok.ac(1, 1e6, 50), circuit=c_ok)
    is_true(not ms_ok, f"正确的 12V→3.3V 分压不该被判失败：{[m.message() for m in ms_ok]}")

    # 模型交的「直通」：上臂几乎是导线
    c_bad = build(1.0, 1e9)
    ms_bad = SPEC.check_targets(targets, c_bad.ac(1, 1e6, 50), circuit=c_bad)
    is_true(bool(ms_bad), "直通电路（输出≈12V）必须被判未达标")

    # 分压比错一半也要抓
    c_mid = build(13.2e3, 10e3)
    ms_mid = SPEC.check_targets(targets, c_mid.ac(1, 1e6, 50), circuit=c_mid)
    is_true(bool(ms_mid), "分压比错一半（输出 5.17V）必须被判未达标")


@case(group="spec_check")
def test_voltage_check_finds_source_by_component_not_by_name():
    """源节点必须按电路里的电压源找，不能猜节点名。

    实测事故：模型把激励节点叫 vin/src 而不是 in，猜错时 vs 取成输出自己
    → 比值恒为 1 → 正确电路被判成「输出 = Vin」→ 真·误杀。
    """
    H.need_ngspice()
    targets = SPEC.parse_targets("把 12V 分压到 3.3V")
    c = Circuit("d")
    c.V("src_weird_name", GND, ac=1)      # 故意不叫 in
    c.R("src_weird_name", "out", 26.4e3)
    c.R("out", GND, 10e3)
    ms = SPEC.check_targets(targets, c.ac(1, 1e6, 50), circuit=c)
    is_true(not ms, f"源节点名不规范不该导致误判：{[m.message() for m in ms]}")


@case(group="spec_check")
def test_voltage_repair_hint_is_actionable():
    """不达标时必须给出可执行的修法（分压比该是多少）。"""
    H.need_ngspice()
    targets = SPEC.parse_targets("把 12V 分压到 3.3V")
    c = Circuit("d"); c.V("in", GND, ac=1)
    c.R("in","out",1.0); c.R("out",GND,1e9)
    ms = SPEC.check_targets(targets, c.ac(1,1e6,50), circuit=c)
    hint = SPEC.repair_hint(ms)
    is_true("0.275" in hint, f"修复提示应给出正确分压比 0.275，实际：{hint[:160]}")
