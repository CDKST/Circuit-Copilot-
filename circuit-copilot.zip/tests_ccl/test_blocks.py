"""可复用子电路库（9 个 block）+ 端口组合 + 报告导出。

blocks 是「代码为核心」相对图形方案的真正红利：子电路是一个**函数**，
可参数化、可组合、可单独测试。所以这里的用例守两件事：

  1. **每个块单独立得住**：能构建、声明了 ports、单独 lint 零 error、
     并且它的物理量对得上解析式（fc / 分压比 / 增益 / 工作点）
  2. **组合时不互相污染**：端口级联后增益/带宽仍对；未知端口必须报错并列出可用端口；
     端口不接时内部节点被前缀化（不会和外部节点撞车）

另有两条 CONTRACT 硬约束要守：
  - 块里**不放独立源**（内联后与外部共节点，两个理想源并联就是 singular matrix）
  - 块**必须声明 ports**（否则组合时要靠记内部节点名，最易错）
"""

import math
import os
import sys
import warnings

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, close_abs, in_range, is_false, is_true, raises  # noqa: E402

from ccl import report as RPT  # noqa: E402
from ccl.blocks import BLOCKS, catalog  # noqa: E402
from ccl.core import GND, Circuit  # noqa: E402
from ccl.errors import CCLConfigError  # noqa: E402

TAU = 2 * math.pi

# 每个块的「标准参数」与入口端口（vcc 类块需要外部供电，单独处理）
ARGS = {
    "rc_lowpass": dict(fc=1e3),
    "rc_highpass": dict(fc=1e3),
    "divider": dict(ratio=0.25),
    "rlc_bandpass": dict(f0=100e3, q=10),
    "noninv_amp": dict(gain=10, gbw=1.3e6),
    "inv_amp": dict(gain=10, gbw=1.3e6),
    "sallen_key_lowpass": dict(fc=10e3, q=0.7071),
    "bjt_ce_bias": dict(rc=100, rb=100e3),
    "emitter_follower": dict(rb=100e3, re=1e3),
    "sallen_key_highpass": dict(fc=5e3, q=0.707),
    "difference_amp": dict(gain=10),
    "twin_t_notch": dict(f0=50),
}


def _wrap(block: Circuit, *, ac=1.0, dc=0.0, drive_in: bool = True) -> Circuit:
    """把 block 内联进一个顶层电路（激励留在顶层，块里不许有源）。

    drive_in=False 用于偏置类块（bjt_ce_bias / emitter_follower）：它们的 `in`
    就是三极管基极，本身由 vcc 经基极电阻偏置；若把 `in` 接到一个理想电压源，
    基极会被那个源钳死（Vbe 直接变 0），电路完全是另一回事。
    """
    top = Circuit(f"wrap_{block.name}")
    conns = {"out": "y"}
    if drive_in:
        top.V("src", GND, ac=ac, dc=dc)
        conns["in"] = "src"
    if "vcc" in block.ports:
        top.V("vcc", GND, dc=5.0)
        conns["vcc"] = "vcc"
    top.use_ports(block, conns, prefix="B")
    return top


# ==========================================================================
# 清单与逐个构建
# ==========================================================================
@case(group="清单")
def test_catalog_complete():
    """块清单：块齐全、每个块都有说明与参数表、每个块都有说明与参数表（Web 端直接吃这份结构）。

    防的是：加/删块时忘了登记到 BLOCKS（于是 use_ports 找不到它），
    或 catalog() 缺字段导致前端渲染空白。
    """
    cat = {b["name"]: b for b in catalog()}
    # 用**显式名单**而不是数字：加块是正常进化（不该报错），
    # 但删掉/漏登记一块必须被抓住。数字会随着加块而频繁失效，名单不会。
    # 以 ARGS 为唯一事实来源：它同时驱动下面的「逐块构建」测试，
    # 所以「清单里有但 ARGS 没登记」= 那个块没有被构建检查覆盖，必须补。
    is_true(set(cat) == set(ARGS), f"块名单不符，缺 {set(ARGS) - set(cat)}，多 {set(cat) - set(ARGS)}")
    for name, info in cat.items():
        is_true(bool(info["summary"]), f"{name} 应有摘要说明")
        is_true(len(info["params"]) >= 1, f"{name} 应有参数表，实测 {info['params']}")
        is_true(any(p["required"] for p in info["params"]), f"{name} 应至少有一个必填参数")


def _make_build_case(name: str):
    def _impl():
        """单个块：能构建、声明了 ports、内部不含独立源、单独 lint 零 error。"""
        H.need_ngspice.__doc__  # 只是提醒：这条用例不需要仿真
        blk = BLOCKS[name](**ARGS[name])
        is_true(isinstance(blk, Circuit), f"{name} 应返回 Circuit，实测 {type(blk).__name__}")
        is_true(bool(blk.ports), f"{name} 必须声明 ports（组合时靠它，不靠内部节点名）")
        srcs = [c.ref for c in blk.components if c.kind.upper() in ("V", "I")]
        is_false(srcs, f"{name} 里不该有独立源（内联后会与外部源并联导致 singular matrix），实测 {srcs}")
        errs = [i for i in blk.lint() if i.level == "error"]
        is_false(errs, f"{name} 单独 lint 不该有 error，实测 {[(i.title, i.ref) for i in errs]}")
        is_true(len(blk.components) >= 2, f"{name} 至少要有 2 个器件，实测 {len(blk.components)}")

    _impl.__name__ = f"test_block_builds_{name}"
    _impl.__doc__ = f"{name}：能构建、有 ports、无独立源、单独 lint 干净。"
    return _impl


for _name in ARGS:
    case(group="逐块构建")(_make_build_case(_name))


# ==========================================================================
# 物理核对（每个块的解析式）
# ==========================================================================
@case(group="物理核对")
def test_blocks_physics():
    """每个块的物理量都要对上解析式（不是"能构建就算过"）。

        rc_lowpass / rc_highpass   f3db = fc
        divider                    Vout = ratio × Vin
        rlc_bandpass               谐振点 = f0，谐振时 |H| = 1
        noninv_amp / inv_amp       增益 = ±gain
        sallen_key_lowpass         f3db ≈ fc，Q=0.7071 时无峰化
        bjt_ce_bias                Vbe 0.55~0.78V、Vce 在放大区
        emitter_follower           Ve = Vb − Vbe（Vbe 0.55~0.8V）
    """
    H.need_ngspice()

    # --- 一阶低通 / 高通 ---
    for name in ("rc_lowpass", "rc_highpass"):
        blk = BLOCKS[name](fc=1e3)
        sol = _wrap(blk).ac(1, 1e6, 400)
        close(sol.f3db("y"), 1e3, 0.02, what=f"{name} 的 −3dB 频率（设计 1kHz）")

    # --- 分压 ---
    blk = BLOCKS["divider"](ratio=0.25)
    sol = _wrap(blk, ac=0.0, dc=4.0).op()
    close(float(sol.value_at("y", 0.0)), 1.0, 1e-3, what="divider(0.25) 在 4V 输入下的输出")

    # --- RLC 带通 ---
    f0, q = 100e3, 10.0
    blk = BLOCKS["rlc_bandpass"](f0=f0, q=q)
    sol = _wrap(blk).ac(1e3, 1e7, 800)
    mags = sol.mag("y")
    close(sol.x[mags.index(max(mags))], f0, 0.02, what="rlc_bandpass 的谐振频率")
    close(max(mags), 1.0, 0.03, what="rlc_bandpass 谐振点 |H|（串联 RLC 谐振时 = 1）")

    # --- 同相 / 反相放大 ---
    blk = BLOCKS["noninv_amp"](gain=10, gbw=1.3e6)
    sol = _wrap(blk).ac(1, 1e7, 300)
    close(abs(sol.value_at("y", 1.0)), 10.0, 0.02, what="noninv_amp 增益")
    blk = BLOCKS["inv_amp"](gain=10, gbw=1.3e6)
    sol = _wrap(blk).ac(1, 1e6, 300)
    close(abs(sol.value_at("y", 1.0)), 10.0, 0.02, what="inv_amp |增益|")

    # --- Sallen-Key：最大平坦 ---
    blk = BLOCKS["sallen_key_lowpass"](fc=10e3, q=0.7071)
    sol = _wrap(blk).ac(10, 1e6, 400)
    close(sol.f3db("y"), 10e3, 0.05, what="sallen_key_lowpass 的 −3dB 频率（设计 10kHz）")
    close_abs(sol.peak_db("y"), 0.0, 0.2, what="Q=0.7071 时通带峰化（应基本为 0dB）")

    # --- BJT 共射偏置（基极由 vcc 经 rb 偏置，不接外部源）---
    blk = BLOCKS["bjt_ce_bias"](rc=100, rb=100e3)
    sol = _wrap(blk, drive_in=False).op()
    vb = float(sol.value_at("B.b", 0.0))      # in 端口未接 → 内部节点 B.b 就是基极
    vc = float(sol.value_at("y", 0.0))
    in_range(vb, 0.55, 0.78, what="bjt_ce_bias 的 Vbe")
    in_range(vc, 0.3, 4.9, what="bjt_ce_bias 的 Vce（放大区）")

    # --- 射极跟随器 ---
    blk = BLOCKS["emitter_follower"](rb=100e3, re=1e3)
    sol = _wrap(blk, drive_in=False).op()
    vb = float(sol.value_at("B.b", 0.0))
    ve = float(sol.value_at("y", 0.0))
    in_range(vb - ve, 0.55, 0.80, what="射极跟随器的 Vbe")
    is_true(ve > 1.0, f"射极应有明显输出（跟随基极 − Vbe），实测 Ve={ve:.3f}V")
    # Ie = Ve/Re 必须与 Ib=(5−Vb)/Rb 满足 β=Ie/Ib 在合理范围
    ie = ve / 1e3
    ib = (5.0 - vb) / 100e3
    in_range(ie / ib, 100.0, 600.0, what="射极跟随器的 β = Ie/Ib")


# ==========================================================================
# 组合与端口
# ==========================================================================
@case(group="组合与端口")
def test_cascade_ports():
    """端口级联（低通 → 同相放大）：增益 10、−3dB 仍在 1kHz 左右。

    防的是：内联后子电路的输出端口没接到下一级输入（于是下一级输入悬空/接地），
    或者两级共用同一个内部节点名互相短路。
    """
    H.need_ngspice()
    top = Circuit("chain")
    top.V("src", GND, ac=1)
    top.use_ports(BLOCKS["rc_lowpass"](fc=1e3), {"in": "src", "out": "n1"}, prefix="A")
    top.use_ports(BLOCKS["noninv_amp"](gain=10, gbw=1.3e6), {"in": "n1", "out": "y"}, prefix="C")
    sol = top.ac(1, 1e6, 300)
    close(abs(sol.value_at("y", 1.0)), 10.0, 0.03, what="级联低频增益")
    close(sol.f3db("y"), 1e3, 0.10, what="级联 −3dB 频率（仍由前级低通决定）")
    # 两个实例的内部节点必须互不重叠
    refs = [c.ref for c in top.components]
    is_true(any(r.startswith("A.") for r in refs) and any(r.startswith("C.") for r in refs),
            f"两个实例的位号前缀应不同，实测 {refs}")


@case(group="组合与端口")
def test_unknown_port_reports_available():
    """未知端口必须报错并列出可用端口（组合时最常犯的错）。

    防的是：端口名拼错（"n1" vs "in"）时不报错，静默接到一个内部节点上。
    """
    top = Circuit("t")
    top.V("src", GND, ac=1)
    e = raises(CCLConfigError, top.use_ports, BLOCKS["rc_lowpass"](fc=1e3), {"nope": "src"},
               what="未知端口")
    is_true("nope" in str(e), f"报错应点名 nope，实测：{e}")
    is_true("in" in str(e) and "out" in str(e), f"报错应列出可用端口 in/out，实测：{e}")


@case(group="组合与端口")
def test_no_ports_subcircuit_rejected():
    """子电路没声明 ports 时，use_ports 必须报错并指出替代写法。

    防的是：用户按端口名接线，而块没声明端口 → 要么静默什么都不接，
    要么报一个跟"端口"无关的错。
    """
    bare = Circuit("bare")
    bare.R("a", GND, 1e3)
    top = Circuit("t")
    top.V("src", GND, ac=1)
    e = raises(CCLConfigError, top.use_ports, bare, {}, what="无 ports 的子电路")
    is_true("ports" in str(e), f"报错应说明缺少 ports 声明，实测：{e}")


@case(group="组合与端口")
def test_unconnected_ports_internalized():
    """端口没接时，内部节点必须被加前缀（不能直接暴露成顶层节点名）。

    防的是：两个块都没接 out 端口 → 两个内部 out 节点撞成同一个节点，
    短路而不报错。
    """
    top = Circuit("t")
    top.V("src", GND, ac=1)
    top.use_ports(BLOCKS["rc_lowpass"](fc=1e3), {"in": "src"}, prefix="A")   # 只接 in
    top.use_ports(BLOCKS["rc_lowpass"](fc=1e3), {"in": "src"}, prefix="B")   # 只接 in
    nodes = {n for c in top.components for n in c.nodes()}
    is_true("A.out" in nodes and "B.out" in nodes,
            f"未连接的端口节点应被前缀化，实测 {sorted(nodes)}")
    is_false(len(nodes & {"out"}), f"不该出现裸的顶层 out 节点，实测 {sorted(nodes)}")


@case(group="组合与端口")
def test_inlining_block_does_not_warn():
    """内联 block 不能触发 CCLWarning（块里没有独立源，就不该报"源并联"）。

    防的是：警告泛滥 —— 每个正常组合都刷一条警告，用户会开始无视它。
    """
    top = Circuit("t")
    top.V("src", GND, ac=1)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        for i, (name, kwargs) in enumerate(ARGS.items()):
            # 每个实例用不同前缀（前缀相同会产生重复位号，那是 use() 的正确行为）
            blk = BLOCKS[name](**kwargs)
            # 按**该块真实声明的端口**做映射：差分块是 inp/inn，没有 in。
            # 以前这里写死 {"in": "src"}，加了差分块就崩——块多样性是常态。
            mapping = {p: "src" for p in ("in", "inp") if p in blk.ports}
            top.use_ports(blk, mapping, prefix=f"U{i}")
    msgs = [str(w.message) for w in caught]
    is_false([m for m in msgs if "独立源" in m], f"内联无源块不该报独立源警告，实测 {msgs}")


# ==========================================================================
# 报告导出（M5）
# ==========================================================================
@case(group="报告导出")
def test_report_markdown():
    """报告 6 个章节齐全、含网表与规格核对结果。

    防的是：报告依赖某个字段而该字段没了（Web 下载的 markdown 变成半截），
    或者规格核对整段缺失（用户看不到"哪条没达标"）。
    """
    H.need_ngspice()
    c = Circuit("rc_rep")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-9)
    c.expect("fc", "out", 1e3, tol=0.05)
    sol = c.ac(1, 1e5, 100)
    md = RPT.markdown(c, sol, analysis_desc=".ac dec 100 1 1e5")
    secs = [ln for ln in md.splitlines() if ln.startswith("## ")]
    is_true(len(secs) == 6, f"报告应有 6 个章节，实测 {secs}")
    is_true("```spice" in md, "报告里应有 SPICE 网表代码块")
    is_true("全部通过" in md or "未达标" in md, "报告里应有规格核对结论")
    is_true("R1" in md and "C1" in md, "报告里应有器件清单")


if __name__ == "__main__":
    sys.exit(H.main("test_blocks", "test_blocks：子电路库与端口组合"))
