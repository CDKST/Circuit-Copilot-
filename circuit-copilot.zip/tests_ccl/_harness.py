"""CCL 正式测试套件的极简框架 —— 只用标准库，不引入 pytest。

## 为什么自己写（而不是 pip install pytest）

1. 项目硬约束：**只用标准库**（见 ccl/CONTRACT.md「环境」一节），ngspice 是唯一的
   外部依赖，测试框架必须跟着这个约束走。
2. 我们需要的东西很少：注册、跑、计时、区分 PASS/FAIL/SKIP，加一个别的框架
   默认没有的东西 —— **known_bug 标记**（见下）。

## known_bug 纪律（本套件最重要的一条规矩）

当一条测试断言的是「物理上应该对的东西」，而被测代码给出错的结果时，正确的做法
**不是**把断言放宽到刚好通过，而是：

    保留严格断言 + 打上 known_bug 标记

这样报告里能同时看到两件事：

  - 这条物理规律现在是错的（bug 存在，有精确复现用例）
  - 断言没有被偷偷改松（bug 修好那天，它会自动变成「🎉 已修复？」提示）

`python3 tests_ccl/run_all.py` 的退出码只看**意料之外的失败**：
known_bug 失败不算新问题（它已经被记录在案、已经报给 lead 了）。

本文件刻意和 tests/_harness.py 长得像（同一个项目、同一套规矩），但代码是重新
写的，不复用、不 import 它 —— `tests/` 属于参数化工具那条线，**不能被 CCL 套件牵动**。
"""

from __future__ import annotations

import math
import os
import time
import traceback
from dataclasses import dataclass, field
from typing import Callable

# --------------------------------------------------------------------------
# 控制流：Fail / Skip
# --------------------------------------------------------------------------
class Fail(AssertionError):
    """断言失败（≠ 代码崩溃）。runner 会把「崩溃」和「失败」分开显示。"""


class Skip(Exception):
    """跳过（环境不满足，例如没装 ngspice）。原因会写进汇总。"""


def skip(reason: str) -> None:
    """跳过当前用例。"""
    raise Skip(reason)


# --------------------------------------------------------------------------
# ngspice 可用性
# --------------------------------------------------------------------------
_NGSPICE_STATE: dict[str, object] = {}


def ngspice_version() -> str:
    """探测 ngspice 版本；失败返回 "not-installed"（不抛，让调用方决定 Skip）。"""
    if "v" not in _NGSPICE_STATE:
        try:
            from copilot import sim

            _NGSPICE_STATE["v"] = sim.version()
        except Exception as exc:  # noqa: BLE001
            _NGSPICE_STATE["v"] = f"error:{type(exc).__name__}"
    return str(_NGSPICE_STATE["v"])


def need_ngspice() -> None:
    """需要真跑仿真的用例开头调用一次：没装 ngspice 就 Skip 而不是红一片。"""
    v = ngspice_version()
    if v in ("not-installed", "") or v.startswith("error:"):
        skip(f"环境里没有可用的 ngspice（探测结果 {v!r}），跳过依赖仿真的核对")
    if v == "unknown":
        skip("ngspice 存在但取不到版本号，状态不可信，跳过依赖仿真的核对")


# --------------------------------------------------------------------------
# 断言工具
#
# 统一约定：**失败消息里必须同时有「期望值」和「实际值」**。
# 只写「断言失败」的报错，会让人回去翻代码才知道差多少 —— 那是浪费。
# --------------------------------------------------------------------------
def is_true(cond: object, msg: str = "") -> None:
    if not cond:
        raise Fail(msg or "断言失败：条件为假")


def is_false(cond: object, msg: str = "") -> None:
    if cond:
        raise Fail(msg or "断言失败：条件为真")


def is_finite(v: object, what: str = "值") -> float:
    """要求是有限实数。None / NaN / inf 都不行 —— 它们会让后面的比较静默出错。"""
    if v is None:
        raise Fail(f"{what} 是 None（期望一个实数）")
    try:
        f = float(v)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        raise Fail(f"{what} 不是数字：{v!r}（{type(v).__name__}）") from None
    if not math.isfinite(f):
        raise Fail(f"{what} 不是有限值：{f!r}")
    return f


def rel_err(actual: float, theory: float) -> float:
    """相对误差；理论值为 0 时退化为绝对误差。"""
    if theory == 0:
        return abs(actual - theory)
    return abs(actual - theory) / abs(theory)


def close(actual: float, theory: float, rel: float, what: str = "", note: str = "") -> float:
    """|实测−理论| / |理论| <= rel。返回实际相对误差（便于记表）。"""
    a = is_finite(actual, f"{what or '实测值'}")
    t = is_finite(theory, f"{what or '理论值'}")
    e = rel_err(a, t)
    if not (e <= rel):
        raise Fail(
            f"{what or '数值'} 超差：期望 {t:.6g} / 实测 {a:.6g} / "
            f"相对误差 {e * 100:+.3f}%（容差 ±{rel * 100:g}%）" + (f"（{note}）" if note else "")
        )
    return e


def close_abs(actual: float, theory: float, abs_tol: float, what: str = "") -> float:
    """绝对容差版本（dB 类、偏置点这类只能给绝对量的指标用）。"""
    a = is_finite(actual, what or "实测值")
    t = is_finite(theory, what or "理论值")
    d = abs(a - t)
    if not (d <= abs_tol):
        raise Fail(
            f"{what or '数值'} 超差：期望 {t:.6g} / 实测 {a:.6g} / "
            f"偏差 {d:.6g}（容差 ±{abs_tol:g}）"
        )
    return d


def in_range(v: float, lo: float, hi: float, what: str = "") -> float:
    """要求落在区间内 —— 「正向压降 0.5~0.8V」这类只能给物理区间的核对用。"""
    f = is_finite(v, what or "数值")
    if not (lo <= f <= hi):
        raise Fail(f"{what or '数值'} 越界：实测 {f:.6g}，期望落在 [{lo:.6g}, {hi:.6g}]")
    return f


def between_ratio(actual: float, base: float, lo: float, hi: float, what: str = "") -> float:
    """核对「实测 ≈ base 的 lo~hi 倍」。带宽这种只有量级判据的指标用。"""
    a = is_finite(actual, what or "实测值")
    b = is_finite(base, "基准值")
    if b == 0:
        raise Fail(f"{what or '比值'}：基准值为 0，无法算比值")
    k = a / b
    if not (lo <= k <= hi):
        raise Fail(
            f"{what or '比值'} 越界：实测 {a:.6g} / 基准 {b:.6g} = {k:.4f}×，"
            f"期望落在 [{lo:g}, {hi:g}]×"
        )
    return k


def raises(exc: type[BaseException], fn: Callable, *args, what: str = "", **kwargs):
    """要求 fn 抛出 exc 类型。

    两件事必须一起核对，否则「错误路径」测试是假的：
      1. 好电路**不报错**（由别的用例保证）
      2. 坏电路**报的是我们指定的那一类错**，而不是碰巧因为别的原因崩了
    """
    label = what or getattr(fn, "__name__", "调用")
    try:
        out = fn(*args, **kwargs)
    except exc as e:
        return e
    except BaseException as e:  # noqa: BLE001 —— 抛错类型不对同样是问题
        raise Fail(
            f"{label} 抛出了 {type(e).__name__} 而不是 {exc.__name__}：{e}"
        ) from None
    raise Fail(f"{label} 没有抛 {exc.__name__}，而是正常返回了 {type(out).__name__}：{out!r}")


# --------------------------------------------------------------------------
# 用例注册
# --------------------------------------------------------------------------
@dataclass
class Case:
    fn: Callable
    name: str
    module: str          # 所在文件名（不含 .py），run_all 用它分模块跑
    group: str = ""      # 汇总时的小标题
    known_bug: str = ""  # 非空 → 断言的是「正确行为」，当前代码已知不满足
    doc: str = ""        # 中文说明：这条用例在防什么

    @property
    def bug_id(self) -> str:
        return self.known_bug.split("|", 1)[0].strip() if "|" in self.known_bug else ""

    @property
    def bug_text(self) -> str:
        return self.known_bug.split("|", 1)[1].strip() if "|" in self.known_bug else self.known_bug


CASES: list[Case] = []


def case(fn: Callable | None = None, *, group: str = "", known_bug: str = ""):
    """@case 注册一条用例。

    模块名取 `fn.__code__.co_filename` 而不是 `fn.__module__`：被 import 时模块名
    是 "test_core"，但 `python3 tests_ccl/test_core.py` 直接跑时是 "__main__"，
    只有文件名永远可靠。
    """

    def deco(f: Callable) -> Callable:
        mod = os.path.splitext(os.path.basename(f.__code__.co_filename))[0]
        name = f.__name__
        # 同一个模块被 import 两次（reload）时不要注册两遍
        for c in CASES:
            if c.module == mod and c.name == name:
                return f
        CASES.append(
            Case(fn=f, name=name, module=mod, group=group, known_bug=known_bug,
                 doc=(f.__doc__ or "").strip().splitlines()[0] if (f.__doc__ or "").strip() else "")
        )
        return f

    return deco(fn) if fn is not None else deco


# --------------------------------------------------------------------------
# 执行与汇总
# --------------------------------------------------------------------------
@dataclass
class Result:
    case: Case
    status: str            # pass / fail / skip
    seconds: float = 0.0
    message: str = ""
    crashed: bool = False

    @property
    def is_known_bug_fail(self) -> bool:
        return self.status == "fail" and bool(self.case.known_bug)

    @property
    def is_unexpected_pass(self) -> bool:
        """打了 known_bug 标记却通过了 —— bug 修好了，该摘标记了。"""
        return self.status == "pass" and bool(self.case.known_bug)


@dataclass
class Summary:
    results: list[Result] = field(default_factory=list)
    seconds: float = 0.0

    def _n(self, pred) -> int:
        return sum(1 for r in self.results if pred(r))

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return self._n(lambda r: r.status == "pass" and not r.is_unexpected_pass)

    @property
    def failed(self) -> int:
        return self._n(lambda r: r.status == "fail")

    @property
    def known_bug_fails(self) -> int:
        return self._n(lambda r: r.is_known_bug_fail)

    @property
    def new_fails(self) -> int:
        """意料之外的失败 = 真正的代码问题。"""
        return self._n(lambda r: r.status == "fail" and not r.case.known_bug)

    @property
    def skipped(self) -> int:
        return self._n(lambda r: r.status == "skip")

    @property
    def unexpectedly_passed(self) -> int:
        return self._n(lambda r: r.is_unexpected_pass)

    @property
    def ok(self) -> bool:
        return self.new_fails == 0 and self.unexpectedly_passed == 0

    def extend(self, other: "Summary") -> None:
        """把另一个模块的结果并进来（run_all 用）。"""
        self.results.extend(other.results)
        self.seconds += other.seconds


def run(module: str | None = None, *, verbose: bool = True) -> Summary:
    """跑（某个模块的）全部用例。"""
    sel = [c for c in CASES if module is None or c.module == module]
    out = Summary()
    t0 = time.perf_counter()
    cur_group = None
    for c in sel:
        if verbose and c.group and c.group != cur_group:
            cur_group = c.group
            print(f"\n  ── {cur_group} " + "─" * max(4, 52 - len(cur_group)))
        t = time.perf_counter()
        try:
            c.fn()
            r = Result(c, "pass")
        except Skip as e:
            r = Result(c, "skip", message=str(e))
        except Fail as e:
            r = Result(c, "fail", message=str(e))
        except Exception:  # noqa: BLE001 —— 崩溃也是失败，但要把 traceback 摊开
            tb = traceback.format_exc(limit=4)
            r = Result(c, "fail", message=tb.strip().splitlines()[-1], crashed=True)
            if verbose:
                print(tb)
        r.seconds = time.perf_counter() - t
        out.results.append(r)
        if verbose:
            print(_fmt_line(r))
    out.seconds = time.perf_counter() - t0
    return out


_ICON = {"pass": "✅", "skip": "⏭️ ", "fail": "❌"}


def _fmt_line(r: Result) -> str:
    icon = _ICON[r.status]
    tail = ""
    if r.is_known_bug_fail:
        icon = "🐞"                       # 预期内的失败：已记录的代码缺陷
    if r.is_unexpected_pass:
        icon = "🎉"                       # 已知 bug 居然过了
    if r.status == "skip":
        tail = f"  ← {r.message}"
    elif r.status == "fail":
        tail = f"  ← {'崩溃: ' if r.crashed else ''}{r.message}"
        if r.case.known_bug:
            tail += f"\n      [{r.case.bug_id or '已知缺陷'}] {r.case.bug_text}"
    elif r.is_unexpected_pass:
        tail = f"\n      [{r.case.bug_id or '已知缺陷'} 已修复？] {r.case.bug_text}"
    return f"  {icon} {r.case.name:46s} {r.seconds * 1000:6.0f}ms{tail}"


def report(s: Summary, title: str = "测试汇总") -> str:
    """汇总表。把「新问题」和「已知缺陷」分开放，不混成一个失败数。"""
    lines = [f"\n{'=' * 74}", f"  {title}", "=" * 74]
    lines.append(
        f"  共 {s.total} 项：通过 {s.passed} · 失败 {s.new_fails} · "
        f"跳过 {s.skipped} · 已知缺陷 {s.known_bug_fails} · 耗时 {s.seconds:.1f}s"
    )
    if s.unexpectedly_passed:
        lines.append(f"  ⚠️ {s.unexpectedly_passed} 个已知缺陷用例现在通过了 —— 可以摘掉 known_bug 标记。")

    bad = [r for r in s.results if r.status == "fail" and not r.case.known_bug]
    if bad:
        lines.append("\n  ❌ 失败详情（这些是代码问题，不是测试问题）：")
        for r in bad:
            lines.append(f"    - [{r.case.module}] {r.case.name}: {r.message}")

    bugs: dict[str, tuple[str, list[str]]] = {}
    for r in s.results:
        if r.is_known_bug_fail:
            key = r.case.bug_id or r.case.bug_text
            bugs.setdefault(key, (r.case.bug_text, []))[1].append(r.case.name)
    if bugs:
        lines.append(f"\n  🐞 已知缺陷 {len(bugs)} 个（断言保持严格，代码当前不满足）：")
        for key, (text, names) in bugs.items():
            lines.append(f"    [{key or '?'}] {text}")
            lines.append(f"        复现用例：{', '.join(names)}")

    skips = [r for r in s.results if r.status == "skip"]
    if skips:
        lines.append("\n  ⏭️  跳过：")
        for r in skips:
            lines.append(f"    - [{r.case.module}] {r.case.name}: {r.message}")

    lines.append("=" * 74)
    return "\n".join(lines)


def main(module: str | None = None, title: str | None = None) -> int:
    """给 `python3 tests_ccl/test_xxx.py` 单独跑用。"""
    s = run(module, verbose=True)
    print(report(s, title or f"{module or '全部'} 汇总"))
    return 0 if s.ok else 1
