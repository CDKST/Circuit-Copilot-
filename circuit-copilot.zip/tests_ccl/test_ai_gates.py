"""AI 生成链的对账闸门 —— 第三轮审计（`ccl/ai/`）挖出来的坑，逐条钉住。

## 这一层防的是什么

「**AI 说成功、其实不成立**」。这条链的招牌是「AI 只说话，数字全靠算」，
所以最致命的失效不是崩溃，而是：算完了、没对账、或者对账失败被当成没事，
最后照样回一句「已生成」。

审计实测到的原状（每条都对应下面一个用例）：
- `at.warnings` 写到 `Attempt` 上（没有这个字段）→ AttributeError 被同一个 except 吞掉，
  顺手把 `_misses` 清成 `[]` —— 「抽不到指标要告警」那道总闸是**死代码**
- `check_targets` 用同一个 `[]` 表示「没抽到 / 全达标 / **测不到**」
- `generate()` 从不跑 lint → 1nΩ 电阻、10 万法电容全部交付成功
- 沙箱把真模块对象传进 exec，模型一行 `Circuit.ac = lambda...` 就能**永久**污染进程
- `review.check_rails` 用了未导入的 `GND` → NameError → 「撞电源轨」检查从未执行过
"""
from __future__ import annotations

import importlib

import _harness as H
from _harness import case, is_true

GEN = importlib.import_module("ccl.ai.generate")
SC = importlib.import_module("ccl.ai.spec_check")
SB = importlib.import_module("ccl.ai.sandbox")
RV = importlib.import_module("ccl.ai.review")

from ccl import GND, Circuit


class _Stub:
    """固定返回一段代码的桩模型（真模型每次 20~40s，回归里不能用）。"""
    model = "stub"

    def __init__(self, code: str) -> None:
        self._code = code

    def available(self) -> bool:          # noqa: D401
        return True

    def chat(self, *a, **k) -> str:       # noqa: D401
        return "```python\n" + self._code + "```"


_RC_1K = """from ccl import Circuit, GND

def build():
    c = Circuit("rc")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-9)
    return c
"""


@case(group="AI 对账")
def test_unparsed_metric_produces_warning():
    """★回归：需求里有抽不到的量化指标时，必须**真的**吐一条 warning。

    原状：`gen.warnings.append` 被写成 `at.warnings.append`，AttributeError 被
    同一个 `except Exception` 吞掉 → `ok=True`、`warnings=[]`，用户什么都看不到。
    """
    g = GEN.generate("做一个低通滤波器，相位裕度 45°", max_repair=1, _llm=_Stub(_RC_1K))
    is_true(any("相位裕度" in w for w in g.warnings),
            f"应提示「相位裕度」无法对账，实际 warnings={g.warnings}")


@case(group="AI 对账")
def test_checker_crash_is_not_success():
    """★回归：对账器自己崩了，绝不能等于「全部达标」。"""
    orig = SC.check_targets_strict
    SC.check_targets_strict = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("核对器坏了"))
    try:
        g = GEN.generate("低通滤波器，截止频率 10kHz", max_repair=0, _llm=_Stub(_RC_1K))
    finally:
        SC.check_targets_strict = orig
    is_true(g.ok is False, "对账器异常时 ok 必须为 False")
    is_true(any("对账" in w for w in g.warnings), f"应有对账异常的告警，实际 {g.warnings}")


@case(group="AI 对账")
def test_measurable_target_miss_fails():
    """抽得到、但实测差 90% → 必须判失败，且错误里带实测数字。"""
    g = GEN.generate("低通滤波器，截止频率 10kHz", max_repair=0, _llm=_Stub(_RC_1K))
    is_true(g.ok is False, f"要求 10kHz、实测约 1kHz，应判失败（ok={g.ok}）")
    is_true("994" in str(g.error), f"错误信息应带实测值，实际 {g.error}")


@case(group="AI 对账")
def test_unmeasurable_is_exception_not_empty():
    """★回归：`check_targets_strict` 对「测不到」必须抛 Unmeasurable，不能返回 []。"""
    ts = SC.parse_targets("截止频率 1kHz")
    is_true(bool(ts), "应解析出目标")
    raised = False
    try:
        SC.check_targets_strict(ts, None)
    except SC.Unmeasurable:
        raised = True
    is_true(raised, "solution=None 时必须抛 Unmeasurable（不能返回 [] 冒充全达标）")


@case(group="AI 对账")
def test_absurd_component_values_rejected():
    """★回归：`generate()` 必须跑 lint —— 1nΩ 电阻 / 10 万法电容不能交付成功。"""
    bad = """from ccl import Circuit, GND

def build():
    c = Circuit("bad")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e-9)
    c.C("out", GND, 1e5)
    return c
"""
    g = GEN.generate("做一个 1kHz 低通", max_repair=0, _llm=_Stub(bad))
    is_true(g.ok is False, f"参数越界必须判失败（ok={g.ok}，error={g.error}）")
    is_true("越界" in str(g.error) or "范围" in str(g.error),
            f"错误应说明参数越界，实际 {g.error}")


@case(group="AI 对账")
def test_sandbox_blocks_attribute_assignment():
    """★回归：沙箱必须禁止 `对象.属性 = ...`。

    原状：模型一行 `Circuit.ac = lambda ...` 就永久改掉进程里的全局类，
    此后**所有**请求的 ac() 返回 None → 对账拿 None 当达标 → 永远报成功。
    """
    bad = """from ccl import Circuit, GND

def build():
    Circuit.ac = lambda self, *a, **k: None
    return Circuit("x")
"""
    r = SB.run_source(bad, require_circuit=True)
    is_true(r.ok is False, "属性赋值必须被静态检查拦下")
    is_true("属性赋值" in str(r.error), f"错误应说明禁止属性赋值，实际 {r.error}")


@case(group="AI 对账")
def test_runtime_guard_restores_polluted_class():
    """★回归：万一有路径绕过 AST，运行时护栏必须发现并**回滚**。

    两道防线是有意的：AST 挡常见路径，护栏兜底 —— 一次污染 = 整个进程此后永远成功。
    """
    orig = Circuit.ac
    snap = SB._snapshot_guarded()
    try:
        Circuit.ac = lambda self, *a, **k: None      # 模拟被污染
        bad = SB._restore_if_polluted(snap)
        is_true(any("Circuit.ac" in b for b in bad), f"护栏应发现污染，实际 {bad}")
        is_true(Circuit.ac is orig, "护栏必须把原方法恢复回去")
    finally:
        Circuit.ac = orig


@case(group="AI 对账")
def test_check_rails_runs_and_has_no_false_positive():
    """★回归：`check_rails` 曾用未导入的 `GND` → 一传 op 解就 NameError，
    「输出撞电源轨」这条检查**从未执行过**；修好后又因漏把地当下轨而误报分压器。
    """
    # ① 正常分压器（12V 轨、输出 6V）不应被判撞轨
    c = Circuit("div")
    c.V("v", GND, dc=12)
    c.R("v", "a", 1e3)
    c.R("a", GND, 1e3)
    is_true(RV.check_rails(c, c.op()) == [], "12V 轨上的 6V 分压不应报撞轨")

    # ② 线性模型把运放输出推到 99.9V（电源只有 12V）→ 必须报
    c2 = Circuit("rail")
    c2.V("vcc", GND, dc=12)
    c2.R("vcc", GND, 1e6)                       # 运放宏模型没有电源脚，给 vcc 一条通路
    c2.V("sig", GND, dc=1)
    c2.OpAmp("sig", "fb", "out")
    c2.R("out", "fb", 99e3)
    c2.R("fb", GND, 1e3)
    sol = c2.op()
    is_true(sol.value_at("out", 0.0) > 50.0, "构造场景应把输出推到轨外")
    iss = RV.check_rails(c2, sol)
    is_true(bool(iss), "输出 99.9V 而电源只有 12V，必须报撞轨")


@case(group="AI 对账")
def test_vin_not_guessed_from_product_name():
    """★回归：`vin` 不能用「前面所有电压取最大」猜。

    原状：「设计一个 3.3V 电源电路，输出 3.3V」→ 产品名里的 3.3V 被当成输入电压
    → 一个正确的 12V→3.3V 分压被算成「实测 0.9075、偏差 72.5%」判失败；
    换个说法「把 12V 分压到 3.3V」就 ok=True。**同一答案，成败取决于电压写在第几个位置。**
    现在：没有明确输入电压时**不猜**，直接报「没法对账」。
    """
    c = Circuit("d")
    c.V("in", GND, ac=1)
    c.R("in", "out", 26.4e3)
    c.R("out", GND, 10e3)
    sol = c.ac(1, 1e4, 50)

    # ① 写明了输入电压 → 应该能核对（12V 分压到 3.3V 是达标的）
    ts = SC.parse_targets("把 12V 分压到 3.3V")
    is_true(ts and ts[0].vin == 12.0, f"应认出 vin=12，实际 {[t.vin for t in ts]}")
    is_true(SC.check_targets_strict(ts, sol, circuit=c) == [], "12V→3.3V 应达标")

    # ② 只写输出值 → 必须抛 Unmeasurable（不许拿 1.0 冒充输入电压）
    ts2 = SC.parse_targets("设计一个 3.3V 电源电路，输出 3.3V")
    is_true(ts2 and ts2[0].vin is None, f"产品名里的 3.3V 不该被当成输入，实际 {[t.vin for t in ts2]}")
    raised = False
    try:
        SC.check_targets_strict(ts2, sol, circuit=c)
    except SC.Unmeasurable:
        raised = True
    is_true(raised, "缺输入电压时必须报「没法对账」，不能编一个偏差出来")


@case(group="AI 对账")
def test_unparsed_metrics_is_per_word():
    """★回归：`unparsed_metrics` 必须**逐词**判断，不能被同窗口里其它能解析的数掩盖。

    原状：「LDO 输出 3.3V，纹波<10mV，效率85%」里 vout 解析成功就把「纹波」整条吞掉；
    「在 10 倍截止频率处衰减 40dB」的「衰减」一个字都不报。
    """
    outs = SC.unparsed_metrics("LDO 输出 3.3V，纹波<10mV，效率85%")
    is_true("纹波" in outs, f"「纹波」必须被报出来，实际 {outs}")
    is_true("效率" in outs, f"「效率」必须被报出来，实际 {outs}")

    outs2 = SC.unparsed_metrics("fc=10kHz，在 10 倍截止频率处衰减 40dB")
    is_true("衰减" in outs2, f"「衰减」必须被报出来，实际 {outs2}")

    # 已经被正确解析的指标不该误报
    is_true(SC.unparsed_metrics("截止频率 1kHz 的低通滤波器") == [],
            "截止频率能解析，不该误报")


@case(group="AI 对账")
def test_frequency_ratio_not_mistaken_for_gain():
    """★回归：「10 倍截止频率」是频率倍数，不是增益 10 倍。

    原状它被抽成 `gain_lin=10` 的假目标 → 逼模型把无源低通改成 10 倍增益，
    而真正的「衰减 40dB」没人管。
    """
    ts = SC.parse_targets("fc=10kHz，在 10 倍截止频率处衰减 40dB")
    keys = [(t.key, t.value) for t in ts]
    is_true(not any(k == "gain_lin" for k, _ in keys),
            f"不该凭空生成 gain_lin 目标，实际 {keys}")
    is_true(any(k == "fc" and abs(v - 10000) < 1 for k, v in keys),
            f"应认出 fc=10kHz，实际 {keys}")


@case(group="AI 对账")
def test_fix_checks_requirements():
    """★回归：`fix(code, request=...)` 必须**真的**核需求。

    原状：`_diagnose` 只跑 lint + c.expect，一次需求对账都没有 →
    `fix(code, request="截止频率必须改成10kHz")` 返回 ok=True、**模型调用 0 次**、
    UI 说「没发现问题」，代码一字未动、实测仍 995Hz。
    """
    calls = {"n": 0}

    class _Stub2(_Stub):
        def __init__(self) -> None:
            super().__init__(_RC_1K)

        def chat(self, *a, **k):
            calls["n"] += 1
            return "```python\n" + _RC_1K + "```"

    r = GEN.fix(_RC_1K, request="截止频率必须改成 10kHz", max_repair=1, _llm=_Stub2())
    is_true(calls["n"] >= 1, "需求没满足时必须调用模型去修（原状是 0 次）")
    is_true(r.ok is False, "桩模型改不动，应如实返回失败")
    is_true("截止频率" in str(r.error),
            f"失败原因应指出是哪条需求没满足，实际 {r.error}")


@case(group="AI 对账")
def test_model_saying_impossible_is_not_success():
    """★回归：模型自己在注释里写「物理上不可能」时，不能返回成功。

    原状（真模型实测）：需求「RC 低通截止 1kHz，且在 1kHz 处衰减 60dB」本身自相矛盾，
    模型很诚实地在源码顶部写了「# …互相矛盾…物理上不可能」，产品却返回
    `{ok: true, warnings: []}`，面板只显示「已生成」。**模型说不可能、工具说成功。**
    """
    src = (
        "# 限制：要求 fc=1kHz，而一阶 RC 在 f=fc 处恒为 -3dB，\n"
        "# 两者物理上互相矛盾，物理上不可能同时满足。\n"
        "from ccl import Circuit, GND\n\n"
        "def build():\n"
        "    c = Circuit('rc')\n"
        "    c.V('in', GND, ac=1)\n"
        "    c.R('in', 'out', 1.6e3)\n"
        "    c.C('out', GND, 100e-9)\n"
        "    return c\n"
    )
    g = GEN.generate("RC 低通截止 1kHz，且在 1kHz 处衰减 60dB",
                     max_repair=0, _llm=_Stub(src))
    is_true(g.ok is False, f"模型说做不到时必须不交付，实际 ok={g.ok}")
    is_true("无法满足" in str(g.error) or "做不到" in str(g.error),
            f"错误应说明是需求无法满足，实际 {g.error}")
