"""数据模型层：Circuit / Component / Pin / validate / ports / use / with_ / sweep。

这一层是**契约层**（CONTRACT「core.py 已固定接口」），所有别的模块都假设它成立。
所以这里的用例防的都是「改一处悄悄破坏全局约定」这类事故：

  - 引脚顺序 = SPICE 端子顺序（错了仿真照样跑通，只是结果全错）
  - 地节点固定 "0"（换个名字整套网表就错了）
  - 悬空/无地必须报错并点名（不能静默产出一份跑不出结果的电路）
  - 已声明端口不算悬空（blocks 全靠这条，否则每个子电路都刷一堆假错误）
  - use()/with_()/sweep() 不能改动原电路（否则回归测试本身不可信）
"""

import os
import sys
import warnings

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import _harness as H  # noqa: E402
from _harness import case, close, is_false, is_true, raises  # noqa: E402

from ccl.core import GND, Circuit, Component, Pin, normalize_node  # noqa: E402
from ccl.errors import (  # noqa: E402
    CCLConfigError,
    CCLNetlistError,
    CCLWarning,
    NodeError,
    RefError,
)


# ==========================================================================
# 节点名与引脚
# ==========================================================================
@case(group="节点与引脚")
def test_ground_is_zero():
    """地节点必须永远是 "0"：GND/"GND"/"ground"/int 0 都归一化成同一个名字。

    防的是：有人给地取个别名（"gnd"），于是网表里出现两个浮空参考点，
    仿真或 singular matrix 或算出一组毫无意义的电压。
    """
    is_true(GND == "0", f'GND 常量必须是 "0"，实测 {GND!r}')
    for src in ("0", "GND", "gnd", "Ground", " 0 ", 0):
        got = normalize_node(src)
        is_true(got == "0", f'normalize_node({src!r}) 期望 "0"，实测 {got!r}')


@case(group="节点与引脚")
def test_bad_node_names_rejected():
    """非法节点名必须报错，不能进网表。

    防的是：节点名里带空格/括号/逗号，把网表的「位号 节点 节点 值」分列结构
    拆错，ngspice 于是把值当成节点 —— 报错信息离真正的错处几十行远。
    """
    for bad in ("", "   ", "a b", "n(1)", "x,y", "n=1", "n'1"):
        raises(NodeError, normalize_node, bad, what=f"normalize_node({bad!r})")
    # 非 0 的整数节点：用户可能想写节点号 1，但那不是 SPICE 的节点语义
    raises(NodeError, normalize_node, 1, what="normalize_node(1)")
    raises(NodeError, normalize_node, 1.5, what="normalize_node(1.5)")
    # 合法名字不能被误杀（子电路前缀、括号表达式都用得上）
    for good in ("out", "n1", "U1.R1", "v_out", "n[1]", "a+", "-5"):
        is_true(normalize_node(good) == good, f"合法节点名 {good!r} 被改写成 {normalize_node(good)!r}")


@case(group="节点与引脚")
def test_pin_order_is_spice_order():
    """引脚顺序就是网表端子顺序 —— 这条错了仿真照跑，只是结果全错。

    这里直接用 Component 的原始引脚断言，不经过 devices 层：
    即使 devices 重写，core 这个约定也必须独立成立。
    """
    c = Circuit("t")
    comp = c.add(Component(kind="Q", ref="",
                           pins=[Pin("c", "cc"), Pin("b", "bb"), Pin("e", "ee")]))
    is_true(comp.ref == "Q1", f"自动位号应为 Q1，实测 {comp.ref!r}")
    is_true(comp.nodes() == ["cc", "bb", "ee"],
            f"引脚顺序必须保持声明顺序，实测 {comp.nodes()}")
    is_true(comp.node("b") == "bb", f'node("b") 应为 bb，实测 {comp.node("b")!r}')
    # 取一个不存在的引脚：必须报错并列出可用引脚（而不是 KeyError 或静默返回）
    e = raises(CCLConfigError, comp.pin, "d", what='pin("d")')
    is_true("c" in str(e) and "b" in str(e),
            f"报错应列出可用引脚 c/b/e，实测：{e}")


@case(group="节点与引脚")
def test_nets_and_nodes():
    """nets()/nodes() 是 lint 与 check_dc_path 的唯一数据源，顺序与内容都要稳。

    防的是：靠 nets() 做「悬空判断」的代码因为顺序变化而漏判。
    """
    c = Circuit("t")
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)
    c.V("in", GND, ac=1)
    net = c.nets()
    is_true(list(net) == ["in", "out", "0"], f"节点首次出现顺序应为 in/out/0，实测 {list(net)}")
    # R 的引脚是 a→b，所以 out 上是 R1 的 b 端、C1 的 a 端（顺序即声明顺序）
    is_true(net["out"] == [("R1", "b"), ("C1", "a")],
            f"out 上的引脚应为 R1.b / C1.b，实测 {net['out']}")
    is_true(c.nodes() == ["in", "out", "0"], f"nodes() 应与 nets() 的键一致，实测 {c.nodes()}")


# ==========================================================================
# 位号
# ==========================================================================
@case(group="位号")
def test_auto_ref_and_dup():
    """自动位号要按类型递增，且重复位号必须当场报错。

    防的是：两个器件共用一个位号 → 网表里两行同位号 → ngspice 只认其中一行，
    另一台器件**静默消失**，算出来的电路跟你写的不一样。
    """
    c = Circuit("t")
    refs = [c.R("in", "a", 1e3).ref, c.R("a", GND, 1e3).ref,
            c.C("a", GND, 1e-9).ref]
    is_true(refs == ["R1", "R2", "C1"], f"自动位号应为 R1/R2/C1，实测 {refs}")
    # 手工位号占位后，自动分配的计数器要跟着抬高（R9 之后从 R10 继续）
    c.R("in", GND, 1e3, ref="R9")
    is_true(c.R("in", GND, 1e3).ref == "R10",
            f"有 R9 之后自动位号应为 R10，实测 {c.components[-1].ref}")
    e = raises(RefError, c.R, "in", GND, 1e3, ref="R1", what="重复位号 R1")
    is_true("R1" in str(e), f"重复位号报错必须点名 R1，实测：{e}")
    is_true(c.find("R10") is not None and c.find("nope") is None,
            "find() 按位号能命中，找不到时必须返回 None 而不是抛异常")


# ==========================================================================
# validate
# ==========================================================================
@case(group="validate")
def test_floating_node_rejected():
    """悬空节点（只连一个引脚）必须报错点名 + 指出器件。

    防的是：节点名打错一个字（out → ot），电路少接一根线却照常跑出个"结果"。
    """
    c = Circuit("dangling")
    c.V("in", GND, dc=1)
    c.R("in", "a", 1e3)
    c.C("a", "nowhere", 1e-9)      # nowhere 只出现一次
    e = raises(NodeError, c.validate, what="validate() 悬空节点")
    is_true("nowhere" in str(e), f"报错必须点名悬空节点 nowhere，实测：{e}")
    is_true("C1" in str(e), f"报错必须指出是 C1 造成的，实测：{e}")


@case(group="validate")
def test_allow_floating_escape_hatch():
    """validate(allow_floating=True) 必须真的放行 —— 测试点/探针是合理需求。

    防的是：为了严格而把留测试点的合法电路也打死，逼用户删掉探针。
    """
    c = Circuit("probe")
    c.V("in", GND, dc=1)
    c.R("in", GND, 1e3)
    c.add(Component(kind="R", ref="R99", pins=[Pin("a", "in"), Pin("b", "probe_tp")]))
    raises(NodeError, c.validate, what="默认 validate()")
    warns = c.validate(allow_floating=True)
    is_true(isinstance(warns, list), f"allow_floating=True 应返回警告列表，实测 {type(warns).__name__}")


@case(group="validate")
def test_no_ground_rejected():
    """完全没有地必须报错。

    防的是：SPICE 没有参考地 → 矩阵奇异 → 报一句「no convergence」，
    用户根本猜不到是漏接了一根地线。
    """
    c = Circuit("no_gnd")
    c.R("a", "b", 1e3)
    c.R("b", "c", 1e3)
    c.R("c", "a", 1e3)             # 每个节点都有 2 个引脚，但整体不接地
    e = raises(NodeError, c.validate, what="validate() 无地")
    is_true("地" in str(e) or "GND" in str(e), f"报错应说明缺地，实测：{e}")


@case(group="validate")
def test_empty_circuit_rejected():
    """空电路必须报错，而不是产出一份只有标题和 .end 的"网表"。

    防的是：ngspice 对空网表会回一条叫 all 的伪向量，上层把它当真实波形。
    """
    e = raises(CCLNetlistError, Circuit("empty").validate, what="validate() 空电路")
    is_true("没有任何器件" in str(e), f"报错应说明没有任何器件，实测：{e}")


@case(group="validate")
def test_ref_kind_mismatch_is_warning():
    """位号首字母与器件类型不符 → 只是警告，不拦。

    防两件事：① 把「R1 其实是电容」这种笔误彻底打死（有时是有意的）；
    ② 反过来，把警告实现成异常，让正常电路建不出来。
    """
    c = Circuit("mismatch")
    c.V("in", GND, ac=1)
    c.add(Component(kind="C", ref="R7", pins=[Pin("a", "in"), Pin("b", GND)], value=1e-9))
    warns = c.validate()
    is_true(any("R7" in w for w in warns), f"应有一条警告提到 R7，实测 {warns}")


@case(group="validate")
def test_declared_ports_are_not_floating():
    """已声明的端口节点不算悬空 —— blocks 的正确性完全建立在这条上。

    防的是：每个子电路单独检查时都刷一堆「in 悬空 / out 悬空」假错误，
    假错误比漏报更伤信任（用户会开始无视所有报错）。
    """
    c = Circuit("block")
    c.R("in", "out", 1e3)
    c.C("out", GND, 1e-9)
    e = raises(NodeError, c.validate, what="未声明端口时")
    is_true("in" in str(e), f"未声明端口时应报 in 悬空，实测：{e}")
    c.ports = {"in": "in", "out": "out"}
    warns = c.validate()           # 声明端口后不该再抛
    is_true(not any("悬空" in w for w in warns), f"声明端口后不应再报悬空，实测 {warns}")
    is_true(c.port("in") == "in", f'port("in") 应为 "in"，实测 {c.port("in")!r}')
    e2 = raises(CCLConfigError, c.port, "nope", what='port("nope")')
    is_true("in" in str(e2) and "out" in str(e2), f"未知端口应列出可用端口，实测：{e2}")


# ==========================================================================
# use / use_ports（内联展平）
# ==========================================================================
@case(group="use 内联")
def test_use_inline_prefix():
    """内联后位号加前缀、内部节点加前缀、地节点不加前缀，maps 生效。

    防的是：内联把两个子电路的内部节点撞在一起（比如都叫 n1），
    短路成一个节点，仿真跑通但电路完全不是写的样子。
    """
    sub = Circuit("half")
    sub.R("a", "m", 1e3)
    sub.R("m", GND, 1e3)

    top = Circuit("top")
    top.V("src", GND, dc=1)
    top.use(sub, maps={"a": "src"})
    refs = [c.ref for c in top.components]
    is_true("U1.R1" in refs and "U1.R2" in refs, f"内联位号应带 U1. 前缀，实测 {refs}")
    nodes = set()
    for c in top.components:
        nodes |= set(c.nodes())
    is_true("U1.m" in nodes, f"未映射的内部节点应变成 U1.m，实测 {sorted(nodes)}")
    is_true("src" in nodes, f"maps 应把子电路的 a 接到 src，实测 {sorted(nodes)}")
    is_true(GND in nodes, "地节点内联后必须仍是 \"0\"（不能变成 U1.0）")
    is_false(any(n.startswith("U1.0") for n in nodes), f"地节点被错误加了前缀：{sorted(nodes)}")

    # 再内联一次 → 前缀自动递增，两个实例互不干扰
    top.use(sub, maps={"a": "src"})
    is_true(any(r.startswith("U2.") for r in [c.ref for c in top.components]),
            "第二次内联应自动用 U2 前缀")


@case(group="use 内联")
def test_use_self_rejected():
    """电路不能内联到自己里面 —— 会无限递归，最后是 RecursionError 而不是人话。"""
    c = Circuit("self")
    c.R("in", GND, 1e3)
    raises(CCLConfigError, c.use, c, what="use(self)")


@case(group="use 内联")
def test_use_source_warning():
    """子电路里含独立源要警告。

    防的是：内联后两个理想电压源接在同一对节点上 → singular matrix，
    而报错出现在离 use() 几十行远的仿真阶段，用户压根想不到是复用造成的。
    """
    sub = Circuit("with_src")
    sub.V("a", GND, dc=1)
    sub.R("a", GND, 1e3)

    top = Circuit("top")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        top.use(sub, maps={"a": "src"})
    kinds = [w.category for w in caught]
    is_true(any(issubclass(k, CCLWarning) for k in kinds),
            f"内联含独立源的子电路应发出 CCLWarning，实测 {[k.__name__ for k in kinds]}")


@case(group="use 内联")
def test_use_ports():
    """按端口名连接；未知端口/无端口必须报错并说明怎么改。

    防的是：用户按端口名接线时拼错端口，结果静默接到内部节点上（不报错但接错了）。
    """
    sub = Circuit("div")
    sub.R("in", "out", 1e3)
    sub.R("out", GND, 1e3)
    sub.ports = {"in": "in", "out": "out"}

    top = Circuit("top")
    top.V("src", GND, dc=1)
    top.use_ports(sub, {"in": "src", "out": "y"}, prefix="D")
    nodes = {n for c in top.components for n in c.nodes()}
    is_true({"src", "y", "0"} <= nodes, f"端口连接后应有 src/y/0，实测 {sorted(nodes)}")

    e = raises(CCLConfigError, top.use_ports, sub, {"nope": "x"}, what="未知端口")
    is_true("nope" in str(e) and "in" in str(e),
            f"未知端口的报错应点名 nope 并列出可用端口，实测：{e}")

    no_ports = Circuit("bare")
    no_ports.R("a", GND, 1e3)
    e2 = raises(CCLConfigError, top.use_ports, no_ports, {}, what="子电路无 ports")
    is_true("ports" in str(e2), f"应提示子电路没有声明 ports，实测：{e2}")


# ==========================================================================
# with_ / sweep（变体与参数扫描）
# ==========================================================================
@case(group="变体与扫描")
def test_with_returns_copy():
    """with_() 返回副本，原电路的值必须一点不变。

    防的是：参数扫描把原电路改了，于是后续所有断言都基于被污染的值 ——
    测试自己骗自己，是最难发现的一类错误。
    """
    c = Circuit("rc")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)

    v = c.with_(R1=2e3)
    is_true(v is not c, "with_() 必须返回新对象")
    close(c.find("R1").value, 1e3, 1e-12, what="原电路 R1")
    close(v.find("R1").value, 2e3, 1e-12, what="副本 R1")
    is_true(len(v.components) == 3, f"副本应保留全部 3 个器件，实测 {len(v.components)}")
    is_true(v.find("R1") is not c.find("R1"), "副本里的器件对象也必须是新的")

    e = raises(RefError, c.with_, R9=1e3, what="with_(R9=…)")
    is_true("R9" in str(e), f"未知位号应点名 R9，实测：{e}")
    raises(CCLConfigError, c.with_, R1="abc", what="with_(R1='abc')")
    raises(CCLConfigError, c.with_, R1=-1, what="with_(R1=-1)")


@case(group="变体与扫描")
def test_sweep_generator():
    """sweep() 是生成器：值+副本成对产出，支持叠加固定参数，且不改原电路。

    防的是：扫描时把 fixed 参数丢掉（静默只扫一个变量），或者原地改电路。
    """
    c = Circuit("rc")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)

    rows = list(c.sweep("R1", [1e3, 2e3, 4e3]))
    is_true(len(rows) == 3, f"应产出 3 份，实测 {len(rows)}")
    is_true([r[0] for r in rows] == [1e3, 2e3, 4e3], f"产出顺序应与输入一致，实测 {[r[0] for r in rows]}")
    for val, ckt in rows:
        close(ckt.find("R1").value, val, 1e-12, what=f"sweep 值为 {val} 的副本")
    close(c.find("R1").value, 1e3, 1e-12, what="扫描后原电路 R1")

    # 多参数联合扫描：fixed 必须应用到每一份副本上
    rows2 = list(c.sweep("R1", [1e3, 2e3], C1=47e-9))
    for _, ckt in rows2:
        close(ckt.find("C1").value, 47e-9, 1e-12, what="fixed 参数 C1")


# ==========================================================================
# expect 的参数校验（断言声明本身写错了要立刻报，不要等到跑仿真）
# ==========================================================================
@case(group="expect 声明")
def test_expect_argument_validation():
    """expect() 的非法参数必须当场报错。

    防的是：mode 拼成 "minn"、tol 写成负数这种错误被静默接受，
    于是规格形同虚设 —— 报告显示"通过"，其实什么都没核对。
    """
    c = Circuit("rc")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)
    raises(CCLConfigError, c.expect, "fc", "out", 1e3, mode="minn", what="mode 非法")
    raises(CCLConfigError, c.expect, "fc", "out", 1e3, tol=-0.1, what="tol 为负")
    raises(CCLConfigError, c.expect, "fc", "out", None, what="value 为 None")
    raises(CCLConfigError, c.expect, "fc", None, 1e3, what="缺 target")
    # 合法声明要能链式调用
    c.expect("fc", "out", 1e3, tol=0.05).expect("gain", "out", 1.0, tol=0.02)
    is_true(len(c.expectations) == 2, f"两条规格应被记录，实测 {len(c.expectations)}")


# ==========================================================================
# 杂项契约
# ==========================================================================
@case(group="杂项契约")
def test_directive_rules():
    """directive() 只收 '.' 开头的行，且自动去重。

    防的是：把 .model 写成 "model xxx"（漏了点），ngspice 当器件行处理 →
    unknown model，报错指不到用户真正写错的地方。
    """
    c = Circuit("t")
    c.V("in", GND, dc=1)
    c.R("in", GND, 1e3)
    raises(CCLNetlistError, c.directive, "model X D", what="指令不含点")
    c.directive(".model X D(Is=1e-14)")
    c.directive("  .model X D(Is=1e-14)  ")   # 同一行（带空白）
    is_true(len(c.directives) == 1, f"重复指令应去重，实测 {c.directives}")


@case(group="杂项契约")
def test_component_clone_independent():
    """clone() 必须产出独立对象（改副本不影响原件），位号/节点可重映射。

    防的是：clone 只做浅拷贝 → 子电路内联时改一个实例的引脚，另一个实例跟着变，
    多实例电路的结果互相污染（而且完全静默）。
    """
    c = Circuit("t")
    r = c.R("a", "b", 1e3)
    r.params["temp"] = 27.0

    cl = r.clone(ref="R9", pin_nodes={"a": "x"})
    is_true(cl.ref == "R9", f"clone 应改位号，实测 {cl.ref}")
    is_true(cl.nodes() == ["x", "b"], f"clone 应重映射引脚，实测 {cl.nodes()}")
    is_true(r.nodes() == ["a", "b"], f"原件引脚不能变，实测 {r.nodes()}")
    cl.params["temp"] = 100.0
    close(r.params["temp"], 27.0, 1e-12, what="原件 params（== 说明拷贝不独立）")
    close(cl.value, 1e3, 1e-12, what="clone 的值")


@case(group="杂项契约")
def test_describe_smoke():
    """describe()/__repr__ 不能崩，且要给出器件数与节点数。

    防的是：报错/报告路径里调 describe() 时反而抛异常，把真正的错误盖掉。
    """
    c = Circuit("rc")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)
    text = c.describe()
    is_true("3 个器件" in text, f"describe 应给出器件数，实测：{text.splitlines()[0]}")
    is_true("R1" in text and "C1" in text, f"describe 应逐器件列出位号，实测：{text}")
    is_true("Circuit" in repr(c), f"repr 应含 Circuit，实测 {c!r}")


if __name__ == "__main__":
    sys.exit(H.main("test_core", "test_core：数据模型"))
