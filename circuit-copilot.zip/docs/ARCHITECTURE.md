# Circuit Copilot 架构说明

面向要接手或评审这个项目的人。读完应该能回答四个问题：

1. 一次「做一个 1kHz 的 RC 低通」或者一次「在 IDE 里按 Ctrl+Enter」的请求，代码里到底发生了什么，每步花多少钱；
2. 出了问题该去哪个文件里找；
3. CCL 那五层为什么要这样切，边界在哪；
4. 想加一个拓扑 / 器件 / 子电路块 / 检查项 / 面板，要动哪几个地方（以及哪几处最容易漏）。

本文所有描述都对应仓库里的实际代码；标了「实测」的数字是本机（Android / Termux / ngspice-47）跑出来的，
标了「注释」的是代码注释里记录的结论。

---

## 0. 先看全景

仓库里有三层东西，它们共用同一个 ngspice 后端，但彼此是**单向**依赖：

```
   ┌──────────────────────────── 浏览器 ────────────────────────────┐
   │  /            → web/index.html      参数化工具界面（单文件）      │
   │  /ide         → web/ide/index.html  CCL Studio（VS Code 风格）   │
   └───────────────┬─────────────────────────────┬──────────────────┘
                   │ NDJSON                      │ JSON
                   ▼                             ▼
          web/server.py                  web/ccl_api.py
       （路由 + 参数化设计流）          （CCL 的 HTTP 适配层）
                   │                             │
                   ▼                             ▼
        copilot/agent.py                       ccl/
     （理解 → 闸门 → 搜索 → 判定            （数据模型 → 编译 → 仿真
       → 容差 → 评审）                        → 检查/断言 → 报告）
                   │                             │
                   └──────────┬──────────────────┘
                              ▼
                      copilot/sim.py  ──►  ngspice -b（子进程）
                              │
                              ▼
              rawfile（二进制，失败回退 ASCII）→ Python 波形
```

CLI 入口 `main.py` 只连左边那条链（`copilot/`）；IDE 只连右边那条链（`ccl/`）。
两边唯一的共享物是 `copilot/sim.py`（ngspice 封装）和 `copilot/llm.py`（模型客户端）。

IDE 那一层还挂着一块**只读的电路图**：`Circuit` → SVG 的投影（`web/ide/schematic.js`）。
它不在仿真链路上，也不回写任何东西——图是投影，代码是真相（§6.4 讲算法，§6.5 讲怎么证明连接是对的）。

---

## 1. 模块职责与依赖关系

### 1.1 `ccl/`（12 个模块）—— CCL 代码库

```
                          ccl/__init__.py  （公开导出）
                                  │
        ┌──────────────┬──────────┼───────────────┬──────────────┐
        ▼              ▼          ▼               ▼              ▼
     errors.py      core.py    solution.py      devices.py     ...
     （叶子）          │            │               │
                       │            │               ├──► (lazy) copilot.topologies.opamp_subckt()
                       │            │               │
        ┌──────────────┼────────────┴───────┐       │
        ▼              ▼                    ▼       │
    format.py      compile.py            runner.py ─┴─► (lazy) copilot.sim
        │              │                    │
        └──────────────┴────────┬───────────┘
                                ▼
                     solution.py（Solution 波形访问）
                                │
              ┌─────────────────┼──────────────────┐
              ▼                 ▼                  ▼
        assertions.py      lint.py            blocks.py ──► core.py
              │                 │                  │
              └────────┬────────┴──────────────────┘
                       ▼
                   report.py ──► (lazy) copilot.elements（人类单位格式化）
```

> **行数表的读法（本节所有行数表都适用）**：下面的数字是 **2026-11-03 那次 `wc -l` 的快照**，
> 不是契约。要核对就自己敲 `wc -l ccl/*.py`——**以 `wc -l` 为准**，本文与它的差值只说明
> 「文档写完之后又改过代码」，不代表文档别的内容也错了。

| 文件 | 行数（快照） | 职责 | 关键入口 |
|---|---|---|---|
| `ccl/__init__.py` | 45 | 公开导出（不带出 ai） | `Circuit` `Solution` `Component` `Pin` `GND` + 6 个异常 |
| `ccl/errors.py` | 56 | 异常体系，报错必须带位号/节点名 | `CCLError` `NodeError` `RefError` `CCLConfigError` `CCLNetlistError` `CCLConvergenceError` `CCLAssertionError` |
| `ccl/core.py` | 664 | `Pin`/`Component`/`Circuit` 数据模型 + 便捷器件方法 + `expect/verify/sweep/with_/use/use_ports` + **仿真结果复用** | `Circuit` `GND` `normalize_node()`、**`Circuit.netlist_fingerprint()` / `remember_simulation()` / `recall_simulation()`** |
| `ccl/devices.py` | 1006 | **12 类**器件（含开关 `Switch`）、7 张真实模型卡、数值格式化入口 | `Resistor`…`SinSource`、`Switch`、`switch_model_name()`、`apply_switch_states()`、`MODEL_CARDS`、`component_directives()` |
| `ccl/format.py` | 220 | SPICE 数值格式化（网表里一律纯十进制） | `fmt_value()`、`fmt_eng()` |
| `ccl/compile.py` | 431 | `Circuit` → 网表；位号 SPICE 化；拒收 `.control` | `compile_circuit()`、`netlist_ref()` |
| `ccl/runner.py` | 484 | 生成分析卡 → 调 `copilot.sim` → 翻译异常 + **把 Solution 记回 circuit（供复用）** | `ac_sweep()` `operating_point()` `transient()` **`dc_sweep()`** `simulate()`、`apply_switch_states()`、`_drop_stale_switch_directives()` |
| `ccl/solution.py` | 989 | 波形访问与指标计算（全部 Python 侧） | `Solution.v/db/phase/mag/f3db/peak_db/value_at/node_names/plot`、**`dc_curves()`**、**`rise_time/fall_time/overshoot_pct/settling_time/steady_state`** |
| `ccl/assertions.py` | 306 | `c.expect` 的实现与核对 | `Expect` `ExpectResult` `Report` `evaluate()` |
| `ccl/lint.py` | 619 | 静态 + 工作点检查（**唯一真相**） | `lint()` `Issue` `check_solution()` |
| `ccl/blocks.py` | 320 | 12 个可复用子电路块 | `BLOCKS` `catalog()` |
| `ccl/report.py` | 252 | Markdown 报告（6 章节，无 `expect` 时是 5 节）；**网表带分析卡、`tran` 报末值/峰值/谷值、`dc` 报起点/末点（只有 `ac` 才用 `f3db/peak_db`）** | `markdown()` |

两个细节值得先记住：

- `assertions.py` 与 `lint.py` **不 import 任何 ccl 模块**（只有 `math`/`re`），
  它们的输入是「电路 + Solution」。这让它们能被单测直接喂假数据，也避免了和 `solution` 成环。
- 核心层对 `copilot/` 的依赖只有**三处、全是函数内 lazy import**：
  `devices → opamp_subckt`（复用已验证的运放宏模型）、`runner → sim`（ngspice 后端）、
  `report → elements`（`4.7kΩ` / `100nF` 这种人类单位）。`import ccl` 本身不需要 ngspice。

### 1.2 `ccl/ai/`（8 个文件）—— 可选 AI 子包

```
ccl/ai/__init__.py
   ├── generate.py ──► prompts.py、sandbox.py、spec_check.py、（lazy）..assertions、..lint、copilot.llm
   ├── review.py   ──► ..lint（Issue 复用）、（lazy）copilot.llm
   ├── explain.py  ──► prompts.py、（lazy）copilot.llm
   ├── sandbox.py  ──► ast / signal / importlib（+ lazy ..core.Circuit）
   ├── spec_check.py ──► 纯 stdlib（从中文里抽数字）+ `Unmeasurable`
   ├── plugin_gen.py ──► 生成插件（python 后端 + JS 面板）；只被 `POST /api/plugin/gen`、`/api/plugin/install` 用
   └── prompts.py  ──► 纯 stdlib（API_CARD + 7 个 few-shot）
```

| 文件 | 行数（快照） | 职责 |
|---|---|---|
| `generate.py` | 780 | `generate()` 生成 + 自修复循环；`fix()` 诊断驱动修复；`Generation`/`Attempt`；**lint 闸门**、`_model_claims_impossible()`、`_diagnose(…, request)` |
| `sandbox.py` | 486 | AST 白名单（含**禁止 `对象.属性 = …`**）+ 受限 `__builtins__` + 超时 + 行号定位 + **`_snapshot_guarded/_restore_if_polluted` 运行时回滚**；`run_source()` |
| `prompts.py` | 336 | `API_CARD`（器件与 API 卡）、`FEWSHOT`（7 个可运行示例）、`repair_prompt()` |
| `spec_check.py` | 598 | 从需求原文正则抽目标数字，和生成代码的实测做兜底核对；**测不到抛 `Unmeasurable`**、`unparsed_metrics()` 覆盖总闸 |
| `review.py` | 500 | 从 `ccl.lint` 导入静态/工作点检查，**只保留**叙事 + 波形形状检查（撞轨/峰化） |
| `plugin_gen.py` | 524 | 插件生成器（`ccl.lint` 规则 + JS 侧栏面板），与电路生成链无关 |
| `explain.py` | 280 | 中文解释；无模型时退回确定性模板 |
| `__init__.py` | 38 | 导出 `generate/fix/review/explain/Generation/Attempt/Issue/LLMUnavailable` |

**核心库绝不 import 这个子包**——`import ccl` 在没有 API Key、没有网络的环境里也不会失败。

### 1.3 `web/` 与 `web/ide/`（5 + 10 个文件）—— 界面

| 文件 | 行数（快照） | 职责 |
|---|---|---|
| `web/server.py` | 644 | `ThreadingHTTPServer`：静态页 + `/ide` 路由 + 参数化设计（NDJSON 流）+ CCL 四个接口转发 |
| `web/ccl_api.py` | 1023 | CCL 的 HTTP 适配层：`execute()`（沙箱执行→仿真→lint→expect→**live/timeline**）、`run_analysis()`（四类分析的分发与序列化，**命中缓存时 `analysis.reused=true`**）、**`collect_live()` / `collect_timeline()`**、**`_downsample()` / `_downsample_idx()`（保峰降采样）**、`ai_*`、`build_report` |
| `web/ccl_examples.py` | 209 | IDE 侧栏示例代码（11 条，**必须真实可跑**；改器件层后要重跑验证） |
| `web/index.html` | 964 | 参数化工具的单文件前端（原生 JS + 手写 SVG Bode 图 + 容差区间条） |
| `web/ccl.html` | 514 | M1~M3 的聊天式 CCL 页面。主路由 `/ccl` 已 302 到 `/ide`，这个文件只保留兼容 |
| `web/ide/index.html` | 121 | IDE 的 DOM 骨架（标题栏/活动栏/侧栏/主区/结果面板/状态栏） |
| `web/ide/style.css` | 1371 | VS Code Dark+ 配色、四区网格、桌面与窄屏断点、命令面板、分隔条、电路图全屏浮层 |
| `web/ide/main.js` | 2688 | **集成层**：活动栏、侧栏、标签页（**开关覆盖按标签页存**）、运行（+`switch_states`）、**开关覆盖提示条 + 「恢复按代码运行」**、AI 三动作、报告下载、电路图全屏与导出、**动画参数组装（`animSpec`）**、状态栏、分隔条 |
| `web/ide/editor.js` | 1915 | 编辑器：行号、高亮、诊断、自动缩进、括号配对、Ctrl+/ 注释、自维护 undo |
| `web/ide/panels.js` | 1815 | 结果面板：电路图（**+ 时间轴播放条的挂载/销毁**）、SVG Bode（dB + 相位）、DC 曲线族、十字线、PNG 导出、问题/指标/工作点/网表/报告 |
| `web/ide/schematic.js` | 2113 | **只读电路图**：`Circuit` → SVG（分层布局 + 正交走线）+ **工作态/瞬态动画层**；**17 个命名导出 + `default`**（`renderSchematic` / `schematicOrEmpty` / `applyLive` / `applyLiveFrame` / `createPlayer` / `wireSwitchClicks` / `deriveSwitchStates` / `switchSideEffects` …，清单见 §6.4） |
| `web/ide/boot.js` | 189 | 启动层：首屏骨架、加载态与「运行中」指示，先出界面再等后端 |
| `web/ide/plugins.js` | 291 | 插件面板：已加载扩展列表与状态（`plugins/` 下的示例插件从这里可见） |
| `web/ide/commands.js` | 97 | 命令面板（Ctrl/Cmd+Shift+P）：自建 DOM、↑↓/Enter/Esc |
| `web/ide/snippets.js` | 71 | 块与器件的插入片段 + 自动补 `from ccl.blocks import BLOCKS` |

（`web/ide/` 一共 10 个文件：1 HTML + 1 CSS + 8 JS，另有 **4 份契约**：`CONTRACT.md`（骨架）、`CONTRACT_ROUND4.md`（早期移动端实测缺陷，历史）、
`CONTRACT_ROUND5_DESKTOP.md`（桌面版对标）、`CONTRACT_SCHEMATIC.md`（电路图模块）。哪份管哪一层见那几篇开头的「相关契约（别处）」。）

### 1.4 `copilot/`（12 个模块 + `topologies/` 包）—— 参数化工具

```
main.py ──► agent.py ──┬─► understand.py ─┬─► llm.py（OpenAI 兼容, urllib）
                       │                   ├─► feasibility.py（纯解析式）
                       │                   └─► verify.py（语义对账）
                       ├─► topologies/ ──► sim.py ──► ngspice
                       ├─► judge.py（只 import topologies 读 METRICS）
                       ├─► tolerance.py（import judge + sim）
                       └─► report.py ──►（反向 import agent.Session）
```

| 文件 | 行数 | 职责 |
|---|---|---|
| `copilot/sim.py` | 494 | ngspice 封装：注入 `.control`、`ngspice -b`、**二进制 rawfile 解析（`_parse_binary_raw()`，失败回退 `_parse_ascii_raw()`）**、复数 `Wave`、`branch_currents(at_index=)` |
| `copilot/topologies/`（包） | 2789 | 13 个参数化拓扑、`METRICS` 词表、`Param/Design/Topology`、`opamp_subckt()`、`ac_sweep()`。实现按职责拆成 `base.py`（基类与通用数值工具）、`filters.py`、`amplifiers.py`、`misc.py` 四个子模块，`__init__.py` 只做门面 re-export + 持有 `REGISTRY` |
| `copilot/elements.py` | 103 | E6/E12/E24/E96 吸附 + `human_r/c/l/f` 人类单位 |
| `copilot/agent.py` | 1044 | 闭环主流程 `run()`、候选搜索、关键词路由 `parse_rules()`、`Session` |
| `copilot/understand.py` | 285 | 需求理解编排：语言理解 / 假设声明 / 可行性预判 / 语义复核的串接 |
| `copilot/feasibility.py` | 384 | 物理可行性预判（一阶 RC 不可能 60dB 衰减这类，纯公式判定） |
| `copilot/verify.py` | 220 | 语义对账闸门：把用户原文里的数字和最终 spec 逐项比对 |
| `copilot/scope.py` | 220 | **能力边界**：本工具不做的电路（开关电源 / 振荡器 / 变压器…）当场拒绝，不兜底凑一个 |
| `copilot/judge.py` | 152 | 判定规则 `Rule(mode, tol, kind)`、`SPEC_RULE`、`check()`、`cost()` |
| `copilot/tolerance.py` | 411 | 蒙特卡洛：三层容差叠加、高斯扰动、分布、成品率、短板 |
| `copilot/llm.py` | 320 | OpenAI 兼容 chat（纯 `urllib`）、`plan()`/`review()`、配置读写 |
| `copilot/report.py` | 344 | Markdown 报告 + BOM（从**网表**反推，`SIM_ONLY_REFS` 剔掉仿真专用件） |

（表里的行数是 **2026-11-03 快照**的 `wc -l`，**以你手上的 `wc -l` 为准**；拓扑数量和块数量更不要信文档里的
写死数字，用 `python3 main.py --catalog` 与 `from ccl.blocks import BLOCKS` 现取。）

### 1.5 三条依赖纪律

1. **严格单向**，唯一的例外是 `report.py` 反过来 import `agent.Session`（报告就是「打印 Session」），
   所以 `agent` 不能 import `report`——CLI 与 Web 各自在入口处把两者拼起来。
2. `judge.py` **只 import `topologies`**（读 `METRICS` 词表），绝不 import `agent`，
   否则 `agent → judge` 与 `judge → agent` 成环（容差分析也要用 `judge.check()`）。
3. `ccl/` 与 `copilot/` 之间没有反向依赖：`copilot` 完全不知道 CCL 存在，
   所以 IDE 那条链坏了不会影响 CLI，反之亦然。

---

## 2. CCL 的五层结构

CCL 的分层不是审美，是**每一层都能被单独验证**的结果：

```
  ① 数据模型   core.py        Pin / Component / Circuit        —— 不含任何仿真知识
  ② 编译       compile.py     Circuit → 网表（+ format.py 数值） —— 唯一的"编译"出口
  ③ 仿真       runner.py      Circuit → 分析卡 → copilot.sim
               solution.py    波形 → 指标（v/db/f3db/peak_db…）
  ④ 检查       lint.py        静态 + 工作点          ┐ 全是确定性代码
               assertions.py  c.expect 规格断言      ┘ 无 API Key 也能用
  ⑤ AI（可选） ccl/ai/        generate / fix / review / explain
```

### 2.1 第 1 层：数据模型（`core.py`）

`Circuit` 只描述「有哪些器件、每个引脚接哪个节点」，**不知道 SPICE 长什么样**。
四条刻意的约定：

- 节点是字符串，地固定 `GND = "0"`（跟 SPICE 一致，不发明新地符号）。
- `Component.pins` 是**有序**列表，第 i 个引脚 = 网表里第 i 个端子。顺序由器件类保证。
- 多端器件：两端件 `(a, b, value)`；三端及以上按引脚顺序做位置参数且同名关键字可用。
- 子电路复用走「**内联展平**」而不是 `.subckt`：`Circuit.use()` 把子电路的器件 `clone()` 进来，
  位号加前缀（`U1.R1`）、内部节点加前缀（`U1.n1`）。没有作用域管理，也没有 `.subckt` 名字冲突
  （器件自己的宏模型如运放仍用 `.subckt`，由器件的 `directives()` 输出）。

### 2.2 第 2 层：编译（`compile.py` + `format.py`）

输出结构固定：标题行 → 器件行 → directives（`.model`/`.subckt`）→ 分析卡 → `.end`。
这一层扛着三个「必须在源头掐掉」的决定（详见 `ccl/CONTRACT.md` D1/D2/D5）：

- **不注入 `.control`**，而且会**拒收**用户手写的 `.control`（抛 `CCLNetlistError`）。
  因为 `copilot.sim.run()` 靠「网表里没有 `.control`」才注入自己的控制块，没有它 rawfile 不落盘。
- **数值一律纯十进制**，不用单位后缀。实测 `1m → 0.001`、`1M → 0.001`（大写 M 也是毫！），
  所以 `fmt_value()` 只输出 `1600`、`0.0000001`、`1e-09` 这类形式。
- **写进网表的位号必须过 `netlist_ref()`**：ngspice 按行首字符判断器件类型，
  内联产生的 `U1.R1` 会被当成 U 型器件拒收，必须补成 `R.U1.R1`。

另外有一道「值 token 内部不得含空白」的保护（第 218 行起）：它挡的是「拆分错列」这类最难查的 bug。
它的代价是 PULSE/SIN 不能用空格写法（见 §7.11）。

### 2.3 第 3 层：仿真（`runner.py` + `solution.py`）

`runner` 很薄，只做四件事：生成分析卡（`.ac dec N f1 f2` / `.op` / `.tran step stop` /
**`.dc src start stop step`**）、把器件宏模型塞进 directives、把 `copilot.sim.SimError`
翻译成 `CCLConvergenceError`（**保留 netlist 与原始输出**，上层自纠全靠这两个字段）、计时。

第四件藏在 `copilot.sim` 里：**把每个器件的支路电流也存进 rawfile**（`_save_devices()` 自动生成
`save all @r1[i] @d1[id] @sw1[i] …`）。`write all` 只给节点电压与电源电流，不含器件内部量，
而「LED 按电流发光、电阻按功耗发热」全部依赖它。**AC 一律不下发 save**（频域没有支路电流，
实测 `save all @r1[i]` 会让 `write` 失败 → 「仿真未产生任何波形数据」→ 整个交流电路崩掉，
这个回归被 `tests_api` 抓到并钉住）；中间态（网表里还没有分析卡）返回 `"none"`，同样不下发。

两个必须知道的边界（都实测过）：

- **`.subckt` ~ `.ends` 之间的器件一律不 save**（`copilot/sim.py:231` 的 `in_subckt` 状态机）。
  子电路内部元件的 `@r0[i]` 在顶层命名空间里根本不存在，ngspice 会报
  `Warning from checkvalid: vector @c0[i] is not available` → `Error during 'write': no writable vector found`
  → **整次仿真失败**。运放宏模型内部就有 `R0/C0`，所以这条漏了的时候**任何含 `c.OpAmp()` 的电路在
  op/tran/dc 下 100% 跑不了**（项目自带的运放拓扑只做 `.ac`、不下发 save，所以测试全绿没抓到）。
- **save 失败绝不决定仿真的成败**：`run()` 发现 rawfile 是空/`no writable vector found` 就
  **丢掉 save 重跑一次**（`copilot/sim.py::run()` 的 `build("")` 分支）。电路结果仍然正确，
  只是没有器件级数据（界面就不显示工作态）。

**取数格式：默认二进制 rawfile，ASCII 退为回退路径**（`copilot/sim.py:143-217`、`:409`、`:461-465`）

- control 块现在写 `set filetype=binary`（`sim.py:409`，受 `_use_binary_raw()` 控制），
  新增 `_parse_binary_raw()`：读纯 ASCII 头部（`No. Variables/Points/Flags` + 变量表）到
  一行 `Binary:\n`，之后是原生 double 序列（复数则实部/虚部交替），用 `array("d")` **一次读完**。
- **ASCII 回退保留**：`_parse_binary_raw()` 任何异常/格式不符都返回 `None`
  （头部超过 1 MB、短读、没有 `Binary:` 行都算），`run()` 于是回退 `_parse_ascii_raw()`
  ——「取数优化」不允许决定「仿真成败」。`CCL_RAW_ASCII=1`（或 `true`/`yes`）可强制走 ASCII，
  出事时的手动开关。
- **为什么换**：ASCII 只有约 10 位有效数字，且 12 MB 文本要拆成 50 万+ 个子串再逐个 `float()`。
  实测（本次对账自己跑的：41 器件 RC 梯形、`.tran 1u 10m`、10008 点、62 条波形）：
  **binary 883 ms / ascii 3709 ms（4.2×）**，逐点最大偏差 **8.88e-16**（float64 舍入，被截断的是 ASCII 那侧）。
  仓库里 `3a76c17` 记的同一份 35 器件网表是 905 ms / 2576 ms，端到端 `POST /api/ccl/run` 约 **4.8 s → 1.61 s**。
- **二进制解析错位不会报错，只会静默算错**（寄存器顺序 / 复数交错 / `.op` 无横轴这些分支），
  所以钉了一条常驻用例 `tests_ccl/test_sim.py::test_binary_raw_matches_ascii`：同一份网表跑两遍
  （一遍 `CCL_RAW_ASCII=1`）逐点比对全部波形，并要求最大偏差 <1e-12；`.op` 单独比。
- 边界：这只覆盖 `write c.raw all` 这一条落盘路径（CCL 侧本来就会**拒收**用户手写的 `.control`，见 §2.2）；
  `.op` 的 plot 没有独立横轴，横轴一律 `0..n−1`（与 ASCII 解析口径一致）。

`solution` 是「波形 → 数字」的唯一入口，所有指标都在 Python 侧算，不用 `.meas`。
节点名大小写与 `v(out)` / `out` 两种写法都兼容；查不到节点抛 `NodeError` 并列出可用节点。

第三轮加进来的两块分析能力都住在这层，且**都在 Python 侧**：

- **直流扫描**（`runner.dc_sweep()` + `Solution.dc_curves()`）：一维给传输特性，
  两维给曲线族。两维结果在 rawfile 里是「外层固定、内层扫完」的分段结构，
  `dc_curves()` 按内层点数切段（切段前先核对点数整除，对不上就退回
  「扫描量回头处切段」的实测切法）；不切段直接按点号连线会画出折返锯齿。
- **瞬态指标**（`Solution.rise_time/fall_time/overshoot_pct/settling_time/steady_state`）：
  高/低电平取「第一样本 + 末段 10% 均值」，10%/90% 电平在相邻样本间线性插值，
  测不到一律 `None`。三条口径边界（多周期脉冲串、`t_stop ≥ 5τ`、`steady_state` 是窗口均值）
  写在 `ccl/CONTRACT.md` 的「已知限制（分析方法本身）」里。

### 2.4 第 4 层：检查（`lint.py` + `assertions.py`）

这一层是「代码即测试」的底座，**住在核心库而不是 AI 包里**——因为它是库的能力，
不是模型的能力：没有 API Key 也必须能用。

- `lint()` 分两段：静态（空电路/无地/悬空/无直流通路/电压源并联/参数越界/无 AC 激励/孤立子网）
  与工作点（节点电压发散/电阻功耗/BJT 工作区/MOS 工作区）。任何单项检查抛异常都只打印跳过，
  不让检查器自己变成崩溃源。
- `assertions.py` 把 `c.expect(...)` 声明的规格跑成 `Report`：`eq/min/max` × `rel/abs`，
  **测不到的指标判 `NaN` → 未达标，绝不编数据**。

### 2.5 第 5 层：AI（`ccl/ai/`，可选）

三条硬性要求写在 `generate.py` / `sandbox.py` 的 docstring 里：生成**代码**（不是网表）、
生成后**必须真跑一次**、exec **必须隔离**（AST 白名单 + 受限 builtins + 超时）。
`sandbox.run_source()` 同时被 `generate()` / `fix()` / `web/ccl_api.execute()` 复用——
浏览器里贴的代码和模型生成的代码享受同一套限制。

**边界**：核心库不 import `ccl.ai`；`ccl.ai.review` 从 `ccl.lint` 导入检查项（反向依赖是不允许的）。

#### 「AI 说成功」必须同时满足六条（第三轮审计后定案）

这一层的判据只有一句：**拿不到证据就当失败**。落到代码上是六个互相独立的闸门：
**前五条不满足就 `ok=False` 并进修复循环**，第六条（覆盖总闸）不判失败但**必须**把
「这些指标没自动核对」写进 `warnings`（细节与代码位置见 `ccl/CONTRACT.md`
的「AI 生成链的对账语义」一节）：

| 闸门 | 什么时候判失败 | 位置 |
|---|---|---|
| 沙箱静态检查 | 导入白名单外、`while`、下划线属性、`__` 名字、**`对象.属性 = …`** | `sandbox.py:_Checker` |
| 运行时护栏 | exec 之后发现 `Circuit.ac/tran/op/dc/…` 被改写 → **回滚 + 判失败** | `sandbox.py:_snapshot_guarded/_restore_if_polluted` |
| 结构 + lint | `validate()` 失败；或 `circuit.lint(None)` 出 `error`（`R=1nΩ`、`C=100kF` 这种买不到的值） | `generate.py:_run_and_simulate` |
| 需求对账 | `check_targets_strict()` 抛 `Unmeasurable`（solution 为空 / 读不出节点 / 没有可测节点 / **需求里没写输入电压**）或不达标 | `spec_check.py` |
| 模型自认不可能 | 源码注释里出现「物理上不可能 / 互相矛盾」等标记 → 按**未交付**处理 | `generate.py:_model_claims_impossible()` |
| 覆盖总闸 | 需求里有量化词+数字、但 `parse_targets()` 一个都没抽出来 → 逐词报出来让人工确认 | `generate.py` + `spec_check.unparsed_metrics()` |

两个历史教训值得记住（都是「同一段代码，成败取决于写法」）：

- **`check_targets` 的 `[]` 有三义**（没抽到目标 / 全部达标 / **测不到**），调用方一律读成「没问题」。
  现在 `check_targets_strict()` 用 `Unmeasurable` 把「测不到」变成异常，旧签名 `check_targets()` 只为兼容保留（仍返回 `[]`）。
- **`vin` 不再「取前面所有电压的最大值」**：那让「设计一个 3.3V 电源电路，输出 3.3V」里的产品名 3.3V
  被当成输入电压。现在的优先级是「显式输入标记 → 目标值之前最靠后且≠目标的电压 → **没有就返回 None 并抛 `Unmeasurable`**」，
  即**不猜**。

---

## 3. 一次参数化设计请求的时序

以「做一个 1MHz 的 Sallen-Key 二阶低通滤波器」为例（无大模型 Key，走规则模式）。

```
浏览器                       web/server.py              copilot/agent.py        子进程 / 其它模块
  │  POST /api/design             │                          │                        │
  │  {"text": "...", "use_llm":t} │                          │                        │
  ├──────────────────────────────►│  _read_body()            │                        │
  │                               │  sid = uuid4()[:12]      │                        │
  │◄── 200 + ndjson 头 ───────────┤  （无 Content-Length，     │                        │
  │    Connection: close          │    必须 Connection:close）│                        │
  │                               │  agent.run(text,         │                        │
  │                               │    progress=progress) ──►│                        │
  │◄── {"type":"stage",           │                          │ emit("understand")     │
  │      stage:"understand"} ─────┤                          │  LLM().available()     │
  │                               │                          │  → True 走 plan()      │
  │                               │                          │  → False 走 parse_rules│
  │◄── stage:"design" ────────────┤                          │ emit("design")         │
  │                               │                          │  topo.design(spec)     │
  │                               │                          │  ── 阶段 2.5 闸门 ──    │
  │                               │                          │  feasibility.evaluate()│
  │                               │                          │  verify.verify()       │
  │◄── stage:"simulate"           │                          │  _candidates(base)     │
  │    {done:n,total:N}  ×N ──────┤                          │  for 候选:              │
  │                               │                          │   topo.build(c) ──────►│ sim.run(netlist)
  │                               │                          │                        │  ngspice -b c.cir
  │                               │                          │   judge.check(spec,    │◄─ RAW 二进制波形
  │                               │                          │     d.metrics,         │   （单次 50~165ms）
  │                               │                          │     topo.spec_overrides)│
  │                               │                          │   judge.cost(rows)     │
  │◄── stage:"tolerance" ─────────┤                          │ emit("tolerance")      │
  │                               │                          │  monte_carlo(runs=20) ►│ 20 × topo.build()
  │                               │                          │                        │ ≈ 2.9 s（实测）
  │◄── stage:"review" ────────────┤                          │ emit("review")         │
  │◄── {"type":"result", id,      │  LOCK: SESSIONS[sid]=s   │  无 Key → _rule_review()│
  │     data:serialize(s)} ───────┤                          │                        │
  └── 连接关闭（Connection: close）└──────────────────────────┴────────────────────────┘
```

### 3.1 各阶段耗时（实测，本机）

| 阶段 | 做什么 | 耗时量级 | 备注 |
|---|---|---|---|
| `understand` | 规则匹配 / 一次 chat | 规则 <5 ms / LLM 1~5 s | LLM 失败降级为规则，并写进报告 `注意` |
| `design` | `topo.design(spec)`，纯解析式 | <5 ms | 结果**不吸附**标称值，留给搜索 |
| `design` 之后的**闸门** | `feasibility.evaluate()` + `verify.verify()` | <2 ms | 纯正则与公式；闸门本身抛异常只打印跳过 |
| `simulate` | 每候选一次 `topo.build()`（运放类要 2~3 个网表） | 单次 35~165 ms；整段 0.2~0.8 s | RC 一阶实测 3 候选共 189~207 ms；同相放大 9 候选 743 ms。对账复测单次：`rc_lowpass` 130 ms、`sallen_key_lowpass` 36 ms、`opamp_noninverting` 35 ms（换二进制 rawfile 后比原记录更快） |
| `tolerance` | 20 次高斯扰动，每次重建+仿真 | 实测 **2.94 s** | `runs=20` 硬编码在 `agent.run()` |
| `review` | 规则模板 <1 ms；LLM 一次 chat | <1 ms / 1~5 s | 规则评审永远有输出 |

端到端（规则模式，含 Python 导入与子进程启动）：

| 需求 | 候选数 | 工具自己记账的「累计仿真耗时」 | 墙钟时间 |
|---|---|---|---|
| `做一个1kHz的RC低通滤波器` | 3 | 189~207 ms | 2.5~3.4 s |
| `做一个1MHz的Sallen-Key二阶低通滤波器` | 18 | 2.2 s | 7~12 s |

墙钟与账面的差额是**每次 `ngspice` 子进程的启动开销 + Python 导入 + 系统负载**（这台机器上常有并行任务）。
看性能别只看墙钟，报告末尾的「累计仿真耗时」是工具自己记的账。

### 3.2 HTTP 接口（`web/server.py`，两块并存）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/`、`/index.html` | 参数化工具的单文件前端 |
| GET | `/ide`、`/ide/*` | IDE 页面与静态资源（`..` 与绝对路径一律 400） |
| GET | `/ccl`、`/ccl.html` | 302 → `/ide`（旧的聊天式页面路径保留兼容） |
| GET | `/api/health` | `agent.diagnose()`：ngspice 版本、拓扑数、LLM 是否配置 |
| GET | `/api/catalog` | 拓扑清单（同一份数据喂给 LLM 与前端） |
| GET | `/api/report/<sid>` | 该会话的 Markdown 附件 |
| POST | `/api/design` | 参数化设计主流程，响应为 **NDJSON 流**（`stage`×N + `result`/`error`） |
| POST | `/api/config` | 写 LLM Key/Base/Model（`~/.cc/config.json`，权限 600） |
| GET | `/api/ccl/example` | IDE 示例清单（11 条） |
| GET | `/api/ccl/blocks` | 12 个子电路块的签名与说明 |
| POST | `/api/ccl/run` | `{code, analysis, require?, switch_states?}` → `{ok, circuit, analysis, lint, expect, netlist, error, line, stage}` + `live` / `timeline` / `switch_states` / `switch_apply`（见 §4.2） |
| POST | `/api/ccl/ai` | `{action:"generate"\|"fix"\|"explain", prompt?, code?, analysis?}` |
| POST | `/api/ccl/report` | `{code, analysis}` → `{ok, markdown, id, filename}` |
| GET | `/api/ccl/report/<id>` | 附件下载（`Content-Disposition: attachment`） |

会话只存在内存里（`SESSIONS: dict[str, Session]` + `threading.Lock`），进程重启即失效——
所以 `/api/report/<sid>` 找不到时返回 404 并提示「报告不存在或已过期，请重新生成设计」。
`/api/ccl/report` 的缓存同理（按 id 最多留 30 份）。

---

## 4. 一次 IDE 请求的时序

```
editor.js（textarea）  main.js                      web/ccl_api.py            ccl/
   Ctrl+Enter ─────────► run()                       │                        │
                         POST /api/ccl/run            │                        │
                         {code, analysis} ───────────►│ execute()              │
                                                      │ sandbox.run_source() ──►│ AST 白名单 + exec
                                                      │                        │ 拿到 Circuit
                                                      │ circuit.validate() ────►│ 结构自检
                                                      │ circuit.to_spice() ────►│ 网表（含分析卡）
                                                      │ run_analysis() ────────►│ .dc/.tran/.ac/.op → Solution
                                                      │ collect_lint() ────────►│ ccl.lint
                                                      │ collect_expect() ──────►│ ccl.assertions
                                                      │ collect_timeline() ────►│ 仅 tran：t + series
                                                      │ collect_live() ────────►│ op/tran/dc：器件级 I/V/P
                         ◄────────────────────────────│ {ok, circuit, analysis, │
                         applyResult(d)                │  lint, expect, netlist, │
                                                      │  live, timeline}        │
   setDiagnostics()◄──────┤ 面板：波形/问题/指标/工作点/网表   │
   状态栏 行/列、器件数、规格 n/m │                        │                        │
```

`analysis.traces` 的形状（前端画图直接用）：

```js
traces = { "out": { x:[1,1.02,…], y:[-0.02,-0.05,…], phase:[…], unit:"dB" }, … }
```

`unit:"dB"` 表示 `y` **已经是 dB 值**，前端不许再转一次（见 §7.12）。

**一次 IDE 运行的端到端耗时（实测）**：35 器件梯形网络 + LED 的 `.tran 10m`，`POST /api/ccl/run`
端到端约 **1.6 s**（换二进制 rawfile 之前约 4.8 s，见提交 `3a76c17`）。同一份电路 + 同一组分析参数
再跑一次时 `recall_simulation()` 命中缓存、**不再起 ngspice**，响应里 `analysis.reused=true`（见 §4.2 末）。
TRAN / DC 分析的 `unit` 都是 `"V"`；OP 分析不产生 traces，只给 `op: {节点: 电压}`。

### 4.1 `run_analysis()` 的四条分支

`web/ccl_api.py::run_analysis(circuit, spec)` 是唯一的分发点，`spec.kind` 决定走哪条路。
四条路径的参数、网表卡与返回形状都不一样，前端只认 `kind`：

| `kind` | `spec` 里的字段 | 实际调用 | `analysis` 里回来的东西 |
|---|---|---|---|
| `"op"` | 无 | `circuit.op()` | `op: {节点: 电压}`，`traces` 为空，`xs` 清空 |
| `"ac"`（默认） | `f_start` / `f_stop` / `points`（10~1000 夹紧） | `circuit.ac(f1, f2, pts)` | 每节点 `{x, y(dB), phase, unit:"dB"}` |
| `"tran"` | `t_step` / `t_stop`（`t_stop/t_step > 2e6` 时自动放大 `t_step` 并写 warning） | `circuit.tran(t_step, t_stop)` | 每节点 `{x, y, unit:"V"}` + **`metrics`**（5 个瞬态指标，测不到是 `null`） |
| `"dc"` | `source`（必填，位号）+ `dc_start` / `dc_stop` / `dc_step`，可选 `second_source` / `second_start` / `second_stop` / `second_step` | `circuit.dc(src, a, b, st, second=…)` | 按曲线族拆开的 `traces`：无第二维时 key 是节点名，有第二维时是 `"out @ I1=0.5mA"`，每条 `{x, y, unit:"V", label}` |

几个必须知道的口径（都在代码里）：

- **`dc` 的 `source` 是位号，不是节点名**；缺了直接报错
  `直流扫描需要指定被扫器件位号（如 V1）`，不会静默退化成别的分析。
- `dc_step` 缺省是 `(dc_stop - dc_start)/100`（仍是 0 就取 1），`second_*` 缺省
  `0 → 1e-3`、步长 `5e-4`。
- `traces` 一律走 `_downsample()`，并且 `_num()` 把 NaN/Inf 转成 `null`（见 §7.9）。
- `sweepVar` / `secondVar` 原样回传，`panels.js` 的十字线读数靠它显示 `V1=3.2V out=1.85V`。
- 实测（本机）：分压 `V1 0→5V` 单维回 6 个点；同一电路加 `second_source=I1`（0→1mA，3 段）
  回 18 个点、6 条 trace（`in @ I1=0A` / `in @ I1=0.5mA` / `in @ I1=1mA` …），每条 6 点。

> 界面上「直流扫描」工具条只填得了第一维（`扫/起/止/步`）；第二维目前只有
> Python API 与 `POST /api/ccl/run` 的 `second_*` 字段能表达——这是已知缺口，不是文档口径问题。

**规格核对会补跑一次分析**：用户声明的规格可能同时含交流类（`fc`）和工作点类（`v`），
而页面一次只跑一种分析，`collect_expect()` 会把缺的那一类补跑一次（单次几十毫秒），
并在 `expect.extra` 里如实说明「为核对交流类规格，额外跑了一次扫频」。

### 4.2 「工作态」三件套：`switch_states` / `live` / `timeline`（M6）

口径的权威在 `ccl/CONTRACT.md` 的「M6 新增」一节，这里只记**实现分布与串联关系**。

**开关状态覆盖（仿真之前）**：`execute()` 拿到 `Circuit` 之后、`describe_circuit()` 之后、
`validate()` 之前，如果请求带了 `switch_states`，就调 `ccl.runner.apply_switch_states()`
就地改电路对象（改控制节点上**独立 DC 电压源**的 DC 值 → `"source"`；没有可改的 DC 源就改该开关
`.model` 的 `Vt` → `"vt"`），**不动用户代码文本**，并把两件事分开回报：`switch_apply`（怎么做的）
与 `switch_states`（最终状态）。

三条容易搞错的口径（都在 `ccl/devices.py:738` / `:785`）：

- **PULSE / SIN 源不能走 `source` 那条路**：它们的 KIND 也是 `"V"`，但网表里没有 `dc` 位置，
  改 `comp.dc` 后网表一个字节都不变，却仍会回报 `"source"` → 用户点了开关毫无反应。
  判据是 `value_tokens()[0] == "DC"`，不满足就落到 `vt` 路径。
- **`vt` 判据固定为 `Vt = ∓1000V`**（导通 `-1000`、断开 `+1000`），与控制波形无关；
  早先「先跑 `circuit.op()` 量出 `V(ctrl)` 再放到它另一侧」对 PULSE 驱动完全失效，还白跑一次仿真。
- **未知位号不再让整次运行失败**：忽略 + 往 `warnings` 里写一条，`ok` 仍为 `true`
  （`stage="switch_states"` 现在只用于「状态词认不出」和控制端无源这两类真错误）。

**器件级工作态 `live`**（`web/ccl_api.py::collect_live()`）：电流来自
`copilot.sim.branch_currents(solution, at_index=…)`，电压来自两端节点电压之差，功耗 `|V·I|`。
**`ac` 一律 `None`**；取不到的量是 `None`（不估算）。四个容易被误读的口径：

- **取哪个时刻：`tran` / `dc` 取末点**（`t_pick = solution.x[-1]`，电流用同一个
  `at_index = len(xs)-1`），`op` 就是那一个点。**电流与电压严格来自同一时刻**——早先电流写死取
  `ys[0]` 而电压已取末点，功耗算成 `|I(t=0)·V(t末点)|`，没有物理意义（实测 PULSE 电路报
  R1 `0A/0W`，真值 11.4mA/28mW）。**旧文档「`tran` 下 `live` 是 `t=0` 的快照」已经作废。**
- `live` 里多了一个 **`t`** 字段（秒；op 恒 `0.0`），说明这份工作态是哪个时刻的。
- **`voltage` 取了绝对值**（没有极性）；而且**只有正好两个引脚的器件才有 `voltage`/`power`**——
  三端（`Q`/`M`）与四端（`S` 开关）一律 `None`，`current` 仍是真值。原因见 §8.1 第 10 条。
- 电压源 `live` 里没有 `current`（`branch_currents()` 只解析 `i(@ref[...])`），这与
  `timeline` 里电压源**有** `current`（`_current_key()` 认 `i(v1)`）是两条不同的取数路径。

**时间序列 `timeline`**（`collect_timeline()`）：**只有 `tran` 返回，其它分析 `None`**。
`{t, dt, points, raw_points, t_stop, series}`，点数窗口 120~400（原始不足就原样），
降采样是**保峰**（min/max 包络，`_downsample_idx()`；末位下标一定是 `n-1`），
所有曲线共用同一组抽样下标所以不会错位；
取不到 `@dev[i]` 的器件不进 `series`（不填 0）。实测：raw 1023→200、5009→361、10020→200、
100030→201 点——**`points` 不是固定 400**（桶内 min/max 落在同一下标时该桶只贡献 1 点）；
对 RC 解析解的最大误差 5.2e-05 V、50% 到达时刻误差 0.02%。

**同一次运行里不跑两遍仿真**：`Circuit` 上新增 `remember_simulation()` / `recall_simulation()` /
`netlist_fingerprint()`（`ccl/core.py:598/624/638`），四个分析入口跑完就 `remember`，
`run_analysis()` 开跑前先 `recall`。判据是「分析类型 + 参数**数值**逐值相等 + 电路状态指纹一致」，
认不出的参数类型直接不复用；缓存挂在 **circuit 实例**上（模块级会在 `ThreadingHTTPServer`
下串台）。响应里新增 **`analysis.reused`** 说明走的是哪条路，`elapsed_ms` 仍是那次真仿真的耗时。
详见 `ccl/CONTRACT.md` §7。

**前端怎么用**（`main.js`）：`applyResult()` 里 `if (d.live && !d.timeline)` 才把 `live` 叠成静态快照
——有 `timeline` 时交给逐帧动画，两者**互斥**（同时画会「亮着又灭了」）；
`animSpec()` 在 `timeline` 为空/点数不足/没有 `series` 时返回 `{timeline: null}`，面板于是
**不建播放条**（`ac`/`op`/`dc` 就是这样）。点开关 → `toggleSwitch()` → 带 `switch_states` 重跑。

---

## 5. 关键数据结构

### 5.1 参数化工具侧

```python
@dataclass
class Param:
    name: str        # 网表里的参数名，如 "R1"
    label: str       # 报告里的人话标签，如 "反馈电阻 R1"
    kind: str        # R / C / L / freq / gain / db / volt / opamp / ratio
    lo: float; hi: float
    series: str | None = None   # 非 None → 参与 E 系列候选搜索（"E12"/"E24"/"E96"）

class Topology:
    id / name / summary
    params: list[Param]
    metrics_keys: list[str]        # 必须是 METRICS 的子集
    spec_overrides: dict[str, str] = {}   # 如 {"fc": "min"}
    design_keys: set[str] = set()         # 非指标型设计选择（order/kind/ripple_db）

    def render(self, p) -> str: ...            # 参数 → 网表（纯字符串拼接）
    def extract(self, res, p) -> dict: ...     # 波形 → 指标（Python 侧算）
    def design(self, spec) -> dict: ...        # 目标指标 → 初始参数（解析式）
    def sweep_center(self, p) -> float | None  # 该重点关心哪个频率（决定扫频卡）
    def build(self, params) -> Design          # 模板方法：clamp → render → 调频 → sim → extract
```

`build()` 是模板方法，子类**不要**覆盖：它先 `Param.clamp()` 限幅，再 `render()`，
然后按 `sweep_center()` 重写 `.ac` 卡片（RLC 且 Q>10 时按 Q 加密），最后 `sim.run()` + `extract()`。

```python
@dataclass
class Design:        # 一次候选的产物
    topology: str; params: dict; metrics: dict
    netlist: str     # 报告与 BOM 都从这里读，避免"两套数据打架"
    waves: dict; elapsed_ms: float; iteration: int

@dataclass
class Session:       # 一次请求的全状态（报告就是打印它）
    request / topology / spec / best / tries / rows / review / reason / caveat
    plan_source: str = "rule"      # "llm" | "rule"
    feasibility: object = None     # feasibility.Verdict（物理不可行时 .hard 非空）
    conflicts: list = []           # verify.Conflict（需求与设计对不上）
    mc: MCResult | None; error: str

@dataclass(frozen=True)
class Rule:
    mode: str   # eq | min | max
    tol: float
    kind: str   # rel（相对目标值） | abs（绝对单位）
    def band(self, target) -> (lo, hi)
```

`cost(rows) -> (bad_count, norm_err)` 是候选排序的唯一依据：先比不达标项数，
再比归一化总偏差（每项封顶 5.0，避免单个离谱指标压倒一切）。

`MCResult` 里 `runs` 只数**仿真成功**的样本，所以 `yield_pct = ok_runs / runs`；
20 次全失败时 `runs=0`、`yield_pct` 是 `nan`，报告改口说「设计点很可能贴在收敛边界上」而不是输出 0%。

### 5.2 CCL 侧

```python
# ccl/core.py
@dataclass
class Pin:        name: str; node: str          # node 在 __post_init__ 里 normalize

@dataclass
class Component:
    kind: str                       # "R"/"C"/"L"/"V"/"I"/"X"/"D"/"Q"/"M"/"S"（S=开关）
    ref: str                        # "R1"、"U1.OpAmp1"
    pins: list[Pin]                 # 有序，顺序即网表端子顺序
    value: float | str | None; model: str | None
    params: dict; meta: dict
    def value_tokens(self) -> list[str]

class Circuit:
    name / components / directives / expectations / ports
    add / find / nets / nodes / validate / use / use_ports / directive
    expect / verify / assert_ok / lint / with_ / sweep
    to_spice / ac / op / tran

# ccl/devices.py —— 开关（SPICE S 元件，M6）
class Switch(Device):
    KIND = "SW"; on_voltage / ron / roff / model
    pins = a, b, ctrl, "0"           # 控制量 = V(ctrl) − V(0)
    # 模型名由 (ron, roff, Vt) 派生：SW_0p01_1e09_2p5（Vt 必须进名字，见 ccl/CONTRACT.md §1）
    def switch_model_name(comp) / switch_model_card(comp)
    def apply_switch_states(circuit, {"SW1": "on"}) -> {"SW1": "source"|"vt"}

# ccl/solution.py —— 波形访问
class Solution:
    kind: "ac"|"op"|"tran"|"dc"; x: list[float]; waves: dict[str, Wave]
    netlist; elapsed_ms; warnings: list[str]
    # 直流扫描专用（无第二维时 second_* 为空）
    sweep_var / second_var: str
    sweep_values / second_values: list[float]
    v / db / phase / mag / f3db / peak_db / value_at / node_names / plot
    dc_curves(node) -> list[{"label","x","y"}]        # 切好段的曲线族，别按点号连线
    # 瞬态指标（测不到一律 None）
    steady_state(node, tail=0.1) / rise_time(node, low=0.1, high=0.9)
    fall_time(node, low=0.1, high=0.9) / overshoot_pct(node)
    settling_time(node, tol=0.02)

# ccl/assertions.py
@dataclass
class Expect:      kind, target, value, tol, mode, at, note
                   def needs_ac() / needs_op() / band()
@dataclass
class Report:      results: list[ExpectResult]; netlist; elapsed_ms
                   .passed / .failed / .table() / __str__()

# ccl/lint.py
@dataclass
class Issue:       level("error"|"warn"|"info"), title, detail, ref, code
```

`Circuit.validate()` 与 `Circuit.lint()` 都会**放行已声明的 `ports`**——
否则每个 block 单独检查时，自己的端口会被报成「悬空」，误报比漏报更伤信任。

---

## 6. IDE 前端结构

### 6.1 布局网格

```
#app  grid:
  ┌──────────────── titlebar (36px) ────────────────┐
  │ activity │ sidebar  │ main                      │
  │ 44px     │ 220px    │ 1fr                       │
  ├──────────────── statusbar (22px) ───────────────┤
```

`#main` 内部是**垂直**三段：`#editor-area : 1fr` / `#splitter-h : 6px` / `#panel : var(--panel-h)`。
`main.js` 拖动分隔条时只写一个 CSS 变量 `--panel-h`，`editor.layout()` 再重算尺寸。

断点（`style.css`）：`max-width:720px` 侧栏默认收起变浮层；`min-width:1000px` 侧栏 220px、面板更高；
`(orientation:landscape) and (max-height:420px)` 再压标题栏/活动栏/面板，保证 640×360 下编辑区仍有 ≥120px。

### 6.2 模块所有权与职责

| 文件 | 角色 | 契约要点 |
|---|---|---|
| `main.js` | **集成层**（唯一知道全局状态的地方） | 数据结构 `S = {tabs, activeTab, analysis, busy, lastResult, examples, blocks}`；`run()` / `applyResult()` / `exportReport()` / `aiCall()` / `setSidebar()` / 命令面板列表 |
| `editor.js` | 纯编辑器组件 | `createEditor(host, {value, onChange, onCursor, onRun})` → `getValue/setValue/focus/setDiagnostics/goToLine/layout/insertText/getCursor/undo/redo` |
| `panels.js` | 纯面板组件 | `createPanels({panelBody, panelTabs})` → `showWaveform/showProblems/showMetrics/showOperatingPoint/showNetlist/showReport/setActive/clear` |
| `commands.js` | 命令面板 | `openCommandPalette([{id,label,hint,run}])` / `close()` / `isOpen()` |
| `snippets.js` | 代码片段 | `BLOCK_SNIPPETS` / `DEVICE_SNIPPETS` / `requiredImports()` / `mergeSnippet()` |
| `style.css` | 全部样式 | `--bg/--fg/--accent` 等 token、网格、断点、`#cmdk` 命令面板、`#sidebar-resizer` 热区 |
| `index.html` | DOM 骨架 | **不要改结构**，只可按需加 class |

三条都实现了的「隐性契约」，改任何模块前先对照：

1. **组件之间不互相 import**。`panels.js` 要「跳到某一行」时**派发自定义事件**
   `ccl:goto-line`，由 `main.js` 统一接住并调 `editor.goToLine()`。这样编辑器换实现不用碰面板。
2. **`main.js` 是唯一碰网络的地方**（`fetch('/api/ccl/*')`）。两个组件都不知道 HTTP 存在。
3. **撤销栈自己维护**。手写 textarea 会破坏原生 undo，`editor.js` 自己维护快照栈并接管
   `Ctrl/Cmd+Z`、`Shift+Z`、`Ctrl+Y`（外加 `beforeinput` 的 `historyUndo/Redo`）——注释里写明了原因：
   合成的 `keydown` 事件驱动不了浏览器默认动作，「按一下 Ctrl+Z」在任何自动化验收里都会一动不动。

### 6.3 状态栏与诊断的闭环

```
后端 error + line  ──► main.js applyResult() ──► editor.setDiagnostics([{line, level, message}])
                                             └► panels.showProblems([{level, title, detail, ref, line}])
状态栏：stStatus / stAnalysis / stDevices / stCursor（行,列）/ stExpect（规格 n/m）/ stTime / stEngine
```

`stCursor` 由 `editor` 的 `onCursor(line, col)` 推送（1-based），`stExpect` 由 `/api/ccl/run`
返回的 `expect.passed/total/failed` 拼出。

### 6.4 电路图渲染（`web/ide/schematic.js`，1826 行）

**定位：代码是真相，图是投影。** 图由 `Circuit` 对象在每次运行后重新生成，不可编辑——
所以不存在「图和代码不一致」这个状态，也没有图形编辑器那套双向同步。
代码跑不通时 `applyResult()` 直接把电路图清空（`S.lastSchematic = ''`），
理由是：不能让人对着一张跟当前代码无关的图做判断。

**静态渲染那条路不碰 DOM**（纯字符串拼 SVG、样式内联），所以能在 Node 里直接自测；
但 M6 加的**动画层必须操作 DOM**（`applyLive` / `applyLiveFrame` / `createPlayer` /
`wireSwitchClicks`），这些函数开头都有 `typeof document === 'undefined'` 守卫，所以在 Node 里
import 仍然安全。**「对外只有两个导出」这句已过时**：当前是 **17 个命名导出 + `default`**，
清单与语义见本节末尾「工作态与瞬态动画层」。

#### 分层：按信号流角色建有向图，丢掉反馈边，再最长路径分层

1. 收集所有网络，`"0"` 之外的进 `ranked`；**GND 不参与分层**，单独做底部母线。
2. 每个器件由 `pinRoles()` 给出「左（输入/控制端）」与「右（输出/被控端）」：
   `X`: `inp/inn → out`；`Q`: `b → c/e`；`M`: `g → d/s/b`；`D`: `a → k`；
   两端件 `pin0 → pin1`；其它多端件 `pin0 → 其余`。
3. 按「左网 → 右网」加边，**强边先加**（`X`/`Q`/`M`/`D` 这类因果明确的器件），
   弱边（R/C/L/V/I）后加，而且**弱边若会成环就反向加**（`addEdge(v,u)`）——
   于是电源电阻不会把层级掰反；**强边若会成环就直接丢弃**（`reaches(v,u)` 做可达性检查）——
   这就是「反馈边丢弃」。运放负端因此不会被排到输出右边。
4. 在无环图上跑**最长路径分层**（`rank(n) = max(rank(pred)+1)`，memo + 栈保护防意外成环），
   同 rank 内按「后继的最小 rank」排序，源自然落在最左。

#### 每个网络独占一列（以及为什么不按 rank 算 x）

契约初稿写的是 `x(net) = marginL + rank * COL_GAP`。**字面实现是错的**：
同一 rank 上常有多个网络（例如两个互不相连的分支），按公式它们会拿到**同一个 x**，
两根竖线重叠成一根——视觉上等于「这两个网络连在一起」，**画出错误连接**。

实际实现改成：按 rank 从小到大遍历，组内按上面的顺序，**每个网络 `col += 1` 独占一列**，
`x = marginL + col * colGap`（`colGap = 128`）。层级有序 ⇒ 列序天然单调，信号仍然从左到右；
代价是图更宽、个别网络要拉长线跨越好几列（于是有了 `README` 里那条「无圆点交叉」的限制）。

#### 摆位与走线

- 一端接地的两端件强制**竖排**（`mode:"v"`，从信号网往下接到 GND 母线）；同一网络挂多个竖排件时
  横向错开 `spacing = max(20, min(40, 100/(k-1)))`，不叠在一起
- 横排两端件与三/四端器件按「行带」装箱：`packBox()` 与已有盒子相交就往下挪 8px，
  行高 `rowH = 42`、块高 `blockH = 100`
- **全正交走线**：每个网络一根垂直母线（`x` 固定，纵跨它所有引脚），每个引脚到母线一条水平短线
  （引线 `lead = 16` 起步），没有斜线
- **≥3 个引脚的网**在母线上打实心圆点（`r = 2.6`，坐标去重阈值 0.6px）；GND 母线同样处理
- GND 单独一条**底部母线**（`gndY`），右端挂手画的接地符号 + `GND` 文字
- 每个元件 `<g>` 带 `data-ref` / `data-kind` / `data-mode` / `data-axis` / `data-pins="网名@x,y …"`，
  每条线与母线都带 `data-net="<网名>"`（地线是 `data-net="0"`），圆点带 `data-junction="1"`
  —— 这些是给下一节的自测当钩子用的

#### 交互（`main.js`）

- 面板里 `width="100%"` 自适应缩放，复杂电路会缩得很小
- **点图 → 全屏**：`toggleBigSchem()` 按 `viewBox` **显式设** `width/height = viewBox × 1.4`
  （不设就会塌成 0 宽，见 §7.15），Esc 或点任意处关闭
- **导出 `.svg`**：`exportSvg()` 去掉 `width="100%"` / `height="auto"` 再存盘，
  样式已全部内联成 SVG 属性，独立文件打开也是对的

#### 工作态与瞬态动画层（M6，`schematic.js` + `style.css` + `panels.js`）

三条铁律：**视觉只由真仿真数据驱动**、**取不到就不显示（绝不沿用上一帧、绝不填 0）**、
**没有 `timeline` 就不演**（`ac`/`op`/`dc` 不建播放条）。

| 环节 | 数据 | 实现 |
|---|---|---|
| 静态快照 | 后端 `live` | `applyLive(svg, live)`：LED 染符号本身（`ledAt`）、电阻按功耗着色、其它器件按电流加光晕。**只在没有 `timeline` 时用** |
| 逐帧动画 | 后端 `timeline` | `createPlayer()` 的 rAF 主循环 → `frameState()` → `applyLiveFrame()`：**只改已存在节点的属性**（元素句柄首帧缓存），不重渲染、不拼字符串 |
| 导线流动 | `series` 的 `current` | 同一网络的多段线聚合成一条 `<path>`（`ensureFlow`），按 `abs(I)/本网络峰值` 切 6 档 class（`f1…f6`）；虚线跑动方向取自**电流的时间导数符号**，不承载极性 |
| 开关点击 | 用户输入（**不是**仿真数据） | `wireSwitchClicks()` → `onSwitch(ref, closed)` → `main.js` 的 `toggleSwitch()` → 带 `switch_states` **重跑仿真** |

几个容易踩的点（都真实发生过）：

- **开关点击必须独立于播放器**：早先绑在 `createPlayer` 里，于是工作点分析（没有播放条）下
  点开关毫无反应。现在 `panels.js` 在「没有播放条」的分支里也绑（`tests_api` 按源码断言钉住）。
- **静态快照必须自己点亮 LED**：早先 `applyLive` 里 `if (st.kind === 'light') continue;` 把发光
  全交给动画帧，而 op 分析没有动画帧 → 19 mA 流过、灯是灰的。
- **`live` 与 `timeline` 互斥**：`if (d.live && !d.timeline)` 才叠静态快照，否则「亮着又灭了」。
- **播放节奏不是物理时间倍率**：一整轮约 6 秒墙钟（`CYCLE_SEC`，按 0.25~4× 缩放），
  因为仿真时长常在微秒级；真实时刻看播放条上的读数（`t` 轴标签）。
- 播放条上的数据来源标签固定写 `数据：ngspice 瞬态仿真 · N 点 / X 时长`（N = `timeline.t` 长度）。

### 6.5 连接正确性怎么保证

**丑可以接受，接错不行。** 判据不看「像不像电路图」，而是**从 SVG 几何反推连通性**，
再与声明的网络对账（`tests_ui/schematic_selfcheck.mjs` 第 7 组，13 种构造拓扑）：

1. 取出所有带 `data-net` 的 `<line>`（走线）与所有 `data-pins`（引脚坐标）；
2. 两条线**只在共享端点**（端点距离 ≤ 0.6px）时算连通，**纯十字交叉不算连通**
   —— 这正是电路图的阅读规则，也是「无圆点交叉」能被安全容忍的原因；
3. 并查集把线段并成几何连通块；每个引脚只要离某条线段 ≤ 0.6px 就算「挂上了」，
   一条都没挂上的记「悬空」；
4. 断言三件事：① 无悬空引脚；② 同一连通块内不出现两个不同网络（没画出短路）；
   ③ 同一网络的所有引脚必在同一连通块（该连的都连上了）。

实测结果：

| 覆盖 | 数量 | 结果 |
|---|---|---|
| 构造拓扑（rc / cascade / divider / sallen_key / noninv_amp / devices / threepin / inductor / current_src / opamp_grounded_in / mos_bulk_tied_source / unknown_three_pin / parallel_pair） | 13 | 13/13 一致，自测 51 项全通过 |
| 真实后端示例（示例代码真跑一遍，把 `/api/ccl/run` 返回的 `circuit` 喂给渲染器） | 9 | 9/9 一致（**手工核对**，脚本已下线，不是自动化回归项） |
| 差分对（8 器件 / 7 网络，允许「乱」的结构） | 1 | 31 段走线 / 20 引脚 / 7 连通块，无悬空、无短路、无拆散；但有 7 处无圆点交叉 |

最后一行就是那条已知限制的实测依据：`n1` 的长线横穿了 `n2` 的母线，
**读者可能看错连接，但数据本身是对的**——因为那里的交点没有圆点，按规则就不是连接。

这套判据现在有两条独立通道在跑，谁都不能被悄悄删掉：

| 通道 | 位置 | 说明 |
|---|---|---|
| Node 自测（主回归） | `tests_ui/schematic_selfcheck.mjs`（51 项） | 在 Node 里直接 import `schematic.js`，覆盖 13 种构造拓扑 + 9 种符号（**开关 `S` 尚未纳入**）+ 空态/未知 kind 降级 |
| 前端契约（源码断言） | `tests_api/test_ui_contract.py` | 不跑浏览器：按源码断言 `wireSwitchClicks` 必须独立导出、`applyLive` 必须调用 `ledAt`、开关点击不得回到播放器内部 |
| 回归套件 | `tests_ccl/test_schematic.py`（7 个用例） | 从 Python 侧 `node --input-type=module` 批量渲染、把 SVG 拉回 Python 断言；没装 node 时整组 **Skip**（会写进汇总，不静默忽略） |

`test_schematic.py` 里还有一条**给反推器本身**的用例（`test_connectivity_analyzer_rules`）：
拿人工构造的「十字交叉」与「T 型接点」验证判据本身没错——
否则那三条断言可能因为「什么都算连通」而全部空过，那种测试比没有测试更危险。

---

## 7. 踩坑记录（这些都真实发生过）

按「症状 → 根因 → 现在的做法」写，方便以后对号入座。

### 7.1 ngspice batch 模式只有 `.meas` 会静默不跑

- **症状**：`ngspice -b deck.cir` 退出码 0，看起来成功了，可是什么数据都没有；
  输出里只有一句 `no .plot/.print lines in batch mode`。
- **根因**：batch 模式下只有 `.print`/`.plot`/`.control` 才会真正产生输出。
- **现在**：`sim.run()` 统一注入 `.control`（`set filetype=binary` → `run` → `write c.raw all` → `.endc`；
  二进制解析失败会回退 ASCII，见 §2.3），
  波形从 `c.raw` 读，不依赖任何 `.meas`；注入用 `deck.rpartition(".end")`。

### 7.2 网表表达式里 `pi` 不被识别

- **症状**：把 `C0 = A0/(2*pi*GBW)` 直接写进网表，仿真报错或算出荒谬结果。
- **根因**：ngspice 网表的数值字段不做表达式求值。
- **现在**：所有参数在 Python 侧算成纯数字再写入（`opamp_subckt()` 里的 `C0 = A0/(2π·GBW)` 就是算完的字面量）。

### 7.3 `.meas ... FIND vdb(x)` 解析不稳定

- **症状**：同一条 `.meas`，换个网表格式就取不到值；错误信息在 stdout 里而退出码仍是 0。
- **现在**：完全不用 `.meas`。ngspice 只负责算波形，指标在 Python 侧算：
  `-3dB` 用对数频率轴线性插值；二阶 `f0` 用相位过 ±90° 锚点；高通通带增益取 f0 上方 20~300 倍频段的**中位数**。

### 7.4 带限幅 B 源的行为级运放在 AC 分析里 gmin stepping 不收敛

- **症状**：为模拟输出饱和给运放加 B 源限幅，DC/TRAN 正常，一进 `.ac` 就 `no convergence` 或 `singular matrix`。
- **现在**：`opamp_subckt()` 是**纯线性**单极点模型（`Rin` + `E0` + `R0/C0` + `Rout`）；
  输出饱和在 Python 侧用「峰值是否超出电源轨」判断，不进网表。`devices.OpAmp` 的 docstring 里写死了「不要改回带限幅的版本」。

### 7.5 纯 DC 源在 AC 分析里激励为 0，分压必须显式加 `AC 1`

- **症状**：分压拓扑的 `v(out)` 在 AC 分析里恒为 0，指标全是 NaN。
- **根因**：`Vin in 0 DC 5` 只定义直流值，AC 小幅度默认 0。
- **现在**：源写成 `Vin in 0 DC 5 AC 1`，`extract()` 用 `|v(out)| × Vin` 还原真实输出。
  CCL 侧同理：`voltage_source.value_tokens()` 固定输出 `DC <值> AC <值>` 两个都写。

### 7.6 NDJSON 流式响应：没有 Content-Length 就必须 `Connection: close`

- **症状**：浏览器一直转圈到超时；数据其实早就发完了。
- **根因**：`protocol_version = "HTTP/1.1"` 默认 keep-alive，而响应既没有 `Content-Length` 也没有 chunked 结束标记。
- **现在**：`_design()` 里显式 `self.close_connection = True` + `send_header("Connection", "close")`；
  `write()` 吞掉 `BrokenPipeError/ConnectionResetError`（用户点停止不是错误）。

### 7.7 `.subckt` 内部元件会混进 BOM

- **症状**：BOM 里冒出 `Rin 10Meg`、`C0 795uF`、`R0 1Ω`。
- **现在**：`bom()` 维护 `in_subckt` 计数器（`.subckt` +1 / `.ends` −1），内部行跳过；
  `.`/`*`/`+` 开头也跳过；`V` 源不算物料。

### 7.8 容差语义 bug：把相对容差当绝对容差用（本项目最贵的一次 bug）

- **症状**：1kHz 目标、10% 容差的 Sallen-Key，蒙特卡洛成品率被算成 **50%**（真实 95%+）；
  同时 `gain_db` 的 `±0.6dB` 变成了 `±12dB`。
- **根因**：`SPEC_RULE` 里的容差一律按**相对值**存（0.10 = 10%），但 `min`/`max` 模式按**绝对值**比较：
  「1000Hz、10%」被解释成 `actual >= 1000 − 0.10 = 999.9Hz`，990.9Hz 判不合格。
- **现在**：`Rule` 显式带 `kind ∈ {rel, abs}`，比较统一走允许区间：
  `d = |target|·tol`(rel) 或 `d = tol`(abs)，`eq → [t−d, t+d]`、`min → [t−d, +∞)`、`max → (−∞, t+d]`。
  报告把区间直接印出来（`≥ 900kHz`、`0.9kHz ~ 1.1kHz`）。
  **CCL 侧犯过同一个错**：`assertions.Expect.band()` 也用同一套 `rel/abs` 判别（`_ABS_TOL = {gain_db, peak_db}`）。

### 7.9 另外两个顺手记下的坑

- **NaN 不是合法 JSON**：`json.dumps(float('nan'))` 会写出裸 `NaN`，浏览器 `JSON.parse` 直接抛异常、
  整条结果丢掉。`web/server.py`/`ccl_api.py` 的 `_num()` 统一把 NaN/Inf 转 `null`，前端按 `null` 显示 `—`。
- **指标 key 不在词表里等于没算**：`judge.check()` 遇到不在 `METRICS` 里的 key 直接 `continue`，
  新拓扑忘了登记指标时仿真照跑、报告少一行，**而且不报错**——静默漏判比报错危险。

### 7.10 地节点在 SPICE 输出里根本没有波形

- **症状**：CCL 的工作点检查里，凡是接地的器件（分压下臂、`C` 接地端、`D` 阴极接地的整流电路）
  **全部被静默跳过**，检查结果看起来「没问题」。
- **根因**：`0` 是参考点，ngspice 的输出里没有 `v(0)` 这条波形。
  实测现在 `Solution.value_at("0", 0)` 直接抛 `NodeError`（`仿真结果里没有节点 '0'。可用节点：in, out, i(v1)`）；
  早前的写法用 `try/except` 把它吞成 `None`，于是 `_volt()` 返回 `None`，调用方 `continue`。
- **现在**：`ccl/lint.py::_volt()` 第一行就特判地节点，直接返回 `0.0`：

  ```python
  if n in ("0", "") or n.upper() in ("GND", "GROUND"):
      return 0.0
  ```

  写任何基于 `Solution` 的新检查时都要记住这一条。

### 7.11 PULSE / SIN 的空格写法会撞 compile 的「token 不得含空白」保护

- **症状**：把 `PULSE(0 5 0 1n 1n 1m 2m)` 当成一个 token 返回，`compile` 直接抛
  `CCLNetlistError: [器件 R1] 值字段 'PULSE(0 5 0 1n 1n 1m 2m)' 内部含空白，会把网表行拆错列`
  （本机复现过）。
- **根因**：`compile._value_tokens()` 有一道保护——值 token 内不得含空白，防的是「拆分错列」这类最难查的 bug。
- **现在**：`PulseSource/SinSource.value_tokens()` 统一输出**逗号**形式：
  `PULSE(0,5,0,0.000000001,0.000000001,0.001,0.002)`、`SIN(0,1,1000,0,0)`。
  ngspice-47 实测空格与逗号都接受，所以**不要为了好看改回空格**——那会撞上保护，或者更糟：让保护被削弱。

### 7.12 前端把后端已经算好的 dB 又转了一次

- **症状**：AC 波形整张图压成一根竖线；游标读到 `−600dB`。
- **根因**：后端 `traces[n].y` 已经是 dB，前端又套了一次 `20*log10(|y|)`。
  `0dB` 被当成线性幅度 0（下限钳到 1e-30）→ `20·log10(1e-30) = −600dB`。
- **现在**：`panels.js` 的 `toY()` 先看 `unit`：

  ```js
  const toY = (tr, isAC) => {
    if (!isAC) return tr.y.slice();
    if ((tr.unit || "").toLowerCase() === "db") return tr.y.slice();   // ← 已经是 dB，不再转
    return tr.y.map(v => 20 * Math.log10(Math.max(Math.abs(v), 1e-30)));
  };
  ```

  约定记在 `web/ide/CONTRACT.md` 的数据形状里：**`unit` 就是单位声明，前端按它决定要不要换算**。

### 7.13 沙箱导入白名单：新增 `ccl.blocks` 要同步白名单，但**不能**放 `ccl.ai`

- **背景**：M5 加了 `ccl/blocks.py`，而 AI 生成的代码与 IDE 里贴的代码都要能 `from ccl.blocks import BLOCKS`。
- **现在**：`ccl/ai/sandbox.py` 的 `ALLOWED_IMPORTS = {"ccl", "ccl.blocks", "math"}`。
  **刻意不含 `ccl.ai`**——否则生成的代码可以反过来调用模型（模型调模型，白烧 token 且不可控）。
- **两层都要过，实测确认过**：
  - 静态预检 `check_source()` 只按**顶层包名**判断，所以 `import ccl.ai` 在预检这层是**放行的**
    （`root = name.split('.')[0] == "ccl"`）；
  - 真正拦住它的是 exec 期的 import 钩子，它按**完整模块名**比对：
    实测 `run_source('from ccl.ai import generate …')` → `ImportError: 沙箱白名单里没有模块 'ccl.ai'`。
  - 结论：**改白名单时两处都要想清楚**，别以为改了 AST 白名单就完事。

### 7.14 子智能体报 failed，但文件其实已经交付了

- **症状**：并行开发时，某个 agent 回报「失败/超时」，可它的文件已经写好并且自测通过。
- **根因**：状态来自子进程的退出码或它自己的自述，而不是产物。
- **现在**：验收看**产物**——文件 `mtime`、`wc -l`、`node --check`、真跑一次。
  这条不是代码 bug，是本项目的协作纪律（`web/ide/CONTRACT.md` 的验收清单就是按"能跑"写的，
  不是按"它说它做完了"写的）。

### 7.15 SVG 只带 `viewBox`、没有固有尺寸，放进浮层会塌成 0 宽

- **症状**：面板里电路图正常，一点「全屏」图就没了——浮层是空的，只有一行提示文字。
- **根因**：`renderSchematic()` 输出的根元素是 `width="100%" height="auto" viewBox="…"`。
  在内联面板里这样最省事（跟着容器缩放），但放进一个 `display:flex` 居中的浮层时，
  「100%」的参照就变成了收缩到内容的盒子，`height:auto` 又没有比例基准 → **算出来的宽度是 0**。
- **现在**：`main.js::toggleBigSchem()` 从 `viewBox` 读出 `W/H`，**显式设**
  `width = round(W*1.4)`、`height = round(H*1.4)`，再 `removeAttribute('style')`；
  导出时反过来——`exportSvg()` 把 `width="100%"`、`height="auto"` 去掉，让看图器按 `viewBox` 自适应。
  两处方向相反，都写在代码注释里。

### 7.16 直流扫描**降序**时 `value_at` 假设升序轴，所有查询返回端点值

- **症状**：`.dc V1 5 -5 -1` 这种降序扫描，x 是 `[5,4,…,−5]`，图上曲线是对的，
  但十字线读数永远是同一个数：`value_at(5)` / `value_at(0)` / `value_at(−5)` 全都返回**第一个点**的值
  （2.5V）。
- **根因**：`Solution.value_at()` 背后的插值按「`xs` 升序」写的（对比 `x` 落在哪一段、
  段内线性/loglog 插值）。降序轴下所有 `x` 都「不在这段里」，函数退化成返回端点值——
  **不报错，静默给错数**，这类 bug 最贵。
- **现在**：`value_at()` 先判轴方向——`xs[0] > xs[-1]` 时把 `xs`/`ys` **一起反转**再插值
  （`ccl/solution.py` 的注释写明「直流扫描允许降序，而插值函数假设 x 升序；
  不处理的话任何查询都会退化成端点值（实测：5 / 0 / -5 全返回 2.5）」）；
  `dc_curves()` 的「扫描量回头处切段」也用镜像判据（降序看 `xs[i] >= xs[i-1]`）。
  回归用例：`tests_ccl/test_sim.py::test_descending_sweep_value_at_is_correct`
  （1k/1k 分压、`c.dc("V1", 5, -5, -1)`，断言 11 点且确实是降序，
  再逐点核对 `x ∈ {5, 2.5, 0, −2.5, −5}` 时 `value_at("o", x) = 0.5·x`，容差 0.005）。

### 7.17 「输出撞电源轨」这条检查**从未执行过**（`GND` 没导入）+ 地把不是下轨

- **症状**：`ccl.ai.review.check_rails()` 只要真的拿到一个 `op` 解就抛 `NameError: name 'GND' is not defined`
  → 整个 `review()` 崩掉。而调用它的地方吞异常/只传 `solution=None`，所以**从来没有一次运行走到过这条检查**。
  文档与 README 一直把「撞轨」列在「波形形状检查」里，实际上它一次也没跑过。
- **根因**：`check_rails()` 用了 `GND` 但文件顶部只 `from ..lint import ...`，没有 `from ..core import GND`；
  测试只用 `solution=None` 调用（提前 `return []`），覆盖不到真正用到 `GND` 的那个分支。
- **第二个 bug（同一个函数里）**：rails 只从「一端接地的电压源」收集，于是**单电源**电路（只有 +12V）
  得到 `rails=[12]`、`lo=12`，任何低于 12V 的节点都被判「低于下轨」——实测普通 12V 分压器（输出 6V）
  被报「输出撞电源轨 [12,12]V」。地必须是**下轨**。
- **现在**：`ccl/ai/review.py:46` 补上 `from ..core import GND`；`:73` 把 rails 初值改成 `[0.0]`（地 = 下轨），
  再并入接地电压源的 DC 值。对账实测：
  单电源 12V、10k/10k 分压（`out=6.0V`）→ `check_rails()` 返回 `[]`、`review()` 正常返回；
  同一个电路从 `out` 灌 2 mA（`out=16.0V`）→ 返回 `[('error','输出撞电源轨', …超出电源轨 [0, 12]V…)]`。
  **检查在跑，而且只在真撞轨时报。**

### 7.18 同一个 `[]` 表示三种相反的事实（最贵的一类：拿不到证据就判无罪）

- **症状**：`spec_check.check_targets()` 用空列表同时表示「需求里没抽到目标」「全部达标」「**测不到**」。
  调用方一律读成「没问题」，于是：沙箱被污染导致 `ac()` 返回 `None` → `[]` → 产品宣称成功；
  退化电路没有输出节点 → `[]` → 宣称成功；核对器自己抛异常 → `[]` → 宣称成功。
  真模型实测：要求「截止 1kHz」交了实测 995 Hz 以外的错电路、要求「输出 5V」交了 5.45 V，
  都是 `ok=True` + `warnings=[]`。
- **同类**：`_diagnose()` 当时只跑 lint + `c.expect`，**一次需求对账都不做** →
  `fix(code, request="截止频率必须改成10kHz")` 返回 `ok=True`、**模型调用 0 次**、界面说「没发现问题」，
  代码一字未动、实测仍 995 Hz。
- **现在**：
  - `spec_check.py:292` 新增 `Unmeasurable`；`:305` 的 `check_targets_strict()` 在
    「solution 为空 / 读不出节点 / 没有任何节点 / 没有可测输出节点 / 电压类目标缺输入电压」时**抛异常**；
    `:329` 的旧 `check_targets()` 只为兼容保留（仍返回 `[]`）；
  - `generate.py` 把 `Unmeasurable` 当**失败**（`_check_failed=True` → `ok=False` 进修复循环）；
  - `generate.py:607` 的 `_diagnose(circuit, solution, source, request)` 现在**会核需求**，
    对账做不成也按「有问题」处理；`:588` 的 `_model_claims_impossible()` 把「模型自己在注释里说物理上不可能」
    判为未交付。
  - 回归钉：`tests_ccl/test_ai_gates.py`（本轮新增的两个文件之一，另一个是 `tests_ccl/test_regressions.py`）。

---

## 8. 目前仍未修的问题（逐条实测核对）

这一节是**现在**的行为，不是历史记录。三块分工如下：

- **§8.1**：仍然成立的问题，每条都留了位置与复现口径（对账时逐条重跑过）；
- **§8.2**：已经修掉的，附「当初的现象 → 修法 → 现在的证据」，这是这份文档最值钱的部分；
- **§8.3**：分析方法本身的边界，**不是 bug**，别再当 bug 修。

> 判定纪律：写「已修」必须能指出代码位置或一条能复现的命令；拿不准的一律留在 §8.1。

### 8.1 仍然成立

本轮（2026-11-03）逐条重跑过一遍。**只有第 8 条是例外**：它已经修了，
但为了不打断别处的「§8.1 第 8 条」交叉引用，编号与划线都留在原位，证据在 §8.2。
其余 12 条都重新核对过代码位置，仍然成立。

| # | 现象 | 位置 | 复现 / 说明 |
|---|---|---|---|
| 1 | 手写 CCL 代码用默认 `c.ac(..., points=200)` 时，**高 Q 电路的 Q/带宽测不准** | `ccl/solution.py` 的 `f3db/peak_db`、`assertions._measure('bw')` 依赖扫频采样点；`Circuit.ac()` 的 `points` 默认仍是 200（拓扑库侧已不封顶，见 §8.2） | Q≈316 的 RLC（L=1mH/C=10nF/R=1Ω）在 200 点/十倍频下 `bw=450Hz`（理论 159Hz），`points=4000` 后 164Hz；对账复测（扫频 10Hz~1MHz）：200 点 → `549Hz`、4000 点 → `160.8Hz`，数字随扫频范围变、现象不变。**这条只剩「你自己写代码时的默认点数」这半边**——拓扑库那半边已经真修掉了（原来封顶 4000 本身就是个 bug，见 §8.2） |
| 2 | 分压拓扑的 Bode 图只有两个点 | `copilot/topologies/misc.py:37` 的 `Divider.render()` 仍是写死的 `.ac dec 1 1 10` | 分压不需要频响，但 IDE/前端的波形面板仍会画它。对账复核：一行没变 |
| 3 | 规则模式（无 Key）**可能归错因** | `agent.parse_rules()` + `_rule_review()` | 结论（达标/不达标）来自仿真，可信；「为什么不达标」那句话是模板文字，不一定点对指标。配了 Key 时 `caveat` 会直说「物理上做不到」 |
| 4 | 搜索只在初值的 ±1 倍频程内活动 | `agent._candidates()` / `_neighborhood()` | `design()` 解析式写错时搜索**兜不回来**（历史上反相放大 10 倍就是这么错的）。缓解：每个 `design()` 都有物理核对用例 |
| 5 | 运放是行为级单极点模型 | `copilot.topologies.opamp_subckt()` / `ccl/devices.OpAmp` | 只有 A0 与 GBW 两个自由度：无噪声、无压摆率、无输出限幅、CMRR 理想。相位裕度/带宽可信，失真/噪声/削顶不可信 |
| 6 | 单用户、无鉴权、会话在内存 | `web/server.py` | 进程重启后 `/api/report/<id>`、`/api/ccl/report/<id>` 失效；默认只监听 `127.0.0.1` |
| 7 | **开关（SPICE `S`）在 `.op` 下取不到支路电流** | `copilot/sim.py` 的 `_SAVE_PARAM` / ngspice | 实测 `.op` 下 `@sw1[i]` 恒为 **1.94e-13 A**，`.tran` 下才是真值 **19.410 mA**。所以 `live.items.sw1.current` 在 op 分析里是 `0.0` —— **取不到，不是没电流**。瞬态动画不受影响。注意这条只在「本来该有大电流」时看得出来：断开态（`roff=1e9`）op 与 tran 都测到真实漏电 **5e-09 A** |
| 8 | ~~**`tran` 的 `live` 是 `t=0` 快照**~~ → **已修** | `web/ccl_api.py::collect_live()` + `copilot/sim.py::branch_currents(at_index=)` | 现在取**末点**且电流与电压同一时刻（`t_pick = x[-1]`、`at_index = len(xs)-1`），`live` 另带 `t` 字段。证据见 §8.2。**编号保留**是为了不打断别处的「§8.1 第 N 条」交叉引用 |
| 9 | **导线流动的「方向」不承载物理极性** | `web/ide/schematic.js::flowAt()` | 方向取自该网络电流的**时间导数符号**（`next − prev`），稳态时固定正向。只有强弱（`abs(I)` 相对该网络峰值）是数据；不同网络的粗细也不能互相比较 |
| 10 | **`live` 的 `voltage` 丢了极性** | `web/ccl_api.py::collect_live()` 的 `abs(float(volt))` | 想判断正负请用节点电压（`analysis.op` / `traces`），不要读 `live`。**并且三端及以上器件根本不给电压/功耗**：`Q`/`M`（3~4 引脚）与 `S`（4 引脚）的 `voltage` 与 `power` 恒为 `null`，`current` 仍是真值——取「前两个引脚之差」实测 BJT 得 `Vcb=1.008V`（真 `Vce=1.706V`）、MOS 功耗差 **20 倍**，宁可不给也不给错的 |
| 11 | **AI 生成用不上开关** | `ccl/ai/prompts.py:35` 的 `API_CARD` 里没有 `c.SW(...)` | 能力在库里做了，但提示词没同步 → AI 生成不出带开关的电路（正是 §9.2 第 5 步警告的那种「能力做了却用不上」）。对账复核：`grep -n "SW\|开关" ccl/ai/prompts.py` **零命中**，这条仍然成立。修法：把 `c.SW` 加进 `API_CARD` |
| 12 | **开关符号没有前端自测** | `tests_ui/schematic_selfcheck.mjs` | 对账实测：`node tests_ui/schematic_selfcheck.mjs` → **51 项全部通过**，而文件里 `S` / `SW` / `switch` **零命中**——仍然只覆盖原来那 9 种符号。`S` 的回归目前只在 `tests_api/test_ui_contract.py`（按源码断言），几何/交互没有自动化覆盖 |
| 13 | **「落地前必须确认」清单不覆盖开关，CCL 报告里也没有这一节** | `copilot/report.py:209` 的 `_landing_section()` 只服务参数化工具（13 个拓扑，没有开关类结构）；`ccl/report.py` 的 6 个章节（概况/器件清单/SPICE 网表/实测结果/电路检查/规格核对）里没有它 | 两条都核对过：清单现有 6 条（运放行为级模型 / 电容介质 / 分压负载 / 寄生布局 / 温度老化 / 不做范围）与代码现状**一致**（`opamp_subckt()` 仍是 `Rin/E0/R0/C0/Rout`，只有 A0/GBW/Rout）；但**用开关搭出来的电路从 IDE 导出报告时，不会得到「开关没有开关速度/弹跳/寿命、断开态有漏电」这类提醒** |

（原来这张表里还有一条「自定义器件模型不可用」——它已经修掉了，挪到 §8.2。）

### 8.2 已经修掉的

每条写清**当初的现象 → 修法 → 现在的证据**，证据都能用一条命令复现：

| 原条目 | 现在的实测结果 | 证据（代码 / 命令） |
|---|---|---|
| 「把12V分压到3.3V」解析成 `vout=6V` 且**报达标** | `spec={'vout': 3.3}`，实测 3.3202V，✅ | `agent.parse_rules()` 里三种句式逐个试 + 兜底取「最后一个电压」；另有 `copilot/verify.py` 语义对账闸门独立复核原文与 spec |
| 「10 倍反相放大器」必然未达标（`R2=(gain−1)R1`） | `design({'gain_lin':10})` → `R2=10000`，实测 9.9989 倍，✅ | `OpampInverting.design()` 已改为 `R2 = \|g\|·R1`，注释里写明了旧错 |
| 「阻带衰减 60dB」被当成 `gain_db=60` | `spec={'fc':1000,'atten_db':60}`，`atten_db` 实测 20.04dB → 正确判**未达标** | `parse_rules()` 里 `衰减/抑制/挡掉/滤除/压制 … dB` 抢在 `gdb` 之前识别，并把 `gdb`/`gm` 清空 |
| BOM 里多一个 `Rload 1MΩ` | BOM 只有 `R1 976Ω / R2 8.87kΩ / X1 运放` | `report.SIM_ONLY_REFS = {"rload","rlod","r_sim","rsim"}` |
| `resolve_tol(tol={"R":"0.1%"})` 抛 `ValueError` | 返回 `{'R': 0.001, 'C': 0.05, …}` | `tolerance.resolve_tol()` 改走 `_as_fraction(v)` |
| `fc ≲ 5Hz` 的合法需求被静默算错（「1Hz 低通」报 1.729Hz） | 「做一个1Hz的RC低通滤波器」→ `fc=0.9947Hz`，✅ | `topologies.ac_sweep(center)` 按 `sweep_center()` 生成扫频卡（实测网表 `.ac dec 200 0.0001 9947.18`），不再固定 1Hz~100MHz |
| RLC 高 Q 时 Q 不可信（Q≈316 报 91.3） | 拓扑库侧**已修到位**：Q=200/500/1000/2000 实测 **199.999 / 499.998 / 999.995 / 1999.988**、Q≈316（1mH/10nF/1Ω）实测 **316.226**（\|误差\| ≤0.001%）；手写代码仍要自己给 `points` | 旧实现 `ppd = min(max(200, 70·Q), 4000)` **封顶本身就是 bug**：f0=100kHz 时步长 57.6Hz，而 Q=2000 的 −3dB 带宽只有 50Hz → 实测 Q=2000 测成 **2306.8（+15.3%，好设计被误杀）**、Q=5000 测成 4423.9（−11.5%，不合格却判达标）。上限放到 **400k**（`copilot/topologies/base.py:264`），代价要如实说：Q=2000 那一次仿真 **6.9 s**（Q=200 是 0.9 s）。另有 `tests/test_physics.py::test_rlc_high_q_is_accurate`（Q≈316）持续钉住 |
| 自定义器件模型不可用（D/Q/M 带 `model_params` 时 ngspice 报 `unknown parameter`） | 三种自定义模型都能跑通 | 现象：`model_params` 被塞进 `comp.params`，`compile` 又把 `params` 作为 `key=value` 追加到**器件实例行**，而 ngspice 只认 `.model` 卡里的参数。修法：`ccl/devices.py::_Modeled` 单独存 `self.model_params`（只用于生成 `.model` 卡），`comp.params` 留空，`clone()` 里同步拷贝 |
| **`tran` 的 `live` 是 `t=0` 快照**（原 §8.1 第 8 条） | 现在取**末点**、电流与电压**同刻**。同一份 RC（0→5V 阶跃、τ=100µs、`tran(1e-6, 1e-3)`）实测：`live.t = 0.001`、`live.items.r1.current = 2.27e-07`（修之前是 `0.0`）；`live.items.c1.voltage = 4.999773` | `web/ccl_api.py::collect_live()` 里 `t_pick = x[-1]` + `branch_currents(..., at_index=len(xs)-1)`；`copilot/sim.py::branch_currents()` 新增 `at_index` 参数（`-1` = 末点）。另修的配套问题：电压已取末点而电流仍取 `ys[0]` 时，功耗是 `\|I(t=0)·V(t末点)\|`（实测 PULSE 电路报 R1 `0A/0W`，真值 11.4mA/28mW） |
| 含运放（`.subckt`）的电路在 op/tran/dc 下 **100% 崩** | 正常跑通。原因不是电路，是 `save`：`_save_devices()` 把 `.subckt OPA` 内部器件的 `@r0[i]`/`@c0[i]` 也 save 了，ngspice 报 `vector @c0[i] is not available` → `write` 失败 → 整次仿真失败。修法：跳过 `.subckt`~`.ends` 之间的器件（`copilot/sim.py:231`）；另加降级——save 失败就丢掉 save 重试一次，电路结果仍然正确、只是没有器件级数据（`copilot/sim.py::run()`）。原来项目自带运放拓扑只做 `.ac`（不下发 save），所以测试全绿没抓到 | `copilot/sim.py::_save_devices()` 的 `in_subckt` 状态机 + `run()` 里的 `build("")` 重试分支 |
| **「输出撞电源轨」检查从未执行过**（`GND` 没导入）+ 地把不是下轨 | `check_rails()` 现在跑得起来，且只在真撞轨时报：单电源 12V、10k/10k 分压（`out=6.0V`）→ `[]`；同一电路从 `out` 灌 2 mA（`out=16.0V`）→ `[('error','输出撞电源轨',…超出电源轨 [0, 12]V…)]` | 见 §7.17。`ccl/ai/review.py:46` 补 `from ..core import GND`（原来只要拿到 `op` 解就 `NameError`，整条检查从未跑到过）；`:73` rails 初值 `[0.0]`（地 = 下轨），再并入接地电压源的 DC 值 |
| `spec_check` 用同一个 `[]` 表示「没抽到目标 / 全达标 / **测不到**」 | 测不到一律抛 `Unmeasurable`：`check_targets_strict()` 在「solution 为空 / 读不出节点 / 没有任何节点 / 没有可测输出节点 / 电压类目标缺输入电压」时抛异常，`generate()` 把它当**失败**；旧签名 `check_targets()` 只为兼容保留 | `ccl/ai/spec_check.py:292`（异常）`:305`（严格版）`:329`（兼容版）；`ccl/ai/generate.py` 的 `_check_failed` 分支。见 §7.18 |
| 模型在注释里说「物理上不可能」，工具照样报成功 | 现在按**未交付**处理：`ok=False`，并把模型原话写进 `warnings` | `ccl/ai/generate.py:588 _model_claims_impossible()`（标记词表 + 只认 `#` 开头的行），`:533` 处调用 |
| `fix()` 有 0 次需求对账（模型调用 0 次却说「没发现问题」） | `_diagnose(circuit, solution, source, request)` 现在会核需求；对账做不成也按「有问题」处理 | `ccl/ai/generate.py:607`；回归在 `tests_ccl/test_ai_gates.py` |
| `generate()` 不跑 lint：`R=1nΩ` / `C=100kF` / `R=1TΩ` 交付 `ok=True` 零告警 | 现在 `circuit.lint(None)` 出 `error` 直接判失败（`stage="lint"`），进修复循环 | `ccl/ai/generate.py:297-309` |
| 生成代码能一行改掉全局类（`Circuit.ac = lambda…`），污染整个常驻进程 | 两道防线：AST 禁止 `对象.属性 = …`；运行时 `_snapshot_guarded()`/`_restore_if_polluted()` 校验并**回滚** `Circuit` 的 9 个关键方法，发现被改写就判失败 | `ccl/ai/sandbox.py:151-165`（`_check_assign_targets`）、`:348-380`（守护/回滚）、`:427` 处使用 |
| 成品率系统性虚高（`DEFAULT_TOL["Vin"]=0.0`，把电源当绝对理想） | 12V→3.3V 分压器成品率 **98.3% → 55.0%**（诚实值）。`Vin` 改为 ±1%，并在 `tol_summary()` 里**明确列出**「输入电压 ±1%」，不再静默假设 | `copilot/tolerance.py:36-41`；同一提交里 `test_yield_drops_as_design_approaches_spec_boundary` 加了「钉死 Vin 时必须明显更高（≥+5 点）」的加固断言 |
| 「电阻 1% 电容 5%」里的 1% 被挂到电容头上 → 成品率虚高 20~25 点 | `tol_from_text("电阻 1% 电容 5%")` → `{'R':0.01,'C':0.05}`（**每个百分数只配给一个元件**，词在数字前优先） | `copilot/tolerance.py:130-165` |
| 纯 RC 电路的报告也印「运放 GBW ±20% · 开环增益 ±50%」 | `tol_summary(sections)` 按电路实际器件族过滤（`Vin` 永远列出，因为它不是器件） | `copilot/tolerance.py:260-275` |
| 导出报告三处与屏幕不一致 | ① 网表带上分析卡（`.ac/.tran/.op` 不再漏）；② `tran` 报末值/峰值/谷值、`dc` 报起点/末点，只有 `ac` 才用 `f3db/peak_db`（以前 5V 直流节点写成「峰值 13.98 dB」、0V 写成「−300 dB」）；③ 认 `switch_states`，与界面走同一条覆盖路径 | `ccl/report.py:111-122`（分析卡）、`:148-170`（tran/dc 分支）；`web/ccl_api.py::build_report(code, analysis, switch_states=)` |
| 电路名带中文 → 报告下载**直接断连** | 改 RFC 5987：`Content-Disposition: attachment; filename="<ascii 兜底>"; filename*=UTF-8''<percent-encoded>`；实测中文名下载成功 | `web/server.py:318-323` |

对账实测（2026-11-03 本轮，原样抄终端输出）：`python3 tests/run_all.py` →
`共 133 项：通过 133 · 已知缺陷 0 · 失败 0`（物理核对表 121 条全吻合，耗时 58.4 s）；
`known_bug` 标记数为 **0**——原来靠标记钉住的那批用例现在全部真通过（`e2e_bug` 组仍然保留，
断言是严格的那一版）。CCL 侧 `python3 tests_ccl/run_all.py` → `共 225 项：通过 225 · 失败 0 · 跳过 0 · 已知缺陷 0`（54.8 s），
其中 `tests_ccl/test_regressions.py`、`tests_ccl/test_ai_gates.py` 是本轮新增的两个回归钉
（用例数会随轮次继续增长，别把数字当契约）。

### 8.3 分析方法本身的边界（不是 bug，别再当 bug 修）

这几条是**刻意的口径**，改掉它们会让指标开始说谎（README 的「已知限制」里有同样的条目）：

| 边界 | 为什么这么定 | 实测依据 |
|---|---|---|
| 多周期脉冲串测不出瞬态指标（`rise_time / overshoot_pct / settling_time` → `None`） | 判据要求「末段安静或存在足够长的平台」，目的是**不把纯正弦误报成阶跃** | τ=1ms、脉冲宽 1ms / 周期 2ms 的 RC 方波四指标全 `None`。对账复测补充：**只把脉宽拉长不够**——τ=100µs 的 RC、脉宽 1ms（10τ）/ 周期 10ms / `t_stop=5ms` 仍全 `None`（末段已回低电平）；改成单次阶跃（`pw ≥ t_stop`）或把 `t_stop` 收进第一个脉冲内，才恢复读数（`rise_time=219.7µs`、`steady_state=5.000V`） |
| `t_stop ≥ 5τ` 才量得准 | 高电平取自**末段均值**，跑得太短量的只是「这段爬了多少」 | 同一个 τ=100µs 的 RC：`t_stop=100µs` → `rise_time=74.0µs`、`steady_state=3.067V`；`t_stop=5ms` → `219.7µs` / `5.000V` |
| `steady_state` 是末 10% 窗口均值，不是末点 | 末点会被最后一小步的抖动带偏；整条均值又会把上升段算进去 | 5V 阶跃 `steady_state=5.0000V`（末点通常差最后一个时间步的量级） |
| 高 Q 的 `overshoot_pct` 要求窗口足够长 | 分母是 `steady_state`，窗口落在振铃里会**同时低估稳态与超调** | RLC（L=10mH/C=1µF/R=20Ω，Q=5）：`t_stop=5ms` → 72.56%（稳态 5.0106V）；`t_stop=20ms` → 72.93%（稳态 5.0000V），理论 72.92% |

最后一行踩过一次真事故：曾把「Q=5 实测 70.29%」当成「运放 A0/GBW 把实际 Q 拉低了」，
差点把一条正确的理论对照删掉——真正的原因是测量窗口。回归用例
`test_high_q_overshoot_needs_long_enough_window` 现在钉住这个陷阱。

---

## 9. 扩展指南

### 9.1 新增一个拓扑（参数化工具，五步）

**第 1 步：写在 `copilot/topologies/` 包里**（按类别放进 `filters.py` / `amplifiers.py` / `misc.py`
之一，别硬塞进 `base.py`——那是基类与通用数值工具），继承 `Topology`：

```python
class MyFilter(Topology):
    id = "my_filter"
    name = "我的滤波器"
    summary = "一句话说明这个结构是什么、什么时候用。"   # 会喂给 LLM 选型，请写清楚
    params = [
        Param("R", "电阻 R", "R", 10.0, 1e6, series="E96"),   # series 非 None 才参与标称值搜索
        Param("C", "电容 C", "C", 1e-12, 1e-3, series="E12"),
    ]
    metrics_keys = ["fc", "gain_db"]        # 必须是 METRICS 的子集
    spec_overrides = {"fc": "min"}          # 可选

    def render(self, p):                    # 参数 → 网表
        # 1) 数值用 E.fmt() 写成纯数字（ngspice 不认 pi）
        # 2) 交流源必须带 AC 1
        # 3) 结尾要有分析卡与 .end（.control 由 sim.run() 注入；build() 会按 sweep_center 重写分析卡）
        return f"* {self.name}\nVin in 0 AC 1\nR1 in out {E.fmt(p['R'])}\nC1 out 0 {E.fmt(p['C'])}\n{AC_FULL}\n.end"

    def extract(self, res, p):              # 波形 → 指标（全部 Python 侧）
        w = res.waves["v(out)"]
        db = w.db()
        return {"gain_db": db[0], "fc": _find_f3db(w, db[0]) or _fnan()}

    def design(self, spec):                 # 目标指标 → 初始参数（解析式，不吸附）
        c = 100e-9
        return {"R": 1.0 / (PI2 * spec["fc"] * c), "C": c}
```

（`E` / `AC_FULL` / `_find_f3db` / `PI2` / `_fnan` 都是 `topologies/` 包里现成的名字（门面 re-export），不用额外 import。
上面这段实测可跑：`design({'fc':1e3})` → `R=1591.55`；`build()` 后
`metrics = {'gain_db': -0.0, 'fc': 1000.0}`，网表里的分析卡被自动改写成 `.ac dec 200 0.1 1e+07`。）

要点：

- `render()` 只保证语法与物理结构正确；参数已经过 `Param.clamp()`，但仍要修掉除零风险。
- `extract()` 只读 `res.waves`，**不得再跑仿真**（例外是差分放大/运放这类需要共模或环路增益的，
  它们会多跑 1~2 个网表，代价要算进时间预算）。
- `design()` 是**搜索起点**，不是答案。它算错不会崩，但会让搜索彻底找不到解（§8.1 第 4 条）。
- 若特征频率不等于 `fc`（多级级联、综合型拓扑），**覆写 `sweep_center()`**，
  否则基类启发式会认错（`filter_lowpass_synth` 就覆盖了它，注释里记着「基类给出 13.3kHz、真实 fc=10kHz」）。
- 拓扑专属提示：覆写 `note(p, m) -> str`。

**第 2 步：注册**到文件末尾的 `REGISTRY`。`catalog()`、`--catalog`、`/api/catalog`、`/api/health`
的拓扑数都会自动跟着变（**没有任何地方硬编码拓扑数量**）。

**第 3 步（最容易漏）：让规则模式能选中它**。配了 Key 时走 `llm.plan()`（拓扑清单自动生成，无需改）；
没配 Key 时走 `agent.parse_rules()` 的 `if/elif` 关键词路由，**顺序即优先级**——
「二阶高通」必须写在「高通」前面，否则用户拿到一阶高通却被报「全部达标」。
历史上这个缺陷让三个新拓扑在规则模式下**完全不可达**。加分支后补一条回归用例
（`tests/test_e2e.py::test_rule_parser_can_select_new_topologies` 是模板）。

**第 4 步：跑物理核对**。`tests/test_physics.py` 的写法是「解析公式 vs 实测 → 相对误差 → 与容差比较」，
并且**自己实现插值/取点**（不 import `topologies` 的内部工具函数），避免「提取算错」与「插值算错」互相掩盖。

**第 5 步：跑端到端**：`python3 tests/run_all.py`，再用一句真实中文需求跑 `python3 main.py "…"`，
肉眼确认报告里的元件值是可买到的标称值。

### 9.2 新增一个器件（CCL）

1. 在 `ccl/devices.py` 里继承 `Device`（两端件继承 `_TwoTerminal`，要模型卡的继承 `_Modeled`），
   **显式声明 `kind` 与有序 `pins`**，覆盖 `value_tokens()`。
2. 引脚顺序 = SPICE 端子顺序，这是唯一不能搞错的事（错了不报错、结果全错）。
   顺手在类 docstring 里写清「引脚顺序：…」——`ccl/devices.py` 顶部的总表就是给人对照的。
3. 在 `ccl/core.py` 的 `Circuit` 上加一个便捷方法（`c.XXX(...)`），保持"两端件 `(a,b,value)`、
   多端件按引脚顺序 + 同名关键字"的规则。
4. 参数越界抛 `CCLConfigError`，报错里带位号和参数名。
5. 加进 `ccl/ai/prompts.py` 的 `API_CARD`（否则 AI 生成不出这个器件——M2 做完后曾经就是这样，
   能力做了却用不上）；若需要新模块，同步 `sandbox.ALLOWED_IMPORTS`（见 §7.13）。
   **M6 的开关就是现成的反例**：`c.SW()` 在库里能用、有测试、界面能点，但 `API_CARD` 里没有它，
   所以 AI 生成时不会想到开关（见 §8.1 第 11 条）。
6. 在 `tests_ccl/test_devices.py` 里加一条解析式核对的用例（二极管正向压降、MOS 饱和电流这类），
   打印实测数字——「能跑」不算过，**数字要对得上解析式**。

### 9.3 新增一个子电路块（`ccl/blocks.py`）

1. 写一个返回 `Circuit` 的函数，**内部不放独立源**（内联后会与外部共节点 → 可能 singular matrix）。
2. 用 `_set_ports(ckt, {"in": ..., "out": ...})` 声明端口。
3. 加进 `BLOCKS` 字典；`catalog()` 会自动带出签名（前端侧栏与 `/api/ccl/blocks` 都用它）。
4. 在 `tests_ccl/test_blocks.py` 的 `ARGS` 里登记该块（**这份名单就是契约**）：
   块清单用例（`test_catalog_complete`）、逐块构建用例（`test_block_builds_*`）与物理核对用例
   都会自动覆盖它。刻意不用「块数量 == N」这种写死数字的断言——加块是正常进化，
   只有**漏登记**才该报警。

### 9.4 新增一个检查项（`ccl/lint.py`）

1. 写一个 `check_xxx(circuit, solution)` → `list[Issue]`，`Issue` 带 `level/title/detail/ref/code`。
2. 静态检查加进 `_STATIC` 元组；需要 solution 的加进 `check_solution()` 的串联里。
3. 需要「忽略端口」的检查要接受 `ignore` 参数（`check_floating`/`check_dc_path` 是范例）。
4. 单项检查抛异常只会打印跳过——这是刻意的，但**不许静默**，所以 `prints` 到 stderr。
5. `ccl.ai.review` 与 `ccl.ai.generate._diagnose()` 会自动用上新的检查项（它们从 `ccl.lint` 导入），
   所以「检查项越多，AI 修复越准」这句话是真的。

### 9.5 改 IDE 的某个模块

先读 `web/ide/CONTRACT.md`（布局网格、三个模块的签名、验收标准），然后：

- 只改自己名下的文件。`index.html` 是骨架，只可按需加 class。
- 组件之间不互相 import；要跨组件动作就派发事件（`ccl:goto-line` 是范例）。
- 改完 `node --check web/ide/*.js`，并在窄屏档（360×640 竖屏 / 640×360 横屏）下确认无横向滚动——这是**兼容性**检查，主场景是桌面。
- `style.css` 的 token 在文件顶部，改配色只改 token，不要散落硬编码颜色。
- **动电路图要额外过一关**：`schematic.js` 的契约是 `CONTRACT_SCHEMATIC.md`，改完必须跑
  `node tests_ui/schematic_selfcheck.mjs`（51 项，其中第 7 组是几何连通性反推）——
  只看着「图变好看了」就收工是这套契约明确禁止的做法，**连接关系错了比丑严重得多**。

### 9.6 本地验证命令

```bash
python3 main.py --check                 # ngspice 版本 / 拓扑数 / LLM 是否配置
python3 main.py --catalog               # 拓扑清单（README 的表格就来自这里）
python3 tests/run_all.py                # 参数化工具全量测试（含物理核对表与 known_bug 统计）
python3 tests/run_all.py physics judge  # 只跑指定模块（子串匹配）
python3 tests_ccl/run_all.py            # CCL 回归套件（本机实测 225 项 / 54.8s，用例数随轮次增长）
python3 tests_api/run_all.py            # 服务层与前端契约（44 项 / 约 11~16s）
node tests_ui/schematic_selfcheck.mjs   # 电路图渲染 + 几何连通性（51 项，不需要服务）
python3 bench/run_gates.py              # AI 拦截基准（98 条 / 约 2s，零 API Key；退 1 表示有漏网）
bash selfcheck.sh --fast                # 以上全部 + 闸门基准（7 项套件 / 约 117~142s，看机器负载）
bash selfcheck.sh                       # 再加真实模型基准（需要模型端点，慢）
node --check web/ide/main.js            # IDE 语法自检（editor/panels/commands/snippets/schematic 同理）
```
