# 前端界面测试（`tests_ui/`）

**被测对象是前端 `web/ide/` 里的纯逻辑模块**，不是 Python 包。
目前这一层只有一个文件：`schematic_selfcheck.mjs`（电路图几何自检，51 项）。

```bash
cd /storage/emulated/0/文件夹/dz/circuit-copilot

node tests_ui/schematic_selfcheck.mjs    # 全部通过：51 项  → 退出码 0
```

**退出码**：`0` 全部通过；`1` 有失败（末尾会列出失败项）。不需要服务、不需要 npm 依赖、不碰网络，
只依赖系统里的 `node`。因此 `selfcheck.sh` 里它是独立的一条，ngspice 或后端环境坏了它也照样跑。

---

## 这一层测什么

`web/ide/schematic.js` 把一份 `circuit`（JSON）渲染成 SVG 字符串。这个文件是
**纯函数 + 字符串拼接、不碰 DOM**，所以能在 Node 里直接跑、直接断言。

覆盖面（7 组，共 51 项断言）：

| 组 | 内容 |
|---|---|
| 1 | RC 低通：完整 `<svg>` 外壳、`data-ref` 元件分组、源在左的布局次序、走线全正交 |
| 2 | 级联 6 元件（含内联位号 `U1.R1` 与运放 `U2.X1`）：符号数、独立分组 |
| 3 | 三引脚网络（`out` 同时接 R1/C1/R2）：必须出现 `data-junction="1"` 的节点圆点 |
| 4 | 二极管 / 三极管 / MOSFET 的符号几何 |
| 5 | 未知 `kind`（如 `Z`）：不抛异常、降级成矩形、位号仍在 |
| 6 | 空电路：退化成空态占位，不是白屏 |
| 7 | **连接关系反推（最重要）**：13 种构造拓扑 —— 按「电路图阅读规则」从 SVG 几何（线段端点、引脚落点、节点圆点、悬空判断）反推出连通性，再与电路声明的网络逐条对账 |

第 7 组的判据是三个硬指标全为 0：**悬空引脚**（引脚端点没有走线落上）、
**串网**（本该分开的两个网在图上连成了一片）、**断线**（同一个网被画成多个连通块）。
前 6 组测「画出来像不像」，第 7 组测「画出来的东西在电气上是不是同一个电路」——
后者才是这块真正的风险：一个符号画得再漂亮，只要少一段线，用户读到的就是另一个电路。

**不覆盖**：视觉美观、浏览器里的交互/事件、真实后端示例的电路图。
后者原先由 `scratch_m1/_viz/realcheck.mjs`（9 例）手工核对，需要服务在跑，
不是可自动化的回归项，已随里程碑清理一并删除。

---

## 为什么不放进 `tests_ccl/`

`tests_ccl/` 是 **Python 代码库 `ccl/` 的回归套件**，契约是「Python 标准库 + ngspice-47」。
这条前端几何自检硬塞进去有三个坏处：

1. **被测对象不同**。这里 import 的是 `web/ide/schematic.js`（前端 ES module），
   断言的是一坨 SVG 字符串。`tests_ccl/` 的 helper 全部围绕 `Circuit` / `Solution` / 端口展开，
   把 51 项 SVG 断言塞进去，一半的 helper 用不上，还得为 frontend 造一套新的。
2. **口径会漂移**。塞进 Python 只有两条路：把 51 项断言用 Python 重写一遍（等于两份实现，
   改一处忘一处，迟早对不上），或者在 Python 里嵌 `node` 子进程再解析它的输出
   （失败信息被吞一层，定位变差，`--verbose` 也没法直接看到哪一段几何不对）。
   保持单份实现、失败直接打在终端最有效。
3. **依赖边界不同**。`tests_ccl/` 有个隐式前提「ngspice 可用」（唯一可选的 node 只服务
   `test_schematic.py`）。几何自检只需要 `node`，把它单独放一层，
   ngspice 环境坏了它仍然能跑，故障归因也清楚：这是前端的问题，不是仿真器的问题。

所以分工是：**Python 库的回归留在 `tests_ccl/`，前端纯逻辑的回归放这里。**

### 与 `tests_ccl/test_schematic.py` 的关系

两者都测 `schematic.js`，但不是一个东西，有意保留重叠：

- `tests_ccl/test_schematic.py`（7 项，Python 侧）：从 Python 构造 circuit → 起一次 `node` 渲染 →
  在 Python 里反推连通性。它证明的是「**Python 能看到且能核对前端产物**」这条路是通的，
  是跨语言那一侧的接口回归。
- `tests_ui/schematic_selfcheck.mjs`（51 项，Node 侧）：几何层的**主回归**，
  断言更密（13 种拓扑对账 + 9 种符号 + 空态/未知 kind 降级）。
  改 `schematic.js` 时先跑这个，失败信息最直接。

---

## 编写约定

- **只能用 `node` 标准库**，不引入 npm 依赖（`node_modules` 不存在，也不该出现）。
- 项目里**没有** `package.json type=module`，直接 `import 'web/ide/schematic.js'` 会被当成 CJS
  报 `SyntaxError`。可靠做法是读源码 → base64 → `import('data:text/javascript;base64,…')`，
  等价于浏览器的 `<script type="module">`，测的仍是**同一份源码**（不是拷贝）。
- 路径一律从 `import.meta.url` 推（`ROOT = path.resolve(HERE, '..')`），
  这样从任何目录调用都能跑，不依赖当前工作目录。
- 断言用文件里的 `ok(cond, label, extra)` 小工具：失败不中断，全部跑完再汇总，
  一次性看到所有坏掉的地方。
