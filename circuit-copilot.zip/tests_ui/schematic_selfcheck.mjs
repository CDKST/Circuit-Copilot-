/* ------------------------------------------------------------------
 * schematic.js 自测（纯 Node，无 npm 依赖）
 *   node tests_ui/schematic_selfcheck.mjs
 *
 * 为什么用 data: URL 导入：项目里没有 package.json type=module，
 * Node 会把 web/ide/schematic.js 当成 CJS，直接 import 会 SyntaxError。
 * 读源码 + data: URL 导入等价于浏览器的 <script type="module">，测的还是同一份源码。
 * ------------------------------------------------------------------ */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const SRC_PATH = path.join(ROOT, 'web/ide/schematic.js');

const src = fs.readFileSync(SRC_PATH, 'utf8');
const mod = await import('data:text/javascript;base64,' + Buffer.from(src, 'utf8').toString('base64'));
const { renderSchematic, schematicOrEmpty } = mod;

/* ---------------- 断言小工具 ---------------- */
let pass = 0;
const fails = [];
function ok(cond, label, extra) {
  if (cond) { pass += 1; console.log('  ✓ ' + label + (extra ? '  — ' + extra : '')); }
  else { fails.push(label + (extra ? '  — ' + extra : '')); console.log('  ✗ ' + label + (extra ? '  — ' + extra : '')); }
}
function count(svg, tag) {
  const m = svg.match(new RegExp('<' + tag + '[\\s>/]', 'g'));
  return m ? m.length : 0;
}
/** 抓出某个片段里所有 <line> 的坐标 */
function linesOf(inner) {
  const re = /<line x1="([-\d.]+)" y1="([-\d.]+)" x2="([-\d.]+)" y2="([-\d.]+)"/g;
  const arr = [];
  let m;
  while ((m = re.exec(inner)) !== null) arr.push({ x1: +m[1], y1: +m[2], x2: +m[3], y2: +m[4] });
  return arr;
}

/** 取某个 data-ref 的 <g ...>...</g> 内容（本项目不嵌套同名 g，够用） */
function group(svg, ref) {
  const re = new RegExp('<g data-ref="' + ref.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"[^>]*>([\\s\\S]*?)</g>');
  const m = svg.match(re);
  if (!m) return null;
  const attr = (name) => {
    const am = m[0].match(new RegExp(' ' + name + '="([^"]*)"'));
    return am ? am[1] : null;
  };
  return { inner: m[1], attr, head: m[0] };
}

/* ============================ 1. RC 低通 ============================ */
console.log('\n[1] RC 低通');
const RC = {
  name: 'rc_lowpass',
  nodes: ['in', '0', 'out'],
  components: [
    { ref: 'V1', kind: 'V', model: null, value_text: 'AC 1V', pins: ['a', 'b'], pin_nodes: { a: 'in', b: '0' } },
    { ref: 'R1', kind: 'R', model: null, value_text: '1.6kΩ', pins: ['a', 'b'], pin_nodes: { a: 'in', b: 'out' } },
    { ref: 'C1', kind: 'C', model: null, value_text: '100nF', pins: ['a', 'b'], pin_nodes: { a: 'out', b: '0' } },
  ],
};
const rc = renderSchematic(RC, { theme: 'dark' });
console.log('    SVG 长度 ' + rc.length + ' 字符');
ok(rc.startsWith('<svg') && rc.endsWith('</svg>'), '产出完整 <svg> 根元素');
console.log('    元素统计： <line>=' + count(rc, 'line')
  + '  <path>=' + count(rc, 'path')
  + '  <rect>=' + count(rc, 'rect')
  + '  <text>=' + count(rc, 'text')
  + '  <circle>=' + count(rc, 'circle')
  + '  <polyline>=' + count(rc, 'polyline')
  + '  <polygon>=' + count(rc, 'polygon'));
ok(count(rc, 'line') > 0, '<line> 存在', count(rc, 'line') + ' 条');
ok(count(rc, 'text') >= 6, '<text> 至少 6（3 位号 + 3 值 + GND）', count(rc, 'text') + ' 个');
ok(count(rc, 'rect') >= 1, '电阻矩形被画出', count(rc, 'rect') + ' 个 rect');
ok(count(rc, 'circle') >= 1, '电压源画成圆（circle ≥1）', count(rc, 'circle') + ' 个');

const v1 = group(rc, 'V1'), r1 = group(rc, 'R1'), c1 = group(rc, 'C1');
ok(!!v1 && !!r1 && !!c1, '三个元件都有 data-ref 分组');
const v1x = parseFloat(v1.attr('data-x')), r1x = parseFloat(r1.attr('data-x')), c1x = parseFloat(c1.attr('data-x'));
ok(v1x < r1x, '源在左：V1.x < R1.x', 'V1.x=' + v1x + '  R1.x=' + r1x);
ok(r1x < c1x, '信号从左到右：R1.x < C1.x', 'R1.x=' + r1x + '  C1.x=' + c1x);
ok(v1.attr('data-mode') === 'v', 'V1（接 GND）竖直摆放', 'data-mode=' + v1.attr('data-mode'));
ok(c1.attr('data-mode') === 'v', 'C1（接 GND）竖直摆放', 'data-mode=' + c1.attr('data-mode'));
ok(r1.attr('data-mode') === 'h', 'R1（两端都不接地）横放', 'data-mode=' + r1.attr('data-mode'));

/* C1 的引线必须 x 相同、y 不同 —— 真几何，不只看标志位 */
const c1lines = linesOf(c1.inner).filter(l => Math.abs(l.x1 - l.x2) < 0.01);
ok(c1lines.length >= 2, 'C1 有 ≥2 条竖直引线', c1lines.length + ' 条');
ok(linesOf(c1.inner).filter(l => Math.abs(l.y1 - l.y2) < 0.01).length === 2,
  '电容是两条平行极板',
  linesOf(c1.inner).filter(l => Math.abs(l.y1 - l.y2) < 0.01).length + ' 条水平线');
const ys = c1lines.map(l => [l.y1, l.y2]).flat();
ok(new Set(c1lines.map(l => l.x1)).size === 1 && Math.max(...ys) - Math.min(...ys) > 60,
  'C1 引线同 x、y 跨度 >60（真的竖直）',
  'x=' + c1lines[0].x1 + '  y ' + Math.min(...ys) + '→' + Math.max(...ys));

/* 正交：不许出现斜线 */
const diag = [...rc.matchAll(/<line x1="([-\d.]+)" y1="([-\d.]+)" x2="([-\d.]+)" y2="([-\d.]+)"/g)]
  .filter(m => Math.abs(+m[1] - +m[3]) > 0.01 && Math.abs(+m[2] - +m[4]) > 0.01);
ok(diag.length === 0, '所有 <line> 都是正交的（无斜线）', diag.length + ' 条斜线');

/* ============================ 2. 级联（含运放）============================ */
console.log('\n[2] 级联：RC + 同相放大（6 元件，含运放 U2.X1）');
const CASCADE = {
  name: 'two_stage',
  nodes: ['src', '0', 'n1', 'U2.sum', 'y'],
  components: [
    { ref: 'V1', kind: 'V', model: null, value_text: 'AC 1V', pins: ['a', 'b'], pin_nodes: { a: 'src', b: '0' } },
    { ref: 'U1.R1', kind: 'R', model: null, value_text: '1.59kΩ', pins: ['a', 'b'], pin_nodes: { a: 'src', b: 'n1' } },
    { ref: 'U1.C1', kind: 'C', model: null, value_text: '100nF', pins: ['a', 'b'], pin_nodes: { a: 'n1', b: '0' } },
    { ref: 'U2.R1', kind: 'R', model: null, value_text: '1kΩ', pins: ['a', 'b'], pin_nodes: { a: 'U2.sum', b: '0' } },
    { ref: 'U2.R2', kind: 'R', model: null, value_text: '9kΩ', pins: ['a', 'b'], pin_nodes: { a: 'y', b: 'U2.sum' } },
    {
      ref: 'U2.X1', kind: 'X', model: 'OPA_100000_1p3e06', value_text: 'OPA_100000_1p3e06',
      pins: ['inp', 'inn', 'out'], pin_nodes: { inp: 'n1', inn: 'U2.sum', out: 'y' },
    },
  ],
};
const cas = renderSchematic(CASCADE);
const symCount = (cas.match(/data-ref="/g) || []).length;
ok(symCount >= 6, '至少 6 个元件符号（data-ref 分组）', symCount + ' 个');
console.log('    元素统计： <line>=' + count(cas, 'line') + '  <path>=' + count(cas, 'path')
  + '  <rect>=' + count(cas, 'rect') + '  <text>=' + count(cas, 'text')
  + '  <circle>=' + count(cas, 'circle') + '  <polygon>=' + count(cas, 'polygon'));
ok(/U2\.X1/.test(cas), '位号 U2.X1 出现在文本里');
const x1g = group(cas, 'U2.X1');
ok(!!x1g, '运放 U2.X1 有独立分组');
const tri = x1g && x1g.inner.match(/<polygon points="([-\d.,\s]+)"/);
ok(!!tri && tri[1].trim().split(/\s+/).length === 3, '运放画成三角形（3 点多边形）',
  tri ? tri[1].trim().split(/\s+/).length + ' 个顶点' : '无 polygon');
ok(/OPA/.test(cas), '长型号被压缩后仍出现（OPA…）');
ok(cas.includes('1.3e06') || /OPA 1/.test(cas), 'OPA_100000_1p3e06 压缩成短文本', (cas.match(/OPA[^<]*/) || [''])[0]);

/* ============================ 3. 三引脚网络 ============================ */
console.log('\n[3] 三引脚网络（out 同时接 R1 / C1 / R2）');
const THREE = {
  name: 'rc3',
  nodes: ['in', '0', 'out'],
  components: [
    { ref: 'V1', kind: 'V', value_text: 'AC 1V', pins: ['a', 'b'], pin_nodes: { a: 'in', b: '0' } },
    { ref: 'R1', kind: 'R', value_text: '1.6kΩ', pins: ['a', 'b'], pin_nodes: { a: 'in', b: 'out' } },
    { ref: 'C1', kind: 'C', value_text: '100nF', pins: ['a', 'b'], pin_nodes: { a: 'out', b: '0' } },
    { ref: 'R2', kind: 'R', value_text: '1kΩ', pins: ['a', 'b'], pin_nodes: { a: 'out', b: '0' } },
  ],
};
const three = renderSchematic(THREE);
const jdots = (three.match(/data-junction="1"/g) || []).length;
console.log('    元素统计： <circle>=' + count(three, 'circle') + '（其中节点圆点 ' + jdots + '）');
ok(jdots >= 1, '三引脚网络的母线上出现实心圆点', jdots + ' 个圆点');

/* ============================ 4. D / Q / M ============================ */
console.log('\n[4] 二极管 / 三极管 / MOSFET');
const DQM = {
  name: 'devices',
  nodes: ['vcc', '0', 'b', 'c', 'a', 'g'],
  components: [
    { ref: 'V1', kind: 'V', value_text: 'DC 5V', pins: ['a', 'b'], pin_nodes: { a: 'vcc', b: '0' } },
    { ref: 'R1', kind: 'R', value_text: '100kΩ', pins: ['a', 'b'], pin_nodes: { a: 'vcc', b: 'b' } },
    { ref: 'R2', kind: 'R', value_text: '100Ω', pins: ['a', 'b'], pin_nodes: { a: 'vcc', b: 'c' } },
    { ref: 'Q1', kind: 'Q', value_text: 'Q2N3904', pins: ['c', 'b', 'e'], pin_nodes: { c: 'c', b: 'b', e: '0' } },
    { ref: 'D1', kind: 'D', value_text: 'D1N4148', pins: ['a', 'k'], pin_nodes: { a: 'a', k: '0' } },
    { ref: 'M1', kind: 'M', value_text: 'M2N7002', pins: ['d', 'g', 's', 'b'], pin_nodes: { d: 'c', g: 'g', s: '0', b: '0' } },
    { ref: 'R3', kind: 'R', value_text: '1kΩ', pins: ['a', 'b'], pin_nodes: { a: 'vcc', b: 'a' } },
    { ref: 'R4', kind: 'R', value_text: '10kΩ', pins: ['a', 'b'], pin_nodes: { a: 'vcc', b: 'g' } },
  ],
};
let dqm = '';
try { dqm = renderSchematic(DQM); } catch (e) { console.log('    渲染抛异常：' + e.message); }
ok(!!dqm, 'D/Q/M 电路渲染不抛异常');
const d1 = group(dqm, 'D1'), q1 = group(dqm, 'Q1'), m1 = group(dqm, 'M1');
ok(!!d1 && d1.attr('data-kind') === 'D', 'D1 data-kind=D');
ok(!!d1 && /<polygon/.test(d1.inner) && /<line/.test(d1.inner), '二极管 = 三角形 + 阴极竖线');
ok(!!q1 && q1.attr('data-kind') === 'Q', 'Q1 data-kind=Q');
ok(!!q1 && /<circle/.test(q1.inner) && (q1.inner.match(/<polyline/g) || []).length >= 2
  && /<polygon/.test(q1.inner), '三极管 = 圆 + 两条斜线 + 发射极箭头');
ok(!!m1 && m1.attr('data-kind') === 'M', 'M1 data-kind=M');
ok(!!m1 && (m1.inner.match(/<line/g) || []).length >= 6, 'MOSFET 有栅极竖线 + 沟道三段 + d/s 引线',
  (m1.inner.match(/<line/g) || []).length + ' 条 line');
console.log('    元素统计： <line>=' + count(dqm, 'line') + '  <text>=' + count(dqm, 'text')
  + '  <circle>=' + count(dqm, 'circle') + '  <polygon>=' + count(dqm, 'polygon'));

/* ============================ 5. 未知 kind ============================ */
console.log('\n[5] 未知 kind（Z）');
let unknown = '';
let threw = null;
try {
  unknown = renderSchematic({
    name: 'weird',
    nodes: ['in', '0', 'out'],
    components: [
      { ref: 'V1', kind: 'V', value_text: 'DC 1V', pins: ['a', 'b'], pin_nodes: { a: 'in', b: '0' } },
      { ref: 'Z9', kind: 'Z', value_text: 'MYSTERY', pins: ['a', 'b'], pin_nodes: { a: 'in', b: 'out' } },
      { ref: 'C1', kind: 'C', value_text: '10nF', pins: ['a', 'b'], pin_nodes: { a: 'out', b: '0' } },
    ],
  });
} catch (e) { threw = e; }
ok(!threw, '未知 kind 不抛异常', threw ? threw.message : '');
const z9 = unknown ? group(unknown, 'Z9') : null;
ok(!!z9 && z9.attr('data-kind') === 'Z', '降级元件仍有 data-ref/data-kind');
ok(!!z9 && /<rect/.test(z9.inner), '未知 kind 降级成方框');
ok(/Z9/.test(unknown), '位号 Z9 仍然显示');
/* 各种畸形输入都不许崩 */
let robust = true;
for (const bad of [null, undefined, {}, { components: [] }, { components: [{}] }, { components: [{ kind: 'R' }] },
  { components: [{ ref: 'R1', kind: 'R', pins: ['a', 'b'], pin_nodes: { a: 'x', b: 'x' } }] },
  { components: [{ ref: 'X1', kind: 'X', pins: [], pin_nodes: {} }] }]) {
  try { renderSchematic(bad); } catch (e) { robust = false; console.log('    崩溃输入：' + JSON.stringify(bad) + ' -> ' + e.message); }
}
ok(robust, 'null / 空 / 缺字段 / 自环 等畸形输入都不抛异常');

/* ============================ 6. 空电路 ============================ */
console.log('\n[6] 空电路');
const emptyCases = [null, {}, { components: [] }, { name: 'empty', nodes: [], components: [] }];
for (const ec of emptyCases) {
  const s = schematicOrEmpty(ec);
  const noSvg = !/<svg/.test(s);
  const hasText = /还没有元件/.test(s);
  ok(noSvg && hasText, '空态：无 <svg> 且有提示文字', JSON.stringify(ec) + ' -> ' + s.length + ' 字符');
}

/* ============================ 7. 连接关系反推（额外，最重要）============================ */
/* 做法：把 SVG 里所有带 data-net 的 <line> 当地线段，**完全按电路图的阅读规则**
 * 重建连通性 —— 两条线只要共享一个「端点」（L 角或 T 型接点）就算连通；
 * 纯粹的十字交叉（交点在两者内部）**不算**连通。
 * 然后把每个元件声明的引脚落点 data-pins 贴回这套几何连通块：
 *   · 每个引脚必须落在某条线上（否则悬空）
 *   · 同一个几何连通块里不能出现两个不同网络（否则就是「接错了」）
 *   · 同一个网络的所有引脚必须在同一个连通块里（否则线断了）
 */
function parseAttrs(str) {
  const o = {};
  const re = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)="([^"]*)"/g;
  let m;
  while ((m = re.exec(str)) !== null) o[m[1]] = m[2];
  return o;
}
function distToSeg(px, py, s2) {
  const dx = s2.x2 - s2.x1, dy = s2.y2 - s2.y1;
  const len2 = dx * dx + dy * dy;
  let t = len2 > 0 ? ((px - s2.x1) * dx + (py - s2.y1) * dy) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  const cx = s2.x1 + t * dx, cy = s2.y1 + t * dy;
  return Math.hypot(px - cx, py - cy);
}
function onSeg(px, py, s2) { return distToSeg(px, py, s2) <= 0.6; }

function reverseEngineer(svg) {
  const segs = [];
  for (const m of svg.matchAll(/<line\s([^>]*?)\/>/g)) {
    const a = parseAttrs(m[1]);
    if (!a['data-net']) continue;            /* 纯装饰（符号内部）不参与 */
    segs.push({ net: a['data-net'], x1: +a.x1, y1: +a.y1, x2: +a.x2, y2: +a.y2 });
  }
  const pins = [];
  for (const m of svg.matchAll(/<g\s([^>]*?)>/g)) {
    const a = parseAttrs(m[1]);
    if (!a['data-ref'] || !a['data-pins']) continue;
    for (const tok of a['data-pins'].split(' ')) {
      if (!tok) continue;
      const at = tok.lastIndexOf('@');
      const net = tok.slice(0, at);
      const xy = tok.slice(at + 1).split(',');
      pins.push({ ref: a['data-ref'], net, x: +xy[0], y: +xy[1] });
    }
  }
  const par = segs.map((_, i) => i);
  const find = (i) => (par[i] === i ? i : (par[i] = find(par[i])));
  const uni = (i, j) => { const a = find(i), b = find(j); if (a !== b) par[a] = b; };
  const P = (s2) => [[s2.x1, s2.y1], [s2.x2, s2.y2]];
  for (let i = 0; i < segs.length; i++) {
    for (let j = i + 1; j < segs.length; j++) {
      const a = segs[i], b = segs[j];
      let joined = false;
      for (const [x, y] of P(a)) if (onSeg(x, y, b)) joined = true;
      for (const [x, y] of P(b)) if (onSeg(x, y, a)) joined = true;
      if (joined) uni(i, j);          /* 只有「端点落在对方身上」才算连通 */
    }
  }
  /* 引脚贴回几何连通块 */
  const pinOwner = [];
  const floating = [];
  for (const p of pins) {
    let owner = -1;
    for (let i = 0; i < segs.length; i++) {
      if (onSeg(p.x, p.y, segs[i])) { if (owner < 0) owner = i; else uni(owner, i); }
    }
    if (owner < 0) floating.push(p);
    pinOwner.push(owner < 0 ? -1 : find(owner));
  }
  /* 重新归一（上面的 uni 可能改过根） */
  for (let i = 0; i < pinOwner.length; i++) if (pinOwner[i] >= 0) pinOwner[i] = find(pinOwner[i]);

  const groups = new Map();
  for (let i = 0; i < segs.length; i++) {
    const r = find(i);
    if (!groups.has(r)) groups.set(r, { nets: new Set(), pins: [] });
    groups.get(r).nets.add(segs[i].net);
  }
  for (let i = 0; i < pins.length; i++) {
    if (pinOwner[i] < 0) continue;
    const g = groups.get(pinOwner[i]);
    if (!g) continue;
    g.nets.add(pins[i].net);
    g.pins.push(pins[i]);
  }
  const mixed = [...groups.values()].filter(g => g.nets.size > 1);
  /* 同一网络必须全在一个连通块里 */
  const byNet = new Map();
  for (let i = 0; i < pins.length; i++) {
    const p = pins[i];
    if (!byNet.has(p.net)) byNet.set(p.net, new Set());
    byNet.get(p.net).add(pinOwner[i] < 0 ? 'float' : pinOwner[i]);
  }
  const split = [...byNet.entries()].filter(([, set]) => set.size > 1);
  return { segs: segs.length, pins: pins.length, groups: groups.size, floating, mixed, split };
}

console.log('\n[7] 连接关系反推（几何连通性 vs 声明的网络）');
const NET_CASES = {
  rc: RC, cascade: CASCADE, threepin: THREE, devices: DQM,
  divider: {
    name: 'divider', nodes: ['in', '0', 'mid'],
    components: [
      { ref: 'V1', kind: 'V', value_text: 'DC 5V', pins: ['a', 'b'], pin_nodes: { a: 'in', b: '0' } },
      { ref: 'R1', kind: 'R', value_text: '10kΩ', pins: ['a', 'b'], pin_nodes: { a: 'in', b: 'mid' } },
      { ref: 'R2', kind: 'R', value_text: '10kΩ', pins: ['a', 'b'], pin_nodes: { a: 'mid', b: '0' } },
    ],
  },
  noninv_amp: {
    name: 'noninv_amp', nodes: ['src', '0', 'sum', 'out'],
    components: [
      { ref: 'V1', kind: 'V', value_text: 'AC 1V', pins: ['a', 'b'], pin_nodes: { a: 'src', b: '0' } },
      { ref: 'R1', kind: 'R', value_text: '1kΩ', pins: ['a', 'b'], pin_nodes: { a: 'sum', b: '0' } },
      { ref: 'R2', kind: 'R', value_text: '9kΩ', pins: ['a', 'b'], pin_nodes: { a: 'out', b: 'sum' } },
      { ref: 'X1', kind: 'X', value_text: 'OPA_100000_1p3e06', pins: ['inp', 'inn', 'out'],
        pin_nodes: { inp: 'src', inn: 'sum', out: 'out' } },
    ],
  },
  sallen_key: {
    name: 'sallen_key_lp', nodes: ['in', '0', 'n1', 'n2', 'out'],
    components: [
      { ref: 'V1', kind: 'V', value_text: 'AC 1V', pins: ['a', 'b'], pin_nodes: { a: 'in', b: '0' } },
      { ref: 'R1', kind: 'R', value_text: '11.2kΩ', pins: ['a', 'b'], pin_nodes: { a: 'in', b: 'n1' } },
      { ref: 'R2', kind: 'R', value_text: '11.2kΩ', pins: ['a', 'b'], pin_nodes: { a: 'n1', b: 'n2' } },
      { ref: 'C1', kind: 'C', value_text: '20nF', pins: ['a', 'b'], pin_nodes: { a: 'n1', b: 'out' } },
      { ref: 'C2', kind: 'C', value_text: '10nF', pins: ['a', 'b'], pin_nodes: { a: 'n2', b: '0' } },
      { ref: 'X1', kind: 'X', value_text: 'OPA_100000_1e6', pins: ['inp', 'inn', 'out'],
        pin_nodes: { inp: 'n2', inn: 'out', out: 'out' } },
    ],
  },
};
/* 再补几种「刁钻」拓扑：电感 / 电流源 / 运放输入接地 / MOS 衬底接源 / 未知三端器件 / 并联 */
const CCR = (ref, kind, vt, pins, pn) => ({ ref, kind, value_text: vt, pins, pin_nodes: pn });
Object.assign(NET_CASES, {
  inductor: { name: 'lc', nodes: ['in', '0', 'out'], components: [
    CCR('V1', 'V', 'AC 1V', ['a', 'b'], { a: 'in', b: '0' }),
    CCR('L1', 'L', '1mH', ['a', 'b'], { a: 'in', b: 'out' }),
    CCR('C1', 'C', '1nF', ['a', 'b'], { a: 'out', b: '0' })] },
  current_src: { name: 'isrc', nodes: ['n1', '0', 'out'], components: [
    CCR('I1', 'I', 'DC 1mA', ['a', 'b'], { a: '0', b: 'n1' }),
    CCR('R1', 'R', '1kΩ', ['a', 'b'], { a: 'n1', b: 'out' }),
    CCR('C1', 'C', '1uF', ['a', 'b'], { a: 'out', b: '0' })] },
  opamp_grounded_in: { name: 'gnd_in', nodes: ['in', '0', 'out'], components: [
    CCR('V1', 'V', 'AC 1V', ['a', 'b'], { a: 'in', b: '0' }),
    CCR('X1', 'X', 'OPA', ['inp', 'inn', 'out'], { inp: '0', inn: 'in', out: 'out' }),
    CCR('R1', 'R', '1kΩ', ['a', 'b'], { a: 'out', b: '0' })] },
  mos_bulk_tied_source: { name: 'mos2', nodes: ['vdd', '0', 'd', 'g', 's'], components: [
    CCR('V1', 'V', 'DC 5V', ['a', 'b'], { a: 'vdd', b: '0' }),
    CCR('R1', 'R', '1kΩ', ['a', 'b'], { a: 'vdd', b: 'd' }),
    CCR('R2', 'R', '1MΩ', ['a', 'b'], { a: 'g', b: '0' }),
    CCR('R3', 'R', '1kΩ', ['a', 'b'], { a: 's', b: '0' }),
    CCR('M1', 'M', 'NMOS', ['d', 'g', 's', 'b'], { d: 'd', g: 'g', s: 's', b: 's' })] },
  unknown_three_pin: { name: 'unk', nodes: ['a', '0', 'b', 'c'], components: [
    CCR('V1', 'V', 'DC 1V', ['a', 'b'], { a: 'a', b: '0' }),
    CCR('Z1', 'Z', 'THING', ['p', 'q', 'r'], { p: 'a', q: 'b', r: '0' }),
    CCR('R1', 'R', '1kΩ', ['a', 'b'], { a: 'b', b: 'c' }),
    CCR('C1', 'C', '1uF', ['a', 'b'], { a: 'c', b: '0' })] },
  parallel_pair: { name: 'par', nodes: ['in', '0', 'out'], components: [
    CCR('V1', 'V', 'AC 1V', ['a', 'b'], { a: 'in', b: '0' }),
    CCR('R1', 'R', '1kΩ', ['a', 'b'], { a: 'in', b: 'out' }),
    CCR('R2', 'R', '2kΩ', ['a', 'b'], { a: 'in', b: 'out' }),
    CCR('C1', 'C', '1uF', ['a', 'b'], { a: 'out', b: '0' })] },
});

for (const [name, circ] of Object.entries(NET_CASES)) {
  const svg = renderSchematic(circ);
  const r = reverseEngineer(svg);
  const okAll = r.floating.length === 0 && r.mixed.length === 0 && r.split.length === 0;
  ok(okAll, '连接关系与声明一致：' + name,
    r.segs + ' 段线 / ' + r.pins + ' 引脚 / ' + r.groups + ' 个连通块'
    + (r.floating.length ? ' | 悬空引脚 ' + r.floating.map(p => p.ref + '.' + p.net).join(',') : '')
    + (r.mixed.length ? ' | 串网 ' + r.mixed.map(g => [...g.nets].join('+')).join(' ; ') : '')
    + (r.split.length ? ' | 断线 ' + r.split.map(([n, set]) => n + '(' + set.size + '块)').join(',') : ''));
}

/* ============================ 汇总 ============================ */
console.log('\n' + '-'.repeat(56));
if (fails.length === 0) {
  console.log('全部通过：' + pass + ' 项');
  process.exit(0);
} else {
  console.log('通过 ' + pass + ' 项，失败 ' + fails.length + ' 项：');
  for (const f2 of fails) console.log('  ✗ ' + f2);
  process.exit(1);
}
