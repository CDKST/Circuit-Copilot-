"""`Solution`：一次仿真的结果，以及从波形里算指标的方法。

设计原则（和 `copilot/sim.py` 一脉相承）：**ngspice 只负责算波形，判定和指标在
Python 侧做**。这样 AI 生成的网表即使有错，物理量依然可信；而且指标算法可以
单独测试、单独解释。

## 节点名兼容性（体验的关键）

ngspice ASCII rawfile 里的名字是小写的 `v(out)` / `i(vin)`。用户会用各种写法问：

    sol.f3db("out")        sol.f3db("V(out)")      sol.f3db("OUT")

三种都必须命中，所以这里做归一化：去空白 → 转小写 → 剥掉 `v(...)` 包裹。
找不到时抛 `NodeError`，**并把可用节点名列出来**——报错只说「节点不存在」而不说
有哪些节点，是这类库最让人抓狂的地方。

## 指标算法的两个要点

1. **在对数频率轴上线性插值**，不要直接取最近的采样点。200 点/十倍频时，
   直接取点带来的误差可达 0.3%；插值后 <0.01%。
2. `f3db` 用「第一处穿过 ref−3.01dB」来定位，低通/高通都能处理。
"""

from __future__ import annotations

import math
import re

from .errors import CCLConfigError, NodeError

__all__ = ["Solution"]

_V_WAVE = re.compile(r"^v\((.+)\)$")
_I_WAVE = re.compile(r"^i\((.+)\)$")
_DB3 = 3.010299956639812  # 20·log10(1/√2)

# ---- 瞬态指标口径常量（改这里等于改全库口径，必须与 CONTRACT 同步）----
_METRIC_TAIL = 0.10        # steady_state 默认时间窗：最后 10%
_SETTLE_RIPPLE = 0.20      # 末段纹波 ≤ 20%·阶跃幅度 → 认为「已经稳住」
_PLATEAU_BAND = 0.02       # 「停在平台上」= 落在平台 ±2%·全程幅度 内
_PLATEAU_MIN_FRAC = 0.05   # 未稳住时，到达的平台至少要占记录时长的 5%
_MIN_STEP_FRAC = 1e-3      # 起点与终点之差 < 0.1%·全程幅度 → 视作「没有阶跃」
_SWEEP_KEYS = ("v-sweep", "i-sweep", "v(v-sweep)", "i(i-sweep)")


class Solution:
    """一次仿真结果。

    属性
        kind          "ac" | "op" | "tran" | "dc"
        x             频率轴（ac）/ 时间轴（tran）/ 扫描轴（dc）；op 是 [0.0, ...]
        waves         {波形名: copilot.sim.Wave}，名字是 ngspice 原始小写形式
        netlist       实际送给 ngspice 的网表（含注入的 .control），自纠时要用
        elapsed_ms    本次调用（编译+仿真+解析）的总耗时，毫秒
        stdout        ngspice 原始输出
        warnings      ngspice 的 warning/note 行（runner 追加的提示也在里面）
        circuit       源电路（可选，便于报告里反向引用位号）
        sweep_var     dc：被扫器件位号（如 "V1"），其它分析为 ""
        sweep_values  dc：主扫描轴取值（内层扫描）
        sweep_unit    dc：主扫描量的单位 "V" / "A" / ""（未知）
        second_var    dc：第二维被扫位号，无第二维为 ""
        second_values dc：第二维取值（外层扫描，一条曲线一个值）
        second_unit   dc：第二维单位
    """

    def __init__(self, kind: str, x=None, waves=None, netlist: str = "",
                 elapsed_ms: float = 0.0, stdout: str = "", warnings=None,
                 circuit=None, sweep_var: str = "", sweep_values=None,
                 sweep_unit: str = "", second_var: str = "",
                 second_values=None, second_unit: str = ""):
        self.kind = kind
        self.waves: dict = dict(waves or {})
        self.netlist = netlist
        self.elapsed_ms = float(elapsed_ms)
        self.stdout = stdout
        self.warnings = list(warnings or [])
        self.circuit = circuit
        self.x = list(x or [])
        self.sweep_var = sweep_var or ""
        self.sweep_values = [float(v) for v in (sweep_values or [])]
        self.sweep_unit = sweep_unit or ""
        self.second_var = second_var or ""
        self.second_values = [float(v) for v in (second_values or [])]
        self.second_unit = second_unit or ""
        self._alias: dict[str, str] | None = None
        self._internal: set[str] | None = None
        self._sweep_key: str | None = None      # None 且已探测 → 用 `_sweep_probed` 标记
        self._sweep_probed = False

    # ------------------------------------------------------------------
    # 构造
    # ------------------------------------------------------------------
    @classmethod
    def from_sim(cls, result, kind: str, *, elapsed_ms: float | None = None,
                 circuit=None) -> "Solution":
        """从 `copilot.sim.SimResult` 构造。

        关于 `.op` 的横轴：**ngspice 的 Operating Point 结果没有真正的横轴**
        （只有 1 个点，第 0 列是第一个变量而不是 frequency/time）。修好后的
        `copilot.sim._parse_ascii_raw` 会把全部变量都保留下来，并给非扫频分析
        填一个「点序号」轴，所以这里对 op 统一把自己的 x 归零成 [0.0, …]：
        `sol.value_at("out", 0)`、`sol.db("out")` 都直接可用。

        关于 `.dc` 的横轴：DC transfer rawfile 里**第 0 个变量就是扫描量本身**，
        名字固定是 `v(v-sweep)`（扫电压源）或 `i(i-sweep)`（扫电流源），不是
        `frequency`/`time`，所以 `copilot.sim` 的 `is_sweep` 判据不认它，会把它
        当成一条普通波形、x 轴填成点序号。这里把扫描量提升成横轴：
        `sol.x == sol.sweep_values`，各波形的 x 也一并改掉，于是
        `sol.value_at("out", 2.5)` 在直流扫描里读的就是「扫到 2.5V 时 out 是多少」。

        （M1 早期这里有一份「把被吞掉的 v(in) 补回来」的重建逻辑；`copilot.sim` 的
         `is_sweep` 修复上线后已删除，避免两套逻辑打架。）
        """
        waves = dict(result.waves)
        x = list(next(iter(waves.values())).x) if waves else []
        if kind == "op":
            x = [0.0] * (len(x) or 1)
        sol = cls(
            kind=kind,
            x=x,
            waves=waves,
            netlist=getattr(result, "netlist", ""),
            elapsed_ms=result.elapsed_ms if elapsed_ms is None else elapsed_ms,
            stdout=getattr(result, "stdout", ""),
            warnings=getattr(result, "warnings", None),
            circuit=circuit,
        )
        if kind == "dc":
            sol._adopt_sweep_axis()
        return sol

    def _adopt_sweep_axis(self) -> None:
        """把 rawfile 里的扫描量（`v(v-sweep)` / `i(i-sweep)`）提升成横轴。

        一维扫描时它就是全部点；两维扫描时它是「内层」扫描量，外层每前进一步
        就把它从 start 重新走一遍（0..5, 0..5, 0..5）——切段逻辑见 `dc_curves()`。
        """
        key = self._sweep_wave_key()
        if key is None:
            return
        vals = self.waves[key].real()
        if not vals:
            return
        self.sweep_values = [float(v) for v in vals]
        self.x = list(self.sweep_values)
        for w in self.waves.values():
            w.x = list(self.sweep_values)

    def _sweep_wave_key(self) -> str | None:
        """找到 rawfile 里那条「扫描量」波形名（没有就返回 None）。"""
        if self._sweep_probed:
            return self._sweep_key
        found = None
        for key in self.waves:
            low = key.strip().lower()
            if low in _SWEEP_KEYS:
                found = key
                break
            m = _V_WAVE.match(low) or _I_WAVE.match(low)
            inner = m.group(1) if m else low
            if inner in ("v-sweep", "i-sweep", "sweep"):
                found = key
                break
        self._sweep_key = found
        self._sweep_probed = True
        return found

    # ------------------------------------------------------------------
    # 节点解析
    # ------------------------------------------------------------------
    @staticmethod
    def _normalize(node: str) -> str:
        if not isinstance(node, str):
            raise NodeError(f"节点名必须是字符串，收到 {type(node).__name__}: {node!r}")
        s = node.strip().lower().replace(" ", "")
        if s == "":
            raise NodeError("节点名不能为空")
        return s

    def _build_alias(self) -> dict[str, str]:
        alias: dict[str, str] = {}
        for key in self.waves:
            k = key.strip().lower()
            alias.setdefault(k, key)
            m = _V_WAVE.match(k)
            if m:
                inner = m.group(1)
                alias.setdefault(inner, key)          # "out" → "v(out)"
                if inner.endswith("#branch"):
                    alias.setdefault(inner[: -len("#branch")], key)
                continue
            m = _I_WAVE.match(k)
            if m:
                inner = m.group(1)
                if inner.endswith("#branch"):
                    inner = inner[: -len("#branch")]
                alias.setdefault(f"i({inner})", key)
                alias.setdefault(k, key)
        return alias

    def v(self, node: str):
        """取一条波形（`copilot.sim.Wave`）。

        支持 `"out"` / `"V(out)"` / `"OUT"` 三种写法；电流要写 `"i(vin)"`。
        找不到抛 `NodeError` 并列出可用节点。
        """
        if self._alias is None:
            self._alias = self._build_alias()
        key = self._normalize(node)
        if key in self.waves:
            return self.waves[key]
        if key in self._alias:
            return self.waves[self._alias[key]]
        raise NodeError(
            f"仿真结果里没有节点 {node!r}。可用节点：{', '.join(self.node_names())}"
            f"。提示：电压直接写节点名（如 \"out\"），电流要带 i()（如 \"i(vin)\"）"
        )

    def _internal_keys(self) -> set[str]:
        """宏模型（.subckt）内部的节点/支路名，用户不该在第一眼看到。

        ngspice 把子电路内部节点命名成 `<实例名>.<内部名>`（展平过的实例前面还会
        多一段 `x.`），内部受控源的电流叫 `i(e.<实例名>.<源名>)`。这些不是电路对外
        节点，出现在「可用节点」列表里只会干扰人——但 `v()` 仍然能查到它们（调运放
        内部工作点时有用）。
        """
        if self._internal is None:
            # 规则只有一条：ngspice 把子电路内部节点命名成
            #       <网表里的实例名>.<内部名>
            # 内部受控源的电流则是 i(e.<实例名>.<源名>)。
            # 注意「网表里的实例名」不等于 comp.ref：子电路内联后 comp.ref 是
            # `U1.X1`，网表里是 `X.U1.X1`（见 CONTRACT D5 / compile.netlist_ref），
            # 于是内部节点叫 `x.u1.x1.ox1`。**必须用 netlist_ref，不能用 comp.ref**，
            # 否则前缀对不上，内部节点会漏进「可用节点」列表。
            prefixes = ["x.", "e.x."]          # 兜底：拿不到 circuit 时只能粗过滤
            if self.circuit is not None:
                prefixes = []
                try:
                    from .compile import netlist_ref
                except Exception:              # compile.py 缺失时退回原始位号
                    netlist_ref = lambda c: c.ref  # noqa: E731
                for comp in getattr(self.circuit, "components", []) or []:
                    if str(getattr(comp, "kind", "")).upper() == "X":
                        nl = str(netlist_ref(comp)).lower()
                        prefixes.extend([f"{nl}.", f"e.{nl}."])
            self._internal = set()
            for key in self.waves:
                k = key.strip().lower()
                m = _V_WAVE.match(k) or _I_WAVE.match(k)
                core = m.group(1) if m else k
                if core.endswith("#branch"):
                    core = core[: -len("#branch")]
                if any(core.startswith(pref) for pref in prefixes):
                    self._internal.add(key)
            # 直流扫描的 rawfile 里有一条叫 `v(v-sweep)` / `i(i-sweep)` 的扫描量
            # 波形。它不是电路节点，列进「可用节点」会让前端多画一条 y=x 的直线，
            # 所以对用户隐藏（`v("v-sweep")` 依然查得到）。
            if self.kind == "dc":
                sweep_key = self._sweep_wave_key()
                if sweep_key:
                    self._internal.add(sweep_key)
        return self._internal

    def node_names(self) -> list[str]:
        """可用节点名（用户视角）：电压给纯节点名，电流给 `i(...)` 形式。

        宏模型内部节点（`x.…`）不列出；要看全集用 `all_node_names()`。
        """
        internal = self._internal_keys()
        names: list[str] = []
        currents: list[str] = []
        for key in self.waves:
            if key in internal:
                continue
            k = key.strip().lower()
            m = _V_WAVE.match(k)
            if m:
                inner = m.group(1)
                names.append(inner[: -len("#branch")] if inner.endswith("#branch") else inner)
                continue
            currents.append(k)
        return sorted(dict.fromkeys(names)) + sorted(dict.fromkeys(currents))

    def all_node_names(self) -> list[str]:
        """含宏模型内部节点在内的全部节点名（排查运放内部工作点时用）。"""
        names: list[str] = []
        for key in self.waves:
            k = key.strip().lower()
            m = _V_WAVE.match(k)
            if m:
                inner = m.group(1)
                names.append(inner[: -len("#branch")] if inner.endswith("#branch") else inner)
            else:
                names.append(k)
        return sorted(dict.fromkeys(names))

    def has_node(self, node: str) -> bool:
        try:
            self.v(node)
            return True
        except NodeError:
            return False

    def xaxis(self, node: str | None = None) -> list[float]:
        """横轴。AC 是频率、TRAN 是时间；也允许直接用某条波形自带的 x。"""
        if node is None:
            return list(self.x)
        return list(self.v(node).x)

    # ------------------------------------------------------------------
    # 基本量
    # ------------------------------------------------------------------
    def mag(self, node: str) -> list[float]:
        """线性幅度 |V|（或 |I|）。"""
        return self.v(node).mag()

    def db(self, node: str) -> list[float]:
        """20·log10|V|。0 幅度给 −300（不是 −inf，避免下游 nan 传染）。"""
        return self.v(node).db()

    def phase(self, node: str) -> list[float]:
        """相位，单位**度**，范围 (−180, 180]。"""
        return self.v(node).phase_deg()

    def real(self, node: str) -> list[float]:
        return self.v(node).real()

    # ------------------------------------------------------------------
    # 指标
    # ------------------------------------------------------------------
    def peak_db(self, node: str) -> float:
        """通带峰值（dB）——取整条曲线的最大值。空数据返回 −300。"""
        db = self.db(node)
        return max(db) if db else -300.0

    def f3db(self, node: str, ref_db: float | None = None) -> float | None:
        """−3dB 频率（相对参考增益）。

        ref_db 不给时用曲线最大值作为参考（低通 = 平坦段、高通 = 通带）。
        取「第一次穿过 ref−3.01dB」的交点，并在**对数频率轴上线性插值**。
        扫频范围没覆盖到交点（例如 1Hz 低通却从 100Hz 开始扫）时返回 None，
        而不是编一个数出来。

        op 分析没有频率轴，恒返回 None。
        """
        if self.kind == "op":
            return None
        w = self.v(node)
        xs, db = w.x, w.db()
        if len(xs) < 2:
            return None
        if ref_db is not None:
            ref = ref_db
        else:
            ref = max(db)
            # 扫频必须真的覆盖了「通带平台」，否则 max(db) 只是"区间内最高点"，
            # 不是一个真实的通带增益——算出来的"−3dB 点"毫无意义。
            # 真实反例：fc≈99.5Hz 的低通从 1kHz 起扫，曲线全程在下坡，
            # 却仍能"找到"一个 −3dB 交点（1417Hz），静默给出错误结论。
            # 判据：参考点旁边要有平坦段（相邻点差 ≤0.3dB）。
            # 判据：曲线上必须存在一段「平坦段」落在 ref 附近（相邻两点都贴近 ref）。
            # 只看 max 的邻居会误伤有峰化的二阶滤波器（峰顶邻点必然差很多），
            # 所以扫描整条曲线。
            # ⚠ 判据不能是「相邻两点都贴近 ref」——200 点/十倍频下单极点相邻点
            # 只差 0.099dB，该判据恒真，于是从 1kHz 起扫 100Hz 低通会"找到"
            # 1417Hz 这个假交点（实测）。真实平台必须**跨足够宽的频率范围**。
            imax = db.index(ref)
            interior_peak = 0 < imax < len(db) - 1
            if not interior_peak:
                # max 落在端点：既可能是真平台（从通带内起扫），
                # 也可能是"从阻带起扫、全程下坡"的假象。要求平台跨度 ≥ 2 倍。
                span_ok = False
                j = 0
                n = len(db)
                while j < n:
                    if abs(db[j] - ref) > 0.3:
                        j += 1
                        continue
                    k = j
                    while k + 1 < n and abs(db[k + 1] - ref) <= 0.3:
                        k += 1
                    # xs 是对数轴上的点；跨度按频率比判断
                    if xs[k] > 0 and xs[j] > 0 and xs[k] / xs[j] >= 2.0:
                        span_ok = True
                        break
                    j = k + 1
                if not span_ok:
                    return None
        return _cross_log_x(xs, db, ref - _DB3)

    def gain_db(self, node: str) -> float:
        """低频/通带增益（dB）。AC 取第一个点；op 取该节点直流电平转成的 dB。"""
        return self.db(node)[0] if self.waves else -300.0

    def value_at(self, node: str, x: float) -> float:
        """在横轴位置 x 处取幅度。

        - ac：|V|，在**对数频率轴**上做对数插值（Bode 图的标准读法）
        - tran / op：实部值（时域电压/电流），线性插值
        超出范围时钳到端点，和示波器/Bode 仪的行为一致。
        """
        w = self.v(node)
        xs = w.x
        if not xs:
            raise NodeError(f"节点 {node!r} 的波形是空的")
        x = float(x)
        ys = w.mag() if self.kind == "ac" else w.real()
        # 直流扫描允许**降序**（如 .dc V1 5 -5 -1），而插值函数假设 x 升序。
        # 不处理的话任何查询都会退化成端点值（实测：5 / 0 / -5 全返回 2.5）。
        if len(xs) >= 2 and xs[0] > xs[-1]:
            xs = xs[::-1]
            ys = ys[::-1]
        if self.kind == "ac":
            return _interp_loglog(xs, ys, x)
        return _interp_linear(xs, ys, x)

    def is_stable_peak(self, node: str, limit_db: float = 0.0) -> bool:
        """通带峰值是否超出 limit_db（简易稳定性/峰化判据，不是环路裕度）。"""
        return self.peak_db(node) > limit_db

    # ------------------------------------------------------------------
    # 直流扫描：曲线族
    # ------------------------------------------------------------------
    def dc_curves(self, node: str) -> list[dict]:
        """把直流扫描结果切成「一条曲线一条 x/y」，供画图与读数。

        返回
        ----
        list[dict]，每个是 `{"label": str, "x": list[float], "y": list[float]}`
        无第二维时只有一条，`label` 为 `""`；有第二维时每条一个 label，
        形如 `"I1=0.5mA"`。

        **两维扫描为什么要切段**

        ngspice 两维 `.dc` 的 rawfile 是「外层固定 → 内层扫完 → 外层前进」的
        分段结构，而且**只记内层扫描量**（名字仍叫 `v(v-sweep)`）：

            .dc V1 0 5 1 I1 0 1m 0.5m      → 18 点 = 3 段 × 每段 6 点
            点号  0..5  : v(v-sweep)=0..5，I1=0
            点号  6..11 : v(v-sweep)=0..5，I1=0.5mA      ← 扫描量在这里「回头」
            点号 12..17 : v(v-sweep)=0..5，I1=1mA

        所以按点号直接连线会画出折返的锯齿。这里按内层扫描点数（`sweep_values`
        长度）切块；切块前先核对点数整除，对不上（例如外层点数被夹紧过）就退回
        「扫描量回头处切段」的实测切法——宁可按实测走，也不猜。
        """
        w = self.v(node)
        ys = w.real()
        xs = list(self.x) if self.kind == "dc" and self.x else list(w.x)
        if len(xs) != len(ys) or not ys:
            return []
        n_inner = len(self.sweep_values)
        if not self.second_var or not self.second_values:
            return [{"label": "", "x": list(xs), "y": list(ys)}]

        labels: list = list(self.second_values)
        if n_inner < 1 or len(ys) % n_inner != 0 or len(ys) // n_inner != len(labels):
            segs = _segment_by_turn(xs, ys)          # 退回实测切段
            if len(segs) != len(labels):
                labels = [None] * len(segs)          # 段数与参数对不上就别硬套标签
        else:
            segs = [(k * n_inner, (k + 1) * n_inner) for k in range(len(labels))]

        out: list[dict] = []
        for i, (a, b) in enumerate(segs):
            val = labels[i] if i < len(labels) else None
            out.append({
                "label": self._second_label(val),
                "x": xs[a:b],
                "y": ys[a:b],
            })
        return out

    def _second_label(self, value) -> str:
        """第二维取值的图例文字，如 `"I1=0.5mA"`。拿不到值就不给 label。"""
        if value is None:
            return ""
        return f"{self.second_var}={_si(value, self.second_unit)}"

    # ------------------------------------------------------------------
    # 瞬态指标（口径见各 docstring，与 ccl/CONTRACT.md 一致）
    # ------------------------------------------------------------------
    def steady_state(self, node: str, tail: float = _METRIC_TAIL) -> float | None:
        """稳态值：**最后 tail 比例时间窗的平均值**（不是取最后一个点）。

        取末点会被最后一小步的抖动带偏，取整条曲线的均值又会把上升过程算进去；
        默认 tail=0.1 即最后 10% 的时间窗。

        返回
        ----
        float | None
            `tran` 给末段均值；`op` 只有一个点，直接返回它；
            `ac` / `dc` 没有时间轴 → None（不编数）。
        """
        tail = _check_tail(tail)
        if self.kind in ("ac", "dc"):
            return None
        if self.kind == "op":              # 工作点只有一个数，末段均值就是它本身
            ys = self.v(node).real()
            return float(ys[0]) if ys else None
        data = self._metric_xy(node)
        if data is None:
            return None
        xs, ys = data
        if len(ys) == 1:
            return float(ys[0])
        return _tail_mean(xs, ys, tail)

    def rise_time(self, node: str, low: float = 0.1, high: float = 0.9) -> float | None:
        """上升时间（秒）：**第一次**穿过 10% 电平 到 第一次穿过 90% 电平的时间差。

        口径
        ----
        - 低电平 = 波形第一个样本；高电平 = `steady_state()`（末段均值）；
          若记录末段低于起点（如从高往低的脉冲串），两者交换使用
        - 10% / 90% 电平 = `低 + low·摆幅`、`低 + high·摆幅`，在相邻样本之间
          **线性插值**，不取最近采样点
        - 只认**上升方向**的穿越，且取**第一次**（不是最后一次）
        - 不是阶跃（起点与终点几乎一样，如纯正弦、恒值）→ None
        - 扫到 90% 电平之前就结束了 → None

        注意：高电平取自**本次记录的末段均值**。如果 t_stop 短到波形还没稳定
        （例如只跑了 1τ），量到的是「这段时间爬了多少」，不是器件的真实上升时间；
        要看真值请把 t_stop 放到 ≥5τ。

        绝不编数：测不到就是 None。
        """
        low, high = _check_levels(low, high)
        lv = self._step_levels(node)
        if lv is None:
            return None
        xs, ys, y0, end = lv
        # 上升沿：低电平 = 起点，高电平 = 末段；若记录是从高往低（脉冲串等），
        # 上升沿相对的是「起点附近的高电平 → 平台低电平」，同样处理。
        lo, hi = (y0, end) if end > y0 else (end, y0)
        t1 = _crossing_time(xs, ys, _thr(lo, hi, low), 0, falling=False)
        if t1 is None:
            return None
        t2 = _crossing_time(xs, ys, _thr(lo, hi, high), t1[0] + 1, falling=False)
        if t2 is None or t2[1] <= t1[1]:
            return None
        return t2[1] - t1[1]

    def fall_time(self, node: str, low: float = 0.1, high: float = 0.9) -> float | None:
        """下降时间（秒）：**第一次**穿过 90% 电平 到 第一次穿过 10% 电平 的时间差。

        口径
        ----
        - 电平按「10% 电平 = 低电平 + 0.1·摆幅、90% 电平 = 低电平 + 0.9·摆幅」定义
          （示波器同一套口径），高/低电平由第一样本与末段均值给出
        - 只认**下降**方向的穿越：从 90% 电平降到 10% 电平
        - 记录里没有下降沿（例如单次上升阶跃）→ None；测不到返回 None
        """
        low, high = _check_levels(low, high)
        lv = self._step_levels(node)
        if lv is None:
            return None
        xs, ys, y0, end = lv
        hi, lo = (y0, end) if end < y0 else (end, y0)
        t1 = _crossing_time(xs, ys, _thr(lo, hi, high), 0, falling=True)
        if t1 is None:
            return None
        t2 = _crossing_time(xs, ys, _thr(lo, hi, low), t1[0] + 1, falling=True)
        if t2 is None or t2[1] <= t1[1]:
            return None
        return t2[1] - t1[1]

    def overshoot_pct(self, node: str) -> float | None:
        """超调百分比，**相对稳态值**：`(峰值 − 稳态)/|稳态| · 100`。

        - 上升阶跃取全程最大值，下降阶跃取全程最小值（阶跃到负值也能用）
        - 没有超调返回 `0.0`（「测到就是没有」，不是编数）
        - 稳态值相对阶跃幅度小到可以忽略（≈0V）时百分比没有意义 → None
        - 不是阶跃（纯正弦等）→ None
        """
        lv = self._step_levels(node)
        if lv is None:
            return None
        _, ys, y0, end = lv
        amp = end - y0
        span = max(ys) - min(ys)
        if amp == 0 or abs(end) < 1e-6 * span:
            return None                    # 稳态≈0：除出来的是噪声，不编数
        peak = max(ys) if amp > 0 else min(ys)
        ov = (peak - end) / abs(end) * 100.0 if amp > 0 else (end - peak) / abs(end) * 100.0
        return max(0.0, ov)

    def settling_time(self, node: str, tol: float = 0.02) -> float | None:
        """建立时间（秒）：最后一次离开 ±tol·稳态 带、并且**再没回来**的时刻。

        口径
        ----
        - 稳态值用 `steady_state()`（末段均值），带宽 = `tol·|稳态|`
          （稳态为 0 时改用 `tol·(max−min)`，否则带宽恒为 0 无法判定）
        - 取「带外最后一个样本」的下一个样本时刻，即重新进入并留住的那一刻
        - 波形到最后还在带外（根本没稳住）→ None；从头就在带内 → 0.0
        """
        try:
            tol = float(tol)
        except (TypeError, ValueError):
            raise CCLConfigError(f"tol 必须是数字，收到 {tol!r}") from None
        if not (0 < tol < 1):
            raise CCLConfigError(f"tol 必须在 (0, 1) 之间，收到 {tol!r}")
        end = self.steady_state(node)
        lv = self._step_levels(node)
        if end is None or lv is None:
            return None
        xs, ys, _y0, _end = lv
        band = tol * abs(end)
        if band <= 0:
            band = tol * (max(ys) - min(ys))
        last_out = -1
        for i, y in enumerate(ys):
            if abs(y - end) > band:
                last_out = i
        if last_out < 0:
            return 0.0
        if last_out + 1 >= len(xs):
            return None                   # 最后一个点仍在带外：没建立
        return xs[last_out + 1]

    # ---- 瞬态指标的内部工具 ----
    def _metric_xy(self, node: str):
        """取 (xs, ys)；点太少或长度不一致返回 None。"""
        w = self.v(node)
        ys = w.real()
        xs = list(w.x)
        if len(xs) != len(ys) or len(xs) < 3:
            return None
        return xs, ys

    def _step_levels(self, node: str):
        """估计阶跃的 (xs, ys, 起点电平, 终点电平)；不是可测量的阶跃返回 None。

        判据只有两条，都是「要么真稳住了、要么真有平台」：
        1. **末段安静**（末 10% 窗纹波 ≤ 20%·阶跃幅度）→ 终点电平 = 末段均值。
           真正的阶跃响应（含过冲/振铃后稳定）都走这条。
        2. **末段不安静但存在平台**（如多周期脉冲串）→ 终点电平 = 首个跳变之后
           停留够久的平台值。纯正弦的极值只是「过一下」，凑不出这样的平台，
           因此正弦在这里被判掉 → None（这正是契约要求的）。
        """
        if self.kind != "tran":
            return None
        data = self._metric_xy(node)
        if data is None:
            return None
        xs, ys = data
        y0 = ys[0]
        span = max(ys) - min(ys)
        if span <= 0:
            return None
        ss = _tail_mean(xs, ys, _METRIC_TAIL)
        amp = ss - y0
        if abs(amp) < _MIN_STEP_FRAC * span:
            return None                    # 起点≈终点：没有阶跃（纯正弦/恒值）
        tail = _tail_slice(xs, ys, _METRIC_TAIL)
        ripple = max(tail) - min(tail)
        if ripple <= _SETTLE_RIPPLE * abs(amp):
            return xs, ys, y0, ss
        plateau = _first_plateau(xs, ys, y0, span)
        if plateau is None:
            return None
        if abs(plateau - y0) < 0.2 * span:
            return None                    # 平台和起点几乎一样：其实没跳变
        return xs, ys, y0, plateau

    # ------------------------------------------------------------------
    # 展示
    # ------------------------------------------------------------------
    def plot(self, node: str, *, width: int = 64, height: int = 15) -> str:
        """返回一段 ASCII 图：ac 是 Bode 幅频（dB vs 对数频率），tran 是时域波形。

        只用标准库手画，够看清「有没有峰、滚降多陡、几个极点」，不追求出版级。
        """
        w = self.v(node)
        xs, ys = w.x, w.db() if self.kind == "ac" else w.real()
        if len(xs) < 2:
            return f"{node}: 数据点不足，无法绘图"
        width = max(20, min(int(width), 160))
        height = max(5, min(int(height), 40))
        ymin, ymax = min(ys), max(ys)
        if ymax - ymin < 1e-12:
            ymax = ymin + 1.0
        pad = (ymax - ymin) * 0.08
        ymin, ymax = ymin - pad, ymax + pad

        logx = self.kind == "ac" and xs[0] > 0 and xs[-1] > 0
        u = _axis_u(xs, logx)

        grid = [[" "] * width for _ in range(height)]
        for i in range(width):
            target = i / (width - 1)
            j = min(range(len(u)), key=lambda k: abs(u[k] - target))
            row = height - 1 - int(round((ys[j] - ymin) / (ymax - ymin) * (height - 1)))
            grid[max(0, min(height - 1, row))][i] = "*"

        unit = "dB" if self.kind == "ac" else "V"
        if self.kind == "ac":
            xlab = "频率 (Hz)"
        elif self.kind == "dc":
            xlab = f"{self.sweep_var or '扫描量'} 扫描值 ({self.sweep_unit or '?'})"
        else:
            xlab = "时间 (s)"
        head = f"{node}   {unit} vs {xlab}"
        out = [head]
        for r, row in enumerate(grid):
            val = ymax - r * (ymax - ymin) / (height - 1)
            out.append(f"{val:9.3f} |" + "".join(row))
        out.append(" " * 9 + "+" + "-" * width)
        if self.kind == "ac":
            out.append(f"{'':10}{xs[0]:<{max(10, width // 2)}.4g}{xs[-1]:.4g}")
        else:
            out.append(f"{'':10}{xs[0]:<{max(10, width // 2)}.4g}{xs[-1]:.4g}")
        return "\n".join(out)

    def summary(self, node: str | None = None) -> str:
        """一句话摘要（AC 给增益/带宽/峰值，OP 给各节点直流电平，DC 给扫描范围）。"""
        if self.kind == "op":
            lines = [f"工作点（{self.elapsed_ms:.0f} ms）："]
            for name in self.node_names():
                if name.startswith("i("):
                    lines.append(f"  {name:<14} {self.value_at(name, 0.0):.6g} A")
                else:
                    lines.append(f"  v({name})".ljust(17) + f"{self.value_at(name, 0.0):.6g} V")
            return "\n".join(lines)
        if self.kind == "dc":
            head = (f"直流扫描 {self.sweep_var or '?'}"
                    f"（{len(self.sweep_values)} 点")
            if self.second_var:
                head += f" × {self.second_var} {len(self.second_values)} 段"
            head += "）："
            if not node or not self.has_node(node):
                return head + "未指定节点"
            curves = self.dc_curves(node)
            if not curves:
                return head + "没有可画的波形"
            ys = curves[0]["y"]
            return (head + f"v({node}) 首段 {ys[0]:.4g} → {ys[-1]:.4g} V")
        node = node or self._guess_interesting_node()
        if node is None:
            return "（没有电压波形）"
        f3 = self.f3db(node)
        tail = f"，−3dB @ {f3:.4g} Hz" if f3 else ""
        return f"v({node})：增益 {self.gain_db(node):.2f} dB，峰值 {self.peak_db(node):.2f} dB{tail}"

    def _guess_interesting_node(self) -> str | None:
        """猜用户关心哪个节点：优先有 −3dB 转折的（真有频率响应的那个），否则第一个。"""
        volts = [n for n in self.node_names() if not n.startswith("i(")]
        for n in volts:
            if self.f3db(n) is not None:
                return n
        return volts[0] if volts else None

    def __repr__(self) -> str:
        return (f"<Solution {self.kind}: {len(self.waves)} 波形, "
                f"{len(self.x)} 点, {self.elapsed_ms:.0f} ms>")


# --------------------------------------------------------------------------
# 内部算法（独立实现，思路与 copilot.topologies 里的拓扑专用版本一致）
# --------------------------------------------------------------------------
def _axis_u(xs: list[float], logx: bool) -> list[float]:
    """把横轴映射到 [0,1]。对数轴用于频率，线性轴用于时间。"""
    if logx:
        lo, hi = math.log10(xs[0]), math.log10(xs[-1])
        if hi == lo:
            return [0.0 for _ in xs]
        return [(math.log10(v) - lo) / (hi - lo) for v in xs]
    lo, hi = xs[0], xs[-1]
    if hi == lo:
        return [0.0 for _ in xs]
    return [(v - lo) / (hi - lo) for v in xs]


def _cross_log_x(xs: list[float], ys: list[float], target: float) -> float | None:
    """找「第一处 ys 穿过 target」的横轴位置，在 log10(x) 上线性插值。

    低通（下降穿过）和高通（上升穿过）都适用；返回 None 表示扫频范围没覆盖。
    """
    for i in range(1, len(xs)):
        y0, y1 = ys[i - 1], ys[i]
        if y0 == y1:
            continue
        if (y0 - target) * (y1 - target) > 0:
            continue
        x0, x1 = xs[i - 1], xs[i]
        if x0 <= 0 or x1 <= 0:          # 时间轴含 0 点时无法取对数，退回线性
            t = (target - y0) / (y1 - y0)
            return x0 + t * (x1 - x0)
        lx0, lx1 = math.log10(x0), math.log10(x1)
        t = (target - y0) / (y1 - y0)
        return 10.0 ** (lx0 + t * (lx1 - lx0))
    return None


def _interp_linear(xs: list[float], ys: list[float], x: float) -> float:
    if x <= xs[0]:
        return ys[0]
    if x >= xs[-1]:
        return ys[-1]
    for i in range(1, len(xs)):
        if xs[i] >= x:
            x0, x1 = xs[i - 1], xs[i]
            if x1 == x0:
                return ys[i]
            return ys[i - 1] + (x - x0) / (x1 - x0) * (ys[i] - ys[i - 1])
    return ys[-1]


def _interp_loglog(xs: list[float], mags: list[float], x: float) -> float:
    """在 log(x)–log(|y|) 上线性插值（Bode 幅频图的标准读法）。"""
    if x <= 0:
        return mags[0]
    if x <= xs[0]:
        return mags[0]
    if x >= xs[-1]:
        return mags[-1]
    for i in range(1, len(xs)):
        if xs[i] >= x:
            x0, x1 = xs[i - 1], xs[i]
            y0, y1 = mags[i - 1], mags[i]
            if x1 == x0:
                return y1
            if y1 <= 1e-30 or y0 <= 1e-30:
                return _interp_linear(xs, mags, x)
            t = (math.log10(x) - math.log10(x0)) / (math.log10(x1) - math.log10(x0))
            return 10.0 ** (math.log10(y0) + t * (math.log10(y1) - math.log10(y0)))
    return mags[-1]


# --------------------------------------------------------------------------
# 直流扫描切段 / 瞬态指标的辅助算法
# --------------------------------------------------------------------------
def _segment_by_turn(xs: list[float], ys: list[float]) -> list[tuple[int, int]]:
    """按「扫描量回头处」切段，返回 [(起, 止), ...]（左闭右开）。

    两维 `.dc` 的 rawfile 只记内层扫描量，外层每前进一步它就从 start 重走一遍，
    于是 x 序列是锯齿：0,1,2,3,4,5, 0,1,2,... 。内层单调上升时，看
    `xs[i] <= xs[i-1]` 就知道换段了；降序扫描（step<0）用镜像判据。

    只有「按点数切块」对不上时才走到这里——它是实测兜底，不猜参数。
    """
    n = len(xs)
    if n < 2:
        return [(0, n)]
    descending = xs[0] > xs[1]
    cuts = [0]
    for i in range(1, n):
        turned = xs[i] >= xs[i - 1] if descending else xs[i] <= xs[i - 1]
        if turned:
            cuts.append(i)
    cuts.append(n)
    return [(cuts[k], cuts[k + 1]) for k in range(len(cuts) - 1)]


def _si(value: float, unit: str = "") -> str:
    """工程记数法短标签：`0.0005` → `"0.5mA"`、`0.6` → `"0.6V"`、`1000` → `"1k"`。

    尾数控制在 [0.1, 1000)：所以 0.6V 不会被写成 600mV（图例里 0.6V 更好读），
    而 0.5mA 也不会写成 0.0005A。只用于图例文字，不参与任何计算。
    """
    v = float(value)
    if v == 0:
        return f"0{unit}"
    for scale, prefix in ((1e9, "G"), (1e6, "M"), (1e3, "k"), (1.0, ""),
                          (1e-3, "m"), (1e-6, "µ"), (1e-9, "n"), (1e-12, "p")):
        mant = abs(v) / scale
        if 0.1 <= mant < 1000.0:
            return f"{v / scale:.4g}{prefix}{unit}"
    return f"{v:.4g}{unit}"


def _check_tail(tail) -> float:
    try:
        t = float(tail)
    except (TypeError, ValueError):
        raise CCLConfigError(f"tail 必须是数字（0~1 的比例），收到 {tail!r}") from None
    if not (0 < t <= 1):
        raise CCLConfigError(f"tail 必须在 (0, 1] 之间，收到 {tail!r}（0.1 = 最后 10% 时间窗）")
    return t


def _check_levels(low, high) -> tuple[float, float]:
    try:
        lo, hi = float(low), float(high)
    except (TypeError, ValueError):
        raise CCLConfigError(f"low/high 必须是数字，收到 {low!r} / {high!r}") from None
    if not (0 <= lo < hi <= 1):
        raise CCLConfigError(
            f"阈值必须满足 0 ≤ low < high ≤ 1，收到 low={lo!r} high={hi!r}"
        )
    return lo, hi


def _tail_start(xs: list[float], tail: float) -> int:
    """最后 tail 比例时间窗的起始下标。"""
    if len(xs) < 2:
        return 0
    t0, t1 = xs[0], xs[-1]
    if t1 <= t0:
        return 0
    edge = t0 + (1.0 - tail) * (t1 - t0)
    for i, x in enumerate(xs):
        if x >= edge:
            return i
    return len(xs) - 1


def _tail_slice(xs: list[float], ys: list[float], tail: float) -> list[float]:
    seg = ys[_tail_start(xs, tail):]
    return seg or ys[-1:]


def _tail_mean(xs: list[float], ys: list[float], tail: float) -> float:
    seg = _tail_slice(xs, ys, tail)
    return sum(seg) / len(seg)


def _thr(low_level: float, high_level: float, frac: float) -> float:
    """把「摆幅的 frac 处」换算成具体电平（示波器的 10%/90% 口径）。"""
    return low_level + frac * (high_level - low_level)


def _crossing_time(xs: list[float], ys: list[float], target: float,
                   start: int = 0, falling: bool | None = None
                   ) -> tuple[int, float] | None:
    """从第 start 个样本起，找**第一次**穿过 target 的位置，线性插值。

    falling=None 不分方向；True 只认下降穿越；False 只认上升穿越。
    返回 (下标, 时刻)；找不到返回 None。
    """
    n = len(ys)
    if n == 0:
        return None
    if start == 0 and ys[0] == target and falling is None:
        return 0, xs[0]
    for i in range(max(1, start), n):
        y0, y1 = ys[i - 1], ys[i]
        if y0 == y1:
            if y1 == target and falling is None:
                return i, xs[i]
            continue
        if falling is True and not (y1 < y0):
            continue
        if falling is False and not (y1 > y0):
            continue
        if (y0 - target) * (y1 - target) > 0:
            continue
        x0, x1 = xs[i - 1], xs[i]
        t = (target - y0) / (y1 - y0)
        return i, x0 + t * (x1 - x0)
    return None



def _first_plateau(xs: list[float], ys: list[float], y0: float,
                   span: float) -> float | None:
    """找「首个跳变之后真正停住的一段」，返回该平台的值。

    判据：一段连续样本的峰峰值 ≤ 2%·span，且这段时长 ≥ 5%·记录时长。
    纯正弦的极值只是「过一下」（停留时间远短于 5% 周期），凑不出这样的平台；
    方波/脉冲串则有货真价实的高电平平台。与起点同值的平台会被跳过。
    """
    n = len(ys)
    if n < 3:
        return None
    total = xs[-1] - xs[0]
    if total <= 0:
        return None
    band = _PLATEAU_BAND * span
    min_dur = _PLATEAU_MIN_FRAC * total
    i = 0
    while i < n:
        j = i
        lo = hi = ys[i]
        while j + 1 < n:
            v = ys[j + 1]
            new_lo, new_hi = min(lo, v), max(hi, v)
            if new_hi - new_lo > band:
                break
            j += 1
            lo, hi = new_lo, new_hi
        if j > i and xs[j] - xs[i] >= min_dur:
            mid = (lo + hi) / 2.0
            if abs(mid - y0) > _PLATEAU_BAND * span:   # 跳过「还没跳变」的起始平台
                return mid
        i = max(j, i) + 1
    return None

