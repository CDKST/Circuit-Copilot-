"""CCL 器件库：把「电气意图」翻译成「SPICE 端子顺序 + 网表字段」。

## 这个文件为什么重要

CCL 里最容易错的东西不是数学，而是**端子顺序**。`R in out 1k` 和 `R out in 1k`
在电阻上等价，但 `C in out` 与 `C out in`、`X1 in n1 out OPA` 里引脚顺序错了，
仿真是会跑通的——只是结果全错，还不报错。所以每个器件类在这里显式声明
`kind` 与**有序** `pins`，并各自覆盖 `value_tokens()`。

## 约定

- 两端件引脚名固定为 `"a"` / `"b"`，第 1 个节点写 `a`，第 2 个写 `b`。
- 运放引脚固定为 `"inp"` / `"inn"` / `"out"`（同相、反相、输出），顺序与
  `copilot.topologies.opamp_subckt()` 里 `.subckt OPA inp inn out` 一致。
- `ref=None` 表示交给 `Circuit.add()` 自动分配位号。
- 参数越界一律抛 `CCLConfigError`，报错里带位号与参数名。

## 网表长什么样（便于对照）

    R1 in out 1.6k              ← Resistor("in","out",1.6e3)
    C1 out 0 100n               ← Capacitor("out",GND,100e-9)
    L1 in out 1m                ← Inductor("in","out",1e-3)
    V1 in 0 DC 0 AC 1           ← VoltageSource("in",GND,ac=1)
    I1 out 0 DC 1m AC 0         ← CurrentSource("out",GND,dc=1e-3)
    X1 in n1 out OPA_1e5_1p3e6  ← OpAmp(a0=1e5, gbw=1.3e6)  + 一段 .subckt
"""

from __future__ import annotations

import copy
import math

from .core import Component, Pin
from .errors import CCLConfigError

__all__ = [
    "Device",
    "Resistor",
    "Capacitor",
    "Inductor",
    "VoltageSource",
    "CurrentSource",
    "OpAmp",
    "Diode",
    "Bjt",
    "Mosfet",
    "Switch",
    "PulseSource",
    "SinSource",
    "MODEL_CARDS",
    "component_directives",
    "switch_model_name",
    "apply_switch_states",
]

# --------------------------------------------------------------------------
# 数值格式化：优先用 core-eng 的 ccl.format.fmt_value（唯一真相），
# 它还没交付时退回一个等价的最小实现，保证本模块任何时候都能独立工作。
# --------------------------------------------------------------------------
_FMT = None


def _fallback_fmt(value: float) -> str:
    """最小可用的 SPICE 数值格式化（仅在 ccl/format.py 缺失时使用）。

    规则：不用单位后缀（`1M` 这种歧义形式绝对不输出），只输出纯数字；
    太大/太小的量级才用科学计数法——ngspice-47 能正确解析 `1e-07`、`1e+06`。
    """
    if value == 0:
        return "0"
    if not math.isfinite(value):
        raise CCLConfigError(f"器件参数必须是有限数，收到 {value!r}")
    text = f"{value:.6g}"
    # .6g 在 1e-4 < |v| < 1e6 区间天然是纯小数形式，其余是科学计数法，都合法。
    return text


def _fmt(value: float) -> str:
    global _FMT
    if _FMT is None:
        try:  # pragma: no cover - 依赖队友进度
            from .format import fmt_value as _impl
        except Exception:  # ImportError 或模块内其它错误都退回本地实现
            _impl = _fallback_fmt
        _FMT = _impl
    return _FMT(value)


def _check_positive(value, name: str, ref: str | None, unit: str = "") -> float:
    """参数必须 > 0。带位号的报错，让人知道该改哪一行。"""
    where = f"器件 {ref} " if ref else ""
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise CCLConfigError(f"{where}{name} 必须是数字，收到 {value!r}") from None
    if not math.isfinite(v):
        raise CCLConfigError(f"{where}{name} 必须是有限数，收到 {v!r}")
    if v <= 0:
        raise CCLConfigError(f"{where}{name} 必须 > 0，收到 {v!r}{unit}")
    return v


# --------------------------------------------------------------------------
# 基类
# --------------------------------------------------------------------------
class Device(Component):
    """所有 CCL 器件的基类。

    两个作用：

    1. **修正 `clone()`**。`core.Component` 是 dataclass，它的 `clone()` 走
       `dataclasses.replace()`，会拿 `kind=/pins=` 去调子类构造函数——而子类的
       构造函数签名是 `(a, b, value, ref=...)`，必然炸。子电路内联（`Circuit.use`）
       依赖 `clone()`，所以这里改成基于 `copy.copy` 的实现。
    2. **提供 `directives()`** 钩子：需要宏模型/模型的器件（运放）返回 `.subckt`
       等指令，供编译层收集。
    """

    def clone(self, *, ref: str | None = None, pin_nodes: dict[str, str] | None = None) -> Component:
        new = copy.copy(self)
        new.ref = ref or self.ref
        if pin_nodes:
            new.pins = [Pin(p.name, pin_nodes.get(p.name, p.node)) for p in self.pins]
        else:
            new.pins = [Pin(p.name, p.node) for p in self.pins]
        new.params = dict(self.params)
        new.meta = dict(self.meta)
        return new

    def directives(self) -> list[str]:
        """该器件需要写进网表的 `.xxx` 指令（默认没有）。"""
        return []

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.ref or '(auto)'}: {'-'.join(self.nodes())}>"


class _TwoTerminal(Device):
    """两端件的公共部分：引脚 `a`（第 1 端子）、`b`（第 2 端子）。"""

    KIND = "?"

    def __init__(self, a, b, value, ref: str | None = None, *, params=None, meta=None,
                 model=None, label="值", **kw):
        if kw:
            raise CCLConfigError(
                f"{'器件 ' + ref + ' ' if ref else ''}{label}：不认识的参数 {sorted(kw)}；"
                f"只支持 value / ref / params / meta / model"
            )
        v = _check_positive(value, label, ref)
        super().__init__(
            kind=self.KIND,
            ref=ref or "",
            pins=[Pin("a", a), Pin("b", b)],
            value=v,
            model=model,
            params=dict(params or {}),
            meta=dict(meta or {}),
        )

    def value_tokens(self) -> list[str]:
        return [_fmt(self.value)]


# --------------------------------------------------------------------------
# 无源件
# --------------------------------------------------------------------------
class Resistor(_TwoTerminal):
    """电阻。

    引脚顺序：`a` → `b`（无极性，顺序不影响结果，但网表里按这个顺序写）

    网表：`R1 in out 1.6k`

    参数
        value   阻值，欧姆，必须 > 0
        ref     位号，默认 "R1"、"R2"…
    """

    KIND = "R"

    def __init__(self, a, b, value, ref: str | None = None, **kw):
        super().__init__(a, b, value, ref, label="电阻值", **kw)


class Capacitor(_TwoTerminal):
    """电容（无极性）。

    引脚顺序：`a` → `b`

    网表：`C1 out 0 100n`

    参数
        value   容值，法拉（100e-9 = 100nF），必须 > 0
    """

    KIND = "C"

    def __init__(self, a, b, value, ref: str | None = None, **kw):
        super().__init__(a, b, value, ref, label="电容值", **kw)


class Inductor(_TwoTerminal):
    """电感。

    引脚顺序：`a` → `b`

    网表：`L1 in out 1m`

    参数
        value   感值，亨利（1e-3 = 1mH），必须 > 0
    """

    KIND = "L"

    def __init__(self, a, b, value, ref: str | None = None, **kw):
        super().__init__(a, b, value, ref, label="电感值", **kw)


# --------------------------------------------------------------------------
# 独立源
# --------------------------------------------------------------------------
class _Source(Device):
    """独立源的公共部分：DC 工作点 + AC 小信号幅度。"""

    KIND = "?"

    def __init__(self, a, b, dc=0.0, ac=0.0, ref: str | None = None, **kw):
        where = f"器件 {ref} " if ref else ""
        try:
            dc = float(dc)
            ac = float(ac)
        except (TypeError, ValueError):
            raise CCLConfigError(f"{where}dc/ac 必须是数字，收到 dc={dc!r} ac={ac!r}") from None
        if not (math.isfinite(dc) and math.isfinite(ac)):
            raise CCLConfigError(f"{where}dc/ac 必须是有限数，收到 dc={dc!r} ac={ac!r}")
        if ac < 0:
            raise CCLConfigError(
                f"{where}AC 幅度必须 >= 0（相位要用复数幅度的话请自行在网表里写），收到 {ac!r}"
            )
        super().__init__(
            kind=self.KIND,
            ref=ref or "",
            pins=[Pin("a", a), Pin("b", b)],
            value=dc,
            params=dict(kw.pop("params", None) or {}),
            meta=dict(kw.pop("meta", None) or {}),
            model=kw.pop("model", None),
        )
        if kw:
            raise CCLConfigError(
                f"{where}不认识的参数：{sorted(kw)}；"
                f"独立源只支持 dc / ac / ref / params / meta"
            )
        self.dc = dc
        self.ac = ac

    def value_tokens(self) -> list[str]:
        # `DC <值> AC <值>`：两个都显式写出，避免 ngspice 把第二个数字当别的含义。
        return ["DC", _fmt(self.dc), "AC", _fmt(self.ac)]

    def clone(self, *, ref=None, pin_nodes=None):
        new = super().clone(ref=ref, pin_nodes=pin_nodes)
        new.dc, new.ac = self.dc, self.ac
        return new


class VoltageSource(_Source):
    """独立电压源。

    引脚顺序：`a`（正端）→ `b`（负端）。电压定义是 `V(a)-V(b) = dc`，
    所以「in 到地」要写 `VoltageSource("in", GND, ...)`，反过来就变成负电压。

    网表：`V1 in 0 DC 0 AC 1`

    参数
        dc  DC 工作点电压，伏（可负）
        ac  小信号 AC 幅度，伏（一般 1，便于直接读增益）；必须 >= 0

    注意
        同时 `dc=0` 且 `ac=0` 的源是**允许**的：它在网表里是一段对地的 0V 短接，
        .op 里没有贡献，.ac 里所有波形恒为 0（Solution.db() 会给出 -300）。
        通常是笔误（想做分压却忘了给 AC 幅度），所以这里说明清楚。
    """

    KIND = "V"

    def __init__(self, a, b, dc=0.0, ac=0.0, ref: str | None = None, **kw):
        super().__init__(a, b, dc=dc, ac=ac, ref=ref, **kw)


class CurrentSource(_Source):
    """独立电流源。

    引脚顺序：`a` → `b`，电流方向是**从 a 经源内部流向 b**（SPICE 约定：
    正电流从第一个节点流出外部回路）。`CurrentSource("out", GND, dc=1e-3)`
    表示「向 out 节点灌入 1mA」时，实际灌入方向取决于两端接法，务必对照 .op 结果确认。

    网表：`I1 out 0 DC 1m AC 0`

    参数
        dc  DC 电流，安（可负）
        ac  小信号 AC 幅度，安；必须 >= 0

    注意
        `dc=0` 且 `ac=0` 也是合法网表（一个开路支路），但几乎总是笔误。
    """

    KIND = "I"

    def __init__(self, a, b, dc=0.0, ac=0.0, ref: str | None = None, **kw):
        super().__init__(a, b, dc=dc, ac=ac, ref=ref, **kw)


# --------------------------------------------------------------------------
# 运放
# --------------------------------------------------------------------------
def _num_tag(value: float) -> str:
    """把数值变成能放进 SPICE 名字里的片段：1.3e6 → '1p3e6'（点会破坏名字）。"""
    text = f"{value:.6g}"
    return (
        text.replace("+", "")
        .replace("-", "m")
        .replace(".", "p")
        .replace(" ", "")
    )


class OpAmp(Device):
    """运放（单极点、含 GBW 限制的小信号宏模型）。

    引脚顺序：`inp`（同相 +）→ `inn`（反相 −）→ `out`
    与 `copilot.topologies.opamp_subckt()` 里 `.subckt OPA inp inn out` 严格一致。

    三端器件：节点按引脚顺序做位置参数，同名关键字同样可用。

        OpAmp("src", "sum", "out", gbw=1.3e6)       # 按引脚顺序
        OpAmp(inp="src", inn="sum", out="out")      # 关键字，不易读错

    网表：
        X1 in n1 out OPA_1e5_1p3e6
        .subckt OPA_1e5_1p3e6 inp inn out
        Rin inp inn 10Meg
        E0 ox1 0 inp inn 1e5          ← 开环增益 A0
        R0 ox1 ox2 1
        C0 ox2 0 <A0/(2π·GBW)>        ← 主极点，A0·fp = GBW
        Rout ox2 out 50
        .ends

    参数
        gbw   增益带宽积，Hz（必须 > 0）
        a0    开环直流增益，倍数（必须 > 0）

    ## 为什么用这个模型，而不是自己写一个理想运放

    `opamp_subckt()` 是项目里已经验证过的行为级模型：单极点、纯线性（电阻/电容/
    受控源），所以 AC 分析必定收敛。**不要**改成带限幅 B 源的版本——那种结构在
    AC 分析里会让 gmin stepping 不收敛；也**不要**用理想 VCVS（`E out 0 inp inn A0`
    加无限带宽）：它没有 GBW 限制，历史上因此算出过 CMRR=165dB 这种物理不可能的
    数字，结论全是假的。

    ## 这是个「小信号」模型，注意边界

    - 没有电源引脚，也没有输出限幅：.op / .ac 用它算增益、带宽、相位裕度是对的，
      **不能用它判断输出是否削顶或轨到轨**（那要在 Python 侧拿峰值和电源轨比）。
    - 共模抑制是理想的（无限 CMRR），所以共模相关指标它给不出真实值。
    - 输入阻抗 10Meg、输出电阻 50Ω 是固定值，见 `opamp_subckt()`。
    """

    _SUBCKT = "OPA"   # opamp_subckt() 里的原始名字，我们只替换成唯一名字

    def __init__(self, inp, inn, out, *, gbw: float = 1e6, a0: float = 1e5,
                 ref: str | None = None, **kw):
        gbw = _check_positive(gbw, "gbw（增益带宽积）", ref, " Hz")
        a0 = _check_positive(a0, "a0（开环直流增益）", ref, " 倍")
        self.gbw = gbw
        self.a0 = a0
        self.subckt = f"OPA_{_num_tag(a0)}_{_num_tag(gbw)}"
        super().__init__(
            kind="X",
            ref=ref or "",
            pins=[Pin("inp", inp), Pin("inn", inn), Pin("out", out)],
            value=None,
            model=self.subckt,
            params=dict(kw.pop("params", None) or {}),
            meta=dict(kw.pop("meta", None) or {}),
        )
        if kw:
            raise CCLConfigError(
                f"{'器件 ' + ref + ' ' if ref else ''}运放不认识的参数：{sorted(kw)}；"
                f"只支持 gbw / a0 / ref / params / meta"
            )

    def clone(self, *, ref=None, pin_nodes=None):
        new = super().clone(ref=ref, pin_nodes=pin_nodes)
        new.gbw, new.a0, new.subckt = self.gbw, self.a0, self.subckt
        return new

    # ---- 网表字段 ----
    def value_tokens(self) -> list[str]:
        tokens = [self.subckt]
        for k, v in self.params.items():
            tokens.append(f"{k}={_fmt(v) if isinstance(v, (int, float)) else v}")
        return tokens

    # ---- 宏模型 ----
    def subckt_text(self) -> str:
        """本运放的 .subckt 定义（复用已验证的 opamp_subckt，只换名字）。"""
        from copilot.topologies import opamp_subckt

        lines = opamp_subckt(self.a0, self.gbw).splitlines()
        # 第一行是 ".subckt OPA inp inn out"，把 OPA 换成唯一名字，
        # 否则两个参数不同的运放会共用一个模型（静默出错，最难查）。
        if lines and lines[0].lower().startswith(".subckt"):
            lines[0] = f".subckt {self.subckt} inp inn out"
        return "\n".join(lines)

    def directives(self) -> list[str]:
        """整段 .subckt（含 .ends），作为一个字符串返回，由编译层连续写入。"""
        return [self.subckt_text()]


# ==========================================================================
# M2：半导体器件（二极管 / 三极管 / MOSFET）
#
# 为什么不给理想模型：理想的二极管（0.7V 恒压）、理想的 BJT（β 恒定）
# 会让用户算出一堆在真实电路里不成立的结论。这里用真实器件的 SPICE 模型卡，
# 让 .op 里能看到真实工作点、真实正向压降、真实饱和边界。
#
# 模型命名注意：SPICE 模型名不能以数字开头，所以 1N4148 的模型名是 `D1N4148`。
# ==========================================================================

# 真实器件模型卡（业界通用参数，ngspice-47 实测可用）
MODEL_CARDS: dict[str, tuple[str, str]] = {
    "D1N4148": ("D", "Is=2.52n Rs=.568 N=1.752 Cjo=4p M=.4 tt=20n"),
    "D1N4007": ("D", "Is=7.023n Rs=.04 N=1.8 Cjo=20p M=.5 tt=5u"),
    "D1N5819": ("D", "Is=31.7u Rs=.05 N=1.05 Cjo=180p M=.4 tt=10n"),
    "Q2N3904": ("NPN", "Is=6.734f Xti=3 Eg=1.11 Vaf=74.03 Bf=416.4 Ne=1.259 Ise=6.734f "
                       "Ikf=.06678 Xtb=1.5 Br=.7371 Nc=2 Isc=0 Ikr=0 Rc=1 Cjc=3.638p "
                       "Mjc=.3085 Vjc=.75 Fc=.5 Cje=4.493p Mje=.2593 Vje=.75 Tr=239.5n "
                       "Tf=301.2p Itf=.4 Vtf=4 Xtf=2 Rb=10"),
    "Q2N3906": ("PNP", "Is=1.41f Xti=3 Eg=1.11 Vaf=18.7 Bf=180.7 Ne=1.5 Ise=0 Ikf=80m "
                       "Xtb=2.2 Br=4.977 Nc=2 Isc=0 Ikr=0 Rc=2.5 Cjc=9.728p Mjc=.5776 "
                       "Vjc=.75 Fc=.5 Cje=8.063p Mje=.3677 Vje=.75 Tr=33.42n Tf=179.3p "
                       "Itf=.65 Vtf=5 Xtf=8 Rb=10"),
    # MOSFET 用 Level-1（Shichman-Hodges）：收敛性最好，教学/工程估算够用。
    # 真实功率 MOS 请换 VDMOS 或厂商子电路模型。
    "M2N7002": ("NMOS", "Level=1 Vto=2.1 Kp=0.15 Lambda=0.02 Cgso=1.5n Cgdo=0.2n Cgbo=0.2n"),
    "MIRF540": ("NMOS", "Level=1 Vto=3.5 Kp=20 Lambda=0.01 Cgso=50n Cgdo=5n Cgbo=5n"),
}


class _Modeled(Device):
    """需要 `.model` 卡的器件的公共部分。"""

    MODEL_KIND = ""      # SPICE 模型类型：D / NPN / PNP / NMOS / PMOS
    DEFAULT_MODEL = ""

    def __init__(self, model_name: str | None, pins: list[Pin], ref: str | None,
                 extra_params: dict | None = None):
        name = (model_name or self.DEFAULT_MODEL).strip()
        if not name:
            raise CCLConfigError(f"{self.__class__.__name__} 必须给 model")
        if name[0].isdigit():
            raise CCLConfigError(
                f"模型名 {name!r} 不能以数字开头（SPICE 限制）。"
                f"常用器件请用内置名，如 {sorted(MODEL_CARDS)}"
            )
        # 注意：模型参数**不能**放进 comp.params ——
        # compile 会把 params 作为 "key=value" 追加到**器件实例行**，
        # 而 ngspice 只认 .model 卡里的参数，实例行多写会报
        #   unknown parameter (is)  →  incomplete or empty netlist
        # 所以单独存 self.model_params，只用于生成 .model 卡。
        super().__init__(kind=self.KIND, ref=ref or "", pins=pins, value=None,
                         model=name, params={}, meta={})
        self.model_params: dict = dict(extra_params or {})

    def model_card(self) -> str:
        """该器件要写进网表的 .model 行。内置器件用真实模型卡，自定义器件用 model_params。"""
        name = self.model or self.DEFAULT_MODEL
        if name in MODEL_CARDS:
            kind, body = MODEL_CARDS[name]
        else:
            kind = self.MODEL_KIND
            mp = getattr(self, "model_params", None) or {}
            if not mp:
                raise CCLConfigError(
                    f"自定义模型 {name!r} 没有给出参数。"
                    f"请传 model_params={{...}}，或改用内置模型 {sorted(MODEL_CARDS)}"
                )
            body = " ".join(f"{k}={v}" for k, v in mp.items())
        return f".model {name} {kind}({body})"

    def directives(self) -> list[str]:
        return [self.model_card()]

    def clone(self, *, ref=None, pin_nodes=None):
        new = super().clone(ref=ref, pin_nodes=pin_nodes)
        new.model_params = dict(getattr(self, "model_params", None) or {})
        return new


class Diode(_Modeled):
    """二极管。

    引脚顺序：`a`（阳极）→ `k`（阴极），电流方向 a → k。
    SPICE 端子顺序：`D<name> ANODE CATHODE MODEL` —— 反了会得到一个
    「永远反向偏置」的二极管，而且仿真不报错。

    网表：`D1 a k D1N4148` + `.model D1N4148 D(Is=2.52n ...)`

    内置器件：D1N4148（小信号）、D1N4007（整流）、D1N5819（肖特基）
    """

    KIND = "D"
    MODEL_KIND = "D"
    DEFAULT_MODEL = "D1N4148"

    def __init__(self, a, k, model=None, ref: str | None = None, *, model_params=None,
                 area: float | None = None, **kw):
        if kw:
            raise CCLConfigError(f"二极管不认识的参数 {sorted(kw)}；只支持 model/model_params/area/ref")
        if area is not None and (area <= 0 or not math.isfinite(area)):
            raise CCLConfigError(f"器件 {ref or '(auto)'} 的 area 必须 > 0，收到 {area!r}")
        super().__init__(model, [Pin("a", a), Pin("k", k)], ref, model_params)
        self.area = area

    def value_tokens(self) -> list[str]:
        toks = [self.model or self.DEFAULT_MODEL]
        if self.area is not None:
            toks.append(_fmt(self.area))
        return toks

    def clone(self, *, ref=None, pin_nodes=None):
        new = super().clone(ref=ref, pin_nodes=pin_nodes)
        new.area = self.area
        return new


class Bjt(_Modeled):
    """双极型三极管（NPN / PNP）。

    引脚顺序：`c`（集电极）→ `b`（基极）→ `e`（发射极）。
    SPICE 端子顺序：`Q<name> COLLECTOR BASE EMITTER MODEL`
    —— 这个顺序错得最隐蔽：接反了会跑出一个反向放大区，数字「看着正常」。

    网表：`Q1 c b e Q2N3904` + `.model Q2N3904 NPN(...)`

    内置器件：Q2N3904（NPN）、Q2N3906（PNP）
    """

    KIND = "Q"
    MODEL_KIND = "NPN"
    DEFAULT_MODEL = "Q2N3904"

    def __init__(self, c, b, e, model=None, ref: str | None = None, *, model_params=None, **kw):
        if kw:
            raise CCLConfigError(f"三极管不认识的参数 {sorted(kw)}；只支持 model/model_params/ref")
        super().__init__(model, [Pin("c", c), Pin("b", b), Pin("e", e)], ref, model_params)

    def value_tokens(self) -> list[str]:
        return [self.model or self.DEFAULT_MODEL]


class Mosfet(_Modeled):
    """MOSFET（NMOS / PMOS，Level-1 模型）。

    引脚顺序：`d`（漏）→ `g`（栅）→ `s`（源）→ `b`（衬底/体）。
    SPICE 端子顺序：`M<name> DRAIN GATE SOURCE BULK MODEL`
    `bulk` 省略时自动接到源极（网表里是 `M1 d g s s model`），这是最常见的接法。

    网表：`M1 d g s s M2N7002` + `.model M2N7002 NMOS(Level=1 ...)`

    内置器件：M2N7002、MIRF540（都是 Level-1 简化模型，收敛优先）
    """

    KIND = "M"
    MODEL_KIND = "NMOS"
    DEFAULT_MODEL = "M2N7002"

    def __init__(self, d, g, s, bulk=None, model=None, ref: str | None = None,
                 *, model_params=None, **kw):
        if kw:
            raise CCLConfigError(f"MOSFET 不认识的参数 {sorted(kw)}；只支持 model/model_params/bulk/ref")
        super().__init__(model, [Pin("d", d), Pin("g", g), Pin("s", s),
                                 Pin("b", bulk if bulk is not None else s)], ref, model_params)

    def value_tokens(self) -> list[str]:
        return [self.model or self.DEFAULT_MODEL]


# ==========================================================================
# 开关（电压控制理想开关，ngspice `S` 元件）
# ==========================================================================

#: 电压控制开关的网络表关键字。ngspice 的 `S` 元件需要配 `.model <name> SW(...)`。
SWITCH_KIND = "SW"


def switch_model_name(comp) -> str:
    """开关要用的 `.model` 名字。

    **每个开关一个独立 model 名**（`SW_MAXON_0p01` + 参数后缀），同类参数复用同一个
    名字。理由写在 `Switch` 的类文档里（重复声明同名 model 时 ngspice 静默只认
    最后一份——见 `Switch` 的实测记录）。
    """
    # ⚑ **Vt 必须进名字**。ngspice 对同名 .model 重复声明不报错、静默只认
    # 一份，于是两个 ron/roff 相同但阈值不同的开关会互相偷换阈值。
    # 实测：SW1(Vt=2.5) 与 SW2(Vt=4.0) 撞名 → 控制 3V 时两个都导通；
    # 而且「改 Vt 强制状态」那条路会把**别的开关**一起改掉。
    vt = getattr(comp, "on_voltage", 2.5)
    return (f"SW_{_num_tag(getattr(comp, 'ron', 0.01))}_"
            f"{_num_tag(getattr(comp, 'roff', 1e9))}_{_num_tag(vt)}")


def switch_model_card(comp) -> str:
    """开关的 `.model` 行：`SW(Ron=.. Roff=.. Vt=..)`。"""
    return (f".model {switch_model_name(comp)} SW(Ron={_fmt(comp.ron)} "
            f"Roff={_fmt(comp.roff)} Vt={_fmt(comp.on_voltage)})")


class Switch(Device):
    """电压控制理想开关（SPICE `S` 元件）。

    引脚顺序：`a` / `b`（被开关的两端）+ 第 3、4 端子是**控制端** `ctrl` 与参考点。
    SPICE 语法：`S<ref> <a> <b> <ctrl> 0 <model>` —— 控制量为 `V(ctrl) - V(0)`。

        Switch("a", "b", "ctrl")          # 控制端参考地，最常见的接法
        c.SW("a", "b", "ctrl_net")        # 同上

    网表：
        S1 a b ctrl 0 SW_MAXON_0p01_1000000000
        .model SW_MAXON_0p01_1000000000 SW(Ron=0.01 Roff=1e9 Vt=2.5)

    ## 参数

    on_voltage  Vt，导通阈值电压（伏）。`V(ctrl) > Vt` 导通，`< Vt` 断开。
                **实测 ngspice-47**：省略 Vt 时默认 Vt=0，于是「控制端悬空/0V」
                的开关会处于导通状态——这与直觉相反，所以 CCL 明写 Vt。
    ron         导通电阻，欧。默认 0.01Ω（电流几十 mA 时压降约 0.2mV，可忽略）
    roff        断开电阻，欧。默认 1e9Ω（1GΩ）。**断开不等于理想开路**：
                5V 回路里仍会漏 ~5nA 量级，所以「断开时 LED 电流 ≈ 0」是 ≈0
                而不是恒等于 0。想要更小漏电流就把 roff 调到 1e12 以上。
    model       给这个开关起一个模型名（可选）。不给就用参数派生的唯一名字。

    ## 为什么每个开关一个 model（而不是共用一个）

    实测（ngspice-47）：
      - 多个 `S` 元件**共用**同名 model 完全正常，不报错；
      - 但同一个 model 名被声明**.model 两次且参数不同**时，ngspice **不报错、
        不警告**，静默只认后一份（实测：先声明 Ron=0.01、再声明 Ron=100，
        分压结果按 Ron=100 算）。两个开关若一个想改 ron、另一个不改，
        共用名字就会让**其中一个的 ron 被偷偷换掉**，而且全程无提示。

    所以 CCL 的规则是：**模型名由 (ron, roff) 派生**——参数相同的开关自然复用
    同一个名字（网表里只有一份 `.model`，编译层 `_directives()` 会按文本去重）；
    参数不同的开关拿到不同名字，各写一份 `.model`。

    ⚠️ Vt **不进**模型名：这样 `switch_states` 才能把 Vt 改成 `±(1+|V(ctrl)|)`
    来强制通断（见 `ccl.runner` 里的说明），而不会因此产生两份同名不同 Vt 的
    `.model`。

    ## 状态覆盖

    `ccl.runner` 会把 `switch_states` 落成两种改动，都不碰用户代码文本：
      1. 这个控制节点上挂着**独立电压源** → 直接改那个源的 DC 值（最干净）；
      2. 否则改本开关 `.model` 的 Vt 到 `±(1+|V(ctrl)|)`，把结论**逼**出来。
    """

    KIND = SWITCH_KIND

    def __init__(self, a, b, ctrl, *, on_voltage: float = 2.5, ron: float = 0.01,
                 roff: float = 1e9, model: str | None = None,
                 ref: str | None = None, **kw):
        where = f"器件 {ref} " if ref else ""
        ron = _check_positive(ron, "ron（导通电阻）", ref, " Ω")
        roff = _check_positive(roff, "roff（断开电阻）", ref, " Ω")
        if roff <= ron:
            raise CCLConfigError(
                f"{where}roff({roff:g}Ω) 必须大于 ron({ron:g}Ω)，否则开关断开时比导通更通"
            )
        try:
            on_voltage = float(on_voltage)
        except (TypeError, ValueError):
            raise CCLConfigError(
                f"{where}on_voltage（Vt 阈值）必须是数字，收到 {on_voltage!r}") from None
        if not math.isfinite(on_voltage):
            raise CCLConfigError(f"{where}on_voltage 必须是有限数，收到 {on_voltage!r}")
        if model is not None and (not str(model).strip() or any(
                ch.isspace() for ch in str(model))):
            raise CCLConfigError(f"{where}model 名不能为空或含空白，收到 {model!r}")
        if kw:
            raise CCLConfigError(
                f"{where}开关不认识的参数 {sorted(kw)}；"
                f"只支持 on_voltage / ron / roff / model / ref / params / meta"
            )
        super().__init__(
            kind=self.KIND,
            ref=ref or "",
            pins=[Pin("a", a), Pin("b", b), Pin("ctrl", ctrl), Pin("ref", "0")],
            value=ron,
            model=str(model).strip() if model else None,
            params={},
            meta={},
        )
        self.on_voltage = on_voltage
        self.ron = ron
        self.roff = roff
        self.ctrl_blatant = False          # 由 apply_switch_states 置位（见下）

    # ---- 网表字段：`S1 a b ctrl 0 <model>` 里的 model ----
    def model_name(self) -> str:
        return self.model or switch_model_name(self)

    def value_tokens(self) -> list[str]:
        return [self.model_name()]

    def directives(self) -> list[str]:
        return [switch_model_card(self)]

    def clone(self, *, ref=None, pin_nodes=None):
        new = super().clone(ref=ref, pin_nodes=pin_nodes)
        new.on_voltage, new.ron, new.roff = self.on_voltage, self.ron, self.roff
        new.ctrl_blatant = self.ctrl_blatant
        return new

    def describe(self) -> str:
        return (f"{self.ref}({self.kind}) {self.node('a')}-{self.node('b')} "
                f"控制于 {self.node('ctrl')}（Vt={self.on_voltage:g}V）")


# ---- 开关状态覆盖 -------------------------------------------------------
#: `switch_states` 里认的「开」/「关」写法
_SWITCH_ON_WORDS = frozenset({"on", "closed", "close", "1", "true", "通", "闭合", "开"})
_SWITCH_OFF_WORDS = frozenset({"off", "open", "0", "false", "断", "断开", "关"})


def _find_ctrl_source(circuit, node: str):
    """找**接在控制节点上的独立电压源**，返回 (器件, 极性)；没有就 (None, 0)。

    这是「开关状态覆盖」的首选路径：开关的控制端几乎总是接一个逻辑电平
    （`Vctl ctrl 0 DC 5`），把这个源的 DC 值改掉，等于「把逻辑电平拨到另一档」，
    物理含义最直白，且对 op / tran / dc 三种分析都成立。

    极性：源正端接控制节点（`V ctrl 0`）为 +1；控制端接源负端（`V 0 ctrl`）为 -1
    —— 那种接法下「给 5V」实际是 -5V，必须翻符号。

    ⚠️ 早先这里按「位号 == 节点名」去匹配，永远匹配不上（控制节点叫 ctrl，
    源的位号叫 V2），于是每次都静默退回改 Vt 的那条路：功能看起来能用，
    却从没走过最干净的一条。
    """
    node = str(node)
    for comp in getattr(circuit, "components", []) or []:
        if str(getattr(comp, "kind", "")).upper() != "V":
            continue
        # ⚑ 只认**真的输出 DC 电平**的源。PULSE / SIN 源的 KIND 也是 'V'，
        # 但它们的网表是 `PULSE(...)` / `SIN(...)`，根本没有 dc 这个位置：
        # 改 comp.dc 之后网表一个字节都不会变，却仍然回报 {"SW1": "source"}，
        # 于是用户点了开关**什么都没发生**（实测：tran 下 on/off 的 LED 峰值
        # 完全相同 0.0222758A）。用 PULSE 驱动开关恰恰是瞬态里最常见的接法。
        try:
            toks = comp.value_tokens()
        except Exception:
            continue
        if not toks or str(toks[0]).upper() != "DC":
            continue
        pins = list(getattr(comp, "pins", []) or [])
        if len(pins) < 2:
            continue
        if str(pins[0].node) == node:
            return comp, 1
        if str(pins[1].node) == node:
            return comp, -1
    return None, 0


def _find_any_source(circuit) -> bool:
    """电路里有没有任何独立源（V / I）。只用于错误信息更准确。"""
    for comp in getattr(circuit, "components", []) or []:
        if str(getattr(comp, "kind", "")).upper() in ("V", "I"):
            return True
    return False


def apply_switch_states(circuit, states: dict | None, *,
                        warnings: list[str] | None = None) -> dict[str, str]:
    """按 `{"SW1": "on"|"off"}` 覆盖开关状态，**就地改电路对象**（不动用户代码文本）。

    返回 `{位号: 实际采用的实现方式}`，实现方式取值：
        "source"   改了这个控制节点上独立电压源的 DC 值（最干净的做法）
        "vt"       没有可改的源，改本开关 .model 的 Vt 把结论逼出来
    **只有真的生效的开关**才出现在返回值里。

    `warnings` 给了就往里追加提示（上位把它挂到响应的 warnings 字段）。

    未知位号**不是错误**（见下面「为什么忽略」），传 `warnings` 列表即可拿到提示。

    为什么认「控制节点上的独立源」：开关的控制端在真实电路里几乎总是接一个
    逻辑电平（`Vctl 5V`）。直接改它的 DC 值等于「把那个逻辑电平拨到另一档」，
    物理含义最直白，而且对 op / tran / dc 三种分析都成立。

    为什么退回改 Vt 也可靠：ngspice 的 `S` 开关判据就是 `V(ctrl) > Vt`。
    把 Vt 放到 `V(ctrl)` 的另一侧（正负各加 1V 余量）就能强制通/断，
    与 `ron/roff` 无关，也不需要知道控制电压到底是多少。

    为什么**未知位号只警告不报错**（实测事故）：界面上点过一下开关之后，用户把
    代码里的 `c.SW(...)` 删了（或改名了），前端仍把旧的 `{"SW1": "on"}` 发上来。
    早先这里抛 `CCLConfigError` → `execute()` 把整次运行判失败 → 用户明明写对了
    电路却「跑一次就失败」，而且错误信息指向的是界面状态不是代码。
    开关覆盖只是**界面附加意图**，它失效不该否决整段电路：忽略它、写进 warnings、
    电路照常仿真（全部位号都不存在也照跑，用户至少能看到电路和波形）。
    """
    if not states:
        return {}
    if not isinstance(states, dict):
        raise CCLConfigError("switch_states 必须是 {位号: \"on\"/\"off\"} 形式的字典")

    switches = [c for c in getattr(circuit, "components", []) or []
                if isinstance(c, Switch)]
    by_ref = {str(c.ref).lower(): c for c in switches}
    done: dict[str, str] = {}

    for raw_ref, raw_state in states.items():
        ref = str(raw_ref or "").strip()
        sw = by_ref.get(ref.lower())
        if sw is None:
            # 未知位号：忽略 + 提示，绝不否决整次运行（理由见 docstring）。
            if warnings is not None:
                avail = [c.ref for c in switches]
                warnings.append(
                    f"界面上的开关覆盖状态 {ref or '（空位号）'} 已忽略："
                    f"代码里已经没有这个开关了"
                    f"（现有开关：{'、'.join(avail) if avail else '无'}）"
                )
            continue
        word = str(raw_state if raw_state is not None else "").strip().lower()
        if word in _SWITCH_ON_WORDS:
            want_on = True
        elif word in _SWITCH_OFF_WORDS:
            want_on = False
        else:
            raise CCLConfigError(
                f"switch_states[{ref!r}] = {raw_state!r} 认不出来；"
                f"请写 \"on\" 或 \"off\""
            )

        ctrl = sw.node("ctrl")
        src, polarity = _find_ctrl_source(circuit, ctrl)
        # 控制节点上挂着独立电压源 → 改它的 DC 值（ac 幅度一并清零，
        # 免得一次小信号扫频把这个开关扫成半个导通）
        if src is not None:
            magnitude = abs(float(getattr(src, "dc", 0.0))) or 5.0
            src.dc = polarity * (magnitude if want_on else 0.0)
            src.value = src.dc
            try:
                src.ac = 0.0
            except AttributeError:
                pass
            done[sw.ref] = "source"
            continue

        # 没有可改的源：改本开关的 Vt，把状态逼出来
        # 先测一次当前控制电压，把 Vt 放到它的另一侧并留 1V 余量。
        # 注意「不跨过 0」：控制电压常在 0V 附近，`Vt = V+1` 与 `Vt = V-1` 可能都落在
        # 同一侧（实测踩到过——导通后控制点被拉高，Vt 反而又落到它下面，状态自相
        # 矛盾）。夹在 0 的另一侧才与电路当前状态无关。测不到就按 ±1kV 硬判，
        # 对任何 ±1000V 以内的电路都成立。
        # ⚑ 判据必须**与控制波形无关**：把 Vt 推到控制电压永远到不了的量级。
        #   want_on  → Vt = -1000V（任何 |V(ctrl)|<1000V 都 > Vt → 恒闭合）
        #   want_off → Vt = +1000V（任何 |V(ctrl)|<1000V 都 < Vt → 恒断开）
        #
        # 早先的做法是「先跑一次 circuit.op() 量出 V(ctrl)，再把 Vt 放到它另一侧」，
        # 有两个毛病：
        #   1) 对**时变控制**（PULSE/SIN 驱动开关，瞬态里最常见的接法）完全失效：
        #      t=0 时 V(ctrl)=0，want_off 得到 Vt=1，而脉冲升到 5V 时 5>1 仍然闭合
        #      —— 实测「关」和「开」的 LED 峰值电流一样，点了等于没点。
        #   2) 白跑一次 ngspice（op 也是真仿真）。
        # 固定 -1000/+1000 对静态电平和任何波形都成立，且不再多跑一次仿真。
        if not _find_any_source(circuit):
            raise CCLConfigError(
                f"开关 {sw.ref} 的控制节点 {ctrl!r} 上没有独立电压源，无法强制它的状态；"
                f"请给控制端接一个独立源（如 c.V(ctrl, GND, dc=5)）"
            )
        sw.on_voltage = -1000.0 if want_on else 1000.0
        sw.ctrl_blatant = True
        done[sw.ref] = "vt"
    return done


# ==========================================================================
# M2：时域激励（脉冲 / 正弦）
# ==========================================================================

class PulseSource(Device):
    """脉冲电压源，用于瞬态（阶跃响应、开关过程）。

    SPICE 语法：`V1 a b PULSE(V1 V2 TD TR TF PW PER)`
        v1 初始值   v2 脉冲值   td 延迟   tr 上升时间
        tf 下降时间 pw 脉宽     per 周期

    注意：`PULSE` 只在 `.tran` 里有效；做 `.ac` 时它的 AC 幅度按 0 处理，
    所以扫频请另用带 `ac=` 的独立源，或两者各写一个。
    """

    KIND = "V"

    def __init__(self, a, b, v1=0.0, v2=5.0, td=0.0, tr=1e-9, tf=1e-9,
                 pw=500e-6, per=1e-3, ref: str | None = None, **kw):
        where = f"器件 {ref} " if ref else ""
        vals = dict(v1=v1, v2=v2, td=td, tr=tr, tf=tf, pw=pw, per=per)
        for k, v in vals.items():
            try:
                vals[k] = float(v)
            except (TypeError, ValueError):
                raise CCLConfigError(f"{where}{k} 必须是数字，收到 {v!r}") from None
            if not math.isfinite(vals[k]):
                raise CCLConfigError(f"{where}{k} 必须是有限数，收到 {v!r}")
        if vals["tr"] <= 0 or vals["tf"] <= 0:
            raise CCLConfigError(f"{where}上升/下降时间必须 > 0（理想边沿用 1e-9），"
                                 f"收到 tr={tr!r} tf={tf!r}")
        if vals["pw"] <= 0 or vals["per"] <= 0:
            raise CCLConfigError(f"{where}脉宽与周期必须 > 0，收到 pw={pw!r} per={per!r}")
        if vals["pw"] >= vals["per"]:
            raise CCLConfigError(f"{where}脉宽 {vals['pw']:g}s 不能 >= 周期 {vals['per']:g}s")
        if kw:
            raise CCLConfigError(f"{where}不认识的参数 {sorted(kw)}")
        super().__init__(kind=self.KIND, ref=ref or "",
                         pins=[Pin("a", a), Pin("b", b)], value=vals["v2"], params={}, meta={})
        self.spec = vals

    def value_tokens(self) -> list[str]:
        s = self.spec
        # 逗号分隔：既符合 ngspice 语法（实测空格/逗号都接受），
        # 又是一个不含空白的单 token —— compile 层有「token 不得含空白」的保护，
        # 那条保护是防真正拆错列的 bug，不该为了这里削弱它。
        return [f"PULSE({_fmt(s['v1'])},{_fmt(s['v2'])},{_fmt(s['td'])},"
                f"{_fmt(s['tr'])},{_fmt(s['tf'])},{_fmt(s['pw'])},{_fmt(s['per'])})"]

    def clone(self, *, ref=None, pin_nodes=None):
        new = super().clone(ref=ref, pin_nodes=pin_nodes)
        new.spec = dict(self.spec)
        return new


class SinSource(Device):
    """正弦电压源，用于瞬态与交流。

    SPICE 语法：`V1 a b SIN(VO VA FREQ TD THETA)`
        vo 直流偏置   va 幅度   freq 频率   td 延迟   theta 阻尼系数(1/s)

    网表：`V1 in 0 SIN(0 1 1000 0 0)`
    """

    KIND = "V"

    def __init__(self, a, b, vo=0.0, va=1.0, freq=1e3, td=0.0, theta=0.0,
                 ref: str | None = None, **kw):
        where = f"器件 {ref} " if ref else ""
        vals = {}
        for k, v in dict(vo=vo, va=va, freq=freq, td=td, theta=theta).items():
            try:
                vals[k] = float(v)
            except (TypeError, ValueError):
                raise CCLConfigError(f"{where}{k} 必须是数字，收到 {v!r}") from None
            if not math.isfinite(vals[k]):
                raise CCLConfigError(f"{where}{k} 必须是有限数，收到 {v!r}")
        if vals["freq"] <= 0:
            raise CCLConfigError(f"{where}频率必须 > 0，收到 {freq!r}")
        if vals["va"] < 0:
            raise CCLConfigError(f"{where}幅度必须 >= 0，收到 {va!r}")
        if kw:
            raise CCLConfigError(f"{where}不认识的参数 {sorted(kw)}")
        super().__init__(kind=self.KIND, ref=ref or "",
                         pins=[Pin("a", a), Pin("b", b)], value=vals["va"], params={}, meta={})
        self.spec = vals

    def value_tokens(self) -> list[str]:
        s = self.spec
        return [f"SIN({_fmt(s['vo'])},{_fmt(s['va'])},{_fmt(s['freq'])},"
                f"{_fmt(s['td'])},{_fmt(s['theta'])})"]

    def clone(self, *, ref=None, pin_nodes=None):
        new = super().clone(ref=ref, pin_nodes=pin_nodes)
        new.spec = dict(self.spec)
        return new


# --------------------------------------------------------------------------
# 宏模型收集
# --------------------------------------------------------------------------
def component_directives(circuit) -> list[str]:
    """收集电路里所有器件声明的 `.xxx` 指令（运放的 .subckt 等），去重保序。

    用途：`ccl.runner` 在编译前调用，把这些指令塞进 `circuit.directives`，
    这样即使编译层没有实现「从器件收集 directives」，运放宏模型也一定进网表。
    """
    out: list[str] = []
    for comp in getattr(circuit, "components", []):
        getter = getattr(comp, "directives", None)
        if not callable(getter):
            continue
        for line in getter() or []:
            text = str(line).strip()
            if text and text not in out:
                out.append(text)
    return out
