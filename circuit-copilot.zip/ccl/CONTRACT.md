# CCL M1 契约（改动这里等于改公开 API，必须同步通知全员）

## 相关契约（别处）

本仓库的契约按**层**分散存放，各自成篇，谁管哪一层的权威如下——读之前先确认自己要看的是哪一层：

| 文件 | 权威范围 | 谁该读 |
|---|---|---|
| **本文件（`ccl/CONTRACT.md`）** | **CCL 库这一层的权威**：`ccl/` 的数据模型、器件库、编译、断言、lint、报告、沙箱、AI 子包，以及 M1~M5 定下的接口与决策；末尾「指标口径」「第三轮：直流扫描与瞬态指标」「电路图渲染」几节是**口径的最终解释** | 改 `ccl/`、写 CCL 代码、判指标口径的人 |
| `ccl/CONTRACT_ROUND3.md` | 第三轮（直流扫描 + 瞬态指标）开工时的**原始契约与验收标准**；口径定案后已合并进本文件，两份冲突时**以本文件为准** | 想知道「当初为什么这么定」的人 |
| `docs/ARCHITECTURE.md` | **描述性文档**（不是契约）：模块依赖、请求时序、电路图连接正确性、踩坑记录、**目前仍未修的问题与已修清单**、扩展指南 | 想知道「现在实际怎么跑」的人 |
| `web/ide/CONTRACT*.md`（4 份） | **IDE / 前端那一层**：布局网格、各 `*.js` 模块签名与验收标准、电路图渲染模块 | 改 `web/ide/` 的人 |

三条使用纪律：

- **本文件里的数字不随扩展自动更新**（例如 M5 那一节记的「9 个块全部可构建」是当时的验收快照）。
  当前是 **12 个块 / 13 个拓扑**，以 `python3 -c "from ccl.blocks import BLOCKS; print(len(BLOCKS))"`
  与 `python3 main.py --catalog` 的输出为准。
- 前端侧的自测脚本已从 `scratch_m1/` 迁到 `tests_ui/`（`node tests_ui/schematic_selfcheck.mjs`，51 项），
  见 `web/ide/CONTRACT_SCHEMATIC.md` 与 `tests_ui/README.md`。
- 「协作纪律」里那条「每个模块自带 `scratch_m1/` 下的自测脚本」已过时：`scratch_m1/` 已随里程碑清理下线，
  新用例一律加进 `tests_ccl/`（Python 库）、`tests/`（参数化工具）、`tests_api/`（服务层）、
  `tests_ui/`（前端纯逻辑）四个正式套件之一，并且要能被 `bash selfcheck.sh` 跑到。

项目：`/storage/emulated/0/文件夹/dz/circuit-copilot`
包：`ccl/`（新库，复用已验证的 `copilot/sim.py` 作为 ngspice 后端）

## 定位

**代码是唯一真相**。电路用 Python 写，不画图、不识图。
核心库**不依赖任何大模型**；AI 生成是独立可选子包 `ccl/ai/`。

## 分层与文件所有权

| 文件 | 内容 | 负责人 |
|---|---|---|
| `ccl/__init__.py` | 公开导出 | Lead |
| `ccl/errors.py` | 异常体系 | Lead ✅ 已完成 |
| `ccl/core.py` | `Pin` / `Component` / `Circuit` 数据模型 + `value_tokens()` 契约 | Lead ✅ 已完成 |
| `ccl/format.py` | SPICE 数值格式化（`fmt_value`） | **core-eng** |
| `ccl/compile.py` | `Circuit → SPICE 网表` | **core-eng** |
| `ccl/devices.py` | 器件库 | **dev-eng** |
| `ccl/runner.py` | 仿真入口（复用 `copilot.sim`） | **dev-eng** |
| `ccl/solution.py` | `Solution`：波形访问与指标计算 | **dev-eng** |
| `ccl/ai/__init__.py` 等 | AI 生成（独立功能） | **ai-eng** |
| `ccl/CONTRACT.md` | 本文件 | Lead |

**只改自己负责的文件。** 需要动别人的文件先告诉 Lead。

## 已固定的接口（不得单方面修改）

### core.py（已实现，只读参考）

```python
GND = "0"

@dataclass
class Pin:
    name: str          # 引脚名，如 "a" "b" "in" "out"
    node: str          # 节点名（已 normalize）

@dataclass
class Component:
    kind: str                                  # "R"/"C"/"L"/"V"/"I"/"X"/"D"/"Q"/"M"
    ref: str                                   # "R1"、"U1.OpAmp1"
    pins: list[Pin]                            # 有序，顺序即网表端子顺序
    value: float | str | None = None
    model: str | None = None
    params: dict = field(default_factory=dict)
    meta: dict = field(default_factory=dict)
    def pin(self, name) -> Pin
    def node(self, pin_name) -> str
    def nodes(self) -> list[str]
    def value_tokens(self) -> list[str]         # ★ 器件必须实现/覆盖
    def clone(self, *, ref=None, pin_nodes=None) -> Component
    def describe(self) -> str

class Circuit:
    name: str
    components: list[Component]
    directives: list[str]
    def add(self, comp) -> Component
    def find(self, ref) -> Component | None
    def nets(self) -> dict[str, list[tuple[str, str]]]
    def nodes(self) -> list[str]
    def validate(self, *, allow_floating=False) -> list[str]
    def use(self, sub, *, prefix=None, maps=None) -> Circuit
    def directive(self, line) -> Circuit
    def to_spice(self, analysis=None, *, title=None) -> str      # → compile.compile_circuit
    def ac(self, f_start=1.0, f_stop=1e6, points=200, *, check=True)   # → runner.ac_sweep
    def op(self, *, check=True)                                        # → runner.operating_point
    def tran(self, t_step, t_stop, *, check=True)                      # → runner.transient
    # 便捷加器件：R / C / L / V / I / OpAmp（已实现，委托 devices）
```

## core-eng 要交付

### `ccl/format.py`

```python
def fmt_value(v: float) -> str:
    """SPICE 数值：避免科学计数法与后缀歧义。例：1e-7 → "100n"，4700 → "4.7k"。
    必须能被 ngspice 正确解析；不确定时用 6 位有效数字的纯数字形式。"""
```
要求：`0.0000001` 不能写成 `1e-7`（ngspice 能认，但更稳的是 `100n` 或 `0.0000001`）；
**不要**输出带单位后缀的歧义形式（如 `1M` 会被当兆，`1m` 会被当毫，必须显式区分大小写并加测试）。

### `ccl/compile.py`

```python
def compile_circuit(circuit: Circuit, analysis: str | None = None,
                    title: str | None = None) -> str
```
- 输出顺序：标题行（`* ` 开头）→ 器件行 → directives → `analysis`（若有）→ `.end`
- 器件行：`f"{ref} {' '.join(nodes)} {' '.join(value_tokens())}"`
- **不要**注入 `.control`（runner 会交给 `copilot.sim` 处理）
- `analysis` 是完整分析卡，如 `".ac dec 200 1 1meg"`
- 编译前先调 `circuit.validate()`；失败抛 `CCLNetlistError` 并带上出问题的位号
- 位号里含 `.`（内联子电路）时，SPICE 允许，但请写测试确认 ngspice 不报错；若报错，改用 `_` 并在本文件注释说明

## dev-eng 要交付

### `ccl/devices.py`

必须提供这些类（构造函数签名固定，`ref=None` 表示自动分配）：

```python
Resistor(a, b, value, ref=None, **kw)
Capacitor(a, b, value, ref=None, **kw)
Inductor(a, b, value, ref=None, **kw)
VoltageSource(a, b, dc=0.0, ac=0.0, ref=None, **kw)     # value_tokens → ["DC","5","AC","1"]
CurrentSource(a, b, dc=0.0, ac=0.0, ref=None, **kw)
OpAmp(inp, inn, out, *, gbw=1e6, a0=1e5, ref=None)   # ★ 三端，节点是必填位置参数
```

- 每个器件必须设 `kind` 与**有序** `pins`（顺序即 SPICE 端子顺序）
- **多端器件构造规则（M1 补充）**：两端件 `(a, b, value)`；三端及以上按引脚顺序作为
  位置参数，且同名关键字必须可用。运放固定为 `OpAmp(inp, inn, out, *, gbw, a0)`，
  两种写法都要支持：`c.OpAmp("src","sum","out", gbw=1.3e6)` 与 `c.OpAmp(inp="src", inn="sum", out="out")`
- 需要宏模型的器件（OpAmp）通过 `circuit.directive(...)` 追加 `.subckt`，或提供 `directives()` 方法让 compile 收集
- **OpAmp 必须复用 `copilot.topologies.opamp_subckt(a0, gbw)`** 的模型（单极点、含 GBW 限制、纯线性结构），不要自己另写一个理想运放
- 引脚命名建议：两端件用 `"a"/"b"`；运放用 `"inp"/"inn"/"out"`（单电源或无供电引脚时在 docstring 说明这是小信号模型）
- 越界参数抛 `CCLConfigError`（如 value<=0、gbw<=0）

### `ccl/runner.py` + `ccl/solution.py`

```python
# runner.py
def ac_sweep(circuit, f_start, f_stop, points=200, *, check=True) -> Solution
def operating_point(circuit, *, check=True) -> Solution
def transient(circuit, t_step, t_stop, *, check=True) -> Solution
def simulate(circuit, netlist, **kw) -> Solution
```
- 内部调用 `copilot.sim.run(netlist)`；把 `copilot.sim.SimError` 转成 `CCLConvergenceError`（保留 netlist 与原始输出）
- `check=True` 时先 `circuit.validate()`

```python
# solution.py
class Solution:
    kind: str                       # "ac" | "op" | "tran"
    x: list[float]                  # 频率或时间轴
    waves: dict[str, Wave]          # 复用 copilot.sim.Wave
    netlist: str
    elapsed_ms: float
    def v(self, node) -> Wave       # 支持 "out" 或 "v(out)"
    def db(self, node) -> list[float]
    def phase(self, node) -> list[float]
    def mag(self, node) -> list[float]
    def f3db(self, node, ref_db=None) -> float | None
    def peak_db(self, node) -> float
    def value_at(self, node, x) -> float
    def node_names(self) -> list[str]
    def plot(self, node) -> str     # 可选：返回 ASCII 或 SVG 片段，M1 可先 stub
```
- 节点名要与 SPICE 输出对得上（SPICE 输出是 `v(out)` 小写）；做好大小写兼容与 `v()` 包裹兼容
- 找不到节点时抛 `NodeError`，并把可用节点名列出来

## ai-eng 要交付（独立可选功能）

`ccl/ai/` 包，**核心库不得依赖它**。

```python
from ccl.ai import generate, review, explain

generate(prompt: str, *, model: str | None = None, max_repair: int = 1) -> Generation
# Generation: .ok / .source(可执行 Python 代码) / .circuit / .solution / .error / .attempts

review(circuit, solution=None) -> list[Issue]     # Issue: .level(error/warn/info) .title .detail .ref
explain(circuit, solution=None) -> str
```
硬性要求：
1. **生成的是可执行的 Python 代码**，不是网表（网表写错一处整个崩，代码能解析到行）
2. 生成后必须：在受限命名空间里 exec → 拿到 `Circuit` → 真跑一次仿真 → 失败则带着错误信息自动修复重试（`max_repair` 次）
3. exec 必须做安全隔离：白名单 `__builtins__`，禁止 `import`/`open`/`eval`/`exec`/`__import__`
4. 没有 API Key 时：`generate` 抛清晰错误或返回 `.ok=False`，**不许影响核心库**
5. 复用 `copilot.llm.LLM`（OpenAI 兼容，已是纯 stdlib）

## M1 验收标准（Lead 会用这个卡）

全部必须通过：

1. `c = Circuit("rc_lp"); c.V("in", GND, ac=1); c.R("in","out",1.6e3); c.C("out",GND,100e-9)`
   → `sol = c.ac(1, 1e5)`，`sol.f3db("out")` 与 `1/(2πRC)=995.0Hz` 误差 <1%
2. 同相放大（R1=1k, R2=9k, GBW=1.3M）：增益 10±1%、闭环带宽与 `GBW/10` 相符（0.7~1.1 倍）
3. 反相放大（R1=1k, R2=10k）：`|增益|` = 10±1%
4. 子电路：`@subcircuit` 风格的内联复用能跑通，位号/节点前缀正确，仿真结果与手写展平版一致
5. 悬空节点、无地、重复位号三类错误都给出**指向具体位号/节点**的中文报错
6. `compile_circuit()` 输出的网表可被 ngspice 直接跑通（不经过 runner 也能跑）
7. `from ccl.ai import generate` 在没有 Key 的环境下 import 不报错
8. 每个模块自带 `scratch_m1/` 下的自测脚本，把实测数字打印出来

## 环境

- 工作目录 `/storage/emulated/0/文件夹/dz/circuit-copilot`（bash 每次新 shell，必须自己 `cd`）
- Python 3.14，ngspice-47 已装，`copilot` 包可 `import`
- **只用标准库**，不 pip install
- 不要启停 web 服务（`kill $(cat out/pid)` 会杀掉队友在用的）

## 协作纪律

- 只改自己名下的文件；需要别人改动 → 发消息给 Lead
- 交付时给 **实测数字**（理论值 vs 实测值），不要只说"跑通了"
- 做不到就如实说，不要放宽判定标准假装通过

---

# Lead 答疑（M1 期间新增，最后更新于三路开工当天）

## Q1：运放怎么接线？（ai-eng 提出，已确认为契约疏漏）

原签名 `OpAmp(gbw=1e6, a0=1e5, ref=None, **kw)` 漏了节点——运放是三端器件，没节点建不出来。
已修正为：

```python
# ccl/core.py（Lead 已实现）
def OpAmp(self, inp, inn, out, *, gbw=1e6, a0=1e5, ref=None, **kw)

# ccl/devices.py（dev-eng 负责实现，kind="X"）
class OpAmp(Component):
    def __init__(self, inp, inn, out, *, gbw=1e6, a0=1e5, ref=None, **kw)
```

两种调用等价，都必须在测试里覆盖：

```python
c.OpAmp("src", "sum", "out", gbw=1.3e6)     # 按引脚顺序（few-shot 用这个）
c.OpAmp(inp="src", inn="sum", out="out")    # 关键字，可读性更好
```

`gbw` / `a0` / `ref` 是**关键字-only**（`*` 之后），不能位置传。

## 由此定下的通用规则（以后所有多端器件照此办理）

| 器件端数 | 构造签名 | 例 |
|---|---|---|
| 两端 | `(a, b, value)` | `c.R("in", "out", 1.6e3)` |
| 三端及以上 | 按引脚顺序作为位置参数，且同名关键字必须可用 | `OpAmp(inp, inn, out, *, gbw, a0)` |

引脚命名约定：两端件 `a` / `b`；运放 `inp` / `inn` / `out`。
地节点固定写 `GND`（值为 `"0"`）。

## 完整运放示例（可直接用作 few-shot）

```python
from ccl import Circuit, GND

def build():
    c = Circuit("noninv_amp")
    c.V("src", GND, ac=1)
    c.R("sum", GND, 1e3)          # R1
    c.R("out", "sum", 9e3)        # R2 → 增益 = 1 + R2/R1 = 10
    c.OpAmp("src", "sum", "out", gbw=1.3e6)
    return c
```

## 给 ai-eng 的额外提醒

生成的代码若用了旧签名（`c.OpAmp(gbw=...)`）会在 exec 阶段报 `TypeError`。
请把**正确签名**放进错误回喂的内容里，让修复重试循环能自愈，而不是反复生成同一种错写法。

---

# Lead 决策（core-eng 交付后补充，全员适用）

## D1：`.control` 不得出现在 directives 里 —— 改为硬错误

`compile.py` 原实现「原样放行」，我要求改成抛 `CCLNetlistError`。

原因（这是会让错误出现在离现场很远的地方的坑）：
`copilot.sim.run()` 靠 `if ".control" not in deck` 判断要不要注入自己的控制块。
用户自带 `.control` → 我们那套 `write c.raw all` 不注入 → rawfile 不落盘 →
runner 拿到空波形 → 用户在几十行外看到一个「仿真未产生有效波形」的错，
根本想不到是自己多写了一个 `.control`。

报错文案要求：说清「不要手写 .control，请用 `c.ac()` / `c.op()` / `c.tran()`，
分析卡由 runner 生成」。

## D2：数值格式 —— 网表里一律纯十进制，不许可读性优先

保持 core-eng 现行的「无单位后缀」方案，不改。

因为实测（我独立复核过）：
```
1m → 0.001    1M → 0.001  ← 大写 M 也是毫！
1meg → 1e6    1k → 1000
```
SPICE 的 `M` = milli（不是 mega），这一个坑就足以否决所有后缀风格。
`fmt_eng("100n")` 只允许用于显示/日志，**绝不可回喂网表**。

## D3：`params` 的输出去重责任在 compile

- `Component.params` 由 `compile` 拼成 `key=value` 追加在 `value_tokens()` 之后
- **器件不要在 `value_tokens()` 里重复输出 `params` 里已有的键**；compile 会去重，但别指望它
- 这条对 dev-eng 的 OpAmp 尤其重要（它要在实例行带宏模型参数）

## D4：错误类双继承是有意的，不要"清理"

`compile` 抛出的是 `NetlistNodeError(CCLNetlistError, NodeError)` 这样同时继承两边的类。
因为契约要求编译失败抛 `CCLNetlistError`，而 `Circuit.validate()` 抛 `NodeError`/`RefError`。
结果是 `except CCLNetlistError` 和 `except NodeError` **都能捕获**，调用方不必记住是哪一层出的错。
这是刻意设计，不要为了"继承关系干净"而改掉。

## D5：内联子电路的位号必须过 `netlist_ref()`

实测（我复核过）ngspice **按行首字符决定器件类型**，所以 `U1.R1` 被当成 U 型器件而拒收；
换成 `U1_R1` 一样拒收——**病根不是点号**。正确做法是保留点号并补类型字母：`U1.R1` → `R.U1.R1`。

因此：**任何要写进网表的位号，都必须经 `ccl.compile.netlist_ref(comp)`**，
不能用 `comp.ref` 直接拼。谁在网表里用到位号（报告、BOM、交叉引用）也要用这个函数。

## D6：次正规数区间 1e-320 ~ 1e-307

保持现状：`|v| < 1e-320` 抛错（避免静默归零），
1e-320 以上但落在次正规区间的值允许写出，精度损失在 docstring 里记录。
原因：真实元件值不会进入这个区间（最小也就 1fF = 1e-15），不值得为此加复杂逻辑。

---

# M2 新增（Lead 实现，已完成并验证）

## 器件库扩展

| 器件 | 签名 | 引脚顺序（= SPICE 端子顺序） | 网表形态 |
|---|---|---|---|
| 二极管 | `Diode(a, k, model=None, *, model_params=None, area=None)` | `a`阳极 → `k`阴极 | `D1 a k D1N4148` |
| 三极管 | `Bjt(c, b, e, model=None, *, model_params=None)` | `c`集电极 → `b`基极 → `e`发射极 | `Q1 c b e Q2N3904` |
| MOSFET | `Mosfet(d, g, s, bulk=None, model=None, ...)` | `d` → `g` → `s` → `b`（省略则接源极） | `M1 d g s s M2N7002` |
| 脉冲源 | `PulseSource(a, b, v1, v2, td, tr, tf, pw, per)` | `a`+ → `b`− | `V1 a b PULSE(0,5,0,1n,1n,1m,2m)` |
| 正弦源 | `SinSource(a, b, vo, va, freq, td, theta)` | `a`+ → `b`− | `V1 a b SIN(0,1,1k,0,0)` |

`Circuit` 上的便捷方法：`c.D(...)` `c.Q(...)` `c.M(...)` `c.PULSE(...)` `c.SIN(...)` `c.SW(...)`

> 这张表是 M2 的验收快照。**M6 又加了一类器件：开关 `c.SW(a, b, ctrl)`**（SPICE `S` 元件），
> 签名、引脚顺序、模型名派生规则与实测数字见本文档末尾「M6 新增」§1。

内置真实模型卡（`devices.MODEL_CARDS`）：
`D1N4148` `D1N4007` `D1N5819` `Q2N3904` `Q2N3906` `M2N7002` `MIRF540`

- 模型名不能以数字开头（SPICE 限制），所以 1N4148 → `D1N4148`
- MOSFET 用 Level-1（Shichman-Hodges）：收敛优先，教学/工程估算够用；
  真实功率 MOS 请传 `model_params` 或换厂商子电路模型
- 自定义器件：`c.D("a", GND, "MYDIODE", model_params={"Is":"1e-14","N":"1.8"})`

## 一条实测硬约束：PULSE/SIN 用**逗号**分隔

`compile` 层有「token 内不得含空白」的保护（防真正拆错列的 bug），
而 `PULSE(0 5 0 1n ...)` 的空格形式会被它拦下。
ngspice-47 实测空格与逗号都接受，所以 `value_tokens()` 统一输出逗号形式：
`PULSE(0,5,0,1e-09,1e-09,0.001,0.002)`、`SIN(0,2,1000,0,0)`。
**不要为了好看改回空格形式**，那会撞上编译层的保护。

## M2 验证结果（解析式核对，不是"能跑"）

| 检查 | 实测 | 理论/期望 |
|---|---|---|
| 1N4148 正向压降（5V/1k） | 0.6532 V | 0.6~0.7 V |
| 1N4148 反向漏电 | ≈0 µA | 截止 |
| 2N3904 Vbe / Vce / β | 0.7178V / 4.289V / 166 | 放大区 |
| M2N7002 饱和电流 | 693.8 mA | 公式值 693.8 mA（一分不差） |
| M2N7002 截止（Vgs=0） | Vd=5.0000 V | 无电流 |
| PULSE+RC：t=τ | 3.1606 V | 0.632×5 = 3.160 V |
| SIN 幅度 | ±2.0000 V | ±2 V |

## Web 接入

- `GET /ccl` → `web/ccl.html`（代码编辑器 + 波形图）
- `GET /api/ccl/example` → 示例代码清单（`web/ccl_examples.py`，**示例必须真实可跑，改器件层后要重跑验证**）
- `POST /api/ccl/run` `{code, analysis:{kind,f_start,f_stop,points,t_step,t_stop}}`
  → `{ok, circuit, analysis, netlist, error, line, stage}`
- 执行走 `ccl.ai.sandbox.run_source()`（与 AI 生成共用同一套沙箱），
  所以浏览器里贴进来的代码同样受 AST 白名单 + 超时保护
- `web/ccl_api.py` 独立于 `server.py` 的参数化工具逻辑：两边互不拖累

---

# M3 新增（Lead 实现，已完成并验证）

## 1. 断言机制 —— 「代码即测试」

```python
c.expect("fc", "out", 1e3, tol=0.05)          # 截止 1kHz ±5%（相对容差）
c.expect("gain", "out", 10, tol=0.01)         # 增益 10 倍 ±1%
c.expect("peak_db", "out", 0.5, mode="max")   # 峰化不超过 0.5dB（绝对容差）
c.expect("v", "b", 0.7, tol=0.1)              # 工作点：节点 b 电压 0.7V±10%
c.expect("p", "R1", 0.2, mode="max")          # R1 功耗 ≤ 0.2W

rep = c.verify(ac=(1, 1e5, 100))   # → Report，逐项目标 vs 实测
c.assert_ok()                      # 不通过抛 CCLAssertionError
```

可用 `kind`：`fc` `gain` `gain_db` `peak_db` `q` `bw` `v` `i` `p` `value_at`
比较方式：`eq`（默认）/ `min` / `max`

**容差语义**（同 D 系列教训）：频率/增益/电压/功率用**相对**容差；
`gain_db`/`peak_db` 用**绝对**容差。混用会让「1000Hz ±10%」变成「≥999.9Hz」，
一个合格的 990Hz 设计被判失败。

`verify()` 会自动判断需要哪种分析：有交流类规格就跑 AC，有工作点类规格就跑 OP，
两类都有就都跑。**测不到的指标判 `NaN` → 未达标**，绝不编数据。

## 2. 参数扫描

```python
for r, variant in c.sweep("C1", [100e-9, 47e-9, 22e-9]):
    print(r, variant.ac(1, 1e5).f3db("out"))
```

- `c.with_(R1=2e3)` 返回**副本**，不改原电路（键是位号，必须精确，如 `C1` 不是 `C`）
- `sweep` 是生成器，可叠加固定参数：`c.sweep("R1", [...], C1=47e-9)`

## 3. 检查分层修正（重要）

静态检查原先住在 `ccl/ai/review.py`——**那是分层放错了**：核心能力不该住在可选 AI 包里。
现在：

| 能力 | 位置 | 说明 |
|---|---|---|
| 静态检查 + 工作点检查 | **`ccl/lint.py`（唯一真相）** | 无 Key 也能用 |
| `ccl.ai.review` | 从 `ccl.lint` 导入 | 只保留「模型叙事」与波形形状检查（撞轨/峰化） |

`c.lint(solution=None)` 可直接调用；`Issue` 新增 `code` 字段用于程序化判断。

新增工作点检查项：

| 项 | 级别 | 依据 |
|---|---|---|
| 节点电压发散（\|V\|>1kV） | error | 接错或未收敛 |
| 电阻功耗超限 | warn(≥0.25W) / error(≥1W) | P=(Va−Vb)²/R |
| 三极管放大/饱和/截止 | info/warn | Vce<0.3V 饱和；Vbe<0.5V 截止 |
| MOSFET 截止/线性/饱和 | warn/info | 对比模型卡里的 Vto |

## 4. 一处必须记住的坑：地节点在 SPICE 输出里没有波形

`_volt(solution, "0")` 会返回 `None`，于是**所有接地器件的检查被静默跳过**。
`ccl/lint.py::_volt()` 已特判地节点为零伏。写任何基于 `Solution` 的检查时都要注意这点。

## 5. Web 集成

`POST /api/ccl/run` 的返回新增两个字段：

```json
"lint":   [{"level":"error","code":"resistor_power","title":"R1 功耗 10W 严重超限","detail":"...","ref":"R1"}],
"expect": {"passed": false, "total": 2, "failed": 1,
           "items":[{"label":"−3dB 截止频率(out)","mode":"eq","target":1000,"unit":"Hz","actual":9947,"ok":false}],
           "text": "...", "extra": ["为核对交流类规格，额外跑了一次扫频"]}
```

注意：用户声明的规格可能同时包含交流和直流类，而页面一次只跑一种分析，
接口会**补跑缺的那一类**（单次仿真几十毫秒），并在 `extra` 里如实说明。

---

# M4 新增（Lead 实现，已完成并验证）—— AI 层与 M2/M3 打通

## 问题：AI 曾经用不上 M2/M3 的能力

M2（二极管/三极管/MOS/脉冲正弦源）和 M3（`expect` 断言）做完之后，
`ccl/ai/prompts.py` 里的 `API_CARD` 仍然只认识 R/C/L/V/I/OpAmp，也不提 `expect`。
**AI 生成不出这些电路**——能力做了却用不上，等于没做。

## 改动

### 1. prompt 重写（`ccl/ai/prompts.py`）

- `API_CARD`（约 2700 字）覆盖全部器件：`c.D/c.Q/c.M/c.PULSE/c.SIN/c.expect`，
  并显式警告「引脚顺序 = SPICE 端子顺序，错了不会报错但结果全错」
- `FEWSHOT` 从 3 个扩到 **7 个**完整可运行示例：RC+断言 / 运放 / 二极管 /
  BJT 共射 / PULSE 瞬态 / Sallen-Key（含 Q 公式与 C1 跨接提醒）
- 铁律加入「有明确指标时**一定**写 `c.expect`」

### 2. 生成校验改为「断言优先」

`generate()` 的校验顺序：
1. **代码自带 `c.expect` → 用 `assertions.evaluate` 核对**（语义无歧义，最可靠）
2. 再从 prompt 正则抽数字核对（`spec_check`，兜住没写 expect 的情况）

原因：从中文里抽「10kHz」可能抽错（抽成带宽、抽成采样率），
而 `c.expect("fc","out",10e3)` 是明确声明的目标。

### 3. 新增 `fix()` —— 改现成代码

```python
from ccl.ai import fix
g = fix(your_code)          # 按实际检查结果修正
g.ok, g.source, g.attempts
```

流程：**先用确定性诊断**（`ccl.lint` 静态+工作点 + `c.expect` 核对），
- 没有 error/warn → **直接返回原代码，一次模型都不调用**（实测 0.2s / 0 轮）
- 有问题 → 把具体问题回喂模型修复，再验证

关掉「合格代码也白烧 token」这个常见浪费。

### 4. Web 集成

`POST /api/ccl/ai` `{action: "generate"|"fix"|"explain", prompt?, code?, analysis?}`

页面上方新增 AI 栏：
- **生成**：一句话 → 填入编辑器 → **自动运行**
- **修复**：诊断当前代码，有问题才调模型
- **解释**：讲这段电路在做什么、实测如何

## 实测（真实模型 cn:deepseek-v4-flash）

| 需求 | 结果 |
|---|---|
| 5V 经 1k 串 1N4148 | ok，用 `c.D`，自带 1 条断言，1 轮 |
| 2N3904 共射偏置 | ok，用 `c.Q`，自带 2 条断言，1 轮 |
| 10kHz 二阶低通 Q=0.707 | ok，自带 3 条断言，1 轮 |
| `fix()` 合格代码 | 0 轮 0.2s（未调模型） |
| `fix()` 规格不达标 | 1 轮修好，f3db 994.7Hz |
| `fix()` 结构错误（悬空/孤立节点） | 1 轮修好 |

## 注意
- `ccl.ai` 仍是**独立可选**：无 Key 时 `import ccl.ai` 不失败，`generate/fix`
  返回明确错误，`explain` 退回确定性模板；手写代码完全不受影响
- `fix()` 的诊断依赖 `ccl.lint`，所以 lint 的检查项越多、AI 修复越准

---

# M5 新增（Lead 实现，已完成并验证）—— 子电路库 + 报告导出

## 1. 可复用子电路库 `ccl/blocks.py`

```python
from ccl import Circuit, GND
from ccl.blocks import BLOCKS

c = Circuit("two_stage")
c.V("src", GND, ac=1)
c.use_ports(BLOCKS["rc_lowpass"](fc=1e3),        {"in": "src", "out": "n1"})
c.use_ports(BLOCKS["noninv_amp"](gain=10),       {"in": "n1",  "out": "y"})
```

| 块 | 参数 | 端口 |
|---|---|---|
| `rc_lowpass(fc, r=None, c=None)` | 截止频率 | in, out |
| `rc_highpass(fc, r=None, c=None)` | 截止频率 | in, out |
| `divider(ratio, total_r=10e3)` | 分压比 ∈(0,1) | in, out |
| `rlc_bandpass(f0, q=10)` | 中心频率/Q | in, out |
| `noninv_amp(gain, r1=1e3, bw=None, gbw=None)` | 增益 | in, out |
| `inv_amp(gain, r1=1e3, bw=None, gbw=None)` | 增益 | in, out |
| `sallen_key_lowpass(fc, q=0.7071, gbw=None)` | 截止/Q | in, out |
| `bjt_ce_bias(rc, rb, model="Q2N3904")` | 电阻 | vcc, in, out |
| `emitter_follower(rb, re, model="Q2N3904")` | 电阻 | vcc, in, out |

**两条硬约束**
1. **块里不放独立源**——内联后与外部共节点，两个电压源接同一对节点就是 singular matrix
2. **块必须声明 `ports`**——组合时用 `use_ports(sub, {"端口名": "外部节点"})`，
   不用记内部节点叫什么；未知端口会报错并列出可用端口

## 2. 端口与检查的关系（重要）

块的端口本来就是「留给外部接的」，所以：

- `Circuit.validate()` 与 `Circuit.lint()` **自动放行已声明的端口**，不报「悬空节点」
- `check_dc_path` 把「走到端口」视为通路离开本子电路，由外部负责
  （否则 `rlc_bandpass` 里 L-C 之间的内部节点会被误判成浮地）

这条不加的话，每个 block 单独检查都会冒出一堆假错误——**误报比漏报更伤信任**。

## 3. 报告导出 `ccl/report.py`

```python
from ccl import report as RPT
md = RPT.markdown(circuit, solution, analysis_desc=".ac dec 100 1 1e5")
```

6 个章节：概况 / 器件清单 / SPICE 网表 / 实测结果 / 电路检查 / 规格核对。

## 4. Web

- `GET  /api/ccl/blocks`        子电路清单
- `POST /api/ccl/report`        `{code, analysis}` → `{ok, markdown, id, filename}`
- `GET  /api/ccl/report/<id>`   带 `Content-Disposition: attachment` 下载

**下载必须走同源 URL**：实测 Android WebView 里 `Blob + a[download]` 不会落文件，
所以 `POST` 生成后服务端缓存一份（按 id，最多留 30 份），前端在 Android 上
`window.open('/api/ccl/report/<id>')`，其它平台仍用 Blob。

## 5. 沙箱白名单

`ccl.ai.sandbox.ALLOWED_IMPORTS` 增加 `ccl.blocks`（纯构造，无 IO）。
**刻意不含 `ccl.ai`**——否则生成出来的代码可以反过来调用模型。

## 6. 验证结果

| 项 | 结果 |
|---|---|
| 9 个块全部可构建、端口正确、单独检查无 error | ✅ |
| 端口级联（低通 → 同相放大）增益 9.999、−3dB 1000Hz | ✅ |
| 未知端口报错并列出可用端口 | ✅ |
| 报告 6 章节齐全、含网表与规格核对 | ✅ |
| 同源下载（HTTP 200 + attachment 头） | ✅ |

---

# 指标口径补充（qa-ccl 审计后定案）

## `Solution.f3db(node, ref_db=None)`

- 参考值取**曲线的最大值**（`ref_db` 可显式覆盖）
- 返回「第一次穿过 `ref − 3.01dB`」的频率，对数轴插值
- **必须存在「平坦段」**（相邻两点都贴近参考值 ≤0.3dB）才认这个参考；
  否则 `ref` 只是"扫频区间内最高点"，不是真实通带增益 → **返回 None**
  - 真实反例：fc≈99.5Hz 的低通从 1kHz 起扫，全程在下坡，却仍能"找到"一个
    −3dB 交点（1417Hz），静默给出错误结论

**口径警告（已知语义混杂）**：同一个返回值在不同电路上含义不同——
- 单极点低通/高通：真正的 −3dB 截止频率
- 有峰化的二阶低通：相对**峰值**下降 3dB 的频率（不是相对通带）
- 带通：第一个边沿

所以在二阶或有峰化的电路上用 `expect("fc", ...)` 时，务必确认你要的是哪个口径；
需要绝对口径就显式传 `ref_db`。

## `assertions` 里的 `bw`（带宽）

- **低通**（峰值在扫频起点）：带宽 = 从**直流**到 −3dB 点 = `hi` 本身。
  **不能**写成 `hi − xs[0]`——那样带宽会随扫频起点漂移（100Hz 起扫低估 9%、
  300Hz 起扫低估 21%），同一个电路换个扫描范围就被判不合格。
- **前提**：扫描起点必须比 −3dB 点低至少一个十倍频（`xs[0] × 10 ≤ hi`），
  否则通带增益不可信 → 返回 `NaN`（测不到就判未达标，不编数）。
  只查"起点局部是否平坦"不够：单极点 −20dB/dec 滚降很缓，300Hz 起点处
  局部也平（相邻点差 0.01dB），但 `db[0]` 已比 DC 低 0.38dB。
- 带通/峰化：按峰值两侧各找 −3dB 点，正常计算。

## 通用原则

**测不到就返回 `None`/`NaN` 并判未达标，绝不编一个看起来正常的数字。**
这条在 `f3db`、`bw`、以及工作点检查里都适用。

---

# 第三轮：直流扫描与瞬态指标（口径与限制）

## `.dc` 直流扫描

```python
c.dc("V1", 0, 10, 1)                                    # 一维：Vout–Vin 传输特性
c.dc("V1", 0, 5, 1, second=("I1", 0, 1e-3, 0.5e-3))     # 两维：曲线族
```

**ngspice 的两维输出结构（实测，务必记住）**
- rawfile 里**只有内层扫描量**（变量名 `v(v-sweep)` / `i(i-sweep)`），
  外层值**不存在于数据里**，只能由 `second=(ref,start,stop,step)` 参数算
- **第一个源是内层**：`.dc V1 ... I1 ...` 中 V1 是内层
- 点数 = `floor(区间/步长)+1`，**不补端点**（`.dc V1 0 1 0.3` → 4 点 0/.3/.6/.9）
- 切段靠 `len(sweep_values)`（内层点数）；不匹配时退回「扫描量回头处」实测切段
- `value_at(node, x)` 在锯齿 x 上**只在第一段内插值** → 曲线族请一律走 `dc_curves()`

**降序扫描（已修）**：`.dc V1 5 -5 -1` 的 x 是降序，而插值函数假设升序，
曾导致 `value_at` 对所有查询都返回端点值（5/0/−5 全返回 2.5）。
`Solution.value_at` 现在会先反转降序轴。**回归用例 `test_descending_sweep_value_at_is_correct` 钉住此行为。**

## 瞬态指标

```python
rise_time(node, low=0.1, high=0.9)   # 10%→90%，取**第一次**穿过
fall_time(node, low=0.1, high=0.9)
overshoot_pct(node)                  # 相对稳态；无超调返回 0.0；稳态≈0 时 None
settling_time(node, tol=0.02)        # 最后一次离开 ±tol 带并再未回来
steady_state(node, tail=0.1)         # 末 10% 时间窗的**算术均值**（不是末点）
```

**超调量的正确公式**（契约初稿写错过，以此为准）：
`overshoot = exp(−πζ/√(1−ζ²))·100`，其中 **ζ = 1/(2Q)**

| Q | 实测 | 理论 |
|---|---|---|
| 0.707 | 4.34% | 4.32% |
| 1.0 | 16.34% | 16.30% |
| 2.0 | 44.51% | 44.43% |
| 5.0 | 72.95% \* | 72.92% |

⚠️ 初稿把「16.3%」标成了 Q=2 的值，**那是 Q=1**。Q=2 是 44.4%。

\* **Q=5 那行必须用足够长的测量窗口**（实测 `t_stop=9ms`，fc=1kHz）。
超调的分母是 `steady_state`（末 10% 窗均值），Q 越大振铃越长；
窗口落在振铃里 → 稳态被低估 → **超调被低估**：

| t_stop | steady_state 估计 | overshoot |
|---|---|---|
| 5 ms | 5.0799 V（还在振铃） | 70.29% ← 偏小 |
| 9 ms | 5.0018 V（已稳定） | 72.95% ✓ |

这与运放有限增益/GBW **无关**（实测 GBW 1e6→1e8 只从 72.95% 变到 72.83%）。
回归用例 `test_high_q_overshoot_needs_long_enough_window` 钉住这个陷阱。

> 历史注记：某轮测试工程师把 70.29% 误判为「运放 A0/GBW 把实际 Q 拉低」，
> 并据此建议删掉本表 Q=5 那行。复核后确认**原数字正确**，真正的原因是测量窗口。
> 教训：指标对不上时，先查测量口径，再怀疑模型。

## 已知限制（分析方法本身，不是 bug）

1. **多周期脉冲串可能测不出指标**——**有前提，不是无条件**：
   当平台被 RC 平滑掉（**脉宽 pw ≈ τ 量级**）且末段落在低相位时，
   `rise_time / overshoot_pct / settling_time` 全返回 `None`。
   判据要求「末段安静或存在足够长的平台」，这是**为了不误报纯正弦**。
   实测边界（τ=100µs 的 RC）：
   - `pw = 1ms`（≈10τ）→ 平台保住，`rise_time = 219.7µs` **能正常测到**
   - `pw = 100µs`（≈1τ）→ 平台被平滑，四项全 `None`

   **正确用法**：`pw ≥ 10τ`，或直接用单次阶跃 `pw ≥ t_stop`，或把 `t_stop` 缩到第一个脉冲内。
2. **`t_stop` 太短会量偏**：高电平取自末段均值，只跑 1τ 时 `rise_time` 量的是「这段爬了多少」。
   **要看真值请 `t_stop ≥ 5τ`。**
3. **`steady_state` 是末 10% 窗口的均值**：多周期波形里若该窗落在低相位，得到的是窗内均值，
   不是高电平。需要高电平请缩 `t_stop` 或用更小的 `tail`。

---

# 电路图渲染（只读投影）

## 定位

**代码是真相，图是投影。** 不做图形编辑——图上画的永远由 `Circuit` 对象重新生成，
所以不存在「图和代码不一致」这种状态。

## 实现要点（`web/ide/schematic.js`）

- 10 种符号（R/C/L/V/I/D/Q/M/X/**S 开关**），未知 kind 降级成方框
  （`S` 是 M6 加的，见上文「M6 新增」与 `web/ide/CONTRACT_SCHEMATIC.md` 的动画层一节）
- 分层：按元件「信号流角色」建有向图（X: inp/inn→out，Q: b→c/e，M: g→d/s/b，D: a→k），
  **会成环的反馈边直接丢弃**，再跑最长路径分层。所以运放负端不会被排到输出右边。
- GND 不参与分层，单独做底部母线；一端接地的元件自动竖画
- 全正交走线；每个网络一条垂直母线 + 引脚水平短线；≥3 引脚打实心圆点
- **每个网络独占一列**（偏离初版契约里的 `x = marginL + rank*COL_GAP`）
  —— 同 rank 多网络按字面公式会同 x 重叠、**画出错误连接**，故改为正确性优先
- 每个元件 `<g>` 带 `data-ref/data-kind/data-mode/data-pins`，线上带 `data-net`，
  圆点带 `data-junction` → 便于自动断言

## 连接正确性验证（这是底线）

自测里加了一项**按电路图阅读规则从 SVG 几何反推连通性**：
两条线只在「共享端点」时连通，**纯十字交叉不算连通**；再断言
① 无悬空引脚 ② 同一几何连通块内不出现两个网络 ③ 同一网络的引脚必在同一连通块。
13 种拓扑全部一致；另有 9 个真实后端示例 9/9 一致。

**丑可以接受，接错不行。**

## 交互

- 面板内的图 `width=100%` 自适应缩放（复杂电路会变小）
- **点图 → 全屏**（按 viewBox 设 1.4 倍自然尺寸，Esc 或点任意处关闭）
- 标题栏「⤓ SVG」导出独立 `.svg`（样式全内联）
- **代码跑不通时清空电路图**——不能让人看着一张跟当前代码无关的图

---

# M6 新增（已完成并验证）—— 开关器件 + 工作态 / 瞬态数据

这一轮的题目是「让电路在 IDE 里动起来」。做法的边界先钉死，三条铁律：

1. **所有视觉必须由真仿真数据驱动**——不用「看起来合理」的假数据填动画；
2. **不用交流分析（频域）的数据演时域动画**；
3. **数据取不到就不显示，绝不填 0**。

下面每条都带实测数字与代码位置。实测环境：本机 ngspice-47。

## 1. 开关器件 `c.SW(...)`

| 项 | 值 |
|---|---|
| 便捷方法 | `Circuit.SW(a, b, ctrl, *, on_voltage=2.5, ron=0.01, roff=1e9, model=None, ref=None)`（`ccl/core.py:267`） |
| 器件类 | `ccl/devices.py:622` `class Switch(Device)`，`KIND = "SW"` |
| 引脚顺序 | `a` → `b` → `ctrl` → `ref`；`ref` 端**固定接 `"0"`**，所以控制量是 `V(ctrl) − V(0)`。**注意是 4 个引脚**，见 §3 的「多端器件不给 voltage/power」 |
| 网表 | `SW1 a b ctl 0 SW_0p01_1e09_2p5` + `.model SW_0p01_1e09_2p5 SW(Ron=0.01 Roff=1000000000 Vt=2.5)` |
| 支持的分析 | `.op` / `.tran` / `.dc` 都能跑；`ac` 下没有「工作态」（见 §3） |

**模型名由 `(ron, roff, Vt)` 派生，不是固定名**：`switch_model_name()`（`ccl/devices.py:600`）输出
`SW_{ron}_{roff}_{Vt}`，数值经 `_num_tag()`（`ccl/devices.py:318`）变成名字安全的片段
（小数点 → `p`、负号 → `m`、`+` 去掉）。实测（本机跑 `switch_model_name()`）：

| ron / roff / Vt | 模型名 |
|---|---|
| 0.01 / 1e9 / 2.5（默认） | `SW_0p01_1e09_2p5` |
| 0.01 / 1e9 / 4.0 | `SW_0p01_1e09_4` |
| 100 / 1e12 / 2.5 | `SW_100_1e12_2p5` |

三个参数都相同的开关**复用同一个 model**（编译层按文本去重：实测两个默认参数开关只产生 1 条 `.model`），
任一参数不同则各写一份 `.model`。

**为什么不用固定名**：ngspice-47 实测，同一个 model 名被 `.model` 声明两次且参数不同时
**不报错、不警告、静默只认后一份**（先声明 `Ron=0.01`、再声明 `Ron=100`，分压结果按 `Ron=100` 算）。
两个开关若共用一个固定名，其中一个的 `ron` 会被另一个**静默改掉**。

**`Vt` 必须进模型名（曾经漏掉，是真实事故）**：早先名字只有 `SW_{ron}_{roff}`，于是
**两个 `ron`/`roff` 相同、`Vt` 不同的开关撞名**——实测 `SW1(Vt=2.5)` 与 `SW2(Vt=4.0)` 撞在一起后，
控制电压 3V 时**两个都导通**（本该只有 Vt=2.5 那个导通）；而且 §2 的「改 Vt 强制状态」那条路
会把**别的开关**的阈值一起改掉。Vt 进名字之后两者分别是
`SW_0p01_1e09_2p5` 与 `SW_0p01_1e09_4`，互不干扰。

> 副作用（已处理，别当成 bug）：`switch_states` 的 vt 路径改完 Vt 之后模型名会变，网表里
> 会多出一条新名字的 `.model`。`ccl/runner.py:155` `_drop_stale_switch_directives()` 会在改完之后
> 清掉「长得像开关 model（前缀 `SW_`）但不在当前需要的名字集合里」的 `.model` 行，
> 所以网表里不会留下没人引用的旧 model。用户手写的 `.model`（不以 `SW_` 开头）**绝不会被碰**。

**参数校验**（全部抛 `CCLConfigError`，报错带位号与参数名）：
`ron`/`roff` 必须 > 0 且 `roff > ron`（否则「断开比导通还通」）；`on_voltage` 必须是有限数；
`model` 名不得为空或含空白；不认识的 kwarg 直接报错并列出支持的参数。

**`Vt` 必须显式写**：实测 ngspice 省略 `Vt` 时默认 `Vt=0`，于是「控制端 0V」的开关处于
**导通**状态——与直觉相反。本机实测（`5V → 220Ω → S1 → 220Ω → GND`，`V(ctl)=0V`）：
`.model SW(Ron=0.01 Roff=1e9)` 不给 Vt → `I(R1)=11.3634 mA`（导通，正好 5V/440Ω）；
给 `Vt=2.5` → `I(R1)=0.0000 mA`（只剩 5.0 nA 漏电）。所以 `SW()` 总是把 `Vt` 写进 `.model`。

> 代码注释的一处陈旧（**只在注释里，代码是对的**）：`Switch` 类 docstring 里的网表示例写的是
> `S1 a b ctrl 0 SW_MAXON_0p01_1000000000`，与 `switch_model_name()` 的实际输出
> （默认参数下 `SW_0p01_1e09_2p5`，且**含 Vt**）不一致。**以 `_num_tag` 的实现为准**，docstring 待修。

### 断开态不是理想开路（刻意的物理诚实）

`roff=1e9Ω` → 断开态仍有漏电。实测网表 `V1 5V → R1 220Ω → SW1 → D1N4148 → GND`，控制源 `Vctl`：

| Vctl | `@sw1[i]` | LED（D1）电流 |
|---|---|---|
| 0V（断开） | 4.951 nA | 4.951 nA |
| 5V（闭合） | 19.410 mA（`.tran`） | 19.422 mA |
| 闭合但用 `R=0.01Ω` 代替开关 | — | 19.410 mA |

闭合与无开关基准相差 **< 0.1%**（19.4221 vs 19.4103 mA）。所以要更小的漏电就把 `roff` 调到 1e12 以上。

### ⚑ ngspice 已知限制：`S` 元件在 `.op` 下取不到真实电流

实测 `@sw1[i]` 在 `.op` 下恒为 **1.94e-13 A**（≈0），`.tran` 下才是真值 **19.410 mA**。
所以工作点分析里开关电流「看起来是 0」= **取不到**，不是没电流。本机逐一对过（同一条
`V1 5V → R1 220Ω → SW1 → D1N4148 → GND`，读 `live.items.sw1`）：

| 状态 | `.op` 的 `sw1.current` | `.tran` 的 `sw1.current` |
|---|---|---|
| 闭合（Vctl=5V） | `0.0` ← **取不到**（真值 19.410 mA） | `0.019410063` = 19.410 mA |
| 断开（Vctl=0V） | `5e-09` = 真实漏电 | `5e-09` = 真实漏电 |

也就是说：**只有「本来该有大电流」的时候才看得出这条限制**；断开态测到的 5 nA 是真值，
不是残差。

- `live.items.sw1.current` 在 op 分析下会四舍五入成 `0.0`；`live.items.sw1.voltage` /
  `power` 在**任何**分析下都是 `null`（开关有 4 个引脚，见 §3「多端器件不给电压/功耗」），
  所以 op 下也不存在「power=0.0」这种说法——是 `null`。
- 瞬态动画（下方 §4 的 `timeline`）不受影响，它读的是 `@sw1[i]` 的**整条真序列**。

`_SAVE_PARAM`（`copilot/sim.py:204`）单独给 `"S": "i"` 开了一条：开关自己的支路电流必须存，
否则「开关这一段没有电流」只能靠相邻元件推断——那是猜，不是数据。

## 2. 开关状态覆盖：`switch_states`（状态）与 `switch_apply`（实现方式）

请求体可以带 `switch_states: {"SW1": "on"}`（也认 `closed/close/1/true/通/闭合/开` 与
`open/0/false/断/断开/关`；位号与状态值都大小写不敏感）。覆盖**发生在仿真之前、作用在电路对象上**，
**绝不修改用户代码文本**——代码框里永远是用户自己写的东西。

**两个字段含义不同，别混**：

| 字段 | 含义 | 取值 |
|---|---|---|
| `switch_states` | 每个开关**最终的状态**（界面据此画开关视觉） | `{"SW1": "on"}` / `{"SW1": "off"}` |
| `switch_apply` | 后端**用什么办法**把它强制成这个状态（**调试用**） | `{"SW1": "source"}` / `{"SW1": "vt"}` |

回报在 `web/ccl_api.py:676-686`：先拿到 `how = apply_switch_states(circuit, states, warnings=sw_notes)`
写进 `switch_apply`，再把用户请求归一化成 `on`/`off` 写进 `switch_states`（**只保留真正生效的位号**），
最后把 `sw_notes` 追加进响应的 `warnings`。

**历史坑（已修，tests_api 钉住）**：早先只返回实现方式，前端把 `"source"` 当状态读，
正则不匹配 → 一律判 `false` → 仿真对了但灯不亮、开关视觉被重置。

实现有两条路（`ccl/devices.py:785` `apply_switch_states`，`ccl/runner.py:183` 转发）：

1. **`source`（首选）**：控制节点上挂着**独立电压源** → 直接改它的 DC 值
   （导通写 `polarity × (|原 DC| 或 5V)`，断开写 0），并把该源的 `ac` 清 0
   （否则一次小信号扫频会把开关扫成半导通）。物理含义最直白，op/tran/dc 都成立。
   极性按引脚判定：控制节点接源正端 `+1`、接负端 `−1`。
   **⚠️ 只认真的输出 DC 电平的源**（`ccl/devices.py:738` `_find_ctrl_source`，判据是
   `value_tokens()[0] == "DC"`）：`PULSE(...)` / `SIN(...)` 源的 KIND 也是 `"V"`，但它们
   网表里**没有 dc 这个位置**，改 `comp.dc` 之后网表一个字节都不会变——却仍然回报
   `{"SW1": "source"}`，于是用户点了开关**什么都没发生**。实测（tran，PULSE 驱动控制端）：
   修复前 on/off 的 LED 峰值电流**完全相同** `0.0222758 A`；现在这类源会落到下面的 `vt` 路径。
   用 PULSE 驱动开关恰恰是瞬态里最常见的接法，所以这条不是边角。
2. **`vt`（兜底）**：没有可改的 DC 源 → 改本开关 `.model` 的 `Vt`，把结论**逼**出来。
   判据**固定**为 `want_on → Vt = −1000V`、`want_off → Vt = +1000V`，对任何
   `|V(ctrl)| < 1000V` 的电路（静态电平或 PULSE/SIN 波形）都成立，且**与当前控制电压无关**。
   早先的写法是「先跑一次 `circuit.op()` 量出 `V(ctrl)`，再把 Vt 放到它另一侧」，两个毛病都实测过：
   对时变控制完全失效（t=0 时 `V(ctrl)=0`，`want_off` 得到 `Vt=1`，脉冲升到 5V 时 `5>1` 仍然闭合）；
   而且白跑一次真实 ngspice。
   **控制节点上没有源、并且整个电路里一个独立源都没有** → 仍然抛 `CCLConfigError`（这种电路
   连控制电压都无从谈起）。错误信息里会提示接一个 `c.V(ctrl, GND, dc=5)`。

**未知位号不是错误，只写 `warnings` 并忽略**（`ccl/devices.py:824-836`）：界面上点过开关之后
用户把代码里的 `c.SW(...)` 删了/改名了，前端仍把旧的 `{"SW1": "on"}` 发上来。早先这里抛
`CCLConfigError` → `execute()` 把**整次运行**判失败 → 用户明明写对了电路却「跑一次就失败」，
而且报错指向界面状态而不是代码。现在：忽略它、往 `warnings` 里写一句
（`界面上的开关覆盖状态 SW9 已忽略：代码里已经没有这个开关了（现有开关：SW1）`），
`ok` 仍然是 `true`，电路照常仿真（**全部位号都不存在也照跑**）。

**仍然会报错的情况**（不要以为「什么都不报」）：① 状态词认不出来（`{"SW1": "maybe"}`）；
② 开关存在、控制端没有 DC 源、且全电路没有任何独立源。这两种都是代码/请求本身有问题，
不是界面残留。

改过 `Vt` 之后，`ccl/runner.py:155` `_drop_stale_switch_directives()` 会把 `circuit.directives` 里
**已经用不到**的开关 `.model` 摘掉。判据是**当前需要的模型名集合**：
删掉所有「以 `.model SW_` 开头、但不在这个集合里」的行（用户手写的、不以 `SW_` 开头的
`.model` 一律不碰）。早先的实现方向反了——拿**改完之后**的新名字去匹配旧行，一条都删不掉
（实测：改 off 之后网表里同时留着 `Vt=2.5` 和 `Vt=1000` 两条 model 卡）。

实测（电路：`V1 5V → R1 220Ω → SW1 → D1N4148 → GND`，控制源 `Vctl`，LED 两端另并 100kΩ；
op 分析，读 `live.items.d1.current`）：

| 请求 | `switch_states` | `switch_apply` | LED 电流 |
|---|---|---|---|
| 不带 `switch_states` | **字段不出现** | — | 19.411 mA |
| `{"SW1": "off"}`（控制端接独立源） | `{"SW1": "off"}` | `{"SW1": "source"}` | 0（开关支路仍漏 4.951 nA，被 100kΩ 旁路掉） |
| `{"SW1": "on"}` | `{"SW1": "on"}` | `{"SW1": "source"}` | 19.411 mA |
| `{"SW1": "off"}`（控制端由 10k/10k 分压驱动，没有独立源） | `{"SW1": "off"}` | `{"SW1": "vt"}` | 0（同上，此时 `Vt` 被设成 `+1000`） |
| `{"SW1": "off"}`（控制端由 **PULSE 源**驱动） | `{"SW1": "off"}` | `{"SW1": "vt"}` | 0（同上；修复前这种接法点了没反应） |
| `{"SW9": "off"}`（位号不存在） | `{}`（字段在，但是空表——没有生效的位号） | `{}` | **`ok=true`**，`warnings` 里多一条「SW9 已忽略」 |
| `{"SW1": "maybe"}`（状态词认不出） | 字段不出现 | 字段不出现 | `ok=false`，`stage="switch_states"`，`CCLConfigError: switch_states['SW1'] = 'maybe' 认不出来；请写 "on" 或 "off"` |

## 3. `/api/ccl/run` 的 `live`：器件级工作态

`collect_live(circuit, solution, kind)`（`web/ccl_api.py:349`）。**只搬运真实仿真数据**：

- 电流 ← `copilot.sim.branch_currents(solution, at_index=…)`（`copilot/sim.py:293`），即 rawfile 里的
  `i(@r1[i])` / `i(@d1[id])` / `i(@sw1[i])`；
- 电压 ← 两端节点电压之差（一端接地就取对地电压，地按 0V）；
- 功耗 ← `|I·V|`（V 与 I 是**同一时刻**的实测值，**不是** I²R 反推）；只有电流与电压都拿到时才算。

```json
"live": {
  "kind": "op",
  "t": 0.0,
  "items": {
    "v1":  {"kind": "V",  "current": null,          "voltage": 5.0,      "power": null},
    "r1":  {"kind": "R",  "current": 0.019409935,   "voltage": 4.270186, "power": 0.082884025},
    "sw1": {"kind": "SW", "current": 0.0,           "voltage": null,     "power": null},
    "d1":  {"kind": "D",  "current": 0.019422134,   "voltage": 0.72962,  "power": 0.014170782},
    "vctl":{"kind": "V",  "current": null,          "voltage": 5.0,      "power": null}
  }
}
```

上面这份是真实输出（`V1 5V → R1 220Ω → SW1(闭合) → D1N4148 → GND`，op 分析）。
同一电路跑 `tran(1e-6, 1e-3)` 时 `t` 变成 `0.001`、`r1.current` 变成 `0.019410063`
（`sw1.current` 也从 op 的 `0.0` 变成真值 `0.019410063`，原因见 §1 的 ngspice 限制）。

五条必须记住的口径：

- **`ac` 一律 `live: null`**：频域没有「瞬时工作点」，不拿频域数据假装时域状态
  （`collect_live()` 开头 `if solution is None or kind == "ac": return None`）。
- **取哪个时刻：`tran` / `dc` 取末点，`op` 就是那一个点**（`web/ccl_api.py:369-384`）。
  `tran`/`dc` 下 `t_pick = solution.x[-1]`、电流用 `branch_currents(..., at_index=len(xs)-1)`，
  **电压与电流严格同一时刻**（否则功耗 `|I·V|` 没有物理意义）。`live` 里因此多了
  **`t`** 字段（秒；op 恒为 `0.0`），前端可以用它标「这是哪个时刻的工作态」。
  早先这里取的是 **`t = 0`** 的首点：0→5V 阶跃的 RC 上 `live.items.r1.current = 0.0`，
  而同一份 `timeline` 中段明明是 `-2.35e-07 A`（更极端的 PULSE 电路里 `live` 全 0、
  图例显示「0/3 个器件导通」而真值 19.4 mA）——**那个行为已经修掉了**。
- **只有正好两个引脚的器件才有 `voltage` / `power`**（`web/ccl_api.py:401-412`）。
  三端器件（`Q` / `M`，3~4 引脚）与开关（`S`，4 引脚）的 `voltage` 与 `power` **一律是 `null`**，
  `current` 仍是真实值。原因：取「前两个引脚之差」得到的是任意一对引脚——实测 BJT 得
  `Vcb=1.008V`（真实 `Vce=1.706V`）、功耗 3.32mW（真实 5.63mW）；MOSFET 得 `Vdg=4.767V`
  （真实 `Vds=0.233V`）、功耗差 **20 倍**。与其给一个「看起来像对」的错数，不如不给。
  想看这些器件的电压请读节点电压（`analysis.traces`）。
- **`voltage` 是两端电压差的绝对值**（代码里 `abs(float(volt))`），**丢了极性**。
- **电压源没有 `current`**：`branch_currents()` 只解析 `i(@ref[...])` 形式，而电压源的支路电流在
  rawfile 里叫 `i(v1)` → `null`。注意这**只影响 `live`**：`timeline` 走的是另一个函数
  （`_current_key()`，`web/ccl_api.py:155`），它**认** `i(v1)`，所以 `timeline.series.v1.current`
  是有数据的（见 §4）。电流取不到的器件 `current`/`power` 都是 `null`，不估算。
- **`tran` 下 `live` 也不再是「只有时间序列、没有别的」**——它是末点的静态快照，
  但仍不是「稳态」概念（末点 = 仿真终点，电路未必已稳定）。要看全过程用 `timeline`；
  `web/ide/main.js` 只在**没有 timeline** 时才用 `live` 画静态快照
  （`if (d.live && !d.timeline) svg = applyLive(svg, d.live)`）。

## 4. `/api/ccl/run` 的 `timeline`：瞬态时间序列（只有 tran 有）

`collect_timeline(circuit, solution)`（`web/ccl_api.py:180`）。**仅 `kind=="tran"` 返回，
其它分析一律 `null`**（前端据此不建播放条）。

```json
"timeline": {
  "t": [0, 2e-06, 4e-06, "…"],
  "dt": 2e-06,
  "points": 400,
  "raw_points": 1042,
  "t_stop": 0.002,
  "series": {
    "r1": {"kind": "R", "current": ["…"], "voltage": ["…"]},
    "c1": {"kind": "C", "current": ["…"], "voltage": ["…"]},
    "v1": {"kind": "V", "current": ["…"], "voltage": ["…"]}
  }
}
```

- **点数窗口 120~400**（`_TIMELINE_MIN_POINTS` / `_TIMELINE_MAX_POINTS`，`web/ccl_api.py:69-70`）：
  原始点数 ≤ 400 就**原样返回**（实测 59 点 → 59 点、208 点 → 208 点）；超过则做**保峰降采样**，
  返回**不超过** 400 点。`points = len(t)`，`raw_points` 是降采样前的原始点数。
- **不是均匀抽样，是保峰（min/max 包络）**：`_downsample_idx()`（`web/ccl_api.py:73`）把时间轴分成
  `n_keep/2` 个桶，每桶取最大值点与最小值点。均匀抽样会**丢尖峰**——实测 10ns 步长、1ms 总长
  （10 万点）里一个 2µs 的脉冲，均匀抽 400 点后**一个非零点都不剩**（原始 214 个非零点 → 0 个），
  动画会显示「电路从没动过」。
- **⚠️ `points` 不等于 400，实测常在 200 上下**（这是当前实现的真实行为，别按 400 写死缓冲之外的东西）：
  本机实测 raw → points：`1023 → 200`、`5009 → 361`、`10020 → 200`、`5024 → 200`、`100030 → 201`。
  原因：桶内如果某条探针是平的（DC 电平/饱和段），该桶的 min 与 max 落在同一个下标上，
  于是这一桶只贡献 1 个点而不是 2 个。**包络仍然保留**（实测窄脉冲的峰值 1 A 在 202 点里仍在），
  但笔数会降。引用「最多 400 点」是对的，引用「一定 400 点」是错的。
- **所有曲线共用同一组抽样下标**（`_downsample_idx()`，**末位下标一定是 `n-1`**）：
  `t` 与每条 `series[*]` 的同一个位置对应同一时刻，不会错位。末点必取是为了让动画演到仿真终点
  （早先 `n_total=5024, n_keep=400` 时最后一格停在 5011，`t[-1]=4.9882e-4` 而仿真到 `5e-4`，
  少演 0.24% 时长，进度条永远走不满）。
- **取不到 `@dev[i]` 的器件不进 `series`**（绝不填 0）：两条都取不到的器件整个不出现。
  电压源**有** `current`（`i(v1)`，`_current_key()` 认这种名字），所以 `series.v1` 通常是
  `{kind, current, voltage}` 三项齐全——这与 `live.v1.current = null` 是两条不同的取数路径，
  别互相推论。
- `dt` 取相邻采样间隔的**中位数**（时间轴不均匀时比端点差值稳）；`t_stop` 是原始末点时间。
- **保真实测**（τ=100µs 的 RC 阶跃，raw 1024 点 → 400 点）：降采样序列对解析解
  `5(1−e^(−t/τ))` 的最大误差 **5.2e-05 V**，50% 到达时刻误差 **0.02%**
  （原始序列同口径 5.2e-05 V / 0.00%）。降采样没有引入可见失真。
- 采样密度实测：`c.tran(1e-8, 1e-3)` 出 **10 万点上下**原始数据（本机 100020~100049 点，耗时数秒），
  前端只拿 **200~400** 点（见上，`points` 不是固定 400）。

## 5. 前端：工作态与动画（`web/ide/`）

契约细节在 `web/ide/CONTRACT_SCHEMATIC.md` 的「工作态与瞬态动画层」一节，这一层与 CCL 的接口只有两条：

| 后端字段 | 前端用途 |
|---|---|
| `live` | **静态快照**：只在**没有 `timeline`** 时使用（`web/ide/main.js` 的 `applyResult`），op/dc 就是这样点亮的 |
| `timeline` | **逐帧动画**：`createPlayer()` 建播放条，每帧只改已存在节点的属性，不重渲染 |

三条不许破的规矩（实现位置见前端契约）：

1. `timeline` 为 `null` / 点数 < 2 / 没有可用的 `series` → **不建播放条、不动 SVG**（不演假动画）；
   `analysis.kind` 不是 `tran` 时即便后端误塞了 timeline 也忽略（前端会 `console.warn`）。
2. 某一帧取不到数据 → 那一层保持「看不见」，**绝不沿用上一帧的残影**（那是假数据）。
3. 点开关 = **带 `switch_states` 重跑仿真**，不是前端假切换；视觉先切（立刻反馈），
   数值以重新仿真回来的为准。

## 6. 文档与代码的对账（本轮核对结果）

写文档时逐条核过，下面这些**是当前代码的真实行为**，与某些注释/旧文档不一致，以本节为准：

| 位置 | 旧说法 | 实际行为 |
|---|---|---|
| `web/ccl_api.py:740` 的注释 | 「取波形最后一点（稳态）」后面跟一个 `if kind == "tran": pass` | 注释的**意图现在是真的**（`collect_live()` 对 tran/dc 确实取 `x[-1]`，电流同刻）；但**那个 `if/pass` 块是死代码**，改这一层时别以为它还控制什么 |
| `ccl/devices.py::Switch` docstring | model 名示例 `SW_MAXON_0p01_1000000000` | 实际 `SW_0p01_1e09_2p5`（`_num_tag` 派生，**含 Vt**） |
| `ccl/devices.py::switch_model_name` docstring | 「每个开关一个独立 model 名（`SW_MAXON_0p01` + 参数后缀）」 | 实际前缀是 `SW_`，后缀是 `{ron}_{roff}_{Vt}` |
| 前端导线流动「方向」 | 容易被读成「电流方向」 | 方向取自**该网络电流的时间导数符号**（`flowAt()`），稳态时固定正向；**不是电流极性**，只有强弱（`abs(I)/该网络峰值`）承载数据 |
| `live` 的 `voltage` | 容易被读成「电压」 | 是**绝对值**，没有极性；而且**三端及以上器件直接是 `null`**（见 §3） |
| `timeline` 的点数 | 「超过则均匀抽样到 400」 | 现在是**保峰降采样**，返回 ≤400 点，实测常在 **200** 上下（见 §4） |
| `web/ide/panels.js:438` 的 `downsample()` | 「面板降采样已改保峰」 | **后端**（`web/ccl_api.py:31` `_downsample()`）已改保峰；**前端这一份仍是均匀取下标**。它作用在后端已抽过的 traces 上，且 `maxPts = max(200, 绘图区宽 × 2)` 通常大于 400 → 实测基本**不触发**（等于直通）。缩到很窄时才生效，那时仍会丢尖峰 |

## 7. 新增的公开接口（可以直接 import / 调用的部分）

这一节列的是**跨模块的公开接口**，不写内部细节。全部按「宁可少复用，也不要错」设计。

### 7.1 仿真结果复用：`Circuit.remember_simulation()` / `recall_simulation()` / `netlist_fingerprint()`

写在 `ccl/core.py`（`netlist_fingerprint` 在 `:598`，`remember_simulation` 在 `:624`，
`recall_simulation` 在 `:638`）。**动机**：用户代码里通常已经 `c.tran(...)` 跑过一次
（沙箱执行时真跑了 ngspice），`run_analysis` 又跑一遍 —— 同一件事算两次。实测 35 器件电路：
沙箱 1.75s + 分析 1.87s，**49% 的时间在重算同一个结果**。

```python
Circuit.netlist_fingerprint() -> tuple
    # 「会影响网表」的状态指纹：电路名 + 每个器件的
    # (位号, kind, 端子顺序, value_tokens(), model, params, 开关参数) + 指令卡 + 端口
Circuit.remember_simulation(kind: str, params, solution) -> None
    # 记下刚跑完的那次（由 ccl.runner 的四个分析入口在成功后调用）
Circuit.recall_simulation(kind: str, params) -> Solution | None
    # 类型 + 参数数值 + 电路状态指纹**逐值相等**才返回，否则 None
```

**复用的判据是「参数浮点逐位相等 + 电路状态指纹一致」，认不出来的就直接不复用**：

- 参数走 `_norm_sim_params()`（`ccl/core.py:72`）归一成元组后比较，**比数值不比字符串**：
  沙箱里写 `c.tran(1e-6, 5e-4)`、前端 JSON 送来 `0.000001` —— `1e-06 != 0.000001` 作为字符串，
  但数值相等。实测 `{"t_step": 1e-6}` 与 `{"t_step": 0.000001}` 都能命中（`reused=true`）。
- **认不出的参数类型直接抛 `TypeError`**，`remember` 接住即**清空缓存**、`recall` 接住即返回
  `None` —— 宁可多跑一次 ngspice，也不猜「这两个参数大概一样」。
- 电路被动过就不复用：指纹包含 `value_tokens()`（**不是** `value` 的字符串，出网表的首选路径）、
  端子顺序、`model`、`params`、指令卡、端口。**开关参数单独纳入**（`_FP_EXTRA_ATTRS =
  ("on_voltage", "ctrl_blatant", "ron", "roff")`，`ccl/core.py:596`）：`Vt` 藏在
  `.model SW_* SW(...)` 里，不进指纹的话 `switch_states` 改过 Vt 之后会**错误复用旧波形**
  （开关点了没反应，且完全无提示）。
- `NaN` 不与自身相等 → 带 `NaN` 的参数天然永不复用。
- 缓存挂在 **`Circuit` 实例**上（`self._sim_cache`），**不是模块级全局**：
  `ThreadingHTTPServer` 下两个并发请求会互相覆盖，A 的检查拿到 B 的波形，数据静默串台
  （这个坑踩过一次，别再往模块级挪）。
- 缓存只是优化，**任何异常都不许影响仿真结果**（`ccl/runner.py:201` `_remember_simulation()`
  把 `remember` 全包在 `try/except: pass` 里）。

### 7.2 `apply_switch_states(circuit, states, *, warnings=None)`

`ccl/devices.py:785` 实现，`ccl/runner.py:183` 转发（`ccl.Circuit` 上没有这个方法，
`ccl/__init__.py` 也不导出它 —— 从 `ccl.runner` 或 `ccl.devices` 拿）。

```python
apply_switch_states(circuit, {"SW1": "on"}, warnings=notes) -> {"SW1": "source"|"vt"}
```

- 第三个参数是**关键字-only** 的 `warnings: list[str] | None`：给了就往里 `append` 提示。
  上位（`web/ccl_api.execute()`）把它挂到响应的 `warnings` 字段。
- **未知位号只写 warnings、不抛错、也不进返回值**（见 §2）。
- 返回值只包含**真的生效**的开关：位号不存在的不在里面，被忽略的不在里面。

### 7.3 响应字段 `analysis.reused`

`web/ccl_api.run_analysis()`（`web/ccl_api.py:448`）返回的 `analysis` 里新增布尔字段
**`reused`**：`true` = 这次没跑 ngspice，直接用了 `Circuit` 上已有的同结果；
`false` = 真跑了一遍。四种分析都有这个字段（`op` / `dc` / `tran` / `ac`）。

- 缓存键必须与 `ccl.runner` **记录时用的键完全一致**，否则永远不命中：
  `op → ("op", ())`、`tran → ("tran", (t_step, t_stop))`、`ac → ("ac", (f1, f2, pts))`、
  `dc → ("dc", (源位号小写, start, stop, step, 第二维或 None))`。
- **`elapsed_ms` 是「那一次真仿真」的耗时，不是 0**：复用时界面上的耗时不该因为「省了一次」
  变成一个好看但失真的数字。
- 实测：同参数第二次 → `reused=true` 且 `elapsed_ms=75.5`；改 `t_step` → `reused=false`；
  换成 `op` → `reused=false`（用户代码里只跑过 tran，op 没有现成结果）。
- 复用的正确性实测：两次独立 ngspice 运行的结果逐点最大偏差 **0.0**（完全相同）。

---

# AI 生成链的对账语义（第三轮审计后定案）

这一节是**契约级**的：谁改 `ccl/ai/generate.py` / `spec_check.py` / `sandbox.py`，
必须先满足这里的判据，否则「AI 说成功」又会变成一句空话。

## 1. `Unmeasurable`：测不到 ≠ 达标

`check_targets()` 早先用**同一个 `[]`** 表示三件相反的事：「需求里没抽到目标」「全部达标」
「**测不到**」。调用方一律读成「没问题」，于是沙箱被污染导致 `ac()` 返回 `None`、
退化电路没有输出节点、核对器自己抛异常——三种情况都会让产品**宣称成功**。
这是项目里最贵的一类 bug：拿不到证据就当无罪。

现在的契约分两个函数（`ccl/ai/spec_check.py`）：

```python
class Unmeasurable(RuntimeError)          # :292 —— 「测不了」，不是「达标」
check_targets_strict(targets, solution, node="out", circuit=None) -> list[Miss]   # :305
    # 主动抛 Unmeasurable 的情形：
    #   · solution 为空（这次没拿到仿真结果）
    #   · solution.node_names() 抛异常（读不出节点）
    #   · 没有任何节点
    #   · 电路里没有可测的输出节点
    #   · 目标里有电压类（vout）但**需求里没写输入电压**（vin is None）
    # 注意：`targets` 本身为空时返回 []（真的没什么要对账）
check_targets(targets, solution, node="out", circuit=None) -> list[Miss]          # :329
    # ⚠ 兼容旧签名：捕获 Unmeasurable 后返回 []。**新代码不许用**，只在老调用点保留
```

**`generate()` 必须把 `Unmeasurable` 当失败**（`ccl/ai/generate.py` 的 `_check_failed` 分支）：
这一轮判 `ok=False`、写 `warnings`、进修复循环，绝不"跳过对账然后交交付"。

**`vin` 不许猜**（`spec_check.py:231` 的 `_pick_vin()`）。早先写的是
「取目标值之前所有电压的最大值」，于是「设计一个 3.3V 电源电路，输出 3.3V」里的**产品名 3.3V**
被当成输入电压 → 一个正确的 12V→3.3V 分压被算成偏差 72.5% 判失败；换成
「把 12V 分压到 3.3V」就 `ok=True`。**同一个正确答案，成败取决于电压写在第几个位置**——
这种判据不能留。现在的优先级：① 显式输入标记（`输入/进线/供电/电源/Vin` + `从/由`）
② 目标值之前、**排除与目标相同**的电压里最靠后的一个 ③ 都没有 → `None` → 抛 `Unmeasurable`。

**抽不出来的指标要吭声**（`spec_check.unparsed_metrics()`，`:560`）。`parse_targets()` 只认
`fc/f0/gain_lin/gain_db/q/bw/vout` 七个 key，「输出 1A」「不超过 100mW」「误差小于 2%」
「相位裕度 45°」「CMRR 80dB」「输出阻抗 50Ω」全都返回 `[]`，而 `generate()` 把 `[]` 当成
「没有指标要对账」→ 交出一个不满足需求的结果仍然 `ok=True`。现在按**每个词**判断覆盖率
（不能「同窗口里有别的指标解析成功就算这个词也没问题」，那样实测会吞掉「纹波」「衰减 40dB」），
逐词报进 `warnings`。

## 2. 一次生成要同时满足六个闸门才算「成功」

| 闸门 | 判据 | 违反时 |
|---|---|---|
| 沙箱静态 | 导入白名单（`ccl`/`ccl.blocks`/`math`）、禁 `while`、禁下划线属性、禁 `__` 名字、**禁 `对象.属性 = …`** | 失败，回喂行号 + 原文 |
| 运行时护栏 | exec 后校验 `Circuit` 的 `ac/tran/op/dc/validate/to_spice/add/nodes/components` 没被替换，被替换则**回滚** | 失败（这轮作废，防进程级污染） |
| 结构 + lint | `validate()` 通过；`circuit.lint(None)` 无 `level=="error"` | 失败，进修复循环（`stage="lint"`） |
| 需求对账 | `check_targets_strict()` 不抛异常且无 `Miss` | 失败，进修复循环 |
| 模型自认不可能 | 源码 `#` 注释里没有「物理上不可能 / 互相矛盾」这类标记 | 按**未交付**处理，原话写进 `warnings` |
| 覆盖总闸 | 需求里有量化词+数字时，要么 `parse_targets()` 抽到了，要么 `unparsed_metrics()` 的结果被写进 `warnings` | 不判失败，但必须告知用户「这些指标没自动核对」 |

`fix()` 的诊断同一条纪律：`_diagnose(circuit, solution, source, request)`（`generate.py:607`）
**必须核需求**。早先它只跑 lint + `c.expect`，于是
`fix(code, request="截止频率必须改成10kHz")` 返回 `ok=True`、**模型调用 0 次**、
界面说「没发现问题」，而代码一字未动、实测仍 995 Hz。对账做不成也按「有问题」处理，
因为 `fix()` 是用「`problems` 为空」来判断「不需要修」的。

## 3. 取数格式：二进制 rawfile（ASCII 是回退，不是主路径）

`copilot/sim.py`：

- 注入的 `.control` 块写 `set filetype=binary`（`_use_binary_raw()`，`:409`）。
- `_parse_binary_raw()`（`:148`）：ASCII 头部（`No. Variables/Points/Flags` + 变量表）→
  一行 `Binary:\n` → 原生 double 序列（`Flags` 含 `complex` 时实部/虚部交替），`array("d")` 一次读完。
- **任何异常都返回 `None`**（读不到 `Binary:` 行、头部 >1 MB、`No. Variables/Points` 缺失、
  字节数不足），`run()` 于是回退 `_parse_ascii_raw()`（`:461-465`）。**取数优化不许决定仿真成败。**
- `CCL_RAW_ASCII=1`（也认 `true`/`yes`）强制 ASCII，出事时的手动开关。
- `.op` 的 plot 没有独立横轴，横轴一律 `0..n−1`，与 ASCII 解析口径一致（历史上这里错位过一次）。
- 契约：**同一份网表的数值必须逐点一致**。常驻用例
  `tests_ccl/test_sim.py::test_binary_raw_matches_ascii` 跑两遍（一遍 `CCL_RAW_ASCII=1`）
  逐点比对全部波形，要求最大偏差 <1e-12，`.op` 单独比。
- 实测：41 器件 RC 梯形、`.tran 1u 10m`、10008 点 → binary **883 ms** / ascii **3709 ms**，
  逐点最大偏差 **8.88e-16**（float64 舍入，被截断的是 ASCII 那一侧）。
