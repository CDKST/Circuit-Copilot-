"""SPICE 数值格式化：`fmt_value(v) -> str`。

这个文件很小，但它是整个网表的正确性闸门：一个数字写错，仿真结果依然会
「跑通」并给你一个看似合理的错误答案。所以这里的每条规则都有 ngspice-47
实测依据，写在下面。

## 结论先行：输出**不带单位后缀**的纯十进制数

实测（ngspice-47，`I1 0 out ac 1` + `R1 out 0 <值>` 读回 `|v(out)|`）：

    tok        实测解析值               说明
    ---------- ------------------------ ------------------------------------
    1m         1e-3                     毫
    1M         1e-3                     ★ 大写 M 也是「毫」！不是兆
    1meg       1e6                      兆必须写 meg / MEG
    1k / 1K    1e3                      大小写都行
    100n       1e-7                     ✓
    1t         1e12                     ngspice 额外支持 t=giga? → 实测为 1e12（tera）
    1g         9.999999999999999e+08    ★ 连 T/G 都有 1ULP 误差

所以后缀这条路有真实的坑：
- `1M` 与 `1m` 完全等价（都是毫）——用户想写兆而写成 `M` 就错了 10^9 倍；
- `1g`/`1t` 这类「高级」后缀解析后带 1ULP 误差；
- 后缀还要求调用者自己选幂次，容易在边界上反复纠结。

因此本模块统一输出**纯十进制**（如 `1e-7 → "0.0000001"`，`4700 → "4700"`），
并实测确认 ngspice 对纯十进制是精确解析的：

    "0.0000001"              → 1e-7        relerr 0
    "0.000000000000001"      → 1e-15       relerr 0
    "1000000000000000000"    → 1e18        relerr 0
    "340000000000000000000"  → 3.4e20      relerr 0
    "0.30000000000000004"    → 0.3         relerr 1.9e-16（double 极限）
    "0.00000012345678901234566" → 1.234567890123457e-07  relerr 4.3e-16

为了不写出 300 多位的巨型字面量（`5e-324` 的纯十进制有 326 个字符），
超过 `_MAX_PLAIN_LEN` 个字符时退回指数形式（`1e-40`、`1e-300`），
指数形式同样实测可被 ngspice 精确解析。

## 三条硬规则

1. `0` 输出 `"0"`（不是 `"-0"`、`"0.0"`）
2. 非有限值（`nan` / `inf`）**直接抛错**，绝不静默写进网表
   —— ngspice 会把 `nan` 当节点名/语法错误吞掉，最终表现成一个莫名其妙的
   「no convergence」，排查成本极高。
3. 字符串值：能解析成数字的就按数字格式化；不能解析的当作**已经合法的 SPICE
   token** 原样返回（如子电路名 `"OPA"`），但拒绝含空白的字符串（会破坏网表的
   「位号 节点… 值…」分列结构）。
"""

from __future__ import annotations

import math
from decimal import Decimal, InvalidOperation

from .errors import CCLConfigError

# 纯十进制形式超过这个长度就改用指数形式（纯粹是可读性/文件体积考虑，
# ngspice 本身并不限制长度——实测 "0.000…1"（43 字符，1e-41）也能精确解析）。
_MAX_PLAIN_LEN = 32

# 量级下限：低于这个值的 token 会被 ngspice 的 double 解析成次正规数甚至 0，
# 静默给出错误答案。实测（`let x = <token>` 后从 rawfile 读回）：
#
#   1e-305  -> 1.000000000000000e-305      ✓ 精确
#   1e-310  -> 9.999999999999969e-311      relerr 3e-15（次正规，开始掉精度）
#   1e-320  -> 9.999888671826830e-321      relerr 1.1e-4  ← 已经不可信
#   1e-323  -> 9.881312916824931e-324      relerr 1.2e-2
#   5e-324  -> 0.000000000000000e+00       ★ 直接归零
#
# 「静默归零」正是本模块要防的事故，所以宁可在这里报错。
_MIN_MAGNITUDE = 1e-320


def _to_float(v, *, what: str = "数值") -> float:
    """把 int/float/Decimal/bool 转成 float，非有限值抛错。"""
    if isinstance(v, bool):  # bool 是 int 的子类，显式放过并转成 0/1
        return float(v)
    if isinstance(v, (int, float)):
        f = float(v)
    elif isinstance(v, Decimal):
        f = float(v)
    else:
        raise CCLConfigError(
            f"{what} 必须是数字，收到 {type(v).__name__}（{v!r}）"
        )
    if not math.isfinite(f):
        raise CCLConfigError(
            f"{what} {f!r} 不是有限数值（nan/inf），无法写进 SPICE 网表。"
            f"请检查器件参数或计算过程（常见原因：除零、log(0)、开环增益发散）"
        )
    return f


def _plain(f: float) -> str:
    """最短往返的纯十进制表示（不含指数、不含多余尾零）。"""
    # repr() 给出「最短且能唯一还原该 double」的十进制串，
    # 用它构造 Decimal 再做定点格式化，可以拿到没有浮点尾巴的十进制写法。
    d = Decimal(repr(f))
    s = format(d, "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    return s


def _exponent(f: float) -> str:
    """指数形式，形如 `1e-40` / `1.2345678901234566e-07`。"""
    s = repr(f)
    if "e" not in s and "E" not in s:
        s = f"{f:.17e}"
        mant, _, exp = s.partition("e")
        if "." in mant:
            mant = mant.rstrip("0").rstrip(".")
        s = f"{mant}e{int(exp)}"
    s = s.replace("E", "e").replace("e+", "e")
    return s


def fmt_value(v) -> str:
    """把数值格式化成 ngspice 能**精确**解析的字符串。

    参数
    ----
    v : int | float | Decimal | str
        数字 → 格式化；字符串 → 若是数字则格式化，否则原样返回（当作 SPICE token）。

    返回
    ----
    str
        - `0` → `"0"`
        - 普通量级 → 纯十进制最短往返形式：`1e-7 → "0.0000001"`、`4700 → "4700"`
        - 极端量级（纯十进制超过 32 字符）→ 指数形式：`1e-40 → "1e-40"`
        - 绝不带单位后缀 —— `1M` 在 ngspice 里是**毫**（见模块文档的实测表）

    异常
    ----
    CCLConfigError
        nan / inf / 空字符串 / 含空白的字符串 / 非数字类型。

    例
    --
    >>> fmt_value(1e-7)
    '0.0000001'
    >>> fmt_value(100e-9)
    '0.0000001'
    >>> fmt_value(4700)
    '4700'
    >>> fmt_value(1e-3)
    '0.001'
    >>> fmt_value(0)
    '0'
    >>> fmt_value(1e12)
    '1000000000000'
    >>> fmt_value("OPA")     # 子电路名等非数字 token 原样通过
    'OPA'
    """
    if isinstance(v, str):
        s = v.strip()
        if not s:
            raise CCLConfigError("SPICE 值字段不能是空字符串")
        if any(c.isspace() for c in s):
            raise CCLConfigError(
                f"SPICE 值字段 {s!r} 含空白，会被网表当成多列；"
                f"请拆成多个 token 或去掉空白"
            )
        try:
            return fmt_value(float(s))
        except ValueError:
            # 不是数字 → 认定调用方给的是合法 SPICE token（子电路名、{param} 等）。
            return s
        except CCLConfigError:
            raise

    f = _to_float(v)
    if f == 0.0:
        return "0"
    if abs(f) < _MIN_MAGNITUDE:
        raise CCLConfigError(
            f"数值 {f!r} 太小：低于 ngspice 的 double 表示下限（实测 1e-320 已有 1e-4 "
            f"相对误差、5e-324 直接被解析成 0），写进网表只会得到一个静默的错误答案。"
            f"请检查单位（是不是把 uF 当成了 F 的某次幂？）"
        )

    plain = _plain(f)
    if len(plain) <= _MAX_PLAIN_LEN:
        return plain
    return _exponent(f)


def fmt_eng(v) -> str:
    """**仅供人看的**工程记数法（`1e-7 → "100n"`）。不要用于网表！

    这是给报告、图表标签、`explain()` 之类地方用的显示格式。网表请一律用
    :func:`fmt_value`——`1M`/`1m` 在 ngspice 里都表示「毫」，歧义就是在这儿踩的。
    这里输出的 `4.7k`/`100n` 只是标签，**不要**再被喂回网表。
    """
    f = _to_float(v)
    if f == 0.0:
        return "0"
    sign = "-" if f < 0 else ""
    a = abs(f)
    suffixes = ((12, "T"), (9, "G"), (6, "M"), (3, "k"), (0, ""),
                (-3, "m"), (-6, "u"), (-9, "n"), (-12, "p"), (-15, "f"))
    for exp, suf in suffixes:
        if a >= 10.0 ** exp:
            q = a / 10.0 ** exp
            s = f"{q:.4g}"
            if float(s) >= 1000.0 and exp < 12:  # 999.97 这类四舍五入后要进位
                continue_hi = dict(suffixes).get(exp + 3)
                if continue_hi is not None:
                    s = f"{a / 10.0 ** (exp + 3):.4g}"
                    suf = continue_hi
            return f"{sign}{s}{suf}"
    # 比 1e-15 还小，或超出 T 的表示范围：退回指数形式
    return sign + _exponent(a)


__all__ = ["fmt_value", "fmt_eng"]
