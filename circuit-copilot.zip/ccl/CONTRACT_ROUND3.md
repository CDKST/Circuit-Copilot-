# 第三轮：功能补全契约（直流扫描 + 瞬态指标）

## 为什么补这两个

| 洞 | 后果 |
|---|---|
| **没有 `.dc` 直流扫描** | 传输特性（Vout–Vin）、BJT 输出特性（Ic–Vce）、二极管伏安曲线——电子工程最常用的三种分析**一个都做不了** |
| **瞬态分析只剩原始波形** | 上升时间、超调量、建立时间、稳态值全要人眼看。瞬态做了等于没做 |

## 文件所有权（严格，不许越界）

| 文件 | 内容 | 负责人 |
|---|---|---|
| `ccl/runner.py` | `dc_sweep()` 实现 | **analysis-eng** |
| `ccl/solution.py` | `Solution.kind="dc"` 支持 + `sweep_var`/`sweep_values` + **瞬态指标** | **analysis-eng** |
| `web/ide/panels.js` | 直流扫描渲染（线性 x、多曲线）+ 瞬态指标卡片 | **web-eng** |
| `ccl/core.py` | `Circuit.dc(...)` 便捷方法 | Lead |
| `web/ccl_api.py` | 分析类型分发 + 序列化 | Lead |
| `web/ide/main.js` | 工具条加「直流扫描」+ 参数 | Lead |
| `ccl/assertions.py` | 新增 metric kind（可选，看 analysis-eng 交付后） | Lead |
| `ccl/CONTRACT.md` | 口径记录 | Lead |

## 一、直流扫描（analysis-eng）

### `ccl/runner.py`

```python
def dc_sweep(circuit, source: str, start: float, stop: float, step: float,
             *, second: tuple[str, float, float, float] | None = None,
             check: bool = True) -> Solution
```

- `source`：**器件位号**（如 `"V1"`），扫描它的直流值
- `second`：可选的第二维扫描 `(位号, start, stop, step)`，用于**输出特性曲线族**
  （如扫 Ib 得一族 Ic–Vce 曲线）
- 网表分析卡：`.dc <src> <start> <stop> <step>`；有 second 时
  `.dc <src1> <s1> <e1> <st1> <src2> <s2> <e2> <st2>`
- **注意**：被扫的源必须是**独立电压/电流源**，否则抛 `CCLConfigError` 并说明
- 步数保护：`(stop-start)/step > 5000` 时夹到 5000 并在 `Solution.warnings` 里说明

### `ccl/solution.py` 扩展

```python
# Solution 新增字段
kind: str                      # 现增加 "dc"
sweep_var: str = ""            # 被扫位号，如 "V1"
sweep_values: list[float] = [] # 主扫描轴取值
second_var: str = ""           # 第二维（可能为空）
second_values: list[float] = []

def dc_curves(self, node: str) -> list[dict]
    # 返回 [{"label": "V2=0.6V", "x": [...], "y": [...]}, ...]
    # 无第二维时返回单条 {"label": "", ...}
```

- 无第二维：`Solution.x` = 扫描值，`v(node)` 可直接用
- 有第二维：ngspice 的 `.dc` 嵌套扫描输出按「外层固定、内层扫完」分段，
  **必须正确切段**，每段的 x 是内层扫描值；`dc_curves()` 负责切段并附 label
- **切段错了会画出乱七八糟的折线**，这是本任务最容易错的地方，务必用
  「2 段 × 3 点」和一个「3 段 × 4 点」的小网表核对点数与分段

### `ccl/core.py`（Lead 会加，供你参考签名）

```python
def dc(self, source: str, start: float, stop: float, step: float, *, second=None, check=True)
    -> Solution
```

## 二、瞬态指标（analysis-eng，`ccl/solution.py`）

```python
def rise_time(self, node: str, low: float = 0.1, high: float = 0.9) -> float | None
    # 10%~90% 上升时间（秒）。找不到返回 None，不编数。
def fall_time(self, node: str, low: float = 0.1, high: float = 0.9) -> float | None
def overshoot_pct(self, node: str) -> float | None
    # 相对**稳态值**的百分比超调；无超调返回 0.0；测不到返回 None
def settling_time(self, node: str, tol: float = 0.02) -> float | None
    # 最后一次离开 ±tol·稳态 带并再未回来的时刻
def steady_state(self, node: str, tail: float = 0.1) -> float | None
    # 取波形最后 tail 比例的平均值（比取最后一点稳，避免噪声/末点抖动）
```

**口径要求（必须写进 docstring）**：
- `steady_state` 用**最后 10% 时间窗的均值**，不用最后一点
- `overshoot_pct` 相对稳态值算：`(max - ss)/|ss| * 100`（阶跃到负值也能用）
- `rise_time` 用**第一次**穿过 low/high 的时刻（不是最后一次）
- 全部**测不到就返回 None**，绝不编数（这是本项目一贯原则）

## 三、前端（web-eng，`web/ide/panels.js`）

### 1. 直流扫描渲染
- `opts.kind === "dc"` 时：x 轴**线性**、y 轴线性（不是 dB）
- 调 `dc_curves(node)` 拿曲线族，每条不同颜色、图例可开关
- 十字线读数显示 `V1=3.2V  out=1.85V`
- 有第二维时图例显示每段 label

### 2. 瞬态指标卡片
- `showMetrics()` 收到 `rise_time/fall_time/overshoot_pct/settling_time/steady_state` 时，
  **带单位格式化**（时间用 µs/ms、百分比带 %），不要显示裸数字
- 只显示存在的项（值为 null 的跳过，不要显示一堆 "—"）

## 验收（Lead 卡）

### 直流扫描
1. 分压电路扫 Vin（0→10V，步 1V）→ 输出应是一条**直线**，斜率 = R2/(R1+R2)，
   实测点数 = 11，且每点都满足 `Vout = Vin·R2/(R1+R2)` ±0.5%
2. 二极管 + 电阻扫 Vin → 得到**指数形**伏安/传输曲线
3. **第二维扫描**：`V1` 扫 0→5V（6 点）× `I1` 扫 0→1mA（3 点）→
   `dc_curves()` 必须返回 **3 条曲线、每条 6 点**（段数/点数错就是切段 bug）
4. 步数保护：`(stop-start)/step = 10000` 时被夹到 5000 且给出 warning

### 瞬态指标
5. RC 阶跃（τ=100µs）：`rise_time` ≈ 2.197τ = 219.7µs（一阶系统 10→90% 正好 2.197τ），误差 <3%
6. 二阶欠阻尼阶跃：`overshoot_pct` 应对得上 `exp(-πζ/√(1-ζ²))·100`，其中 **ζ = 1/(2Q)**
   - Q=0.707 → 4.3%；Q=1 → **16.3%**；Q=2 → **44.4%**；Q=5 → 72.9%
   - ⚠️ 本节初稿把「16.3%」错标成 Q=2 的值，实际那是 Q=1。实现是对的，是验收标准写错了，
     已用 4 组 Q 交叉验证（实测 4.34/16.34/44.51/72.95 vs 理论 4.32/16.30/44.43/72.92，误差 <0.5%）
7. 同一电路的 `steady_state` 应 ≈ 终值（5V ±1%），且用最后 10% 均值比取末点更稳
8. 测不到的（比如纯正弦无阶跃）返回 `None` 而不是乱给

## 环境
- `cd /storage/emulated/0/文件夹/dz/circuit-copilot`（bash 每次新 shell）
- Python 3.14 + ngspice-47，只用标准库
- 重启服务用 `bash start.sh`，**不要 pkill**
- 回归：`python3 tests_ccl/run_all.py`（146 项，必须保持全绿）
