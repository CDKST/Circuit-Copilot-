"""把一次电路设计导出成 Markdown 报告。

报告的价值在于**可粘贴、可存档、可评审**：把结构、网表、实测、检查、规格核对
放在一份文件里，别人不用重跑就能看懂这个电路是什么、验证过什么。

刻意不含：仿真时间戳以外的元数据、模型的自述、任何「本设计性能良好」的废话。
"""

from __future__ import annotations

import datetime
import math


def _fmt(x, nd: int = 4) -> str:
    if x is None:
        return "—"
    try:
        f = float(x)
    except (TypeError, ValueError):
        return str(x)
    if not math.isfinite(f):
        return "—"
    a = abs(f)
    if a != 0 and (a < 1e-3 or a >= 1e5):
        return f"{f:.3e}"
    return f"{f:.{nd}g}"


def _human(comp) -> str:
    kind = comp.kind.upper()
    v = comp.value
    if v is None:
        return comp.model or ""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)
    try:
        from copilot import elements as E
        if kind == "R":
            return E.human_r(v)
        if kind == "C":
            return E.human_c(v)
        if kind == "L":
            return E.human_l(v)
    except Exception:
        pass
    return f"{v:.6g}"


def _node_list(solution) -> list[str]:
    try:
        return list(solution.node_names())
    except Exception:
        return []


def _device_sections(circuit) -> set[str]:
    """电路里真实出现的器件族（R/C/L/GBW/A0）。给容差表过滤用。"""
    out: set[str] = set()
    try:
        for c in circuit.components:
            k = str(getattr(c, "kind", "")).upper()
            if k in ("R", "C", "L"):
                out.add(k)
            elif k in ("X", "Q", "M"):
                out.add("GBW"); out.add("A0")
    except Exception:
        return {"R", "C", "L", "GBW", "A0"}
    return out


def markdown(circuit, solution=None, *, title: str | None = None,
             analysis_desc: str = "") -> str:
    """生成完整报告。solution 可为 None（只讲结构）。"""
    name = getattr(circuit, "name", "circuit")
    L: list[str] = []
    L.append(f"# 电路报告：{title or name}\n")
    L.append(f"生成时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    # ---- 概况 ----
    comps = list(getattr(circuit, "components", []) or [])
    nodes = []
    try:
        nodes = circuit.nodes()
    except Exception:
        pass
    L.append("## 概况\n")
    L.append(f"- 器件数：**{len(comps)}**")
    L.append(f"- 节点数：**{len(nodes)}**")
    if analysis_desc:
        L.append(f"- 分析：{analysis_desc}")
    if solution is not None:
        kind = getattr(solution, "kind", "")
        if kind:
            L.append(f"- 分析类型：{kind.upper()}")
        ms = getattr(solution, "elapsed_ms", None)
        if ms:
            L.append(f"- 仿真耗时：{_fmt(ms, 3)} ms")
    L.append("")

    # ---- 器件表 ----
    L.append("## 器件清单\n")
    L.append("| 位号 | 类型 | 值 / 模型 | 端子 |")
    L.append("|---|---|---|---|")
    for c in comps:
        L.append(f"| {c.ref} | {c.kind} | {_human(c)} | {' · '.join(c.nodes())} |")
    L.append("")

    # ---- 网表 ----
    # ⚑ 必须带上分析卡。早先这里用无参 `to_spice()`，而界面走的是
    # `to_spice(analysis=...)` → 导出的网表**漏掉 .ac/.tran/.op**，
    # 复制到 ngspice 里根本跑不起来（「导出的网表是死的」）。
    try:
        net = circuit.to_spice(analysis_desc) if analysis_desc else circuit.to_spice()
    except TypeError:
        try:
            net = circuit.to_spice()
        except Exception as e:
            net = f"* 网表生成失败：{e}"
    except Exception as e:
        net = f"* 网表生成失败：{e}"
    L.append("## SPICE 网表\n")
    L.append("```spice")
    L.append(net.rstrip())
    L.append("```\n")

    # ---- 实测 ----
    if solution is not None:
        kind = getattr(solution, "kind", "")
        L.append("## 实测结果\n")
        if kind == "op":
            L.append("| 节点 / 支路 | 值 |")
            L.append("|---|---|")
            try:
                for n in solution.node_names():
                    try:
                        v = solution.value_at(n, 0.0)
                    except Exception:
                        continue
                    unit = "A" if str(n).lower().startswith("i(") else "V"
                    L.append(f"| {n} | {_fmt(v)} {unit} |")
            except Exception:
                pass
            L.append("")
        elif kind == "tran":
            # ⚑ 瞬态**不能**套交流的 f3db/peak_db。早先这里对 kind != "op" 一律走 AC 分支，
            # 于是 5V 直流节点被写成「峰值 13.98 dB」（=20log10(5)）、0V 节点写成「−300 dB」，
            # 而界面上同一份数据是 5V/0V 的波形 —— 用户导出报告去评审，
            # 评审的是一份和屏幕无关的数字。
            L.append("| 节点 | 末值（仿真终点） | 峰值 | 谷值 |")
            L.append("|---|---|---|---|")
            for n in _node_list(solution):
                if str(n).lower().startswith("i("):
                    continue
                try:
                    w = solution.v(n)
                    ys = [complex(v).real for v in w.y] or [0.0]
                    unit = "V"
                    L.append(f"| {n} | {_fmt(ys[-1])} {unit} | {_fmt(max(ys))} {unit} "
                             f"| {_fmt(min(ys))} {unit} |")
                except Exception:
                    continue
            L.append("")
        elif kind == "dc":
            # 直流扫描：报扫描范围与末点，不报 f3db
            L.append("| 节点 | 起点 | 末点 |")
            L.append("|---|---|---|")
            for n in _node_list(solution):
                if str(n).lower().startswith("i("):
                    continue
                try:
                    w = solution.v(n)
                    ys = [complex(v).real for v in w.y] or [0.0]
                    L.append(f"| {n} | {_fmt(ys[0])} V | {_fmt(ys[-1])} V |")
                except Exception:
                    continue
            L.append("")
        else:
            L.append("| 节点 | 关键指标 |")
            L.append("|---|---|")
            try:
                for n in solution.node_names():
                    if str(n).lower().startswith("i("):
                        continue
                    bits = []
                    try:
                        f3 = solution.f3db(n)
                        if f3:
                            bits.append(f"−3dB {_fmt(f3)} Hz")
                    except Exception:
                        pass
                    try:
                        pk = solution.peak_db(n)
                        if pk is not None and math.isfinite(float(pk)):
                            bits.append(f"峰值 {_fmt(pk)} dB")
                    except Exception:
                        pass
                    L.append(f"| {n} | {' · '.join(bits) if bits else '—'} |")
            except Exception:
                pass
            L.append("")

    # ---- 检查 ----
    try:
        issues = circuit.lint(solution)
    except Exception:
        issues = []
    L.append("## 电路检查\n")
    if not issues:
        L.append("静态与工作点检查均未发现问题。\n")
    else:
        L.append("| 级别 | 问题 | 位置 | 说明 |")
        L.append("|---|---|---|---|")
        tag = {"error": "错误", "warn": "警告", "info": "提示"}
        for i in issues:
            L.append(f"| {tag.get(i.level, i.level)} | {i.title} | "
                     f"{getattr(i, 'ref', '') or '—'} | {i.detail} |")
        L.append("")

    # ---- 规格核对 ----
    exps = list(getattr(circuit, "expectations", []) or [])
    if exps:
        L.append("## 规格核对\n")
        try:
            from .assertions import evaluate
            ac = solution if getattr(solution, "kind", "") == "ac" else None
            op = solution if getattr(solution, "kind", "") == "op" else None
            if ac is None and any(e.needs_ac() for e in exps):
                ac = circuit.ac(1.0, 1e6, 100)
            if op is None and any(e.needs_op() for e in exps):
                op = circuit.op()
            rep = evaluate(exps, circuit, ac_sol=ac, op_sol=op)
            L.append(f"**结果：{'全部通过' if rep.passed else f'{len(rep.failed)} 项未达标'}**\n")
            L.append("| 规格 | 要求 | 实测 | 结论 |")
            L.append("|---|---|---|---|")
            for r in rep.results:
                e = r.expect
                cmp = {"eq": "=", "min": "≥", "max": "≤"}[e.mode]
                actual = ("—" if r.actual is None or (isinstance(r.actual, float) and math.isnan(r.actual))
                          else f"{_fmt(r.actual)}{e.unit}")
                L.append(f"| {e.label()} | {cmp} {_fmt(e.value)}{e.unit} | {actual} | "
                         f"{'✅' if r.ok else '❌'} |")
            L.append("")
        except Exception as e:
            L.append(f"（规格核对失败：{type(e).__name__}: {e}）\n")

    L.append("---\n")
    L.append("*由 CCL（Circuit Code Library）生成。电路以代码为准，"
             "本报告只是它的一次快照。*")
    return "\n".join(L)
