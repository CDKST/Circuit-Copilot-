"""断言机制：让电路代码自带「规格」，一改元件就知道哪里坏了。

## 为什么这是代码优先方案的最大价值

画图方案没法把「这个滤波器必须在 1kHz 处 −3dB」写进图里，只能写在旁边的文档，
或者靠人眼比对。代码可以：

    c.expect("fc", "out", 1e3, tol=0.05)
    c.expect("gain", "out", 10, tol=0.01)
    c.expect("v", "b", 0.7, tol=0.1)
    c.check()      # → 全部通过 / 列出哪条不达标

改一个电阻，几十条规格自动重跑。这就是「可回归的设计」，
也是「代码为核心」相对「图形为核心」最实际的差别。

## 容差语义（踩过一次坑，见 ccl/CONTRACT.md 的 D 系列）

- `kind` 用了**相对容差**（频率/增益/电压/功率）：tol=0.05 表示 ±5%
- dB 类指标用**绝对容差**：tol=0.6 表示 ±0.6dB
- 三种比较方式：`eq`（落在区间内）/ `min`（不低于）/ `max`（不高于）

把相对容差当绝对容差用，会让「1000Hz ±10%」变成「999.9Hz 以上」，
于是一个完全合格的 990Hz 设计被判失败——所以这里显式区分。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

# 哪些指标需要哪种分析
_NEEDS_AC = {"fc", "gain", "gain_db", "peak_db", "q", "bw", "value_at"}
_NEEDS_OP = {"v", "i", "p"}
_NEEDS_TRAN = {"rise_time", "fall_time", "overshoot_pct", "settling_time", "steady_state"}

# dB 类指标用绝对容差
_ABS_TOL = frozenset({"gain_db", "peak_db", "overshoot_pct"})

_UNIT = {"fc": "Hz", "gain": "", "gain_db": "dB", "peak_db": "dB", "q": "",
         "bw": "Hz", "v": "V", "i": "A", "p": "W", "value_at": "",
         "rise_time": "s", "fall_time": "s", "settling_time": "s",
         "overshoot_pct": "%", "steady_state": "V"}

_LABEL = {"fc": "−3dB 截止频率", "gain": "电压增益", "gain_db": "增益", "peak_db": "峰值增益",
          "q": "品质因数 Q", "bw": "带宽", "v": "节点电压", "i": "支路电流",
          "p": "电阻功耗", "value_at": "指定频率处幅值",
          "rise_time": "上升时间(10–90%)", "fall_time": "下降时间(90–10%)",
          "settling_time": "建立时间(±tol)", "overshoot_pct": "超调量",
          "steady_state": "稳态值"}


@dataclass
class Expect:
    """一条规格声明。"""

    kind: str
    target: str            # 节点名或位号（看 kind）
    value: float
    tol: float = 0.05
    mode: str = "eq"       # eq / min / max
    at: float | None = None   # kind="value_at" 时指定频率
    note: str = ""

    def label(self) -> str:
        base = _LABEL.get(self.kind, self.kind)
        return f"{base}({self.target})" + (f" {self.note}" if self.note else "")

    @property
    def unit(self) -> str:
        return _UNIT.get(self.kind, "")

    def needs_ac(self) -> bool:
        return self.kind in _NEEDS_AC

    def needs_op(self) -> bool:
        return self.kind in _NEEDS_OP

    def needs_tran(self) -> bool:
        return self.kind in _NEEDS_TRAN

    def band(self) -> tuple[float, float]:
        d = self.tol if self.kind in _ABS_TOL else abs(self.value) * self.tol
        if self.mode == "min":
            return self.value - d, math.inf
        if self.mode == "max":
            return -math.inf, self.value + d
        return self.value - d, self.value + d


@dataclass
class ExpectResult:
    expect: Expect
    actual: float

    @property
    def ok(self) -> bool:
        if self.actual is None or (isinstance(self.actual, float) and math.isnan(self.actual)):
            return False
        lo, hi = self.expect.band()
        return lo <= self.actual <= hi

    @property
    def rel_err(self) -> float:
        e = self.expect
        if self.actual is None or (isinstance(self.actual, float) and math.isnan(self.actual)):
            return math.inf
        if e.kind in _ABS_TOL:
            return abs(self.actual - e.value)
        return abs(self.actual - e.value) / max(abs(e.value), 1e-12)

    def message(self) -> str:
        e = self.expect
        cmp = {"eq": "=", "min": "≥", "max": "≤"}[e.mode]
        u = e.unit
        a = "测不到" if self.actual is None or (isinstance(self.actual, float) and math.isnan(self.actual)) \
            else f"{self.actual:.4g}{u}"
        return (f"{'✅' if self.ok else '❌'} {e.label():28s} 要求 {cmp} {e.value:.4g}{u}"
                f"  实测 {a}")


@dataclass
class Report:
    """一次断言核对的结果。"""

    results: list[ExpectResult] = field(default_factory=list)
    netlist: str = ""
    elapsed_ms: float = 0.0

    @property
    def passed(self) -> bool:
        return bool(self.results) and all(r.ok for r in self.results)

    @property
    def failed(self) -> list[ExpectResult]:
        return [r for r in self.results if not r.ok]

    def __str__(self) -> str:
        head = ("全部通过 ✅" if self.passed else
                f"有 {len(self.failed)} 项未达标 ❌") if self.results else "没有声明任何规格"
        return head + "\n" + "\n".join("  " + r.message() for r in self.results)

    def table(self) -> list[dict]:
        return [{"label": r.expect.label(), "kind": r.expect.kind, "node": r.expect.target,
                 "mode": r.expect.mode, "target": r.expect.value, "unit": r.expect.unit,
                 "actual": None if (r.actual is None or r.actual != r.actual) else r.actual,
                 "ok": r.ok} for r in self.results]


def _interp_logx(xs: list[float], ys: list[float], target: float) -> float | None:
    """对数频率轴上线性插值求 y=target 的 x。"""
    for i in range(1, len(xs)):
        y0, y1 = ys[i - 1], ys[i]
        if y0 == y1:
            continue
        if (y0 <= target <= y1) or (y0 >= target >= y1):
            if xs[i - 1] <= 0 or xs[i] <= 0:
                continue
            t = (target - y0) / (y1 - y0)
            return 10 ** (math.log10(xs[i - 1]) + t * (math.log10(xs[i]) - math.log10(xs[i - 1])))
    return None


def _val_at(solution, node: str, x: float) -> float:
    try:
        return float(solution.value_at(node, x))
    except Exception:
        return float("nan")


def _measure(e: Expect, ac_sol, op_sol, tran_sol=None) -> float:
    """把一条规格换算成实测值。测不到就返回 NaN（不要编）。"""
    k = e.kind

    if k in ("v", "i", "p"):
        sol = op_sol
        if sol is None:
            return float("nan")
        if k == "p":
            comp = getattr(sol, "_circuit_ref", None)
            return float("nan")  # 由上层统一处理
        try:
            return float(sol.value_at(e.target, 0.0))
        except Exception:
            return float("nan")

    if k in _NEEDS_TRAN:
        if tran_sol is None:
            return float("nan")
        return _measure_tran(k, e.target, tran_sol)

    sol = ac_sol
    if sol is None:
        return float("nan")
    xs = list(getattr(sol, "x", []) or [])
    if not xs:
        return float("nan")

    if k == "fc":
        try:
            v = sol.f3db(e.target)
            return float(v) if v else float("nan")
        except Exception:
            return float("nan")

    if k in ("gain", "gain_db"):
        g = _val_at(sol, e.target, xs[0])
        if not math.isfinite(g):
            return float("nan")
        if k == "gain":
            return abs(g)
        return 20 * math.log10(abs(g)) if g else float("nan")

    if k == "peak_db":
        try:
            return float(sol.peak_db(e.target))
        except Exception:
            return float("nan")

    if k == "value_at":
        f = e.at if e.at else xs[0]
        return abs(_val_at(sol, e.target, f))

    if k == "bw":
        try:
            db = sol.db(e.target)
        except Exception:
            return float("nan")
        if not db:
            return float("nan")
        peak = max(db)
        imax = db.index(peak)
        # 单极点低通的峰值就落在扫描起点（imax==0），低侧根本不存在 −3dB 交点，
        # 「两侧都找到」的写法会让低通带宽永远是 NaN。
        # 与 ccl/ai/spec_check.py 的口径保持一致：峰在起点时只算高频侧。
        if imax <= 1:
            # 低通（峰在扫描起点）：带宽 = 从直流到 −3dB 点，也就是 hi 本身。
            # 不能减 xs[0]：那样带宽会随扫频起点漂移（100Hz 起扫低估 9%、
            # 300Hz 起扫低估 21%），同一电路换个扫描范围就被判不合格。
            #
            # 但还要防另一件事：峰值落在扫描起点时，`peak=max(db)` 可能只是
            # "区间内最高点"而不是真实通带增益（扫频起点已在滚降段）。
            # 判据：扫描起点必须比 −3dB 点低至少一个十倍频，通带增益才可信。
            # 只查"起点局部是否平坦"是不够的——单极点滚降很缓（−20dB/dec），
            # 300Hz 起点处局部也平（相邻点只差 0.01dB），但此时 db[0] 已比 DC 低 0.38dB，
            # 拿它当参考会把带宽算高 8.7%。十倍频的间距才真正保证落到平台区。
            # 测不到就返回 NaN，绝不编数。
            hi = _interp_logx(xs, db, peak - 3.0103)
            if not hi:
                return float("nan")
            if xs[0] * 10 > hi:
                return float("nan")
            return hi
        lo = _interp_logx(xs[: imax + 1], db[: imax + 1], peak - 3.0103)
        hi = _interp_logx(xs[imax:], db[imax:], peak - 3.0103)
        return (hi - lo) if (lo and hi) else float("nan")

    if k == "q":
        # 二阶网络在 f0 处相位恒为 ∓90°（与 Q 无关），
        # 用它定 f0，再用 |H(f0)|/|H(通带)| 求 Q。Q≤0.707 没有峰化，带宽比法会失效。
        try:
            ph = list(sol.phase(e.target))
        except Exception:
            return float("nan")
        f0 = _interp_logx(xs, ph, -90.0) or _interp_logx(xs, ph, 90.0)
        if not f0:
            return float("nan")
        h = abs(_val_at(sol, e.target, f0))
        g0 = abs(_val_at(sol, e.target, xs[0]))
        return h / g0 if g0 else float("nan")

    return float("nan")


def _measure_tran(kind: str, node: str, sol) -> float:
    """瞬态指标。后端没实现对应方法时返回 NaN（测不到就判未达标，不编数）。"""
    fn = getattr(sol, kind, None)
    if not callable(fn):
        return float("nan")
    try:
        v = fn(node)
        return float(v) if v is not None else float("nan")
    except Exception:
        return float("nan")


def evaluate(expects: list[Expect], circuit=None, *, ac_sol=None, op_sol=None,
             tran_sol=None) -> Report:
    """对一组规格做核对。给哪个 solution 就核哪类指标，缺的一律判「测不到」。"""
    results = [ExpectResult(e, _measure(e, ac_sol, op_sol, tran_sol)) for e in expects]
    if circuit is not None:
        # 电阻功耗单独算：需要拿到器件值
        for r in results:
            if r.expect.kind != "p":
                continue
            comp = circuit.find(r.expect.target)
            if comp is None or op_sol is None:
                r.actual = float("nan")
                continue
            try:
                a, b = comp.nodes()[0], comp.nodes()[1]
                va = 0.0 if a in ("0", "GND") else float(op_sol.value_at(a, 0.0))
                vb = 0.0 if b in ("0", "GND") else float(op_sol.value_at(b, 0.0))
                r.actual = (va - vb) ** 2 / float(comp.value)
            except Exception:
                r.actual = float("nan")
    return Report(results=results)
