"""CCL 数据模型：Component / Pin / Circuit。

**这是整个库的契约**，其余模块（compile / devices / runner / solution / ai）都围绕它工作。
改动这里等于改公开 API，务必同步更新 ccl/CONTRACT.md。

## 三个刻意的设计决定

1. **节点是字符串，地节点固定为 "0"**
   与 SPICE 一致，不给用户发明一套地符号。`GND = "0"`。

2. **引脚顺序即 SPICE 端子顺序**
   `Component.pins` 是有序列表，第 i 个引脚对应网表里第 i 个节点。
   器件类负责保证这个顺序正确（这是最容易出错、也最该集中在一处的地方）。

3. **多端器件的构建规则**：两端件用 `(a, b, value)`；三端及以上按**引脚顺序**
   作为位置参数，并且同名关键字必须可用（`OpAmp(inp, inn, out, *, gbw, a0)`）。
   这样既有统一的位置约定，又不逼用户记引脚顺序。

4. **子电路采用「内联展平」而非 .subckt**
   复用时把子电路的器件复制进来，位号加前缀（`U1.R1`）、内部节点加前缀（`U1.n1`）。
   这样没有作用域管理，也不会有 .subckt 名字冲突——M1 阶段最不容易出错的做法。
   （器件自己的宏模型如运放仍用 .subckt，由器件类输出 directives。）
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field, replace

import warnings as _warnings

from .errors import (CCLAssertionError, CCLConfigError, CCLNetlistError,
                     CCLWarning, NodeError, RefError)

GND = "0"
"""地节点。SPICE 约定，必须叫 "0"。"""

_RESERVED_NODE_CHARS = set(" \t\r\n()=,'\"")
_VALID_NODE = re.compile(r"^[A-Za-z0-9_.\-+\[\]]+$")


@dataclass
class Pin:
    """一个器件的引脚：名字 + 连接的节点名。"""

    name: str
    node: str

    def __post_init__(self):
        self.node = normalize_node(self.node)


def normalize_node(node) -> str:
    """统一节点表示：允许 int 0 → "0"，去掉空白。"""
    if isinstance(node, int):
        if node != 0:
            raise NodeError(f"整数节点只支持 0（地），收到 {node}")
        return GND
    if not isinstance(node, str):
        raise NodeError(f"节点必须是字符串或 0，收到 {type(node).__name__}")
    n = node.strip()
    if n == "":
        raise NodeError("节点名不能为空字符串；地节点请用 GND 或 0")
    if n.upper() in ("GND", "GROUND"):
        return GND
    if not _VALID_NODE.match(n):
        bad = sorted(set(n) & _RESERVED_NODE_CHARS)
        raise NodeError(f"节点名 {n!r} 含非法字符 {bad}（不允许空白、括号、逗号、等号）")
    return n


def _norm_sim_params(params) -> tuple:
    """分析参数归一化成可比较的元组（仿真缓存用）。

    为什么不能比分析卡**字符串**：沙箱里用户写的是 `c.tran(1e-6, 5e-4)`，
    Web 层拿到的是前端 JSON 里的 `0.000001` —— 数值相等，字符串不等
    （`1e-06` vs `0.000001`）。比字符串就等于永远不复用；比数值才对。

    认不出的类型直接抛：调用方（remember/recall）接住后不复用，
    宁可多跑一次 ngspice，也不猜「这两个参数大概一样」。
    """
    if params is None:
        return ()
    if isinstance(params, (str, bytes)) or not isinstance(params, (tuple, list)):
        params = (params,)
    out = []
    for p in params:
        if p is None:
            out.append(None)
        elif isinstance(p, str):
            out.append(p)
        elif isinstance(p, bool):
            out.append(float(p))
        elif isinstance(p, (int, float)):
            out.append(float(p))
        elif isinstance(p, (tuple, list)):
            out.append(_norm_sim_params(p))
        else:
            raise TypeError(f"分析参数 {p!r}（{type(p).__name__}）无法比较，不复用缓存")
    return tuple(out)


@dataclass
class Component:
    """电路里的一个器件。

    kind      SPICE 器件首字母族，如 "R" "C" "L" "V" "I" "D" "X"（子电路实例）
    ref       位号，如 "R1"；必须全电路唯一
    pins      有序引脚，顺序即网表端子顺序
    value     标量值（电阻阻值、电容容值、源电压…）；也可为 None 由模型/参数决定
    model     引用的 .model 名或 .subckt 名（如 "1N4148"、"OPA"）
    params    附加参数，写进网表的键值对（如 {"temp": 25}）
    meta      用户附加信息（注释、说明、来源），不参与网表
    """

    kind: str
    ref: str
    pins: list[Pin]
    value: float | str | None = None
    model: str | None = None
    params: dict[str, float | str] = field(default_factory=dict)
    meta: dict[str, str] = field(default_factory=dict)

    # ---- 便捷访问 ----
    def pin(self, name: str) -> Pin:
        for p in self.pins:
            if p.name == name:
                return p
        raise CCLConfigError(
            f"器件 {self.ref} 没有名为 {name!r} 的引脚，可用：{[p.name for p in self.pins]}"
        )

    def node(self, pin_name: str) -> str:
        return self.pin(pin_name).node

    def nodes(self) -> list[str]:
        return [p.node for p in self.pins]

    def clone(self, *, ref: str | None = None, pin_nodes: dict[str, str] | None = None) -> "Component":
        """复制一个器件，可改位号、可重映射引脚节点。供子电路内联使用。"""
        pins = self.pins
        if pin_nodes:
            pins = [Pin(p.name, pin_nodes.get(p.name, p.node)) for p in self.pins]
        else:
            pins = [Pin(p.name, p.node) for p in self.pins]
        return replace(self, ref=ref or self.ref, pins=pins,
                       params=dict(self.params), meta=dict(self.meta))

    def value_tokens(self) -> list[str]:
        """网表里跟在节点之后的那些字段（器件负责覆盖）。

        默认：把 value 格式化成一个数字。电源会选择 "DC 5 AC 1"，
        运放会给出子电路名与参数，各自覆盖本方法。
        """
        from .format import fmt_value
        if self.value is None:
            return []
        return [fmt_value(self.value)]

    def describe(self) -> str:
        """人话描述，用于报错与报告。"""
        return f"{self.ref}({self.kind}) 端子 {'-'.join(self.nodes())}"


class Circuit:
    """一份电路：一组器件 + 一组分析/模型指令。

    用法（M1）：
        c = Circuit("rc_lp")
        c.V("in", GND, ac=1)
        c.R("in", "out", 1.6e3)
        c.C("out", GND, 100e-9)
        sol = c.ac(1, 1e6)          # 由 ccl.runner 提供
        sol.f3db("out")
    """

    def __init__(self, name: str = "circuit"):
        self.name = name
        self.components: list[Component] = []
        self.directives: list[str] = []   # .model / .param / .options 等
        self._counters: dict[str, int] = {}
        self._sub_count = 0
        self.expectations: list = []   # assertions.Expect 列表（见 c.expect）
        self.ports: dict[str, str] = {}  # 对外端口 {端口名: 内部节点名}（blocks 用）
        #: 最近一次仿真的结果缓存：`(key, Solution)`，见 remember_simulation()。
        #: ⚑ **必须是实例属性**。曾经把 Solution 放在模块级全局里，Web 层
        #: （ThreadingHTTPServer）两个并发请求会互相覆盖，A 的检查拿到 B 的波形，
        #: 数据静默串台 —— 这个坑踩过一次，不要再往模块级挪。
        self._sim_cache: tuple | None = None

    # ------------------------------------------------------------------
    # 器件添加
    # ------------------------------------------------------------------
    def add(self, comp: Component) -> Component:
        """加入一个器件。自动补位号、检查重复。"""
        if not comp.ref:
            comp.ref = self._next_ref(comp.kind)
        if self.find(comp.ref) is not None:
            raise RefError(f"位号 {comp.ref} 重复；每个器件位号必须唯一")
        self._bump_counter(comp.kind, comp.ref)
        self.components.append(comp)
        return comp

    def _next_ref(self, kind: str) -> str:
        n = self._counters.get(kind, 0) + 1
        while self.find(f"{kind}{n}") is not None:
            n += 1
        return f"{kind}{n}"

    def _bump_counter(self, kind: str, ref: str) -> None:
        m = re.fullmatch(re.escape(kind) + r"(\d+)", ref)
        if m:
            self._counters[kind] = max(self._counters.get(kind, 0), int(m.group(1)))

    def find(self, ref: str) -> Component | None:
        for c in self.components:
            if c.ref == ref:
                return c
        return None

    # ---- 器件便捷方法（实现委托给 ccl.devices，避免 core 依赖具体器件知识）----
    def R(self, a, b, value, ref: str | None = None, **kw):
        from .devices import Resistor
        return self.add(Resistor(a, b, value, ref=ref, **kw))

    def C(self, a, b, value, ref: str | None = None, **kw):
        from .devices import Capacitor
        return self.add(Capacitor(a, b, value, ref=ref, **kw))

    def L(self, a, b, value, ref: str | None = None, **kw):
        from .devices import Inductor
        return self.add(Inductor(a, b, value, ref=ref, **kw))

    def V(self, a, b, dc: float = 0.0, ac: float = 0.0, ref: str | None = None, **kw):
        from .devices import VoltageSource
        return self.add(VoltageSource(a, b, dc=dc, ac=ac, ref=ref, **kw))

    def I(self, a, b, dc: float = 0.0, ac: float = 0.0, ref: str | None = None, **kw):
        from .devices import CurrentSource
        return self.add(CurrentSource(a, b, dc=dc, ac=ac, ref=ref, **kw))

    def OpAmp(self, inp, inn, out, *, gbw: float = 1e6, a0: float = 1e5,
              ref: str | None = None, **kw):
        """运放（三端）。节点既可按序位置传，也可用关键字传，两种写法等价：

            c.OpAmp("src", "sum", "out", gbw=1.3e6)          # 按引脚顺序
            c.OpAmp(inp="src", inn="sum", out="out")         # 关键字，更不易读错

        引脚顺序固定为 inp / inn / out，与 SPICE 子电路端子顺序一致。
        """
        from .devices import OpAmp
        return self.add(OpAmp(inp, inn, out, gbw=gbw, a0=a0, ref=ref, **kw))

    # ---- M2 器件便捷方法 ----
    def D(self, a, k, model: str | None = None, ref: str | None = None, **kw):
        from .devices import Diode
        return self.add(Diode(a, k, model, ref=ref, **kw))

    def Q(self, c, b, e, model: str | None = None, ref: str | None = None, **kw):
        from .devices import Bjt
        return self.add(Bjt(c, b, e, model, ref=ref, **kw))

    def M(self, d, g, s, bulk=None, model: str | None = None, ref: str | None = None, **kw):
        from .devices import Mosfet
        return self.add(Mosfet(d, g, s, bulk, model, ref=ref, **kw))

    def SW(self, a, b, ctrl, *, on_voltage: float = 2.5, ron: float = 0.01,
           roff: float = 1e9, model: str | None = None, ref: str | None = None, **kw):
        """电压控制开关（SPICE `S` 元件）。

            c.SW("a", "b", "ctrl")                 # 位号自动 SW1、SW2…
            c.SW("a", "b", ctrl_net, on_voltage=2.5, ron=0.01)

        第 3 个参数是**控制节点**（`V(ctrl)` 高于 `on_voltage` 时导通）。
        控制端参考地，网表写作 `S1 a b ctrl 0 SW_<...>`，并配一条
        `.model SW_<...> SW(Ron=.. Roff=.. Vt=..)`。op / tran / dc 都能跑。
        """
        from .devices import Switch
        return self.add(Switch(a, b, ctrl, on_voltage=on_voltage, ron=ron,
                               roff=roff, model=model, ref=ref, **kw))

    def PULSE(self, a, b, v1=0.0, v2=5.0, td=0.0, tr=1e-9, tf=1e-9,
              pw=500e-6, per=1e-3, ref: str | None = None, **kw):
        """脉冲电压源。只在 c.tran() 里有效。"""
        from .devices import PulseSource
        return self.add(PulseSource(a, b, v1=v1, v2=v2, td=td, tr=tr, tf=tf,
                                    pw=pw, per=per, ref=ref, **kw))

    def SIN(self, a, b, vo=0.0, va=1.0, freq=1e3, td=0.0, theta=0.0,
            ref: str | None = None, **kw):
        from .devices import SinSource
        return self.add(SinSource(a, b, vo=vo, va=va, freq=freq, td=td,
                                  theta=theta, ref=ref, **kw))

    # ------------------------------------------------------------------
    # 结构查询
    # ------------------------------------------------------------------
    def nets(self) -> dict[str, list[tuple[str, str]]]:
        """{节点: [(位号, 引脚名), ...]}，按首次出现顺序。"""
        out: dict[str, list[tuple[str, str]]] = {}
        for c in self.components:
            for p in c.pins:
                out.setdefault(p.node, []).append((c.ref, p.name))
        return out

    def nodes(self) -> list[str]:
        return list(self.nets())

    def node_capacitance_to_ground(self, node: str) -> bool:
        """该节点是否直接到地（用于判断浮地）。"""
        return any(p.node == GND for c in self.components for p in c.pins
                   if node in c.nodes())

    # ------------------------------------------------------------------
    # 校验
    # ------------------------------------------------------------------
    def validate(self, *, allow_floating: bool = False) -> list[str]:
        """结构自检，返回警告列表；致命问题抛异常。

        检查的是「电路描述本身是否讲得通」，不做电气分析（那要靠仿真）。
        """
        if not self.components:
            raise CCLNetlistError("电路里没有任何器件")

        warnings: list[str] = []
        netmap = self.nets()

        # 已声明的端口允许暂时不接（blocks 用法：端口是留给外部连的）
        ports = set((getattr(self, "ports", {}) or {}).values())

        # 1) 单引脚节点 = 悬空，几乎一定是笔误
        floating = [n for n, pins in netmap.items()
                    if n != GND and len(pins) < 2 and n not in ports]
        if floating and not allow_floating:
            detail = "；".join(
                f"节点 {n!r} 只连着 {netmap[n][0][0]}.{netmap[n][0][1]}" for n in floating
            )
            raise NodeError(
                f"有 {len(floating)} 个悬空节点（只连了一个引脚）：{detail}。"
                f"如果是刻意保留的测试点，用 validate(allow_floating=True)"
            )

        # 2) 完全没有地
        if GND not in netmap:
            raise NodeError(
                "电路里没有任何器件接地（GND / 0）。SPICE 必须有参考地，否则无解"
            )

        # 3) 位号与器件类型首字母不符
        for c in self.components:
            if c.ref[0].upper() != c.kind[0].upper():
                warnings.append(f"位号 {c.ref} 与器件类型 {c.kind} 首字母不一致")

        return warnings

    # ------------------------------------------------------------------
    # 子电路复用（内联展平）
    # ------------------------------------------------------------------
    def use(self, sub: "Circuit", *, prefix: str | None = None,
            maps: dict[str, str] | None = None) -> "Circuit":
        """把另一个电路内联进本电路。

        maps 用于把子电路的对外节点接到本电路的节点，例如：
            top.use(inv_amp(), maps={"in": "src", "out": "out"})
        未在 maps 里出现的节点会被加上前缀，成为内部节点。
        """
        if sub is self:
            raise CCLConfigError("不能把电路内联到自己里面")

        # 子电路里带独立源（V/I）是常见误用：内联后它会和外部节点并联，
        # 一旦形成「两个电压源接同一对节点」就是 singular matrix，
        # 而报错出现在仿真阶段，离用户写 use() 的地方很远。
        srcs = [c.ref for c in sub.components if c.kind.upper() in ("V", "I")]
        if srcs:
            _warnings.warn(
                f"子电路 {sub.name!r} 含独立源 {srcs}，内联后会与外部电路共用节点。"
                f"若外部也存在源，可能形成并联电压源导致 singular matrix。"
                f"通常应该把激励留在顶层电路，子电路只做无源/受控部分。",
                CCLWarning,
                stacklevel=2,
            )
        self._sub_count += 1
        prefix = prefix or f"U{self._sub_count}"
        maps = dict(maps or {})

        def rename(node: str) -> str:
            if node in maps:
                return normalize_node(maps[node])
            if node == GND:
                return GND
            return f"{prefix}.{node}"

        for c in sub.components:
            self.add(c.clone(ref=f"{prefix}.{c.ref}",
                             pin_nodes={p.name: rename(p.node) for p in c.pins}))
        for d in sub.directives:
            if d not in self.directives:
                self.directives.append(d)
        return self

    def port(self, name: str) -> str:
        """取端口对应的内部节点名。"""
        if name not in self.ports:
            raise CCLConfigError(
                f"电路 {self.name!r} 没有端口 {name!r}；可用端口：{sorted(self.ports)}"
            )
        return self.ports[name]

    def use_ports(self, sub: "Circuit", connections: dict[str, str] | None = None,
                  *, prefix: str | None = None) -> "Circuit":
        """按**端口名**内联子电路，不用记内部节点叫什么。

            top.use_ports(amp, {"in": "src", "out": "y"})
            # 等价于 top.use(amp, maps={"<amp.ports['in']>": "src", ...})

        没连接的端口保持内部化（会加前缀）。
        """
        connections = dict(connections or {})
        if not sub.ports:
            raise CCLConfigError(
                f"电路 {sub.name!r} 没有声明 ports，无法按端口连接；"
                f"请用 use(sub, maps={{内部节点: 外部节点}}) 或给 sub 设置 ports"
            )
        unknown = set(connections) - set(sub.ports)
        if unknown:
            raise CCLConfigError(
                f"电路 {sub.name!r} 没有这些端口：{sorted(unknown)}；可用：{sorted(sub.ports)}"
            )
        maps = {sub.ports[port]: node for port, node in connections.items()}
        return self.use(sub, prefix=prefix, maps=maps)

    # ------------------------------------------------------------------
    # 指令
    # ------------------------------------------------------------------
    def directive(self, line: str) -> "Circuit":
        """添加一条 SPICE 指令（.model / .param / .options …）。"""
        line = line.strip()
        if not line.startswith("."):
            raise CCLNetlistError(f"指令必须以 '.' 开头，收到 {line!r}")
        if line not in self.directives:
            self.directives.append(line)
        return self

    # ------------------------------------------------------------------
    # M3：规格断言 / 检查 / 变体 / 参数扫描
    # ------------------------------------------------------------------
    def expect(self, kind: str, target: str | None = None, value: float | None = None,
               *, tol: float = 0.05, mode: str = "eq", at: float | None = None,
               note: str = "") -> "Circuit":
        """声明一条规格。可链式调用。

            c.expect("fc", "out", 1e3, tol=0.05)     # 截止 1kHz ±5%
            c.expect("gain", "out", 10, tol=0.01)    # 增益 10 倍 ±1%
            c.expect("peak_db", "out", 0.5, mode="max")   # 峰化不超过 0.5dB
            c.expect("v", "b", 0.7, tol=0.1)         # 工作点：节点 b 电压 0.7V±10%
            c.expect("p", "R1", 0.2, mode="max")     # R1 功耗不超过 0.2W

        kind 可用：fc / gain / gain_db / peak_db / q / bw / v / i / p / value_at
        """
        from .assertions import Expect
        if mode not in ("eq", "min", "max"):
            raise CCLConfigError(f"mode 必须是 eq/min/max，收到 {mode!r}")
        if tol < 0:
            raise CCLConfigError(f"tol 必须 >= 0，收到 {tol!r}")
        if value is None:
            raise CCLConfigError(f"expect({kind!r}) 必须给 value")
        if target is None and kind not in ("p",):
            raise CCLConfigError(f"expect({kind!r}) 必须给 target（节点名或位号）")
        self.expectations.append(Expect(kind, target or "", float(value),
                                        float(tol), mode, at, note))
        return self

    def verify(self, *, ac=(1.0, 1e6, 100), tran=(1e-6, 5e-3), check: bool = True):
        """跑一遍所有声明的规格，返回 Report。缺分析的指标判「测不到」。

        tran 只在有瞬态类规格（rise_time / overshoot_pct …）时才会跑。
        """
        from .assertions import evaluate
        need_ac = any(e.needs_ac() for e in self.expectations)
        need_op = any(e.needs_op() for e in self.expectations)
        need_tran = any(e.needs_tran() for e in self.expectations)
        ac_sol = op_sol = tran_sol = None
        if need_ac:
            f1, f2, pts = (ac if len(ac) == 3 else (ac[0], ac[-1], 100))
            ac_sol = self.ac(f1, f2, pts, check=check)
        if need_op:
            op_sol = self.op(check=check)
        if need_tran:
            t_step, t_stop = (tran if len(tran) == 2 else (1e-6, 5e-3))
            tran_sol = self.tran(t_step, t_stop, check=check)
        rep = evaluate(self.expectations, self,
                       ac_sol=ac_sol, op_sol=op_sol, tran_sol=tran_sol)
        rep.elapsed_ms = ((ac_sol.elapsed_ms if ac_sol else 0.0)
                          + (op_sol.elapsed_ms if op_sol else 0.0)
                          + (tran_sol.elapsed_ms if tran_sol else 0.0))
        if ac_sol is not None:
            rep.netlist = ac_sol.netlist
        elif op_sol is not None:
            rep.netlist = op_sol.netlist
        return rep

    def check(self, **kw):
        """`verify()` 的别名。文档与示例里常写 `c.check()`，保持可用。"""
        return self.verify(**kw)

    def assert_ok(self, **kw):
        """断言版本：不通过就抛 CCLAssertionError（消息带逐项对比）。"""
        rep = self.verify(**kw)
        if not rep.passed:
            raise CCLAssertionError(str(rep))
        return rep

    def lint(self, solution=None, **kw):
        """静态 + 工作点检查（不需要的话 solution 可省）。"""
        from .lint import lint as _lint
        return _lint(self, solution, **kw)

    def with_(self, **overrides) -> "Circuit":
        """返回一个改了器件值的**副本**（不改原电路）。键是位号，如 c.with_(R1=2e3)。"""
        new = Circuit(f"{self.name}_mod")
        for c in self.components:
            new.add(c.clone())
        new.directives = list(self.directives)
        new.expectations = list(self.expectations)
        for ref, v in overrides.items():
            comp = new.find(ref)
            if comp is None:
                raise RefError(f"with_() 找不到位号 {ref!r}；现有位号：{[c.ref for c in new.components]}")
            try:
                fv = float(v)
            except (TypeError, ValueError):
                raise CCLConfigError(f"with_({ref}={v!r}) 必须是数字") from None
            if fv <= 0:
                raise CCLConfigError(f"with_({ref}={v!r}) 必须 > 0")
            comp.value = fv
        return new

    def sweep(self, ref: str, values, **fixed):
        """参数扫描：对每个值产出一个电路副本。

            for r, c in rc.sweep("R1", [1e3, 2e3, 4.7e3]):
                print(r, c.ac(1, 1e6).f3db("out"))

        fixed 里的键值会应用到每一份副本上（用于多参数联合扫描）。
        """
        for v in values:
            yield v, self.with_(**{ref: v, **fixed})

    # ------------------------------------------------------------------
    # 编译入口（实现见 ccl.compile）
    # ------------------------------------------------------------------
    def to_spice(self, analysis: str | None = None, *, title: str | None = None) -> str:
        from .compile import compile_circuit
        return compile_circuit(self, analysis=analysis, title=title)

    # ------------------------------------------------------------------
    # 仿真入口（实现见 ccl.runner）
    # ------------------------------------------------------------------
    def run(self, netlist: str, **kw):
        from .runner import simulate
        return simulate(self, netlist, **kw)

    def ac(self, f_start: float = 1.0, f_stop: float = 1e6,
           points: int = 200, *, check: bool = True):
        from .runner import ac_sweep
        return ac_sweep(self, f_start, f_stop, points, check=check)

    def op(self, *, check: bool = True):
        from .runner import operating_point
        return operating_point(self, check=check)

    def tran(self, t_step: float, t_stop: float, *, check: bool = True):
        from .runner import transient
        return transient(self, t_step, t_stop, check=check)

    def dc(self, source: str, start: float, stop: float, step: float, *,
           second: tuple[str, float, float, float] | None = None,
           check: bool = True):
        """直流扫描（传输特性 / 输出特性曲线）。

            c.dc("V1", 0, 10, 1)                      # 扫 V1 的直流值 0→10V，步 1V
            c.dc("V1", 0, 5, 1, second=("I1", 0, 1e-3, 0.5e-3))   # 两维，得曲线族

        source 必须是独立源（V / I）的**位号**。
        """
        from .runner import dc_sweep
        return dc_sweep(self, source, start, stop, step, second=second, check=check)

    # ------------------------------------------------------------------
    # 仿真结果复用（同一件事别跑两遍）
    # ------------------------------------------------------------------
    #: 这些属性的变化**不进网表的首选路径**（`value_tokens()` 只看 value/model），
    #: 但会改网表内容 —— 开关的 Vt 就藏在 `.model SW_* SW(Ron=.. Roff=.. Vt=..)`
    #: 里。指纹漏掉它们，`switch_states` 改过 Vt 之后就会错误复用旧波形
    #: （开关点了没反应，且**完全无提示**）。所以逐个纳入指纹。
    _FP_EXTRA_ATTRS = ("on_voltage", "ctrl_blatant", "ron", "roff")

    def netlist_fingerprint(self) -> tuple:
        """「会影响网表」的状态指纹：器件值/模型/端子 + 指令 + 开关参数 + 端口。

        只用于判断**上一次仿真结果还能不能用**（见 remember_simulation）。
        刻意做成结构指纹而不是网表字符串：出网表要跑整条 compile 链，
        这里只要一个能比较的元组，O(器件数) 个 repr。
        """
        comps = []
        for c in self.components:
            try:
                toks = tuple(str(t) for t in (c.value_tokens() or ()))
            except Exception:
                # 取不到就退化为 value 的 repr —— 宁可指纹不稳（=少复用），
                # 也绝不给出一个「看起来一样其实不一样」的指纹。
                toks = ("<tokens-error>", repr(getattr(c, "value", None)))
            extra = tuple(repr(getattr(c, a, None)) for a in self._FP_EXTRA_ATTRS)
            params = tuple(sorted((str(k), repr(v)) for k, v in
                                  (getattr(c, "params", None) or {}).items()))
            comps.append((str(getattr(c, "ref", "")), str(getattr(c, "kind", "")),
                          tuple(str(n) for n in c.nodes()), toks,
                          str(getattr(c, "model", None) or ""), params, extra))
        return (str(self.name),
                tuple(comps),
                tuple(str(d) for d in (self.directives or ())),
                tuple(sorted((str(k), str(v)) for k, v in (self.ports or {}).items())))

    def remember_simulation(self, kind: str, params, solution) -> None:
        """记住刚跑完的那次仿真（`(分析类型, 参数)` + 电路状态指纹 → Solution）。

        由 `ccl.runner` 的四个分析入口在仿真成功后调用，`web/ccl_api.run_analysis`
        在重跑之前先 `recall_simulation()` 看一眼 —— 用户代码里已经 `c.tran(...)`
        跑过一次时，同一次运行里就不必让 ngspice 再算一遍。
        """
        try:
            key = (str(kind), _norm_sim_params(params), self.netlist_fingerprint())
        except Exception:
            self._sim_cache = None      # 指纹都算不出来就别复用
            return
        self._sim_cache = (key, solution)

    def recall_simulation(self, kind: str, params):
        """取回上次的仿真结果；类型/参数/电路状态**逐值相等**才返回，否则 None。

        「宁可少复用，也不要错误复用」：任何一个参数对不上（含 NaN —— NaN 与
        自己也不相等，天然不会被复用）或电路被改过（值、端子、`.model`、
        开关 Vt）都返回 None，调用方照常真跑一遍。
        """
        cache = getattr(self, "_sim_cache", None)
        if not cache:
            return None
        try:
            want = (str(kind), _norm_sim_params(params), self.netlist_fingerprint())
        except Exception:
            return None
        key, sol = cache
        return sol if key == want else None

    # ------------------------------------------------------------------
    def __repr__(self) -> str:
        return f"<Circuit {self.name!r}: {len(self.components)} 器件, {len(self.nets())} 节点>"

    def describe(self) -> str:
        lines = [f"电路 {self.name!r}：{len(self.components)} 个器件 / {len(self.nets())} 个节点"]
        for c in self.components:
            val = "" if c.value is None else f" = {c.value}"
            lines.append(f"  {c.ref:<6} {c.kind:<3} {val:<14} 端子 {'-'.join(c.nodes())}")
        return "\n".join(lines)
