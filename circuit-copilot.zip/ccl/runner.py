"""仿真入口：`Circuit` → 分析卡 → 网表 → `copilot.sim` → `Solution`。

这一层刻意做得很薄——真正碰 ngspice 的是已验证的 `copilot.sim`，这里只负责：

1. **生成分析卡**（`.ac dec N f1 f2` / `.op` / `.tran step stop`）
2. **让器件的宏模型进网表**（运放的 `.subckt`，见 `_prepare()`）
3. **把 `SimError` 翻译成 `CCLConvergenceError`**，并保留网表与原始输出——
   上层自纠（AI 修复、人看报错）全靠这两个字段，丢了就只能说「仿真失败了」
4. **计时**：`Solution.elapsed_ms` 记录整条链路耗时，性能退化能被看见

## 为什么分析卡由这里生成，而不由用户手写

用户面对的是 Python；`.ac dec 200 1 1e6` 这种卡是 SPICE 方言。写错一个字段
（`dec` 写成 `decade`、把 stop 写在 start 前面）ngspice 可能静默不跑。
把它收在一处、做参数校验，比散落在用户代码里安全。
"""

from __future__ import annotations

import math
import re
import time

from .errors import CCLConfigError, CCLConvergenceError, CCLNetlistError
from .solution import Solution

__all__ = ["ac_sweep", "operating_point", "transient", "dc_sweep", "simulate",
           "apply_switch_states"]

_RE_ANALYSIS = re.compile(r"^\s*\.(ac|op|tran|dc|noise|tf|disto)\b", re.I | re.M)

#: 单维最多几个点。超过就放大步长——5000 点一次 DC 扫描已经要几秒，
#: 而 10 万点通常是「步长少写一个 m」的手误（1 步 1µV），跑了也没人看。
_DC_MAX_POINTS = 5000
#: 第二维最多几段（一条曲线一段，几十条已经画不下了）。
_DC_MAX_CURVES = 500
#: 两维的总点数上限。5000×500 = 250 万点会让 ngspice 跑到天亮。
_DC_MAX_TOTAL = 100_000


# --------------------------------------------------------------------------
# 内部工具
# --------------------------------------------------------------------------
def _fmt(value: float) -> str:
    """分析卡里的数值：优先用 ccl.format（core-eng），缺了就本地 .6g。

    ngspice 对 `1e-07`、`1e+06` 这类科学计数法解析是正确的，所以本地实现
    也够用；有 ccl.format 时统一走它，保证全库只有一种数字写法。
    """
    from .devices import _fmt as dev_fmt
    return dev_fmt(value)


def _positive(value, name: str) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise CCLConfigError(f"{name} 必须是数字，收到 {value!r}") from None
    if not (v > 0) or v != v or v == float("inf"):
        raise CCLConfigError(f"{name} 必须 > 0 且有限，收到 {value!r}")
    return v


def _finite(value, name: str) -> float:
    """扫描端点/步长可以是 0 甚至负数，但必须是有限数。"""
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise CCLConfigError(f"{name} 必须是数字，收到 {value!r}") from None
    if not math.isfinite(v):
        raise CCLConfigError(f"{name} 必须是有限数，收到 {value!r}")
    return v


def _sweep_values(start: float, stop: float, step: float) -> list[float]:
    """ngspice 线性扫描用到的取值序列：`start + k·step`，直到越过 stop。

    实测对齐：`start=0 stop=1 step=0.3` ngspice 给 4 点（0/0.3/0.6/0.9，
    **不**补一个 1.0），所以是 floor(区间/步长)+1。那个 1e-6 相对容差用来防
    「4999.0000001 → 4998」这类末点丢失。
    """
    if step == 0:
        return [start]
    ratio = (stop - start) / step
    n = int(math.floor(ratio + 1e-6 * max(1.0, abs(ratio)))) + 1
    n = max(1, n)
    return [start + k * step for k in range(n)]


def _source_of(circuit, ref, what: str = "被扫器件"):
    """按位号找到独立源（V / I），否则抛 CCLConfigError 说清楚哪里不对。"""
    if not isinstance(ref, str) or not ref.strip():
        raise CCLConfigError(f"{what}必须是位号字符串（如 \"V1\"），收到 {ref!r}")
    want = ref.strip()
    comp = None
    find = getattr(circuit, "find", None)
    if callable(find):
        comp = find(want)
    if comp is None:                       # 位号大小写写错也认（V1 / v1）
        for c in getattr(circuit, "components", []) or []:
            if str(getattr(c, "ref", "")).lower() == want.lower():
                comp = c
                break
    if comp is None:
        refs = [c.ref for c in getattr(circuit, "components", []) or []]
        raise CCLConfigError(
            f"电路 {getattr(circuit, 'name', '?')!r} 里没有位号 {want!r}（{what}）；"
            f"可用位号：{', '.join(refs) or '（空）'}"
        )
    kind = str(getattr(comp, "kind", "")).upper()
    if kind not in ("V", "I"):
        raise CCLConfigError(
            f"{what}必须是**独立电压源/电流源**（位号首字母 V 或 I），"
            f"但 {comp.ref} 是 {kind} 型器件（{type(comp).__name__}）。"
            f"直流扫描只能扫源的直流值；要扫电阻/电容参数请用值扫描（sweep / with_）"
        )
    return comp


def _source_unit(comp) -> str:
    return "A" if str(getattr(comp, "kind", "")).upper() == "I" else "V"


def _spice_ref(comp) -> str:
    """写进网表的位号（内联子电路的 `U1.V1` 必须变成 `V.U1.V1`）。"""
    try:
        from .compile import netlist_ref
    except Exception:                      # compile.py 缺失时退回原始位号
        return str(getattr(comp, "ref", ""))
    return str(netlist_ref(comp))


def _prepare(circuit, check: bool):
    """编译前的两件事：结构自检 + 把器件宏模型塞进 directives。"""
    if check:
        circuit.validate()
    _install_device_directives(circuit)
    return circuit


def _install_device_directives(circuit) -> None:
    """把器件自带的 `.subckt` 等指令补进 `circuit.directives`。

    为什么在 runner 而不是在 compile：契约允许两条路（编译层收集 `directives()`
    或用户手动 `circuit.directive(...)`），但运放宏模型是**必需**的——少了它
    ngspice 直接报 unknown subckt。放在这里，无论编译层实现到哪一步，
    运放都能跑。`Circuit.directive()` 自带去重，重复调用无副作用。
    """
    from .devices import component_directives

    for line in component_directives(circuit):
        circuit.directive(line)


def _drop_stale_switch_directives(circuit) -> None:
    """改过开关的 Vt 之后，把 directives 里**已经用不到的**开关 `.model` 摘掉。

    为什么必须做：compile 会先把 `circuit.directives` 收进网表，再收集器件自己的
    `directives()`。旧的 `.model SW_..._2p5 Vt=2.5` 若留在 `circuit.directives`，
    就会和新生成的 `.model SW_..._1 Vt=1` 一起进网表。虽然名字不同、不会有
    「静默只认后一份」的问题，但网表里躺着一条没人引用的 model 是噪音，
    也会让「到底按哪个 Vt 算」变得难查。

    判据用**当前需要的名字集合**，删除所有「长得像开关 model 但不在集合里」的行。
    ⚑ 早先的实现用「改完之后的新名字」去匹配旧行，方向反了 —— 一条都删不掉
    （实测：改 off 之后网表里同时留着 Vt=2.5 和 Vt=1 两条 model 卡）。
    """
    from .devices import Switch, switch_model_name

    wanted = {switch_model_name(c) for c in getattr(circuit, "components", []) or []
              if isinstance(c, Switch)}
    kept = []
    for d in circuit.directives:
        head = d.strip().split()
        # 只清我们自己生成的开关 model（前缀 SW_），别碰用户手写的模型
        if (len(head) >= 2 and head[0].lower() == ".model"
                and head[1].startswith("SW_") and head[1] not in wanted):
            continue
        kept.append(d)
    circuit.directives = kept


def apply_switch_states(circuit, states: dict | None, *,
                        warnings: list[str] | None = None) -> dict[str, str]:
    """按 `{"SW1": "on"|"off"}` 覆盖开关状态（实现在 `ccl.devices`）。

    返回 `{位号: "source"|"vt"}` 说明每个开关是怎么被强制的。**不改用户代码
    文本**——改的是 circuit 对象上的控制源 DC 值，或该开关 .model 的 Vt。

    未知位号（界面上残留、代码里已经删掉的开关）**不抛错**，只往 `warnings`
    里写一条提示并忽略——覆盖状态是界面附加意图，不该否决整次运行。
    """
    from .devices import apply_switch_states as _apply

    done = _apply(circuit, states, warnings=warnings)
    if done:
        _drop_stale_switch_directives(circuit)
    return done


def _remember_simulation(circuit, kind: str, params, sol) -> None:
    """把这次仿真记到 circuit 实例上，供上层「同一次运行里别跑两遍」复用。

    ⚑ 缓存挂在 **circuit 实例**上（见 core.Circuit.remember_simulation），不是模块
    全局：ThreadingHTTPServer 下两个并发请求各建各的电路，模块级缓存会串台。

    缓存只是优化，**任何异常都不许影响仿真结果** —— 记不上就记不上，多跑一次而已。
    """
    remember = getattr(circuit, "remember_simulation", None)
    if callable(remember):
        try:
            remember(kind, params, sol)
        except Exception:
            pass


def _compile(circuit, analysis: str) -> str:
    """调编译层生成网表；compile.py 还没交付时给一条能看懂的报错。"""
    try:
        return circuit.to_spice(analysis)
    except ModuleNotFoundError as exc:      # 队友还没交付 ccl/compile.py
        if "compile" in str(exc):
            raise CCLNetlistError(
                "网表编译器 ccl/compile.py 尚未就绪，无法生成网表；"
                "可以先用 runner.simulate(circuit, netlist) 直接跑手写网表"
            ) from None
        raise


def _infer_kind(netlist: str) -> str:
    """从网表里认出分析类型（多张卡时以最后一张为准，和 ngspice 行为一致）。"""
    kinds = [m.group(1).lower() for m in _RE_ANALYSIS.finditer(netlist)]
    if not kinds:
        raise CCLNetlistError(
            "网表里没有分析卡（.ac / .op / .tran / .dc）；"
            "没有分析卡 ngspice 不会算任何东西，只会回一条伪向量"
        )
    last = kinds[-1]
    if last in ("op", "ac", "dc"):
        return last
    return "tran"


# --------------------------------------------------------------------------
# 公共入口
# --------------------------------------------------------------------------
def simulate(circuit, netlist: str, **kw) -> Solution:
    """跑一份已经拼好的网表，返回 `Solution`。

    参数
        circuit   源电路（用于 .op 的节点补偿与报告反查；可传 None）
        netlist   完整网表（含分析卡与 `.end`）
        **kw      透传给 `copilot.sim.run`（如 `timeout_s=120`），
                  另可传 `kind="ac"|"op"|"tran"` 覆盖自动识别

    失败时抛 `CCLConvergenceError`，`.netlist` 与 `.output` 里保留现场。
    """
    from copilot import sim

    kind = kw.pop("kind", None) or _infer_kind(netlist)
    t0 = time.perf_counter()
    try:
        result = sim.run(netlist, **kw)
    except sim.SimError as exc:
        detail = str(exc)
        if detail.startswith("仿真失败："):      # 避免「仿真失败：仿真失败：」
            detail = detail[len("仿真失败："):]
        where = f"电路 {circuit.name!r} " if circuit is not None else ""
        raise CCLConvergenceError(
            f"{where}仿真失败：{detail}\n"
            f"网表（含分析卡）在 .netlist，ngspice 原始输出在 .output，自纠时直接用这两个字段",
            netlist=getattr(exc, "netlist", netlist) or netlist,
            output=getattr(exc, "raw_output", "") or "",
        ) from exc
    elapsed = (time.perf_counter() - t0) * 1000.0
    return Solution.from_sim(result, kind, elapsed_ms=elapsed, circuit=circuit)


def ac_sweep(circuit, f_start, f_stop, points: int = 200, *, check: bool = True) -> Solution:
    """交流小信号扫频：`.ac dec {points} {f_start} {f_stop}`。

    参数
        f_start / f_stop  起止频率，Hz，必须 0 < f_start < f_stop
        points            每十倍频的点数（dec）。200 点是精度与速度的平衡点；
                          对含运放的电路 60 点就够（指标都在 Python 侧插值）
        check             是否先做结构自检（悬空节点、无地等）

    注意
        源必须有 AC 幅度（`V(..., ac=1)`），否则所有波形恒为 0。
    """
    f_start = _positive(f_start, "f_start")
    f_stop = _positive(f_stop, "f_stop")
    if f_stop <= f_start:
        raise CCLConfigError(f"f_stop 必须大于 f_start，收到 {f_start!r} → {f_stop!r}")
    try:
        points = int(points)
    except (TypeError, ValueError):
        raise CCLConfigError(f"points 必须是整数，收到 {points!r}") from None
    if points <= 0:
        raise CCLConfigError(f"points 必须 > 0，收到 {points!r}")

    _prepare(circuit, check)
    card = f".ac dec {points} {_fmt(f_start)} {_fmt(f_stop)}"
    netlist = _compile(circuit, card)
    sol = simulate(circuit, netlist, kind="ac")
    _remember_simulation(circuit, "ac", (f_start, f_stop, points), sol)
    return sol


def operating_point(circuit, *, check: bool = True) -> Solution:
    """直流工作点：`.op`。

    注意 ngspice 的 `.op` 结果**没有横轴**（只有一个点），`Solution.x` 因此填
    `[0.0]`；各节点值用 `sol.value_at("out", 0)` 或 `sol.db("out")` 读。
    """
    _prepare(circuit, check)
    netlist = _compile(circuit, ".op")
    sol = simulate(circuit, netlist, kind="op")
    _remember_simulation(circuit, "op", (), sol)
    return sol


def transient(circuit, t_step, t_stop, *, check: bool = True) -> Solution:
    """瞬态分析：`.tran {t_step} {t_stop}`。

    参数
        t_step  建议的最大步长，秒（ngspice 会按需要内部细分）
        t_stop  仿真到多久，秒，必须 > t_step

    注意
        起步阶段 ngspice 会插入极小的内部步长，所以 x 轴上第一个非零点可能远
        小于 t_step，这是正常的（不是 bug）。
    """
    t_step = _positive(t_step, "t_step")
    t_stop = _positive(t_stop, "t_stop")
    if t_stop <= t_step:
        raise CCLConfigError(f"t_stop 必须大于 t_step，收到 {t_step!r} → {t_stop!r}")

    _prepare(circuit, check)
    card = f".tran {_fmt(t_step)} {_fmt(t_stop)}"
    netlist = _compile(circuit, card)
    sol = simulate(circuit, netlist, kind="tran")
    _remember_simulation(circuit, "tran", (t_step, t_stop), sol)
    return sol


def dc_sweep(circuit, source: str, start: float, stop: float, step: float,
             *, second=None, check: bool = True) -> Solution:
    """直流扫描：`.dc <源位号> <start> <stop> <step>`，可选第二维。

        c.dc("V1", 0, 10, 1)                                  # 传输特性 Vout–Vin
        c.dc("V1", 0, 5, 1, second=("I1", 0, 1e-3, 0.5e-3))   # 输出特性曲线族

    参数
        source  被扫**器件位号**（如 "V1"），必须是独立电压源/电流源（kind V/I）
        start   起点（可以是负数）
        stop    终点，必须 ≠ start
        step    步长，必须 ≠ 0；`stop<start` 时 step 应为负
        second  可选第二维 `(位号, start, stop, step)`。**第一个源是内层循环**，
                所以每条曲线沿第一个源的扫描轴展开，曲线族按第二维分开
        check   是否先做结构自检

    返回
        `Solution`（`kind="dc"`）：`x` / `sweep_values` 是扫描值，`sweep_var`
        是被扫位号；有第二维时 `second_var` / `second_values` 给出曲线族参数，
        用 `sol.dc_curves("out")` 拿切好段的曲线——**别直接按点号连线**，
        两维的结果是分段锯齿（见 `Solution.dc_curves` 的说明）。

    保护
        单维 > 5000 点、第二维 > 500 段、两维总点数 > 100000 时自动放大步长 /
        减少段数，并在 `Solution.warnings` 里写明改了什么——不静默截断数据。
    """
    warnings: list[str] = []

    src = _source_of(circuit, source)
    start = _finite(start, "start")
    stop = _finite(stop, "stop")
    step = _finite(step, "step")
    if stop == start:
        raise CCLConfigError(f"start 与 stop 不能相同（都是 {start!r}），扫不出曲线")
    if step == 0:
        raise CCLConfigError("step 不能为 0")
    if (stop - start) * step < 0:
        raise CCLConfigError(
            f"step 方向与扫描区间不一致：{start!r} → {stop!r} 需要"
            f"{'正' if stop > start else '负'}步长，收到 {step!r}"
        )

    # spans 里每一项是 (标签, start, stop, step)；第二项（若有）就是曲线族那一维
    spans: list[tuple] = [("主扫描", start, stop, step)]
    srcs = [src]
    if second is not None:
        if not isinstance(second, (tuple, list)) or len(second) != 4:
            raise CCLConfigError(
                f"second 必须是 4 元组 (位号, start, stop, step)，收到 {second!r}"
            )
        src2 = _source_of(circuit, second[0], "第二维被扫器件")
        if srcs[0].ref.lower() == src2.ref.lower():
            raise CCLConfigError(
                f"两维扫描的两个源不能是同一个（都是 {src2.ref}），那等于把同一个量扫两遍"
            )
        s2 = _finite(second[1], "second start")
        e2 = _finite(second[2], "second stop")
        t2 = _finite(second[3], "second step")
        if e2 == s2:
            raise CCLConfigError(f"第二维 start 与 stop 不能相同（都是 {s2!r}）")
        if t2 == 0:
            raise CCLConfigError("第二维 step 不能为 0")
        if (e2 - s2) * t2 < 0:
            raise CCLConfigError(
                f"第二维 step 方向与区间不一致：{s2!r} → {e2!r}，收到 {t2!r}"
            )
        spans.append(("第二维", s2, e2, t2))
        srcs.append(src2)

    # ---- 点数保护（不静默截断：改了什么全写进 warnings）----
    limits = (_DC_MAX_POINTS, _DC_MAX_CURVES)
    for idx, (label, a, b, h) in enumerate(spans):
        n = len(_sweep_values(a, b, h))
        if n <= limits[idx]:
            continue
        new_h = (b - a) / (limits[idx] - 1)
        warnings.append(
            f"{label}点数 {n} 超过上限 {limits[idx]}，已把步长从 {h:g} "
            f"放大到 {new_h:g}（共 {limits[idx]} 点）"
        )
        spans[idx] = (label, a, b, new_h)
        if idx == 0:
            start, step = a, new_h
    if len(spans) == 2:
        n1 = len(_sweep_values(*spans[0][1:]))
        n2 = len(_sweep_values(*spans[1][1:]))
        if n1 * n2 > _DC_MAX_TOTAL and n2 > 2:
            keep = max(2, _DC_MAX_TOTAL // max(1, n1))
            a, b = spans[1][1], spans[1][2]
            new_h = (b - a) / (keep - 1)
            warnings.append(
                f"两维共 {n1 * n2} 点超过上限 {_DC_MAX_TOTAL}，已把第二维从 {n2} 段"
                f"减到 {keep} 段（步长 {new_h:g}）"
            )
            spans[1] = (spans[1][0], a, b, new_h)

    # ---- 分析卡：.dc src1 s1 e1 st1 [src2 s2 e2 st2] ----
    card = f".dc {_spice_ref(srcs[0])} {_fmt(start)} {_fmt(stop)} {_fmt(step)}"
    if len(spans) == 2:
        a, b, h = spans[1][1:]
        card += f" {_spice_ref(srcs[1])} {_fmt(a)} {_fmt(b)} {_fmt(h)}"

    _prepare(circuit, check)
    netlist = _compile(circuit, card)
    sol = simulate(circuit, netlist, kind="dc")

    # ---- 标注扫描轴 ----
    sol.sweep_var = src.ref
    sol.sweep_unit = _source_unit(srcs[0])
    expect_main = len(_sweep_values(*spans[0][1:]))
    if len(spans) == 2:
        sol.second_var = srcs[1].ref
        sol.second_unit = _source_unit(srcs[1])
        sol.second_values = _sweep_values(*spans[1][1:])
    if warnings:
        sol.warnings.extend(warnings)

    # ---- 点数自检：rawfile 点数对不上「内层 × 外层」就一定有地方不对 ----
    total = len(sol.x)
    if len(spans) == 2:
        n_seg = len(sol.second_values)
        if total != expect_main * n_seg:
            sol.warnings.append(
                f"两维直流扫描点数与预期不符：期望 {expect_main}×{n_seg}="
                f"{expect_main * n_seg} 点，实际 {total} 点；曲线族已按实测切段"
            )
    elif total and total != expect_main:
        sol.warnings.append(
            f"直流扫描点数与预期不符：期望 {expect_main} 点，实际 {total} 点"
        )
    _remember_simulation(
        circuit, "dc",
        (str(src.ref).lower(), start, stop, step,
         None if len(spans) < 2 else (str(srcs[1].ref).lower(),) + tuple(spans[1][1:])),
        sol,
    )
    return sol

