"""`Circuit` → SPICE 网表。

这是 CCL 唯一的「编译」出口：Python 侧的电路描述在这里变成一份**可以单独
喂给 ngspice 的网表**（不依赖 runner、不依赖 .control）。

## 输出结构（顺序固定）

    * 标题行                       ← 必须以 '*' 开头；SPICE 第一行永远是标题
    器件行 ...                     ← 每台器件一行：位号 节点… value_tokens… [参数]
    .model / .subckt / .param ...  ← circuit.directives + 器件自带 directives()
    <analysis>                     ← 调用方给的完整分析卡，如 ".ac dec 200 1 1meg"
    .end

## 两个刻意的决定

**1. 不注入 `.control`。**
`copilot.sim.run()` 会在检测到网表里没有 `.control` 时自己注入
（`set filetype=ascii` / `run` / `write c.raw all`）。如果编译期也注入一份，
sim 就不再注入自己的，波形落盘路径/文件类型可能对不上，运行器读不到 rawfile。
所以这里绝不出现 `.control`——但这不妨碍本函数产出的网表被 ngspice 直接
`ngspice -b x.cir` 跑通（batch 模式下只要有分析卡即可）。

**2. 位号（ref）在写进网表前会被「SPICE 化」。**
见下面 `netlist_ref()` 的实测说明——`U1.R1` 这种内联位号 ngspice 是不认的，
**但不是因为点号**，而是因为首字母。

## 写网表的位号，一律先过 `netlist_ref(comp)`

> ⚠️ **任何要写进网表的位号都必须经过 :func:`netlist_ref`，不许直接用 `comp.ref` 拼。**

原因是 ngspice 按**行首字符**判断器件类型：内联子电路产生的 `U1.R1` 首字母是 U，
会被当成「U 型器件」而拒收（`U1_R1` 一样拒收，换下划线无效），必须补成 `R.U1.R1`。
报告、BOM、交叉引用等**在网表语境下提到位号**的地方，同样要用这个函数，
否则用户看到的位号和网表里的不一致，逐条对照时会白花时间。
`circuit.components` 里的 `comp.ref` 仍然是原始位号——它是电路描述层的东西，
不要拿它去和 ngspice 的输出对照。

**3. `.control` 一律拒收（D1）。**
`copilot.sim.run()` 靠「网表里有没有 `.control`」决定要不要注入自己的控制块。
手写一个 `.control` 会让 `write c.raw all` 不再被注入 → rawfile 不落盘 →
runner 拿到空波形 → 用户在离现场几十行远的地方看到「仿真未产生有效波形」。
所以编译期直接报错，把事故消灭在源头。
"""

from __future__ import annotations

import re

from .core import GND, Circuit, Component
from .errors import CCLConfigError, CCLNetlistError, CCLError, NodeError, RefError
from .format import fmt_value

# ----------------------------------------------------------------------
# 报错类型：既是我们自己的 CCLNetlistError，又保留 core 的原始语义
# ----------------------------------------------------------------------
# 编译前要调 circuit.validate()，而 validate() 抛的是 NodeError / RefError。
# CONTRACT 又要求编译失败统一抛 CCLNetlistError。为了不让调用方在两个异常类
# 之间猜来猜去，这两个子类同时继承两边：`except CCLNetlistError` 和
# `except NodeError` 都能捕获到同一个异常，并且带上了 ref / node 字段。


class NetlistNodeError(CCLNetlistError, NodeError):
    """编译期的节点类错误（悬空节点、没有地）。同时是 NodeError。"""


class NetlistRefError(CCLNetlistError, RefError):
    """编译期的位号类错误。同时是 RefError。"""


# ----------------------------------------------------------------------
# 位号 / 节点名的 SPICE 化
# ----------------------------------------------------------------------

# ngspice 实测（ngspice-47，见 tests_ccl/test_compile.py 的位号 SPICE 化用例）：
#
#   U1.R1      → Error on line 3: "Unable to find definition of model …"
#   U1_R1      → 同样的错（换成下划线**没用**）
#   U1R1       → 同样的错
#   R1.2       → ✓ 正常
#   R.U1.1     → ✓ 正常
#   RU1_1      → ✓ 正常
#
# 结论：ngspice 靠**行首字符**决定器件类型（R/C/L/V/I/X/D/Q/M…）。
# 子电路内联产生的 `U1.R1` 首字母是 U，ngspice 把它当成「U 型器件（均匀
# 分布 RC 线）」去读，于是把 "1k" 当成模型名去找 → 报 unknown model。
# **点号本身完全合法**（`R1.2`、`R.U1.1` 都通过了），换成下划线治不了病。
#
# 因此这里做两件事：
#   a) 把非法字符换成 '_'（空格、括号、逗号、'=' 之类）；
#   b) 如果首字母不是该器件的类型字母，就在前面补上「类型字母 + '.'」，
#      即 `U1.R1`（kind="R"）→ `R.U1.R1`。这与 ngspice 自己对子电路展平后
#      的内部命名（`r.x1.r1`）完全一致，实测可解析。
_ILLEGAL_REF_CHARS = re.compile(r"[^A-Za-z0-9_.\-]")


def _sanitize_token(s: str) -> str:
    s = _ILLEGAL_REF_CHARS.sub("_", s)
    return s or "_"


def netlist_ref(comp: Component) -> str:
    """把位号变成 ngspice 认得的形式（保证首字母是器件类型字母）。

    大多数位号（`R1`、`C3`、`X1`）原样返回；只有子电路内联产生的
    `U1.R1` 这类才会被改写成 `R.U1.R1`。
    """
    ref = _sanitize_token(comp.ref or "")
    kind = (comp.kind or "").strip().lstrip("?")
    if not kind:
        return ref
    # 允许 kind 是多字母（如 "SW"、"VCVS"）——取首字母即可
    want = kind[0].upper()
    if not ref[:1].upper() == want:
        ref = f"{kind[0]}.{ref}"
    return ref


# ----------------------------------------------------------------------
# 校验包装
# ----------------------------------------------------------------------
def _locate_first_problem(circuit: Circuit) -> tuple[str | None, str | None]:
    """在 validate() 失败后定位「第一个出问题的 (位号, 节点)」，用于报错前缀。"""
    netmap = circuit.nets() if circuit.components else {}
    if netmap and GND not in netmap:
        return None, GND
    for node, pins in netmap.items():
        if node != GND and len(pins) < 2:
            ref, _pin = pins[0]
            return ref, node
    # 位号重复 / 首字母不符之类没有节点的错误
    seen: dict[str, str] = {}
    for c in circuit.components:
        key = c.ref
        if key in seen:
            return c.ref, None
        seen[key] = c.ref
    return None, None


def _validate(circuit: Circuit) -> list[str]:
    """调 circuit.validate()，把它的错误统一成 CCLNetlistError（带 ref/node）。"""
    if not isinstance(circuit, Circuit):
        raise CCLNetlistError(
            f"compile_circuit() 需要 Circuit，收到 {type(circuit).__name__}"
        )
    try:
        return circuit.validate()
    except NodeError as exc:
        ref, node = _locate_first_problem(circuit)
        raise NetlistNodeError(str(exc), ref=ref, node=node) from exc
    except RefError as exc:
        ref, _ = _locate_first_problem(circuit)
        raise NetlistRefError(str(exc), ref=ref) from exc
    except CCLNetlistError:
        raise
    except CCLError as exc:
        raise CCLNetlistError(str(exc)) from exc


# ----------------------------------------------------------------------
# 子电路实例的端口数自检
# ----------------------------------------------------------------------
_RE_SUBCKT = re.compile(r"^\s*\.subckt\s+(\S+)(.*)$", re.I)


def _subckt_ports(directives: list[str]) -> dict[str, int]:
    """从 directives 里收集 `{子电路名: 端口数}`（用于 X 实例行自检）。

    支持 `.subckt name a b c` 与续行 `+ c d`；带 `=` 的 token 视为参数不计入端口。
    """
    ports: dict[str, int] = {}
    logical: list[str] = []
    for raw in directives:
        for line in raw.splitlines():
            if line.lstrip().startswith("+") and logical:
                logical[-1] += " " + line.lstrip()[1:].strip()
            else:
                logical.append(line.strip())
    for line in logical:
        m = _RE_SUBCKT.match(line)
        if not m:
            continue
        name = m.group(1)
        tokens = [t for t in m.group(2).split() if "=" not in t]
        # `params:` 之后一律是参数
        if "params:" in [t.lower() for t in tokens]:
            tokens = tokens[: [t.lower() for t in tokens].index("params:")]
        ports[name] = len(tokens)
    return ports


# ----------------------------------------------------------------------
# 单器件行
# ----------------------------------------------------------------------
def _value_tokens(comp: Component) -> list[str]:
    """取器件的值/模型字段，失败时带位号报错。"""
    try:
        tokens = comp.value_tokens()
    except CCLNetlistError:
        raise
    except CCLError as exc:
        raise CCLNetlistError(f"无法生成器件的值字段：{exc}", ref=comp.ref) from exc
    except Exception as exc:  # 器件实现里的意外错误也带上位号，别让它裸奔
        raise CCLNetlistError(
            f"器件 value_tokens() 出错（{type(exc).__name__}: {exc}）", ref=comp.ref
        ) from exc

    out: list[str] = []
    for t in tokens or []:
        if not isinstance(t, str):
            try:
                t = fmt_value(t)
            except CCLConfigError as exc:
                raise CCLNetlistError(f"值字段非法：{exc}", ref=comp.ref) from exc
        t = t.strip()
        if not t:
            continue
        if any(ch.isspace() for ch in t):
            raise CCLNetlistError(
                f"值字段 {t!r} 内部含空白，会把网表行拆错列；"
                f"请让 value_tokens() 返回『按空格分隔的 token 列表』",
                ref=comp.ref,
            )
        out.append(t)
    if not out:
        raise CCLNetlistError(
            "没有可写进网表的数值/模型字段（value_tokens() 返回空）。"
            "SPICE 里每个器件行都必须有值或模型名",
            ref=comp.ref,
        )
    return out


def _param_tokens(comp: Component, value_tokens: list[str]) -> list[str]:
    """把 `Component.params` 拼成 `key=value` 追加到行尾。

    约定：**params 由 compile 输出**，器件自己的 `value_tokens()` 不要重复
    输出同名参数（这里会做一次去重，重复的键不会再写第二遍）。
    """
    if not comp.params:
        return []
    joined = " " + " ".join(value_tokens) + " "
    out: list[str] = []
    for key, val in comp.params.items():
        key = str(key).strip()
        if not key or any(ch.isspace() for ch in key):
            raise CCLNetlistError(f"参数名 {key!r} 含空白或为空", ref=comp.ref)
        if f" {key}=" in joined or joined.lstrip().startswith(f"{key}="):
            continue  # 器件已经自己写过了
        try:
            text = fmt_value(val)
        except CCLConfigError as exc:
            raise CCLNetlistError(f"参数 {key} 的值非法：{exc}", ref=comp.ref) from exc
        out.append(f"{key}={text}")
    return out


def _device_line(comp: Component, ports: dict[str, int]) -> str:
    ref = netlist_ref(comp)
    nodes = comp.nodes()
    if not nodes:
        raise CCLNetlistError("器件没有任何引脚/节点", ref=comp.ref)
    for n in nodes:
        if any(ch.isspace() for ch in n):
            raise CCLNetlistError(f"节点名 {n!r} 含空白，无法写入网表", ref=comp.ref)

    toks = _value_tokens(comp)

    # X 实例（子电路调用）自检：端口数必须与 .subckt 声明一致
    if comp.kind[:1].upper() == "X":
        sub = toks[0]
        if sub in ports and ports[sub] != len(nodes):
            raise CCLNetlistError(
                f"子电路 {sub} 声明了 {ports[sub]} 个端口，"
                f"但这一行给了 {len(nodes)} 个节点（{' '.join(nodes)}）",
                ref=comp.ref,
            )

    parts = [ref, *nodes, *toks, *_param_tokens(comp, toks)]
    return " ".join(parts)


# ----------------------------------------------------------------------
# 标题 / 分析卡
# ----------------------------------------------------------------------
def _title_line(circuit: Circuit, title: str | None) -> str:
    text = circuit.name if title is None else title
    text = " ".join(str(text).split())  # 压掉换行与多余空白
    if not text:
        text = circuit.name or "circuit"
    if not text.startswith("*"):
        text = f"* {text}"
    return text


def _analysis_line(analysis: str | None) -> str | None:
    if analysis is None:
        return None
    text = str(analysis).strip()
    if not text:
        return None
    if not text.startswith("."):
        raise CCLNetlistError(
            f"分析卡 {text!r} 必须以 '.' 开头，例如 \".ac dec 200 1 1meg\" 或 \".op\""
        )
    if ".end" in text.lower().split():
        raise CCLNetlistError(f"分析卡里不能包含 .end：{text!r}")
    _reject_control(text)
    return text


_CONTROL_HINT = (
    "不要手写 .control —— copilot.sim 靠「网表里有没有 .control」决定要不要注入自己的"
    "控制块（set filetype=ascii / run / write c.raw all），手写一份会让波形根本落不了盘，"
    "最终表现成离现场几十行远的『仿真未产生有效波形』。"
    "请用 c.ac() / c.op() / c.tran()，分析卡由 runner 生成"
)


def _reject_control(text: str) -> None:
    """D1：出现 `.control` 一律拒收（见模块 docstring 第 3 条）。"""
    for line in str(text).splitlines():
        low = line.strip().lower()
        if low.startswith(".control") or low == ".endc":
            raise CCLNetlistError(
                f"指令里出现了控制块：{line.strip()!r}。{_CONTROL_HINT}"
            )


def _directives(circuit: Circuit) -> list[str]:
    """收集 circuit.directives + 各器件自带的 directives()，去重并保持顺序。"""
    seen: list[str] = []
    for d in circuit.directives:
        if not isinstance(d, str):
            raise CCLNetlistError(f"指令必须是字符串，收到 {type(d).__name__}")
        _reject_control(d)
        if d.strip() and d.strip() not in seen:
            seen.append(d.strip())
    for comp in circuit.components:
        hook = getattr(comp, "directives", None)
        if hook is None or not callable(hook):
            continue
        try:
            extra = hook() or []
        except Exception as exc:
            raise CCLNetlistError(
                f"器件 {comp.ref} 的 directives() 出错（{type(exc).__name__}: {exc}）",
                ref=comp.ref,
            ) from exc
        for d in extra:
            if not isinstance(d, str):
                continue
            _reject_control(d)
            if d.strip() and d.strip() not in seen:
                seen.append(d.strip())
    return seen


# ----------------------------------------------------------------------
# 主入口
# ----------------------------------------------------------------------
def compile_circuit(circuit: Circuit, analysis: str | None = None,
                    title: str | None = None) -> str:
    """把 `Circuit` 编译成 SPICE 网表字符串。

    参数
    ----
    circuit : Circuit
        要编译的电路；编译前会调 `circuit.validate()`。
    analysis : str | None
        完整分析卡，如 `".ac dec 200 1 1meg"`、`".op"`、`".tran 1u 5m"`。
        `None` 时不输出分析卡（留给调用方自己拼，或做非 `.op` 的自定义场景）。
    title : str | None
        SPICE 第一行（标题）。`None` 时用 `circuit.name`。会自动补 `* `。

    返回
    ----
    str
        以 `\\n` 结尾的网表，最后一行是 `.end`。

    异常
    ----
    CCLNetlistError
        编译失败。带 `ref` / `node` 字段，消息里指明具体位号。
        （节点类错误同时是 `NodeError`，位号类错误同时是 `RefError`。）

    例
    --
    >>> from ccl.core import Circuit, GND
    >>> c = Circuit("rc_lp")
    >>> c.R("in", "out", 1.6e3); c.C("out", GND, 100e-9); c.V("in", GND, ac=1)
    >>> print(compile_circuit(c, ".ac dec 200 1 100k"))
    * rc_lp
    ...（器件行）
    .ac dec 200 1 100k
    .end
    """
    _validate(circuit)                     # 1) 结构自检（失败抛 CCLNetlistError）
    directives = _directives(circuit)      # 2) 指令（可能来自器件宏模型）

    ports = _subckt_ports(directives)
    lines: list[str] = [_title_line(circuit, title)]

    # 3) 器件行 + 位号唯一性自检（改写后的网表位号也必须唯一）
    seen_refs: dict[str, str] = {}
    for comp in circuit.components:
        line = _device_line(comp, ports)
        nref = line.split(" ", 1)[0]
        if nref.lower() in seen_refs:
            raise NetlistRefError(
                f"网表位号 {nref} 重复（来自 {seen_refs[nref.lower()]!r} 与 "
                f"{comp.ref!r}）；同一份网表里位号必须唯一",
                ref=comp.ref,
            )
        seen_refs[nref.lower()] = comp.ref
        lines.append(line)

    # 4) directives
    lines.extend(directives)

    # 5) 分析卡
    analysis_line = _analysis_line(analysis)
    if analysis_line:
        lines.append(analysis_line)

    # 6) 结束
    lines.append(".end")
    return "\n".join(lines) + "\n"


__all__ = ["compile_circuit", "netlist_ref", "NetlistNodeError", "NetlistRefError"]
