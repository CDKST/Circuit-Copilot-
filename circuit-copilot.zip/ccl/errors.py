"""CCL 异常。

原则：报错必须**指向具体的元件位号和节点名**。
电路描述库最常见的挫败感来自「网表第 12 行有语法错误」这种没用的话——
用户面对的是 Python 代码，报错就该说「R3 的 b 端连着节点 'n2'，这个节点没有其他连接（悬空）」。
"""

from __future__ import annotations


class CCLWarning(UserWarning):
    """警告：电路能建出来，但有很高概率不是用户想要的东西。"""


class CCLError(Exception):
    """所有 CCL 错误的基类。"""


class RefError(CCLError):
    """位号问题：重复位号、位号与器件类型不匹配。"""


class NodeError(CCLError):
    """节点问题：节点不存在、悬空节点、非法节点名。"""


class CCLConfigError(CCLError):
    """器件配置问题：缺引脚、参数越界、单位无法解析、模型缺失。"""


class CCLNetlistError(CCLError):
    """编译失败：无法生成合法网表。带上下文，便于定位到具体器件。"""

    def __init__(self, message: str, *, ref: str | None = None, node: str | None = None):
        self.ref = ref
        self.node = node
        where = []
        if ref:
            where.append(f"器件 {ref}")
        if node:
            where.append(f"节点 {node!r}")
        prefix = f"[{' / '.join(where)}] " if where else ""
        super().__init__(prefix + message)


class CCLAssertionError(CCLError):
    """声明的规格没通过。消息里带每一项的目标 vs 实测。"""


class CCLConvergenceError(CCLError):
    """仿真不收敛或未产生有效结果。保留原始网表与仿真器输出，供自纠。"""

    def __init__(self, message: str, *, netlist: str = "", output: str = ""):
        self.netlist = netlist
        self.output = output
        super().__init__(message)
