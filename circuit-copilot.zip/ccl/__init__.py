"""CCL（Circuit Code Library）· 以代码为核心的电路描述库。

设计前提：**代码是唯一真相**。没有图形编辑器，没有插图识别。
电路用 Python 写成，可组合、可参数化、可版本控制、可内嵌断言。

三层结构：
    core.py      Component / Pin / Circuit —— 电路的数据模型（不含仿真知识）
    compile.py   Circuit → SPICE 网表（唯一的"编译"出口）
    devices.py   器件库（R/C/L/电源/运放/二极管…），声明端子顺序与模型

仿真由 ccl.runner 复用已验证的 copilot.sim（ngspice 封装），
指标计算见 ccl.solution。

AI 生成是**独立可选功能**（ccl.ai），核心库不依赖任何大模型：
没有 API Key 时，手写代码这条路完全不受影响。
"""

from __future__ import annotations

__version__ = "0.1.0"

from .core import Circuit, Component, Pin, GND  # noqa: E402,F401
from .solution import Solution  # noqa: E402,F401
from .errors import (  # noqa: E402,F401
    CCLConfigError,
    CCLConvergenceError,
    CCLNetlistError,
    CCLError,
    NodeError,
    RefError,
)

__all__ = [
    "Circuit",
    "Solution",
    "Component",
    "Pin",
    "GND",
    "CCLError",
    "CCLConfigError",
    "CCLConvergenceError",
    "CCLNetlistError",
    "NodeError",
    "RefError",
]
