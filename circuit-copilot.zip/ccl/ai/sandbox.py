"""受限执行环境：把大模型生成的 Python 代码安全地跑起来。

## 为什么需要它

`generate()` 拿到的是一段**模型写的 Python 代码**，我们必须 exec 它才能拿到
`Circuit` 对象。直接 `exec(src)` 等于把用户的机器交给模型——模型（或被注入的
prompt）可以写 `import os; os.system("rm -rf ~")`。

## 三层防护（缺一层都不够）

1. **AST 静态检查**（`check_source`）
   在 exec 之前把整棵树走一遍，拒绝 `import os`、`open(...)`、`eval`、
   下划线属性（`().__class__.__bases__` 这类逃逸手法全靠下划线属性）。
   这一层是"看得见的拦截"，报错能指到具体行。

2. **白名单 `__builtins__`**（`_make_builtins`）
   exec 的命名空间里根本没有 `open`/`eval`/`__import__`/`type`/`getattr`，
   即使 AST 检查被绕过（比如未来加了新语法），运行时也拿不到危险函数。

3. **受限 `__import__`**（`_make_import`）
   只从**预先导入并缓存**的白名单模块返回对象，不做真正的动态导入。
   `import ccl` 能成，`import os` 直接 ImportError。

## 超时

用 `signal.setitimer` 中断超时执行（只在主线程有效，如 CLI 直连路径）。
不在主线程时降级并 stderr 留痕——那时靠 AST 层的 **while 禁令**（无限循环
在语言层面不可能）与 `range` 长度上限兜底；`for` 循环量级有界，最坏情况可控。

## 这不是安全沙箱

它挡的是**模型幻觉与 prompt 注入**，不是对抗性的本地代码执行沙箱。
Python 的进程内隔离原则上不可完全信任；真要跑不可信代码请用容器。
对本项目的威胁模型（模型自己写错代码）足够。
"""

from __future__ import annotations

import ast
import importlib
import signal
import sys
import traceback
from dataclasses import dataclass, field

# 允许导入的模块根名。math 是纯计算（模型算 π、开方时要用），无任何 IO 能力。
# 允许导入的模块根名。
#   ccl        核心库（Circuit/GND/器件）
#   ccl.blocks 可复用子电路库（M5）——纯构造，不含任何 IO 或模型调用
#   math       纯计算（算 π、开方），无 IO 能力
# 刻意**不含** ccl.ai：那会让生成出来的代码反过来调用模型。
ALLOWED_IMPORTS: frozenset[str] = frozenset({"ccl", "ccl.blocks", "math"})

# 名字层面直接拒绝（即使 builtins 里没有，也不允许模型把变量叫这个名字，
# 以免出现 `eval = something` 之后再调用这类绕过）
FORBIDDEN_NAMES: frozenset[str] = frozenset({
    "eval", "exec", "compile", "open", "input", "breakpoint",
    "__import__", "globals", "locals", "vars", "dir",
    "getattr", "setattr", "delattr", "hasattr",
    "type", "object", "memoryview", "exit", "quit", "help",
    "os", "sys", "subprocess", "socket", "shutil", "pathlib", "builtins",
})

# 白名单 builtins：只有"算数 + 建数据结构 + 打印"这些
_SAFE_BUILTINS = (
    "abs", "all", "any", "bool", "dict", "enumerate", "filter", "float",
    "frozenset", "int", "isinstance", "len", "list", "map", "max", "min",
    "pow", "reversed", "round", "set", "sorted", "str", "sum", "tuple", "zip",
    # 异常类：模型写的代码常常带 try/except，缺了它们会变成 NameError，
    # 反而把真正的错误信息掩盖掉。异常类本身没有任何 IO 能力。
    "Exception", "BaseException", "ArithmeticError", "ValueError", "TypeError",
    "ZeroDivisionError", "KeyError", "IndexError", "RuntimeError",
    "AttributeError", "StopIteration", "FloatingPointError",
)

_MAX_RANGE_LEN = 1_000_000
_MAX_PRINT_LINES = 200          # print 上限：防止模型在循环里 print 撑爆内存
_MAX_PRINT_CHARS = 20_000


class SandboxError(Exception):
    """沙箱拒绝执行，或执行过程中出错。`line` 指向生成代码的行号（1 起）。"""

    def __init__(self, message: str, *, line: int | None = None, stage: str = "exec"):
        self.line = line
        self.stage = stage          # "static" | "exec" | "extract" | "timeout"
        super().__init__(message)


# --------------------------------------------------------------------------
# 第一层：AST 静态检查
# --------------------------------------------------------------------------

class _Checker(ast.NodeVisitor):
    def __init__(self) -> None:
        self.problems: list[tuple[int, str]] = []

    def _bad(self, node: ast.AST, msg: str) -> None:
        self.problems.append((getattr(node, "lineno", 0), msg))

    def visit_Import(self, node: ast.Import) -> None:
        for a in node.names:
            root = a.name.split(".")[0]
            if root not in ALLOWED_IMPORTS:
                self._bad(node, f"禁止导入 {a.name!r}；只允许 {sorted(ALLOWED_IMPORTS)}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.level:
            self._bad(node, "禁止相对导入")
        else:
            root = (node.module or "").split(".")[0]
            if root not in ALLOWED_IMPORTS:
                self._bad(node, f"禁止从 {node.module!r} 导入；只允许 {sorted(ALLOWED_IMPORTS)}")
        self.generic_visit(node)

    def _targets(self, node) -> list:
        """赋值语句的所有叶子目标。"""
        out = []
        tgt = getattr(node, "target", None) or getattr(node, "targets", None) or []
        if not isinstance(tgt, list):
            tgt = [tgt]
        stack = list(tgt)
        while stack:
            t = stack.pop()
            if isinstance(t, (ast.Tuple, ast.List)):
                stack.extend(t.elts)
            elif t is not None:
                out.append(t)
        return out

    def _check_assign_targets(self, node) -> None:
        """⛑ 禁止 `对象.属性 = ...`。

        为什么必须拦：沙箱把**真模块对象**传进 exec，模型写一行
        `Circuit.ac = lambda self, *a, **k: None` 就能**永久**改掉进程里的类。
        此后所有请求的 `c.ac()` 都返回 None，而 None 会被当成"没报错"，
        对账拿到 `None` 就当全达标 → **整个服务此后永远报成功**。
        实测：一次生成污染后，三条完全无关的需求全部 ok=True、零告警。
        ThreadingHTTPServer 是常驻的，重启前谁用谁中招；一句 prompt 注入就够。

        生成电路代码本来不需要给属性赋值（要设置参数有 `c.R(...)` 这类 API），
        所以直接禁掉，代价远小于风险。
        """
        for t in self._targets(node):
            if isinstance(t, ast.Attribute):
                where = ast.unparse(t) if hasattr(ast, "unparse") else f".{t.attr}"
                self._bad(node, f"禁止给属性赋值（{where} = ...）：这会改动全局类/模块，"
                                f"污染同一进程里的其它请求")

    def visit_Assign(self, node: ast.Assign) -> None:
        self._check_assign_targets(node)
        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self._check_assign_targets(node)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        self._check_assign_targets(node)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        # 逃逸的经典手法全靠下划线属性：().__class__.__bases__[0].__subclasses__()
        if node.attr.startswith("_"):
            self._bad(node, f"禁止访问下划线属性 .{node.attr}")
        self.generic_visit(node)

    def visit_While(self, node: ast.While) -> None:
        # while 一律禁止：signal 超时只在主线程有效（ThreadingHTTPServer 的
        # 每个请求都在子线程里跑 exec），`while True: pass` 在 Web 路径会
        # 永久占死一个线程。禁掉后「无限循环」在语言层面不可能——for 的
        # 可迭代对象全部来自白名单（range 有上限，容器都有限）。
        # 构建电路本来就用 for（扫参数、批量建器件），few-shot 无一用 while。
        self._bad(node, "禁止 while 循环（防死循环占死服务线程）；批量构造请用 for + range/list")

    def visit_Name(self, node: ast.Name) -> None:
        if node.id in FORBIDDEN_NAMES:
            self._bad(node, f"禁止使用名字 {node.id!r}")
        elif node.id.startswith("__"):
            self._bad(node, f"禁止使用双下划线名字 {node.id!r}")
        self.generic_visit(node)


def check_source(source: str) -> list[tuple[int | None, str]]:
    """静态检查生成代码，返回 [(行号, 问题)]（空列表 = 通过）。

    行号单独返回，是为了让 generate 能把**行号 + 原文那一行**一起回喂模型；
    如果压成字符串，调用方还得再解析一次。
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        text = (e.text or "").strip()
        return [(e.lineno, f"语法错误：{e.msg}" + (f"（`{text}`）" if text else ""))]
    checker = _Checker()
    checker.visit(tree)
    return checker.problems


# --------------------------------------------------------------------------
# 第二层 + 第三层：受限 builtins 与预注入模块白名单
# --------------------------------------------------------------------------

def _preload_modules() -> dict[str, object]:
    """预先导入白名单模块并缓存。exec 期间**不做真正的动态导入**。"""
    cache: dict[str, object] = {}
    for name in sorted(ALLOWED_IMPORTS):
        try:
            cache[name] = importlib.import_module(name)
        except Exception:
            # ccl 的某些子模块可能还没写好，这不影响 import ccl.ai 本身
            pass
    return cache


def _make_import(cache: dict[str, object]):
    def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):  # noqa: A002
        if level:
            raise ImportError("沙箱禁止相对导入")
        root = str(name).split(".")[0]
        if root not in ALLOWED_IMPORTS:
            raise ImportError(
                f"沙箱禁止导入模块 {name!r}；只允许 {sorted(ALLOWED_IMPORTS)}"
            )
        mod = cache.get(name)
        if mod is None:
            raise ImportError(f"沙箱白名单里没有模块 {name!r}")
        return mod

    return _safe_import


def _make_builtins(sink: list[str], import_hook) -> dict:
    def _print(*args, sep=" ", end="\n", **kw):  # noqa: A002
        # 上限保护：模型若在循环里 print，截断而不是 OOM
        if len(sink) >= _MAX_PRINT_LINES or sum(map(len, sink)) >= _MAX_PRINT_CHARS:
            if len(sink) == _MAX_PRINT_LINES:
                sink.append("…（print 输出过多，已截断）")
            return
        sink.append(sep.join(str(a) for a in args))

    def _safe_range(*args):
        r = range(*args)
        if len(r) > _MAX_RANGE_LEN:
            raise ValueError(f"range 长度 {len(r)} 超过沙箱上限 {_MAX_RANGE_LEN}")
        return r

    src = __builtins__ if isinstance(__builtins__, dict) else vars(__builtins__)
    safe = {name: src[name] for name in _SAFE_BUILTINS if name in src}
    safe.update({
        "print": _print,
        "range": _safe_range,
        # ★ import 语句走 IMPORT_NAME 字节码，它**只从 builtins 里取 __import__**。
        #   放进 exec 的 globals 里是无效的（踩过一次）。必须放这里。
        "__import__": import_hook,
        "True": True, "False": False, "None": None,
    })
    return safe


# --------------------------------------------------------------------------
# 超时
# --------------------------------------------------------------------------

class _Timeout(Exception):
    pass


class _deadline:
    """在主线程里给 exec 加一个墙钟超时；其他线程静默降级。"""

    def __init__(self, seconds: float):
        self.seconds = float(seconds)
        self._armed = False
        self._old_handler = None

    def __enter__(self):
        if self.seconds <= 0 or not hasattr(signal, "setitimer"):
            return self
        try:
            self._old_handler = signal.signal(signal.SIGALRM, self._handler)
            signal.setitimer(signal.ITIMER_REAL, self.seconds)
            self._armed = True
        except (ValueError, OSError):
            # 不在主线程 → 无法用 signal，降级为「只靠 range 上限 + while 禁令」。
            # 留痕不静默：超时保护失效这件事必须能在日志里看到。
            self._armed = False
            import sys
            print("[sandbox] 当前线程无法用 signal 超时（非主线程），"
                  "依赖 AST 静态限制兜底", file=sys.stderr)
        return self

    def _handler(self, signum, frame):
        raise _Timeout(f"执行超时（>{self.seconds:.0f}s），代码可能有死循环")

    def __exit__(self, *exc):
        if self._armed:
            try:
                signal.setitimer(signal.ITIMER_REAL, 0)
                signal.signal(signal.SIGALRM, self._old_handler)
            except (ValueError, OSError):
                pass
        return False


# --------------------------------------------------------------------------
# 对外入口
# --------------------------------------------------------------------------

@dataclass
class SandboxResult:
    ok: bool
    namespace: dict = field(default_factory=dict)
    circuit: object = None          # 提取到的 Circuit
    error: str | None = None
    line: int | None = None
    stage: str = ""                 # "static" | "exec" | "timeout" | "extract"
    stdout: str = ""

    def trace(self) -> str:
        """给模型的错误描述：带行号，便于它精确修正。"""
        if self.ok:
            return ""
        loc = f"第 {self.line} 行" if self.line else "（无法定位行号）"
        return f"[{self.stage}] {loc}: {self.error}"


def _find_circuit(ns: dict) -> object | None:
    """从命名空间里找 Circuit：优先调用 `build()`，否则扫已实例化的对象。"""
    from ..core import Circuit

    fn = ns.get("build")
    if callable(fn):
        out = fn()
        return out if isinstance(out, Circuit) else ("__build_bad__", out)

    # 扫实例：优先叫 c / circuit / result 的，其次任意
    for key in ("circuit", "c", "result", "ckt"):
        v = ns.get(key)
        if isinstance(v, Circuit):
            return v
    found = [v for v in ns.values() if isinstance(v, Circuit)]
    return found[-1] if found else None


#: 需要守护的「共享可变状态」：这些类是全进程唯一的，被改写会污染所有请求。
_GUARDED_CLASSES: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    ("ccl.core", "Circuit", ("ac", "tran", "op", "dc", "validate", "to_spice",
                             "add", "nodes", "components")),
)


def _snapshot_guarded() -> list[tuple[type, str, object]]:
    """记录关键类方法的当前实现（exec 前调用）。"""
    snap: list[tuple[type, str, object]] = []
    for mod_name, cls_name, attrs in _GUARDED_CLASSES:
        try:
            mod = importlib.import_module(mod_name)
            cls = getattr(mod, cls_name)
        except Exception:
            continue
        for a in attrs:
            if hasattr(cls, a):
                snap.append((cls, a, getattr(cls, a)))
    return snap


def _restore_if_polluted(snap: list[tuple[type, str, object]]) -> list[str]:
    """检查并回滚被改写的类方法。返回被改写的属性名列表（空 = 干净）。"""
    bad: list[str] = []
    for cls, name, orig in snap:
        try:
            now = getattr(cls, name)
        except Exception:
            now = None
        if now is not orig:
            bad.append(f"{cls.__name__}.{name}")
            try:
                setattr(cls, name, orig)
            except Exception:
                pass
    return bad


def run_source(
    source: str,
    *,
    timeout_s: float = 20.0,
    require_circuit: bool = True,
) -> SandboxResult:
    """在受限环境里执行代码并尝试取回 Circuit。

    分阶段返回失败原因（stage + line），让 generate 能把**具体错误**喂回模型。
    """
    if not isinstance(source, str) or not source.strip():
        return SandboxResult(ok=False, error="生成的代码为空", stage="static")

    problems = check_source(source)
    if problems:
        # 只回第一条 + 总条数：给模型太多会淹没它
        line, first = problems[0]
        more = f"（另有 {len(problems) - 1} 处）" if len(problems) > 1 else ""
        return SandboxResult(
            ok=False, stage="static", line=line,
            error=f"沙箱静态检查未通过：{first}{more}",
        )

    try:
        code = compile(source, "<ccl-ai>", "exec")
    except SyntaxError as e:
        return SandboxResult(ok=False, stage="static",
                             error=f"语法错误：{e.msg}", line=e.lineno)

    sink: list[str] = []
    import_hook = _make_import(_preload_modules())
    ns: dict = {
        "__builtins__": _make_builtins(sink, import_hook),
        "__name__": "<ccl_ai_generated>",
        "__doc__": None,
    }

    # ⛑ 运行时护栏：记录关键类方法，exec 之后校验有没有被改写。
    # AST 层已禁止属性赋值，这里是**第二道**——万一还有别的路径
    # （`setattr`、描述符、继承链……）能改到全局类，也要能发现并回滚。
    # 不这么做的后果实测过：一次污染 = 整个进程此后永远报成功。
    _guard = _snapshot_guarded()

    try:
        with _deadline(timeout_s):
            exec(code, ns)  # noqa: S102 —— 安全性由上面三层保证
            _polluted = _restore_if_polluted(_guard)
            if _polluted:
                return SandboxResult(
                    ok=False, stage="static", stdout="\n".join(sink),
                    error=("生成的代码改写了 ccl 的全局类方法（" + "、".join(_polluted) +
                           "）。这会污染同一进程里的所有后续请求，已拦截并回滚。"
                           "请只通过 c.R(...)/c.V(...) 这类 API 改电路，不要改动类本身。"),
                )
            if require_circuit:
                circuit = _find_circuit(ns)
    except _Timeout as e:
        return SandboxResult(ok=False, stage="timeout", error=str(e), stdout="\n".join(sink))
    except Exception as e:  # noqa: BLE001 —— 模型的任何错误都要回喂，必须全接住
        line = _line_of(e, source)
        return SandboxResult(
            ok=False, stage="exec", line=line,
            error=f"{type(e).__name__}: {e}", stdout="\n".join(sink),
        )

    out = "\n".join(sink)
    if not require_circuit:
        return SandboxResult(ok=True, namespace=ns, stdout=out)

    if circuit is None:
        return SandboxResult(
            ok=False, stage="extract", stdout=out,
            error=("执行成功但没有拿到 Circuit 对象。代码必须定义 `build()` 并 return 一个 "
                   "ccl.Circuit，或者在模块顶层创建一个名为 `c` 的 Circuit。"),
        )
    if isinstance(circuit, tuple) and circuit[0] == "__build_bad__":
        return SandboxResult(
            ok=False, stage="extract", stdout=out,
            error=f"build() 返回的是 {type(circuit[1]).__name__}，不是 ccl.Circuit",
        )

    return SandboxResult(ok=True, namespace=ns, circuit=circuit, stdout=out)


def _line_of(err: BaseException, source: str) -> int | None:
    """从异常回溯里挑出属于生成代码的那一帧行号。"""
    tb = err.__traceback__
    line = None
    while tb is not None:
        if tb.tb_frame.f_code.co_filename == "<ccl-ai>":
            line = tb.tb_lineno
        tb = tb.tb_next
    return line


def explain_exception(err: BaseException) -> str:
    """把异常压成一行（给 prompt 用，不要整段 traceback）。"""
    tb = traceback.extract_tb(err.__traceback__)
    frames = [f for f in tb if f.filename == "<ccl-ai>"]
    where = f"第 {frames[-1].lineno} 行" if frames else "（外部）"
    return f"{where} {type(err).__name__}: {err}"
