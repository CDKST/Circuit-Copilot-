"""AI 生成电路：自然语言 → 可执行 Python 代码 → 真跑一遍仿真 → 失败自动修复。

## 防幻觉的三道闸

模型的幻觉（编器件名、编参数、编引脚）没法靠 prompt 消除，只能靠**执行暴露**：

1. **安全 exec**（`sandbox.run_source`）：器件名写错 → `AttributeError`；
   引脚数不对 → `TypeError`；参数越界 → `CCLConfigError`。错误带行号。
2. **真跑一次仿真**：结构对了但电路不成立（无地、悬空、无直流通路、不收敛）
   在这一步暴露。这一步不可省略——只 exec 不仿真等于没验证。
3. **错误回喂**（`max_repair` 次）：把**具体错误**（行号 + 异常 + 原始消息）
   连同"正确签名对照表"一起喂回去。`attempts` 记录每一轮的代码与错误，
   所以事后能判断是"模型不行"还是"prompt 不行"。

## 为什么扫频范围要跟着电路走

固定 `1Hz~100MHz` 是错的：1Hz 低通的第一个采样点就在 −3dB 处，`f3db` 找不到交点。
所以先 `.op` 拿工作点，再按电路里的 RC/RL 时间常数**估计**一个特征频率，
用它定扫频中心。估计失败就退回宽范围扫频（宁可多算几百个点，也不能算错）。

## 没有 API Key 时

`generate()` 返回 `ok=False, error="未配置 API Key"`，**不抛异常**（调用方在 web 里
不该因为没配 Key 就崩）。但 `import ccl.ai` 永远成功——核心库不依赖这里。
"""

from __future__ import annotations

import json
import math
import re
import time
from dataclasses import dataclass, field

from . import prompts, sandbox

__all__ = ["Generation", "Attempt", "generate", "LLMUnavailable"]


class LLMUnavailable(RuntimeError):
    """没有 API Key / 网络不通。只在 `strict=True` 时抛。"""


# --------------------------------------------------------------------------
# 数据结构
# --------------------------------------------------------------------------

@dataclass
class Attempt:
    """一次尝试的完整记录。这是事后归因（模型不行 vs prompt 不行）的唯一依据。"""

    n: int
    source: str = ""
    error: str | None = None
    stage: str = ""            # "llm" | "static" | "exec" | "extract" | "simulate" | "timeout" | "ok"
    line: int | None = None
    elapsed_ms: float = 0.0
    sim_ok: bool = False
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "attempt": self.n,
            "stage": self.stage,
            "error": self.error,
            "line": self.line,
            "elapsed_ms": round(self.elapsed_ms, 1),
            "sim_ok": self.sim_ok,
            "source_chars": len(self.source),
            "source": self.source,
            "notes": list(self.notes),
        }


@dataclass
class Generation:
    """generate() 的返回值。

    字段与 CONTRACT 一致：`.ok / .source / .circuit / .solution / .error / .attempts`。
    """

    ok: bool = False
    source: str = ""
    circuit: object = None
    solution: object = None
    error: str | None = None
    attempts: list[Attempt] = field(default_factory=list)
    model: str = ""
    elapsed_ms: float = 0.0
    request: str = ""
    #: 不致命但必须让用户看见的问题（例如「模型自加的断言没过」）。
    #: 与 .error 的区别：error 非空表示没有交付；warnings 可以有交付。
    warnings: list[str] = field(default_factory=list)

    # ---- 便于人读 ----
    @property
    def repaired(self) -> bool:
        """是否靠修复重试才成功（用于统计模型稳定性）。"""
        return self.ok and len(self.attempts) > 1

    def metrics(self) -> dict:
        """从 solution 里抽关键指标（没有 solution 时返回空 dict）。"""
        if self.solution is None or self.circuit is None:
            return {}
        return _extract_metrics(self.circuit, self.solution)

    def summary(self) -> str:
        head = f"[{'成功' if self.ok else '失败'}] {len(self.attempts)} 次尝试, {self.elapsed_ms:.0f}ms"
        if self.repaired:
            head += f"（修复了 {len(self.attempts) - 1} 次）"
        lines = [head]
        if self.circuit is not None:
            lines.append(self.circuit.describe())
        m = self.metrics()
        if m:
            lines.append("实测：" + "，".join(f"{k}={v}" for k, v in m.items()))
        if self.error:
            lines.append(f"错误：{self.error}")
        return "\n".join(lines)

    def attempts_dicts(self) -> list[dict]:
        return [a.as_dict() for a in self.attempts]


# --------------------------------------------------------------------------
# 代码块提取
# --------------------------------------------------------------------------

_RE_FENCE = re.compile(r"```(?:python|py)?\s*\n(.*?)```", re.S | re.I)


def extract_code(text: str) -> str:
    """从模型回复里抠出代码。

    模型经常前后带解释、或者给多个代码块。策略：
    优先取**定义了 build() 或 import 了 ccl** 的那个块；否则取最长的一块。
    """
    blocks = [b.strip() for b in _RE_FENCE.findall(text or "")]
    if not blocks:
        # 没有围栏：整段当代码（模型有时直接吐代码）
        body = (text or "").strip()
        return body if ("def build" in body or "Circuit(" in body) else ""
    for b in blocks:
        if "def build" in b and "Circuit" in b:
            return b
    for b in blocks:
        if "Circuit(" in b:
            return b
    return max(blocks, key=len)


# --------------------------------------------------------------------------
# 扫频范围：跟着电路走
# --------------------------------------------------------------------------

def _characteristic_freq(circuit) -> float | None:
    """从元件值估一个特征频率，用于定扫频中心。

    只看「有源件 + 它的邻居」太复杂，这里用更稳的启发式：
    对每个 RC / RL 组合取 1/(2πRC) 或 R/(2πL)，取几何中位数。
    再考虑运放 GBW（闭环带宽 ≈ GBW/增益，量级仍由 GBW 决定上限）。
    """
    freqs: list[float] = []
    rs = [c.value for c in circuit.components if c.kind == "R"
          and isinstance(c.value, (int, float)) and c.value > 0]
    cs = [c.value for c in circuit.components if c.kind == "C"
          and isinstance(c.value, (int, float)) and c.value > 0]
    ls = [c.value for c in circuit.components if c.kind == "L"
          and isinstance(c.value, (int, float)) and c.value > 0]

    for r in rs:
        for c in cs:
            freqs.append(1.0 / (2.0 * math.pi * r * c))
        for l in ls:
            freqs.append(r / (2.0 * math.pi * l))

    # 运放：GBW 本身就是个频率尺度
    for comp in circuit.components:
        if comp.kind == "X":
            gbw = getattr(comp, "gbw", None)
            if isinstance(gbw, (int, float)) and gbw > 0:
                freqs.append(float(gbw))

    freqs = [f for f in freqs if f and math.isfinite(f) and f > 0]
    if not freqs:
        return None
    # 几何中位数：对「很多无关 RC 组合」比算术平均稳
    logs = sorted(math.log10(f) for f in freqs)
    return 10.0 ** logs[len(logs) // 2]


def _sweep_range(circuit) -> tuple[float, float]:
    """按特征频率定扫频范围：下 3 个十倍频、上 3 个十倍频。

    3 个十倍频是实测出来的平衡点：足够看到平坦段和滚降段，点数又不多。
    找不到特征频率时退回 1Hz~100MHz（宽扫，至少不会漏掉极点）。
    """
    fc = _characteristic_freq(circuit)
    if not fc:
        return 1.0, 1e8
    lo = max(fc / 1e3, 1e-3)
    hi = min(fc * 1e3, 1e12)
    if hi <= lo * 10:
        hi = lo * 1e6
    return lo, hi


# --------------------------------------------------------------------------
# 指标抽取（给 explain / 报告用）
# --------------------------------------------------------------------------

def check_expectations(circuit, solution) -> list:
    """核对代码里自带的 c.expect 规格。

    **这条比从 prompt 抽数字更可靠**：`c.expect("fc","out",1000)` 是用户/模型
    明确声明的目标，语义没有歧义；而正则从中文里抽「1kHz」可能抽错。
    所以只要代码里有 expect，就以它为准（两者都做，取并集）。
    """
    exps = list(getattr(circuit, "expectations", []) or [])
    if not exps:
        return []
    from ..assertions import evaluate
    kind = getattr(solution, "kind", None)
    ac_sol = solution if kind == "ac" else None
    op_sol = solution if kind == "op" else None
    try:
        if ac_sol is None and any(e.needs_ac() for e in exps):
            ac_sol = circuit.ac(1.0, 1e6, 80)
        if op_sol is None and any(e.needs_op() for e in exps):
            op_sol = circuit.op()
    except Exception:
        pass
    rep = evaluate(exps, circuit, ac_sol=ac_sol, op_sol=op_sol)
    return [r for r in rep.results if not r.ok]


def _extract_metrics(circuit, solution) -> dict:
    """抽几个关键指标。不猜、不编：抽不到就不放进去。"""
    out: dict[str, float] = {}
    if solution is None:
        return out
    try:
        if solution.kind == "ac":
            nodes = [n for n in solution.node_names() if n not in ("in", "i(v1)")]
            target = "out" if solution.has_node("out") else (nodes[-1] if nodes else None)
            if target:
                g = solution.gain_db(target)
                out["低频增益_dB"] = round(g, 2)
                out["增益倍数"] = round(10 ** (g / 20.0), 3)
                f3 = solution.f3db(target)
                if f3:
                    out["f-3dB_Hz"] = _sig(f3)
                peak = solution.peak_db(target)
                if peak - g > 0.5:
                    out["峰化_dB"] = round(peak - g, 2)
        elif solution.kind == "op":
            for n in solution.node_names():
                if n.startswith("i("):
                    continue
                out[f"V({n})"] = round(solution.value_at(n, 0.0), 4)
    except Exception:
        pass
    return out


def _sig(x: float) -> float:
    """保留 4 位有效数字，方便贴到报告里。"""
    if not x or not math.isfinite(x):
        return x
    from math import floor, log10
    exp = floor(log10(abs(x)))
    return round(x, -exp + 3)


# --------------------------------------------------------------------------
# 一次完整尝试：exec + 仿真
# --------------------------------------------------------------------------

def _run_and_simulate(source: str, *, timeout_s: float = 25.0) -> tuple[object, object, str | None, int | None, str, bool]:
    """exec 代码并真跑一次仿真。

    返回 (circuit, solution, error, line, stage, sim_ok)。
    **仿真失败不算致命**：电路已经拿到，可交付（ok=True），只是没有 solution。
    但仿真失败的信息要进 attempts，让修复循环知道。
    """
    res = sandbox.run_source(source, timeout_s=timeout_s)
    if not res.ok:
        return None, None, res.trace(), res.line, res.stage, False

    circuit = res.circuit
    # 先做结构自检：这一步比仿真快，且错误更指向具体器件
    try:
        circuit.validate()
    except Exception as e:
        return circuit, None, f"结构自检失败：{type(e).__name__}: {e}", None, "validate", False

    # ⚑ 静态检查（lint）必须在这里跑。早先只有 `fix()` 路径跑 lint，
    # `generate()` 完全不跑 —— 实测 R=1nΩ / C=100kF / R=1TΩ 全部交付 ok=True 零告警。
    # 这些值物理上不存在（1 纳欧的电阻、10 万法的电容），但电路"能跑"、指标"能算"，
    # 于是用户拿到一张看起来完美、实际买不到的 BOM。
    try:
        from .. import lint as _lint
        _errs = [i for i in circuit.lint(None) if getattr(i, "level", "") == "error"]
        if _errs:
            _msg = "；".join(str(getattr(i, "title", "")) + "：" +
                             str(getattr(i, "detail", ""))[:80] for i in _errs[:3])
            return (circuit, None, f"静态检查未通过：{_msg}", None, "lint", False)
    except Exception:
        pass                      # lint 自己出问题不该阻断生成

    lo, hi = _sweep_range(circuit)

    lo, hi = _sweep_range(circuit)
    try:
        solution = circuit.ac(lo, hi, 200)
    except Exception as e:
        detail = str(e)
        # 收敛错误带上仿真器原始输出（截断），这是修复的关键线索
        raw = getattr(e, "output", "") or ""
        if raw:
            detail += "\n仿真器输出（截断）：\n" + raw[:800]
        return circuit, None, f"仿真失败：{type(e).__name__}: {detail}", None, "simulate", False

    return circuit, solution, None, None, "ok", True


# --------------------------------------------------------------------------
# 主入口
# --------------------------------------------------------------------------

def generate(
    prompt: str,
    *,
    model: str | None = None,
    max_repair: int = 2,
    timeout_s: float = 25.0,
    temperature: float = 0.2,
    strict: bool = False,
    _llm=None,
) -> Generation:
    """把自然语言需求变成**跑通了的**电路。

    参数
        prompt      需求原文，中文即可
        model       覆盖配置里的模型名
        max_repair  失败后最多修复几次（默认 1；总尝试数 = 1 + max_repair）
        timeout_s   单次 exec 的墙钟上限
        strict      True 时无 Key 抛 LLMUnavailable；默认返回 ok=False
        max_repair  修复重试轮数，默认 2（实测二阶滤波类需求需要 3 轮才收敛）

    返回
        Generation。`.ok=True` 时 `.circuit` 一定非空、`.source` 一定可执行。
        `.solution` 可能为 None（电路成立但仿真没跑通），这不算失败但要如实告知。
    """
    t0 = time.perf_counter()
    gen = Generation(request=prompt)

    # ---- 模型可用性：没有 Key 不许影响 import，也不许崩调用方 ----
    try:
        if _llm is None:
            from copilot.llm import LLM, load_config

            cfg = load_config()
            llm = LLM()
            gen.model = model or cfg.get("model", "")
        else:
            llm = _llm
            gen.model = model or getattr(llm, "model", "")
    except ImportError as e:
        gen.error = f"无法加载 copilot.llm（{e}）；AI 生成功能不可用，核心库不受影响"
        gen.elapsed_ms = (time.perf_counter() - t0) * 1000
        if strict:
            raise LLMUnavailable(gen.error) from e
        return gen

    # 无论是自建还是外部传入的 LLM，都必须先确认可用，
    # 否则会白跑一轮网络请求、把「没有 Key」误报成「调用模型失败」。
    try:
        ready = bool(llm.available())
    except Exception:
        ready = False
    if not ready:
        gen.error = "未配置 API Key"
        gen.elapsed_ms = (time.perf_counter() - t0) * 1000
        if strict:
            raise LLMUnavailable(gen.error)
        return gen

    if model:
        # 用 dataclass 的 LLM 时直接改字段；兼容假 LLM
        try:
            llm.model = model
        except Exception:
            pass

    n_rounds = max(0, int(max_repair)) + 1
    source = ""
    error_text = ""

    for n in range(1, n_rounds + 1):
        at = Attempt(n=n)
        round_t0 = time.perf_counter()

        # ---- 1) 让模型出代码 ----
        try:
            messages = (
                prompts.gen_prompt(prompt) if n == 1
                else prompts.repair_prompt(prompt, source, error_text)
            )
            raw = llm.chat(messages, temperature=temperature, max_tokens=1800)
        except Exception as e:
            at.stage, at.error = "llm", f"{type(e).__name__}: {e}"
            at.elapsed_ms = (time.perf_counter() - round_t0) * 1000
            gen.attempts.append(at)
            gen.error = f"调用模型失败：{at.error}"
            if strict:
                raise LLMUnavailable(gen.error) from e
            break

        src = extract_code(raw)
        at.source = src
        if not src:
            at.stage, at.error = "llm", "模型回复里没有找到 Python 代码块"
            at.elapsed_ms = (time.perf_counter() - round_t0) * 1000
            gen.attempts.append(at)
            error_text = at.error
            source = raw[:1500]
            continue

        source = src

        # ---- 2) 安全 exec + 真跑仿真 ----
        circuit, solution, err, line, stage, sim_ok = _run_and_simulate(
            src, timeout_s=timeout_s
        )
        at.stage = stage
        at.error = err
        at.line = line
        at.sim_ok = sim_ok
        at.elapsed_ms = (time.perf_counter() - round_t0) * 1000

        if circuit is not None:
            at.notes.append(circuit.describe())

        gen.attempts.append(at)

        if err is None:
            # 代码能跑 ≠ 满足需求。把 prompt 里明确提出的指标与实测对账，
            # 不达标就当成失败进入修复循环——否则会返回 ok=True 的错答案
            # （实测踩过：要求截止 10kHz，生成电路实测 4170Hz，却报成功）。
            _check_failed = False
            try:
                from . import spec_check as _SC
                # 传 circuit：电压类目标要靠电路里的电压源找激励节点，
                # 只给 solution 的话节点名对不上（模型常把源叫 vin/src）→ 会误判。
                _targets = _SC.parse_targets(prompt)
                # ⚑ 用**严格版**：测不到（solution 为空 / 没有可测节点 / 读不出结果）
                # 一律抛 Unmeasurable，由下面当**失败**处理。
                # 旧版 check_targets 用同一个 [] 表示「没抽到/全达标/测不到」，
                # 调用方一律读成"没问题" —— 沙箱一被污染（ac() 返回 None），
                # 产品就永远宣称成功（实测可复现）。
                _misses = _SC.check_targets_strict(_targets, solution, circuit=circuit)
                # ⚑ 总闸：需求里明明写了量化指标，却一个都没抽出来 → 必须提醒。
                # 否则「输出 1A」「误差小于 2%」「相位裕度 45°」这类会被静默跳过，
                # 用户拿到一个 ok=True 的错答案（实测：要求 5V，交 5.45V 仍算成功）。
                if not _targets:
                    _unp = _SC.unparsed_metrics(prompt)
                    if _unp:
                        gen.warnings.append(
                            "需求里这些指标本工具无法自动对账，请人工确认："
                            + "、".join(dict.fromkeys(_unp)))
            except Exception as _e:
                from . import spec_check as _SC2
                if isinstance(_e, getattr(_SC2, "Unmeasurable", ())):
                    # 测不到 ≠ 达标：这一轮直接判失败，交给修复循环
                    _misses = []
                    _check_failed = True
                    err = err or f"需求对账失败：{_e}"
                    at.notes.append(str(_e))
                    gen.warnings.append(f"需求对账失败（这轮结果不能算达标）：{_e}")
                else:
                    _misses = []
                    _check_failed = True
                    at.notes.append(f"指标核对异常：{type(_e).__name__}: {_e}")
                    gen.warnings.append(
                        f"需求对账器异常，本轮未做指标核对（结果可能不满足需求）：{_e}")
            # 代码里自带的 c.expect 也要核 —— 它比正则抽数字更可靠
            _failed_expects = []
            try:
                _failed_expects = check_expectations(circuit, solution)
            except Exception as _e2:
                at.notes.append(f"规格核对异常（已跳过）：{type(_e2).__name__}: {_e2}")

            if _failed_expects:
                for r in _failed_expects:
                    at.notes.append(r.message())
                if _misses:
                    # 用户明确提的指标都没达到 → 仍然算失败，先进修复循环。
                    # 这时模型自加断言过不过无所谓，用户要求才是第一位的。
                    at.error = "自带的规格未通过：" + "；".join(
                        r.message().replace("❌ ", "") for r in _failed_expects)
                    error_text = ("代码里的 c.expect 规格没有通过仿真验证：\n" +
                                  "\n".join("- " + r.message() for r in _failed_expects) +
                                  "\n请修正元件值（或结构）使这些规格成立，重新给出完整代码。")
                    gen.source, gen.circuit, gen.solution = src, circuit, solution
                    gen.error = at.error
                    gen.ok = False
                    continue
                # 用户要求全部达标，但**模型自己加的断言**没过 → 不再一票否决。
                #
                # 为什么改：c.expect 是模型自己写的，它可能比用户要求更严、甚至写错。
                # 实测案例（真实模型跑出来的）：需求「无源 RLC 带通，中心 100kHz」，
                # 电路峰值实测 100kHz（达标），但模型在代码里写了 `c.expect("fc", ...)`
                # —— 把「带通的中心频率」当成了「−3dB 截止点」（那是低通的定义）→
                # 断言不过 → 一个正确电路被拒收。基准里这一条一直记为「真·误杀」。
                #
                # 现在的处理：交付，但把可疑断言逐条列出来让用户自己判断。
                gen.warnings.append(
                    "模型自加的断言未通过（用户要求本身已达标，可能是断言写得过严或写错）："
                    + "；".join(r.message().replace("❌ ", "") for r in _failed_expects)
                    + "。请核对这几条断言是否真的成立，它们不一定代表需求。")

            if _misses:
                at.error = "指标不达标：" + "；".join(m.message() for m in _misses)
                at.notes.append(at.error)
                error_text = _SC.repair_hint(_misses)
                # 保留这一次的电路与波形（用户看得见跑了什么），但不判成功
                gen.source, gen.circuit, gen.solution = src, circuit, solution
                gen.error = at.error
                gen.ok = False
                continue
            # ⛑ 模型自己说「做不到」→ 绝不能交付为成功
            _imp = _model_claims_impossible(src)
            if _imp:
                at.error = "模型指出需求物理上无法满足：" + _imp
                at.notes.append(at.error)
                gen.warnings.append(
                    "模型在代码注释里指出这条需求物理上做不到，已按未交付处理。原始说法：" + _imp)
                gen.source, gen.circuit, gen.solution = src, circuit, solution
                gen.error = at.error
                gen.ok = False
                continue

            if _check_failed:
                # ⚑ 对账没做成（测不到 / 核对器崩了）→ **绝不能算成功**。
                # 以前这里直接落到下面的 gen.ok=True，于是"拿不到证据"被当成"没问题"。
                at.error = "需求对账没能完成，这一轮结果不能算达标"
                at.notes.append(at.error)
                gen.source, gen.circuit, gen.solution = src, circuit, solution
                gen.error = at.error
                gen.ok = False
                continue
            gen.ok, gen.source, gen.circuit, gen.solution = True, src, circuit, solution
            gen.error = None
            break

        # 电路建出来了但仿真失败：可交付电路，错误留档继续尝试修
        if circuit is not None:
            gen.source, gen.circuit = src, circuit
            gen.error = err

        error_text = err

        # 静态检查/语法错误不重试——同一模型大概率再错一次，浪费一轮
        if stage == "static":
            gen.error = f"{err}\n（静态检查未通过，未重试：这类错误通常来自模型违反沙箱规则）"
            break

    gen.elapsed_ms = (time.perf_counter() - t0) * 1000
    if not gen.ok and not gen.error:
        gen.error = gen.attempts[-1].error if gen.attempts else "生成失败（未知原因）"
    return gen

# --------------------------------------------------------------------------
# fix()：拿用户现成的电路代码，按「实际不达标的地方」去改
# --------------------------------------------------------------------------

#: 模型自己在代码/注释里承认「这个要求做不到」的强判据。
#: 只收**明确指向需求**的说法，避免把「这个值做不到」这类无关评论当成拒绝。
_IMPOSSIBLE_MARKERS = (
    "物理上不可能", "物理不可能", "物理上矛盾", "互相矛盾", "自相矛盾",
    "无法同时满足", "不可能同时", "无法同时达到", "不可能同时达到",
    "做不到这个要求", "违反物理", "不可能实现", "无法实现这个要求",
    "不可能满足", "无法满足这个需求", "这个要求不成立",
)


def _model_claims_impossible(source: str) -> str | None:
    """模型自己在注释里说了「做不到」→ 返回那句话，否则 None。

    ⚑ 为什么必须认这一条：真模型实测（需求「RC 低通截止 1kHz，且在 1kHz 处衰减 60dB」，
    一阶在 fc 处恒为 −3dB，物理上互相矛盾），模型很诚实地在源码顶部写了 5 行
    「# 限制：…互相矛盾…物理上不可能」，而产品返回 `{ok: true, warnings: []}`，
    面板只显示「已生成」。**模型说不可能、工具说成功**是最糟的组合。
    """
    if not source:
        return None
    for ln in source.splitlines():
        s = ln.strip()
        if not s.startswith("#"):
            continue
        for mk in _IMPOSSIBLE_MARKERS:
            if mk in s:
                return s[:160]
    return None

def _diagnose(circuit, solution, source: str, request: str = "") -> tuple[str, list[str]]:
    """把当前代码的所有硬问题收集成一段可回喂给模型的错误描述。

    ⚑ `request` 是对账的**必需**输入。早先这里只跑 lint + c.expect，
    **一次需求对账都没有** —— 实测 `fix(code, request="截止频率必须改成10kHz")`
    返回 ok=True、模型调用 **0 次**、UI 说「没发现问题」，代码一字未动、实测仍 995Hz。
    用户明确写了要改什么，工具却说"没问题"。
    """
    from ..lint import lint as _lint

    problems: list[str] = []
    # 诊断器自己挂了绝不能静默：fix() 靠「problems 为空」判定无需修复，
    # 这里吞掉异常会把「诊断崩溃」变成「电路没问题，判成功」。
    try:
        for i in _lint(circuit, solution):
            if i.level in ("error", "warn"):
                where = f" [{i.ref}]" if getattr(i, "ref", "") else ""
                problems.append(f"- {i.title}{where}：{i.detail}")
    except Exception as e:
        problems.append(f"- 诊断器异常（lint 失败，按有问题处理）：{type(e).__name__}: {e}")

    try:
        for r in check_expectations(circuit, solution):
            problems.append("- 规格未通过：" + r.message().replace("❌ ", ""))
    except Exception as e:
        problems.append(f"- 诊断器异常（规格核对失败，按有问题处理）：{type(e).__name__}: {e}")

    # ⚑ 需求对账：用户说的指标没达到，也算「有问题，必须修」
    if (request or "").strip():
        try:
            from . import spec_check as _SC
            _tg = _SC.parse_targets(request)
            if _tg:
                _miss = _SC.check_targets_strict(_tg, solution, circuit=circuit)
                for m in _miss:
                    problems.append("- 需求未满足：" + m.message())
            else:
                _unp = _SC.unparsed_metrics(request)
                if _unp:
                    problems.append(
                        "- 需求里有本工具无法自动对账的指标（" + "、".join(dict.fromkeys(_unp)) +
                        "）：请按常识确保它们成立，并在代码里用 c.expect(...) 写出可验证的断言")
        except Exception as e:
            # 对账做不成 ≠ 没问题：按「有问题」处理，让模型去补
            problems.append(f"- 需求对账未能完成（按有问题处理）：{type(e).__name__}: {e}")

    return ("\n".join(problems), problems)


def fix(
    source: str,
    *,
    request: str = "",
    model: str | None = None,
    max_repair: int = 2,
    temperature: float = 0.2,
    timeout_s: float = 20.0,
    _llm=None,
) -> Generation:
    """给一段现成的 CCL 电路代码，让模型按实际问题修正它。

    与 `generate()` 的区别：`generate` 从需求造新电路，`fix` 从**用户已有代码**
    出发，先诊断（静态检查 + 工作点 + 自带规格），只把真实存在的问题回喂给模型。

    诊断是确定性的：没有问题时**根本不调用模型**，直接把原代码返回。
    """
    gen = Generation(request=request or "（修改现有电路）", model=model or "")
    gen.source = source or ""
    t0 = time.perf_counter()

    if not (source or "").strip():
        gen.error = "源代码为空"
        gen.elapsed_ms = (time.perf_counter() - t0) * 1000
        return gen

    # ---- 第 0 轮：先诊断，没问题就不花 token ----
    res = None
    try:
        from .sandbox import run_source
        res = run_source(source, timeout_s=timeout_s, require_circuit=True)
    except Exception as e:
        gen.error = f"沙箱异常：{type(e).__name__}: {e}"
        gen.elapsed_ms = (time.perf_counter() - t0) * 1000
        return gen

    diag_text, _ = ("", [])
    if res.ok and res.circuit is not None:
        sol = None
        try:
            sol = res.circuit.ac(1.0, 1e6, 80)
        except Exception:
            try:
                sol = res.circuit.op()
            except Exception:
                sol = None
        diag_text, probs = _diagnose(res.circuit, sol, source, request)
        if not probs:
            gen.ok = True
            gen.circuit, gen.solution = res.circuit, sol
            gen.error = None
            gen.elapsed_ms = (time.perf_counter() - t0) * 1000
            return gen
    else:
        diag_text = "代码本身跑不起来：" + (getattr(res, "trace", lambda: "")() or
                                           getattr(res, "error", "") or "未知错误")

    # ---- 调用模型修复 ----
    try:
        if _llm is None:
            from copilot.llm import LLM   # 与 generate() 同一来源
            llm = LLM()
        else:
            llm = _llm
        ready = getattr(llm, "available", lambda: True)()
    except Exception:
        llm, ready = None, False
    if not ready:
        gen.error = "未配置 API Key（无法自动修复；确定性诊断结果见 attempts）"
        at = Attempt(n=0, stage="diagnose", error=gen.error)
        at.notes.append(diag_text)
        gen.attempts.append(at)
        gen.elapsed_ms = (time.perf_counter() - t0) * 1000
        return gen
    if model:
        try:
            llm.model = model
        except Exception:
            pass

    cur = source
    err_text = diag_text
    for n in range(1, max(0, int(max_repair)) + 1):
        at = Attempt(n=n)
        rt = time.perf_counter()
        try:
            msgs = prompts.repair_prompt(gen.request, cur, err_text)
            raw = llm.chat(msgs, temperature=temperature, max_tokens=1800)
            new_src = extract_code(raw) or ""
            at.source = new_src
        except Exception as e:
            at.stage, at.error = "llm", f"{type(e).__name__}: {e}"
            gen.attempts.append(at)
            gen.error = f"调用模型失败：{at.error}"
            break

        circuit, solution, err, line, stage, sim_ok = _run_and_simulate(new_src, timeout_s=timeout_s)
        at.stage, at.error, at.line, at.sim_ok = stage, err, line, sim_ok
        at.elapsed_ms = (time.perf_counter() - rt) * 1000

        if circuit is not None:
            d2, probs2 = _diagnose(circuit, solution, new_src, request)
            if not probs2 and err is None:
                at.stage = "ok"
                gen.ok, gen.source, gen.circuit, gen.solution = True, new_src, circuit, solution
                gen.error = None
                at.source = new_src
                gen.attempts.append(at)
                break
            err_text = d2 or err or "未知问题"
            at.error = (d2.splitlines()[0][:140] if d2 else err)
        else:
            err_text = err or "代码执行失败"

        gen.attempts.append(at)
        cur = new_src or cur

    # ⚑ 修不动时必须留下**可读的原因**。早先这里直接 `return gen`，
    # 于是 ok=False 但 error=None —— 用户只看到"失败"，不知道哪条需求没满足。
    if not gen.ok and not gen.error:
        _last = gen.attempts[-1] if gen.attempts else None
        gen.error = (getattr(_last, "error", None) or
                     "修复没有成功：达到轮次上限仍未满足需求（详见 attempts）")
    gen.elapsed_ms = (time.perf_counter() - t0) * 1000
    return gen
