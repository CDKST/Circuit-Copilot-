"""电路评审：**先做确定性检查，再让模型解释**。

## 为什么是这个顺序

大模型会编问题。让它"看看这个电路有什么问题"，它会热心地告诉你
"建议检查 R1 的功耗"——即使 R1 根本不存在。这种编造比漏报更伤人：
用户会去修一个不存在的问题，然后对工具失去信任。

所以分工是**硬的**：

- **确定性检查**（本文件的 `check_*` 函数）负责"发现"。全部基于电路结构
  与仿真波形，不依赖模型，可单元测试，结果可复现。
- **模型**负责"翻译"：把确定性结果讲成人话、指出影响、给出改法。
  模型也可以补充它看出的问题，但**必须能对应到电路里真实存在的位号/节点**，
  否则丢弃（`_validate_llm_issues`）。

没有 API Key 时 `review()` 照样返回完整的确定性结果——这是核心库不依赖 AI 的体现。

## 检查项

| 项 | 级别 | 依据 |
|---|---|---|
| 电路为空 | error | 结构 |
| 完全没有地 | error | 结构（SPICE 必须有参考地） |
| 悬空节点（只连 1 引脚） | error | 结构 |
| 节点无直流通路到地 | error | 结构（SPICE 会 singular matrix） |
| 电压源并联/自短路 | error | 结构 |
| 参数越界（R/C/L <= 0） | error | 结构 |
| 无 AC 激励 | warn | 结构（AC 分析恒为 0） |
| 孤立子网络（有地但不连通主电路） | warn | 结构 |
| 输出撞电源轨 | error/warn | 仿真（op） |
| 峰化过大 / 异常谐振峰 | warn/error | 仿真（ac） |
| 输出增益异常（近乎无输出） | warn | 仿真（ac） |
| 无信号源 | warn | 结构 |
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field

__all__ = ["Issue", "review", "deterministic_checks"]

# 静态检查的唯一真相在 ccl/lint.py（核心能力，不属于可选 AI 包）
from ..lint import (
    Issue,
    check_ac_excitation,
    check_dc_path,
    check_empty,
    check_floating,
    check_ground,
    check_isolated_subnets,
    check_params,
    check_voltage_sources,
)

def check_rails(circuit, solution) -> list[Issue]:
    """输出撞电源轨。

    注意：运放用的是**小信号宏模型**（没有电源引脚、没有饱和），
    所以这里的判定是"op 工作点电压超出了从电压源推断出的轨"，
    属于间接推断，detail 里必须说清楚。
    """
    if solution is None or getattr(solution, "kind", "") != "op":
        return []
    rails: list[float] = []
    for c in circuit.components:
        if c.kind.upper() != "V":
            continue
        nodes = c.nodes()
        if GND not in nodes:
            continue
        v = getattr(c, "dc", c.value)
        if isinstance(v, (int, float)) and v != 0:
            rails.append(float(v))
    if not rails:
        return []

    hi, lo = max(rails), min(rails)
    out: list[Issue] = []
    for node in solution.node_names():
        if node.startswith("i(") or node == GND:
            continue
        try:
            val = solution.value_at(node, 0.0)
        except Exception:
            continue
        if not math.isfinite(val):
            out.append(Issue("error", "工作点发散",
                             f"节点 {node!r} 的直流电压是 {val}，电路没有有效工作点", node))
            continue
        if val > hi + 1e-9 or val < lo - 1e-9:
            out.append(Issue(
                "error", "输出撞电源轨",
                f"节点 {node!r} 的直流电压 {val:.4g}V 超出电源轨 [{lo:g}, {hi:g}]V。"
                f"运放宏模型不含饱和，这个数字是线性外推的结果——真实电路里输出会被钳位，"
                f"闭环不再成立。检查偏置与反馈极性（正反馈会把输出推到轨上）",
                node,
            ))
    return out


def _shape(db: list[float]) -> str:
    """从幅频曲线两端的走向判断滤波器类型。

    只看"两端电平差"是错的——带通两端都在下降，永远不可能相等。
    必须看**走向**（斜率）：

    - 左升 + 右平 → 低通（低频通，高频衰减）
    - 左平 + 右升 → 高通（低频衰减，高频通）
    - 左升 + 右升 → 带通（两端都衰减，中间凸）
    - 左平 + 右平 → 全通 / 带阻（中间下陷）

    返回 "lowpass" / "highpass" / "bandpass" / "flat"。
    """
    n = len(db)
    if n < 10:
        return "flat"
    edge = max(3, n // 10)
    # 两个方向都定义成"从最外侧往里走，电平是否上升"：
    # 上升说明该端被衰减了，那一端就是阻带。
    left_rise = db[edge - 1] - db[0]      # 左端（低频侧）
    right_rise = db[-edge] - db[-1]       # 右端（高频侧）★ 内侧减外侧
    thr = 3.0
    left_up = left_rise > thr
    right_up = right_rise > thr
    if left_up and right_up:
        return "bandpass"
    if left_up:
        return "highpass"
    if right_up:
        return "lowpass"
    return "flat"


def check_peaking(circuit, solution) -> list[Issue]:
    """峰化过大 / 异常谐振峰。

    ## 为什么必须先判类型

    "峰化"的含义取决于滤波器类型：

    - **低通 / 高通**：通带是平的，峰值超出通带电平才叫峰化。
    - **带通**：中间那个峰**本来就是设计目标**，两端衰减是应该的。
      对它算 `peak − 低频增益` 会得到 +30dB 的假报警。

    所以先用 `_shape()` 从曲线走向判类型，带通完全不走"峰化"这条路。
    这是踩过的坑：第一版用"两端电平差 <3dB"判带通，而带通两端都在下降、
    永远判不出来，结果每个带通都被误报成严重峰化。
    """
    if solution is None or getattr(solution, "kind", "") != "ac":
        return []
    out: list[Issue] = []
    nodes = [n for n in solution.node_names() if not n.startswith("i(")]
    target = "out" if "out" in nodes else (nodes[-1] if nodes else None)
    if not target:
        return []

    try:
        base = solution.gain_db(target)
        peak = solution.peak_db(target)
        db = solution.db(target)
        xs = solution.v(target).x
    except Exception:
        return []
    if not db or not math.isfinite(base) or base < -300:
        return []

    n = len(db)
    shape = _shape(db)
    edge = max(3, n // 10)

    if shape == "bandpass":
        # 带通的峰是设计目标，不报峰化；只查 Q 过高
        return _bandpass_checks(target, db, xs, peak)

    # 低通取低频端电平、高通取高频端电平，作为"通带电平"
    if shape == "highpass":
        passband = sorted(db[-edge:])[len(db[-edge:]) // 2]
        kind_cn = "高通"
    elif shape == "lowpass":
        passband = sorted(db[:edge])[len(db[:edge]) // 2]
        kind_cn = "低通"
    else:
        passband = max(sorted(db[:edge])[len(db[:edge]) // 2],
                       sorted(db[-edge:])[len(db[-edge:]) // 2])
        kind_cn = "网络"

    excess = peak - passband
    if excess > 6:
        out.append(_peak_issue(target, peak, passband, excess, "error",
                               f"{kind_cn}峰化严重（>6dB），接近自激或 Q 过高"))
    elif excess > 3:
        out.append(_peak_issue(target, peak, passband, excess, "warn",
                               f"{kind_cn}峰化偏大（>3dB），阶跃响应会有明显过冲"))

    # ---- 孤立谐振峰（LC 无阻尼之类）----
    if n >= 5 and xs:
        try:
            i_max = max(range(n), key=lambda i: db[i])
            if 0 < i_max < n - 1:
                left = max(db[:i_max])
                right = max(db[i_max + 1:])
                if db[i_max] - left > 10 and db[i_max] - right > 10:
                    out.append(_resonance_issue(target, xs[i_max], db[i_max], left, right))
        except Exception:
            pass
    return out


def _bandpass_checks(node, db, xs, peak) -> list[Issue]:
    """带通专用：只查 Q 过高。

    带通的正常形态是"中间一个峰、两侧下降"，这本身**不报**。
    真问题是 Q 太高（带宽过窄、对元件容差极敏感）。
    """
    out: list[Issue] = []
    n = len(db)
    if not xs or n < 10 or peak <= -300:
        return out
    idx = max(range(n), key=lambda i: db[i])
    f0 = xs[idx]
    if f0 <= 0:
        return out
    half = peak - 3.0
    left_f = right_f = None
    for i in range(idx, -1, -1):
        if db[i] <= half:
            left_f = xs[i]
            break
    for i in range(idx, n):
        if db[i] <= half:
            right_f = xs[i]
            break
    if not (left_f and right_f) or right_f <= left_f:
        return out
    bw = right_f - left_f
    if bw / f0 < 0.02:
        out.append(Issue(
            "warn", "带通 Q 值过高",
            f"节点 {node!r} 的中心频率 {f0:.4g}Hz，−3dB 带宽只有 {bw:.4g}Hz"
            f"（Q≈{f0/bw:.1f}）。这么窄的带通对元件容差极敏感："
            f"1% 的 R/C/L 误差就能让中心频率偏移 {f0*0.01:.4g}Hz，"
            f"实际装出来大概率对不上。降低 Q 或改用更高精度元件",
            node,
        ))
    return out

def _peak_issue(node: str, peak: float, base: float, excess: float, level: str, why: str) -> Issue:
    return Issue(
        level, "峰化过大",
        f"节点 {node!r} 的通带峰值 {peak:.2f}dB 比低频增益 {base:.2f}dB 高 {excess:.2f}dB。{why}。"
        f"低通/带通里的峰化来自极点 Q 值：Q>0.707 就有峰，Q=1 约 +1.25dB，Q=2 约 +6dB。"
        f"要压平就把阻尼电阻加大或降低 Q",
        node,
    )


def _resonance_issue(node: str, f: float, peak: float, left: float, right: float) -> Issue:
    return Issue(
        "warn", "异常谐振峰",
        f"节点 {node!r} 在 {f:.4g}Hz 出现孤立峰 {peak:.2f}dB，"
        f"而两侧分别只有 {left:.2f}dB / {right:.2f}dB。"
        f"典型原因：LC 谐振没有阻尼（串一个电阻）、或反馈网络在某个频点相位反转",
        node,
    )


def check_output_level(circuit, solution) -> list[Issue]:
    """输出近乎为 0：说明激励没接上、或输出节点选错、或电路把信号吃掉了。"""
    if solution is None or getattr(solution, "kind", "") != "ac":
        return []
    nodes = [n for n in solution.node_names() if not n.startswith("i(")]
    if not nodes:
        return []
    target = "out" if "out" in nodes else nodes[-1]
    try:
        db = solution.db(target)
    except Exception:
        return []
    if not db:
        return []
    if max(db) < -120:
        return [Issue(
            "warn", "输出几乎没有信号",
            f"节点 {target!r} 的最大幅度只有 {max(db):.1f}dB，等于没有信号。"
            f"常见原因：源的 ac 幅度是 0、输出节点没接到任何器件、"
            f"或信号路径被电容/大电阻完全隔断",
            target,
        )]
    return []


# --------------------------------------------------------------------------
# 汇总：确定性检查
# --------------------------------------------------------------------------

def deterministic_checks(circuit, solution=None) -> list[Issue]:
    """全部确定性检查。不依赖模型，结果可复现。"""
    issues: list[Issue] = []
    issues += check_empty(circuit)
    if issues:      # 空电路，后面都没意义
        return issues

    issues += check_ground(circuit)
    issues += check_floating(circuit)
    issues += check_dc_path(circuit)
    issues += check_voltage_sources(circuit)
    issues += check_params(circuit)
    issues += check_ac_excitation(circuit)
    issues += check_isolated_subnets(circuit)

    issues += check_rails(circuit, solution)
    issues += check_peaking(circuit, solution)
    issues += check_output_level(circuit, solution)
    return issues


# --------------------------------------------------------------------------
# 模型补充（可选，且必须校验）
# --------------------------------------------------------------------------

SYSTEM_REVIEW = """你是资深模拟电路工程师，做设计评审。

系统已经用确定性检查找出了结构性问题（下面列出）。你的任务**不是**重复它们，
而是：
1. 对每条已有问题，补一句"这对用户意味着什么、怎么改"，要具体（带位号/数值）。
2. 补充你从电路结构和仿真数据里**确实看出来**的其他问题。

## 铁律（违反即作废）
- **不许编造**。你说的每一个问题都必须能对应到下面 JSON 里真实存在的位号或节点。
  引用不存在的位号会被系统直接丢弃，等于白说。
- 不许重复罗列已给的问题清单。
- 不许说"建议检查功耗""建议确认需求"这类不指向具体器件的话。
- 必须引用具体数字（元件值、Hz、dB）。

## 输出格式
严格 JSON：
{
  "notes": [{"ref": "已给问题的ref或位号/节点", "text": "人话解释 + 改法（带数字）"}],
  "extra": [{"level": "error|warn|info", "ref": "位号或节点", "title": "短标题", "detail": "说明"}]
}
`extra` 只放你**确实看出来**的；没有就空数组。"""


def _valid_refs(circuit) -> set[str]:
    refs = {c.ref for c in circuit.components}
    refs |= set(circuit.nets())
    return refs


def _validate_llm_issues(payload: dict, circuit) -> tuple[dict[str, str], list[Issue]]:
    """校验模型输出：引用不存在的位号/节点一律丢弃。这是防编造的最后一道闸。"""
    valid = _valid_refs(circuit)
    notes: dict[str, str] = {}
    extra: list[Issue] = []

    for item in payload.get("notes") or []:
        if not isinstance(item, dict):
            continue
        ref = str(item.get("ref") or "").strip()
        text = str(item.get("text") or "").strip()
        if not text:
            continue
        # ref 可以是逗号分隔的多个（"R1,R2"）
        parts = [p.strip() for p in ref.split(",") if p.strip()]
        if parts and all(p in valid for p in parts):
            notes[",".join(parts)] = text
        # ref 对不上就丢弃（宁可少一条解释，也不要编造的）

    for item in payload.get("extra") or []:
        if not isinstance(item, dict):
            continue
        level = str(item.get("level") or "warn")
        ref = str(item.get("ref") or "").strip()
        title = str(item.get("title") or "").strip()
        detail = str(item.get("detail") or "").strip()
        if level not in ("error", "warn", "info") or not detail:
            continue
        parts = [p.strip() for p in ref.split(",") if p.strip()]
        if not parts or not all(p in valid for p in parts):
            continue        # 指向不存在的对象 → 编造，丢弃
        extra.append(Issue(level, title or "模型补充", detail, ",".join(parts)))

    return notes, extra


def _component_dict(c) -> dict:
    """把一个器件序列化成给模型看的字典。

    ⚠️ 关键：运放的 `gbw` / `a0`、源的 `dc` / `ac` 是**实例属性**，
    不在 `params` 里（见 ccl/devices.py 的 `_Source.__init__` / `OpAmp.__init__`）。
    只给模型 `值` 字段会让它看不到运放的 GBW，于是"合理地"断言
    「X1 缺少增益/带宽参数」——实测就出现过这条假错误，把仿真数据说成不可信。
    所以这里显式把关键属性列出来。
    """
    d: dict = {
        "位号": c.ref,
        "类型": c.kind,
        "值": c.value if isinstance(c.value, (int, float)) else str(c.value),
        "端子": dict(zip([p.name for p in c.pins], c.nodes())),
    }
    for attr in ("gbw", "a0", "dc", "ac"):
        v = getattr(c, attr, None)
        if isinstance(v, (int, float)):
            d[attr] = v
    return d


def _circuit_payload(circuit, solution, issues) -> str:
    data: dict = {
        "电路名": getattr(circuit, "name", ""),
        "器件": [_component_dict(c) for c in circuit.components],
        "节点": {n: [f"{r}.{p}" for r, p in pins] for n, pins in circuit.nets().items()},
        "确定性检查已发现的问题": [i.as_dict() for i in issues],
    }
    if solution is not None:
        nodes = [n for n in solution.node_names() if not n.startswith("i(")]
        target = "out" if "out" in nodes else (nodes[-1] if nodes else None)
        if target:
            try:
                m = {
                    "分析类型": solution.kind,
                    "观察节点": target,
                    "低频增益_dB": round(solution.gain_db(target), 2),
                    "峰值_dB": round(solution.peak_db(target), 2),
                }
                if solution.kind == "ac":
                    f3 = solution.f3db(target)
                    if f3:
                        m["-3dB频率_Hz"] = round(f3, 2)
                data["仿真"] = m
            except Exception:
                pass
    return json.dumps(data, ensure_ascii=False, indent=2)


# --------------------------------------------------------------------------
# 对外入口
# --------------------------------------------------------------------------

def review(circuit, solution=None, *, model: str | None = None, _llm=None) -> list[Issue]:
    """评审一个电路，返回 Issue 列表（按 error → warn → info 排序）。

    确定性检查永远执行；模型补充是**可选增强**——没有 Key、网络不通、
    模型输出不合规，都只是少几条解释，不影响主结果。

    参数
        circuit    ccl.Circuit
        solution   ccl.Solution（可选；有它才能查撞轨/峰化/输出电平）
        model      覆盖模型名
    """
    issues = deterministic_checks(circuit, solution)

    # ---- 模型补充（尽力而为，失败静默降级）----
    try:
        if _llm is not None:
            llm = _llm
        else:
            from copilot.llm import LLM, load_config

            llm = LLM()
            if not llm.available():
                llm = None
        if llm is not None:
            if model:
                try:
                    llm.model = model
                except Exception:
                    pass
            payload = _circuit_payload(circuit, solution, issues)
            raw = llm.chat(
                [
                    {"role": "system", "content": SYSTEM_REVIEW},
                    {"role": "user", "content": payload},
                ],
                json_mode=True, temperature=0.2, max_tokens=1200,
            )
            from copilot.llm import extract_json

            data = extract_json(raw)
            notes, extra = _validate_llm_issues(data, circuit)
            # 把解释挂到对应 issue 上（保留确定性标题与级别，模型只加话）
            for iss in issues:
                if iss.ref and iss.ref in notes:
                    iss.detail = f"{iss.detail}\n→ {notes[iss.ref]}"
            issues += extra
    except Exception:
        pass        # 没有 Key / 网络问题 / 模型乱答 —— 都不该影响主结果

    order = {"error": 0, "warn": 1, "info": 2}
    issues.sort(key=lambda i: (order[i.level], i.ref))
    return issues
