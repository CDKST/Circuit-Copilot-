"""AI 生成插件。

## 为什么这个功能要格外小心

后端插件是**在本进程里 import 的 Python**，没有任何沙箱（见 `plugins/README.md`）。
所以这里的策略不是"生成完直接装上"，而是**三道闸门**：

1. **只生成草稿，不落盘。** AI 的输出先回到前端给用户看。
2. **落盘前必须过验证**：清单合法 → Python 过 `ast.parse` → JS 过 `node --check`
   → 在**独立子进程**里干跑一遍 `register(api)`，确认真能跑、没副作用。
3. **需要用户显式点「安装」**，不自动启用。

这与项目其他部分的原则一致：AI 可以生成，但**能不能生效由确定性检查决定**。
"""

from __future__ import annotations

import ast
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
PLUGIN_DIR = os.path.join(ROOT, "plugins")

ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")
PY_IDENT_RE = re.compile(r"^[a-z_][a-z0-9_]*$")

# backend.py 在服务启动时被 activate_all() 直接 import——语法合法的恶意代码
# 就是持久代码执行。ast.parse 只挡语法错误，挡不住 import os。
_BACKEND_FORBID_ROOTS = frozenset({
    "os", "sys", "subprocess", "socket", "shutil", "pathlib", "ctypes",
    "importlib", "builtins", "signal", "threading", "asyncio", "http", "urllib",
})
_BACKEND_FORBID_NAMES = frozenset({
    "eval", "exec", "compile", "open", "breakpoint", "__import__",
})


def check_backend_source(source: str) -> list[str]:
    """backend.py 落盘前的危险构造扫描，返回问题列表（空 = 通过）。

    插件的合法形态只需要：json / math / re / datetime 这类纯计算模块 +
    register(api) 钩子；凡是「能摸到进程外部」的构造一律拒绝。
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return [f"第 {e.lineno} 行语法错误：{e.msg}"]
    problems: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] in _BACKEND_FORBID_ROOTS:
                    problems.append(f"第 {node.lineno} 行：禁止 import {a.name}")
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root in _BACKEND_FORBID_ROOTS:
                problems.append(f"第 {node.lineno} 行：禁止 from {node.module} import …")
        elif isinstance(node, ast.Attribute):
            if node.attr.startswith("__"):
                problems.append(f"第 {node.lineno} 行：禁止访问双下划线属性 .{node.attr}")
        elif isinstance(node, ast.Name) and node.id in _BACKEND_FORBID_NAMES:
            problems.append(f"第 {node.lineno} 行：禁止使用 {node.id}")
    return problems


@dataclass
class Draft:
    ok: bool = False
    id: str = ""
    name: str = ""
    description: str = ""
    backend_py: str = ""
    ui_js: str = ""
    plugin_json: str = ""
    validation: dict = field(default_factory=dict)
    error: str = ""
    model: str = ""
    elapsed_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "ok": self.ok, "id": self.id, "name": self.name,
            "description": self.description,
            "backend_py": self.backend_py, "ui_js": self.ui_js,
            "plugin_json": self.plugin_json,
            "validation": self.validation, "error": self.error,
            "model": self.model, "elapsed_ms": round(self.elapsed_ms, 1),
        }


# ---------------------------------------------------------------------------
# Prompt：把插件 API 契约原样钉进去（和 ccl/ai/prompts.py 同一个策略）
# ---------------------------------------------------------------------------

SYSTEM = """你在为 CCL Studio 写一个**插件**。插件只能"追加"能力，不能改主程序。

## 必须严格使用的接口（只有这些，没有别的）

后端 `backend.py` 必须定义 `register(api)`，api 只有三个方法：

```python
from ccl.lint import Issue

def check_something(circuit):
    out = []
    for c in circuit.components:       # c 有 .ref .kind .value .nodes() .pins
        if 某个条件:
            out.append(Issue(
                "warn",                # 只能是 "error" / "warn" / "info"
                "一句话标题",
                "详细说明与建议",
                c.ref,                 # 位号，便于定位，可空字符串
                "plugin.my_code",      # 机器可读 code
            ))
    return out

def register(api):
    api.register_lint_rule(check_something)      # 纯静态检查
    # api.register_lint_rule(fn, solution=True)  # 需要工作点时：fn(circuit, solution)
    # api.register_block("name", factory)        # 新的子电路块（可不用）
    api.log("注册了 xxx")
```

前端 `ui.js` 必须 `export function activate(api)`，api 只有：

```js
export function activate(api) {
  api.registerSidebarPanel({
    id: 'my-panel',            // 只用 a-z 0-9 -
    icon: '🔧',                // 一个 emoji
    title: '面板标题',
    render(box) {              // box 是 DOM 元素，直接写 innerHTML
      box.innerHTML = '<div style="padding:8px">内容</div>';
    },
  });
  // api.registerCommand({id:'x', label:'...', hint:'', run(){}});  // 可选
  api.log('已激活');
}
```

## 硬性要求

- `Issue` 的 level 只能是 `"error"` / `"warn"` / `"info"`
- 插件 id 只允许小写字母、数字、连字符，如 `cap-voltage-margin`
- **不要** import 除 `ccl.lint` / `math` 之外的东西；不要读写文件；不要联网
- 检查规则里**不许编造数据**：算不出来就不报（return []），或报 info 说明测不到
- 代码里所有中文注释都要保留，风格与项目一致（具体、说明"为什么"）

## 输出格式（严格遵守）

只输出一个 JSON 对象，不要 markdown 围栏之外的任何解释：

```json
{
  "id": "cap-voltage-margin",
  "name": "电容耐压余量检查",
  "description": "一句话说明插件作用",
  "backend_py": "完整的 backend.py 源码字符串",
  "ui_js": "完整的 ui.js 源码字符串"
}
```

`backend_py` 和 `ui_js` 的值必须是**完整的、可直接写入文件的源码**（用 \\n 表示换行）。
如果这个需求不适合做成插件，输出 {"error": "原因"}。
"""

FEWSHOT = """示例需求：检查电阻功耗是否超过额定值的一半

示例输出：
{"id":"res-power-margin","name":"电阻功耗余量","description":"电阻实际功耗超过额定一半时给出提醒","backend_py":"from ccl.lint import Issue\\n\\nRATED = 0.25  # 默认按 1/4W 贴片\\n\\n\\ndef check_resistor_margin(circuit, solution):\\n    out = []\\n    for c in circuit.components:\\n        if (c.kind or '').upper() != 'R':\\n            continue\\n        v = solution.v(c.nodes()[0])\\n        out.append(Issue('info', f'{c.ref} 功耗检查', '占位', c.ref, 'plugin.res_power'))\\n    return out\\n\\n\\ndef register(api):\\n    api.register_lint_rule(check_resistor_margin, solution=True)\\n    api.log('已注册电阻功耗余量检查')\\n","ui_js":"export function activate(api) {\\n  api.registerSidebarPanel({\\n    id: 'res-power',\\n    icon: '🔥',\\n    title: '电阻功耗',\\n    render(box) {\\n      box.innerHTML = '<div style=\\"padding:8px\\">电阻超过额定一半会在「问题」里提示</div>';\\n    },\\n  });\\n  api.log('已激活');\\n}\\n"}
"""


def _extract_json(text: str) -> dict:
    """模型可能带 markdown 围栏或前后废话，尽量把 JSON 抠出来。"""
    t = (text or "").strip()
    if not t:
        raise ValueError("模型返回空内容")
    # 去掉 ```json ... ```
    m = re.search(r"```(?:json)?\s*(.+?)```", t, re.S)
    if m:
        t = m.group(1).strip()
    try:
        return json.loads(t)
    except Exception:
        pass
    # 兜底：取第一个 { 到最后一个 }
    i, j = t.find("{"), t.rfind("}")
    if i >= 0 and j > i:
        return json.loads(t[i:j + 1])
    raise ValueError("模型返回里找不到 JSON")


# ---------------------------------------------------------------------------
# 验证：三道闸门
# ---------------------------------------------------------------------------

def _dry_run_backend(src: str, pid: str) -> dict:
    """在**独立子进程**里试跑 backend.py 的 register(api)。

    用子进程而不是 import 到当前进程，是因为插件是可信代码这一前提在这里不成立
    ——AI 刚生成的代码，我们连它会不会 os.system 都不知道。
    """
    probe = '''
import json, sys, types, builtins
SRC = %r
class Stub:
    def __init__(self):
        self.calls = []
        self.logs = []
        self.fns = []          # 保存函数本体，稍后用真实电路调用一遍
    def register_lint_rule(self, fn, solution=False):
        self.calls.append(("lint_rule", getattr(fn, "__name__", "?"), bool(solution)))
        self.fns.append((getattr(fn, "__name__", "?"), fn, bool(solution)))
    def register_block(self, name, factory):
        self.calls.append(("block", name, callable(factory)))
    def log(self, msg):
        self.logs.append(str(msg))

ns = {"__name__": "ccl_plugin_probe", "__builtins__": builtins}
try:
    exec(compile(SRC, "<plugin>", "exec"), ns)
except Exception as e:
    print(json.dumps({"ok": False, "stage": "exec", "error": f"{type(e).__name__}: {e}"}))
    sys.exit(0)

reg = ns.get("register")
if not callable(reg):
    print(json.dumps({"ok": False, "stage": "missing_register",
                      "error": "backend.py 没有定义 register(api)"}))
    sys.exit(0)
api = Stub()
try:
    reg(api)
except Exception as e:
    print(json.dumps({"ok": False, "stage": "register",
                      "error": f"{type(e).__name__}: {e}"}))
    sys.exit(0)

# --- 关键：真的把每条规则跑一遍 ---
# 只调 register 是不够的：规则函数体里的 bug（把 float 当 str、除零、
# 读不存在的属性…）在 register 阶段完全不暴露。这里用一个带 R 和 C 的
# 真实小电路，同时准备 op 解，把每条规则都调用一次。
try:
    from ccl import Circuit, GND
    tc = Circuit("plugin_smoke")
    tc.V("v", GND, dc=10)
    tc.R("v", "m", 1e3)
    tc.C("m", GND, 100e-9)
    sol = tc.op()
except Exception as e:
    print(json.dumps({"ok": True, "calls": api.calls, "logs": api.logs,
                      "smoke": {"skipped": f"无法构建测试电路：{type(e).__name__}: {e}"}}))
    sys.exit(0)

smoke = []
for nm, fn, needs_sol in api.fns:
    try:
        r = fn(tc, sol) if needs_sol else fn(tc)
        if r is not None and not isinstance(r, (list, tuple)):
            smoke.append({"fn": nm, "ok": False,
                          "error": f"返回值应是 list[Issue]，实际 {type(r).__name__}"})
        else:
            smoke.append({"fn": nm, "ok": True, "issues": len(r or [])})
    except Exception as e:
        smoke.append({"fn": nm, "ok": False, "error": f"{type(e).__name__}: {e}"})

print(json.dumps({"ok": True, "calls": api.calls, "logs": api.logs, "smoke": smoke}))
''' % (src,)

    try:
        r = subprocess.run(
            [sys.executable, "-c", probe],
            cwd=ROOT, capture_output=True, text=True, timeout=12,
            env={**os.environ, "PYTHONPATH": ROOT},
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "stage": "timeout", "error": "干跑超过 12 秒（可能有死循环或联网）"}

    out = (r.stdout or "").strip().splitlines()
    for line in reversed(out):
        try:
            return json.loads(line)
        except Exception:
            continue
    return {"ok": False, "stage": "crash",
            "error": (r.stderr or r.stdout or "无输出").strip()[:400]}


def _node_check(js: str) -> dict:
    """用 node --check 校验 JS 语法。没有 node 就跳过（不假装通过）。"""
    with tempfile.NamedTemporaryFile("w", suffix=".mjs", delete=False, encoding="utf-8") as f:
        f.write(js)
        tmp = f.name
    try:
        r = subprocess.run(["node", "--check", tmp], capture_output=True, text=True, timeout=12)
        if r.returncode == 0:
            return {"ok": True}
        return {"ok": False, "error": (r.stderr or "").strip()[:300]}
    except FileNotFoundError:
        return {"ok": True, "skipped": "环境没有 node，未做语法检查"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "node --check 超时"}
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def validate(d: dict) -> dict:
    """对 AI 草稿做完整校验，返回 {ok, checks:[...], ...}。"""
    checks = []

    def add(name, ok, detail="", hard=True):
        """hard=False 的项只作提示，不参与总体判定（例如"目录是否已存在"）。"""
        checks.append({"name": name, "ok": bool(ok), "detail": detail, "hard": hard})
        return ok

    pid = (d.get("id") or "").strip()
    name = (d.get("name") or "").strip()
    desc = (d.get("description") or "").strip()
    be = d.get("backend_py") or ""
    ui = d.get("ui_js") or ""

    if not add("插件 id 合法", bool(ID_RE.match(pid)),
               f"id={pid!r}（只允许小写字母/数字/连字符，≤32 字符）"):
        return {"ok": False, "checks": checks}
    if not add("有名称", bool(name), name):
        return {"ok": False, "checks": checks}
    if not add("有 backend.py", bool(be.strip()), f"{len(be)} 字符"):
        return {"ok": False, "checks": checks}

    # 1) Python 语法
    try:
        ast.parse(be)
        add("backend.py 语法", True)
    except SyntaxError as e:
        add("backend.py 语法", False, f"第 {e.lineno} 行：{e.msg}")
        return {"ok": False, "checks": checks}

    # 2) JS 语法（有 node 才查，没有就标"跳过"而不是"通过"）
    if ui.strip():
        nc = _node_check(ui)
        add("ui.js 语法", nc.get("ok"), nc.get("error") or nc.get("skipped") or "")
        if not nc.get("ok"):
            return {"ok": False, "checks": checks}
    else:
        add("ui.js", True, "（没有前端部分）")

    # 3) 子进程干跑 register(api)
    dr = _dry_run_backend(be, pid)
    if not dr.get("ok"):
        add("子进程干跑 register(api)", False,
            f"[{dr.get('stage')}] {dr.get('error')}")
        return {"ok": False, "checks": checks}
    calls = dr.get("calls") or []
    add("子进程干跑 register(api)", True,
        "注册：" + (", ".join(f"{c[0]}({c[1]})" for c in calls) or "什么都没注册"))
    if not calls:
        add("至少注册了一样东西", False, "插件没有 register 任何规则或块，装上也没作用")
        return {"ok": False, "checks": checks}

    # 4) 规则函数在真实小电路上真的能跑（只 register 不调用是查不出 bug 的）
    smoke = dr.get("smoke")
    if isinstance(smoke, dict) and smoke.get("skipped"):
        add("规则实际执行", True, "跳过：" + str(smoke["skipped"]))
    elif isinstance(smoke, list) and smoke:
        bad = [x for x in smoke if not x.get("ok")]
        if bad:
            add("规则实际执行", False,
                "；".join(f"{x['fn']}: {x['error']}" for x in bad[:2]))
            return {"ok": False, "checks": checks}
        add("规则实际执行", True,
            "；".join(f"{x['fn']} → {x.get('issues', 0)} 条" for x in smoke))
    else:
        add("规则实际执行", True, "无静态规则需要试跑")

    # 4) 目录是否已存在
    target = os.path.join(PLUGIN_DIR, pid)
    add("目录未被占用", not os.path.exists(target),
        "已存在同名插件，安装会被拒绝" if os.path.exists(target) else "可写入",
        hard=False)

    return {
        "ok": all(c["ok"] for c in checks if c.get("hard", True)),
        "checks": checks,
        "registrations": calls,
        "logs": dr.get("logs") or [],
        "target": target,
    }


# ---------------------------------------------------------------------------
# 生成
# ---------------------------------------------------------------------------

def draft(request: str, *, llm=None, model: str | None = None,
          strict: bool = False) -> Draft:
    """让模型生成一个插件草稿，并做完整校验。**不落盘。**"""
    t0 = time.perf_counter()
    d = Draft()

    try:
        if llm is None:
            from copilot.llm import LLM, load_config
            cfg = load_config()
            llm = LLM()
            d.model = model or cfg.get("model", "")
        else:
            d.model = model or getattr(llm, "model", "")
    except ImportError as e:
        d.error = f"无法加载 copilot.llm（{e}）；AI 插件生成不可用，核心库不受影响"
        d.elapsed_ms = (time.perf_counter() - t0) * 1000
        if strict:
            raise
        return d

    try:
        if not bool(llm.available()):
            d.error = "未配置 API Key，无法使用 AI 生成插件"
            d.elapsed_ms = (time.perf_counter() - t0) * 1000
            return d
    except Exception:
        d.error = "模型不可用"
        d.elapsed_ms = (time.perf_counter() - t0) * 1000
        return d

    try:
        raw = llm.chat(
            [{"role": "system", "content": SYSTEM},
             {"role": "user", "content": FEWSHOT + "\n\n现在请为这个需求生成插件：" + request}],
            max_tokens=2600,
        )
    except Exception as e:
        d.error = f"模型调用失败：{type(e).__name__}: {e}"
        d.elapsed_ms = (time.perf_counter() - t0) * 1000
        return d

    try:
        obj = _extract_json(raw)
    except Exception as e:
        d.error = f"模型输出无法解析为 JSON：{e}"
        d.raw = raw[:800]
        d.elapsed_ms = (time.perf_counter() - t0) * 1000
        return d

    if obj.get("error"):
        d.error = str(obj["error"])
        d.elapsed_ms = (time.perf_counter() - t0) * 1000
        return d

    d.id = (obj.get("id") or "").strip()
    d.name = (obj.get("name") or "").strip()
    d.description = (obj.get("description") or "").strip()
    d.backend_py = obj.get("backend_py") or ""
    d.ui_js = obj.get("ui_js") or ""

    # 清单由**我们**生成，不采信模型给的 JSON 字符串（少一个出错点）
    d.plugin_json = json.dumps({
        "id": d.id, "name": d.name, "version": "1.0.0",
        "description": d.description, "author": "AI 生成（已通过校验）",
        "backend": "backend.py",
        **({"ui": "ui.js"} if d.ui_js.strip() else {}),
    }, ensure_ascii=False, indent=2)

    d.validation = validate(d.to_dict())
    d.ok = bool(d.validation.get("ok"))
    if not d.ok:
        bad = [c for c in d.validation.get("checks", []) if not c["ok"]]
        d.error = "校验未通过：" + "；".join(f"{c['name']}（{c['detail']}）" for c in bad[:3])

    d.elapsed_ms = (time.perf_counter() - t0) * 1000
    return d


def install(*, pid: str, plugin_json: str, backend_py: str, ui_js: str,
            force: bool = False) -> dict:
    """把校验过的插件写进 plugins/<id>/。拒绝非法 id / 拒绝覆盖已有目录。"""
    pid = (pid or "").strip()
    if not ID_RE.match(pid):
        return {"ok": False, "error": f"插件 id 非法：{pid!r}"}

    # 再校一遍：前端传回的内容也可能被改过，不能只信"生成时校验过"。
    # 语法 + 危险构造双重检查（backend 会被启动 import，语法合法≠无害）。
    _bad = check_backend_source(backend_py)
    if _bad:
        return {"ok": False, "error": "backend.py 含被禁止的构造：" + "；".join(_bad[:3])}
    try:
        man = json.loads(plugin_json)
    except Exception as e:
        return {"ok": False, "error": f"plugin.json 不是合法 JSON：{e}"}
    if (man.get("id") or "") != pid:
        return {"ok": False, "error": "plugin.json 里的 id 与请求不一致"}

    target = os.path.join(PLUGIN_DIR, pid)
    base = os.path.abspath(PLUGIN_DIR)
    if not os.path.abspath(target).startswith(base + os.sep):
        return {"ok": False, "error": "目标路径越界"}
    if os.path.exists(target) and not force:
        return {"ok": False, "error": f"插件目录已存在：{os.path.basename(target)}"}

    try:
        os.makedirs(target, exist_ok=True)
        with open(os.path.join(target, "plugin.json"), "w", encoding="utf-8") as f:
            f.write(plugin_json)
        with open(os.path.join(target, "backend.py"), "w", encoding="utf-8") as f:
            f.write(backend_py)
        if (ui_js or "").strip():
            with open(os.path.join(target, "ui.js"), "w", encoding="utf-8") as f:
                f.write(ui_js)
    except OSError as e:
        return {"ok": False, "error": f"写入失败：{e}"}

    return {"ok": True, "path": target, "id": pid,
            "files": sorted(os.listdir(target))}
