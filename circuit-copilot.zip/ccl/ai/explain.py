"""把电路和仿真结果讲成人话。

## 设计原则

**没有模型也要能讲。** 核心库不依赖 AI，所以 `explain()` 有两层：

1. **模板层**（`_offline_explain`）：纯确定性，从元件值和仿真数字里生成中文说明。
   不是"抱歉，请配置 API Key"，而是真的把电路讲清楚——元件怎么定的、
   实测指标是多少、和理论值差在哪。没有 Key 时这是**可用**的输出。
2. **模型层**：有 Key 时让模型润色并补充设计权衡。模型输出**必须包含实测数字**，
   否则丢弃（防编造）。

所以 `explain()` 永远返回有内容的中文，不会因为网络问题变成空字符串。
"""

from __future__ import annotations

import math

from . import prompts

__all__ = ["explain"]


# --------------------------------------------------------------------------
# 模板层：确定性中文解释
# --------------------------------------------------------------------------

def _fmt_si(v: float, unit: str) -> str:
    """SI 前缀格式化，报告里读起来比 1.6e+03 舒服。"""
    if v is None or not isinstance(v, (int, float)) or not math.isfinite(v):
        return f"{v}{unit}"
    for factor, pre in ((1e9, "G"), (1e6, "M"), (1e3, "k"), (1.0, ""),
                        (1e-3, "m"), (1e-6, "µ"), (1e-9, "n"), (1e-12, "p")):
        if abs(v) >= factor * 0.999:
            return f"{v / factor:.3g}{pre}{unit}"
    return f"{v:.3g}{unit}"


def _component_lines(circuit) -> list[str]:
    """每个器件一行：位号、值、接法、在电路里的作用（能推断时才说）。"""
    out = []
    for c in circuit.components:
        nodes = c.nodes()
        kind = c.kind.upper()
        if kind == "R":
            val = _fmt_si(c.value, "Ω")
            role = "接在信号路径上（限流/设定增益）" if "0" not in nodes else "接到地（分压/下拉）"
        elif kind == "C":
            val = _fmt_si(c.value, "F")
            role = "串在信号路径上（隔直/耦合）" if "0" not in nodes else "接到地（滤波/旁路）"
        elif kind == "L":
            val = _fmt_si(c.value, "H")
            role = "串在信号路径上（滤波/储能）"
        elif kind == "V":
            val = f"dc={getattr(c, 'dc', 0):g} ac={getattr(c, 'ac', 0):g}"
            role = "AC 激励源"
        elif kind == "I":
            val = f"dc={getattr(c, 'dc', 0):g} ac={getattr(c, 'ac', 0):g}"
            role = "AC 激励源"
        elif kind == "X":
            gbw = getattr(c, "gbw", None)      # 运放 gbw 是属性，不是 params
            val = f"GBW={_fmt_si(gbw, 'Hz')}" if isinstance(gbw, (int, float)) else "运放"
            role = "运放（单极点宏模型）"
        else:
            val = str(c.value)
            role = ""
        conn = " — ".join(nodes)
        out.append(f"- {c.ref}（{c.kind}）{conn}：{val}" + (f"，{role}" if role else ""))
    return out


def _theoretical(circuit) -> list[str]:
    """能算的理论值：RC/RL 特征频率、电阻分压比、同相/反相增益。

    只算能确定算的，算不准的不提。这是"实测 vs 理论"里的理论那一半。
    """
    out = []
    rs = [c for c in circuit.components if c.kind.upper() == "R"]
    cs = [c for c in circuit.components if c.kind.upper() == "C"]
    ops = [c for c in circuit.components if c.kind.upper() == "X"]

    if len(rs) == 1 and len(cs) == 1 and not ops:
        f = 1.0 / (2 * math.pi * rs[0].value * cs[0].value)
        out.append(
            f"这是单极点 RC 网络：特征频率 1/(2πRC) = 1/(2π·{_fmt_si(rs[0].value,'Ω')}·"
            f"{_fmt_si(cs[0].value,'F')}) = {_fmt_si(f,'Hz')}。"
            f"无源 RC 的 Q 恒为 0.5，所以 -3dB 点就是特征频率，滚降固定 −20dB/十倍频"
        )

    if ops:
        # 同相：R 从 out 到 sum、sum 到地，运放 inn 接 sum
        op = ops[0]
        inp_n, inn_n, out_n = (op.pins[0].node, op.pins[1].node, op.pins[2].node)
        r_fb = next((r for r in rs if out_n in r.nodes() and inn_n in r.nodes()), None)
        r_gnd = next((r for r in rs if inn_n in r.nodes() and "0" in r.nodes()), None)
        if r_fb and r_gnd:
            g = 1 + r_fb.value / r_gnd.value
            gbw = getattr(op, "gbw", None)
            txt = (f"这是同相放大结构：增益 = 1 + R_fb/R_gnd = 1 + "
                   f"{_fmt_si(r_fb.value,'Ω')}/{_fmt_si(r_gnd.value,'Ω')} = {g:.3g} 倍"
                   f"（{20*math.log10(g):.1f}dB）")
            if isinstance(gbw, (int, float)) and gbw > 0:
                txt += f"；闭环带宽 ≈ GBW/增益 = {_fmt_si(gbw,'Hz')}/{g:.3g} = {_fmt_si(gbw/g,'Hz')}"
            out.append(txt)
        # 反相：R 从 in 到 sum、R 从 out 到 sum
        r_in = next((r for r in rs if out_n not in r.nodes() and inn_n in r.nodes()
                     and "0" not in r.nodes()), None)
        if r_in and r_fb:
            g = -r_fb.value / r_in.value
            out.append(f"这是反相放大结构：增益 = −R_fb/R_in = −"
                       f"{_fmt_si(r_fb.value,'Ω')}/{_fmt_si(r_in.value,'Ω')} = {g:.3g} 倍"
                       f"（|{20*math.log10(abs(g)):.1f}|dB）")
    return out


def _measured(circuit, solution) -> list[str]:
    """实测数字 + 与理论的偏差。偏差只在与理论同口径时才给。"""
    if solution is None:
        return []
    out = []
    nodes = [n for n in solution.node_names() if not n.startswith("i(")]
    if not nodes:
        return []
    target = "out" if "out" in nodes else nodes[-1]
    try:
        if solution.kind == "ac":
            g_db = solution.gain_db(target)
            g_lin = 10 ** (g_db / 20.0)
            f3 = solution.f3db(target)
            peak = solution.peak_db(target)
            seg = f"实测（AC 扫频）：低频增益 {g_db:.2f}dB = {g_lin:.4g} 倍"
            if f3:
                seg += f"，−3dB 频率 {_fmt_si(f3,'Hz')}"
            if peak - g_db > 0.5:
                seg += f"，通带峰值 {peak:.2f}dB（比低频高 {peak-g_db:.2f}dB，说明有峰化）"
            out.append(seg)
        elif solution.kind == "op":
            vals = []
            for n in nodes[:6]:
                try:
                    vals.append(f"V({n})={solution.value_at(n,0.0):.4g}V")
                except Exception:
                    pass
            if vals:
                out.append("实测（直流工作点）：" + "，".join(vals))
        elif solution.kind == "tran":
            out.append(f"实测（瞬态）：{len(solution.x)} 个时间点，"
                       f"t={solution.x[0]:.4g}~{solution.x[-1]:.4g}s")
    except Exception:
        return out
    return out


def _offline_explain(circuit, solution) -> str:
    parts: list[str] = []
    n_comp = len(circuit.components)
    n_node = len(circuit.nets())
    parts.append(f"## 电路 {getattr(circuit,'name','')!r}")
    parts.append(f"{n_comp} 个器件、{n_node} 个节点。")

    theo = _theoretical(circuit)
    if theo:
        parts.append("\n### 它是什么\n" + "\n".join(theo))

    parts.append("\n### 元件\n" + "\n".join(_component_lines(circuit)))

    meas = _measured(circuit, solution)
    if meas:
        parts.append("\n### 实测\n" + "\n".join(meas))
        # 实测 vs 理论：只有口径明确时才对比
        try:
            if solution is not None and solution.kind == "ac" and theo:
                nodes = [n for n in solution.node_names() if not n.startswith("i(")]
                target = "out" if "out" in nodes else (nodes[-1] if nodes else None)
                if target:
                    f3 = solution.f3db(target)
                    rs = [c for c in circuit.components if c.kind.upper() == "R"]
                    cs = [c for c in circuit.components if c.kind.upper() == "C"]
                    ops = [c for c in circuit.components if c.kind.upper() == "X"]
                    if f3 and len(rs) == 1 and len(cs) == 1 and not ops:
                        th = 1 / (2 * math.pi * rs[0].value * cs[0].value)
                        err = (f3 - th) / th * 100
                        parts.append(
                            f"\n### 实测 vs 理论\n−3dB 理论 {_fmt_si(th,'Hz')}，"
                            f"实测 {_fmt_si(f3,'Hz')}，偏差 {err:+.2f}%"
                            + ("（在插值误差范围内）" if abs(err) < 2 else "（需要检查）")
                        )
        except Exception:
            pass
    else:
        parts.append("\n（没有仿真结果：只讲结构，不报实测指标）")

    return "\n".join(parts)


# --------------------------------------------------------------------------
# 模型层
# --------------------------------------------------------------------------

def _payload(circuit, solution) -> str:
    import json

    data = {
        "电路名": getattr(circuit, "name", ""),
        "器件": [
            {"位号": c.ref, "类型": c.kind,
             "值": c.value if isinstance(c.value, (int, float)) else str(c.value),
             "端子": dict(zip([p.name for p in c.pins], c.nodes())),
             "参数": c.params}
            for c in circuit.components
        ],
    }
    if solution is not None:
        nodes = [n for n in solution.node_names() if not n.startswith("i(")]
        target = "out" if "out" in nodes else (nodes[-1] if nodes else None)
        if target:
            try:
                m = {"分析": solution.kind, "节点": target,
                     "低频增益_dB": round(solution.gain_db(target), 2)}
                if solution.kind == "ac":
                    f3 = solution.f3db(target)
                    if f3:
                        m["-3dB_Hz"] = round(f3, 2)
                    m["峰值_dB"] = round(solution.peak_db(target), 2)
                if solution.kind == "op":
                    m["直流"] = {n: round(solution.value_at(n, 0.0), 4)
                                 for n in nodes[:6]}
                data["仿真"] = m
            except Exception:
                pass
    return json.dumps(data, ensure_ascii=False, indent=2)


def _has_numbers(text: str) -> bool:
    """模型输出必须含数字，否则判定为"没看数据瞎写"，丢弃。"""
    import re

    return bool(re.search(r"\d", text or ""))


def explain(circuit, solution=None, *, model: str | None = None, _llm=None) -> str:
    """中文解释这个电路在做什么、元件怎么定的、实测如何。

    没有 API Key 时返回确定性的模板解释（**不是空字符串**），
    有 Key 时用模型润色；模型输出不含数字则丢弃，退回模板。

    参数
        circuit    ccl.Circuit
        solution   ccl.Solution（可选；没有就只讲结构）
        model      覆盖模型名
    """
    baseline = _offline_explain(circuit, solution)

    try:
        if _llm is not None:
            llm = _llm
        else:
            from copilot.llm import LLM

            llm = LLM()
            if not llm.available():
                return baseline
        if model:
            try:
                llm.model = model
            except Exception:
                pass

        raw = llm.chat(
            prompts.explain_prompt(_payload(circuit, solution)),
            temperature=0.35, max_tokens=900,
        )
        text = (raw or "").strip()
        # 防编造：模型必须真的引用了数字，否则退回确定性版本
        if not text or not _has_numbers(text):
            return baseline
        return text
    except Exception:
        return baseline
