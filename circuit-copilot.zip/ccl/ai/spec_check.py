"""生成结果的指标核对：代码跑通 ≠ 满足了需求。

## 为什么必须有这一层（实测踩到）

需求「二阶低通，截止 10kHz，Q=0.707」，模型生成的代码语法完全正确、
仿真也成功，但实测 f3db = 4170Hz —— 差 58%。
而 generate() 在那一刻返回 `ok=True`。

这是本类工具最危险的失败模式：**看起来成功、实际错得离谱**。
只检查「exec 成功 + 仿真收敛」是不够的，还必须把用户明确提出的数从
prompt 里抽出来，与仿真实测值对账；对不上就当失败，进入修复循环。

这一层刻意做成**纯确定性**（正则 + 数值比较），不依赖大模型——
用模型去判断模型自己的输出是否达标，等于没有约束。
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass

_SI = {"p": 1e-12, "n": 1e-9, "u": 1e-6, "µ": 1e-6, "m": 1e-3,
       "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9}


def _num(tok: str) -> float:
    m = re.match(r"([-+]?\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)", tok.strip())
    if not m:
        return float("nan")
    return float(m.group(1)) * _SI.get(m.group(2), 1.0)


@dataclass
class Target:
    key: str          # "fc" | "f0" | "gain_lin" | "gain_db" | "q" | "bw"
    value: float
    raw: str          # 原文片段，用于报错时回溯
    # 方向语义： "eq" 约等于（默认）/ "min" 不低于（以上、至少）/ "max" 不高于（以下、以内）
    #
    # 为什么必须有这个字段：需求写「带宽 100kHz 以上」时，实测 997kHz 是**完全合格**的，
    # 但当成「约等于 100kHz」就会算出 897% 偏差、判失败，还逼着模型把它改小到
    # 99.75kHz —— 反而变成了不达标。这是实测踩到的真事故。
    bound: str = "eq"
    #: 电压类目标专用：需求里给出的输入电压（伏）。
    #: 「把 12V 分压到 3.3V」→ value=3.3、vin=12。测量时用 |Vo/Vs|×vin 还原绝对电压，
    #: 因为代码路径的激励是 ac=1，直接读节点电压得到的是「增益」不是「伏特」。
    vin: float | None = None

    def label(self) -> str:
        base = {"fc": "截止频率", "f0": "中心频率", "gain_lin": "增益(倍)",
                "gain_db": "增益(dB)", "q": "品质因数 Q", "bw": "带宽",
                "vout": "输出电压"}.get(self.key, self.key)
        if self.bound == "min":
            return base + "下限"
        if self.bound == "max":
            return base + "上限"
        return base


@dataclass
class Miss:
    target: Target
    actual: float

    @property
    def rel_err(self) -> float:
        """偏差量。方向语义下，只在**越过边界**时才算偏差。

        - "eq"   : |实测 − 目标| / 目标
        - "min"  : 实测 >= 目标 → 0（合格）；低于目标才按差距算
        - "max"  : 实测 <= 目标 → 0（合格）；高于目标才按差距算
        """
        if self.actual is None or (isinstance(self.actual, float) and math.isnan(self.actual)):
            return float("inf")
        if self.target.key in ("gain_db",):
            d = self.actual - self.target.value
            if self.target.bound == "min":
                return 0.0 if d >= 0 else -d
            if self.target.bound == "max":
                return 0.0 if d <= 0 else d
            return abs(d)
        scale = max(abs(self.target.value), 1e-12)
        d = self.actual - self.target.value
        if self.target.bound == "min":
            return 0.0 if d >= 0 else -d / scale
        if self.target.bound == "max":
            return 0.0 if d <= 0 else d / scale
        return abs(d) / scale

    def message(self) -> str:
        a = "测不到" if not math.isfinite(self.actual) else f"{self.actual:.4g}"
        b = self.target.bound
        if b == "min":
            head = f"{self.target.label()}要求 ≥ {self.target.value:.4g}"
        elif b == "max":
            head = f"{self.target.label()}要求 ≤ {self.target.value:.4g}"
        else:
            head = f"{self.target.label()}要求 {self.target.value:.4g}"
        return f"{head}，实测 {a}（偏差 {self.rel_err * 100:.1f}%）"


# 各项的容差：频率/增益 10%，Q 15%，dB 0.8dB
_TOL = {"fc": 0.10, "f0": 0.10, "bw": 0.15, "q": 0.15,
        "gain_lin": 0.10, "gain_db": 0.8}

# 方向性目标（"以上"/"以下"）的容差。下限/上限是硬边界，不能给 15%。
_BOUND_TOL = 0.02


# 「以上 / 至少 / 不低于」→ min（下限）；「以下 / 不超过」→ max（上限）
_MIN_WORDS = ("以上", "不低于", "不少于", "不小于", "不短于", "至少", "最少",
              "大于", "高于", "超过", ">=", "≥")
_MAX_WORDS = ("以下", "不高于", "不超过", "最多", "小于", "低于", "短于", "<=", "≤", "以内")
#: ⚑ 判定顺序与「子串陷阱」：`_MAX_WORDS` 里有「小于」，而「**不**小于」是下限。
#: 早先只是 `any(w in chunk)` 顺序扫，于是「带宽不小于 20kHz」被判成**上限**，
#: 实测「要求 ≥20kHz、交 1kHz」竟然判成功 —— 下限变上限，方向反了。
#: 现在先把所有方向词按**长度降序**替换成占位符（长词优先，否定型先吃掉自己的子串），
#: 再根据占位符决定方向。

# 子句分隔符：方向词只在**同一个子句**内生效。
# 不加这个限制会出真事故：「增益至少 20 倍，截止频率不超过 5kHz」里，
# 增益那段的"后面窗口"会框进下一个子句的「不超过」，把"至少"盖掉，
# 于是下限被判成上限 —— 方向完全反了。
_CLAUSE_SEP = "，,。;；、\n"


def _clause_around(t: str, start: int, end: int) -> tuple[str, str]:
    """取这个数值所在子句的（前文，后文），遇到分隔符就截断。"""
    i = start - 1
    while i >= 0 and t[i] not in _CLAUSE_SEP:
        i -= 1
    before = t[i + 1:start]
    j = end
    while j < len(t) and t[j] not in _CLAUSE_SEP:
        j += 1
    after = t[end:j]
    return before, after


def _bound(t: str, start: int, end: int) -> str:
    """判断这个数值是下限、上限还是约等于。

    中文的方向词**两边都可能出现**：

    - 「100kHz **以上**」「带宽 **至少** 100kHz」→ 词在后面
    - 「**至少** 20 倍」「**不超过** 5kHz」       → 词在前面

    所以前后都要看，但**只在同一子句内**看（见 `_CLAUSE_SEP` 的注释）。
    """
    before, after = _clause_around(t, start, end)
    # 三段都要查：匹配原文本身、后文、前文。
    #
    # 为什么必须查匹配原文：正则的 `[^0-9]{0,6}` 会把方向词一起吞进匹配里
    # ——「截止频率不超过 5kHz」的匹配原文就是这整串，"不超过"落在 gap 中，
    # 而 before/after 都是空串，只看前后会把方向判成"约等于"。
    for chunk in (t[start:end], after, before):
        d = _direction_of(chunk)
        if d != "eq":
            return d
    return "eq"


def _direction_of(chunk: str) -> str:
    """子句里的方向：min（下限）/ max（上限）/ eq（约等于）。

    按词长降序替换成占位符，保证「不小于」先在「小于」之前被吃掉。
    """
    c = chunk
    for w in sorted(set(_MIN_WORDS) | set(_MAX_WORDS), key=len, reverse=True):
        if w in c:
            c = c.replace(w, "\x01MIN\x01" if w in _MIN_WORDS else "\x01MAX\x01")
    has_min = "\x01MIN\x01" in c
    has_max = "\x01MAX\x01" in c
    if has_min and not has_max:
        return "min"
    if has_max and not has_min:
        return "max"
    if has_min and has_max:
        # 同时出现时以**离数字更近的那个**为准；这里退化为保守的 min（下限更常见于硬指标）
        return "min"
    return "eq"


def parse_targets(prompt: str) -> list[Target]:
    """从需求文本里抽出用户明确提出的指标。抽不到就不抽，绝不猜。

    关键：**方向词必须保留**。「带宽 100kHz 以上」是下限，
    实测 997kHz 完全合格；当成「约等于 100kHz」就会算出 897% 偏差、
    判失败并把电路改小到 99.75kHz，反而变成真的不达标（实测踩到过）。
    """
    t = prompt.replace("Ｋ", "k")
    out: list[Target] = []

    # 带宽必须**先**解析：否则「带宽 100kHz 以上」会被下面的频率兜底规则
    # 误当成截止频率，凭空多出一条 fc=100kHz 的假目标。
    for m in re.finditer(
        r"(?:带宽|频带|bandwidth)[^0-9]{0,6}(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*(?:hz|赫兹|赫)?",
        t, re.I,
    ):
        out.append(Target("bw", _num(m.group(1) + m.group(2)), m.group(0),
                          _bound(t, m.start(), m.end())))

    # 频率：截止 / 中心 / 转折 + 数值 + Hz
    for m in re.finditer(
        r"(截止|中心|转折|谐振|工作)[^0-9]{0,6}(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*(?:hz|赫兹|赫)",
        t, re.I,
    ):
        kind = "f0" if m.group(1) in ("中心", "谐振") else "fc"
        out.append(Target(kind, _num(m.group(2) + m.group(3)), m.group(0),
                          _bound(t, m.start(), m.end())))

    # 「10kHz 的低通」「在 10kHz」这种没写「截止」但显然是截止频率的。
    # 已有 bw 目标时跳过：那个频率已经被带宽规则认领了。
    if not any(x.key in ("fc", "f0", "bw") for x in out):
        m = re.search(r"(\d+(?:\.\d+)?)\s*([pnuµmkKMG]?)\s*(?:hz|赫兹|赫)", t, re.I)
        if m:
            out.append(Target("fc", _num(m.group(1) + m.group(2)), m.group(0),
                              _bound(t, m.start(), m.end())))

    # 电压类目标（「分压到 3.3V」「输出 5V」「12V 转 3.3V」）。
    #
    # 为什么必须补这一条：实测事故——需求「把 12V 分压到 3.3V，给 STM32 的 ADC 采样」，
    # 模型交了一个 Vout=12V（等于没分压、直通）的电路，而代码路径**没有任何指标对账**
    # （parse_targets 只认 fc/gain/bw/q），于是报 ok=True。用户会拿到一根导线还被告知成功。
    _volt = r"(\d+(?:\.\d+)?)\s*[vV](?![a-zA-Z])"

    def _volts_in(seg: str) -> list[float]:
        return [float(x) for x in re.findall(_volt, seg)]

    def _pick_vin(prefix: str, target: float) -> float | None:
        """从目标值之前的文字里认出**输入电压**。

        ⚑ 这里原来写的是 `vin = max(前面所有电压)`，后果很荒谬：
        「设计一个 3.3V 电源电路，输出 3.3V」→ 产品名里的 3.3V 被当成**输入电压**
        → 一个完全正确的 12V→3.3V 分压被算成「实测 0.9075，偏差 72.5%」判失败；
        换成「把 12V 分压到 3.3V」就 ok=True。**同一个正确答案，成败取决于
        电压写在第几个位置。**

        现在的优先级：
          1) 显式输入标记（「输入 12V」「从 12V」「Vin=12」）—— 最可靠
          2) 目标值之前的电压里，**排除与目标相同的**，取最靠后的一个（紧邻动词）
          3) 都没有 → None（**不猜**，见下面 check 里对 None 的处理）
        """
        m_in = re.search(r"(?:输入|进线|供电|电源|Vin|vin|VIN)\s*(?:为|是|=|:|：)?\s*"
                         + _volt, prefix)
        if m_in:
            return float(m_in.group(1))
        m_from = re.search(r"(?:从|由)\s*" + _volt, prefix)
        if m_from:
            return float(m_from.group(1))
        cands = [v for v in _volts_in(prefix) if abs(v - target) > 1e-12]
        return cands[-1] if cands else None

    # 1) 「把 A 分压/降/转 到 B」：最后一个电压是目标，前面的是输入
    mv = re.search(r"(?:分压|降压|降|转|变|衰减|输出|得到|弄)(?:到|成|为|至|出)?e?"
                   r"?(?:\s*的)?[^0-9]{0,6}?" + _volt, t)
    if mv:
        vout = float(mv.group(1))
        vin = _pick_vin(t[:mv.start()], vout)
        out.append(Target("vout", vout, mv.group(0), _bound(t, mv.start(), mv.end()), vin))
    elif re.search(r"(?:Vout|vout|输出电压)\s*[=＝:：]?\s*" + _volt, t):
        m2 = re.search(r"(?:Vout|vout|输出电压)\s*[=＝:：]?\s*" + _volt, t)
        vout = float(m2.group(1))
        vin = _pick_vin(t, vout)
        out.append(Target("vout", vout, m2.group(0),
                          _bound(t, m2.start(), m2.end()), vin))

    # Q
    m = re.search(r"[Qq]\s*[=＝:：]\s*(\d+(?:\.\d+)?)", t)
    if m:
        out.append(Target("q", float(m.group(1)), m.group(0)))

    # 增益：倍 / dB
    # ⚑ 必须排除「**10 倍截止频率**处衰减 40dB」这种写法 —— 那里的「10 倍」是
    # **频率倍数**（指 10·fc 这个位置），不是增益。早先它被抽成 gain_lin=10 的假目标，
    # 于是模型被逼着把无源低通改成「10 倍增益」，而真正的「衰减 40dB」一个字都没被看到。
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:倍|×)"
                  r"(?!\s*(?:截止|频率|带宽|fc|f0|中心))", t)
    if m:
        out.append(Target("gain_lin", float(m.group(1)), m.group(0),
                          _bound(t, m.start(), m.end())))
    else:
        m = re.search(r"增益[^0-9]{0,4}(\d+(?:\.\d+)?)\s*db", t, re.I)
        if m:
            out.append(Target("gain_db", float(m.group(1)), m.group(0),
                              _bound(t, m.start(), m.end())))

    return out


class Unmeasurable(RuntimeError):
    """**测不了**（不是"达标"）。用于把「取不到数据」与「全部通过」彻底分开。

    这个异常的存在是为了修一类致命缺陷：`check_targets` 原来用同一个 `[]`
    表示三种完全不同的情况——「没抽到目标」「全部达标」「**测不到**」。
    调用方把它们一律读成"没问题"，于是：
      · 沙箱被污染、`ac()` 返回 None → `[]` → 产品宣称成功
      · 退化电路没有输出节点 → `[]` → 宣称成功
      · 核对器自己抛异常 → `[]` → 宣称成功
    三者都是「拿不到证据就判无罪」，与本项目铁律完全相反。
    """


def check_targets_strict(targets: list[Target], solution, node: str = "out",
                         circuit=None) -> list[Miss]:
    """严格版对账：**测不到就抛 Unmeasurable**，绝不用 `[]` 冒充"全达标"。

    调用方（generate）必须把 Unmeasurable 当**失败**处理，而不是跳过。
    """
    if not targets:
        return []                        # 没有目标 → 真的没什么要对账
    if solution is None:
        raise Unmeasurable("这次没有拿到仿真结果（solution 为空），无法对账")
    try:
        names = solution.node_names()
    except Exception as e:
        raise Unmeasurable(f"读不出仿真结果里的节点（{type(e).__name__}: {e}）") from None
    if not names:
        raise Unmeasurable("仿真结果里没有任何节点，无法对账")
    if node not in names:
        cand = [n for n in names if not n.startswith("i(") and n != "in"]
        if not cand:
            raise Unmeasurable(f"电路里没有可测的输出节点（只有 {names}）")
        node = cand[-1]
    return _check(targets, solution, node, circuit)


def check_targets(targets: list[Target], solution, node: str = "out",
                  circuit=None) -> list[Miss]:
    """把目标与仿真实测值对账。返回不达标项；空列表表示全部达标。

    ⚠ 兼容旧签名：`solution is None` 时仍返回 `[]`（老调用方按"没数据=没问题"读）。
    **新代码请用 `check_targets_strict`**，它把"测不到"变成显式异常。
    """
    try:
        return check_targets_strict(targets, solution, node, circuit)
    except Unmeasurable:
        return []


def _check(targets: list[Target], solution, node: str, circuit) -> list[Miss]:
    misses: list[Miss] = []
    for tg in targets:
        # ⚑ 电压类目标缺输入电压 → 直接抛出（**必须在 try 之外**，
        # 否则会被下面那个 `except Exception: actual = nan` 吞掉，
        # 又变回"测不到但当达标"）。
        if tg.key == "vout" and tg.vin is None:
            raise Unmeasurable(
                f"需求里只写了「{tg.label()} = {tg.value:g}」，没写输入电压，"
                f"无法把仿真结果还原成绝对电压来对账"
                f"（请写成「把 12V 分压到 3.3V」这样）")

        actual = float("nan")
        try:
            if tg.key in ("fc", "f0"):
                actual = solution.f3db(node)
                if actual is None:
                    actual = float("nan")
            elif tg.key == "gain_lin":
                g = solution.value_at(node, _f_low(solution))
                actual = abs(g)
            elif tg.key == "gain_db":
                g = solution.value_at(node, _f_low(solution))
                actual = 20 * math.log10(abs(g)) if g else float("nan")
            elif tg.key == "q":
                actual = _measure_q(solution, node)
            elif tg.key == "bw":
                actual = _measure_bw(solution, node)
            elif tg.key == "vout":
                # 代码路径的激励是 ac=1（单位幅度），直接读节点电压得到的是「增益」。
                # 用 |Vo/Vs| × Vin 还原绝对电压（与 bench/run_llm.py 的 divider 量法一致）。
                #
                # ⚠ 源节点**必须从电路里的电压源找**，不能猜节点名。
                # 实测事故：模型生成的电路把源节点叫 "vin"/"src" 而不是 "in"，
                # 猜错时 vs 取成了输出自己 → 比值恒为 1 → 任何电路都被算成「输出=Vin」，
                # 于是正确电路被误判为不达标（真·误杀）。
                # 输入电压已在循环开头校验过（None 直接抛 Unmeasurable），这里一定有值
                vin = tg.vin
                src = _find_source_node(circuit, solution, node)
                f = _f_low(solution)
                if src:
                    vs = abs(solution.value_at(src, f))
                    vo = abs(solution.value_at(node, f))
                    actual = (vo / vs) * vin if vs else float("nan")
                else:
                    actual = float("nan")      # 找不到源就如实报「测不到」，不猜
        except Unmeasurable:
            raise
        except Exception:
            actual = float("nan")
        # 方向性目标（"以上"/"以下"）用紧得多的容差。
        # 「带宽 100kHz 以上」若沿用 15% 的对称容差，85kHz 也会被判合格 ——
        # 那就不叫下限了。2% 只留给元件取值和仿真的正常误差。
        tol = _BOUND_TOL if tg.bound != "eq" else _TOL.get(tg.key, 0.10)
        miss = Miss(tg, actual)
        if not math.isfinite(miss.rel_err) or miss.rel_err > tol:
            misses.append(miss)
    return misses


def _find_source_node(circuit, solution, out_node: str) -> str | None:
    """找出激励源所在的节点（用于把增益还原成绝对电压）。

    优先级：
      1. 电路里的独立电压源的第一个节点（最可靠，和 bench 的做法一致）
      2. 退而求其次：不是输出、且幅度最接近 1.0 的节点（ac=1 激励的特征）
    都找不到就返回 None —— 让调用方如实报「测不到」，绝不瞎猜。
    """
    try:
        for comp in getattr(circuit, "components", []) or []:
            if str(getattr(comp, "kind", "")).upper() == "V":
                nodes = list(comp.nodes() or [])
                if nodes:
                    return nodes[0]
    except Exception:
        pass
    try:
        names = [n for n in solution.node_names() if not str(n).startswith("i(")]
        best, best_err = None, None
        for n in names:
            if n == out_node:
                continue
            try:
                mag = abs(solution.value_at(n, _f_low(solution)))
            except Exception:
                continue
            err = abs(mag - 1.0)
            if best_err is None or err < best_err:
                best, best_err = n, err
        return best
    except Exception:
        return None


def _f_low(solution) -> float:
    xs = getattr(solution, "x", None) or []
    return xs[0] if xs else 1.0


def _cross(xs: list[float], ys: list[float], target: float, rising: bool = False):
    """在对数 x 轴上线性插值求 y=target 的 x。找不到返回 None。"""
    for i in range(1, len(xs)):
        y0, y1 = ys[i - 1], ys[i]
        if y0 == y1:
            continue
        hit = (y0 <= target <= y1) if rising else (y0 >= target >= y1)
        if hit and xs[i - 1] > 0 and xs[i] > 0:
            t = (target - y0) / (y1 - y0)
            return 10 ** (math.log10(xs[i - 1]) + t * (math.log10(xs[i]) - math.log10(xs[i - 1])))
    return None


def _measure_q(solution, node: str) -> float:
    """二阶低通/高通的 Q = |H(f0)| / |H(通带)|，f0 取相位 −90°（低通）或 +90°（高通）交点。

    刻意不用「f0/−3dB 带宽」：Q ≤ 0.707 时没有峰化，那个方法直接失效。
    二阶网络的相位在 f0 处恒为 ∓90°，与 Q 无关——这是唯一对任意 Q 都成立的锚点。
    """
    try:
        ph = solution.phase(node)
        xs = list(solution.x)
        if not ph or not xs:
            return float("nan")
        f0 = _cross(xs, ph, -90.0) or _cross(xs, ph, 90.0)
        if not f0:
            return float("nan")
        h_at = abs(solution.value_at(node, f0))
        g0 = abs(solution.value_at(node, _f_low(solution)))
        return h_at / g0 if g0 else float("nan")
    except Exception:
        return float("nan")


def _measure_bw(solution, node: str) -> float:
    """−3dB 带宽。

    低通和带通的参考电平**不一样**，混用会直接测不出来：

    - 低通：参考 = 低频端（DC）电平，带宽 = 0 → f(−3dB)。峰值就在第一个点，
      若按"峰值两侧各找 −3dB"，起点那侧根本不存在，`lo` 为 None，结果永远是
      测不到（实测踩到过：需求「带宽 100kHz 以上」，单极点电路被判 inf 偏差）。
    - 带通：参考 = 峰值，带宽 = f_lo → f_hi 两侧都要找。

    判据用峰值的位置：峰值贴着扫描起点（前 3 个点内）就是低通/单调下降型。
    """
    try:
        db = solution.db(node)
        xs = list(solution.x)
        if not db or not xs or len(db) < 3:
            return float("nan")
        imax = db.index(max(db))
        if imax <= 2:                      # 低通：从 DC 起算
            hi = _cross(xs, db, db[0] - 3.0103)
            return hi if hi else float("nan")
        ref = db[imax]                     # 带通：相对峰值
        lo = _cross(xs[:imax + 1], db[:imax + 1], ref - 3.0103, rising=True)
        hi = _cross(xs[imax:], db[imax:], ref - 3.0103)
        return (hi - lo) if (lo and hi) else float("nan")
    except Exception:
        return float("nan")


def repair_hint(misses: list[Miss]) -> str:
    """给模型看的修复提示：说清差了哪一项、差多少、往哪个方向改。"""
    lines = ["生成的电路可以运行，但**没有满足需求里的指标**："]
    for m in misses:
        lines.append(f"- {m.message()}")
        k = m.target.key
        if k in ("fc", "f0"):
            if math.isfinite(m.actual) and m.actual > m.target.value:
                lines.append(f"  实测偏高了 {m.actual / m.target.value:.2f} 倍 → 需要把截止频率降下来："
                             f"R 或 C 按比例增大（fc ∝ 1/(RC)）")
            elif math.isfinite(m.actual):
                lines.append(f"  实测偏低了 {m.target.value / max(m.actual, 1e-30):.2f} 倍 → 需要把截止频率提上去："
                             f"R 或 C 按比例减小")
        elif k == "gain_lin":
            lines.append("  增益不对 → 检查反馈电阻比（同相 1+R2/R1，反相 R2/R1）")
        elif k == "vout":
            vin = m.target.vin
            if vin:
                want = m.target.value / vin
                lines.append(
                    f"  输出电压不对 → 分压比应为 Vout/Vin = {want:.4f}，"
                    f"即 R2/(R1+R2) = {want:.4f}（R1 上臂、R2 下臂）。"
                    f"当前比值不对：检查是不是漏了接地电阻，或把 R1/R2 位置接反了。")
            else:
                lines.append(
                    "  输出电压不对 → 若这是分压电路，分压比 = R2/(R1+R2)；"
                    "若是有源电路，检查增益与输入幅度。需求没给输入电压，"
                    "请确保电路确实按需求的输出值设计。")
        elif k == "q":
            want_ratio = (2 * m.target.value) ** 2
            if math.isfinite(m.actual) and m.actual > 0:
                have_ratio = (2 * m.actual) ** 2
                lines.append(
                    f"  单位增益 Sallen-Key 在 R1=R2 时 **Q = 0.5·√(C1/C2)**，"
                    f"即 C1/C2 应为 (2Q)² = **{want_ratio:.3f}**；"
                    f"当前实测 Q={m.actual:.3f} 对应 C1/C2≈{have_ratio:.3f}，"
                    f"需要把 C1 增大到 C2 的 {want_ratio:.3f} 倍（或把 C2 减小）。"
                    f"注意 Q≠0.5·√(C2/C1)，方向别搞反。"
                )
            else:
                lines.append(f"  单位增益 Sallen-Key 在 R1=R2 时 Q = 0.5·√(C1/C2)，"
                             f"取 C1/C2 = (2Q)² = {want_ratio:.3f}")
    lines.append("请只修改元件值（或结构），重新给出完整可执行代码。")
    return "\n".join(lines)


#: 常见量化指标词：命中了词、附近又有数字，却没被 parse_targets 抽成 Target，
#: 就说明「用户提了指标，但本模块不认识」——必须让上层知道，不能静默放过。
_QUANT_WORDS = (
    "输出电流", "输出阻抗", "输入阻抗", "输入电阻", "功耗", "功率", "效率", "纹波", "噪声", "相位裕度",
    "共模抑制", "CMRR", "失调", "偏置电流", "压摆率", "建立时间", "上升时间",
    "超调", "误差", "精度", "温度漂移", "带宽", "截止频率", "中心频率", "增益",
    "品质因数", "衰减", "抑制", "深度", "输出电压",
)


def unparsed_metrics(prompt: str) -> list[str]:
    """需求里有量化表述，但一个都没被 `parse_targets` 抽出来 → 返回那些说法。

    为什么需要：`parse_targets` 只认 7 个 key（fc/f0/gain_lin/gain_db/q/bw/vout）。
    实测「输出 1A」「不超过 100mW」「误差小于 2%」「相位裕度 45°」「CMRR 80dB」
    「输出阻抗 50Ω」全部返回 `[]`，而 `generate` 把 `[]` 当成「没有指标要对账」→
    交出一个 5.45V（要求 5V、误差 9%）的电路仍然 `ok=True`。
    抽不到不是错，**不告诉用户抽不到**才是错。
    """
    if not prompt:
        return []
    found: list[str] = []
    # ⚑ 判定粒度必须是**每个词**，不能是"窗口里只要有东西解析成功就算这个也没问题"。
    # 早先的写法（`if parse_targets(near): continue`）实测吞掉了很多指标：
    #   「LDO 输出 3.3V，纹波<10mV，效率85%」→ 窗口里有 vout 解析成功 → 「纹波」整条隐身；
    #   「fc=10kHz，在 10 倍截止频率处衰减 40dB」→ 「衰减 40dB」一个字都不报。
    try:
        _ts = parse_targets(prompt)
    except Exception:
        _ts = []
    # 覆盖集 = 已解析目标的原文 + 它的中文标签（`截止频率` 这类标签不一定出现在 raw 里）
    _bits = []
    for x in _ts:
        _bits.append(str(getattr(x, "raw", "") or ""))
        try:
            _bits.append(x.label())
        except Exception:
            pass
    covered = " ".join(_bits)
    for w in _QUANT_WORDS:
        for m in re.finditer(re.escape(w), prompt):
            near = prompt[max(0, m.start() - 10): m.end() + 18]
            if not re.search(r"\d", near):
                continue
            if w in covered:          # 这个词已经被某个解析成功的目标覆盖了
                break
            found.append(w)
            break
    return found
