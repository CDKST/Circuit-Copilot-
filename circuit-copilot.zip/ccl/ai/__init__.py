"""CCL 的 AI 生成功能（**独立可选**）。

核心库不依赖这个子包：没有 API Key 时，手写 `Circuit` 那条路完全不受影响。

    from ccl.ai import generate, review, explain

    gen = generate("二阶低通，截止 10kHz，Q=0.707")
    gen.ok        # 是否成功
    gen.source    # 可执行的 Python 代码
    gen.circuit   # 真正构建出来的 Circuit
    gen.solution  # 真跑过一次仿真的结果
    gen.error     # 失败原因
    gen.attempts  # 每次尝试的代码与错误

    issues = review(circuit, solution=None)   # 确定性检查 + 模型解释
    text   = explain(circuit, solution=None)  # 中文解释
    fixed  = fix(your_code)                   # 按实际问题修正现成代码

设计要点见各模块 docstring；三条硬性要求（生成代码而非网表 / 必须真跑 /
exec 安全隔离）分别落在 generate.py、sandbox.py。
"""

from __future__ import annotations

from .explain import explain
from .generate import Attempt, Generation, LLMUnavailable, fix, generate
from .review import Issue, review

__all__ = [
    "generate",
    "fix",
    "review",
    "explain",
    "Generation",
    "Attempt",
    "Issue",
    "LLMUnavailable",
]
