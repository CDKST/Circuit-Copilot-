"""电路静态检查 + 工作点合理性检查（纯确定性，不依赖任何模型）。

这一层是「代码即测试」的基础：电路能不能立得住，不需要仿真也不需要大模型就能
判掉一大半。放在 `ccl/` 核心而不是 `ccl/ai/`，是因为它属于库的底座能力——
没有 API Key 也必须能用。

## 两类检查

静态检查（只看结构，不跑仿真）
    电路为空 / 完全没有地 / 悬空节点 / 节点无直流通路到地 /
    电压源并联或自短路 / 参数越界 / 无 AC 激励 / 孤立子网络

工作点检查（需要 .op 结果）
    节点电压发散（|V| > 1kV）/ 电阻功耗超限 /
    三极管饱和或截止 / MOSFET 截止或线性区

## 与 ccl.ai.review 的关系

`ccl.ai.review` 曾经自带一份静态检查——那是分层放错了：核心能力不该住在
可选包里。现在**本文件是唯一真相**，`ccl.ai.review` 从 `ccl.lint` 导入，
它只保留自己的叙事职责和波形形状检查（撞轨 / 峰化）后处理。
"""

from __future__ import annotations

import math
import re as _re
from dataclasses import dataclass, field

__all__ = [
    "Issue",
    "lint",
    "check_solution",
    "check_node_levels",
    "check_resistor_power",
    "check_bjt_region",
    "check_mos_region",
]

GND = "0"

# 直流导通：这些器件在两个端子之间提供直流通路（电阻性）
_DC_CONDUCTING = frozenset({"R", "L", "V", "E", "F", "G", "H"})
# 阻断直流的器件
_DC_BLOCKING = frozenset({"C"})


@dataclass
class Issue:
    """一条评审意见。

    level   "error"（电路不成立）/ "warn"（能跑但有问题）/ "info"（提示）
    ref     指向的位号或节点，便于用户定位；没有具体对象时为空
    """

    level: str
    title: str
    detail: str
    ref: str = ""
    code: str = ""      # 机器可读标识，用于去重与程序化判断（可空）

    def __post_init__(self):
        if self.level not in ("error", "warn", "info"):
            raise ValueError(f"level 必须是 error/warn/info，收到 {self.level!r}")

    def as_dict(self) -> dict:
        return {"level": self.level, "code": self.code, "title": self.title,
                "detail": self.detail, "ref": self.ref}

    def __str__(self) -> str:
        tag = {"error": "错误", "warn": "警告", "info": "提示"}[self.level]
        where = f" [{self.ref}]" if self.ref else ""
        return f"[{tag}]{where} {self.title}：{self.detail}"


# --------------------------------------------------------------------------
# 确定性检查
# --------------------------------------------------------------------------

def _nets(circuit) -> dict[str, list[tuple[str, str]]]:
    return circuit.nets()


def check_empty(circuit) -> list[Issue]:
    if not circuit.components:
        return [Issue("error", "电路是空的", "没有任何器件，无法构成电路", "")]
    return []


def check_ground(circuit) -> list[Issue]:
    if not circuit.components:
        return []
    if GND not in _nets(circuit):
        return [Issue(
            "error", "没有地节点",
            "电路里没有任何器件接到 GND。SPICE 需要参考地，否则矩阵奇异、无解",
            "GND",
        )]
    return []


def check_floating(circuit, ignore: set | None = None) -> list[Issue]:
    """悬空节点：只连了一个引脚。几乎一定是接线笔误。

    `ignore` 里放的是**已声明的端口**——它们是留给外部电路接的，
    在子电路单独检查时不该算作悬空（否则每个 block 都报一堆假错误）。
    """
    skip = set(ignore or ())
    out: list[Issue] = []
    for node, pins in _nets(circuit).items():
        if node == GND or len(pins) >= 2 or node in skip:
            continue
        ref, pin = pins[0]
        out.append(Issue(
            "error", "悬空节点",
            f"节点 {node!r} 只连着 {ref}.{pin} 一个引脚，另一端没有去处。"
            f"这通常是接线漏了，或节点名打错（检查是否有拼写相近的节点）",
            node,
        ))
    return out


def _dc_graph(circuit) -> dict[str, set[str]]:
    """构建"直流导通"图：{节点: 可直流通达的节点集合}。

    规则：
    - R / L / V / 受控源：两端互通
    - C：两端阻断（直流开路）
    - I（电流源）：两端阻断（理想电流源是开路）
    - X（运放）：所有引脚互通，且视为能到地
      （宏模型内部有 Rin 到差分、E0 到地、Rout 到输出，直流都能通）
    """
    g: dict[str, set[str]] = {}

    def link(a: str, b: str) -> None:
        g.setdefault(a, set()).add(b)
        g.setdefault(b, set()).add(a)

    for c in circuit.components:
        nodes = c.nodes()
        for n in nodes:
            g.setdefault(n, set())
        kind = c.kind.upper()
        if kind in _DC_CONDUCTING:
            for i in range(len(nodes)):
                for j in range(i + 1, len(nodes)):
                    link(nodes[i], nodes[j])
        elif kind == "X":
            for i in range(len(nodes)):
                for j in range(i + 1, len(nodes)):
                    link(nodes[i], nodes[j])
            # 内部到地：E0 参考地
            for n in nodes:
                link(n, GND)
        # C / I / 其他：不连

    # 地自己总是能到地
    g.setdefault(GND, set())
    return g


def check_dc_path(circuit, ignore: set | None = None) -> list[Issue]:
    """每个节点必须有到地的直流通路，否则 SPICE 报 singular matrix。

    这是 SPICE 最常见的"莫名其妙跑不动"，报错信息完全指不到器件，
    所以我们必须在 Python 侧先查出来并指到具体节点。
    """
    if not circuit.components or GND not in _nets(circuit):
        return []      # 没地的情况由 check_ground 负责，不重复报

    g = _dc_graph(circuit)
    out: list[Issue] = []

    skip = set(ignore or ())

    def reachable(start: str) -> bool:
        seen = {start}
        stack = [start]
        while stack:
            cur = stack.pop()
            if cur == GND:
                return True
            # 走到已声明的端口 = 通路离开了本子电路，直流通路由外部负责。
            # 否则 rlc_bandpass 这种 L-C 之间的内部节点会被误判成浮地。
            if cur != start and cur in skip:
                return True
            for nxt in g.get(cur, ()):
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        return False

    for node, pins in _nets(circuit).items():
        if node == GND or len(pins) < 2:
            continue        # 悬空由 check_floating 报
        if node in skip:
            continue        # 已声明的端口：外部电路会接，直流通路不由本电路负责
        if reachable(node):
            continue
        # 找出"谁把这个节点困住了"：列出该节点上所有器件
        who = "、".join(f"{r}.{p}" for r, p in pins)
        blockers = sorted({
            circuit.find(r).kind for r, _ in pins if circuit.find(r) is not None
        })
        out.append(_dc_issue(node, who, blockers))
    return out


def _dc_issue(node: str, who: str, blockers: list[str]) -> Issue:
    hint = ""
    if blockers and all(k in ("C", "I") for k in blockers):
        hint = "（该节点上的器件都是隔直流的：电容阻断直流、理想电流源是开路）"
    return Issue(
        "error", "节点没有直流通路到地",
        f"节点 {node!r} 的器件（{who}）无法通过电阻性通路到达 GND{hint}。"
        f"SPICE 会因此报 singular matrix，且报错不会告诉你位置。"
        f"修法：给该节点加一个到地的电阻（哪怕是 1Meg 的偏置电阻）",
        node,
    )


def check_voltage_sources(circuit) -> list[Issue]:
    """理想电压源并联 = 两个理想源抢同一个电压 → 无解或无限电流。
    电压源两端接同一节点 = 自短路。
    """
    out: list[Issue] = []
    vs = [c for c in circuit.components if c.kind.upper() == "V"]

    for c in vs:
        nodes = c.nodes()
        if len(nodes) == 2 and nodes[0] == nodes[1]:
            out.append(_vs_issue(c.ref, f"{c.ref} 的两端都接在节点 {nodes[0]!r}"))
            continue

    for i in range(len(vs)):
        for j in range(i + 1, len(vs)):
            a, b = vs[i], vs[j]
            na, nb = set(a.nodes()), set(b.nodes())
            if na == nb and len(na) == 2:
                va, vb = a.value, b.value
                same = (isinstance(va, (int, float)) and isinstance(vb, (int, float))
                        and abs(float(va) - float(vb)) < 1e-12)
                if same:
                    out.append(Issue(
                        "warn", "理想电压源并联",
                        f"{a.ref} 与 {b.ref} 并联在同一对节点上且电压相同。"
                        f"仿真能跑，但两个理想源互相钳位，实际电路里没有任何意义"
                        f"（真实情况会因内阻差异产生环流）",
                        f"{a.ref},{b.ref}",
                    ))
                else:
                    out.append(_vs_issue(
                        f"{a.ref},{b.ref}",
                        f"{a.ref}（{va}V）与 {b.ref}（{vb}V）并联在同一对节点上，"
                        f"电压不一致 → 理想源互相短路，方程无解",
                    ))
    return out


def _vs_issue(ref: str, why: str) -> Issue:
    return Issue(
        "error", "理想电压源冲突",
        f"{why}。理想电压源内阻为零，不能并联或自短路；"
        f"需要并联就用两个源各自串一个小电阻（如 0.1Ω）再并",
        ref,
    )


def check_params(circuit) -> list[Issue]:
    """参数越界。devices 层已经拦了，但 review 要能检查任何 Circuit
    （包括用户手工改 value 的、从别处来的）。"""
    out: list[Issue] = []
    for c in circuit.components:
        if c.kind.upper() in ("R", "C", "L"):
            v = c.value
            unit = {"R": "阻值", "C": "容值", "L": "感值"}[c.kind.upper()]
            if v is None:
                out.append(_param_issue(c.ref, f"{c.ref} 的{unit}是空的（None）"))
            elif isinstance(v, (int, float)):
                if v <= 0:
                    out.append(_param_issue(c.ref, f"{c.ref} 的{unit}是 {v}，必须 > 0"))
                elif not math.isfinite(float(v)):
                    out.append(_param_issue(c.ref, f"{c.ref} 的{unit}不是有限数（{v}）"))
                elif c.kind.upper() == "R" and (v < 1e-3 or v > 1e10):
                    out.append(_param_issue(c.ref, f"{c.ref} 的阻值 {v}Ω 超出合理范围（1mΩ~10GΩ）"))
                elif c.kind.upper() == "C" and (v < 1e-15 or v > 1.0):
                    out.append(_param_issue(c.ref, f"{c.ref} 的容值 {v}F 超出合理范围（1fF~1F）"))
            elif isinstance(v, str):
                pass    # 字符串值交给 compile 判断
            else:
                out.append(_param_issue(c.ref, f"{c.ref} 的值类型异常：{type(v).__name__}"))
    return out


def _param_issue(ref: str, why: str) -> Issue:
    return Issue("error", "参数越界", f"{why}。器件值必须为正的有限数", ref)


def check_ac_excitation(circuit) -> list[Issue]:
    """AC 分析要有 AC 幅度非 0 的源，否则所有波形恒为 0（看起来像"电路坏了"）。"""
    out: list[Issue] = []
    sources = [c for c in circuit.components if c.kind.upper() in ("V", "I")]
    if not sources:
        return [Issue(
            "warn", "没有独立源",
            "电路里没有任何电压源或电流源。AC 分析没有激励，输出恒为 0",
            "",
        )]
    # ★ 源的 ac/dc 是**属性**（devices._Source 里存 self.dc / self.ac），
    #   不在 params 字典里。第一版读 params 导致每个正常电路都被误报"没有 AC 激励"。
    ac_sources = [c for c in sources
                  if isinstance(getattr(c, "ac", None), (int, float))
                  and getattr(c, "ac") != 0]
    if not ac_sources:
        out.append(Issue(
            "warn", "没有 AC 激励",
            f"有 {len(sources)} 个源，但没有一个设置了 ac 幅度（如 ac=1）。"
            f"AC 分析需要小信号激励，否则所有节点电压恒为 0，看不出任何频响",
            ",".join(c.ref for c in sources[:4]),
        ))
    return out


def check_isolated_subnets(circuit) -> list[Issue]:
    """有地，但存在与主电路不连通的孤立部分（多半是忘了接上）。"""
    if not circuit.components or GND not in _nets(circuit):
        return []
    g = _dc_graph(circuit)
    # 用"全部器件"的连通性（含电容、电流源），比直流通路更能反映"接线"
    g2: dict[str, set[str]] = {}
    for c in circuit.components:
        nodes = c.nodes()
        for n in nodes:
            g2.setdefault(n, set())
        for i in range(len(nodes)):
            for j in range(i + 1, len(nodes)):
                g2.setdefault(nodes[i], set()).add(nodes[j])
                g2.setdefault(nodes[j], set()).add(nodes[i])

    def comp_of(start: str) -> set[str]:
        seen = {start}
        stack = [start]
        while stack:
            cur = stack.pop()
            for nxt in g2.get(cur, ()):
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        return seen

    main = comp_of(GND)
    out: list[Issue] = []
    for node in _nets(circuit):
        if node in main:
            continue
        group = comp_of(node)
        refs = sorted({r for n in group for r, _ in _nets(circuit).get(n, [])})
        out.append(Issue(
            "warn", "存在孤立子网络",
            f"节点 {sorted(group)} 上的器件（{', '.join(refs[:6])}）与主电路没有连通。"
            f"仿真会正常跑（各子网络独立求解），但结果没有意义——多半是漏接了一根线",
            node,
        ))
        main |= group     # 同一组只报一次
    return out


# ---- 以下需要 solution ----



# ==========================================================================
# 工作点合理性检查（M3 新增）
# ==========================================================================

# 电阻功耗告警阈值（W）。0603 贴片约 0.1W、0805 约 0.125W，
# 取 0.25W 作为「明显超了」的门槛，避免对正常电路刷噪音。
R_POWER_WARN = 0.25
R_POWER_ERROR = 1.0

_BJT_SAT_VCE = 0.3      # Vce 低于此值判饱和
_BJT_CUTOFF_VBE = 0.5   # Vbe 低于此值判截止


def _model_param(model: str, key: str) -> float | None:
    """从内置模型卡里抠出一个参数（如 M2N7002 的 Vto）。"""
    try:
        from .devices import MODEL_CARDS
    except Exception:
        return None
    card = MODEL_CARDS.get(model or "")
    if not card:
        return None
    m = _re.search(r"\b" + key + r"\s*=\s*([-+0-9.eE]+)", card[1])
    return float(m.group(1)) if m else None


def _volt(solution, node: str) -> float | None:
    """取节点电压。

    **地节点必须特判**：SPICE 输出里根本没有 "0" 这个波形（它是参考点，
    恒为 0V），直接查会得到 None，于是所有接地器件的检查会被静默跳过。
    """
    n = str(node).strip()
    if n in ("0", "") or n.upper() in ("GND", "GROUND"):
        return 0.0
    try:
        v = float(solution.value_at(node, 0.0))
        return v if math.isfinite(v) else None
    except Exception:
        return None


def check_node_levels(circuit, solution) -> list[Issue]:
    """节点电压是否异常（数值发散或接错）。"""
    out: list[Issue] = []
    if solution is None:
        return out
    try:
        names = solution.node_names()
    except Exception:
        return out
    for n in names:
        if n.lower().startswith("i("):
            continue
        v = _volt(solution, n)
        if v is None:
            continue
        if abs(v) > 1e3:
            out.append(Issue(
                level="error", code="node_level", ref=n,
                title="节点 %s 电压 %gV 异常" % (n, v),
                detail="远超常规供电范围。通常是接错（源两极短接）、元件值差几个数量级，"
                       "或电路实际不收敛。",
            ))
    return out


def check_resistor_power(circuit, solution) -> list[Issue]:
    """电阻功耗是否超限。"""
    out: list[Issue] = []
    if solution is None:
        return out
    for comp in getattr(circuit, "components", []):
        if comp.kind.upper() != "R":
            continue
        try:
            r = float(comp.value)
        except (TypeError, ValueError):
            continue
        if r <= 0:
            continue
        nodes = comp.nodes()
        va, vb = _volt(solution, nodes[0]), _volt(solution, nodes[1])
        if va is None or vb is None:
            continue
        p = (va - vb) ** 2 / r
        if p >= R_POWER_ERROR:
            out.append(Issue(
                level="error", code="resistor_power", ref=comp.ref,
                title="%s 功耗 %.3gW 严重超限" % (comp.ref, p),
                detail="R=%gΩ 上压降 %.3gV，功耗接近或超过 1W，普通贴片电阻会烧。"
                       "请增大阻值或换用功率电阻。" % (r, abs(va - vb)),
            ))
        elif p >= R_POWER_WARN:
            out.append(Issue(
                level="warn", code="resistor_power", ref=comp.ref,
                title="%s 功耗 %.3gW 偏高" % (comp.ref, p),
                detail="R=%gΩ 上压降 %.3gV。0603/0805 贴片约 0.1W，请确认封装选型"
                       "或增大阻值。" % (r, abs(va - vb)),
            ))
    return out


def check_bjt_region(circuit, solution) -> list[Issue]:
    """三极管工作区：放大 / 饱和 / 截止。"""
    out: list[Issue] = []
    if solution is None:
        return out
    for comp in getattr(circuit, "components", []):
        if comp.kind.upper() != "Q":
            continue
        nodes = comp.nodes()
        vc, vb, ve = _volt(solution, nodes[0]), _volt(solution, nodes[1]), _volt(solution, nodes[2])
        if vc is None or vb is None or ve is None:
            continue
        vbe, vce = vb - ve, vc - ve
        if vbe < _BJT_CUTOFF_VBE:
            out.append(Issue(
                level="warn", code="bjt_cutoff", ref=comp.ref,
                title="%s 处于截止区（Vbe=%.3fV）" % (comp.ref, vbe),
                detail="Vbe 低于 %gV，三极管基本不导通。若本意是放大，"
                       "请检查基极偏置电阻是否过大。" % _BJT_CUTOFF_VBE,
            ))
        elif vce < _BJT_SAT_VCE:
            out.append(Issue(
                level="warn", code="bjt_saturated", ref=comp.ref,
                title="%s 处于饱和区（Vce=%.3fV）" % (comp.ref, vce),
                detail="Vce 低于 %gV，已进入饱和。若本意是放大，请减小集电极电阻"
                       "或降低基极驱动。" % _BJT_SAT_VCE,
            ))
        else:
            out.append(Issue(
                level="info", code="bjt_active", ref=comp.ref,
                title="%s 工作在放大区（Vbe=%.3fV, Vce=%.3fV）" % (comp.ref, vbe, vce),
                detail="偏置点落在放大区，可用于线性放大。",
            ))
    return out


def check_mos_region(circuit, solution) -> list[Issue]:
    """MOSFET 工作区：截止 / 线性区 / 饱和区。"""
    out: list[Issue] = []
    if solution is None:
        return out
    for comp in getattr(circuit, "components", []):
        if comp.kind.upper() != "M":
            continue
        nodes = comp.nodes()
        vd, vg, vs = _volt(solution, nodes[0]), _volt(solution, nodes[1]), _volt(solution, nodes[2])
        if vd is None or vg is None or vs is None:
            continue
        vgs, vds = vg - vs, vd - vs
        vto = _model_param(comp.model, "Vto")
        if vto is None:
            continue
        vov = vgs - vto
        if vov <= 0:
            out.append(Issue(
                level="warn", code="mos_off", ref=comp.ref,
                title="%s 处于截止（Vgs=%.3fV < Vto=%gV）" % (comp.ref, vgs, vto),
                detail="栅源电压未超过阈值，沟道未开启。若本意是开关导通，"
                       "请提高栅极电压。",
            ))
        elif vds < vov:
            out.append(Issue(
                level="info", code="mos_linear", ref=comp.ref,
                title="%s 处于线性区（Vds=%.3fV < Vov=%.3fV）" % (comp.ref, vds, vov),
                detail="可当开关用（导通电阻小）；若要当恒流源或放大器，需要提高 Vds。",
            ))
        else:
            out.append(Issue(
                level="info", code="mos_sat", ref=comp.ref,
                title="%s 处于饱和区（Vgs=%.3fV, Vds=%.3fV）" % (comp.ref, vgs, vds),
                detail="Vov=%.3fV，可作为恒流源或跨导放大级。" % vov,
            ))
    return out


def check_solution(circuit, solution) -> list[Issue]:
    """所有需要仿真结果的工作点检查。"""
    return (check_node_levels(circuit, solution)
            + check_resistor_power(circuit, solution)
            + check_bjt_region(circuit, solution)
            + check_mos_region(circuit, solution))


_STATIC = (
    check_empty, check_ground, check_floating, check_dc_path,
    check_voltage_sources, check_params, check_ac_excitation,
    check_isolated_subnets,
)


# ---------------------------------------------------------------------------
# 插件扩展钩子
# ---------------------------------------------------------------------------
# 插件可以往这两个列表里追加自己的检查函数。约定：
#   EXTRA_RULES          fn(circuit) -> list[Issue]
#   EXTRA_SOLUTION_RULES fn(circuit, solution) -> list[Issue]
# 每个函数都会被单独 try/except 包住（见 lint()），所以插件写坏不会拖垮整体。
EXTRA_RULES: list = []
EXTRA_SOLUTION_RULES: list = []


def lint(circuit, solution=None, *, include_info: bool = True) -> list[Issue]:
    """完整检查：静态 + （给了仿真结果时的）工作点检查。

    返回按级别排序（error → warn → info）并去重的问题列表。
    任何单项检查内部异常都不会让整体失败——检查器本身不该成为崩溃源。
    """
    # 已声明的端口是「留给外部接的」，对它们报悬空/无直流路径是误报。
    # blocks 里的每个子电路都靠这个才不会被自己的端口判定为错误。
    ignore = set((getattr(circuit, "ports", {}) or {}).values())
    issues: list[Issue] = []
    _takes_ignore = (check_floating, check_dc_path)
    for fn in list(_STATIC) + list(EXTRA_RULES):
        try:
            issues += (fn(circuit, ignore) if fn in _takes_ignore else fn(circuit)) or []
        except Exception as _e:  # 单项检查失败不该拖垮整体，但也不许静默
            import sys as _sys
            print(f"[lint] {fn.__name__} 异常（已跳过）：{type(_e).__name__}: {_e}",
                  file=_sys.stderr)
    if solution is not None:
        try:
            issues += check_solution(circuit, solution)
        except Exception as _e:
            import sys as _sys
            print(f"[lint] 工作点检查异常（已跳过）：{type(_e).__name__}: {_e}", file=_sys.stderr)
        for fn in list(EXTRA_SOLUTION_RULES):     # 插件的工作点检查，同样隔离
            try:
                issues += fn(circuit, solution) or []
            except Exception as _e2:
                import sys as _sys
                print(f"[lint] 插件规则 {getattr(fn, '__name__', fn)} 异常（已跳过）："
                      f"{type(_e2).__name__}: {_e2}", file=_sys.stderr)
    seen = set()
    uniq: list[Issue] = []
    for i in issues:
        key = (i.code, getattr(i, "ref", "") or "")
        if key in seen:
            continue
        seen.add(key)
        uniq.append(i)
    order = {"error": 0, "warn": 1, "info": 2}
    uniq.sort(key=lambda i: order.get(i.level, 3))
    if not include_info:
        uniq = [i for i in uniq if i.level != "info"]
    return uniq
