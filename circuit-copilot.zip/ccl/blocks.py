"""可复用的子电路库（building blocks）。

## 为什么这块是「代码为核心」的真正红利

画图方案复用子电路靠复制粘贴：改一处要改十处，改漏了没人知道。
代码方案里子电路就是一个**函数**：参数化、可组合、可单元测试。

## 两条设计约束（刻意如此）

1. **block 里不放独立源**
   内联（`use`）后子电路会和外部共节点，两个电压源接同一对节点就是
   singular matrix。所以供电、激励一律留在顶层，block 只暴露端口。

2. **每个 block 都声明 `ports`**（`{端口名: 内部节点名}`）
   这样组合时不用记住内部节点叫什么：

       top.use_ports(BLOCKS["noninv_amp"](gain=10), {"in": "src", "out": "y"})

## 用法

    from ccl.blocks import BLOCKS, catalog
    amp = BLOCKS["noninv_amp"](gain=10, gbw=1.3e6)
    top = Circuit("chain")
    top.V("src", GND, ac=1)
    top.use_ports(amp, {"in": "src", "out": "y"})
"""

from __future__ import annotations

import math

from .core import Circuit, GND

__all__ = ["BLOCKS", "catalog", "describe"]


def _set_ports(c: Circuit, ports: dict[str, str]) -> Circuit:
    """登记对外端口：{端口名: 内部节点名}。端口名用 "in"/"out" 这类直白名字。"""
    c.ports = dict(ports)
    return c


# --------------------------------------------------------------------------
# 无源块
# --------------------------------------------------------------------------
def rc_lowpass(fc: float, *, r: float | None = None, c: float | None = None) -> Circuit:
    """一阶 RC 低通。fc = 1/(2πRC)。端口：in → out"""
    if fc <= 0:
        raise ValueError("fc 必须 > 0")
    if c is None:
        c = 100e-9
    if r is None:
        r = 1.0 / (2 * math.pi * fc * c)
    elif c == 100e-9:
        c = 1.0 / (2 * math.pi * fc * r)
    ckt = Circuit("rc_lowpass")
    ckt.R("in", "out", r)
    ckt.C("out", GND, c)
    return _set_ports(ckt, {"in": "in", "out": "out"})


def rc_highpass(fc: float, *, r: float | None = None, c: float | None = None) -> Circuit:
    """一阶 RC 高通。端口：in → out"""
    if fc <= 0:
        raise ValueError("fc 必须 > 0")
    if c is None:
        c = 100e-9
    if r is None:
        r = 1.0 / (2 * math.pi * fc * c)
    ckt = Circuit("rc_highpass")
    ckt.C("in", "out", c)
    ckt.R("out", GND, r)
    return _set_ports(ckt, {"in": "in", "out": "out"})


def divider(ratio: float, *, total_r: float = 10e3) -> Circuit:
    """电阻分压，ratio = Vout/Vin ∈ (0,1)。端口：in → out（且带 gnd 参考）"""
    if not (0 < ratio < 1):
        raise ValueError("ratio 必须在 (0,1) 之间")
    ckt = Circuit("divider")
    ckt.R("in", "out", total_r * (1 - ratio))   # 上臂
    ckt.R("out", GND, total_r * ratio)          # 下臂
    return _set_ports(ckt, {"in": "in", "out": "out"})


def rlc_bandpass(f0: float, q: float = 10.0) -> Circuit:
    """串联 RLC 带通。f0 中心频率，Q = ω0L/R。端口：in → out"""
    if f0 <= 0 or q <= 0:
        raise ValueError("f0 与 q 必须 > 0")
    c = 10e-9
    L = 1.0 / ((2 * math.pi * f0) ** 2 * c)
    R = (1.0 / q) * math.sqrt(L / c)
    ckt = Circuit("rlc_bandpass")
    ckt.L("in", "n1", L)
    ckt.C("n1", "out", c)
    ckt.R("out", GND, R)
    return _set_ports(ckt, {"in": "in", "out": "out"})


# --------------------------------------------------------------------------
# 有源块（运放）
# --------------------------------------------------------------------------
def noninv_amp(gain: float, *, r1: float = 1e3, bw: float | None = None,
               gbw: float | None = None) -> Circuit:
    """同相放大，增益 = 1 + R2/R1。端口：in → out

    bw 给定时按 GBW ≥ 增益×带宽×1.3 选运放带宽。
    """
    if gain < 1:
        raise ValueError("同相放大的增益必须 >= 1")
    if gbw is None:
        gbw = (bw * gain * 1.3) if bw else 1e6
    ckt = Circuit("noninv_amp")
    ckt.R("sum", GND, r1)
    ckt.R("out", "sum", (gain - 1) * r1)
    ckt.OpAmp("in", "sum", "out", gbw=gbw)
    return _set_ports(ckt, {"in": "in", "out": "out"})


def inv_amp(gain: float, *, r1: float = 1e3, bw: float | None = None,
            gbw: float | None = None) -> Circuit:
    """反相放大，|增益| = R2/R1。端口：in → out"""
    g = abs(gain)
    if g <= 0:
        raise ValueError("增益绝对值必须 > 0")
    if gbw is None:
        gbw = (bw * (1 + g) * 1.3) if bw else 1e6   # 噪声增益决定带宽
    ckt = Circuit("inv_amp")
    ckt.R("in", "sum", r1)
    ckt.R("out", "sum", g * r1)
    ckt.OpAmp(GND, "sum", "out", gbw=gbw)
    return _set_ports(ckt, {"in": "in", "out": "out"})


def sallen_key_lowpass(fc: float, q: float = 0.7071, *, gbw: float | None = None) -> Circuit:
    """单位增益 Sallen-Key 二阶低通。Q = 0.5·√(C1/C2) → C1/C2 = 4Q²。端口：in → out"""
    if fc <= 0 or q <= 0:
        raise ValueError("fc 与 q 必须 > 0")
    c2 = 10e-9
    c1 = c2 * (2 * q) ** 2
    r = 1.0 / (2 * math.pi * fc * math.sqrt(c1 * c2))
    if gbw is None:
        gbw = max(fc * 20, 1e6)
    ckt = Circuit("sallen_key_lp")
    ckt.R("in", "n1", r)
    ckt.R("n1", "n2", r)
    ckt.C("n1", "out", c1)       # C1 跨在 n1 与输出之间（不是接地）
    ckt.C("n2", GND, c2)
    ckt.OpAmp("n2", "out", "out", gbw=gbw)
    return _set_ports(ckt, {"in": "in", "out": "out"})


# --------------------------------------------------------------------------
# 半导体偏置块（不自带电源，vcc 由外部接进来）
# --------------------------------------------------------------------------
def bjt_ce_bias(rc: float, rb: float, *, model: str = "Q2N3904") -> Circuit:
    """NPN 共射偏置级（基极电阻接 vcc，集电极负载接 vcc）。端口：vcc, in, out

    注意 `in` 是基极（交流输入可直接耦合进来），`out` 是集电极。
    供电由外部接到 `vcc` 端口，block 内不放源。
    """
    if rc <= 0 or rb <= 0:
        raise ValueError("rc 与 rb 必须 > 0")
    ckt = Circuit("bjt_ce_bias")
    ckt.R("vcc", "b", rb)
    ckt.R("vcc", "c", rc)
    ckt.Q("c", "b", GND, model)
    return _set_ports(ckt, {"vcc": "vcc", "in": "b", "out": "c"})


def emitter_follower(rb: float, re: float, *, model: str = "Q2N3904") -> Circuit:
    """射极跟随器（电压跟随，输入阻抗高）。端口：vcc, in, out"""
    if rb <= 0 or re <= 0:
        raise ValueError("rb 与 re 必须 > 0")
    ckt = Circuit("emitter_follower")
    ckt.R("vcc", "b", rb)
    ckt.Q("vcc", "b", "out", model)
    ckt.R("out", GND, re)
    return _set_ports(ckt, {"vcc": "vcc", "in": "b", "out": "out"})




def sallen_key_highpass(fc: float, q: float = 0.7071, *, gbw: float | None = None) -> Circuit:
    """单位增益 Sallen-Key 二阶高通。端口：in → out

    与参数化拓扑 `sallen_key_highpass` 用**同一套解析式**（照抄，别另推）：
        C1 = C2 = C，  R2 = 4Q²·R1    （因为 Q = ½√(R2/R1)）
        ω0 = 1/(C√(R1R2))  ⇒  R1 = 1/(2π·2Q·f0·C)

    两处必须做，否则实测明显偏（都验证过）：
      1. **预畸变**：规格给的是 −3dB 点，公式算的是 f0。两者只由 Q 决定
         （Q=1/√2 时相等；Q=2 时 f3/f0≈0.67，不修正会低 33%）。
      2. 取 5% 裕量：fc 属「不低于」型指标，标称点压线意味着一半产品不达标。

    接法（实测核对过，别改成教材的另一种画法）：
        C1 串联 in→n1；C2 从 n1→np；R2 从 np 对地；R1 从 n1 反馈到 out；运放跟随。
    """
    if fc <= 0 or q <= 0:
        raise ValueError("fc 与 q 必须 > 0")
    q = min(max(q, 0.1), 20.0)
    f3_over_f0 = math.sqrt(
        (-(2.0 - 1.0 / (q * q)) + math.sqrt((2.0 - 1.0 / (q * q)) ** 2 + 4.0)) / 2.0)
    f0 = fc * 1.05 / f3_over_f0
    r1_target = min(10e3, 1e6 / (4.0 * q * q))
    c = 1.0 / (2.0 * math.pi * 2.0 * q * f0 * r1_target)
    r1, r2 = r1_target, 4.0 * q * q * r1_target
    if gbw is None:
        # GBW 必须按 Q 给预算：高 Q 的 Sallen-Key 对运放带宽胃口大得多。
        # 实测教训：f0=1559Hz、Q=2 时只给 1MHz，实际 Q 被压到 0.97（峰值全没了）；
        # 提到 ~3MHz 才回到 2.03。与低通综合的 GBW_MULT=1000 同一口径。
        gbw = max(f0 * 1000.0 * max(q, 1.0), 1e6)
    ckt = Circuit("sallen_key_hp")
    ckt.C("in", "n1", c)
    ckt.C("n1", "np", c)
    ckt.R("np", GND, r2)
    ckt.R("n1", "out", r1)
    ckt.OpAmp("np", "out", "out", gbw=gbw)
    return _set_ports(ckt, {"in": "in", "out": "out"})


def difference_amp(gain: float, *, r_in: float = 10e3,
                   gbw: float | None = None) -> Circuit:
    """单运放差分放大（四电阻减法器）。端口：inp, inn → out

    Vout = gain·(Vinp − Vinn)，gain = R2/R1（两臂对称）。
    输入阻抗约 r_in（不高），要更高请用三运放仪用结构。
    """
    if gain <= 0 or r_in <= 0:
        raise ValueError("gain 与 r_in 必须 > 0")
    r1 = r_in
    r2 = r_in * gain
    if gbw is None:
        gbw = max(1e6, 100.0 * gain * 1e3)
    ckt = Circuit("diff_amp")
    # 反相臂：inn -R1- sum，out -R2- sum
    ckt.R("inn", "sum", r1)
    ckt.R("out", "sum", r2)
    # 同相臂：inp -R3- pos，pos -R4- 地（与反相臂同比例，保证 CMRR）
    ckt.R("inp", "pos", r1)
    ckt.R("pos", GND, r2)
    ckt.OpAmp("pos", "sum", "out", gbw=gbw)
    return _set_ports(ckt, {"inp": "inp", "inn": "inn", "out": "out"})


def twin_t_notch(f0: float, *, c: float | None = None) -> Circuit:
    """Twin-T 双 T 陷波器（无源），掐掉 f0、两侧放行。端口：in → out

    对称条件是全部：R1=R2=R、C1=C2=C、**C3=2C、R3=R/2**。
    写成 C3=C/2、R3=2R 只会得到 −5dB 的「小坑」，工频照样过。

    无源 Twin-T 的 Q 固定 0.25（带宽 = 4×f0），凹陷深度取决于元件匹配。
    """
    if f0 <= 0:
        raise ValueError("f0 必须 > 0")
    if c is None:
        c = 100e-9
        if 1.0 / (2 * math.pi * f0 * c) > 1e6:      # 低频时自动换大电容，避免 10MΩ 级电阻
            c = min(10e-6, c * 100)
    r = 1.0 / (2 * math.pi * f0 * c)
    ckt = Circuit("twin_t_notch")
    ckt.R("in", "a", r)
    ckt.R("a", "t", r)
    ckt.C("a", GND, 2 * c)        # C3 = 2C（并联臂，不是 C/2）
    ckt.C("in", "b", c)
    ckt.C("b", "t", c)
    ckt.R("b", GND, r / 2.0)      # R3 = R/2
    # 汇合点 t 是高阻节点，必须经单位增益缓冲隔离，否则后级一挂就破坏抵消
    ckt.OpAmp("t", "out", "out", gbw=max(f0 * 200, 1e6))
    return _set_ports(ckt, {"in": "in", "out": "out"})

BLOCKS = {
    "rc_lowpass": rc_lowpass,
    "rc_highpass": rc_highpass,
    "divider": divider,
    "rlc_bandpass": rlc_bandpass,
    "noninv_amp": noninv_amp,
    "inv_amp": inv_amp,
    "sallen_key_lowpass": sallen_key_lowpass,
    "bjt_ce_bias": bjt_ce_bias,
    "emitter_follower": emitter_follower,
    "sallen_key_highpass": sallen_key_highpass,
    "difference_amp": difference_amp,
    "twin_t_notch": twin_t_notch,
}


def catalog() -> list[dict]:
    """可复用子电路清单（给前端与文档用）。"""
    import inspect

    out = []
    for name, fn in BLOCKS.items():
        sig = inspect.signature(fn)
        params = []
        for p in sig.parameters.values():
            params.append({
                "name": p.name,
                "required": p.default is inspect.Parameter.empty,
                "default": None if p.default is inspect.Parameter.empty else p.default,
            })
        doc = (fn.__doc__ or "").strip().splitlines()
        out.append({
            "name": name,
            "summary": doc[0] if doc else "",
            "params": params,
        })
    return out


def describe(name: str) -> Circuit:
    """构建一个 block 看一眼它长什么样（调试用）。"""
    fn = BLOCKS[name]
    doc = (fn.__doc__ or "")
    print(doc)
    return fn()


def _unused() -> None:  # pragma: no cover
    return None
