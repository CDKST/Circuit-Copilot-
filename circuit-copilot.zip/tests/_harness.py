"""极简测试框架 —— 只用标准库，不引入 pytest。

为什么自己写：
  1. 项目约束是「只用标准库」，pytest 不在标准库里。
  2. 我们要的东西很少：注册、跑、记录耗时、区分 PASS/FAIL/SKIP，
     外加一个别的框架都没有的功能 —— **known_bug 标记**。

known_bug 是本套件最重要的一条纪律：
    当测试断言的是「物理上应该对的东西」而代码给出错的结果时，
    正确的做法不是把断言放宽到刚好通过，而是保留严格断言 + 打上 known_bug 标记。
    这样报告里能同时看到两件事：
      - 这条物理规律现在是错的（bug 存在，有精确复现）
      - 断言没有被偷偷改松（bug 修好那天，测试会自动转为「已修复」提示）
"""

from __future__ import annotations

import math
import os
import time
import traceback
from dataclasses import dataclass, field
from typing import Callable


# --------------------------------------------------------------------------
# 控制流
# --------------------------------------------------------------------------
class Fail(AssertionError):
    """断言失败（不是代码崩溃）。runner 会把崩溃和失败区分开显示。"""


class Skip(Exception):
    """跳过（环境不满足 / 被测拓扑尚未实现）。原因会写进汇总表。"""


# --------------------------------------------------------------------------
# 断言工具
# --------------------------------------------------------------------------
def is_true(cond: object, msg: str = "") -> None:
    if not cond:
        raise Fail(msg or "断言失败：条件为假")


def is_false(cond: object, msg: str = "") -> None:
    is_true(not cond, msg or "断言失败：条件为真")


def is_finite(v: object, what: str = "值") -> float:
    """要求是有限实数（NaN / inf / None 都不行）。"""
    if v is None:
        raise Fail(f"{what} 是 None")
    try:
        f = float(v)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        raise Fail(f"{what} 不是数字：{v!r}")
    if not math.isfinite(f):
        raise Fail(f"{what} 不是有限值：{f!r}")
    return f


def rel_err(actual: float, theory: float) -> float:
    """相对误差；theory 为 0 时退化为绝对误差。"""
    if theory == 0:
        return abs(actual - theory)
    return abs(actual - theory) / abs(theory)


def close(actual: float, theory: float, rel: float, what: str = "",
          note: str = "") -> float:
    """|actual-theory|/|theory| <= rel。返回实际相对误差（便于记表）。"""
    a = is_finite(actual, f"{what or '实测值'}")
    t = is_finite(theory, f"{what or '理论值'}")
    e = rel_err(a, t)
    if not (e <= rel):
        raise Fail(
            f"{what or '数值'} 超差：理论 {t:.6g} / 实测 {a:.6g} / "
            f"相对误差 {e * 100:+.3f}%，容差 ±{rel * 100:g}%"
            + (f"（{note}）" if note else "")
        )
    return e


def close_abs(actual: float, theory: float, abs_tol: float, what: str = "") -> float:
    a = is_finite(actual, what or "实测值")
    t = is_finite(theory, what or "理论值")
    d = abs(a - t)
    if not (d <= abs_tol):
        raise Fail(
            f"{what or '数值'} 超差：理论 {t:.6g} / 实测 {a:.6g} / "
            f"偏差 {d:.6g}，容差 ±{abs_tol:g}"
        )
    return d


def in_range(v: float, lo: float, hi: float, what: str = "") -> float:
    f = is_finite(v, what or "数值")
    if not (lo <= f <= hi):
        raise Fail(f"{what or '数值'} 越界：{f:.6g} 不在 [{lo:.6g}, {hi:.6g}]")
    return f


def between_ratio(actual: float, base: float, lo: float, hi: float,
                  what: str = "") -> float:
    """核对「实测 ≈ base 的 lo~hi 倍」——带宽这类只能给区间的指标用。"""
    a = is_finite(actual, what or "实测值")
    b = is_finite(base, "基准值")
    k = a / b
    if not (lo <= k <= hi):
        raise Fail(
            f"{what or '比值'} 越界：实测 {a:.6g} / 基准 {b:.6g} = {k:.4f}×，"
            f"应在 [{lo:g}, {hi:g}]×"
        )
    return k


def raises(exc: type[BaseException], fn: Callable, *args, what: str = "", **kwargs):
    """要求 fn 抛出 exc（用来验证「坏电路必须报错而不是静默返回空」）。"""
    try:
        out = fn(*args, **kwargs)
    except exc as e:
        return e
    except BaseException as e:  # noqa: BLE001 —— 抛错类型不对同样是 bug
        raise Fail(f"{what or fn.__name__} 抛出了 {type(e).__name__} 而不是 {exc.__name__}：{e}")
    raise Fail(f"{what or fn.__name__} 没有抛 {exc.__name__}，而是正常返回了 {type(out).__name__}")


# --------------------------------------------------------------------------
# 用例注册
# --------------------------------------------------------------------------
@dataclass
class Case:
    fn: Callable
    name: str
    module: str
    group: str = ""
    known_bug: str = ""   # 非空 → 断言的是「正确行为」，当前代码已知不满足
    order: int = 0

    @property
    def bug_id(self) -> str:
        """已知缺陷编号：known_bug 写成 "B3|说明…" 时取 B3，便于跨模块去重。"""
        return self.known_bug.split("|", 1)[0].strip() if "|" in self.known_bug else ""

    @property
    def bug_text(self) -> str:
        if "|" in self.known_bug:
            return self.known_bug.split("|", 1)[1].strip()
        return self.known_bug


CASES: list[Case] = []


def case(fn: Callable | None = None, *, group: str = "", known_bug: str = ""):
    """@case 注册用例。group 用于汇总分组，known_bug 见模块 docstring。"""

    def deco(f: Callable) -> Callable:
        # 用文件名当模块名：无论被 import 还是被 `python3 tests/test_x.py` 直接运行，
        # f.__module__ 都可能是 "__main__"，只有 co_filename 永远可靠。
        mod = os.path.splitext(os.path.basename(f.__code__.co_filename))[0]
        CASES.append(
            Case(fn=f, name=f.__name__, module=mod, group=group,
                 known_bug=known_bug, order=len(CASES))
        )
        return f

    return deco(fn) if fn is not None else deco


@dataclass
class Result:
    case: Case
    status: str            # pass / fail / skip
    seconds: float = 0.0
    message: str = ""
    crashed: bool = False

    @property
    def is_known_bug_fail(self) -> bool:
        return self.status == "fail" and bool(self.case.known_bug)

    @property
    def is_unexpected_pass(self) -> bool:
        """打了 known_bug 标记却通过了 —— 说明 bug 已修复，该摘标记了。"""
        return self.status == "pass" and bool(self.case.known_bug)


@dataclass
class Summary:
    results: list[Result] = field(default_factory=list)
    seconds: float = 0.0

    def _n(self, pred) -> int:
        return sum(1 for r in self.results if pred(r))

    @property
    def passed(self) -> int:
        return self._n(lambda r: r.status == "pass" and not r.is_unexpected_pass)

    @property
    def failed(self) -> int:
        return self._n(lambda r: r.status == "fail")

    @property
    def known_bug_fails(self) -> int:
        return self._n(lambda r: r.is_known_bug_fail)

    @property
    def new_fails(self) -> int:
        return self._n(lambda r: r.status == "fail" and not r.case.known_bug)

    @property
    def skipped(self) -> int:
        return self._n(lambda r: r.status == "skip")

    @property
    def unexpectedly_passed(self) -> int:
        return self._n(lambda r: r.is_unexpected_pass)

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def ok(self) -> bool:
        """「代码没问题」= 没有意外失败、没有意外通过。known_bug 失败不算新问题。"""
        return self.new_fails == 0 and self.unexpectedly_passed == 0


def run(module: str | None = None, verbose: bool = True) -> Summary:
    """跑（某个模块的）全部用例。"""
    sel = [c for c in CASES if module is None or c.module == module]
    out = Summary()
    t0 = time.perf_counter()
    cur_mod = None
    for c in sel:
        if verbose and c.module != cur_mod:
            cur_mod = c.module
            print(f"\n── {cur_mod} " + "─" * max(4, 58 - len(cur_mod)))
        t = time.perf_counter()
        try:
            c.fn()
            r = Result(c, "pass")
        except Skip as e:
            r = Result(c, "skip", message=str(e))
        except Fail as e:
            r = Result(c, "fail", message=str(e))
        except Exception:  # noqa: BLE001 —— 崩溃也是失败，但要看 traceback
            tb = traceback.format_exc(limit=3)
            r = Result(c, "fail", message=tb.strip().splitlines()[-1], crashed=True)
            if verbose:
                print(tb)
        r.seconds = time.perf_counter() - t
        out.results.append(r)
        if verbose:
            print(_fmt_line(r))
    out.seconds = time.perf_counter() - t0
    return out


_ICON = {"pass": "✅", "skip": "⏭️ ", "fail": "❌"}


def _fmt_line(r: Result) -> str:
    icon = _ICON[r.status]
    tail = ""
    if r.status == "fail" and r.case.known_bug:
        icon = "🐞"   # 预期内的失败：已知 bug
    if r.is_unexpected_pass:
        icon = "🎉"   # 已知 bug 居然过了
    if r.status == "skip":
        tail = f"  ← {r.message}"
    elif r.status == "fail":
        tail = f"  ← {'崩溃: ' if r.crashed else ''}{r.message}"
        if r.case.known_bug:
            tail += f"\n      [{r.case.bug_id or '已知bug'}] {r.case.bug_text}"
    elif r.is_unexpected_pass:
        tail = f"\n      [{r.case.bug_id or '已知bug'} 已修复？] {r.case.bug_text}"
    return f"  {icon} {r.case.name:52s} {r.seconds * 1000:6.0f}ms{tail}"


def report(s: Summary, title: str = "测试汇总") -> str:
    lines = [f"\n{'=' * 70}", f"{title}", f"{'=' * 70}"]
    lines.append(
        f"  共 {s.total} 项：通过 {s.passed} · 已知缺陷 {s.known_bug_fails} · "
        f"失败 {s.new_fails} · 跳过 {s.skipped} · 耗时 {s.seconds:.1f}s"
    )
    if s.unexpectedly_passed:
        lines.append(f"  ⚠️ 有 {s.unexpectedly_passed} 个已知 bug 的用例现在通过了，可以摘掉 known_bug 标记。")

    bad = [r for r in s.results if r.status == "fail" and not r.case.known_bug]
    if bad:
        lines.append("\n  ❌ 意外失败（这些是代码 bug，不是测试问题）：")
        for r in bad:
            lines.append(f"    - {r.case.name}: {r.message}")

    bugs = [r for r in s.results if r.is_known_bug_fail]
    if bugs:
        groups: dict[str, tuple[str, list[str]]] = {}
        for r in bugs:
            key = r.case.bug_id or r.case.bug_text
            groups.setdefault(key, (r.case.bug_text, []))[1].append(r.case.name)
        lines.append(f"\n  🐞 已知缺陷 {len(groups)} 个（断言保持严格，代码当前不满足）：")
        for key, (text, names) in groups.items():
            lines.append(f"    [{key or '?'}] {text}")
            lines.append(f"        复现用例：{', '.join(names)}")

    skips = [r for r in s.results if r.status == "skip"]
    if skips:
        lines.append("\n  ⏭️  跳过：")
        for r in skips:
            lines.append(f"    - {r.case.name}: {r.message}")

    lines.append("=" * 70)
    return "\n".join(lines)
