"""能力边界测试：本工具不做的电路，必须**当场拒绝**，不能兜底凑一个。

## 为什么这组测试存在

改动前的真实输出（实测，不是假设）：

    「做一个 Buck 降压电路，输出 5V」
      → 拓扑：电阻分压网络
      → 结论：✅ 全部达标，成品率 100%（20/20），可直接打样

    「设计一个 50Hz 工频陷波器」
      → 拓扑：RLC 串联带通   ← 带通把 50Hz 放过去，陷波要掐死它，方向相反

    12 条「本工具不做的电路」需求，12 条全部静默落到 rc_lowpass 或最接近的拓扑。

这不是缺功能，是**静默交付错的东西并宣称达标**——正好是项目立身要防的那类错误。
所以这一层的测试和物理测试同等重要：物理测试保证「算出来的数是真仿真」，
这一层保证「不该算的东西不要假装算过了」。

## 两个方向的断言缺一不可

- 全部该拦的都拦住了 → 否则用户拿到错电路
- 一条合法需求都没误杀 → 否则「全部拒绝」也能通过上面那条
"""

from __future__ import annotations

import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import _harness as H  # noqa: E402
from _harness import case, is_true  # noqa: E402

from copilot import agent, scope, understand  # noqa: E402


#: (需求原文, 期望命中的类别码)
MUST_REJECT = [
    # 开关电源：最容易出事的一类（分压器能凑出同样的直流电压，但接上负载就塌）
    ("做一个 Buck 降压电路，输出 5V", "no_switching_supply"),
    ("Boost 升压到 12V", "no_switching_supply"),
    ("LDO 稳压 3.3V", "no_switching_supply"),
    ("DC-DC 转换器 5V→3.3V", "no_switching_supply"),
    ("做一个开关电源", "no_switching_supply"),
    # 陷波：带通方向相反，给了等于没滤
    ("做一个变压器隔离的 5V 电源", "no_transformer"),
    # 其余类别
    ("恒流源 20mA 驱动", "no_current_source"),
    ("电流镜偏置电路", "no_current_source"),
    ("RC 振荡器 1kHz", "no_oscillator"),
    ("文氏桥振荡器", "no_oscillator"),
    ("桥式整流电源", "no_rectifier"),
    ("仪用放大器 增益100", "no_instrumentation_amp"),
    ("三极管共射放大 增益50", "no_bjt_amplifier"),
    ("射极跟随器", "no_bjt_amplifier"),
    ("LED 限流电阻 5V 供电", "no_led_driver"),
    ("阻抗匹配到 50 欧", "no_rf"),
    ("变压器隔离 5V", "no_transformer"),
]

#: 合法需求（**必须一条都不误杀**）。
#: 特意放进这些「看起来像但实际不是」的说法，它们是误杀风险最高的：
#:   「降压」→ 分压器的正常说法，不是 Buck
#:   「阻带」→ 低通的规格，不是要带阻滤波器
#:   「电流源」→ ccl 的激励元件，不是恒流源电路
MUST_ACCEPT = [
    "做一个 1kHz 的 RC 低通滤波器",
    "24V 降压到 3.3V 给单片机供电",          # 降压 = 分压，合法
    "把 12V 分压成 5V",
    "低通滤波器，阻带在 10 倍截止频率处衰减 60dB",   # 阻带是规格，不是带阻
    "二阶带通滤波器，中心频率 100kHz，带宽 300kHz",
    "三阶高通，fc=5kHz",
    "运放同相放大 10 倍，带宽 100kHz",
    "用电流源激励这个网络",                    # 激励源，不是恒流源电路
    "Sallen-Key 二阶低通 Q=0.707",
    "差分放大，增益 10",
    "一阶 RC 高通 500Hz",
    # 陷波已由 Twin-T 支持，不能再被能力边界拦（刚学会就别再宣布不会）
    "设计一个 50Hz 工频陷波器，把干扰滤掉",
    "带阻滤波器，中心 50Hz",
    "notch filter at 60Hz",
]


@case(group="scope")
def test_every_unsupported_category_is_caught():
    """每一类「本工具不做」的电路都要被识别出来，并带上可核对的理由与替代路径。"""
    misses = []
    for req, want in MUST_REJECT:
        hits = scope.detect(req)
        codes = [h.code for h in hits]
        if want not in codes:
            misses.append(f"{req} → 期望 {want}，实际 {codes or '没拦住'}")
            continue
        # 拦住还不够：理由要能复核，替代路径要能落地
        hit = next(h for h in hits if h.code == want)
        is_true(bool(hit.evidence.strip()), f"{req}：{want} 缺少 evidence")
        is_true(bool(hit.suggestion.strip()), f"{req}：{want} 缺少 suggestion")
        is_true(hit.severity == "hard", f"{req}：{want} 应为 hard 而不是 {hit.severity}")
    is_true(not misses, "以下需求没被能力边界拦住：\n  " + "\n  ".join(misses))


@case(group="scope")
def test_legitimate_requests_are_not_killed():
    """合法需求一条都不能误杀——否则「全部拒绝」也能让上面那条测试通过。

    重点看三个歧义词：降压（分压器）、阻带（低通的规格）、电流源（激励元件）。
    """
    killed = []
    for req in MUST_ACCEPT:
        hits = scope.detect(req)
        if hits:
            killed.append(f"{req} → {[h.code for h in hits]}")
    is_true(not killed, "合法需求被误杀：\n  " + "\n  ".join(killed))


@case(group="scope")
def test_case_and_spacing_do_not_evade_the_gate():
    """大小写/空格不能绕过闸门（实测漏判过：「LED 限流电阻」被小写的词表漏掉）。"""
    for req in ("LED 限流电阻", "led 限流电阻", "Led限流"):
        is_true(bool(scope.detect(req)), f"{req} 应被识别为超范围")
    # 反过来：大小写也不能让**已支持**的陷波被误判成超范围
    for req in ("50Hz 陷波", "Notch filter", "TWIN-T notch"):
        is_true(not scope.detect(req), f"{req} 已支持，不该被判超范围")


@case(group="scope")
def test_agent_refuses_before_designing():
    """整条流水线必须**在设计之前**停住，返回明确错误，而不是交一个电路出来。

    这条防的是最坏情况：以前「Buck 5V」会得到 divider + 「✅ 达标，可直接打样」。
    """
    # 用仍然不支持的类别；陷波已经能做了（Twin-T），不该出现在这里
    for req in ("做一个 Buck 降压电路，输出 5V", "做一个变压器隔离的 5V 电源"):
        s = agent.run(req, use_llm=False)
        is_true(s.best is None, f"{req}：不应该产出电路（best 应为 None）")
        is_true(bool(s.error), f"{req}：应该给出明确错误说明")
        is_true(s.total_sims == 0, f"{req}：不该浪费仿真（实际跑了 {s.total_sims} 次）")
        hard = [i.code for i in getattr(s.feasibility, "issues", [])] if s.feasibility else []
        is_true(any(str(c).startswith("no_") for c in hard),
                f"{req}：feasibility 里应记录 no_* 类硬问题，实际 {hard}")


@case(group="scope")
def test_report_says_out_of_scope_not_failure():
    """报告头条必须是「超出能力范围」，不能写成「设计失败」——性质不同。"""
    from copilot import report

    s = agent.run("做一个 Buck 降压电路，输出 5V", use_llm=False)
    md = report.markdown(s)
    is_true("超出本工具的能力范围" in md, "报告应说明是能力边界问题")
    is_true("设计失败" not in md, "不该把能力边界写成设计失败")
    is_true("能力范围" in md and "为什么不做" in md, "应给出原因")


@case(group="scope")
def test_understand_path_marks_blocked():
    """界面/助手那条路径（understand.prepare）也要 blocked，不能只拦 CLI。"""
    u = understand.prepare("做一个 Buck 降压电路，输出 5V", "analog", use_llm=False)
    is_true(u.blocked, "prepare 应把需求标记为不可行")
    is_true(any(i.code.startswith("no_") for i in u.verdict.issues),
            f"verdict 里应有 no_* 问题，实际 {[i.code for i in u.verdict.issues]}")
    # 对照：合法的分压需求不能被拦
    ok = understand.prepare("24V 降压到 3.3V 给单片机供电", "analog", use_llm=False)
    is_true(not any(i.code.startswith("no_") for i in ok.verdict.issues),
            "合法分压需求被能力边界误拦")


@case(group="scope")
def test_legit_requests_still_produce_circuits():
    """误杀的最终检查：合法需求必须真的做出电路（不只是「没被 scope 拦」）。"""
    for req, topo in (
        ("24V 降压到 3.3V 给单片机供电", "divider"),
        ("做一个 1kHz 的 RC 低通滤波器", None),
    ):
        s = agent.run(req, use_llm=False)
        is_true(s.best is not None, f"{req}：应该产出电路，实际 error={s.error}")
        if topo:
            is_true(s.topology == topo, f"{req}：期望 {topo}，实际 {s.topology}")


if __name__ == "__main__":
    summary = H.run(module="test_scope")
    print(H.report(summary, "能力边界"))
