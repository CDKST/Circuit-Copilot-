"""边界与鲁棒性测试 —— 坏输入、极端参数、无解需求、判定边界、BOM 边界。

这些测试回答一个问题：**当事情不正常时，系统会不会骗人？**
    - 不收敛的电路必须抛 SimError，不能静默返回空波形（否则上层会拿空数据当"合格"）
    - 极端元件值不能崩、不能给出 NaN 却当成功
    - 物理上做不到的需求必须判"未达标"并解释，不能假装达标
    - 判定逻辑在容差边缘必须精确（差 1e-9 该不该过，要有确定答案）
    - BOM 只列真实物料（运放宏模型内部的 Rin/R0/C0/Rout 不是物料）

单独运行：  python3 tests/test_robust.py
"""

from __future__ import annotations

import math
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import _harness as H  # noqa: E402
from _harness import Skip, case, close, close_abs, is_false, is_true, raises  # noqa: E402

from copilot import agent, elements as E, judge, report, sim  # noqa: E402
from copilot import topologies as T  # noqa: E402

PI2 = 2.0 * math.pi


def full_params(tid: str, **overrides) -> dict:
    """给拓扑补齐所有声明参数，再覆盖关心的几项。

    - R/C/L/Gain 类：取几何中值（对数尺度上的中点）
    - enum 类（阶数、响应类型等）：取最小合法值，几何中值会得到 3.46 阶这种非法值
    - db 类：取中值
    这样队友给拓扑加参数（CMRR_OPA、order/kind/ripple_db …）时本套件不会碎。
    """
    topo = T.get(tid)
    p = {}
    for prm in topo.params:
        if prm.name in overrides:
            continue
        if prm.kind == "enum":
            p[prm.name] = prm.lo
        else:
            p[prm.name] = math.sqrt(prm.lo * prm.hi)
    p.update(overrides)
    return p


# ==========================================================================
# 1. 不收敛 / 非法网表：必须抛 SimError，不能静默返回空结果
# ==========================================================================
BROKEN_NETLISTS = {
    "短路的电压源":
        "* shorted vsrc\nVin in 0 AC 1\nV1 0 0 DC 0\nR1 in 0 1k\n.ac dec 10 1 1k\n.end",
    "重复定义的节点+短路电感":
        "* shorted inductor\nVin in 0 AC 1\nL1 in 0 1m\n.ac dec 10 1 1k\n.end",
    "悬空节点（奇异矩阵）":
        "* floating node\nVin in 0 AC 1\nR1 in out 1k\nC1 out fl 1u\n.ac dec 10 1 1k\n.end",
    "未知器件":
        "* unknown device\nVin in 0 AC 1\nQ9 in 0 0 NOSUCHMODEL\n.ac dec 10 1 1k\n.end",
}


@case(group="sim")
def test_broken_netlists_raise_simerror():
    """每一种坏网表都必须抛 SimError（携带原始网表，便于上层自纠）。"""
    for name, nl in BROKEN_NETLISTS.items():
        e = raises(sim.SimError, sim.run, nl, what=name)
        is_true(bool(e.netlist), f"{name}: SimError 应携带原始网表")
        is_true(len(str(e)) > 5, f"{name}: SimError 应带可读原因")


@case(group="sim")
def test_deviceless_netlist_raises_or_is_flagged():
    """没有任何器件的网表必须报错。

    实测：`* comment` + `.ac` 这种空电路，ngspice 会正常跑完并吐出一个
    只有频率轴的 raw 文件，sim.run() 于是返回一条名为 `all`、y 值等于频率轴的
    幽灵波形（既不是 v(out) 也不是任何真实节点）。后果：拓扑渲染出错时
    （例如器件名拼错被当成注释）拿到的不是 SimError + 原始网表，
    而是一条"看起来有数据"的假波形，上层只能靠 KeyError 偶然发现。
    """
    nl = "* nothing here\n.ac dec 10 1 1k\n.end"
    try:
        r = sim.run(nl)
    except sim.SimError:
        return                      # 正确行为：报错
    raise H.Fail(
        f"无器件网表未报错，返回了幽灵波形 {r.nodes}"
        "（应抛 SimError，携带原始网表供上层自纠）"
    )


@case(group="sim")
def test_netlist_without_end_raises():
    """缺 .end 的网表必须立刻报错（而不是让 ngspice 静默什么都不算）。"""
    raises(sim.SimError, sim.run, "Vin in 0 AC 1\nR1 in 0 1k\n.ac dec 10 1 1k\n")


@case(group="sim")
def test_sim_never_returns_empty_waves_silently():
    """SimResult 若能返回，就必须真的有波形（不能 waves={} 假装成功）。"""
    d = T.get("rc_lowpass").build({"R": 1e3, "C": 159e-9})
    is_true(len(d.waves) > 0, "设计结果必须带波形")
    is_true("v(out)" in d.waves, "RC 低通必须有 v(out) 波形")
    w = d.waves["v(out)"]
    is_true(len(w.x) > 10 and len(w.y) == len(w.x), "波形长度必须一致且非空")


# ==========================================================================
# 2. 极端参数：不崩、不假装成功
# ==========================================================================
EXTREMES = {
    "1Ω+1F (fc=0.16Hz)": {"R": 1.0, "C": 1.0},
    "1e7Ω+1pF (fc=15.9kHz)": {"R": 1e7, "C": 1e-12},
    "1Ω+1pF (fc=159GHz)": {"R": 1.0, "C": 1e-12},
    "fc≈10MHz": {"R": 1.6, "C": 1e-8},
    "fc≈1Hz": {"R": 1.6e6, "C": 100e-9},
}


@case(group="extreme")
def test_extreme_params_do_not_crash():
    """极端元件值：仿真可以给出 NaN（扫频范围外），但不能抛异常、不能返回荒谬的负值/复数。"""
    topo = T.get("rc_lowpass")
    for name, p in EXTREMES.items():
        d = topo.build(p)          # 抛 SimError 就算失败
        is_true(len(d.waves) > 0, f"{name}: 应拿到波形")
        for k, v in d.metrics.items():
            is_true(isinstance(v, float), f"{name}: 指标 {k} 应是 float，实际 {type(v)}")
            if not math.isnan(v):
                is_true(math.isfinite(v), f"{name}: 指标 {k}={v} 不应是 inf")
        is_true(not math.isnan(d.metrics["gain_db"]) or p["R"] > 1e6,
                f"{name}: 低频增益不应是 NaN（除 fc 低于扫频下限）")


@case(group="extreme")
def test_extreme_params_never_judged_as_pass_on_nan():
    """指标是 NaN 时判定必须是「未达标」——不能因为 NaN 比较为 False 而意外放过。"""
    rows = judge.check({"fc": 1e3}, {"fc": float("nan")})
    is_true(len(rows) == 1 and not rows[0].ok, "NaN 指标必须判为未达标")
    rows2 = judge.check({"fc": 1e3}, {"fc": float("inf")})
    is_true(len(rows2) == 1, "inf 指标要有判定行")


@case(group="extreme")
def test_low_cutoff_frequency_is_measured_correctly():
    """fc 低于 ~5Hz 时，实测 fc 仍应与 1/(2πRC) 相符（容差 10%）。

    物理事实：fc 只由 R、C 决定，与扫频范围无关。
    当前实现把 «1Hz 处增益» 当直流参考，fc 一旦掉到扫频下限附近就整条曲线失真。
    """
    topo = T.get("rc_lowpass")
    # 注意：C 的合法范围是 1e-12~1e-3，原先第二组用 C=1F 会被 clamp 成 1mF
    # （拓扑的护栏行为，不是缺陷），会把这个用例变成"验证 clamp"而不是"验证扫频"。
    # 改用范围内、同样得到 0.159Hz 的组合。
    for fc_target, R, C in [(1.0, 1.6e6, 100e-9), (0.159, 1e6, 1e-6)]:
        d = topo.build({"R": R, "C": C})
        theory = 1.0 / (PI2 * R * C)
        close(d.metrics["fc"], theory, 0.10,
              what=f"fc(R={R:g},C={C:g})", note="扫频下限 1Hz 处的参考点假设")


@case(group="extreme")
def test_out_of_range_high_fc_gives_nan_not_a_wrong_number():
    """超出旧扫频上限时的契约：要么给 NaN，要么给**对得上理论值**的数字。

    绝不能输出一个看似正常却错几个数量级的值。
    注：扫频范围已改为按元件值自适应（topologies.ac_sweep），所以 159GHz 现在
    是**能测到**的——此时要求实测值与 1/(2πRC) 吻合，而不是强求 NaN。
    （该频率在物理上不可实现，由 copilot.feasibility 层负责拦，不在测量层拦。）
    """
    params = EXTREMES["1Ω+1pF (fc=159GHz)"]
    d = T.get("rc_lowpass").build(params)
    fc = d.metrics["fc"]
    theory = 1.0 / (2 * math.pi * params["R"] * params["C"])
    if math.isnan(fc):
        pass  # 测不到时承认测不到，可接受
    else:
        close(fc, theory, 0.15, what="fc(159GHz 档)", note="超出旧扫频上限的实测值")
    rows = judge.check({"fc": 1e3}, d.metrics)
    is_true(not rows[0].ok, "159GHz 的电路不应被判为满足 1kHz 目标")


@case(group="extreme")
def test_param_clamping_protects_render():
    """越界参数必须被钳到 Param 的 [lo,hi]，不许把负电阻写进网表。"""
    d = T.get("rc_lowpass").build({"R": -5.0, "C": 0.0})
    is_true(d.params["R"] >= 1.0, f"R 负值应被钳到下限，实际 {d.params['R']}")
    is_true(d.params["C"] >= 1e-12, f"C 零值应被钳到下限，实际 {d.params['C']}")
    is_true("-" not in d.netlist.split("R1 in out ")[1].split("\n")[0],
            "网表里不能出现负电阻值")


# ==========================================================================
# 3. 无解需求：必须判"未达标"并解释，而不是假装达标
# ==========================================================================
@case(group="no_solution")
def test_first_order_rc_cannot_reach_60db_stopband():
    """一阶 RC 的阻带衰减是 20dB/dec，物理上给不出 60dB（在 10·fc 处）。

    需求 fc=1kHz + 阻带衰减 60dB（@10fc）在同一拓扑里无解：
    无论怎么选 R/C，atten_db 恒为 ≈20dB。系统必须判未达标并解释，
    不能因为"候选里最好的那个 fc 达标了"就整体报达标。
    """
    topo = T.get("rc_lowpass")
    spec = {"fc": 1000.0, "atten_db": 60.0}
    best = None
    for r, c in [(1.6e3, 100e-9), (1.5e3, 100e-9), (1.8e3, 100e-9),
                 (1.6e3, 82e-9), (1.6e3, 120e-9)]:
        d = topo.build({"R": r, "C": c})
        rows = judge.check(spec, d.metrics, topo.spec_overrides)
        if best is None or judge.cost(rows) < best[0]:
            best = (judge.cost(rows), d, rows)
    _cost, d, rows = best
    bad = [r for r in rows if not r.ok]
    is_true(len(bad) > 0, "atten_db=60 应判未达标")
    is_true(all(r.key == "atten_db" for r in bad),
            f"未达标的应该是阻带衰减，实际是 {[r.key for r in bad]}")
    is_true(19.0 <= d.metrics["atten_db"] <= 21.0,
            f"一阶 RC 在 10·fc 处的衰减物理上就是 20dB，实测 {d.metrics['atten_db']:.2f}dB")

    # 评审必须解释清楚，而不是给一句「未达标」了事
    s = agent.Session(request="一阶RC低通，1kHz，阻带衰减60dB")
    s.topology, s.spec, s.best, s.rows, s.total_sims = topo.id, spec, d, rows, 5
    review = agent._rule_review(s, topo)
    is_true("未达标" in review, "评审必须明确写出未达标")
    is_true(("阻带衰减" in review) or ("atten" in review), "评审必须点名是哪一项不达标")
    is_true(len(review) > 60, "评审不能只给一句话，要解释原因与出路")


@case(group="no_solution")
def test_too_narrow_search_space_is_reported_not_hidden():
    """候选搜索只覆盖 ±1 个 E 系列标称值时的行为要可复现（不是黑箱）。

    `_candidates` 对每个 E 系列参数只给 snap_pair 的 2~3 个值，
    所以「数值搜索」实际只有 2~9 个候选点；无解时必须如实说无解，
    而不是暗示"我搜了 40 组"。
    """
    topo = T.get("rc_lowpass")
    base = topo.design({"fc": 1000.0})
    cands = agent._candidates(topo, base, budget=40)
    is_true(1 <= len(cands) <= 9,
            f"RC 低通的候选点数应在 1~9（R 3 档 × C 1~3 档），实际 {len(cands)}")
    s = agent.run("做一个1kHz的RC低通滤波器", use_llm=False)
    is_true(s.total_sims == len(s.tries), "total_sims 必须与实际尝试次数一致")
    is_true(s.total_sims <= 40, f"候选数不应超过 budget，实际 {s.total_sims}")


# ==========================================================================
# 4. 判定逻辑的边界
#    注：容差语义（rel/abs、eq/min/max、边界闭区间）与成品率回归已经独立成
#    tests/test_judge.py —— 那里是「判定宪法」，本文件只管鲁棒性。
#    这里只保留一条：坏数据不能变成"通过"。
# ==========================================================================
@case(group="judge")
def test_judge_never_passes_on_bad_data():
    """NaN / 缺失指标都必须判未达标，未知指标键应被忽略（不能因比较为 False 而放过）。"""
    is_false(judge.check({"fc": 1e3}, {"fc": float("nan")})[0].ok, "NaN 必须判未达标")
    is_false(judge.check({"fc": 1e3}, {})[0].ok, "指标缺失必须判未达标")
    is_true(judge.check({"不存在的指标": 1.0}, {"gain_db": 0.0}) == [], "未知指标键应被忽略")


# ==========================================================================
# 5. BOM 解析边界
# ==========================================================================
@case(group="bom")
def test_bom_excludes_subckt_internals():
    """运放宏模型内部的 Rin/R0/C0/Rout 不是物料，不能进 BOM。"""
    d = T.get("opamp_noninverting").build(full_params("opamp_noninverting", R1=1e3, R2=9e3))
    is_true(all(x in d.netlist for x in ("Rin", "R0", "C0", "Rout")),
            "前提：网表里确实有宏模型内部元件")
    refs = {b["ref"] for b in report.bom(d.netlist)}
    for internal in ("Rin", "R0", "C0", "Rout", "E0"):
        is_true(internal not in refs, f"{internal} 是 .subckt 内部元件，不应出现在 BOM：{refs}")


@case(group="bom")
def test_bom_excludes_sources_and_merges_counts():
    """电压源不进 BOM；同规格电阻合并计数。"""
    rows = report.bom(T.get("divider").render({"R1": 10e3, "R2": 10e3, "Vin": 5.0}))
    is_true(len(rows) == 1, f"两个 10k 电阻应合并成一行，实际 {len(rows)} 行：{rows}")
    is_true(rows[0].get("count") == 2, f"合并后数量应为 2，实际 {rows[0].get('count')}")
    is_true("Vin" not in rows[0]["ref"], "电压源不应进 BOM")


@case(group="bom")
def test_bom_values_parse_to_si():
    """BOM 数值解析：10k / 1Meg / 4.7u / 2.2e3 都要还原成正确的 SI 值。"""
    for tok, want in [("10k", 1e4), ("1Meg", 1e6), ("4.7u", 4.7e-6),
                      ("2.2e3", 2.2e3), ("100n", 1e-7), ("1m", 1e-3), ("0", 0.0)]:
        got = report.spice_num(tok)
        is_true(got is not None, f"spice_num({tok!r}) 不应为 None")
        close(got, want, 1e-9, what=f"spice_num({tok!r})")

    d = T.get("rlc_bandpass").build({"L": 1e-3, "C": 10e-9, "R": 10.0})
    by_kind = {b["kind"]: b for b in report.bom(d.netlist)}
    close(by_kind["L"]["si"], 1e-3, 1e-9, what="BOM 电感值")
    close(by_kind["C"]["si"], 10e-9, 1e-9, what="BOM 电容值")
    close(by_kind["R"]["si"], 10.0, 1e-9, what="BOM 电阻值")


@case(group="bom")
def test_bom_has_no_simulation_only_components():
    """BOM 里不应出现只为仿真而加的负载电阻（用户不会去买它）。"""
    for tid, prm in [("opamp_noninverting", dict(R1=1e3, R2=9e3)),
                     ("opamp_inverting", dict(R1=1e3, R2=9e3))]:
        d = T.get(tid).build(full_params(tid, **prm))
        refs = {b["ref"] for b in report.bom(d.netlist)}
        is_true("Rload" not in refs, f"{tid} 的 BOM 里混进了仿真负载电阻：{refs}")


# ==========================================================================
# 6. 拓扑目录的契约（队友新增拓扑时最容易踩的地方）
# ==========================================================================
@case(group="catalog")
def test_every_topology_builds_with_midrange_params():
    """REGISTRY 里每个拓扑都要能用「中值参数」跑通一次，并给出全部 metrics_keys。"""
    for tid, topo in T.REGISTRY.items():
        p = full_params(tid)
        d = topo.build(p)                       # 抛异常即失败
        is_true(len(d.waves) > 0, f"{tid}: 应有波形")
        for k in topo.metrics_keys:
            is_true(k in d.metrics, f"{tid}: 缺少声明过的指标 {k}（实际 {list(d.metrics)}）")
            is_true(isinstance(d.metrics[k], float), f"{tid}.{k} 应是 float")
        is_true(d.netlist.strip().lower().endswith(".end")
                or ".end" in d.netlist.lower(), f"{tid}: 网表应有 .end")


@case(group="catalog")
def test_every_topology_has_valid_metadata():
    """拓扑元数据自检：id/name/params/metrics 都要对得上全局词表。"""
    seen = set()
    for tid, topo in T.REGISTRY.items():
        is_true(tid == topo.id, f"REGISTRY 键 {tid} 与 topo.id {topo.id} 不一致")
        is_true(tid not in seen, f"重复的拓扑 id：{tid}")
        seen.add(tid)
        is_true(bool(topo.name), f"{tid}: name 不能为空")
        is_true(bool(topo.params), f"{tid}: params 不能为空")
        is_true(bool(topo.metrics_keys), f"{tid}: metrics_keys 不能为空")
        for k in topo.metrics_keys:
            is_true(k in T.METRICS, f"{tid}: 指标 {k} 不在全局 METRICS 词表里")
            is_true(k in judge.SPEC_RULE, f"{tid}: 指标 {k} 没有判定规则（SPEC_RULE）")
        for prm in topo.params:
            is_true(prm.lo < prm.hi, f"{tid}.{prm.name}: lo 必须小于 hi")
            is_true(prm.lo > 0, f"{tid}.{prm.name}: lo 必须为正（否则网表会出负数）")
            if prm.series:
                is_true(prm.series in E.SERIES, f"{tid}.{prm.name}: 未知 E 系列 {prm.series}")
        for k, mode in topo.spec_overrides.items():
            is_true(k in topo.metrics_keys, f"{tid}: spec_overrides 里的 {k} 不在 metrics_keys")
            is_true(mode in ("min", "max", "eq"), f"{tid}: 未知比较模式 {mode}")
        is_true(topo.gain_node.lower() in ("out", "v(out)"), f"{tid}: gain_node={topo.gain_node}")


@case(group="catalog")
def test_design_returns_all_declared_params():
    """每个拓扑的 design() 都要给出全部声明参数，否则 build() 会 KeyError。"""
    specs = {
        "rc_lowpass": {"fc": 1e3},
        "rc_highpass": {"fc": 1e3},
        "rlc_bandpass": {"f0": 100e3, "q": 5.0},
        "divider": {"vout": 2.5, "Vin": 5.0},
        "opamp_noninverting": {"gain_lin": 10.0, "fc": 100e3},
        "opamp_inverting": {"gain_lin": 10.0, "fc": 100e3},
        "sallen_key_lowpass": {"fc": 1e3, "q": 0.707},
        "sallen_key_highpass": {"fc": 1e3, "q": 0.707},
        "difference_amp": {"gain_lin": 10.0, "fc": 100e3},
        "filter_lowpass_synth": {"fc": 10e3, "order": 4, "kind": 1, "ripple_db": 0.5},
        # 高通综合是「级联一阶节」，order 指级数（1~3），没有 kind/ripple。
        "filter_highpass_synth": {"fc": 10e3, "order": 3},
        # 带通综合是「每侧 N 级」，order 必须是偶数（2/4/6），且 Q≤q_max(order/2)。
        # 10k ± 20k → Q=0.25，远低于 2 阶的上限 0.50，保证这条只测参数完整性。
        "filter_bandpass_synth": {"f0": 10e3, "bw": 40e3, "order": 2},
        "twin_t_notch": {"f0": 50.0},
    }
    for tid, topo in T.REGISTRY.items():
        spec = specs.get(tid)
        if spec is None:
            raise Skip(f"{tid} 没有在测试里登记目标规格，跳过（请补 specs 表）")
        p = topo.design(spec)
        missing = [prm.name for prm in topo.params if prm.name not in p]
        is_true(not missing, f"{tid}.design() 缺少参数 {missing}")
        for prm in topo.params:
            v = p[prm.name]
            is_true(isinstance(v, (int, float)) and math.isfinite(v),
                    f"{tid}.design() 的 {prm.name}={v!r} 不是有限数")
            is_true(v > 0, f"{tid}.design() 的 {prm.name}={v} 应为正数")


@case(group="catalog")
def test_e_series_snapping():
    """E 系列吸附：snap/snap_pair 只能给出标称值。"""
    for v in (1591.5, 5000.0, 9.09e3, 1e-7, 2.2e-8, 47.0):
        for series in ("E6", "E12", "E24", "E96"):
            s = E.snap(v, series)
            base = E.SERIES[series]
            decade = math.floor(math.log10(s))
            scaled = s / 10 ** decade
            near = min(base, key=lambda b: abs(b - scaled))
            close(scaled, near, 1e-6, what=f"snap({v:g},{series})={s:g} 的尾数")
    pairs = E.snap_pair(1591.5, "E24")
    is_true(1 <= len(pairs) <= 3, f"snap_pair 应给 1~3 个候选，实际 {pairs}")
    is_true(all(p > 0 for p in pairs), f"snap_pair 不应给非正值：{pairs}")
    close(pairs[0], 1500.0, 1e-9, what="1591.5 向下取标称")


# ==========================================================================
# 7. 端到端不崩：错误信息要能落到界面上
# ==========================================================================
@case(group="report")
def test_report_renders_without_crashing():
    """报告渲染不能崩，且未达标项要出现在表格里。"""
    s = agent.run("做一个1kHz的RC低通滤波器", use_llm=False)
    is_true(not s.error, f"这条需求不该报错：{s.error}")
    md = report.markdown(s)
    is_true("# 电路设计报告" in md, "报告应有标题")
    is_true("BOM" in md, "报告应含 BOM 段")
    is_true("## 设计规格与实测" in md, "报告应含「设计规格与实测」段")
    is_true("| 指标 | 目标 | 实测 |" in md, "报告指标表应含 指标/目标/实测 三列")
    for r in s.rows:
        is_true(r.label in md, f"报告应列出指标 {r.label}")


@case(group="report")
def test_error_session_renders_failure_not_success():
    """设计失败（error 非空）时报告必须显示失败，不能渲染出「全部达标」。"""
    s = agent.Session(request="坏需求")
    s.error = "无法由目标指标推出初始参数：boom"
    md = report.markdown(s)
    is_true("设计失败" in md, "失败报告应明确写出设计失败")
    is_true("全部达标" not in md, "失败报告不能出现「全部达标」")


if __name__ == "__main__":
    summary = H.run(module="test_robust")
    print(H.report(summary, "边界与鲁棒性汇总"))
    sys.exit(0 if summary.ok else 1)


# ==========================================================================
# AI 生成：模型自加的断言写错时，不该一票否决
# ==========================================================================
@case(group="ai_generate")
def test_self_assert_failure_warns_instead_of_vetoing():
    """模型自加的 `c.expect` 没过、但用户要求已达标 → 交付 + 警告，不丢电路。

    真实事故：需求「无源 RLC 带通，中心频率 100kHz」，电路峰值实测 100kHz（达标），
    但模型在代码里写了 `c.expect("fc", ...)` —— 把「带通的中心频率」当成
    「−3dB 截止点」（那是低通的定义）。断言不过 → 一个正确电路被整套流程拒收，
    基准里一直记为「真·误杀」。

    改法：用户要求全达标时，自带断言失败只作为**警告**随结果带出来，
    由人判断那几条断言是不是写错了。
    """
    from ccl.ai.generate import generate as ai_generate

    wrong_assert_code = (
        "from ccl import Circuit, GND\n"
        "import math\n"
        "\n"
        "def build():\n"
        "    # 无源 RLC 串联带通，中心 100kHz（Q=10）\n"
        "    f0, Q = 100e3, 10.0\n"
        "    L = 1e-3\n"
        "    C = 1.0 / ((2 * math.pi * f0) ** 2 * L)\n"
        "    R = (1.0 / Q) * math.sqrt(L / C)\n"
        "    c = Circuit('bp')\n"
        "    c.V('in', GND, ac=1)\n"
        "    c.L('in', 'n1', L)\n"
        "    c.C('n1', 'out', C)\n"
        "    c.R('out', GND, R)\n"
        "    # ↓ 故意写错的断言：带通没有「-3dB 截止频率 = 中心频率」这回事\n"
        "    c.expect('fc', 'out', 50e3, tol=0.05)\n"
        "    return c\n"
    )

    class _FakeLLM:
        model = "fake:wrong-assert"

        def available(self):
            return True

        def chat(self, messages, **kw):  # noqa: ARG002
            return wrong_assert_code

    gen = ai_generate("无源 RLC 带通滤波器，中心频率 100kHz",
                      max_repair=0, _llm=_FakeLLM())
    is_true(gen.ok, f"用户要求已达标却被否决了（error={gen.error}）")
    is_true(bool(gen.warnings), "自加断言没过时必须留下警告，不能静默放过")
    warn = " ".join(gen.warnings)
    is_true("断言" in warn and "未通过" in warn,
            f"警告里应说明是断言未通过，实际：{warn[:120]}")
    is_true(gen.error is None, "这种情形不该记成 error（它是告警不是失败）")
