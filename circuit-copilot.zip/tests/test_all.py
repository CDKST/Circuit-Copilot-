"""全拓扑冒烟测试：每个拓扑跑一次仿真并打印指标，人工核对物理合理性。"""
import sys, math
sys.path.insert(0, "/storage/emulated/0/文件夹/dz/circuit-copilot")
from copilot import topologies as T, sim

print("ngspice:", sim.version())
print("=" * 68)

cases = [
    ("rc_lowpass",        {"R": 1e3, "C": 159e-9}),
    ("rc_highpass",       {"R": 1e3, "C": 159e-9}),
    ("rlc_bandpass",      {"L": 1e-3, "C": 10e-9, "R": 10.0}),
    ("divider",           {"R1": 10e3, "R2": 10e3, "Vin": 5.0}),
    ("opamp_noninverting",{"R1": 1e3, "R2": 9e3, "GBW": 1e6, "A0": 1e5}),
    ("opamp_inverting",   {"R1": 1e3, "R2": 9e3, "GBW": 1e6, "A0": 1e5}),
    ("sallen_key_lowpass",{"R1": 10e3, "R2": 10e3, "C1": 22e-9, "C2": 10e-9, "GBW": 1e7, "A0": 1e5}),
]

for tid, params in cases:
    topo = T.get(tid)
    try:
        d = topo.build(params)
    except sim.SimError as e:
        print(f"✗ {tid}: {e}"); continue
    print(f"✔ {tid:22s} {d.elapsed_ms:7.1f}ms")
    for k, v in d.metrics.items():
        info = T.METRICS[k]
        print(f"    {info.label:14s} = {T.fmt_value(v, info.unit)}")
print("=" * 68)
print("理论核对：")
print("  RC 低通 f3dB 应为 1/(2π·1k·159n) =", f"{1/(2*math.pi*1e3*159e-9):.5g} Hz")
print("  RC 高通 f3dB 同上")
print("  RLC f0 应为", f"{1/(2*math.pi*math.sqrt(1e-3*10e-9)):.5g} Hz,  Q=",
      f"{(1/10.0)*math.sqrt(1e-3/10e-9):.4g}")
print("  分压 5V×0.5 = 2.5V")
print("  运放增益 20dB (10倍)，GBW 1MHz → 闭环带宽应 ≈ 100kHz")
print("  SK fc 理论 f0 =", f"{1/(2*math.pi*math.sqrt(1e-4*22e-9*10e-9)):.5g}",
      ", Q =", f"{math.sqrt(1e-4*22e-9*10e-9)/(10e-9*(2e4)):.4g}")
