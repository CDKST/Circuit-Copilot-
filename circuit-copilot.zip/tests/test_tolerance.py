"""容差分析（蒙特卡洛）正确性测试。

容差分析是本项目里**最容易被"看起来合理"骗过**的一块：
数字总在动，图总在画，成品率总能算出一个百分数 —— 但可能是假的。
所以要钉住四条硬性质：

  1. 容差=0 时，所有采样必须完全一致（方差严格为 0）。做不到就说明
     "扰动"根本不是唯一的随机源（例如拓扑内部还有随机/时间相关的东西）。
  2. 容差增大，指标分布的 σ 必须单调增大。否则采样代码算错了。
  3. 成品率必须落在 0~100，并且**设计点越贴规格边界成品率越低**。
     这条是容差分析存在的理由；如果成品率对设计位置不敏感，它就是废数。
  4. 固定 seed 必须可复现（否则评审结论无法被第三方复核）。

单独运行：  python3 tests/test_tolerance.py
"""

from __future__ import annotations

import math
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import _harness as H  # noqa: E402
from _harness import Skip, case, close, close_abs, is_true, raises  # noqa: E402

from copilot import tolerance as MC  # noqa: E402
from copilot import topologies as T  # noqa: E402

# 便宜的拓扑用来跑统计（一次仿真 ~50ms），保证整套测试几十秒内结束
_RC = {"R": 1.6e3, "C": 100e-9}          # fc ≈ 995Hz
_SPEC = {"fc": 1000.0}
_ZERO = {"R": 0.0, "C": 0.0, "L": 0.0, "GBW": 0.0, "A0": 0.0, "Vin": 0.0}


def _mc(tid="rc_lowpass", params=None, spec=None, runs=16, **kw) -> MC.MCResult:
    return MC.monte_carlo(T.get(tid), params or _RC, spec or _SPEC, runs=runs, **kw)


# ==========================================================================
# 1. 容差 = 0 → 方差严格为 0
# ==========================================================================
@case(group="montecarlo")
def test_zero_tolerance_gives_zero_variance():
    """容差全 0 时，每次采样都是标称值：样本必须完全相同，σ 严格 0。"""
    m = _mc(runs=6, tol=_ZERO)
    is_true(m.runs == 6, f"6 次采样都应成功，实际 {m.runs}（失败 {m.failures}）")
    is_true(m.failures == 0, "标称值不该不收敛")
    d = m.dists["fc"]
    is_true(len(set(d.values)) == 1,
            f"容差为 0 时所有样本必须相同，实际有 {len(set(d.values))} 个不同值：{d.values[:5]}")
    close_abs(d.sigma, 0.0, 1e-9, what="σ(容差=0)")   # 浮点残差允许 1e-9
    close(d.mean, d.values[0], 1e-12, what="均值 = 标称值")
    is_true(m.yield_pct == 100.0, f"标称值达标时成品率应 100%，实际 {m.yield_pct}")


@case(group="montecarlo")
def test_empty_tol_dict_still_uses_defaults():
    """注意语义：tol={} 不等于「不扰动」——它仍然叠加在默认容差之上。

    这条钉住的是 API 语义（resolve_tol 的三层叠加），避免以后有人以为
    传个空字典就等于关掉蒙特卡洛，从而把「成品率 100%」当成真实结论。
    """
    eff = MC.resolve_tol(tol={})
    is_true(eff.get("R", 0) > 0, f"tol={{}} 仍应带默认电阻容差，实际 {eff.get('R')}")
    m = _mc(runs=6, tol={})
    is_true(m.dists["fc"].sigma > 0, "默认容差下 σ 必须大于 0")
    eff0 = MC.resolve_tol(tol=_ZERO)
    is_true(all(v == 0 for v in eff0.values()), f"显式全 0 才是真关掉，实际 {eff0}")


# ==========================================================================
# 2. σ 随容差单调增大
# ==========================================================================
@case(group="montecarlo")
def test_sigma_grows_monotonically_with_tolerance():
    """容差 0 → 0.2% → 1% → 3%，σ(fc) 必须严格递增。

    理论：σ_fc/fc = √(σ_R² + σ_C²)（fc ∝ 1/(RC)），所以 R/C 同容差 t 时
    σ_fc ≈ t·√2·fc。这里既检查单调性，也检查量级。
    """
    sig = []
    for t in (0.0, 0.002, 0.01, 0.03):
        m = _mc(runs=10, tol={"R": t, "C": t})
        s = m.dists["fc"].sigma
        is_true(math.isfinite(s), f"tol={t} 时 σ 应为有限值")
        sig.append(s)
    for a, b in zip(sig, sig[1:]):
        is_true(b > a * 1.5, f"σ 未随容差增大：{sig}")
    # 量级核对：t=1% 时 σ_fc/fc 应约 √2% = 1.41%
    ratio = sig[2] / 995.0
    is_true(0.010 <= ratio <= 0.020,
            f"tol=1% 时 σ_fc/fc 应约 1.4%，实际 {ratio * 100:.2f}%（σ={sig})")


@case(group="montecarlo")
def test_preset_precision_reduces_spread():
    """采购档次预设：standard(1%/5%) > precision(0.1%/1%) > tight 的分布宽度。"""
    spreads = {}
    for preset in ("standard", "precision", "tight"):
        m = _mc(runs=10, preset=preset)
        spreads[preset] = m.dists["fc"].sigma
    is_true(spreads["standard"] > spreads["precision"] > spreads["tight"],
            f"档次越精密 σ 越小，实际 {spreads}")
    close(MC.resolve_tol(preset="precision")["R"], 0.001, 0.01, what="preset precision 的 R 容差")


# ==========================================================================
# 3. 成品率：范围、账目、对设计位置的敏感性
# ==========================================================================
@case(group="montecarlo")
def test_yield_in_range_and_accounting():
    """成品率必须在 0~100；ok_runs ≤ runs ≤ 请求次数；runs+failures = 请求次数。

    分母语义（2026-11 修正）：yield_pct 的分母是 runs+failures（总请求数）——
    扰动到不收敛区的样本物理上大概率超标，剔出分母会系统性高估成品率。
    """
    m = _mc(runs=12)
    is_true(0.0 <= m.yield_pct <= 100.0, f"成品率越界：{m.yield_pct}")
    is_true(m.runs <= 12, f"成功次数不能超过请求次数：{m.runs} > 12")
    is_true(m.ok_runs <= m.runs, f"达标次数不能超过成功次数：{m.ok_runs} > {m.runs}")
    is_true(m.runs + m.failures == 12,
            f"账目必须对得上：runs {m.runs} + failures {m.failures} ≠ 12")
    is_true(math.isclose(m.yield_pct, 100.0 * m.ok_runs / (m.runs + m.failures)),
            f"yield_pct 应由 ok_runs/(runs+failures) 算出："
            f"{m.yield_pct} vs {m.ok_runs}/{m.runs + m.failures}")


@case(group="montecarlo")
def test_yield_drops_as_design_approaches_spec_boundary():
    """同一个需求（vout=2.5V，容差 ±2%）下的三个设计点：

        居中 (R1=R2=5k,   vout=2.50) → 成品率应接近 100%
        贴边 (4.9k/5.1k,  vout=2.55, 恰好卡在上边界) → 应显著下降
        越界 (4.8k/5.2k,  vout=2.60, +4%) → 应接近 0%

    这条是容差分析的**存在理由**：成品率必须对"设计点离边界多远"敏感。
    """
    y = {}
    for label, r1, r2 in [("centered", 5e3, 5e3), ("edge", 4.9e3, 5.1e3), ("outside", 4.8e3, 5.2e3)]:
        m = MC.monte_carlo(T.get("divider"), {"R1": r1, "R2": r2, "Vin": 5.0},
                           {"vout": 2.5}, runs=30)
        y[label] = m.yield_pct
        # 顺手核对：三个方案的 σ 应该几乎一样（同样的元件容差），差别只在中心位置
    # ⚑ 门槛从 90% 调到 85%，**不是为了让测试过**，而是模型变诚实了：
    # 早先 `DEFAULT_TOL["Vin"] = 0.0` 把电源当绝对理想，分压器的 vout 又正比于 Vin，
    # 于是成品率系统性虚高（实测同一设计点 98.3% → 53.3%(Vin±2%) → 25.0%(±5%)）。
    # 现在 Vin 按 1% 计入，居中设计实测 87%，这才是诚实的数字。
    is_true(y["centered"] >= 85.0, f"居中设计成品率应 ≥85%，实际 {y['centered']:.0f}%")
    # 钉死新事实：Vin 的容差必须**真的**在起作用（把 Vin 钉死时成品率应明显更高）。
    # 这条防的是「有人图省事又把 Vin 的容差改回 0」——那会让成品率再次虚高。
    m_ideal = MC.monte_carlo(T.get("divider"), {"R1": 5e3, "R2": 5e3, "Vin": 5.0},
                             {"vout": 2.5}, runs=30, tol={"R": 0.01, "C": 0.05, "Vin": 0.0})
    is_true(m_ideal.yield_pct >= y["centered"] + 5.0,
            f"Vin 钉死时成品率应明显更高（实际 {m_ideal.yield_pct:.0f}% vs "
            f"{y['centered']:.0f}%）——否则说明 Vin 的容差没被计入")
    is_true(y["edge"] < y["centered"] - 10.0,
            f"贴边设计必须明显低于居中：{y['edge']:.0f}% vs {y['centered']:.0f}%")
    is_true(y["outside"] <= 10.0, f"标称值已越界时成品率应 ≤10%，实际 {y['outside']:.0f}%")
    is_true(y["outside"] < y["edge"], f"越界必须比贴边更差：{y}")


@case(group="montecarlo")
def test_weakest_metric_is_identified():
    """成品率被哪个指标拉下来，必须能报出来（报告要用它给整改建议）。"""
    m = MC.monte_carlo(T.get("divider"), {"R1": 4.8e3, "R2": 5.2e3, "Vin": 5.0},
                       {"vout": 2.5}, runs=10)
    weak = m.weakest()
    is_true(weak is not None and weak[0] == "vout",
            f"应指出短板是 vout，实际 {weak}")
    is_true("成品率" in m.verdict(), f"结论文本应含成品率，实际 {m.verdict()!r}")


@case(group="montecarlo")
def test_absurd_tolerance_does_not_fake_a_good_yield():
    """容差荒谬（±300% 电容）时：仿真可以失败/失真，但绝不能算出高成品率。"""
    m = _mc(runs=10, tol={"R": 0, "C": 3.0})
    is_true(math.isfinite(m.yield_pct), "成品率必须是有限值")
    is_true(m.yield_pct <= 50.0,
            f"元件离谱时成品率不该还高：{m.yield_pct:.0f}%（说明扰动没真正作用到电路上）")


# ==========================================================================
# 4. 可复现性
# ==========================================================================
@case(group="montecarlo")
def test_same_seed_is_reproducible():
    """同一个 seed 必须给出逐点相同的样本；不同 seed 必须不同。"""
    a = _mc(runs=6, seed=12345)
    b = _mc(runs=6, seed=12345)
    c = _mc(runs=6, seed=54321)
    is_true(a.dists["fc"].values == b.dists["fc"].values, "同 seed 两次结果必须完全一致")
    is_true(a.dists["fc"].values != c.dists["fc"].values, "不同 seed 应给出不同样本")
    is_true(a.yield_pct == b.yield_pct, "同 seed 成品率必须一致")


@case(group="montecarlo")
def test_default_seed_is_stable_across_calls():
    """不传 seed 也要可复现（默认 seed 固定），否则评审无法复核。"""
    a = _mc(runs=6)
    b = _mc(runs=6)
    is_true(a.dists["fc"].values == b.dists["fc"].values,
            "默认 seed 应固定，两次调用结果必须一致")


# ==========================================================================
# 5. 容差表的解析（三层叠加 + 逐项覆盖）
# ==========================================================================
@case(group="tol_table")
def test_tolerance_resolution_layers():
    """默认 → preset → tol → tol_overrides 的优先级。"""
    base = MC.resolve_tol()
    is_true(base["R"] == 0.01 and base["C"] == 0.05, f"默认档应为 R1%/C5%，实际 {base}")
    pre = MC.resolve_tol(preset="precision")
    is_true(pre["R"] == 0.001, f"precision 档 R 应为 0.1%，实际 {pre['R']}")
    explicit = MC.resolve_tol(preset="precision", tol={"C": 0.02})
    is_true(explicit["R"] == 0.001, "显式 tol 不应覆盖没提到的 preset 项")
    is_true(explicit["C"] == 0.02, f"显式 tol 应覆盖 preset，实际 {explicit['C']}")
    ov = MC.resolve_tol(tol={"R": 0.01}, overrides={"R1": 0.001})
    is_true(ov["R"] == 0.01 and ov["R1"] == 0.001, f"逐项覆盖应并存，实际 {ov}")


@case(group="tol_table")
def test_tolerance_from_user_text():
    """从用户原话里提取容差线索：「0.1% 电阻」→ R=0.001。"""
    t = MC.tol_from_text("希望用 0.1% 的精密电阻，电容就普通的")
    is_true(t.get("R") == 0.001, f"应识别出 0.1% 电阻，实际 {t}")
    t2 = MC.tol_from_text("电容用 5% 的")
    is_true(abs(t2.get("C", 0) - 0.05) < 1e-12, f"应识别出 5% 电容，实际 {t2}")
    is_true(MC.tol_from_text("做一个1kHz低通") == {}, "没提容差时不该瞎猜")


@case(group="tol_table")
def test_tolerance_from_spec_keys():
    """规格里的 tol_R / tol_R1 / precision 三种写法。"""
    t = MC.tol_from_spec({"tol_R": 0.001, "tol_C2": 0.01})
    is_true(t.get("R") == 0.001 and t.get("C2") == 0.01, f"应解析出逐项容差，实际 {t}")
    t2 = MC.tol_from_spec({"precision": "precision"})
    is_true(t2.get("R") == 0.001, f"preset 字符串应展开，实际 {t2}")


@case(group="tol_table")
def test_percentage_string_tolerance_is_accepted():
    """tol={"R": "0.1%"} 这种人类写法应被接受（docstring 里承诺了）。"""
    t = MC.resolve_tol(tol={"R": "0.1%"})
    is_true(abs(t["R"] - 0.001) < 1e-12, f"'0.1%' 应解析成 0.001，实际 {t['R']}")


# ==========================================================================
# 6. 扰动的物理自检
# ==========================================================================
@case(group="montecarlo")
def test_perturbation_actually_reaches_the_netlist():
    """扰动必须真的改变了被仿真的电路（而不是只改了统计用的标签）。

    fc ∝ 1/(RC) 是单调关系：R 单独抖动时 fc 的分布应有明确的相对宽度，
    并且均值几乎不变（高斯扰动是零均值的）。
    """
    # 位置用中位数核对：fc ∝ 1/R 是右偏分布，少量样本的算术均值本身有 ±1.3% 标准误，
    # 用均值会把采样噪声当成偏差。中位数才是「零均值相对扰动」的不动点。
    m1 = _mc(runs=14, tol={"R": 0.05, "C": 0.0})
    nominal = 1.0 / (2 * math.pi * 1.6e3 * 100e-9)
    close(m1.dists["fc"].p50, nominal, 0.03, what="R±5% 时 fc 中位数（应≈标称值）")
    rel = m1.dists["fc"].sigma / nominal
    is_true(0.030 <= rel <= 0.070, f"R±5% 时 σ_fc/fc 应≈5%，实际 {rel * 100:.2f}%")

    # 更强的一条（无采样噪声）：同 seed 下容差翻倍，σ 必须恰好翻倍。
    # 若扰动没有线性作用到网表上（例如被截断/被吸到标称值），这条立刻失败。
    m2 = _mc(runs=14, tol={"R": 0.10, "C": 0.0})
    ratio = m2.dists["fc"].sigma / m1.dists["fc"].sigma
    close(ratio, 2.0, 0.10, what="σ(容差10%)/σ(容差5%)")


@case(group="montecarlo")
def test_monte_carlo_survives_extreme_params():
    """容差把参数推到极端值（含负值）时不能抛异常把整次分析打断。"""
    m = MC.monte_carlo(T.get("rc_lowpass"), {"R": 1.0, "C": 1e-12}, {"fc": 1e3}, runs=8, tol={"R": 0.9, "C": 0.9})
    is_true(m.runs + m.failures == 8, f"账目不平：{m.runs}+{m.failures}")
    is_true(math.isfinite(m.yield_pct) or m.runs == 0, "成品率要么有限，要么确实没有有效样本")


if __name__ == "__main__":
    summary = H.run(module="test_tolerance")
    print(H.report(summary, "容差分析汇总"))
    sys.exit(0 if summary.ok else 1)
