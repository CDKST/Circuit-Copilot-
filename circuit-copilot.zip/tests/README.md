# Circuit Copilot · 测试与验证套件

这个目录守的是项目的**唯一可信度**：仿真出来的数字与物理公式是一致的。

原则：**不允许「仿真跑通了就算过」的断言。** 每一条检查都写成

```
实测值  vs  解析式  →  相对误差  →  与容差比较
```

---

## 一键运行

```bash
cd /storage/emulated/0/文件夹/dz/circuit-copilot
python3 tests/run_all.py            # 全部（约 2.5 分钟，含 ~800 次 ngspice 仿真）
python3 tests/run_all.py physics    # 只跑物理正确性
python3 tests/run_all.py --strict   # 已知缺陷也算失败（发版闸门前用）
python3 tests/test_physics.py       # 单个模块，会打印物理核对表
```

只用标准库，**不需要 pytest**，不需要 pip install。依赖：Python 3.14 + ngspice-47。

退出码：`0` = 没有「意外」失败；`1` = 有意外失败（`--strict` 下含已知缺陷）。

## 文件

| 文件 | 内容 | 用例数 | 耗时 |
|---|---|---|---|
| `_harness.py` | 极简框架：注册、断言、PASS/FAIL/SKIP、known_bug 分类、耗时统计 | — | — |
| `test_judge.py` | **判定容差语义**（rel/abs、eq/min/max、闭区间）+ 成品率回归 | 17 | ~5s |
| `test_physics.py` | **物理正确性**：10 个拓扑 × 解析公式核对 + 核对表 | 37 | ~15s |
| `test_robust.py` | 坏网表、极端参数、无解需求、BOM、拓扑契约 | 22 | ~17s |
| `test_tolerance.py` | 蒙特卡洛：方差/单调性/成品率/可复现/容差表解析 | 16 | ~35s |
| `test_e2e.py` | 15 条真实中文需求走完整 `agent.run(use_llm=False)` | 15 | ~75s |
| **合计** | | **107** | **~150s** |

`test_all.py` / `test_agent.py` 是早期的人眼核对脚本（打印指标给人看），保留未动。

## 两个约定

**1. `known_bug="B3|说明…"`**
当断言的是「物理上正确的行为」而代码给出错的结果时，**不放宽断言**，而是打标记。
分类规则：

- 🐞 已知缺陷 —— 断言严格，代码当前不满足；修好后用例自动变 🎉（提醒摘标记）
- ❌ 意外失败 —— 新问题，没有登记，必须立刻查
- ⏭️ 跳过 —— 环境不满足或拓扑未实现（如队友的拓扑还没注册时）

编号在 `tests/` 内全局唯一，同一根因在多个模块复现时共用同一个编号（报告会合并）。

**2. 独立实现取数**
`test_physics.py` 里的 `_db_at / _phase_cross / _slope` 是自己写的插值，
**故意不调用** `topologies.py` 里的同名 helper —— 否则「提取函数算错」和
「插值函数算错」会互相掩盖，测试就变成自证。

## 物理核对表（`test_physics.py` 的输出）

每个拓扑都对着解析式核对，容差按「能物理保证的精度」设定（不是按 bug 现状凑的）：

| 拓扑 | 核对项 | 解析式 / 判据 | 容差 |
|---|---|---|---|
| `rc_lowpass` | fc | 1/(2πRC) | 1% |
| | 滚降 | 10fc→100fc 斜率 | −20±2 dB/dec |
| | 渐近 | 0dB @低频，−60dB @1000fc，atten_db≈20dB @10fc | 0.5%/2%/5% |
| `rc_highpass` | fc / 滚降 / 渐近 | 同上对偶（+20dB/dec） | 同 |
| `rlc_bandpass` | f0 | 1/(2π√(LC)) | 3% |
| | Q | (1/R)√(L/C) | 3% |
| | 峰值 / bw | \|H(f0)\|=0dB；bw=f0/Q | 15% / 5% |
| `divider` | vout | Vin·R2/(R1+R2) | 0.5% |
| | iout/rout/power | 解析式 | 1e-7% |
| `opamp_noninverting` | 增益 | 1+R2/R1 | 1% |
| | 闭环带宽 | 实测 ∈ [0.7, 1.1]×GBW/gain | 区间 |
| | 相位裕度 | 单极点 ≈90° | 60~95° |
| | ugf | ≈GBW | 5%（低增益 20%） |
| `opamp_inverting` | \|增益\| / 相位 | R2/R1，±180° | 1% / 5° |
| | 闭环带宽 | GBW/(1+R2/R1)（**噪声增益**，不是 \|A\|） | 0.7~1.1× |
| `sallen_key_lowpass` | f0 | 1/(2π√(R1R2C1C2)) | 3% |
| | Q | √(R1R2C1C2)/(C2(R1+R2)) | 3% |
| | fc | f0·√(u+√(u²+1))，u=1−1/(2Q²) | 3% |
| | 滚降/峰值 | −40dB/dec；\|H(f0)\|=Q | 3dB / 3% |
| `sallen_key_highpass` | f0 | 1/(2π√(R1R2C1C2)) | 3% |
| | Q | √(R1R2C1C2)/(R1(C1+C2)) | 3% |
| | 滚降/平台 | +40dB/dec；通带 0dB | 3dB / 1% |
| `difference_amp` | Ad | R2/R1 | 1% |
| | CMRR | 匹配≈运放自身 CMRR；失配=R4/(R3+R4)式 | 2% |
| | 总 CMRR | 1/CMRR=1/电阻项+1/运放项 | 0.5% |
| `filter_lowpass_synth` | fc | 整机 −3dB 落在 fc（三种响应 × 2/4/6 阶） | 10% |
| | Butterworth | 通带最平坦（峰化 0dB）；2fc 处衰减 = 6N dB | 0.3dB / 0.8dB |
| | Bessel | 无峰化；同阶选择性弱于 Butterworth | 0.15dB |
| | Chebyshev | 通带波纹 = 规格 ripple_db | 0.35dB |

`test_physics.py` 里还写下了两个**反直觉结论**的推导过程（注释形式），
它们是这套拓扑最容易写错的地方：

1. **SK 高通**的 `Q = √(R1R2C1C2)/(R1(C1+C2))`，分母是 `R1` 而不是 `R1+R2`；
   `R1=R2=R` 时 `Q=√(C1C2)/(C1+C2) ≤ 0.5`，**无论怎么配电容都上不去**。
2. **反相放大**的闭环带宽用**噪声增益** `1+R2/R1`，不是 `|A|=R2/R1`——
   10 倍反相放大的带宽是 GBW/11，不是 GBW/10。

## 已知缺陷清单

见 `run_all.py` 的汇总输出（按编号分组）。每条都带可复现用例名。

## 加新拓扑时要做的事

1. `tests/test_robust.py::test_design_returns_all_declared_params` 的 `specs` 表里登记目标规格
2. `tests/test_physics.py` 加一节解析式核对（`require("id")` 会在拓扑不存在时自动跳过）
3. 拓扑参数里如果有 `enum` 类型的（阶数、响应类型），`tests` 里的 `full_params()`
   会用几何中值补参数 —— 已对 enum 做「取最小合法值」处理，新拓扑请复用
4. 新指标要同时进 `METRICS` + `SPEC_RULE`，否则
   `test_judge.py::test_every_topo_metric_has_a_rule` 会红（这是防止「静默用默认容差」的闸门）
