"""端到端回归 —— 真实中文需求 → 完整 agent.run(use_llm=False) 闭环。

这条链路是用户真正看到的东西：
    中文需求 → 选拓扑 → 数值搜索 → ngspice 仿真 → 判定 → 评审文字

所以端到端断言检查的不只是"没报错"，而是这四件事必须同时成立：
    1. 没有 error（不是崩在中间）
    2. 物理上可行的需求，passed 必须为 True（真的找到了达标方案）
    3. 元件值必须是 E 系列标称值（用户能买到；用 elements.py 反查）
    4. 物理上做不到的需求，passed 必须为 False 且评审里有解释（不能假装达标）

use_llm=False 是默认部署形态（本机没配 Key 时走的就是这条路），
所以规则解析器的行为就是用户实际体验到的行为 —— 解析错也是产品 bug。

单独运行：  python3 tests/test_e2e.py
"""

from __future__ import annotations

import math
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import _harness as H  # noqa: E402
from _harness import Skip, case, close, is_true  # noqa: E402

from copilot import agent, elements as E  # noqa: E402
from copilot import topologies as T  # noqa: E402

_SESSIONS: dict[str, agent.Session] = {}


def session(request: str) -> agent.Session:
    """跑一次完整闭环（同一条需求只跑一次，多个断言共用）。"""
    if request not in _SESSIONS:
        _SESSIONS[request] = agent.run(request, use_llm=False)
    return _SESSIONS[request]


# --------------------------------------------------------------------------
# 断言工具
# --------------------------------------------------------------------------
def is_eseries(value: float, series: str) -> bool:
    """用 elements.py 反查：value 是否正好是某个 E 系列标称值。"""
    if not math.isfinite(value) or value <= 0:
        return False
    # 反查法一：snap 回来还是自己
    if abs(E.snap(value, series) - value) <= abs(value) * 1e-9:
        return True
    # 反查法二：尾数直接落在系列表里（防 snap 的跨 decade 分支误判）
    decade = math.floor(math.log10(value) + 1e-12)
    scaled = value / 10 ** decade
    return any(abs(scaled - b) <= b * 1e-9 for b in E.SERIES[series])


def check_contract(s: agent.Session, expect_pass: bool) -> None:
    """所有端到端用例共用的硬约束。"""
    is_true(not s.error, f"不该报错，实际 error={s.error!r}")
    is_true(s.best is not None, "必须产出设计方案")
    is_true(bool(s.rows), "必须有判定行")
    is_true(bool(s.review), "必须有评审文字")
    is_true(s.total_sims > 0, "至少要真的仿真过一次")

    # 每个指标都必须是可比较的数（NaN 会让判定悄悄失效）
    for r in s.rows:
        is_true(math.isfinite(r.actual), f"指标 {r.key} 实测值不是有限数：{r.actual!r}")

    # 元件值必须是可采购的 E 系列标称值
    topo = T.get(s.topology)
    for prm in topo.params:
        v = s.best.params.get(prm.name)
        is_true(v is not None, f"缺少参数 {prm.name}")
        is_true(prm.lo <= v <= prm.hi, f"{prm.name}={v} 越出 [{prm.lo},{prm.hi}]")
        if prm.series:
            is_true(is_eseries(v, prm.series),
                    f"{prm.name}={v} 不是 {prm.series} 标称值（用户买不到）")

    if expect_pass:
        is_true(s.passed, "该需求物理上可行，应判达标；未达标的项："
                          + "；".join(f"{r.key} 目标{r.target:.6g}/实测{r.actual:.6g}"
                                      for r in s.rows if not r.ok))
    else:
        is_true(not s.passed, "该需求应判未达标，实际却报达标")


# ==========================================================================
# A. 物理上可行、必须达标的真实需求
# ==========================================================================
REQ_RC_LP = "做一个1kHz的RC低通滤波器"
REQ_RC_HP = "设计一个10kHz的RC高通滤波器，用于音频耦合"
REQ_DIV = "把5V分压到2.5V给ADC采样"
REQ_OPAMP_BW = "10倍同相放大器，需要100kHz带宽"
REQ_SK = "二阶低通，截止1kHz，Q=0.707"
REQ_RC_HF = "设计截止频率10MHz的RC低通"
REQ_OPAMP_DB = "设计一个增益为20dB的同相放大器"
REQ_RLC = "中心频率100kHz、Q=50的带通滤波"
REQ_VAGUE = "做一个低通滤波器"


@case(group="e2e_pass")
def test_e2e_rc_lowpass_1khz():
    """「1kHz RC 低通」：拓扑正确、fc 落在 ±10% 判定容差内、元件是标称值。"""
    s = session(REQ_RC_LP)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "rc_lowpass", f"应选 rc_lowpass，实际 {s.topology}")
    row = next(r for r in s.rows if r.key == "fc")
    close(row.actual, 1000.0, 0.10, what="fc")


@case(group="e2e_pass")
def test_e2e_rc_highpass_10khz():
    s = session(REQ_RC_HP)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "rc_highpass", f"应选 rc_highpass，实际 {s.topology}")
    close(next(r for r in s.rows if r.key == "fc").actual, 1e4, 0.10, what="fc")


@case(group="e2e_pass")
def test_e2e_divider_5v_to_2v5():
    s = session(REQ_DIV)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "divider", f"应选 divider，实际 {s.topology}")
    close(next(r for r in s.rows if r.key == "vout").actual, 2.5, 0.02, what="vout")


@case(group="e2e_pass")
def test_e2e_opamp_noninverting_10x_100khz():
    """10 倍同相放大 + 100kHz 带宽（带宽是「不低于」型指标）。"""
    s = session(REQ_OPAMP_BW)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "opamp_noninverting", f"应选同相放大，实际 {s.topology}")
    g = next(r for r in s.rows if r.key == "gain_lin")
    close(g.actual, 10.0, 0.05, what="gain_lin")
    bw = next(r for r in s.rows if r.key == "fc")
    is_true(bw.actual >= 100e3, f"闭环带宽应 ≥100kHz，实测 {bw.actual:.0f}Hz")


@case(group="e2e_pass")
def test_e2e_sallen_key_1khz_q():
    s = session(REQ_SK)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "sallen_key_lowpass", f"应选 SK 低通，实际 {s.topology}")
    close(next(r for r in s.rows if r.key == "fc").actual, 1e3, 0.10, what="fc")
    close(next(r for r in s.rows if r.key == "q").actual, 0.707, 0.15, what="Q")


@case(group="e2e_pass")
def test_e2e_rc_lowpass_10mhz():
    """10MHz 低通：已经接近扫频上限，仍应达标（边界但合法）。"""
    s = session(REQ_RC_HF)
    check_contract(s, expect_pass=True)
    close(next(r for r in s.rows if r.key == "fc").actual, 1e7, 0.10, what="fc")


@case(group="e2e_pass")
def test_e2e_opamp_gain_db_spec():
    """按 dB 给增益（20dB）：解析成 gain_db，且实测 20.0dB。"""
    s = session(REQ_OPAMP_DB)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "opamp_noninverting", f"应选同相放大，实际 {s.topology}")
    is_true("gain_db" in s.spec, f"规格里应有 gain_db，实际 {s.spec}")
    close(next(r for r in s.rows if r.key == "gain_db").actual, 20.0, 0.05, what="gain_db")


@case(group="e2e_pass")
def test_e2e_rlc_bandpass_q50():
    """带通 f0=100kHz、Q=50：Q 的测量在中等 Q 下仍可信（容差 15%）。"""
    s = session(REQ_RLC)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "rlc_bandpass", f"应选 RLC 带通，实际 {s.topology}")
    close(next(r for r in s.rows if r.key == "f0").actual, 1e5, 0.10, what="f0")
    close(next(r for r in s.rows if r.key == "q").actual, 50.0, 0.15, what="Q")


@case(group="e2e_pass")
def test_e2e_vague_request_uses_sane_default():
    """没给任何数字的需求也要给出一份可用设计（不能崩、不能空转）。"""
    s = session(REQ_VAGUE)
    check_contract(s, expect_pass=True)
    is_true(s.topology == "rc_lowpass", f"模糊的「低通」应默认一阶 RC，实际 {s.topology}")


# ==========================================================================
# B. 物理上做不到的需求 —— 必须判未达标并解释
# ==========================================================================
REQ_ATTEN = "一阶RC低通，截止1kHz，要求阻带衰减60dB"


@case(group="e2e_fail")
def test_e2e_impossible_attenuation_is_not_reported_as_pass():
    """一阶 RC 给不出 60dB 阻带衰减：必须判未达标，且评审要解释。

    注意：本条只检查"结论正确"（未达标）与"有解释"，不检查解释是否点对了指标 ——
    那是下一条 known_bug 用例的事。
    """
    s = session(REQ_ATTEN)
    is_true(not s.error, f"不该报错：{s.error}")
    is_true(not s.passed, "一阶 RC 不可能达到 60dB 阻带衰减，必须判未达标")
    is_true(len(s.review) > 50, "未达标时必须给出解释，不能只丢一个结论")
    is_true(("未达标" in s.review) or ("无解" in s.review), "评审要明确写出未达标/无解")


@case(group="e2e_fail")
def test_e2e_attenuation_requirement_maps_to_atten_db():
    """「衰减 60dB」必须进入 atten_db 指标，而不是 gain_db。"""
    s = session(REQ_ATTEN)
    is_true("atten_db" in s.spec,
            f"「阻带衰减60dB」应解析成 atten_db，实际规格是 {s.spec}")
    is_true("gain_db" not in s.spec,
            f"「衰减」不是「增益」，不该产生 gain_db，实际规格是 {s.spec}")


# ==========================================================================
# C. 已知缺陷：解析/设计式错误导致合法需求做不到（严格断言 + 标记）
# ==========================================================================
REQ_DIV_33 = "把12V分压到3.3V"


@case(group="e2e_bug")
def test_e2e_divider_output_voltage_parsed_from_natural_phrase():
    """「把12V分压到3.3V」必须得到 3.3V 输出，而不是 12/2=6V。"""
    s = session(REQ_DIV_33)
    is_true(not s.error, f"不该报错：{s.error}")
    row = next(r for r in s.rows if r.key == "vout")
    close(row.actual, 3.3, 0.02, what="用户要的分压输出 vout")


REQ_INV = "设计一个10倍的反相放大器"


@case(group="e2e_bug")
def test_e2e_inverting_10x_can_be_met():
    """「10 倍反相放大器」必须做到 10 倍（误差 ≤1%），而不是勉强落在 ±5% 判定带里。

    为什么用 1% 而不是「判达标即可」：1.00kΩ 与 10.0kΩ 都是 E96 标称值，
    这个需求在标准件上**精确可解**，没有任何理由给出 9.54 倍这样的结果。
    把标准卡在 1%，才能逼出根因（design() 用错公式），而不是被 ±5% 判定容差掩盖。
    """
    s = session(REQ_INV)
    is_true(not s.error, f"不该报错：{s.error}")
    row = next(r for r in s.rows if r.key == "gain_lin")
    close(row.actual, 10.0, 0.01, what="反相放大的实际增益")


REQ_1HZ = "做一个1Hz的低通滤波器"


@case(group="e2e_bug")
def test_e2e_1hz_lowpass_can_be_met():
    """「1Hz 低通」是合法需求：1.6MΩ + 100nF 即可，必须判达标。"""
    s = session(REQ_1HZ)
    is_true(not s.error, f"不该报错：{s.error}")
    is_true(s.passed, "1Hz 低通应可达标；未达标项："
                      + "；".join(f"{r.key} 目标{r.target:.6g}/实测{r.actual:.6g}"
                                  for r in s.rows if not r.ok))


# ==========================================================================
# D. 拓扑选择的可达性（新拓扑能不能被规则解析器选中）
# ==========================================================================
@case(group="e2e_pass")
def test_rule_parser_can_select_new_topologies():
    """规则解析器要能把「二阶高通 / Sallen-Key 高通 / 差分放大」映射到正确的拓扑。

    历史上这里有一处真实缺陷（已由队友修复，保留为回归用例）：
    关键词顺序让「二阶高通」命中 rc_highpass（一阶）、「Sallen-Key高通」命中
    sallen_key_lowpass（低通）、「差分放大器」命中 opamp_noninverting（单端）——
    在 use_llm=False 的部署形态下，3 个新拓扑等于完全不可达，
    用户会拿到拓扑完全不同的电路却被报「全部达标」。
    """
    cases = [
        ("设计一个二阶高通滤波器，截止频率1kHz", "sallen_key_highpass"),
        ("Sallen-Key高通，截止频率100Hz", "sallen_key_highpass"),
        ("差分放大器，增益10倍", "difference_amp"),
        ("做一个减法器，增益5倍", "difference_amp"),
    ]
    got = {req: agent.parse_rules(req)["topology"] for req, _ in cases}
    wrong = {req: (got[req], want) for req, want in cases if got[req] != want}
    H.is_true(not wrong, f"拓扑映射错误（实际, 期望）：{wrong}")


if __name__ == "__main__":
    summary = H.run(module="test_e2e")
    print(H.report(summary, "端到端回归汇总"))
    sys.exit(0 if summary.ok else 1)
