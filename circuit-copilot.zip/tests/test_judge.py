"""判定容差语义单元测试 —— 这是本项目最贵的一次 bug 的回归防线。

## 历史 bug（已修，但必须钉死）
`judge.check()` 曾经把 SPEC_RULE 里的**相对**容差在 `min`/`max` 模式下当**绝对**用：
    fc 目标 1000Hz、规则 10% → min 模式变成 `actual >= 1000 − 0.10 = 999.9`
于是 990.9Hz 判不合格，`sallen_key_lowpass`（1kHz/Q=0.707）的蒙特卡洛成品率
被算成 50%（真实 95%）。同一个根因还让 `gain_db` 的 ±0.6dB 变成 ±12dB。

现在规则显式带 `kind`（rel / abs），比较统一走允许区间 [lo, hi]。
本文件就是这套语义的"宪法"：任何改动如果破坏了下面任意一条，
都应该在 1 秒内被测试抓住。

单独运行：  python3 tests/test_judge.py
"""

from __future__ import annotations

import math
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import _harness as H  # noqa: E402
from _harness import case, close, is_false, is_true  # noqa: E402

from copilot import judge, tolerance as MC  # noqa: E402
from copilot import topologies as T  # noqa: E402


def rows_of(spec, metrics, overrides=None):
    return judge.check(spec, metrics, overrides)


def one(spec, metrics, overrides=None) -> judge.CheckRow:
    rows = rows_of(spec, metrics, overrides)
    is_true(len(rows) == 1, f"应产生 1 行判定，实际 {len(rows)} 行")
    return rows[0]


# ==========================================================================
# 1. fc：相对容差，eq 与 min 两种模式（历史 bug 的直接复现用例）
# ==========================================================================
@case(group="semantics")
def test_fc_eq_mode_is_relative_10_percent():
    """fc 目标 1000Hz：允许区间必须是 [900, 1100]，不是 [999.9, 1000.1]。"""
    r = one({"fc": 1000.0}, {"fc": 990.9})
    close(r.lo, 900.0, 1e-12, what="fc eq 下界")
    close(r.hi, 1100.0, 1e-12, what="fc eq 上界")
    is_true(r.kind == "rel", f"fc 应是相对容差，实际 kind={r.kind}")
    is_true(r.ok, "990.9Hz 在 ±10% 内，必须判合格（bug 修复的核心用例）")
    is_false(one({"fc": 1000.0}, {"fc": 1150.0}).ok, "1150Hz 超出 +10%，必须判不合格")


@case(group="semantics")
def test_fc_min_mode_is_still_relative():
    """fc 被 spec_overrides 改成 min 后，容差仍是相对的：λ 990.9Hz 合格、880Hz 不合格。"""
    r = one({"fc": 1000.0}, {"fc": 990.9}, {"fc": "min"})
    is_true(r.mode == "min" and r.kind == "rel", f"期望 min+rel，实际 {r.mode}+{r.kind}")
    close(r.lo, 900.0, 1e-12, what="fc min 下界")
    is_true(r.hi == math.inf, f"min 模式上界应为 inf，实际 {r.hi}")
    is_true(r.ok, "min 模式下 990.9Hz ≥ 900Hz，必须判合格")

    r2 = one({"fc": 1000.0}, {"fc": 880.0}, {"fc": "min"})
    is_false(r2.ok, "880Hz 低于 -10% 下界，必须判不合格")
    is_true(one({"fc": 1000.0}, {"fc": 1e6}, {"fc": "min"}).ok,
            "min 模式下远超目标必须判合格")


@case(group="semantics")
def test_bands_are_closed_intervals():
    """恰好等于 lo 或 hi 必须判合格（闭区间，不能因为浮点边界把合格判成不合格）。"""
    for target, tol in [(1000.0, 0.10), (2.5, 0.02), (0.707, 0.15), (9.0, 0.05)]:
        base = min(T.METRICS.keys() & judge.SPEC_RULE.keys(),
                   key=lambda k: abs(judge.SPEC_RULE[k].tol - tol))
        for edge in ("lo", "hi"):
            r = one({base: target}, {base: target})
            v = r.lo if edge == "lo" else r.hi
            if not math.isfinite(v):
                continue
            got = one({base: target}, {base: v})
            is_true(got.ok, f"{base}: 实测值恰好等于 {edge}={v} 时应判合格（%s）" % got.lo)
            # 再往外挪 1e-6 相对量就必须不合格（前提：不是 inf 上界）
            eps = abs(v) * 1e-6 if v else 1e-9
            out = v - eps if edge == "lo" else v + eps
            is_false(one({base: target}, {base: out}).ok,
                     f"{base}: 越过 {edge} 一点点（{out}）应判不合格")


# ==========================================================================
# 2. dB 类：绝对容差（这是第二个被修的 bug）
# ==========================================================================
@case(group="semantics")
def test_gain_db_uses_absolute_tolerance():
    """gain_db 目标 20dB：容差是 ±0.6dB（绝对），不是 ±0.6×20=±12dB。

    历史 bug：`max(|target|·tol, tol)` 让相对项接管，20dB 目标接受 8~32dB。
    """
    r = one({"gain_db": 20.0}, {"gain_db": 20.5})
    is_true(r.kind == "abs", f"gain_db 应是绝对容差，实际 kind={r.kind}")
    close(r.lo, 19.4, 1e-9, what="gain_db 下界")
    close(r.hi, 20.6, 1e-9, what="gain_db 上界")
    is_true(r.ok, "20.5dB 在 ±0.6dB 内，应合格")
    is_false(one({"gain_db": 20.0}, {"gain_db": 21.2}).ok, "21.2dB 超出 ±0.6dB，应不合格")
    is_false(one({"gain_db": 20.0}, {"gain_db": 31.0}).ok,
             "31dB（旧 bug 会判合格）现在必须不合格")
    # 负增益（反相放大按 -20dB 报）也要同样严格
    is_false(one({"gain_db": -20.0}, {"gain_db": -18.0}).ok, "-18dB 对 -20dB ±0.6 应不合格")


@case(group="semantics")
def test_atten_db_min_mode_is_absolute():
    """atten_db 目标 18dB（不低于）：容差 ±1dB 绝对。"""
    r = one({"atten_db": 18.0}, {"atten_db": 20.0})
    is_true(r.mode == "min" and r.kind == "abs", f"期望 min+abs，实际 {r.mode}+{r.kind}")
    close(r.lo, 17.0, 1e-12, what="atten_db 下界")
    is_true(r.ok, "20dB ≥ 17dB，应合格")
    is_false(one({"atten_db": 18.0}, {"atten_db": 16.5}).ok, "16.5dB < 17dB，应不合格")


@case(group="semantics")
def test_peaking_db_max_mode_is_absolute():
    """peaking_db 是「不高于」，绝对容差 0.6dB。"""
    r = one({"peaking_db": 1.0}, {"peaking_db": 1.5})
    is_true(r.mode == "max" and r.kind == "abs", f"期望 max+abs，实际 {r.mode}+{r.kind}")
    close(r.hi, 1.6, 1e-12, what="peaking_db 上界")
    is_true(r.ok, "1.5dB ≤ 1.6dB，应合格")
    is_false(one({"peaking_db": 1.0}, {"peaking_db": 1.7}).ok, "1.7dB 超上限，应不合格")


@case(group="semantics")
def test_pm_min_mode_is_absolute_degrees():
    """相位裕度：不低于（且绝对度数）。"""
    is_true(one({"pm": 60.0}, {"pm": 55.0}).ok, "55° ≥ 60−5，应合格")
    is_false(one({"pm": 60.0}, {"pm": 54.0}).ok, "54° < 55，应不合格")


# ==========================================================================
# 3. 无量纲与相对类指标
# ==========================================================================
@case(group="semantics")
def test_q_is_relative():
    """Q 目标 0.707、相对 15%：区间 [0.60095, 0.81305]。"""
    r = one({"q": 0.707}, {"q": 0.7388})
    is_true(r.kind == "rel", f"q 应是相对容差，实际 {r.kind}")
    close(r.lo, 0.707 * 0.85, 1e-9, what="q 下界")
    close(r.hi, 0.707 * 1.15, 1e-9, what="q 上界")
    is_true(r.ok, "0.7388 在 ±15% 内，应合格")
    is_false(one({"q": 0.707}, {"q": 0.90}).ok, "0.90 超出 +15%，应不合格")


@case(group="semantics")
def test_vout_and_gain_lin_are_relative():
    is_true(one({"vout": 2.5}, {"vout": 2.45}).ok, "vout 2.45 在 ±2% 边界上，应合格")
    is_false(one({"vout": 2.5}, {"vout": 2.4499}).ok, "刚越过 -2%，应不合格")
    is_true(one({"gain_lin": 10.0}, {"gain_lin": 10.49}).ok, "增益 10.49 在 ±5% 内，应合格")
    is_false(one({"gain_lin": 10.0}, {"gain_lin": 10.51}).ok, "增益 10.51 超出 +5%，应不合格")


@case(group="semantics")
def test_power_and_rout_max_are_relative():
    """功耗/输出阻抗上限是相对目标（15% / 20%），不是绝对值。"""
    r = one({"power": 1e-3}, {"power": 1.1e-3})
    is_true(r.mode == "max" and r.kind == "rel", f"期望 max+rel，实际 {r.mode}+{r.kind}")
    close(r.hi, 1.15e-3, 1e-15, what="power 上限")
    is_true(r.ok, "1.1mW ≤ 1.15mW，应合格")
    is_false(one({"power": 1e-3}, {"power": 1.2e-3}).ok, "1.2mW 超上限，应不合格")
    is_false(one({"rout": 5e3}, {"rout": 6.5e3}).ok, "rout 超 +20%，应不合格")


# ==========================================================================
# 4. 规则表的策略自检：单位 ←→ 容差类型不能配错
# ==========================================================================
@case(group="policy")
def test_tolerance_kind_matches_unit():
    """凡是 dB / 角度指标必须是 abs；频率/倍数/电压/阻抗/功率必须是 rel。

    这是「防止下一个同类 bug」的元规则：以后谁加了新指标却配错 kind，
    这条会立刻红。
    """
    abs_units = {"dB", "°"}
    rel_units = {"Hz", "", "倍", "V", "A", "Ω", "W"}
    for key, rule in judge.SPEC_RULE.items():
        info = T.METRICS.get(key)
        is_true(info is not None, f"SPEC_RULE 里的 {key} 不在 METRICS 词表里")
        if info.unit in abs_units:
            is_true(rule.kind == "abs",
                    f"{key}({info.unit}) 必须用绝对容差 abs，实际 {rule.kind}（容差 {rule.tol}）")
        elif info.unit in rel_units:
            is_true(rule.kind == "rel",
                    f"{key}({info.unit}) 必须用相对容差 rel，实际 {rule.kind}（容差 {rule.tol}）")
        else:
            raise H.Fail(f"{key} 的单位 {info.unit!r} 没有登记容差类型，请先分类再写测试")
        is_true(rule.mode in ("eq", "min", "max"), f"{key}: 未知模式 {rule.mode}")
        is_true(rule.tol > 0, f"{key}: 容差必须为正")


@case(group="policy")
def test_every_topo_metric_has_a_rule():
    """每个拓扑 declared 的指标都必须有判定规则，不能落到默认值。"""
    for tid, topo in T.REGISTRY.items():
        for k in topo.metrics_keys:
            is_true(k in judge.SPEC_RULE, f"{tid}: 指标 {k} 没有显式规则（会静默用 eq/10% 默认值）")
            if k in topo.spec_overrides:
                is_true(topo.spec_overrides[k] in ("eq", "min", "max"),
                        f"{tid}.{k}: 未知 override {topo.spec_overrides[k]}")


@case(group="policy")
def test_missing_and_nan_are_never_ok():
    """指标缺失或 NaN 必须判不合格（不能让「没数据」变成「通过」）。"""
    is_false(judge.check({"fc": 1000.0}, {})[0].ok, "缺失指标应判不合格")
    is_false(judge.check({"fc": 1000.0}, {"fc": float("nan")})[0].ok, "NaN 应判不合格")
    is_true(judge.check({"不存在的指标": 1.0}, {"fc": 1.0}) == [], "未知指标键应被忽略")


# ==========================================================================
# 5. deviation / cost：搜索排序依赖的度量
# ==========================================================================
@case(group="cost")
def test_deviation_is_zero_inside_band():
    """区间内偏差为 0；区间外与超出量成正比（跨指标可相加，用于 cost 排序）。"""
    r = one({"fc": 1000.0}, {"fc": 1000.0})
    close(r.deviation(), 0.0, 1e-12, what="区间内 deviation")
    r2 = one({"fc": 1000.0}, {"fc": 1100.0})
    close(r2.deviation(), 0.0, 1e-12, what="上边界上 deviation")
    r3 = one({"fc": 1000.0}, {"fc": 1200.0})       # 超出 100Hz = 容差 100Hz 的 1 倍
    close(r3.deviation(), 1.0, 1e-9, what="超出 1 倍容差的 deviation")
    r4 = one({"fc": 1000.0}, {"fc": 700.0})       # 低于下界 200Hz = 2 倍容差
    close(r4.deviation(), 2.0, 1e-9, what="低于下界 2 倍容差的 deviation")
    is_true(one({"fc": 1000.0}, {"fc": float("nan")}).deviation() == math.inf,
            "NaN 的偏差应为 inf")


@case(group="cost")
def test_cost_orders_candidates():
    good = judge.check({"fc": 1000.0}, {"fc": 1000.0})     # 偏差 0
    mid = judge.check({"fc": 1000.0}, {"fc": 1200.0})      # 越过上界 1 倍容差
    bad = judge.check({"fc": 1000.0}, {"fc": 2000.0})      # 越过 10 倍容差（被 min(...,5) 截断）
    is_true(judge.cost(good) == (0, 0.0), f"完美命中应为 (0, 0.0)，实际 {judge.cost(good)}")
    is_true(judge.cost(good) < judge.cost(mid) < judge.cost(bad),
            f"cost 必须单调：{judge.cost(good)} / {judge.cost(mid)} / {judge.cost(bad)}")
    miss = judge.check({"fc": 1000.0, "q": 0.707}, {"fc": 1000.0, "q": 1.5})
    is_true(judge.cost(miss)[0] == 1, f"缺 1 项时未达标项数应为 1，实际 {judge.cost(miss)}")


# ==========================================================================
# 6. 回归：SK 低通成品率（修复前 50%，修复后应 ≥90%）
# ==========================================================================
@case(group="regression")
def test_regression_sk_lowpass_yield_after_tolerance_kind_fix():
    """Sallen-Key 低通（1kHz/Q=0.707）成品率必须 ≥90%。

    修复前：fc 的 min 模式把 10% 相对容差当成 0.1Hz 绝对容差，
    蒙特卡洛里 990.9Hz 被判不合格 → 成品率 50%。
    修复后实测 95%。这条断言就是那个 bug 的墓碑。
    """
    params = {"R1": 11.3e3, "R2": 11e3, "C1": 22e-9, "C2": 10e-9, "GBW": 1e6, "A0": 1e5}
    m = MC.monte_carlo(T.get("sallen_key_lowpass"), params, {"fc": 1000.0, "q": 0.707}, runs=20)
    is_true(m.runs == 20, f"20 次采样都应成功，实际 {m.runs}（失败 {m.failures}）")
    is_true(m.yield_pct >= 90.0,
            f"成品率应 ≥90%（修复前是 50%），实际 {m.yield_pct:.0f}%"
            f"；短板 {m.weakest()}")
    # 同时钉住设计点本身是达标的（成品率低不是因为标称值就不达标）
    d = T.get("sallen_key_lowpass").build(params)
    rows = judge.check({"fc": 1000.0, "q": 0.707}, d.metrics,
                       T.get("sallen_key_lowpass").spec_overrides)
    is_true(all(r.ok for r in rows),
            f"标称值必须本身达标：{[(r.key, r.target, r.actual) for r in rows if not r.ok]}")


@case(group="regression")
def test_regression_fc_min_no_longer_rejects_1_percent_low():
    """历史 bug 的最小复现：fc 目标 1000Hz 的 min 模式不能把 990Hz 判死。"""
    is_true(judge.check({"fc": 1000.0}, {"fc": 990.0}, {"fc": "min"})[0].ok,
            "990Hz（只低 1%）必须判合格")
    is_true(judge.check({"fc": 1000.0}, {"fc": 905.0}, {"fc": "min"})[0].ok,
            "905Hz（低 9.5%）仍在 10% 容差内，必须判合格")
    is_false(judge.check({"fc": 1000.0}, {"fc": 890.0}, {"fc": "min"})[0].ok,
             "890Hz（低 11%）超出容差，必须判不合格")


if __name__ == "__main__":
    summary = H.run(module="test_judge")
    print(H.report(summary, "判定语义汇总"))
    sys.exit(0 if summary.ok else 1)
