#!/usr/bin/env python3
"""一键跑完全部测试 —— 只用标准库，不依赖 pytest。

用法：
    python3 tests/run_all.py                # 跑全部
    python3 tests/run_all.py physics judge  # 只跑指定模块（子串匹配）
    python3 tests/run_all.py --table-only   # 只打印物理核对表
    python3 tests/run_all.py --strict      # 把「已知缺陷」也算失败（发版前跑）

输出分四块：
    1. 逐条结果（✅ 通过 / 🐞 已知缺陷 / ❌ 意外失败 / ⏭️ 跳过）
    2. 物理正确性核对表（理论值 vs 实测值 vs 相对误差）—— 最重要的一块
    3. 失败详情（意外失败 = 代码 bug，附断言原话）
    4. 汇总计数

退出码：
    0 = 没有意外失败（已知缺陷已记录在案，不算新问题）
    1 = 有意外失败，或 --strict 下存在已知缺陷（发版闸门用）
已知缺陷（🐞）的断言是**严格**的：修好那天用例会自动转成 🎉，提醒摘标记。
"""

from __future__ import annotations

import importlib
import os
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for p in (_HERE, _ROOT):
    if p not in sys.path:
        sys.path.insert(0, p)

import _harness as H  # noqa: E402

# 导入顺序 = 执行顺序；导入本身会注册用例
MODULES = ["test_judge", "test_physics", "test_robust", "test_scope", "test_tolerance", "test_e2e"]


def load(selected: list[str] | None = None) -> list[str]:
    """导入测试模块，返回实际加载的模块名。"""
    loaded = []
    for name in MODULES:
        if selected and not any(sel.lower() in name.lower() for sel in selected):
            continue
        try:
            importlib.import_module(name)
            loaded.append(name)
        except Exception as e:  # noqa: BLE001 —— 模块导不进来本身就是严重问题
            print(f"❌ 无法导入 {name}: {type(e).__name__}: {e}")
            raise
    return loaded


def main(argv: list[str]) -> int:
    args = [a for a in argv if not a.startswith("-")]
    table_only = "--table-only" in argv
    strict = "--strict" in argv

    t0 = time.perf_counter()
    print("=" * 70)
    print("Circuit Copilot · 测试与验证套件")
    print("=" * 70)
    print(f"  Python      : {sys.version.split()[0]}")
    try:
        from copilot import sim
        print(f"  ngspice     : {sim.version()}")
        from copilot import topologies as T
        print(f"  拓扑数      : {len(T.REGISTRY)} → {', '.join(T.REGISTRY)}")
    except Exception as e:  # noqa: BLE001
        print(f"  ⚠️ 环境自检失败：{e}")

    loaded = load(args)
    if not loaded:
        print("没有匹配到任何测试模块。")
        return 1
    print(f"  测试模块    : {', '.join(loaded)}")

    summary = H.run(verbose=not table_only)

    # ---- 物理核对表（本套件的核心交付物）----
    table = ""
    if "test_physics" in loaded:
        import test_physics  # noqa: PLC0415
        table = test_physics.TABLE.render()
        print("\n" + "=" * 70)
        print("物理正确性核对表（理论值 vs ngspice 实测值）")
        print("=" * 70)
        print(table)

    print(H.report(summary, "全局汇总"))
    print(f"  端到端总耗时：{time.perf_counter() - t0:.1f}s")

    if not summary.ok:
        print("\n结论：有意外失败或已知缺陷已修复但未摘标记，请看上面的详情。")
        return 1
    if summary.known_bug_fails:
        print(f"\n结论：物理与契约断言没有『意外』失败；另有 {summary.known_bug_fails} 条用例"
              f"失败于**已确认的代码缺陷**（断言未放宽，修复后会自动转为通过）。")
        if strict:
            print("--strict 模式：已知缺陷也算失败。")
            return 1
    else:
        print("\n结论：全部通过。")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
