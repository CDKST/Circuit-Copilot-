"""物理正确性回归套件 —— 每个拓扑都必须用解析公式核对仿真结果。

这套测试是「项目可信度」的唯一凭证：它不留"仿真跑通了就算过"的断言，
每一条都写成  `实测值` vs `解析式`  →  相对误差  →  与容差比较。

方法论（很重要，别改成调用 copilot 内部的工具函数）：
    - 幅频/相频的取样与插值由本文件**独立实现**（_db_at / _phase_cross / _slope）。
      如果直接复用 topologies.py 里的 _db_at，那么「提取函数算错」和
      「插值函数算错」这两个 bug 会互相掩盖 —— 自证没有意义。
    - 理论值一律现算（1/(2πRC) 之类），绝不从被测代码里读。

所有核对的数字都记进 TABLE，末尾打印成核对表：
    拓扑 / 指标 / 理论值 / 实测值 / 相对误差 / 容差 / 结论

单独运行：  python3 tests/test_physics.py
"""

from __future__ import annotations

import math
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import _harness as H  # noqa: E402
from _harness import Skip, case, close, close_abs, between_ratio, in_range, is_true, is_finite  # noqa: E402

from copilot import topologies as T  # noqa: E402

PI2 = 2.0 * math.pi


# ==========================================================================
# 独立实现的波形取样工具（不调用 topologies.py 里的任何 helper）
# ==========================================================================
def _db_at(w, f: float) -> float:
    """对数频率轴上线性插值取 dB 值。"""
    xs, db = w.x, w.db()
    if f <= xs[0]:
        return db[0]
    if f >= xs[-1]:
        return db[-1]
    for i in range(1, len(xs)):
        if xs[i] >= f:
            t = (math.log10(f) - math.log10(xs[i - 1])) / (math.log10(xs[i]) - math.log10(xs[i - 1]))
            return db[i - 1] + t * (db[i] - db[i - 1])
    return db[-1]


def _phase_cross(w, target: float) -> float | None:
    """相位首次穿越 target（度）的频率。二阶滤波器在 f0 处相位与 Q 无关，是最好的锚点。"""
    xs, ph = w.x, w.phase_deg()
    for i in range(1, len(ph)):
        a, b = ph[i - 1], ph[i]
        if (a - target) * (b - target) <= 0 and a != b:
            t = (target - a) / (b - a)
            return 10 ** (math.log10(xs[i - 1]) + t * (math.log10(xs[i]) - math.log10(xs[i - 1])))
    return None


def _slope(w, f1: float, f2: float) -> float:
    """f1→f2 之间的平均滚降斜率（dB / decade）。"""
    decades = math.log10(f2 / f1)
    return (_db_at(w, f2) - _db_at(w, f1)) / decades


_BUILD_CACHE: dict[tuple, object] = {}


def design(tid: str, **params):
    """构建（带缓存，同一组参数在一次运行里只仿真一次）。"""
    key = (tid, tuple(sorted(params.items())))
    if key not in _BUILD_CACHE:
        _BUILD_CACHE[key] = T.get(tid).build(params)
    return _BUILD_CACHE[key]


def require(tid: str) -> T.Topology:
    """拓扑存在就连，不存在就跳过（队友并行开发时先写骨架）。"""
    if tid not in T.REGISTRY:
        raise Skip(f"拓扑 {tid} 尚未注册（REGISTRY 里没有）")
    return T.get(tid)


# ==========================================================================
# 核对表
# ==========================================================================
class Table:
    def __init__(self) -> None:
        self.rows: list[dict] = []

    def add(self, topo: str, metric: str, theory: float, measured: float,
            tol: float, ok: bool, unit: str = "", note: str = "") -> None:
        err = abs(measured - theory) / abs(theory) if theory else abs(measured - theory)
        self.rows.append(dict(topo=topo, metric=metric, theory=theory, measured=measured,
                              err=err, tol=tol, ok=ok, unit=unit, note=note))

    def check(self, topo: str, metric: str, theory: float, measured: float,
              rel: float, unit: str = "", note: str = "") -> float:
        """记一行 + 断言。失败时行也会被记下来（结论列显示 ✗），再抛异常。"""
        err = abs(measured - theory) / abs(theory) if theory else abs(measured - theory)
        ok = math.isfinite(measured) and err <= rel
        self.add(topo, metric, theory, measured, rel, ok, unit, note)
        return close(measured, theory, rel, what=f"{topo}.{metric}", note=note)

    def render(self) -> str:
        if not self.rows:
            return "(无核对记录)"
        w = (18, 22, 13, 13, 10, 8, 4)
        head = (f"{'拓扑':<{w[0]}} {'指标':<{w[1]}} {'理论值':>{w[2]}} {'实测值':>{w[3]}} "
                f"{'相对误差':>{w[4]}} {'容差':>{w[5]}}  结论")
        lines = [head, "-" * (sum(w) + 12)]
        n_ok = 0
        for r in self.rows:
            mark = "✅" if r["ok"] else "❌"
            n_ok += bool(r["ok"])
            lines.append(
                f"{r['topo']:<{w[0]}} {r['metric']:<{w[1]}} "
                f"{r['theory']:>{w[2]}.6g} {r['measured']:>{w[3]}.6g} "
                f"{r['err'] * 100:>+{w[4]}.3f}% {('±%.4g%%' % (r['tol'] * 100)):>{w[5]}}  {mark}"
                + (f"  {r['note']}" if r["note"] and not r["ok"] else "")
            )
        lines.append("-" * (sum(w) + 12))
        lines.append(f"共 {len(self.rows)} 项核对：吻合 {n_ok} · 超差 {len(self.rows) - n_ok}")
        return "\n".join(lines)


TABLE = Table()
N = TABLE.check  # 短别名


# ==========================================================================
# 1. RC 一阶低通
#    解析式：|H(f)| = 1/√(1+(f/fc)²)，fc = 1/(2πRC)
#    高频渐近 → -20dB/dec；低频渐近 → 0dB
# ==========================================================================
_R, _C = 1e3, 159e-9
_FC = 1.0 / (PI2 * _R * _C)          # ≈ 1000.97 Hz


@case(group="rc_lowpass")
def test_rc_lowpass_fc():
    """fc = 1/(2πRC)，容差 1%。"""
    d = design("rc_lowpass", R=_R, C=_C)
    N("rc_lowpass", "fc [Hz]", _FC, d.metrics["fc"], 0.01, "1/(2πRC)")


@case(group="rc_lowpass")
def test_rc_lowpass_fc_is_minus3db_point():
    """fc 处增益必须正好 -3.0103dB（定义自洽性检查）。"""
    w = design("rc_lowpass", R=_R, C=_C).waves["v(out)"]
    close_abs(_db_at(w, _FC), -3.0103, 0.02, what="rc_lowpass |H(fc)|")


@case(group="rc_lowpass")
def test_rc_lowpass_slope_20db_per_decade():
    """两个十倍频点（10fc→100fc）的斜率应为 -20dB/dec，容差 2dB。"""
    w = design("rc_lowpass", R=_R, C=_C).waves["v(out)"]
    s = _slope(w, _FC * 10, _FC * 100)
    N("rc_lowpass", "rolloff [dB/dec]", -20.0, s, 2.0 / 20.0, "10fc→100fc")


@case(group="rc_lowpass")
def test_rc_lowpass_asymptotes():
    """低频渐近 0dB；1000·fc 处应约 -60dB；atten_db 指标应≈20dB @10fc。"""
    d = design("rc_lowpass", R=_R, C=_C)
    w = d.waves["v(out)"]
    N("rc_lowpass", "gain@1Hz [dB]", 0.0, _db_at(w, 1.0), 0.005, "低频渐近")
    N("rc_lowpass", "gain@1000fc [dB]", -60.02, _db_at(w, _FC * 1000), 0.02, "渐近 -20dB/dec×3")
    N("rc_lowpass", "atten_db@10fc", 20.04, d.metrics["atten_db"], 0.05, "指标 atten_db")


# ==========================================================================
# 2. RC 一阶高通  （低通的 CR 对偶：fc 相同，滚降 +20dB/dec）
# ==========================================================================
@case(group="rc_highpass")
def test_rc_highpass_fc():
    d = design("rc_highpass", R=_R, C=_C)
    N("rc_highpass", "fc [Hz]", _FC, d.metrics["fc"], 0.01, "1/(2πRC)")


@case(group="rc_highpass")
def test_rc_highpass_slope_20db_per_decade():
    """fc/100 → fc/10 应为 +20dB/dec。"""
    w = design("rc_highpass", R=_R, C=_C).waves["v(out)"]
    s = _slope(w, _FC / 100, _FC / 10)
    N("rc_highpass", "rolloff [dB/dec]", 20.0, s, 2.0 / 20.0, "fc/100→fc/10")


@case(group="rc_highpass")
def test_rc_highpass_asymptotes():
    """高频渐近 0dB；fc/100 处约 -40dB。"""
    d = design("rc_highpass", R=_R, C=_C)
    w = d.waves["v(out)"]
    N("rc_highpass", "gain@100MHz [dB]", 0.0, _db_at(w, 100e6), 0.005, "高频渐近")
    N("rc_highpass", "gain@fc/100 [dB]", -40.0, _db_at(w, _FC / 100), 0.02, "渐近")


# ==========================================================================
# 3. RLC 串联带通
#    f0 = 1/(2π√(LC))，Q = (1/R)·√(L/C)，|H(f0)| = 1（0dB）—— 串联谐振时
#    L 与 C 的压降相互抵消，输出就是输入全压在 R 上。
# ==========================================================================
_L, _CB, _RB = 1e-3, 10e-9, 31.6
_F0 = 1.0 / (PI2 * math.sqrt(_L * _CB))
_Q = (1.0 / _RB) * math.sqrt(_L / _CB)      # ≈ 10.007


@case(group="rlc_bandpass")
def test_rlc_f0():
    """f0 = 1/(2π√(LC))，容差 3%（扫频离散，峰值点采不到精确值）。"""
    d = design("rlc_bandpass", L=_L, C=_CB, R=_RB)
    N("rlc_bandpass", "f0 [Hz]", _F0, d.metrics["f0"], 0.03, "1/(2π√(LC))")


@case(group="rlc_bandpass")
def test_rlc_q():
    """Q = (1/R)√(L/C)，容差 3%（Q≈10 时离散误差约 1%）。"""
    d = design("rlc_bandpass", L=_L, C=_CB, R=_RB)
    N("rlc_bandpass", "Q", _Q, d.metrics["q"], 0.03, "(1/R)√(L/C)")


@case(group="rlc_bandpass")
def test_rlc_peak_is_0db_and_bw():
    """谐振点 |H| 必须是 0dB（串联谐振阻抗最小、电流全过 R），bw = f0/Q。"""
    d = design("rlc_bandpass", L=_L, C=_CB, R=_RB)
    w = d.waves["v(out)"]
    N("rlc_bandpass", "|H(f0)| [dB]", 0.0, _db_at(w, _F0), 0.15, "峰值应 0dB")
    N("rlc_bandpass", "bw [Hz]", _F0 / _Q, d.metrics["bw"], 0.05, "f0/Q")


@case(group="rlc_bandpass")
def test_rlc_high_q_is_accurate():
    """高 Q（这里 Q≈316）时 Q 的测量误差仍应 ≤3%。

    这是**独立的物理事实**：Q 由 R、L、C 唯一决定，与扫频网格无关。

    曾是 known_bug：扫频点数封顶 4000，f0=100kHz 时步长 57.6Hz > Q=2000 的 50Hz 带宽，
    Q 被测成 2306.8（+15.3%）——**好设计被误杀**。
    已修：上限放到 400k（`topologies/base.py`），实测 Q=200/500/1000/2000 →
    199.999 / 499.998 / 999.995 / 1999.988（|误差| ≤0.001%）。
    代价如实记着：Q=2000 那档单次仿真约 6.9 s。
    """
    L, C, R = 1e-3, 10e-9, 1.0
    q_theory = (1.0 / R) * math.sqrt(L / C)
    d = design("rlc_bandpass", L=L, C=C, R=R)
    N("rlc_bandpass", "Q (高Q=316)", q_theory, d.metrics["q"], 0.03,
      "R=1Ω L=1mH C=10nF")


# ==========================================================================
# 4. 电阻分压
#    Vout = Vin·R2/(R1+R2)；Iout = Vin/(R1+R2)；Rout = R1∥R2；P = Vin²/(R1+R2)
# ==========================================================================
@case(group="divider")
def test_divider_vout():
    """Vout = Vin·R2/(R1+R2)，容差 0.5%（纯电阻，应该几乎精确）。"""
    for r1, r2, vin in [(10e3, 10e3, 5.0), (6.8e3, 3.3e3, 5.0), (4.99e3, 4.99e3, 3.3)]:
        d = design("divider", R1=r1, R2=r2, Vin=vin)
        theory = vin * r2 / (r1 + r2)
        N("divider", f"vout(R1={r1:g},R2={r2:g})", theory, d.metrics["vout"], 0.005)


@case(group="divider")
def test_divider_derived_metrics():
    """iout / rout 与解析式一致（注意：这两项是 Python 侧公式算的，不来自仿真）。"""
    r1, r2, vin = 6.8e3, 3.3e3, 5.0
    d = design("divider", R1=r1, R2=r2, Vin=vin)
    N("divider", "iout [A]", vin / (r1 + r2), d.metrics["iout"], 1e-9)
    N("divider", "rout [Ω]", (r1 * r2) / (r1 + r2), d.metrics["rout"], 1e-9)
    N("divider", "power [W]", vin * vin / (r1 + r2), d.metrics["power"], 1e-9)


# ==========================================================================
# 5. 运放同相放大
#    A = 1+R2/R1；单极点运放闭环带宽 ≈ GBW/A；单极点系统相位裕度 ≈ 90°
# ==========================================================================
@case(group="opamp_noninverting")
def test_opamp_noninverting_gain():
    """增益 = 1+R2/R1，容差 1%（A0 有限带来的偏差 ≈ 1/A0·(1+1/β) 量级）。"""
    for r1, r2 in [(1e3, 9e3), (1e3, 1e3), (2e3, 18e3)]:
        d = design("opamp_noninverting", R1=r1, R2=r2, GBW=1e6, A0=1e5)
        N("opamp_noninverting", f"gain(R2/R1={r2 / r1:g})", 1 + r2 / r1,
          d.metrics["gain_lin"], 0.01)


@case(group="opamp_noninverting")
def test_opamp_noninverting_bandwidth():
    """闭环带宽：实测应在 GBW/gain 的 0.7~1.1 倍（只核对下限，不给精确值）。

    GBW/gain 是课本一阶近似；真实模型还受 Rout/负载影响，
    所以只能给区间 —— 这也是本项目 spec_overrides 把 fc 记为 "min" 的原因。
    """
    for r1, r2, gbw in [(1e3, 9e3, 1e6), (1e3, 99e3, 1e6), (1e3, 1e3, 1e6)]:
        d = design("opamp_noninverting", R1=r1, R2=r2, GBW=gbw, A0=1e5)
        g = 1 + r2 / r1
        k = between_ratio(d.metrics["fc"], gbw / g, 0.70, 1.10,
                          what=f"fc vs GBW/gain (g={g:g})")
        TABLE.add("opamp_noninverting", f"fc/(GBW/g) g={g:g}", 1.0, k, 0.30, True,
                  note="区间核对 0.7~1.1")


@case(group="opamp_noninverting")
def test_opamp_noninverting_phase_margin():
    """单极点运放：相位裕度应 ≈90°（80~95 视为合格；理论极限就是 90°）。"""
    for r1, r2 in [(1e3, 9e3), (1e3, 1e3)]:
        d = design("opamp_noninverting", R1=r1, R2=r2, GBW=1e6, A0=1e5)
        pm = d.metrics["pm"]
        in_range(pm, 60.0, 95.0, what=f"pm(g={1 + r2 / r1:.0f})")
        TABLE.add("opamp_noninverting", f"pm g={1 + r2 / r1:.0f} [°]", 90.0, pm, 0.055, True,
                  note="区间核对 60~95")


@case(group="opamp_noninverting")
def test_opamp_noninverting_ugf_vs_gbw():
    """单位增益频率 ≈ GBW。低增益时受 Rout/负载影响偏差较大（实测 -15%），据实核对。"""
    d10 = design("opamp_noninverting", R1=1e3, R2=99e3, GBW=1e6, A0=1e5)
    N("opamp_noninverting", "ugf (g=100) [Hz]", 1e6, d10.metrics["ugf"], 0.05)
    d2 = design("opamp_noninverting", R1=1e3, R2=1e3, GBW=1e6, A0=1e5)
    N("opamp_noninverting", "ugf (g=2) [Hz]", 1e6, d2.metrics["ugf"], 0.20,
      "低增益时 Rout 分压使 ugf 偏低，物理上正常")


# ==========================================================================
# 6. 运放反相放大
#    增益 = -R2/R1（幅值 R2/R1）；相位 180°；
#    闭环带宽 ≈ GBW/(1+R2/R1)  ← 注意是「噪声增益」，不是 |增益|！
#    这一点最容易错：R2/R1=9 时 GBW/9=111kHz，实际 100kHz（差 11%）。
# ==========================================================================
@case(group="opamp_inverting")
def test_opamp_inverting_gain_and_phase():
    """|增益| = R2/R1（容差 1%），低频相位 ±180°。"""
    for r1, r2 in [(1e3, 9e3), (1e3, 1e3), (2e3, 20e3)]:
        d = design("opamp_inverting", R1=r1, R2=r2, GBW=1e6, A0=1e5)
        N("opamp_inverting", f"|gain|(R2/R1={r2 / r1:g})", r2 / r1,
          d.metrics["gain_lin"], 0.01)
        ph = d.waves["v(out)"].phase_deg()[0]
        close_abs(abs(ph), 180.0, 5.0, what=f"反相相位(g={r2 / r1:g})")


@case(group="opamp_inverting")
def test_opamp_inverting_bandwidth_uses_noise_gain():
    """闭环带宽 ≈ GBW/(1+R2/R1)。按 GBW/|A| 算会高估 10%+，这是常见错误。"""
    for r1, r2 in [(1e3, 9e3), (1e3, 1e3)]:
        d = design("opamp_inverting", R1=r1, R2=r2, GBW=1e6, A0=1e5)
        g = r2 / r1
        k = between_ratio(d.metrics["fc"], 1e6 / (1 + g), 0.70, 1.10,
                          what=f"fc vs GBW/(1+A) (A={g:g})")
        TABLE.add("opamp_inverting", f"fc/(GBW/(1+A)) A={g:g}", 1.0, k, 0.30, True,
                  note="区间核对 0.7~1.1")


@case(group="opamp_inverting")
def test_opamp_inverting_design_matches_physics():
    """反相放大的解析设计式必须是 R2 = gain·R1（由 A = -R2/R1 直接得出）。"""
    topo = require("opamp_inverting")
    for g in (10.0, 1.0):
        p = topo.design({"gain_lin": g, "R1": 1e3})
        is_true(p["R2"] > 0, f"gain={g} 时 design() 给出 R2={p['R2']}，非正数无法实现反相放大")
        N("opamp_inverting", f"design R2/R1 (gain={g:g})", g, p["R2"] / p["R1"], 0.01,
          "design() 解析式")


# ==========================================================================
# 7. Sallen-Key 二阶低通（单位增益）
#    ω0 = 1/√(R1R2C1C2) → f0 = ω0/2π
#    Q  = √(R1R2C1C2) / (C2·(R1+R2))
#    -3dB 点：fc = f0·√(u+√(u²+1))，u = 1−1/(2Q²)
#    远阻带 −40dB/dec；|H(f0)| = Q（二阶低通的峰化恒等式）
# ==========================================================================
_SK = dict(R1=10e3, R2=10e3, C1=22e-9, C2=10e-9, GBW=1e7, A0=1e5)
_SK_F0 = 1.0 / (PI2 * math.sqrt(_SK["R1"] * _SK["R2"] * _SK["C1"] * _SK["C2"]))
_SK_Q = math.sqrt(_SK["R1"] * _SK["R2"] * _SK["C1"] * _SK["C2"]) / (
    _SK["C2"] * (_SK["R1"] + _SK["R2"]))
_SK_U = 1 - 1 / (2 * _SK_Q ** 2)
_SK_FC = _SK_F0 * math.sqrt(_SK_U + math.sqrt(_SK_U ** 2 + 1))


@case(group="sallen_key_lowpass")
def test_sk_lowpass_f0():
    """f0 = 1/(2π√(R1R2C1C2))，容差 3%。"""
    d = design("sallen_key_lowpass", **_SK)
    N("sallen_key_lowpass", "f0 [Hz]", _SK_F0, d.metrics["f0"], 0.03, "1/(2π√(R1R2C1C2))")


@case(group="sallen_key_lowpass")
def test_sk_lowpass_q():
    """Q = √(R1R2C1C2)/(C2(R1+R2))，容差 3%。"""
    d = design("sallen_key_lowpass", **_SK)
    N("sallen_key_lowpass", "Q", _SK_Q, d.metrics["q"], 0.03, "√(R1R2C1C2)/(C2(R1+R2))")


@case(group="sallen_key_lowpass")
def test_sk_lowpass_fc():
    """-3dB 点 fc = f0·√(u+√(u²+1))，容差 3%。"""
    d = design("sallen_key_lowpass", **_SK)
    N("sallen_key_lowpass", "fc [Hz]", _SK_FC, d.metrics["fc"], 0.03, "二阶 -3dB 公式")


@case(group="sallen_key_lowpass")
def test_sk_lowpass_slope_and_peak():
    """通带 0dB；10f0→100f0 应 −40dB/dec；|H(f0)|/|H(0)| = Q。"""
    d = design("sallen_key_lowpass", **_SK)
    w = d.waves["v(out)"]
    N("sallen_key_lowpass", "gain@1Hz [dB]", 0.0, _db_at(w, 1.0), 0.002)
    N("sallen_key_lowpass", "rolloff [dB/dec]", -40.0, _slope(w, _SK_F0 * 10, _SK_F0 * 100),
      3.0 / 40.0, "10f0→100f0")
    # 峰化恒等式：|H(f0)| = Q（二阶低通在 ω0 处的模恒等于 Q）
    N("sallen_key_lowpass", "|H(f0)|", _SK_Q, 10 ** (_db_at(w, _SK_F0) / 20), 0.03,
      "= Q")


@case(group="sallen_key_lowpass")
def test_sk_lowpass_needs_gbw_headroom():
    """GBW 只有 ~1000×f0 时阻带斜率已退化到 −25dB/dec —— 记录这个工程事实。

    这不是判定「有没有 bug」，而是把「GBW 不够会怎样」钉成可复现的数字，
    避免有人以为二阶滤波器天然就是 −40dB/dec。
    """
    d = design("sallen_key_lowpass", **{**_SK, "GBW": 1e6})
    w = d.waves["v(out)"]
    slope = _slope(w, _SK_F0 * 10, _SK_F0 * 100)
    TABLE.add("sallen_key_lowpass", "rolloff@GBW=1MHz [dB/dec]", -40.0, slope, 0.5, True,
              note="GBW/f0≈932 时只剩约 −25dB/dec")
    is_true(slope > -35.0,
            f"预期 GBW 不足时斜率明显退化，实测 {slope:.1f} dB/dec（若数值变了请复核 GBW 敏感性）")


# ==========================================================================
# 8. Sallen-Key 二阶高通（队友实现，按需跳过）
#
#    与自己推导的解析式对照。推导（节点法，缓冲器理想 out=np）：
#      节点 np : (Vout−Vn1)·sC2 + Vout/R2 = 0        → Vn1 = Vout·(1+1/(sR2C2))
#      节点 n1 : (Vn1−Vin)sC1 + (Vn1−Vout)sC2 + (Vn1−Vout)/R1 = 0
#    消去 Vn1 并整理（×sR2C2）：
#      Vin·s²R2C1C2 = Vout·[s²R2C1C2 + s(C1+C2) + 1/R1]
#    → H(s) = s² / (s² + s(C1+C2)/(R2C1C2) + 1/(R1R2C1C2))
#    所以            f0 = 1/(2π√(R1R2C1C2))                （与低通同形）
#                    Q  = √(R1R2C1C2) / (R1·(C1+C2))      （分母里是 R1，不是 R1+R2）
#    自检：R1=R2=R 时 Q = √(C1C2)/(C1+C2) ≤ 0.5；
#          C1=C2=C 时 Q = ½√(R2/R1)  → 要 Q=0.707 得 R2=4Q²R1。
#    另：ω0 处相位恒为 +90°，与 Q 无关 → 可作 f0 的可靠锚点。
# ==========================================================================
_SKH = dict(R1=10e3, R2=10e3, C1=22e-9, C2=10e-9, GBW=1e7, A0=1e5)


def _skh_f0(p) -> float:
    return 1.0 / (PI2 * math.sqrt(p["R1"] * p["R2"] * p["C1"] * p["C2"]))


def _skh_q(p) -> float:
    return math.sqrt(p["R1"] * p["R2"] * p["C1"] * p["C2"]) / (p["R1"] * (p["C1"] + p["C2"]))


@case(group="sallen_key_highpass")
def test_sk_highpass_f0():
    """f0 = 1/(2π√(R1R2C1C2))（与低通同形），容差 3%。"""
    require("sallen_key_highpass")
    for p in (_SKH, {"R1": 10e3, "R2": 40e3, "C1": 10e-9, "C2": 10e-9, "GBW": 1e8, "A0": 1e5}):
        d = design("sallen_key_highpass", **p)
        N("sallen_key_highpass", f"f0 (R2/R1={p['R2'] / p['R1']:g})", _skh_f0(p), d.metrics["f0"], 0.03)


@case(group="sallen_key_highpass")
def test_sk_highpass_q():
    """Q = √(R1R2C1C2)/(R1(C1+C2))，容差 3%。含 Q=0.23/0.46/0.5/1.0 四种取值。"""
    require("sallen_key_highpass")
    cases = [
        dict(R1=10e3, R2=10e3, C1=22e-9, C2=10e-9, GBW=1e7, A0=1e5),   # Q≈0.464
        dict(R1=4.7e3, R2=4.7e3, C1=47e-9, C2=47e-9, GBW=1e8, A0=1e5),  # Q=0.5
        dict(R1=10e3, R2=40e3, C1=10e-9, C2=10e-9, GBW=1e8, A0=1e5),    # Q=1.0
        dict(R1=20e3, R2=5e3, C1=10e-9, C2=22e-9, GBW=1e8, A0=1e5),     # Q≈0.232
    ]
    for p in cases:
        d = design("sallen_key_highpass", **p)
        N("sallen_key_highpass", f"Q (R1={p['R1']:g},R2={p['R2']:g})", _skh_q(p), d.metrics["q"], 0.03)


@case(group="sallen_key_highpass")
def test_sk_highpass_slope_and_plateau():
    """通带（高频平台）0dB；f0/100→f0/10 应 +40dB/dec。"""
    require("sallen_key_highpass")
    p = dict(R1=10e3, R2=10e3, C1=22e-9, C2=10e-9, GBW=1e9, A0=1e5)  # 大 GBW，避免运放极点污染斜率
    d = design("sallen_key_highpass", **p)
    w = d.waves["v(out)"]
    f0 = _skh_f0(p)
    N("sallen_key_highpass", "gain@10MHz [dB]", 0.0, _db_at(w, 10e6), 0.01, "通带平台")
    N("sallen_key_highpass", "rolloff [dB/dec]", 40.0, _slope(w, f0 / 100, f0 / 10),
      3.0 / 40.0, "f0/100→f0/10")


@case(group="sallen_key_highpass")
def test_sk_highpass_phase_anchor_is_90deg():
    """ω0 处相位恒为 +90°（与 Q 无关）—— 这是提取 f0 的理论依据。"""
    require("sallen_key_highpass")
    p = dict(R1=10e3, R2=40e3, C1=10e-9, C2=10e-9, GBW=1e8, A0=1e5)   # Q=1.0
    d = design("sallen_key_highpass", **p)
    w = d.waves["v(out)"]
    f0 = _skh_f0(p)
    close_abs(_phase_cross(w, 90.0), f0, f0 * 0.01, what="相位 +90° 交点 = f0")


# ==========================================================================
# 9. 差分放大 / 减法器（队友实现，按需跳过）
#
#    解析式（理想运放，Vout = (R4/(R3+R4))·(1+R2/R1)·Vin2 − (R2/R1)·Vin1）：
#      取 R2=R4、R1=R3  →  差模增益 Ad = R2/R1
#      共模增益 Ac = (R4/(R3+R4))·(1+R2/R1) − R2/R1，理想匹配时为 0
#      CMRR = Ad/Ac，失配 δ 时最坏 ≈ (1+Ad)/(4δ)  →  1% 电阻、Ad=10 只有 ~49dB
#    这是「匹配决定成败」的典型电路：增益靠挑选，CMRR 靠电阻配对。
# ==========================================================================
_DA = dict(R1=1e3, R2=9e3, R3=1e3, R4=9e3)


def full_params(tid: str, **overrides) -> dict:
    """给拓扑补齐所有声明参数，再覆盖关心的几项。

    - R/C/L/Gain 类：取几何中值（对数尺度上的中点）
    - enum 类（阶数、响应类型等）：取最小合法值，几何中值会得到 3.46 阶这种非法值
    - db 类：取中值
    这样队友给拓扑加参数（CMRR_OPA、order/kind/ripple_db …）时本套件不会碎。
    """
    topo = T.get(tid)
    p = {}
    for prm in topo.params:
        if prm.name in overrides:
            continue
        if prm.kind == "enum":
            p[prm.name] = prm.lo
        else:
            p[prm.name] = math.sqrt(prm.lo * prm.hi)
    p.update(overrides)
    return p


@case(group="difference_amp")
def test_difference_amp_gain():
    """差模增益 Ad = R2/R1（R2=R4、R1=R3），容差 1%。"""
    require("difference_amp")
    for r1, r2 in [(1e3, 9e3), (1e3, 1e3), (10e3, 9.09e3)]:
        p = full_params("difference_amp", R1=r1, R2=r2, R3=r1, R4=r2)
        d = design("difference_amp", **p)
        N("difference_amp", f"Ad (R2/R1={r2 / r1:g})", r2 / r1,
          10 ** (d.metrics["gain_db"] / 20), 0.01, "R2/R1")


@case(group="difference_amp")
def test_difference_amp_cmrr_matched():
    """四电阻严格匹配时，CMRR 的两个误差源只剩运放自身：

        - 仿真测到的电阻失配项 cmrr_res_db 极高（只受有限 A0 限制）；
        - 合成后的总 CMRR ≈ 运放自身 CMRR（这里取几何中值 ≈91.6dB）。
    """
    require("difference_amp")
    p = full_params("difference_amp", **_DA)
    d = design("difference_amp", **p)
    res_db = d.metrics.get("cmrr_res_db")
    if res_db is None:
        raise Skip("该拓扑未暴露 cmrr_res_db（无法区分电阻失配与运放自身贡献）")
    is_true(res_db >= 100.0,
            f"电阻严格匹配时电阻失配项应只受 A0 限制（>100dB），实测 {res_db:.1f}dB")
    N("difference_amp", "总CMRR / 运放CMRR", p["CMRR_OPA"], d.metrics["cmrr_db"], 0.02,
      "匹配时总 CMRR 应等于运放自身 CMRR")


@case(group="difference_amp")
def test_difference_amp_cmrr_limited_by_mismatch():
    """故意让 R4 偏离 R2 1%（9.09k vs 9k）：仿真测到的 CMRR 应等于解析失配上限。

    解析式 CMRR = 20log10(Ad/Ac)，Ac = (R4/(R3+R4))·(1+R2/R1) − R2/R1。
    吻合到 2% 以内说明该拓扑的共模建模是对的。
    """
    require("difference_amp")
    topo = require("difference_amp")
    p = full_params("difference_amp", **{**_DA, "R4": 9.09e3})
    d = design("difference_amp", **p)
    got = d.metrics.get("cmrr_res_db", d.metrics["cmrr_db"])
    N("difference_amp", "CMRR 失配(电阻项) [dB]", topo.cmrr_theory_db(p), got, 0.02,
      "对比 cmrr_theory_db")


@case(group="difference_amp")
def test_difference_amp_cmrr_combination_formula():
    """总 CMRR 必须按误差串联合成：1/CMRR = 1/CMRR_电阻 + 1/CMRR_运放。

    独立验算：已知实测电阻项与运放项时，合成值必须同时低于两者，
    且贴近 -20log10(10^(−a/20)+10^(−b/20))。若这条不成立，报告里的
    「真实可达 CMRR」就是编出来的数字。
    """
    require("difference_amp")
    p = full_params("difference_amp", **{**_DA, "R4": 9.09e3, "CMRR_OPA": 80.0})
    d = design("difference_amp", **p)
    res_db = d.metrics.get("cmrr_res_db")
    if res_db is None:
        raise Skip("该拓扑未暴露 cmrr_res_db")
    total = d.metrics["cmrr_db"]
    mine = -20.0 * math.log10(10 ** (-res_db / 20.0) + 10 ** (-80.0 / 20.0))
    N("difference_amp", "总CMRR(串联合成) [dB]", mine, total, 0.005, "1/CMRR 相加")


# ==========================================================================
# 10. 低通滤波器综合（Butterworth / Chebyshev / Bessel，2/4/6 阶）
#
#    这个拓扑「反解」元件值，判据全部来自滤波器综合理论，而不是元件公式：
#      N 阶全极点低通 |H| = 1/√(1 + ε²·Φ_N²(f/fc))
#      - Butterworth：Φ_N = (f/fc)^N  →  最平坦（通带无峰化），
#        2fc 处衰减 = 20log10(2^N) = 6·N dB，即 6dB/oct/阶
#      - Chebyshev I：通带等波纹，**波纹量就是 peaking_db**
#        （偶次阶直流落在波纹谷底，所以 peaking = 波纹值）
#      - Bessel：群延迟最平坦 → 通带无峰化，但选择性最差（同阶衰减最小）
#    判据与元件取值无关，所以能直接核对「综合出来的电路是不是它自称的响应」。
# ==========================================================================
_SYNTH_FC = 10e3


def _synth(order: int, kind: int, ripple: float = 0.5, fc: float = _SYNTH_FC):
    topo = require("filter_lowpass_synth")
    p = topo.design({"fc": fc, "order": order, "kind": kind, "ripple_db": ripple})
    return design("filter_lowpass_synth", **p)


@case(group="filter_lowpass_synth")
def test_synth_fc_is_the_minus3db_point():
    """三种响应 × 2/4/6 阶：整机 −3dB 点都必须落在 fc（容差 10%，即判定容差）。"""
    require("filter_lowpass_synth")
    for kind in (1, 2, 3):
        for order in (2, 4, 6):
            d = _synth(order, kind)
            N("filter_lowpass_synth", f"fc (kind={kind},N={order}) [Hz]", _SYNTH_FC,
              d.metrics["fc"], 0.10, "综合后整机 -3dB")


@case(group="filter_lowpass_synth")
def test_synth_butterworth_is_maximally_flat():
    """Butterworth 的定义就是通带最平坦：峰化必须 ≈0dB，且 2fc 处衰减 = 6N dB。"""
    require("filter_lowpass_synth")
    for order in (2, 4, 6):
        d = _synth(order, 1)
        # 峰化用绝对容差衡量（dB 是绝对单位）
        close_abs(d.metrics["peaking_db"], 0.0, 0.30,
                  what=f"Butterworth N={order} 通带峰化（最平坦应为 0dB）")
        TABLE.add("filter_lowpass_synth", f"Butterworth N={order} 峰化 [dB]", 0.0,
                  d.metrics["peaking_db"], 0.3, True, note="abs ±0.3dB")
        # atten_2fc_db 是「衰减量」（正数），Butterworth 在 2fc 处精确为 6N dB
        close_abs(d.metrics["atten_2fc_db"], 6.0 * order, 0.8,
                  what=f"Butterworth N={order} @2fc 衰减")
        TABLE.add("filter_lowpass_synth", f"Butterworth N={order} @2fc [dB]", 6.0 * order,
                  d.metrics["atten_2fc_db"], 0.8, True, note="abs ±0.8dB")


@case(group="filter_lowpass_synth")
def test_synth_bessel_is_flattest_delay():
    """Bessel 生来无峰化（群延迟最平坦），但同阶选择性最差：2fc 衰减应小于 Butterworth。"""
    require("filter_lowpass_synth")
    for order in (2, 4):
        b = _synth(order, 3)
        close_abs(b.metrics["peaking_db"], 0.0, 0.15,
                  what=f"Bessel N={order} 通带峰化（应无峰化）")
        bw = _synth(order, 1)
        is_true(b.metrics["atten_2fc_db"] < bw.metrics["atten_2fc_db"],
                f"Bessel N={order} 在 2fc 处衰减应小于 Butterworth："
                f"{b.metrics['atten_2fc_db']:.2f} vs {bw.metrics['atten_2fc_db']:.2f} dB")


@case(group="filter_lowpass_synth")
def test_synth_chebyshev_ripple_matches_spec():
    """Chebyshev 的通带波纹必须等于规格值（偶次阶 peaking_db = ripple_db）。

    这是 Chebyshev 的定义性质：等波纹通带，最大值 0dB、谷值 −ripple dB，
    而偶次阶的直流正好落在谷底，所以 peaking = max − dc = ripple。
    """
    require("filter_lowpass_synth")
    for order in (2, 4, 6):
        d = _synth(order, 2, ripple=0.5)
        got = d.metrics["peaking_db"]
        ok = abs(got - 0.5) <= 0.35
        TABLE.add("filter_lowpass_synth", f"Chebyshev N={order} 波纹 [dB]", 0.5, got, 0.35, ok,
                  note="abs ±0.35dB")
        close_abs(got, 0.5, 0.35, what=f"Chebyshev N={order} 通带波纹（规格 0.5dB）")


# ==========================================================================
# 12. 有源高通综合 filter_highpass_synth（级联一阶节 + 缓冲隔离）
#
#     结构：N 级「C 串联 + R 对地 + 单位增益缓冲」，末级过运放宏模型。
#     标定：N 级级联的 −3dB 满足 x² = ½^(1/N)/(1−½^(1/N))，x = fc/f1
#     滚降：两侧 20N dB/dec（远场才显出来，过渡带里斜率偏小）
#
#     为什么必须钉住：这个拓扑的元件值、扫频卡、参考电平全都改过好几轮，
#     其中「扫频上限扫进运放滚降区」会让通带整体报低 12dB、fc 报成 175Hz。
#     没有这几条，同类退化在 177 项里完全看不见。
# ==========================================================================
_HP_FC = 1e3


def _hp(order: int, fc: float = _HP_FC):
    topo = require("filter_highpass_synth")
    return design("filter_highpass_synth", **topo.design({"fc": fc, "order": order}))


@case(group="filter_highpass_synth")
def test_hp_synth_fc_is_the_minus3db_point():
    """1/2/3 级：整机 −3dB 点必须落在 fc。实测偏差 0.24%~0.74%，这里按 2% 钉。"""
    require("filter_highpass_synth")
    for n in (1, 2, 3):
        d = _hp(n)
        N("filter_highpass_synth", f"fc (N={n} 级) [Hz]", _HP_FC, d.metrics["fc"], 0.02,
          "级联后整机 -3dB")


@case(group="filter_highpass_synth")
def test_hp_synth_passband_is_flat():
    """通带（高频侧）必须约 0dB：级联缓冲隔离的代价只该出现在阻带。"""
    require("filter_highpass_synth")
    for n in (1, 2, 3):
        d = _hp(n)
        N("filter_highpass_synth", f"通带增益 (N={n}) [dB]", 0.0, d.metrics["gain_db"], 0.02,
          "高频端参考电平")


@case(group="filter_highpass_synth")
def test_hp_synth_slope_is_20n_db_per_decade():
    """远场滚降必须是 20N dB/dec。

    只能在 fc/100 → fc/1000 量：一阶节的渐近斜率在过渡带里显不出来
    （实测在 fc/4→fc/10 段只有 25dB/dec，会误判成"斜率不对"，其实是取样点不对）。
    """
    require("filter_highpass_synth")
    for n in (1, 2, 3):
        d = require("filter_highpass_synth").build(
            require("filter_highpass_synth").design({"fc": _HP_FC, "order": n}))
        w = d.waves["v(out)"]
        # 注意符号：高通从 fc/1000 扫到 fc/100（频率升高），响应是**往上走**的，
        # _slope 算出来本来就是 +20N。别习惯性取负（低通的斜率是负的，这里不是）。
        got = _slope(w, _HP_FC / 1000.0, _HP_FC / 100.0)
        N("filter_highpass_synth", f"远场斜率 (N={n}) [dB/dec]", 20.0 * n, got, 0.06,
          "fc/1000→fc/100 段")


@case(group="filter_highpass_synth")
def test_hp_synth_cascade_calibration_matches_theory():
    """标定公式本身要对：每级角频率 f1 与整机 fc 之比必须等于 x(N)。"""
    require("filter_highpass_synth")
    topo = require("filter_highpass_synth")
    for n in (1, 2, 3):
        p = topo.design({"fc": _HP_FC, "order": n})
        f1 = 1.0 / (PI2 * p["R1"] * p["C1"])
        N("filter_highpass_synth", f"f1/fc (N={n})", topo._cascade_x(n), _HP_FC / f1, 0.01,
          "标定系数")


# ==========================================================================
# 13. 有源带通综合 filter_bandpass_synth（高通段 × 低通段级联）
#
#     结构：N 级一阶高通串 N 级一阶低通，级间缓冲隔离，总阶数 = 2N。
#     带宽口径：**峰值降 3dB**（与 judge、rlc_bandpass 一致），不是绝对 −3.01dB。
#     这条口径曾经搞错，把 200Hz 的目标量成 2204Hz —— 所以必须钉死。
# ==========================================================================
def _bp(n_stages: int, f_low: float, f_high: float):
    topo = require("filter_bandpass_synth")
    p = topo.design({"f_low": f_low, "f_high": f_high, "order": 2 * n_stages})
    return topo, design("filter_bandpass_synth", **p)


#: 覆盖宽带、中等、接近 Q 上限三种情形
_BP_CASES = [
    (1, 300.0, 3300.0),        # Q≈0.33 宽带
    (1, 100.0, 100e3),         # Q≈0.01 极宽带
    (2, 200.0, 5000.0),        # Q≈0.21，4 阶
    (1, 400.0, 2500.0),        # Q≈0.48，逼近 2 阶上限 0.50
]


@case(group="filter_bandpass_synth")
def test_bp_synth_edges_land_on_target():
    """上下边沿由「峰值降 3dB」定义：带宽必须与目标一致（实测偏差 0.0%）。"""
    require("filter_bandpass_synth")
    for n, fl, fh in _BP_CASES:
        _t, d = _bp(n, fl, fh)
        N("filter_bandpass_synth", f"带宽 ({fl:g}~{fh:g}Hz) [Hz]", fh - fl, d.metrics["bw"], 0.02,
          "峰值降 3dB 口径")


@case(group="filter_bandpass_synth")
def test_bp_synth_center_is_geometric_mean():
    """中心频率取几何中心 √(fL·fH)，与边沿同一套标定。"""
    require("filter_bandpass_synth")
    for n, fl, fh in _BP_CASES:
        _t, d = _bp(n, fl, fh)
        N("filter_bandpass_synth", f"f0 ({fl:g}~{fh:g}Hz) [Hz]",
          math.sqrt(fl * fh), d.metrics["f0"], 0.02, "几何中心")


@case(group="filter_bandpass_synth")
def test_bp_synth_q_follows_from_edges():
    """Q 必须与 (f0, bw) 自洽——判定表要求 Q 在 ±某范围内，不能和边沿打架。"""
    require("filter_bandpass_synth")
    for n, fl, fh in _BP_CASES:
        _t, d = _bp(n, fl, fh)
        want = math.sqrt(fl * fh) / (fh - fl)
        N("filter_bandpass_synth", f"Q ({fl:g}~{fh:g}Hz)", want, d.metrics["q"], 0.03,
          "f0/bw")


@case(group="filter_bandpass_synth")
def test_bp_synth_peak_gain_matches_cascade_theory():
    """峰值插损必须等于级联理论值 20n·log10(k/(1+k))，k 为两段角频率之比。

    窄带一定带插损（400~2500Hz 实测 −3.71dB），把这条钉住，
    以后谁改了角频率求解会立刻发现插损对不上。
    """
    require("filter_bandpass_synth")
    topo = require("filter_bandpass_synth")
    for n, fl, fh in _BP_CASES:
        p = topo.design({"f_low": fl, "f_high": fh, "order": 2 * n})
        d = design("filter_bandpass_synth", **p)
        f1h = 1.0 / (PI2 * p["RHP"] * p["CHP"])
        f1l = 1.0 / (PI2 * p["RLP"] * p["CLP"])
        k = f1l / f1h
        theory = 20.0 * n * math.log10(k / (1.0 + k))
        N("filter_bandpass_synth", f"峰值插损 ({fl:g}~{fh:g}Hz) [dB]",
          theory, d.metrics["gain_db"], 0.02, "级联理论")


@case(group="filter_bandpass_synth")
def test_bp_q_upper_bound():
    """Q 上限是结构决定的（无谐振 ⇒ Q 顶不上去），数值必须钉住。

    每侧 1/2/3 级 → 0.500 / 0.777 / 0.981；由 20n·log10((r+1)/(2√r))=3.0103 解出。
    """
    topo = require("filter_bandpass_synth")
    for n, want in ((1, 0.5000), (2, 0.7769), (3, 0.9807)):
        N("filter_bandpass_synth", f"Q 上限 (每侧 {n} 级)", want, topo.q_max(n), 0.01,
          "解析解")
    is_true(topo.q_max(1) < topo.q_max(2) < topo.q_max(3),
            "Q 上限应随级数单调递增（级数越多裙边越陡，能做的带越窄）")


@case(group="filter_bandpass_synth")
def test_bp_refuses_narrow_band_instead_of_lying():
    """Q 超上限时必须**拒绝**，不能返回一个通带宽一个量级的电路。

    这是本项目最核心的一条纪律：宁可说做不到，也不交付看似成功的错误设计。
    实测历史错误：目标 200Hz 带宽，量出 2204Hz，而报告说"达标"。
    """
    topo = require("filter_bandpass_synth")
    # Q = 1000/800 = 1.25 > q_max(2级)=0.78 → 必须拒
    try:
        topo.design({"f0": 1000.0, "bw": 800.0, "order": 4})
    except ValueError as e:
        msg = str(e)
        is_true("Q" in msg, f"拒绝信息应说明是 Q 超限，实际：{msg[:80]}")
        is_true("上限" in msg, f"拒绝信息应给出上限值，实际：{msg[:80]}")
    else:
        raise AssertionError("Q=1.25（上限 0.78）竟然没有拒绝——这正是要做的事")

    # 对照：Q=0.33 必须能正常做出来（防「一律拒绝」也能通过这类测试）
    p = topo.design({"f0": 1000.0, "bw": 3000.0, "order": 2})
    d = design("filter_bandpass_synth", **p)
    N("filter_bandpass_synth", "Q=0.33 的带宽 [Hz]", 3000.0, d.metrics["bw"], 0.03,
      "不该被拒的对照")


@case(group="filter_bandpass_synth")
def test_bp_accepts_edge_spec_as_well():
    """spec 同时支持 (f0,bw) 和 (f_low,f_high) 两种写法，且结果必须一致。"""
    topo = require("filter_bandpass_synth")
    # 用 Q≈0.33 的可行区间；500~2000Hz 是 Q=0.67，本来就该被拒（别拿它当对照）
    a = topo.design({"f_low": 300.0, "f_high": 3300.0, "order": 2})
    b = topo.design({"f0": math.sqrt(300.0 * 3300.0), "bw": 3000.0, "order": 2})
    for key in ("CHP", "RHP", "CLP", "RLP"):
        N("filter_bandpass_synth", f"两种写法一致：{key}", a[key], b[key], 0.01,
          "f_low/f_high vs f0/bw")


# ==========================================================================
# 14. Twin-T 陷波 twin_t_notch
#
#     结构：R-R-C（低通 T）与 C-C-R（高通 T）并联，汇合点经单位增益缓冲输出。
#     对称条件：R1=R2=R、C1=C2=C、**C3=2C、R3=R/2** —— 缺一条凹陷就塌。
#     无源 Twin-T 的 Q 固定 0.25（带宽 = 4×f0），深度由元件匹配决定。
# ==========================================================================
def _notch(f0: float):
    topo = require("twin_t_notch")
    return topo, design("twin_t_notch", **topo.design({"f0": f0}))


@case(group="twin_t_notch")
def test_notch_f0_is_the_null_frequency():
    """凹陷必须落在 f0 = 1/(2πRC)。实测偏差 0.00%~0.03%。"""
    require("twin_t_notch")
    for f0 in (50.0, 60.0, 1e3):
        _t, d = _notch(f0)
        N("twin_t_notch", f"凹陷频率 (设计 {f0:g}Hz) [Hz]", f0, d.metrics["f0"], 0.02,
          "1/(2πRC)")


@case(group="twin_t_notch")
def test_notch_is_deep():
    """理想匹配下凹陷必须很深（实测 −76dB 以上）。

    只要有一条对称条件写错（例如 C3 取 C/2 而不是 2C），深度会塌到 −5dB 左右
    ——「看着像个坑」但工频照样过。这条把它钉住。
    """
    require("twin_t_notch")
    for f0 in (50.0, 1e3):
        _t, d = _notch(f0)
        is_true(d.metrics["depth_db"] >= 40.0,
                f"f0={f0:g}Hz 凹陷只有 {d.metrics['depth_db']:.1f}dB，"
                f"多半是对称条件（C3=2C、R3=R/2）写错了")


@case(group="twin_t_notch")
def test_notch_q_is_fixed_at_quarter():
    """无源 Twin-T 的 Q 只能是 0.25 —— 这是结构决定的，不是设计参数。

    钉住它有两个作用：1) 回归时 Q 变了说明拓扑被改坏；
    2) 提醒「想要窄陷波必须加正反馈」，避免以后有人以为能靠调元件把 Q 提上去。
    """
    require("twin_t_notch")
    for f0 in (50.0, 1e3):
        _t, d = _notch(f0)
        N("twin_t_notch", f"Q (设计 {f0:g}Hz)", 0.25, d.metrics["q"], 0.05,
          "无源 Twin-T 固定值")


@case(group="twin_t_notch")
def test_notch_bandwidth_is_four_times_f0():
    """Q=0.25 的等价说法：−3dB 带宽 = 4×f0。用两条独立口径互相印证。"""
    require("twin_t_notch")
    for f0 in (50.0, 1e3):
        _t, d = _notch(f0)
        N("twin_t_notch", f"带宽 (设计 {f0:g}Hz) [Hz]", 4.0 * f0, d.metrics["bw"], 0.06,
          "Q=0.25 ⇒ bw=4f0")


@case(group="twin_t_notch")
def test_notch_passband_is_transparent():
    """凹陷之外必须几乎无衰减（通带 ≈ 0dB），否则它就是个宽带衰减器。"""
    require("twin_t_notch")
    topo, d = _notch(50.0)
    w = d.waves["v(out)"]
    for f in (1.0, 5e3):
        # 注意：theory=0 时 N() 的 rel 参数按**绝对 dB** 解释（分母为 0），
        # 所以这里传 0.1 表示「允许 0.1dB」。实测 1Hz 处 −0.028dB 是真实存在的
        # 微小衰减（缓冲的 10MΩ 输入阻抗与网络分压），不是误差。
        N("twin_t_notch", f"通带 {f:g}Hz [dB]", 0.0, _db_at(w, f), 0.1,
          "远离凹陷处（容差为绝对 dB）")


@case(group="twin_t_notch")
def test_notch_requires_the_symmetric_condition():
    """反证：把 C3 从 2C 改成 C/2（不对称），凹陷必须塌掉。

    这条防的是「有人以为元件随手填 R、R、C、C 就行」。数值上凹陷会从 −76dB
    掉到 −5dB 量级——恰好是「看起来能用但不能用」的典型。
    """
    topo = require("twin_t_notch")
    good = topo.design({"f0": 50.0})
    bad = dict(good)
    bad["C3"] = good["C3"] / 4.0       # 2C → C/2，对称条件被破坏
    d_bad = design("twin_t_notch", **bad)
    is_true(d_bad.metrics["depth_db"] < 20.0,
            f"对称条件被破坏后凹陷仍达 {d_bad.metrics['depth_db']:.1f}dB，"
            f"说明测试没有真正破坏条件，或拓扑对失配不敏感（与实测不符）")


@case(group="twin_t_notch")
def test_notch_is_not_a_bandpass():
    """陷波与带通方向相反，必须能从路由上区分开。

    历史事故：「50Hz 工频陷波器」被判成 RLC 带通 → 50Hz 原样通过。
    """
    from copilot import agent

    for req in ("设计一个 50Hz 工频陷波器，把干扰滤掉", "带阻滤波器，中心 50Hz"):
        got = agent.parse_rules(req)["topology"]
        is_true(got == "twin_t_notch", f"{req} 应路由到 twin_t_notch，实际 {got}")
    # 对照：带通需求不能被抢走
    got = agent.parse_rules("二阶带通滤波器，中心频率 100kHz")["topology"]
    is_true(got != "twin_t_notch", f"带通需求被陷波抢走了：{got}")


# ==========================================================================
# 全量核对表（test_physics 的交付物）
# ==========================================================================
def run_all(verbose: bool = True):
    """跑完本文件的所有物理核对，返回 (Summary, 核对表文本)。"""
    s = H.run(module="test_physics", verbose=verbose)
    return s, TABLE.render()


if __name__ == "__main__":
    summary, table = run_all()
    print("\n" + "=" * 70)
    print("物理正确性核对表（理论值 vs ngspice 实测）")
    print("=" * 70)
    print(table)
    print(H.report(summary, "物理回归汇总"))
    sys.exit(0 if summary.ok else 1)
