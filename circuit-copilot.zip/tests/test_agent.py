import sys, time
sys.path.insert(0, "/storage/emulated/0/文件夹/dz/circuit-copilot")
from copilot import agent, topologies as T

print("环境自检:", agent.diagnose())
for req in [
    "做一个1kHz的RC低通滤波器",
    "10倍同相放大器，需要100kHz带宽",
    "把5V分压到2.5V给ADC采样",
    "二阶低通，截止1kHz，Q=0.707",
]:
    print("\n" + "="*70)
    print("需求:", req)
    t0=time.time()
    s = agent.run(req, use_llm=False)
    print(f"拓扑: {s.topology_name}  来源: {s.plan_source}  仿真 {s.total_sims} 次 / {(time.time()-t0)*1000:.0f}ms")
    if s.error: print("错误:", s.error); continue
    print("规格:", {T.METRICS[k].label: v for k,v in s.spec.items()})
    print("元件:", s.best.human_params(T.get(s.topology)))
    for r in s.rows:
        mark = "✔" if r.ok else "✗"
        print(f"  {mark} {r.label:12s} 目标 {T.fmt_value(r.target, r.unit):>10s}  实测 {T.fmt_value(r.actual, r.unit):>10s}")
    print("结论:", "达标" if s.passed else "未达标")
