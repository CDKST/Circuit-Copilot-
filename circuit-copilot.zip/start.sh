#!/data/data/com.termux/files/usr/bin/bash
# Circuit Copilot 一键启动
# 用法：bash start.sh [端口]
set -u
cd "$(dirname "$0")" || exit 1

PORT="${1:-3081}"
PIDFILE="out/pid"
LOG="out/server.log"

# 检查 ngspice
if ! command -v ngspice >/dev/null 2>&1; then
  echo "✗ 没找到 ngspice，先执行： pkg install -y ngspice"
  exit 1
fi

# 停掉旧实例
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "${OLD:-}" ] && kill -0 "$OLD" 2>/dev/null; then
    kill "$OLD" 2>/dev/null
    sleep 0.6
    echo "· 已停止旧实例 (pid $OLD)"
  fi
fi

mkdir -p out
nohup python3 web/server.py "$PORT" > "$LOG" 2>&1 &
echo $! > "$PIDFILE"
sleep 2

if curl -s -m 3 "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then
  echo "✓ Circuit Copilot 已启动"
  echo "  地址： http://127.0.0.1:$PORT"
  echo "  日志： $LOG"
  curl -s "http://127.0.0.1:$PORT/api/health" | python3 -c '
import json,sys
d=json.load(sys.stdin)
print("  ngspice：", d["ngspice"], "| 拓扑：", d["topologies"], "个")
print("  大模型：", d["llm_model"] if d["llm_configured"] else "未配置（规则模式，功能不完整）")
'
else
  echo "✗ 启动失败，看日志："
  tail -20 "$LOG"
  exit 1
fi
