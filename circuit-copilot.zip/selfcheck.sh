#!/usr/bin/env bash
# Circuit Copilot 自检：一条命令跑完全部验证，结论一行一行看完。
#
#   ./selfcheck.sh            默认：全部（约 3~5 分钟）
#   ./selfcheck.sh --fast     跳过最慢的两项（真实模型基准、容差蒙特卡洛聚合）
#   ./selfcheck.sh --verbose  失败时把日志尾部打出来
#
# 退出码：0 全部通过；1 有失败。
# 完整日志写在 out/selfcheck.log，失败时先看那里。
#
# 为什么要有这个脚本：改动之后「哪些东西可能被碰坏了」不该靠记忆。
# 这些套件各自只覆盖一层，漏跑任何一层都可能留下白屏或静默错算。

set -uo pipefail
cd "$(dirname "$0")" || exit 1

PY=python3
command -v python3 >/dev/null 2>&1 || PY=python

LOG=out/selfcheck.log
mkdir -p out
: > "$LOG"

FAST=0
VERBOSE=0
for a in "$@"; do
  case "$a" in
    --fast) FAST=1 ;;
    --verbose|-v) VERBOSE=1 ;;
    *) echo "未知参数：$a"; exit 2 ;;
  esac
done

GREEN=$'\033[32m'; RED=$'\033[31m'; DIM=$'\033[2m'; BOLD=$'\033[1m'; OFF=$'\033[0m'
if [ ! -t 1 ]; then GREEN=; RED=; DIM=; BOLD=; OFF=; fi

FAILED=0
RAN=0
TOTAL_MS=0
FAIL_NAMES=()

# 跑一项：名字、命令、用于判断通过的正则（在输出里找）
# IGNORE_RC=1 时只看输出里的数字，不看退出码——
# 拦截基准的本职就是「发现问题时退 1」，不能因此把自检判红。
IGNORE_RC=0
run_case() {
  local name="$1"; shift
  local expect="$1"; shift
  local t0 t1 ms out rc
  t0=$(date +%s%N 2>/dev/null || echo 0)
  out=$("$@" 2>&1)
  rc=$?
  t1=$(date +%s%N 2>/dev/null || echo 0)
  if [ "$t0" != 0 ] && [ "$t1" != 0 ]; then
    ms=$(( (t1 - t0) / 1000000 ))
  else
    ms=0
  fi
  TOTAL_MS=$(( TOTAL_MS + ms ))

  {
    echo "════════ $name ════════"
    echo "$out"
    echo
  } >> "$LOG"

  RAN=$(( RAN + 1 ))
  local ok=1
  [ $rc -ne 0 ] && [ $IGNORE_RC -eq 0 ] && ok=0
  if [ -n "$expect" ]; then
    echo "$out" | grep -qE "$expect" || ok=0
  fi

  if [ $ok -eq 1 ]; then
    local detail
    detail=$(echo "$out" | grep -oE "$expect" | tail -1)
    printf "  %s✓%s %-22s %6s ms  %s%s%s\n" "$GREEN" "$OFF" "$name" "$ms" "$DIM" "$detail" "$OFF"
  else
    printf "  %s✗%s %-22s %6s ms  %sexit=%s%s\n" "$RED" "$OFF" "$name" "$ms" "$RED" "$rc" "$OFF"
    FAILED=$(( FAILED + 1 ))
    FAIL_NAMES+=("$name")
    if [ $VERBOSE -eq 1 ]; then
      echo "$out" | tail -25 | sed 's/^/      /'
    fi
  fi
}

echo "${BOLD}Circuit Copilot 自检${OFF}  ${DIM}$(date '+%Y-%m-%d %H:%M:%S')${OFF}"
echo "${DIM}日志：$LOG${OFF}"
echo

# ── 1. 语法：最快、最先跑（挡白屏类问题）
run_case "前端语法" "OK" bash -c '
  fail=0
  for f in web/ide/*.js; do
    node --input-type=module --check < "$f" >/dev/null 2>&1 || { echo "语法错误：$f"; fail=1; }
  done
  [ $fail -eq 0 ] && echo OK'
run_case "后端语法" "OK" bash -c '
  '"$PY"' - <<"PYEOF"
import ast, glob, sys
bad = []
for f in glob.glob("**/*.py", recursive=True):
    if f.startswith(("vendor/",)):
        continue
    try:
        ast.parse(open(f, encoding="utf-8").read())
    except SyntaxError as e:
        bad.append(f"{f}: {e}")
if bad:
    print("\n".join(bad)); sys.exit(1)
print("OK")
PYEOF'

# ── 2. 核心库（177 项，物理与口径）
run_case "tests_ccl (228)" "失败 0 · 跳过 0 · 已知缺陷 0" \
  "$PY" tests_ccl/run_all.py

# ── 3. 参数化工具端到端（133 项）
run_case "copilot 端到端 (133)" "全部通过|失败 0" \
  "$PY" tests/run_all.py

# ── 4. HTTP/API 层（26 项，起独立服务，随机端口）
run_case "tests_api (44)" "通过 [0-9]+ · 失败 0" \
  "$PY" tests_api/run_all.py

# ── 5. 电路图几何（51 项）
run_case "电路图布局 (51)" "" \
  node tests_ui/schematic_selfcheck.mjs

# ── 6. AI 拦截基准（确定性闸门，1.5 秒，不需要 Key）
# 闸门层按**数字**判定，不看退出码：基准的本职就是如实报告未达标，
# 它退 1 说明「发现漏网」，不等于自检失败。判据是硬指标：
#   误杀必须是 0，拦截率不得低于基线 95%（当前 39/40=97.5%）。
IGNORE_RC=1
run_case "拦截基准（闸门 98 条）" "通过$" \
  "$PY" -c '
import json, subprocess, sys
subprocess.run([sys.executable, "bench/run_gates.py"], capture_output=True)
cases = json.load(open("bench/results_gates.json", encoding="utf-8"))["cases"]
rj = [c for c in cases if c.get("expect") == "reject"]
ac = [c for c in cases if c.get("expect") == "accept"]
rh = sum(1 for c in rj if c.get("caught"))
ah = sum(1 for c in ac if c.get("caught"))
rate = rh / max(len(rj), 1)
ok = (ah == 0) and rate >= 0.95
print(f"拦截 {rh}/{len(rj)}={rate*100:.1f}%  误杀 {ah}/{len(ac)}  " + ("通过" if ok else "低于基线"))
sys.exit(0 if ok else 1)' 

if [ $FAST -eq 0 ]; then
  # ── 7. 真实模型基准（需要模型端点，慢）
  # 端点不可用时它会自己输出 skipped 并返回 0，这里不算失败——
  # 环境问题不该让自检变红，但要能看出来它被跳过了。
  IGNORE_RC=1
  run_case "拦截基准（真实模型）" "skipped|B 类拦截率" \
    "$PY" bench/run_llm.py
fi
IGNORE_RC=0

echo
if [ $FAILED -eq 0 ]; then
  printf "  %s全部通过%s（%d 项套件，约 %d.%d 秒）\n" \
    "$BOLD$GREEN" "$OFF" "$RAN" "$((TOTAL_MS / 1000))" "$(( (TOTAL_MS % 1000) / 100 ))"
  echo "${DIM}  说明：拦截基准里「AI 编造数值 6/7」中未拦的那条是已知的 gain_lin 10% 容差取舍，不算失败。${OFF}"
  exit 0
else
  printf "  %s有 %d 项失败%s：%s\n" "$BOLD$RED" "$FAILED" "$OFF" "${FAIL_NAMES[*]}"
  echo "${DIM}  先看 $LOG${OFF}"
  exit 1
fi
