# AI 拦截能力基准：契约

## 为什么做这个

`docs/COMPETITIVE.md` 说我们唯一的差异化是「会说'不'的 AI」——
指标对账 + 断言双保险 + 测不到判 NaN。**但这只是主张，没有任何数字。**

这个基准把它变成可度量的东西：**AI 出错时，我们抓不抓得住。**

## 两条铁律

1. **必须跑真实代码路径。** 基准里不能另写一套判定逻辑，
   必须调用 `copilot/feasibility.py`、`copilot/verify.py`、
   `ccl/ai/spec_check.py`、`ccl/assertions.py` 里**现有的函数**。
   否则量的是基准自己，不是产品。

2. **必须同时量误杀率。** 只报拦截率是废指标——
   一个把所有输入都拒绝的系统，拦截率是 100%，但毫无价值。
   每个「该拦」的用例，都要配一个「不该拦」的对照。

## 两个指标的定义

| 指标 | 定义 | 判定 |
|---|---|---|
| **拦截率**（recall） | 该拦的用例里，真的被拦下的比例 | 越高越好，目标 100% |
| **误杀率**（false positive） | 不该拦的用例里，被误拦的比例 | **越低越好，目标 0%** |

两个必须一起报。只给拦截率不算完成。

## 数据格式（严格，供汇总器消费）

每个基准脚本都要能算出这个结构，并写成 JSON：

```json
{
  "layer": "gates",
  "cases": [
    {
      "id": "stopband_rc_60db",
      "category": "物理不可行",
      "expect": "reject",
      "caught": true,
      "detail": "60dB 阻带衰减在一阶 RC 上做不到"
    },
    {
      "id": "stopband_rc_20db",
      "category": "物理不可行",
      "expect": "accept",
      "caught": false,
      "detail": ""
    }
  ]
}
```

- `expect`: `"reject"`（该拦）或 `"accept"`（不该拦）
- `caught`: 实际是否被判为问题/拒绝
  - `expect=="reject"` 时，`caught=true` 表示**正确拦下**
  - `expect=="accept"` 时，`caught=true` 表示**误杀**（这是坏事）
- 汇总时：
  - 拦截率 = `expect=="reject"` 中 `caught==true` 的比例
  - 误杀率 = `expect=="accept"` 中 `caught==true` 的比例

## 现有闸门接口（用这些，别自己造）

```python
from copilot import feasibility as F
F.evaluate(topology_id, spec, *, order=1, q=None, gbw_hint=None, stopband=None) -> Verdict
    # Verdict 只有 .issues : list[Issue]；空列表 = 可行
F.check_opamp_gbw(topology_id, gain, bw, gbw_hint=None) -> Issue | None
F.check_stopband_order(topology_id, fc, atten_db, ratio) -> Issue | None
F.check_passive_q(topology_id, q) -> Issue | None
F.check_sk_high_q(topology_id, q, order=2) -> Issue | None
F.check_divider_ratio(topology_id, vout, vin) -> Issue | None
F.check_component_range(topology_id, fc) -> Issue | None
F.required_order_table(ratio, targets=(20,40,60,80)) -> list[tuple[float,int]]
F.rc_one_pole_atten_db(ratio) -> float
F.order_for_attenuation(atten_db, ratio, kind="butterworth") -> int

from copilot import verify as V
V.verify(request: str, topology_id: str, spec: dict) -> list[Conflict]
    # Conflict(code, message, said, got)；空列表 = 无冲突
V.expect_topology(request) -> set[str] | None

from ccl.ai import spec_check as SC
SC.parse_targets(prompt) -> list[Target]      # Target(key, value, raw, bound)
SC.check_targets(targets, solution, node="out") -> list[Miss]   # Miss(target, actual)

# 断言层
ccl.assertions.Expect(kind, target, value, tol=...)
ccl.assertions.evaluate(expects, circuit, ac_sol=..., op_sol=..., tran_sol=...)
```

可用拓扑 id 见 `copilot/topologies.py` 的 `REGISTRY`（用
`python3 -c "import sys;sys.path.insert(0,'.');from copilot import topologies as T;print(list(T.REGISTRY))"` 查）。

## 文件所有权（严格）

| 文件 | 负责人 |
|---|---|
| `bench/gates_cases.py`、`bench/run_gates.py` | **gates-bench** |
| `bench/llm_cases.py`、`bench/run_llm.py` | **llm-bench** |
| `bench/run_bench.py`、`bench/README.md` | Lead |
| `bench/CONTRACT.md`（本文件） | Lead |

**不许修改** `ccl/`、`copilot/`、`web/`、`tests_ccl/`、`tests/`、`tests_api/`、`tests_ui/`、`docs/`。
如果发现闸门本身有 bug：**如实报告，不要顺手改**（改代码要单独走一轮）。

## 诚实要求

- 拦截率不是 100% 就如实报。**发现漏网比掩盖有价值。**
- 每条用例都要写清"它在防什么真实场景"。
- 找不到合适参数而跳过某类用例，要在报告里说明原因，不要悄悄省略。
