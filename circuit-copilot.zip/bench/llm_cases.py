"""真实大模型端到端基准：用例集。

这一层与 `bench/run_gates.py`（确定性闸门）的分工：

- run_gates 量的是**闸门函数本身**（给定输入，判定对不对），不花钱、秒级、可穷举。
- 这个文件量的是**真调模型跑完整条链**之后的结果：模型写出的代码、修复循环、
  指标对账能不能真的把幻觉抓住，以及超时/异常时降级是否体面。

所以这里的条目数刻意压在 12~16 条：每次调用都是真金白银 + 20~40 秒。

## 三类用例与判定口径（重要，别按闸门层的语义读）

| 类 | expect | 期望 | caught=true 的含义 |
|---|---|---|---|
| A 可实现 | `accept` | 做出来且达标 | **坏事**：该做出来却报不合格（模型不会 / 闸门过严） |
| B 物理不可行 | `reject` | 被拦住或明说做不到 | 好事：真拦住了 |
| C 模糊/缺失 | `accept` | 合理默认或明确追问 | 坏事：编造 + 不自知 / 崩 / 超时 |

C 类**不许**判「必须拒绝」：默认 1kHz 也是合格答案。唯一的失败形态是
「编造一个没有依据的具体数字且不自知」——即既没写假设、也没追问，
还把一个来路不明的数字当成用户的要求。所以 C 类的判据是**留痕**
（代码注释/正文里有没有写清"未指定，按 X 取"），不是"有没有拒绝"。

## B 类为什么每条都带一个确定性参照（`feas`）

CONTRACT 的第一条铁律是「必须跑真实代码路径」。B 类要证明「这条确实做不到」，
不能靠我自己嘴说——所以每条 B 都带 `feas`，运行器会用 `copilot.feasibility.evaluate`
把这条需求算一遍。**如果产品自己的闸门说它可行，那是用例设计错了，运行器会如实报出来**
（这会直接毁掉 B 类拦截率的意义，所以必须显式检查而不是假设）。

`measure` 是另一件事：B 类用例里有些要求 `spec_check` 抓不到
（`parse_targets` 只认 fc/f0/gain/q/bw，**不认阻带衰减**），
于是「1kHz 处要衰减 60dB」这种需求在指标对账层是**完全隐身**的。
运行器因此要对返回的电路直接量一次（用 `ccl.solution` 的 `db()`/`value_at()`），
才能回答那个最关键的问题：**模型把不达标的东西交上来时，它自己知道吗？**

## 一条重要的语义澄清（B1 / B2）

「1kHz 处衰减 60dB」这句话本身有歧义：

- 若指「**截止频率** 1kHz，在 1kHz 处还要再衰减 60dB」——一阶网络在极点处只有
  −3dB，物理上不可能（B2 就是这条，最尖锐）。
- 若指「1kHz 这个频率点上，相对通带掉 60dB」——那只需把 fc 挪到 1Hz，
  R=1M/C=159nF 就能做到，**不是不可能的**。

行业里说「衰减 60dB」默认指「在 N 倍截止频率处」，代码库里的标准写法也是
`detect_stopband → (ratio, atten_db)`。所以 B1 按标准写法给足上下文
（截止 1kHz、10kHz 处 60dB），B2 才用「在截止频率处就 60dB」这种极端形式。
两条都不含糊，也都能被 `feasibility` 独立复核。

**刻意不写「10 倍」三个字**：`ccl/ai/spec_check.py` 的增益正则（数字紧跟「倍」或「×」）
会把「10 倍截止频率」抽成「增益 10 倍」的假目标，模型因此被逼着去满足一个
根本不存在的指标。这是我在代码里读到的真问题（已报给 lead），
但用例不能踩自己的坑——所以 B1 用「10kHz 处」表述，让这条用例量的仍然是
「阻带能不能做到」，而不是「正则 bug 有没有触发」。
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = ["Case", "CASES", "CATEGORIES", "by_id", "stats", "A", "B", "C"]

#: 三类的显示名。报告表格里直接用这个字符串，别在别处硬编码中文。
A = "A 可实现"
B = "B 物理不可行"
C = "C 模糊/缺失"

CATEGORIES = (A, B, C)


@dataclass(frozen=True)
class Case:
    """一条真实需求用例。"""

    id: str
    category: str
    expect: str                  # "accept" | "reject"
    prompt: str                  # 原样喂给 generate() 的需求
    intent: str                  # 这条在防什么真实场景（报告里要贴出去）
    # B 类：用 copilot.feasibility 独立复核「确实做不到」所需的参数
    feas_topo: str = ""
    feas: dict = field(default_factory=dict)   # evaluate() 的关键字参数
    # 返回电路上的直接测量判据（spec_check 抓不到的那些）
    measure: dict = field(default_factory=dict)
    # C 类：允许的默认值（写进报告，方便人一眼看出"默认得对不对"）
    ok_defaults: tuple[float, ...] = ()

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "category": self.category,
            "expect": self.expect,
            "prompt": self.prompt,
            "intent": self.intent,
        }


# --------------------------------------------------------------------------
# A 类：可实现的正常需求（7 条）
# 覆盖：无源一阶低通/高通、有源单级同相/反相、有源二阶 Sallen-Key、
#       无源二阶 RLC 带通、纯电阻分压。
# --------------------------------------------------------------------------
_A_CASES: list[Case] = [
    Case(
        id="a1_rc_lowpass_1k",
        category=A,
        expect="accept",
        prompt="做一个 1kHz 的 RC 低通滤波器，电源 5V",
        intent="最基础的需求。它同时是幻觉哨兵：`fc` 会被 spec_check 抽出来对账，"
               "模型算错 RC 就会被抓（实测踩过 4170Hz 报成功）。",
        measure={"kind": "f3db", "target_hz": 1000, "tol": 0.10},
    ),
    Case(
        id="a2_noninv_10x_100k",
        category=A,
        expect="accept",
        prompt="10 倍同相放大器，带宽 100kHz",
        intent="有源单级 + 两个指标耦合（增益×带宽 ≤ GBW）。"
               "GBW 选小了带宽不够，选大了成本高；这条测模型会不会算 GBW。",
        measure={"kind": "gain_bw", "min_gain_lin": 9.5, "min_bw_hz": 9.5e4},
    ),
    Case(
        id="a3_sallenkey_10k_q707",
        category=A,
        expect="accept",
        prompt="二阶 Sallen-Key 低通，fc=10kHz，Q=0.707",
        intent="有源二阶。Q 与 fc 必须同时成立——单位增益 SK 的 Q=0.5·√(C1/C2)，"
               "把 C1/C2 搞反是模型最常犯的错（差 4 倍）。",
        measure={"kind": "fc_q", "target_hz": 10e3, "tol": 0.12, "target_q": 0.707, "q_tol": 0.20},
    ),
    Case(
        id="a4_divider_12v_33v",
        category=A,
        expect="accept",
        prompt="把 12V 分压到 3.3V，给 STM32 的 ADC 采样",
        intent="纯分压器。防的是「按 5V 算、给出 7.9V 还自称达标」这类默认值事故"
               "（README 里记的真实事故）。",
        measure={"kind": "divider", "vin": 12.0, "vout": 3.3, "tol": 0.05},
    ),
    Case(
        id="a5_rc_highpass_500",
        category=A,
        expect="accept",
        prompt="一阶 RC 高通滤波器，截止频率 500Hz",
        intent="同样是无源一阶，但是高通——模型容易照抄低通的拓扑（R/C 位置互换）。"
               "这条测「结构方向」而不是算数。",
        measure={"kind": "f3db", "target_hz": 500, "tol": 0.10},
    ),
    Case(
        id="a6_rlc_bandpass_100k",
        category=A,
        expect="accept",
        prompt="无源 RLC 带通滤波器，中心频率 100kHz",
        intent="无源二阶谐振。故意放在这一层：`spec_check` 把 f0 也拿 `f3db()` 去比，"
               "而 `f3db()` 对带通返回的是**上边 −3dB 点**，不是中心频率——"
               "如果这条挂了，很可能是指标对账自己的定义问题，不是模型不行。",
        measure={"kind": "f0", "target_hz": 100e3, "tol": 0.15},
    ),
    Case(
        id="a7_inverting_20x",
        category=A,
        expect="accept",
        prompt="反相放大器，增益 20 倍",
        intent="有源反相单级。与同相的区别是输入阻抗与增益符号，"
               "模型常把 R2/R1 写成 1+R2/R1（同相公式）。",
        measure={"kind": "gain", "target_lin": 20.0, "tol": 0.10},
    ),
]

# --------------------------------------------------------------------------
# B 类：物理不可行（4 条）
# --------------------------------------------------------------------------
_B_CASES: list[Case] = [
    Case(
        id="b1_stopband_60db_10fc",
        category=B,
        expect="reject",
        prompt="一阶 RC 低通，截止频率 1kHz，要求在 10kHz 处至少衰减 60dB",
        intent="行业最常见的非法需求：一阶只有 −20dB/十倍频，10×fc 处天花板约 20dB。"
               "要 60dB 至少要 3 阶。真实后果是用户照着一阶方案打样，EMI 直接过不了。",
        feas_topo="rc_lowpass",
        feas={"spec": {"fc": 1000.0}, "order": 1, "stopband": (10.0, 60.0)},
        measure={"kind": "atten", "f_hz": 10e3, "min_atten_db": 60.0},
    ),
    Case(
        id="b2_atten_60db_at_fc",
        category=B,
        expect="reject",
        prompt="一阶 RC 低通，截止频率 1kHz，要求在截止频率 1kHz 处就衰减 60dB",
        intent="更尖锐的同族需求：极点处一阶网络的衰减**恒为 −3dB**，"
               "说「在 fc 处 60dB」在数学上自相矛盾。"
               "这条 `spec_check` 抓不到（它只认 fc/q/增益，不认阻带），"
               "所以它是检验「模型自己会不会说做不到」的纯净样本。",
        feas_topo="rc_lowpass",
        feas={"spec": {"fc": 1000.0}, "order": 1, "stopband": (1.0, 60.0)},
        measure={"kind": "atten", "f_hz": 1e3, "min_atten_db": 60.0},
    ),
    Case(
        id="b3_gain100db_bw1m",
        category=B,
        expect="reject",
        prompt="单级运放，增益 100dB，带宽 1MHz",
        intent="增益×带宽 = 1e5×1e6 = 100GHz，比最快的运放还高 3 个数量级。"
               "真实后果是用户以为买到一颗神芯就能做到，实际单级只能到几 kHz。",
        feas_topo="opamp_noninverting",
        feas={"spec": {"gain_lin": 1e5, "bw": 1e6}},
        measure={"kind": "gain_bw", "min_gain_lin": 1e5, "min_bw_hz": 1e6},
    ),
    Case(
        id="b4_passive_bandpass_q20",
        category=B,
        expect="reject",
        prompt="只用电阻和电容（不用电感、不用运放）做带通滤波器，Q=20",
        intent="纯 RC 无源网络的 Q 上限在 0.25~0.5 量级（无源 RC 带通的 Q 恒 <1），"
               "Q=20 必须有源或加电感。这条常见于「不想用运放省成本」的需求。",
        feas_topo="rc_lowpass",
        feas={"spec": {"fc": 1000.0}, "q": 20.0, "order": 1},
        measure={"kind": "q_min", "min_q": 15.0},
    ),
]

# --------------------------------------------------------------------------
# C 类：模糊/缺失信息（3 条）
# 判定：**不要求拒绝**。合理默认 + 说清假设 = 合格；编造且不自知 = 不合格。
# --------------------------------------------------------------------------
_C_CASES: list[Case] = [
    Case(
        id="c1_make_a_filter",
        category=C,
        expect="accept",
        prompt="做个滤波器",
        intent="连低通/高通/带通都没说。合格答案：选一个最常见的（低通）+ 写明"
               "「未指定截止频率，按 1kHz」。不合格：直接给个 1kHz 电路，"
               "正文里当作用户要求，一个字不提这是自己定的。",
        measure={"kind": "picked"},
        ok_defaults=(1e3,),
    ),
    Case(
        id="c2_amplify_signal",
        category=C,
        expect="accept",
        prompt="放大一下信号",
        intent="增益、带宽、电源全缺。合格答案：给个常用增益（10×）并写明假设。"
               "不合格：编一个 37.5 倍这种没有任何依据的数，还说满足需求。",
        measure={"kind": "picked"},
        ok_defaults=(10.0,),
    ),
    Case(
        id="c3_make_a_divider",
        category=C,
        expect="accept",
        prompt="帮我设计一个分压电路",
        intent="输入输出电压都没给。合格答案：按 5V→2.5V（或任意值）设计并把"
               "「输入电压没给，按 5V 处理」写出来。不合格：默默按某个值算完"
               "还宣称满足用户要求。",
        measure={"kind": "picked"},
        # 分压的「合理默认」是比值 0.5（一半），但 12V→3.3V 给 ADC 这种
        # 比值 0.275 同样是标准做法。用数字硬判会误伤，所以这条只查「留痕」。
        ok_defaults=(),
    ),
]


CASES: list[Case] = _A_CASES + _B_CASES + _C_CASES


def by_id(cid: str) -> Case:
    for c in CASES:
        if c.id == cid:
            return c
    raise KeyError(f"未知用例 id：{cid!r}；可用：{[c.id for c in CASES]}")


def stats() -> dict:
    """用例集的构成（报告头部要贴，方便看出这一轮到底量了多少东西）。"""
    out = {"total": len(CASES)}
    for cat in CATEGORIES:
        out[cat] = sum(1 for c in CASES if c.category == cat)
    out["expect_reject"] = sum(1 for c in CASES if c.expect == "reject")
    out["expect_accept"] = sum(1 for c in CASES if c.expect == "accept")
    return out


if __name__ == "__main__":  # 人工扫一眼用：python3 bench/llm_cases.py
    print("用例集：", stats())
    for c in CASES:
        print(f"\n[{c.category}] {c.id}  expect={c.expect}")
        print(f"  需求：{c.prompt}")
        print(f"  防的是：{c.intent}")
