"""确定性闸门基准 —— 用例集。

## 这一层量什么

「AI 给出一个错误输出时，我们抓不抓得住」。

**不调**大模型。每个"AI 的错误输出"都是手工写好的输入，直接喂给闸门函数：

- `copilot/feasibility.py`  物理可行性（要拦「物理做不到」）
- `copilot/verify.py`       需求 ↔ 规格对账（要拦「说的数和设计的数不符」）
- `copilot/topologies.py`   REGISTRY（要拦「不存在的拓扑」）
- `ccl/ai/spec_check.py`    AI 声明的数字 ↔ 仿真实测（要拦「编造数值」）
- `ccl/assertions.py` + `ccl/solution.py`  断言层与「测不到判 None」口径

好处：毫秒级、完全可复现（不依赖模型随机性）、谁都能复跑验证。
代价：只能覆盖**确定性**的部分；模型的话术、幻觉的语义层面，这一层看不见。
那部分由 `bench/llm_cases.py` 负责。

## 判定约定（与 bench/CONTRACT.md 一致）

| 字段 | 含义 |
|---|---|
| `expect="reject"` | 该拦。`caught=True` 表示**真的拦住**（好事） |
| `expect="accept"` | 不该拦。`caught=True` 表示**误杀**（坏事） |

每个 Case 的 `fn()` 返回 `(caught, detail)`：
- `caught`：闸门是否把这个输入判为问题/拒绝
- `detail`：**闸门自己给出的理由**（编码 + 证据），不是基准自己编的判词。
  这是"有理由地拦"而不是"瞎拦"的证据。

## 闸门口径的两个注意点

1. `feasibility` 的 `Issue` 有 `severity`：`hard`（做不到）和 `tight`（能做但勉强）。
   两者都算"判为问题"（都会进 `Verdict.issues`），detail 里标出 severity，
   读表的人自己判断是不是"过度告警"。
2. "不该拦"的对照里**不能出现 tight**，否则量的是设计取舍而不是误杀。
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

from copilot import feasibility as F
from copilot import scope as _SC
from copilot import topologies as T
from copilot import verify as V

import ccl
from ccl import Circuit, GND
from ccl.ai import spec_check as SC
from ccl.assertions import Expect, evaluate
from ccl.devices import OpAmp, PulseSource, SinSource


# --------------------------------------------------------------------------
# 用例容器
# --------------------------------------------------------------------------
@dataclass
class Case:
    id: str
    category: str
    expect: str          # "reject" | "accept"
    scenario: str        # 防的是哪个真实场景（人话）
    fn: Callable[[], tuple[bool, str]]


def _issues_text(issues, limit: int = 2) -> str:
    """把闸门给出的 Issue 压成一行：编码／标题／证据。"""
    if not issues:
        return ""
    parts = []
    for i in issues[:limit]:
        sev = "" if getattr(i, "severity", "hard") == "hard" else f"[{i.severity}]"
        parts.append(f"{i.code}{sev}: {i.title}")
    return "；".join(parts)


def _conflicts_text(cs) -> str:
    return "；".join(f"{c.code}: {c.message}" for c in cs)


# --------------------------------------------------------------------------
# 共用的仿真夹具（只在需要时跑，并且只跑一次）
#
# 这里用真实的 ngspice：claude「AI 声称的数 vs 实测」这类用例必须有一个
# 可信的实测值，手编一个数字就变成"量基准自己"了。
# --------------------------------------------------------------------------
_SIM_CACHE: dict[tuple, object] = {}


def _rc_lowpass_ac(fc: float, f_start: float, f_stop: float, points: int = 200):
    """一阶 RC 低通的 AC 解（R=1k，C 由 fc 定）。"""
    key = ("rc_ac", float(fc), float(f_start), float(f_stop), int(points))
    if key not in _SIM_CACHE:
        c = Circuit(f"rc{fc:g}")
        c.V("in", "0", dc=0.0, ac=1.0)
        c.R("in", "out", 1e3)
        c.C("out", "0", 1.0 / (2 * math.pi * 1e3 * fc))
        _SIM_CACHE[key] = c.ac(f_start, f_stop, points)
    return _SIM_CACHE[key]


def _noninv_amp_ac(gain: float = 9.5, gbw: float = 1e7):
    """同相放大器（R1=1k，R2=(gain-1)k），实测增益 9.4991。"""
    key = ("amp_ac", float(gain), float(gbw))
    if key not in _SIM_CACHE:
        c = Circuit("amp")
        c.V("in", "0", dc=0.0, ac=1.0)
        c.add(OpAmp("in", "n1", "out", gbw=gbw, a0=1e5))
        c.R("n1", "0", 1e3)
        c.R("out", "n1", (gain - 1.0) * 1e3)
        _SIM_CACHE[key] = c.ac(1.0, 1e4, 200)
    return _SIM_CACHE[key]


def _rc_step_tran(tau: float = 1e-3):
    """单次阶跃（PULSE），平台足够长 —— 瞬态指标应该能正常测到。"""
    key = ("rc_step", float(tau))
    if key not in _SIM_CACHE:
        c = Circuit("step")
        c.add(PulseSource("in", "0", v1=0.0, v2=1.0, tr=1e-9, tf=1e-9,
                          pw=90e-3, per=100e-3))
        c.R("in", "out", 1e3)
        c.C("out", "0", tau / 1e3)
        _SIM_CACHE[key] = c.tran(tau / 500.0, tau * 50)
    return _SIM_CACHE[key]


def _rc_sine_tran(tau: float = 1e-3, freq: float = 1e3):
    """纯正弦激励 —— 没有"平台"，没有超调概念，瞬态指标必须测不到。"""
    key = ("rc_sine", float(tau), float(freq))
    if key not in _SIM_CACHE:
        c = Circuit("sine")
        c.add(SinSource("in", "0", vo=0.0, va=1.0, freq=freq))
        c.R("in", "out", 1e3)
        c.C("out", "0", tau / 1e3)
        _SIM_CACHE[key] = c.tran(tau / 500.0, tau * 10)
    return _SIM_CACHE[key]


# --------------------------------------------------------------------------
# 一、物理不可行
#
# 真实场景：用户（或 AI）提出一个物理上做不到的需求，工具却硬算出一个
# 零件清单，用户拿去打样才发现不行。这一层要在动手之前就拒绝。
# --------------------------------------------------------------------------
def _a1() -> tuple[bool, str]:
    # 真实场景：用户要「一阶 RC 低通，在 10 倍截止频率处衰减 60dB」。
    # 一阶只有 −20dB/十倍频，10×fc 处最多 20.04dB —— 差 40dB，物理上做不到。
    iss = F.check_stopband_order("rc_lowpass", 1e3, 60.0, 10.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _a2() -> tuple[bool, str]:
    # 真实场景：高通版同一类错误 —— 「5 倍截止频率处衰减 40dB」。
    # 一阶在 5×fc 处只有 14.2dB。「要挡掉 50Hz 工频」这种需求经常被写成这样。
    iss = F.check_stopband_order("rc_highpass", 1e3, 40.0, 5.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _a3() -> tuple[bool, str]:
    # 真实场景：用户要求「无源 RC 网络 Q=20」（想要窄带选频）。
    # 无源 RC 只有两个实极点，Q 恒为 0.5 —— Q=20 需要复数极点，必须用有源/有感。
    iss = F.check_passive_q("rc_lowpass", 20.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _a4() -> tuple[bool, str]:
    # 真实场景：用户说「无源 RC 做二阶巴特沃斯（Q=0.707）」。
    # 这句话本身就自相矛盾：无源 RC 不是二阶，也做不出 Q>0.5 的峰化。
    iss = F.check_passive_q("rc_lowpass", 0.707)
    return iss is not None, _issues_text([iss] if iss else [])


def _a5() -> tuple[bool, str]:
    # 真实场景：AI 为了满足窄带需求，给出「Sallen-Key，Q=25」。
    # 单位增益 SK 的 Q 靠 R2/R1 比值硬拉，Q=25 要求比值 > 2000，
    # 1% 电阻会把 Q 误差放大 25 倍 —— 名义值对、实物必偏。
    iss = F.check_sk_high_q("sallen_key_lowpass", 25.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _a6() -> tuple[bool, str]:
    # 真实场景：用户只说「要衰减 60dB」没说在几倍频率处。
    # 若不按惯例的 10×fc 兜底评估，这条要求会**完全绕过**物理校验，
    # 一阶 RC 也敢声称达标。evaluate() 里有这条兜底逻辑，单独验它。
    v = F.evaluate("rc_lowpass", {"fc": 1e3, "atten_db": 60.0})
    return bool(v.issues), _issues_text(v.issues)


def _a7() -> tuple[bool, str]:
    # 对照（不该拦）：同样一阶 RC，10×fc 处要 20dB —— 一阶实测 20.04dB，
    # 刚好够。这是真实可做的需求，拦了就是误杀。
    iss = F.check_stopband_order("rc_lowpass", 1e3, 20.0, 10.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _a8() -> tuple[bool, str]:
    # 对照（不该拦）：Q=0.5 正是无源 RC 的本征值，提这个要求完全合理。
    iss = F.check_passive_q("rc_lowpass", 0.5)
    return iss is not None, _issues_text([iss] if iss else [])


def _a9() -> tuple[bool, str]:
    # 对照（不该拦）：Sallen-Key 做 Q=0.707（巴特沃斯）是教科书标准用法。
    iss = F.check_sk_high_q("sallen_key_lowpass", 0.707)
    return iss is not None, _issues_text([iss] if iss else [])


def _a10() -> tuple[bool, str]:
    # 对照（不该拦）：只说「衰减 20dB」，走默认 10×fc 口径正好一阶够用。
    v = F.evaluate("rc_lowpass", {"fc": 1e3, "atten_db": 20.0})
    return bool(v.issues), _issues_text(v.issues)


# --------------------------------------------------------------------------
# 二、增益带宽积矛盾
#
# 真实场景：AI 写下「100 倍增益 + 1MHz 带宽」，同时选了一颗 GBW=1MHz 的运放。
# 闭环带宽 = GBW/增益 = 10kHz，实际差 100 倍。这类错误在 Bode 图上"看起来对"，
# 只有把 GBW 约束算出来才暴露。
# --------------------------------------------------------------------------
def _b1() -> tuple[bool, str]:
    # 真实场景：用户要「单级 100dB 增益 + 1MHz 带宽」。
    # 需要 GBW = 1e5 × 1e6 = 100GHz —— 常见运放差 3 个数量级。
    iss = F.check_opamp_gbw("opamp_noninverting", 1e5, 1e6)
    return iss is not None, _issues_text([iss] if iss else [])


def _b2() -> tuple[bool, str]:
    # 真实场景：AI 选了 GBW=1MHz 的通用运放（LM358 档），却要求 10 倍增益 + 1MHz 带宽。
    # 实际闭环带宽只有 100kHz。这是"器件选型"和"指标"打架的典型。
    iss = F.check_opamp_gbw("opamp_noninverting", 10.0, 1e6, gbw_hint=1e6)
    return iss is not None, _issues_text([iss] if iss else [])


def _b3() -> tuple[bool, str]:
    # 真实场景：差分放大器要 100 倍增益 + 1MHz 带宽，配 1MHz 的运放。
    # 差分拓扑的噪声增益更高，实际更糟 —— 必须拦。
    iss = F.check_opamp_gbw("difference_amp", 100.0, 1e6, gbw_hint=1e6)
    return iss is not None, _issues_text([iss] if iss else [])


def _b4() -> tuple[bool, str]:
    # 真实场景：spec 里写的是 gain_db=40（=100 倍）而不是 gain_lin，
    # evaluate() 要能换算成 100 倍再算 GBW，否则这条约束被静默跳过。
    v = F.evaluate("opamp_noninverting", {"gain_db": 40.0, "bw": 1e6}, gbw_hint=1e6)
    return bool(v.issues), _issues_text(v.issues)


def _b5() -> tuple[bool, str]:
    # 对照（不该拦）：10 倍增益 + 100kHz 带宽，配 GBW=1MHz 的运放 ——
    # 需要 1MHz，正好在 5% 裕量内，完全可做。
    iss = F.check_opamp_gbw("opamp_noninverting", 10.0, 1e5, gbw_hint=1e6)
    return iss is not None, _issues_text([iss] if iss else [])


def _b6() -> tuple[bool, str]:
    # 对照（不该拦）：20dB（10 倍）+ 100kHz，未指定器件 —— 需求侧完全合理。
    iss = F.check_opamp_gbw("opamp_noninverting", 10.0, 1e5)
    return iss is not None, _issues_text([iss] if iss else [])


def _b7() -> tuple[bool, str]:
    # 对照（不该拦）：反相 2 倍 + 100kHz，GBW 只要 200kHz，随手一颗运放都行。
    iss = F.check_opamp_gbw("opamp_inverting", 2.0, 1e5, gbw_hint=1e6)
    return iss is not None, _issues_text([iss] if iss else [])


# --------------------------------------------------------------------------
# 三、需求自相矛盾（verify：说的数 vs 设计的数）
#
# 真实场景（项目里真实发生过）：「把 12V 分压到 3.3V」被解析成 vout=6.0，
# 系统还判定「达标」。一次正则写漏就产出一个看起来成功、实际错得离谱的答案。
# --------------------------------------------------------------------------
def _c1() -> tuple[bool, str]:
    # 真实场景：用户说 12V→3.3V 给 STM32 ADC，系统按 6.0V 设计。
    # 拿去打样会把 ADC 打坏 —— 这是最致命的一类。
    cs = V.verify("把12V分压到3.3V给STM32的ADC采样", "divider",
                  {"vout": 6.0, "__Vin": 12.0})
    return bool(cs), _conflicts_text(cs)


def _c2() -> tuple[bool, str]:
    # 真实场景：用户要「增益 10 倍」，系统按 100 倍设计（小数点/单位差一位）。
    cs = V.verify("同相放大，增益 10 倍，带宽 100kHz", "opamp_noninverting",
                  {"gain_lin": 100.0})
    return bool(cs), _conflicts_text(cs)


def _c3() -> tuple[bool, str]:
    # 真实场景：用户写「截止频率 1kHz」，系统按 10kHz 设计（k 和 10k 混了）。
    cs = V.verify("低通滤波，截止频率 1kHz", "rc_lowpass", {"fc": 1e4})
    return bool(cs), _conflicts_text(cs)


def _c4() -> tuple[bool, str]:
    # 真实场景：用户说「在 10 倍截止频率处**衰减** 60dB」，系统把它当成
    # 「**增益** 60dB」去设计 —— 滤波器被做成了放大器，方向完全反了。
    cs = V.verify("在10倍截止频率处衰减 60dB", "rc_lowpass", {"gain_db": 60.0})
    return bool(cs), _conflicts_text(cs)


def _c5() -> tuple[bool, str]:
    # 真实场景：用户说「把 24V 分压到 3.3V」，系统按 Vin=12V 算分压比。
    # 输出值碰巧对（3.3V 一致），但**输入电压错了**，分压比是错的。
    # 期望：应当报 conflict。这是本基准预期会漏网的一条（见报告），
    # 原因是 verify() 在「文本里有两个电压」时只核对最后一个（=输出）。
    cs = V.verify("把24V分压到3.3V", "divider", {"vout": 3.3, "__Vin": 12.0})
    return bool(cs), _conflicts_text(cs)


def _c6() -> tuple[bool, str]:
    # 真实场景：需求写「带宽 1kHz」，而最终 spec 里 bw=10kHz（差 10 倍）。
    # 期望：应当发现不符。本基准预期会漏网 —— verify() 只把原文频率与
    # spec 的 fc/f0 比，spec 里的 bw 从未参与对账。
    cs = V.verify("低通滤波，带宽 1kHz", "rc_lowpass", {"fc": 1e3, "bw": 1e4})
    return bool(cs), _conflicts_text(cs)


def _c7() -> tuple[bool, str]:
    # 对照（不该拦）：5V→2.5V，spec 完全一致。
    cs = V.verify("把5V分压到2.5V", "divider", {"vout": 2.5, "__Vin": 5.0})
    return bool(cs), _conflicts_text(cs)


def _c8() -> tuple[bool, str]:
    # 对照（不该拦）：截止频率 1kHz 的低通，spec 里就是 1kHz。
    cs = V.verify("低通滤波，截止频率 1kHz", "rc_lowpass", {"fc": 1e3})
    return bool(cs), _conflicts_text(cs)


def _c9() -> tuple[bool, str]:
    # 对照（不该拦）：增益 10 倍，spec 就是 10 倍。
    cs = V.verify("同相放大，增益 10 倍", "opamp_noninverting", {"gain_lin": 10.0})
    return bool(cs), _conflicts_text(cs)


# --------------------------------------------------------------------------
# 四、AI 编造数值（spec_check：AI 声明的数 vs 仿真实测）
#
# 真实场景：需求「二阶低通 10kHz Q=0.707」，AI 生成的代码跑通了、仿真收敛了，
# 实测 f3db=4170Hz（差 58%），而 generate() 返回 ok=True。
# 这一层负责在"看起来成功"里把数字对账出来。
# 实测基准电路：同相放大器实测增益 9.4991，一阶 RC 实测 fc 1.0000kHz。
# --------------------------------------------------------------------------
def _d1() -> tuple[bool, str]:
    # 真实场景：AI 文本宣称「增益 20 倍」，实际 9.50 倍（差 52%）。
    misses = SC.check_targets(SC.parse_targets("同相放大，增益 20 倍"), _noninv_amp_ac())
    txt = "；".join(m.message() for m in misses)
    return bool(misses), txt


def _d2() -> tuple[bool, str]:
    # 真实场景：AI 宣称「截止频率 2kHz」，实测 1.000kHz（差 2 倍）——
    # 元件值算错一个 2π 就会这样。
    misses = SC.check_targets(SC.parse_targets("低通滤波，截止频率 2kHz"),
                              _rc_lowpass_ac(1e3, 1.0, 1e6))
    txt = "；".join(m.message() for m in misses)
    return bool(misses), txt


def _d3() -> tuple[bool, str]:
    # 真实场景：AI 宣称「增益 10 倍」，实测 9.50 倍（差 5.3%）。
    # **这是任务书里点名的例子，期望它被抓住。**
    # 实际会漏网：spec_check 对 gain_lin 的容差是 10%，5.3% 落在容差内 ——
    # 这是刻意的容差设计（元件 1% 容差 + 运放 A0 有限），不是 bug。
    # 如实记为漏网，并在报告里说明取舍：想抓住它就等于把 5% 的元件容差判死。
    misses = SC.check_targets(SC.parse_targets("同相放大，增益 10 倍"), _noninv_amp_ac())
    txt = "；".join(m.message() for m in misses)
    return bool(misses), txt


def _d4() -> tuple[bool, str]:
    # 真实场景：AI 宣称「带宽 20kHz」，实测 ~1kHz（差 20 倍）。
    misses = SC.check_targets(SC.parse_targets("低通滤波，带宽 20kHz"),
                              _rc_lowpass_ac(1e3, 1.0, 1e6))
    txt = "；".join(m.message() for m in misses)
    return bool(misses), txt


def _d5() -> tuple[bool, str]:
    # 真实场景：AI 宣称「截止频率 10kHz」，实测 1.000kHz（k 与 10k 混淆）。
    misses = SC.check_targets(SC.parse_targets("低通滤波，截止频率 10kHz"),
                              _rc_lowpass_ac(1e3, 1.0, 1e6))
    txt = "；".join(m.message() for m in misses)
    return bool(misses), txt


def _d6() -> tuple[bool, str]:
    # 对照（不该拦）：AI 说 9.5 倍，实测 9.4991 —— 一致。
    misses = SC.check_targets(SC.parse_targets("同相放大，增益 9.5 倍"), _noninv_amp_ac())
    txt = "；".join(m.message() for m in misses)
    return bool(misses), txt


def _d7() -> tuple[bool, str]:
    # 对照（不该拦）：AI 说 1kHz，实测 1.0000kHz。
    misses = SC.check_targets(SC.parse_targets("低通滤波，截止频率 1kHz"),
                              _rc_lowpass_ac(1e3, 1.0, 1e6))
    txt = "；".join(m.message() for m in misses)
    return bool(misses), txt


def _d8() -> tuple[bool, str]:
    # 对照（不该拦）：需求是「带宽 1kHz **以上**」（下限语义），
    # 实测 1.0009kHz ≥ 1kHz —— 合格。若把"以上"当成"约等于"，
    # 这条会被判成 0.09% 偏差还行，但方向反的场合（997kHz）就会误杀，
    # 所以下限/上限语义必须在这里也被尊重。
    tg = SC.parse_targets("低通滤波，带宽 1kHz 以上")
    misses = SC.check_targets(tg, _rc_lowpass_ac(1e3, 1.0, 1e6))
    txt = "；".join(m.message() for m in misses) or \
          "bound=" + ",".join(t.bound for t in tg)
    return bool(misses), txt


# --------------------------------------------------------------------------
# 五、器件/拓扑不存在
#
# 真实场景：AI 选了一个 REGISTRY 里不存在的拓扑（「带阻」「LC 低通」「电流镜」），
# 或者语义明显是该用分压/带通，却选了 rc_lowpass。
# 注意：`agent.py` 里 `T.get()` 的 KeyError 被 `except KeyError` **静默吞掉**
# 并回退到 rc_lowpass —— 也就是说闸门会喊，但产品层不一定听得见（见报告 bug#2）。
# --------------------------------------------------------------------------
def _topo_lookup(tid: str) -> tuple[bool, str]:
    try:
        t = T.get(tid)
        return True, f"REGISTRY 命中 {t.id}（{t.name}）"
    except KeyError as e:
        return False, f"REGISTRY 查表抛 KeyError：{e}"


def _e1() -> tuple[bool, str]:
    # 真实场景：用户要「50Hz 工频陷波」，AI 报出拓扑 notch_filter —— 不存在。
    ok, txt = _topo_lookup("notch_filter")
    return (not ok), txt


def _e2() -> tuple[bool, str]:
    # 真实场景：AI 写「LC 低通」——REGISTRY 里只有 rlc_bandpass，没有纯 LC 低通。
    ok, txt = _topo_lookup("lc_lowpass")
    return (not ok), txt


def _e3() -> tuple[bool, str]:
    # 真实场景：AI 想用「电流镜偏置」block —— 工程上真实存在，但本工具不支持。
    ok, txt = _topo_lookup("current_mirror")
    return (not ok), txt


def _e4() -> tuple[bool, str]:
    # 真实场景：需求明确是带通，AI 却给了 rc_lowpass（低通根本挡不住低频侧）。
    cs = V.verify("做一个带通滤波器，中心 1kHz", "rc_lowpass", {"fc": 1e3})
    return bool(cs), _conflicts_text(cs)


def _e5() -> tuple[bool, str]:
    # 真实场景（项目实测过）：同一个需求「把12V分压到3.3V」，
    # 模型 temperature>0 时一次给 divider、一次给 rc_lowpass。
    # 选错拓扑时 -3dB 低通和分压器是完全不同的电路。
    cs = V.verify("把12V分压到3.3V给ADC采样", "rc_lowpass", {"fc": 1e3})
    return bool(cs), _conflicts_text(cs)


def _e6() -> tuple[bool, str]:
    # 对照（不该拦）：存在的拓扑 + 语义与之一致。
    ok, txt = _topo_lookup("sallen_key_lowpass")
    cs = V.verify("低通滤波，截止频率 1kHz", "sallen_key_lowpass", {"fc": 1e3})
    return (not ok) or bool(cs), txt + ("；" + _conflicts_text(cs) if cs else "")


def _e7() -> tuple[bool, str]:
    # 对照（不该拦）：带通需求 + rlc_bandpass。
    ok, txt = _topo_lookup("rlc_bandpass")
    cs = V.verify("做一个带通滤波器，中心 1kHz", "rlc_bandpass", {"f0": 1e3})
    return (not ok) or bool(cs), txt + ("；" + _conflicts_text(cs) if cs else "")


# --------------------------------------------------------------------------
# 六、该判 None 却给数
#
# 真实场景：AI 只跑了 AC 分析，却敢报 rise_time；输入是纯正弦，却敢报超调。
# 纪律是「测不到就返回 None/NaN 并判未达标，绝不编一个看起来正常的数字」。
# 这一类的"该拦"= 闸门确实给出了 NaN/None；"不该拦"= 真跑出来的数必须给得出。
# --------------------------------------------------------------------------
def _f1() -> tuple[bool, str]:
    # 真实场景：只做了 .ac，断言里却写了 rise_time（10–90%）。
    # 时域指标在频域解上不存在 —— 必须 NaN，不能拿群时延之类的东西凑。
    r = evaluate([Expect("rise_time", "out", 1e-3)], None,
                 ac_sol=_rc_lowpass_ac(1e3, 1.0, 1e6), tran_sol=None)
    a = r.results[0].actual
    nan = a is None or (isinstance(a, float) and math.isnan(a))
    return nan, f"rise_time 实测={a}（NaN 表示拒绝给数），ok={r.results[0].ok}"


def _f2() -> tuple[bool, str]:
    # 真实场景：只做了 .ac，却报 overshoot（超调是阶跃响应的属性）。
    r = evaluate([Expect("overshoot_pct", "out", 5.0)], None,
                 ac_sol=_rc_lowpass_ac(1e3, 1.0, 1e6), tran_sol=None)
    a = r.results[0].actual
    nan = a is None or (isinstance(a, float) and math.isnan(a))
    return nan, f"overshoot_pct 实测={a}，ok={r.results[0].ok}"


def _f3() -> tuple[bool, str]:
    # 真实场景：真跑了 .tran，但激励是**纯正弦** —— 没有平台、没有稳态阶跃，
    # 「超调」这个概念不成立（给个数就是编的）。
    sol = _rc_sine_tran()
    a = sol.overshoot_pct("out")
    return a is None, f"overshoot_pct('out')={a}（None = 正确拒绝）"


def _f4() -> tuple[bool, str]:
    # 同类：纯正弦要 settling_time，同样不成立。
    sol = _rc_sine_tran()
    a = sol.settling_time("out")
    return a is None, f"settling_time('out')={a}（None = 正确拒绝）"


def _f5() -> tuple[bool, str]:
    # 真实场景（ccl/CONTRACT.md 亲自点名的反例）：fc≈100Hz 的低通从 1kHz 起扫，
    # 全程在下坡，「参考值」只是区间内最高点，不是真实通带增益。
    # 口径要求：`f3db` 必须返回 None。
    # 期望 → 拦。实测会漏网（见报告 bug#1）：
    # 平坦段判据「相邻两点都在 ref±0.3dB 内」在 200 点/十倍频下恒成立
    # （相邻点只差 0.1dB），于是它"找到"了 1417Hz 这个假交点。
    sol = _rc_lowpass_ac(100.0, 1e3, 1e6)
    a = sol.f3db("out")
    return a is None, f"从 1kHz 起扫 100Hz 低通，f3db={a}（None 才是正确）"


def _f6() -> tuple[bool, str]:
    # 对照（不该拦）：真跑了单次阶跃，rise_time 应该测得出。
    # τ=1ms → 10–90% = 2.2τ = 2.197ms。
    sol = _rc_step_tran()
    a = sol.rise_time("out")
    r = evaluate([Expect("rise_time", "out", 2.2e-3, tol=0.05)], None, tran_sol=sol)
    # caught 语义 = "闸门拒绝了这条断言"，所以这里 = 断言失败（或测不到）。
    return (not r.passed), f"rise_time={a}，断言 ok={r.results[0].ok}"


def _f7() -> tuple[bool, str]:
    # 对照（不该拦）：扫频范围真的覆盖了通带平台（1Hz 起扫，fc=100Hz），
    # f3db 必须给得出数 —— 而且必须是 100Hz 左右。
    sol = _rc_lowpass_ac(100.0, 1.0, 1e6)
    a = sol.f3db("out")
    good = a is not None and abs(a - 100.0) / 100.0 < 0.05
    return (not good), f"f3db={a}"


def _f8() -> tuple[bool, str]:
    # 对照（不该拦）：真阶跃的 steady_state 应该测得出且接近 1.0V。
    sol = _rc_step_tran()
    r = evaluate([Expect("steady_state", "out", 1.0, tol=0.05)], None, tran_sol=sol)
    return (not r.passed), f"steady_state 实测={r.results[0].actual}，ok={r.results[0].ok}"


# --------------------------------------------------------------------------
# 六·五、电压类目标（分压/输出 X 伏）
#
# 真实事故：需求「把 12V 分压到 3.3V」，模型交了一个 Vout=12V 的电路（等于一根导线），
# 而当时 parse_targets 只认 fc/gain/bw/q，**电压目标零对账** → 报 ok=True。
# 这是唯一一个「工具说成功、东西是错的」的口子，所以要有回头看得见的用例守着。
# --------------------------------------------------------------------------
def _divider_circuit(r1: float, r2: float, src: str = "in"):
    c = Circuit("d")
    c.V(src, GND, ac=1)
    c.R(src, "out", r1)
    c.R("out", GND, r2)
    return c


def _k1() -> tuple[bool, str]:
    # 直通：上臂几乎是导线，输出≈Vin。必须被抓。
    tg = SC.parse_targets("把 12V 分压到 3.3V")
    c = _divider_circuit(1.0, 1e9)
    ms = SC.check_targets(tg, c.ac(1, 1e6, 50), circuit=c)
    return bool(ms), "；".join(m.message() for m in ms)


def _k2() -> tuple[bool, str]:
    # 正确的 12→3.3（R1/R2 = 2.636）：不该被判失败。
    tg = SC.parse_targets("把 12V 分压到 3.3V")
    c = _divider_circuit(26.4e3, 10e3)
    ms = SC.check_targets(tg, c.ac(1, 1e6, 50), circuit=c)
    return bool(ms), "；".join(m.message() for m in ms)


def _k3() -> tuple[bool, str]:
    # 分压比错一半（输出 5.17V）：必须被抓。
    tg = SC.parse_targets("把 12V 分压到 3.3V")
    c = _divider_circuit(13.2e3, 10e3)
    ms = SC.check_targets(tg, c.ac(1, 1e6, 50), circuit=c)
    return bool(ms), "；".join(m.message() for m in ms)


def _k4() -> tuple[bool, str]:
    # 源节点名不规范（叫 src_x 而不是 in）：不能因此误判正确电路。
    tg = SC.parse_targets("把 12V 分压到 3.3V")
    c = _divider_circuit(26.4e3, 10e3, src="src_x")
    ms = SC.check_targets(tg, c.ac(1, 1e6, 50), circuit=c)
    return bool(ms), "；".join(m.message() for m in ms)


# --------------------------------------------------------------------------
# 七、能力边界（本工具不做的电路类别）
#
# 真实场景：需求根本不在本工具的能力范围内（开关电源、陷波、振荡器…），
# 而旧行为是**静默兜底**成最接近的拓扑：
#     「做一个 Buck 降压电路，输出 5V」→ 电阻分压网络 → 「✅ 达标，可直接打样」
#     「设计一个 50Hz 工频陷波器」    → RLC **带通**（方向相反，50Hz 原样通过）
# 12 条这样的需求 12 条全中。这不是缺功能，是交付错的东西还宣称达标。
#
# 这一类的「不该拦」尤其重要：全部拒绝的系统拦截率 100% 但毫无价值，
# 而这里最容易被误杀的是「降压」（分压器的正常说法）、
# 「阻带」（低通的规格）、「电流源」（激励元件）——都是看起来像但实际不是。
# --------------------------------------------------------------------------
def _j1() -> tuple[bool, str]:
    # 真实场景：要开关电源。分压器能凑出同样的直流电压，但效率/负载调整率/隔离全不同。
    iss = _SC.detect("做一个 Buck 降压电路，输出 5V")
    return bool(iss), _issues_text(iss)


def _j2() -> tuple[bool, str]:
    # 真实场景：要变压器隔离。现有器件模型只有 R/L/C/二极管/三极管/MOSFET/运放，
    # 没有耦合电感与磁芯，给不出变比与漏感。
    iss = _SC.detect("做一个变压器隔离的 5V 电源")
    return bool(iss), _issues_text(iss)


def _j11() -> tuple[bool, str]:
    # 对照（能力刚补上的一类）：50Hz 工频陷波现在由 Twin-T 支持，
    # 不能再被能力边界拦掉——否则等于「刚学会就宣布不会」。
    iss = _SC.detect("设计一个 50Hz 工频陷波器，把干扰滤掉")
    return bool(iss), _issues_text(iss)


def _j3() -> tuple[bool, str]:
    # 真实场景：要振荡器。它靠正反馈满足巴克豪森判据，不是选频滤波能替代的。
    iss = _SC.detect("做一个 RC 振荡器，频率 1kHz")
    return bool(iss), _issues_text(iss)


def _j4() -> tuple[bool, str]:
    # 真实场景：要恒流源/电流镜——关键指标是负载调整率与温漂，交流扫频答不了。
    iss = _SC.detect("设计一个恒流源 20mA 驱动负载")
    return bool(iss), _issues_text(iss)


def _j5() -> tuple[bool, str]:
    # 真实场景：要整流桥。非线性导通角，小信号线性分析给不出。
    iss = _SC.detect("做一个桥式整流电源")
    return bool(iss), _issues_text(iss)


def _j6() -> tuple[bool, str]:
    # 真实场景：要仪用放大器（三运放）。单运放差分放大输入阻抗低，不能替代。
    iss = _SC.detect("做一个仪用放大器，增益 100")
    return bool(iss), _issues_text(iss)


def _j7() -> tuple[bool, str]:
    # 对照（最关键的防误杀）：「24V 降压到 3.3V」是分压器的正常说法，不是 Buck。
    # 如果闸门认了「降压」这个词，一整类合法需求会被误杀。
    iss = _SC.detect("24V 降压到 3.3V 给单片机供电")
    return bool(iss), _issues_text(iss)


def _j8() -> tuple[bool, str]:
    # 对照：「阻带衰减 60dB」是低通的规格，不是要带阻滤波器。
    iss = _SC.detect("低通滤波器，阻带在 10 倍截止频率处衰减 60dB")
    return bool(iss), _issues_text(iss)


def _j9() -> tuple[bool, str]:
    # 对照：「用电流源激励」说的是分析用的激励元件，不是恒流源电路。
    iss = _SC.detect("用电流源激励这个网络，看输出响应")
    return bool(iss), _issues_text(iss)


def _j10() -> tuple[bool, str]:
    # 对照：正常带通需求必须放行（带通 ≠ 带阻，别把两者混成一条词）。
    iss = _SC.detect("二阶带通滤波器，中心频率 100kHz，带宽 300kHz")
    return bool(iss), _issues_text(iss)


# --------------------------------------------------------------------------
# 八、结构上限（拓扑本身做得到、换结构才做得到）
#
# 真实场景：需求写「四阶带通，中心 1kHz，带宽 800Hz」（Q=1.25）。
# 这句话物理上没问题——但**级联 RC 带通这个结构**做不到：单调上升再单调下降的
# 无源串接没有谐振，Q 上限是 0.50/0.78/0.98（每侧 1/2/3 级）。
#
# 这类错误最危险的地方是「能做出来、但差一个数量级」：实测错误的旧做法
# 目标带宽 200Hz 却给出 2204Hz 的电路，报告照样说达标。所以必须在闸门层拦。
# --------------------------------------------------------------------------
def _i1() -> tuple[bool, str]:
    # 真实场景：「四阶带通 1kHz 带宽 800Hz」→ Q=1.25，超 4 阶的上限 0.78。
    iss = F.check_cascaded_bandpass_q("filter_bandpass_synth", 1.25, 4)
    return iss is not None, _issues_text([iss] if iss else [])


def _i2() -> tuple[bool, str]:
    # 真实场景：「二阶带通 1kHz 带宽 400Hz」→ Q=2.5，超 2 阶的上限 0.50（差 5 倍）。
    iss = F.check_cascaded_bandpass_q("filter_bandpass_synth", 2.5, 2)
    return iss is not None, _issues_text([iss] if iss else [])


def _i3() -> tuple[bool, str]:
    # 真实场景：6 阶也救不了 Q=1.5（上限 0.98）——用户会以为"阶数越高越窄"，
    # 其实每加一级只把上限从 0.50 抬到 0.78 再到 0.98，边际递减。
    iss = F.check_cascaded_bandpass_q("filter_bandpass_synth", 1.5, 6)
    return iss is not None, _issues_text([iss] if iss else [])


def _i4() -> tuple[bool, str]:
    # 真实场景：闸门放行了、但 design() 必须**第二道防线**也拒。
    # 只靠 feasibility 是不够的——调用方可能绕过它直接 design（插件、脚本、检索候选）。
    # 要求：抛 ValueError 且信息里带「上限」，不是返回一个凑数的电路。
    try:
        T.get("filter_bandpass_synth").design({"f0": 1000.0, "bw": 800.0, "order": 4})
    except ValueError as e:
        msg = str(e)
        return ("上限" in msg), f"design 拒绝：{msg[:70]}"
    except Exception as e:                                    # noqa: BLE001
        return False, f"抛了别的异常：{type(e).__name__}: {e}"
    return False, "design 竟然返回了参数——窄带需求被静默做成了宽通带电路"


def _i5() -> tuple[bool, str]:
    # 对照：Q=0.33 宽带的带通，级联结构完全可以做，不该拦。
    iss = F.check_cascaded_bandpass_q("filter_bandpass_synth", 0.33, 2)
    return iss is not None, _issues_text([iss] if iss else [])


def _i6() -> tuple[bool, str]:
    # 对照：Q=0.50 正好等于 2 阶的结构上限，属于边界合法值，不该拦。
    # （q_max 是解析解，浮点会给 0.4999999；这里量的是那个容差有没有做好。）
    iss = F.check_cascaded_bandpass_q("filter_bandpass_synth", 0.50, 2)
    return iss is not None, _issues_text([iss] if iss else [])


def _i7() -> tuple[bool, str]:
    # 对照：Q=0.55 在 4 阶（上限 0.78）以内，不该拦。
    iss = F.check_cascaded_bandpass_q("filter_bandpass_synth", 0.55, 4)
    return iss is not None, _issues_text([iss] if iss else [])


def _i8() -> tuple[bool, str]:
    # 对照（防越权）：**RLC 串联带通是谐振结构，Q=20 完全能做**。
    # 如果级联的 Q 上限被错用到 RLC 上，这里会红 —— 那是把「换结构就能解决」
    # 误判成「做不到」，等于劝用户放弃一个本来能实现的方案。
    iss = F.check_cascaded_bandpass_q("rlc_bandpass", 20.0, 2)
    return iss is not None, _issues_text([iss] if iss else [])


# --------------------------------------------------------------------------
# 八、参数越界（元件值落到买不到/做不出的范围）
#
# 真实场景：AI 为了凑 fc=0.01Hz 算出一个 1F 电容或 100MΩ 电阻，
# 或者为了 fc=1GHz 用集总参数 RC —— 后者物理模型已经不成立。
# --------------------------------------------------------------------------
def _g1() -> tuple[bool, str]:
    # 真实场景：fc=0.01Hz（人体心电/次声波滤波常见需求），
    # R·C ≈ 15.9s —— 需要 1F 级电容或 100MΩ 级电阻，器件不存在。
    iss = F.check_component_range("rc_lowpass", 0.01)
    return iss is not None, _issues_text([iss] if iss else [])


def _g2() -> tuple[bool, str]:
    # 真实场景：fc=1GHz —— 波长已与元件尺寸可比，寄生主导，集总参数模型失效。
    iss = F.check_component_range("rc_lowpass", 1e9)
    return iss is not None, _issues_text([iss] if iss else [])


def _g3() -> tuple[bool, str]:
    # 真实场景：同上，但走 evaluate() 的统一入口（agent 实际调用的是这条路径）。
    v = F.evaluate("rc_lowpass", {"fc": 0.5})
    return bool(v.issues), _issues_text(v.issues)


def _g4() -> tuple[bool, str]:
    # 真实场景：Sallen-Key 想做 2GHz —— 有源滤波器在这个频段根本不工作。
    v = F.evaluate("sallen_key_lowpass", {"fc": 2e9})
    return bool(v.issues), _issues_text(v.issues)


def _g5() -> tuple[bool, str]:
    # 真实场景：多级综合滤波器要 0.05Hz 截止 —— 同样落不到真实元件。
    v = F.evaluate("filter_lowpass_synth", {"fc": 0.05})
    return bool(v.issues), _issues_text(v.issues)


def _g6() -> tuple[bool, str]:
    # 对照（不该拦）：fc=1kHz，元件取 1k/159nF，随手就是标准件。
    iss = F.check_component_range("rc_lowpass", 1e3)
    return iss is not None, _issues_text([iss] if iss else [])


def _g7() -> tuple[bool, str]:
    # 对照（不该拦）：fc=1Hz 正好在阈值上（判据是 fc<1.0），
    # R=1MΩ / C=159nF 完全做得出。边界值不能被误杀。
    iss = F.check_component_range("rc_lowpass", 1.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _g8() -> tuple[bool, str]:
    # 对照（不该拦）：fc=100kHz，集总参数毫无问题。
    iss = F.check_component_range("rc_lowpass", 100e3)
    return iss is not None, _issues_text([iss] if iss else [])


# --------------------------------------------------------------------------
# 八、分压比不可达
#
# 真实场景：用户要「5V 升到 10V」，AI 给了一个电阻分压网络。
# 电阻分压输出恒 ≤ 输入，比值最大趋近 1 —— 物理上不可能升压。
# 这类错误最阴的地方是：算出来的 R1/R2 是**负电阻**，网表跑起来还"收敛"。
# --------------------------------------------------------------------------
def _h1() -> tuple[bool, str]:
    # 真实场景：5V→10V 用无源分压。
    iss = F.check_divider_ratio("divider", 10.0, 5.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _h2() -> tuple[bool, str]:
    # 同一个需求走 evaluate() 的统一入口（spec 里带 Vin，与 agent 的实际调用一致）。
    v = F.evaluate("divider", {"vout": 10.0, "Vin": 5.0})
    return bool(v.issues), _issues_text(v.issues)


def _h3() -> tuple[bool, str]:
    # 真实场景：5V→12V（想给 12V 继电器供电，只想用一个 5V 电源）。
    iss = F.check_divider_ratio("divider", 12.0, 5.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _h4() -> tuple[bool, str]:
    # 真实场景：5V→5.1V，只"升"了 2% —— 看起来无害，但分压器依然做不到。
    # 微小升压是最容易被放过的（比值算出来 0.98，看着像正常衰减）。
    v = F.evaluate("divider", {"vout": 5.1, "Vin": 5.0})
    return bool(v.issues), _issues_text(v.issues)


def _h5() -> tuple[bool, str]:
    # 对照（不该拦）：5V→2.5V，标准二分压。
    iss = F.check_divider_ratio("divider", 2.5, 5.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _h6() -> tuple[bool, str]:
    # 对照（不该拦）：12V→3.3V 给 ADC（项目里的真实高频需求）。
    iss = F.check_divider_ratio("divider", 3.3, 12.0)
    return iss is not None, _issues_text([iss] if iss else [])


def _h7() -> tuple[bool, str]:
    # 对照（不该拦）：5V→5V（比值 1）。理论上界，等价于不衰减；
    # 判据用 vin*1.0001 留了栅极，不该被误杀。
    iss = F.check_divider_ratio("divider", 5.0, 5.0)
    return iss is not None, _issues_text([iss] if iss else [])


# --------------------------------------------------------------------------
# 用例表
# --------------------------------------------------------------------------
CATEGORIES = [
    "物理不可行",
    "增益带宽积矛盾",
    "需求自相矛盾",
    "AI 编造数值",
    "器件/拓扑不存在",
    "该判 None 却给数",
    "参数越界",
    "分压比不可达",
    "结构上限",
    "能力边界",
    "需求解析",   # 含越界边界：两类都是「需求 → 判定表」这条管道上的真实事故
]

# --------------------------------------------------------------------------
# 六、需求解析 × 越界边界（2024 年两轮对抗审计挖出来的真实用例）
#
# 这一组专门补「基准自证循环」的漏洞：原有 87 条全部用**规整句式**
# （「四阶 Butterworth 低通 截止 10kHz」），恰好绕开了四类真实失效：
#   ① 中文习惯说法（品质因数5 / 带宽500Hz / 输出阻抗小于100Ω）
#   ② 量程越界（design() 死写容值 → 静默钳位 → 一个像真值的错数）
#   ③ 方向词反转（「不小于」被当成「小于」）
#   ④ 容差线索挂错元件（电阻 1% 挂到电容头上）
# 每一条都对应一次真实事故，数字来自当年的实测。
# --------------------------------------------------------------------------
def _design_and_judge(text: str):
    """走真实规则链：解析 → design → 仿真 → 判定。返回 (topo, spec, metrics, passed, 详情)。"""
    import copilot.agent as A
    import copilot.judge as J
    plan = A.parse_rules(text)
    tid = plan.get("topology")
    spec = dict(plan.get("spec") or {})
    if not tid or not spec:
        return None, spec, {}, None, "解析不出拓扑或指标"
    topo = T.get(tid)
    # 分压/放大这类拓扑的 design() 需要激励电压，规则层放在 __Vin 里
    if "__Vin" in spec:
        spec = dict(spec)
        spec["Vin"] = spec["__Vin"]
    try:
        d = topo.design(spec)
        b = topo.build(d)
    except Exception as e:
        return topo, spec, {}, None, f"设计失败：{type(e).__name__}: {e}"
    rows = J.check({k: v for k, v in spec.items() if not k.startswith("__")}, b.metrics)
    passed = all(r.ok for r in rows) if rows else None
    bad = "；".join(f"{r.key} 要求{r.target:g} 实测{r.actual:.6g}"
                    for r in rows if not r.ok)[:160]
    return topo, spec, b.metrics, passed, bad


def _p_divider_rout() -> tuple[bool, str]:
    """分压器「输出阻抗小于100Ω」——曾因 rout 没被解析而判「全部达标」（实测 2336Ω，超 23 倍）。"""
    topo, spec, m, passed, bad = _design_and_judge("5V分压到1.8V，输出阻抗小于100Ω")
    if "rout" not in spec:
        return False, "rout 没进判定表（这正是当年的 bug，属于漏拦）"
    return (passed is False), bad or f"rout={m.get('rout')}"


def _p_divider_power() -> tuple[bool, str]:
    """分压器「功耗小于1mW」——曾判达标（实测 14.2mW，超 14 倍）。"""
    topo, spec, m, passed, bad = _design_and_judge("12V分压到3.3V，功耗小于1mW")
    if "power" not in spec:
        return False, "power 没进判定表（漏拦）"
    return (passed is False), bad or f"power={m.get('power')}"


def _p_divider_iout() -> tuple[bool, str]:
    """分压器「输出电流至少10mA」——曾判达标（实测 0.5mA，低 20 倍）。"""
    topo, spec, m, passed, bad = _design_and_judge("5V分压到2.5V，输出电流至少10mA")
    if "iout" not in spec:
        return False, "iout 没进判定表（漏拦）"
    return (passed is False), bad or f"iout={m.get('iout')}"


def _p_q_chinese() -> tuple[bool, str]:
    """「品质因数5」不带等号——曾因正则只认 `Q=` 而按 0.707 造（峰化差 14dB）仍判达标。

    这里判的是**解析**：q 必须被认成 5。认不出来就是静默丢弃（漏拦）。
    """
    import copilot.agent as A
    spec = A.parse_rules("二阶低通滤波器，截止频率 1kHz，品质因数5").get("spec") or {}
    q = spec.get("q")
    ok = q is not None and abs(float(q) - 5.0) < 0.01
    return ok, f"解析出的 q={q}（应为 5）"


def _p_bw_on_rlc() -> tuple[bool, str]:
    """「RLC带通 带宽500Hz」——bw 解析曾只写在 filter_bandpass_synth 分支里，
    而带通默认路由到 rlc_bandpass → bw 被整个丢掉 → 实测 172Hz（窄 2.9 倍）仍判达标。
    """
    import copilot.agent as A
    plan = A.parse_rules("RLC带通滤波器，中心频率 1kHz，带宽 500Hz")
    spec = plan.get("spec") or {}
    bw = spec.get("bw")
    ok = bw is not None and abs(float(bw) - 500.0) < 1.0
    return ok, f"解析出的 bw={bw}（应为 500）；拓扑={plan.get('topology')}"


def _p_min_not_reversed() -> tuple[bool, str]:
    """「带宽**不**小于 20kHz」是下限，不是上限——子串匹配曾把方向判反，
    于是「要求 ≥20kHz、交 1kHz」竟然判成功。
    """
    from ccl.ai import spec_check as SC
    ts = SC.parse_targets("带宽不小于 20kHz")
    if not ts:
        return False, "解析不出带宽目标"
    bound = ts[0].bound
    ok = (bound == "min")
    return ok, f"方向判成 {bound}（应为 min）"


def _p_cap_tol_not_stolen() -> tuple[bool, str]:
    """「电阻 1% 电容 5%」——1% 曾被同时匹配给电容（正则跨词），
    C 真实 80% 的成品率被报成 100%。
    """
    from copilot.tolerance import tol_from_text
    got = tol_from_text("1kHz 低通，电阻 1% 电容 5%")
    r, c = got.get("R"), got.get("C")
    ok = (r is not None and abs(r - 0.01) < 1e-9) and (c is not None and abs(c - 0.05) < 1e-9)
    return ok, f"R={r} C={c}（应为 0.01 / 0.05）"


def _p_vin_tol_counted() -> tuple[bool, str]:
    """电源容差不得被当成 0（否则分压器成品率虚高 20~45 个点）。"""
    from copilot.tolerance import DEFAULT_TOL
    v = DEFAULT_TOL.get("Vin", 0.0)
    return (v is not None and v > 0), f"Vin 容差={v}（必须 >0，否则成品率虚高）"


def _p_rlc_low_freq_not_refused() -> tuple[bool, str]:
    """1kHz/Q=5 的 RLC 带通是**能做的**——design() 死写 10nF 曾让电感被钳到 1H、
    f0 报成 1591Hz（+59%），并误判「纯 E 系列无解」。误杀带宽 5Hz~1591Hz。
    """
    topo = T.get("rlc_bandpass")
    d = topo.design({"f0": 1000.0, "q": 5.0})
    b = topo.build(d)
    f0 = b.metrics.get("f0") or 0
    err = abs(f0 / 1000.0 - 1) * 100
    # accept 类：caught=True = 「被误拦」。所以**偏差大**（说明被设计坏了/被拒）才算 caught
    return (err >= 10.0), f"f0={f0:.1f}Hz（偏差 {err:.1f}%，应 <10%）"


def _p_rc_extreme_fc_not_broken() -> tuple[bool, str]:
    """fc=0.1Hz 的 RC 低通是能做的——死写 100nF 曾把 f0 报成 1.59Hz（+1491%）。"""
    topo = T.get("rc_lowpass")
    b = topo.build(topo.design({"fc": 0.1}))
    f = b.metrics.get("fc") or 0
    err = abs(f / 0.1 - 1) * 100
    return (err >= 10.0), f"fc={f:.4g}Hz（偏差 {err:.1f}%）"


def _p_twin_t_keeps_user_f0() -> tuple[bool, str]:
    """Twin-T 的 design() 曾把用户给的 f0 硬夹到 [0.1, 1e6]——
    要 2MHz 陷波，"实测"报 1.00027MHz 却当成达标。用户的指标不能被悄悄改。
    """
    topo = T.get("twin_t_notch")
    b = topo.build(topo.design({"f0": 2e6}))
    f = b.metrics.get("f0") or 0
    err = abs(f / 2e6 - 1) * 100
    return (err >= 10.0), f"f0={f:.4g}Hz（偏差 {err:.1f}%，应 <10%）"


CASES: list[Case] = [
    # 一、物理不可行
    Case("rc_stopband_60db_10x", "物理不可行", "reject",
         "用户要一阶 RC 在 10×fc 处衰减 60dB（一阶只有 20dB）", _a1),
    Case("rc_highpass_stopband_40db_5x", "物理不可行", "reject",
         "一阶高通要 5×fc 处衰减 40dB（实为 14.2dB）", _a2),
    Case("passive_q20", "物理不可行", "reject",
         "要无源 RC 网络 Q=20（无源 Q 恒为 0.5）", _a3),
    Case("passive_q_butterworth", "物理不可行", "reject",
         "「无源 RC 做二阶巴特沃斯 Q=0.707」本身自相矛盾", _a4),
    Case("sk_q25", "物理不可行", "reject",
         "Sallen-Key Q=25，元件容差被放大约 25 倍", _a5),
    Case("atten_db_default_ratio", "物理不可行", "reject",
         "只说「衰减 60dB」不说频率，按 10×fc 兜底也必须拦", _a6),
    Case("rc_stopband_20db_10x", "物理不可行", "accept",
         "一阶 RC 在 10×fc 处要 20dB —— 正好够（20.04dB）", _a7),
    Case("passive_q05", "物理不可行", "accept",
         "Q=0.5 正是无源 RC 的本征值", _a8),
    Case("sk_q_butterworth", "物理不可行", "accept",
         "Sallen-Key Q=0.707 是标准巴特沃斯", _a9),
    Case("atten_db_20_default", "物理不可行", "accept",
         "只说「衰减 20dB」，一阶 10×fc 够用", _a10),

    # 二、增益带宽积矛盾
    Case("gbw_100db_1mhz", "增益带宽积矛盾", "reject",
         "单级 100dB 增益 + 1MHz 带宽 = 需要 100GHz GBW", _b1),
    Case("gbw_10x_1mhz_with_1mhz_opamp", "增益带宽积矛盾", "reject",
         "10 倍增益 + 1MHz 带宽却配 GBW=1MHz 的运放（实际只到 100kHz）", _b2),
    Case("gbw_diffamp_100x_1mhz", "增益带宽积矛盾", "reject",
         "差分放大 100 倍 + 1MHz 带宽配 1MHz 运放", _b3),
    Case("gbw_gain_db_entry", "增益带宽积矛盾", "reject",
         "spec 写 gain_db=40（100 倍），evaluate 必须换算后再算 GBW", _b4),
    Case("gbw_10x_100khz_ok", "增益带宽积矛盾", "accept",
         "10 倍 + 100kHz，GBW=1MHz 正好够", _b5),
    Case("gbw_20db_100khz_nohint", "增益带宽积矛盾", "accept",
         "20dB（10 倍）+ 100kHz，未指定器件，需求侧合理", _b6),
    Case("gbw_inv_2x_100khz", "增益带宽积矛盾", "accept",
         "反相 2 倍 + 100kHz，只要 200kHz GBW", _b7),

    # 三、需求自相矛盾
    Case("verify_divider_target_wrong", "需求自相矛盾", "reject",
         "「12V分压到3.3V」被解析成 vout=6.0（真实事故）", _c1),
    Case("verify_gain_10_vs_100", "需求自相矛盾", "reject",
         "用户说增益 10 倍，系统按 100 倍设计", _c2),
    Case("verify_fc_1k_vs_10k", "需求自相矛盾", "reject",
         "用户说截止 1kHz，系统按 10kHz 设计", _c3),
    Case("verify_atten_as_gain", "需求自相矛盾", "reject",
         "「衰减 60dB」被当成「增益 60dB」，滤波器做成放大器", _c4),
    Case("verify_divider_vin_wrong", "需求自相矛盾", "reject",
         "「24V分压到3.3V」却按 Vin=12V 算分压比（输出对、比例错）", _c5),
    Case("verify_bw_1k_vs_10k", "需求自相矛盾", "reject",
         "需求写「带宽 1kHz」，spec 里 bw=10kHz", _c6),
    Case("verify_divider_ok", "需求自相矛盾", "accept",
         "5V→2.5V，文本与 spec 完全一致", _c7),
    Case("verify_fc_ok", "需求自相矛盾", "accept",
         "截止 1kHz，spec 就是 1kHz", _c8),
    Case("verify_gain_ok", "需求自相矛盾", "accept",
         "增益 10 倍，spec 就是 10 倍", _c9),

    # 四、AI 编造数值
    Case("claim_gain20_actual95", "AI 编造数值", "reject",
         "AI 宣称增益 20 倍，实测 9.50 倍（差 52%）", _d1),
    Case("claim_fc2k_actual1k", "AI 编造数值", "reject",
         "AI 宣称截止 2kHz，实测 1.000kHz（差 2 倍）", _d2),
    Case("claim_gain10_actual95", "AI 编造数值", "reject",
         "AI 宣称增益 10 倍，实测 9.50 倍（差 5.3%，落在 10% 容差内）", _d3),
    Case("claim_bw20k_actual1k", "AI 编造数值", "reject",
         "AI 宣称带宽 20kHz，实测 ~1kHz（差 20 倍）", _d4),
    Case("claim_fc10k_actual1k", "AI 编造数值", "reject",
         "AI 宣称截止 10kHz，实测 1.000kHz", _d5),
    Case("claim_gain95_actual95", "AI 编造数值", "accept",
         "AI 说 9.5 倍，实测 9.4991 —— 一致", _d6),
    Case("claim_fc1k_actual1k", "AI 编造数值", "accept",
         "AI 说 1kHz，实测 1.0000kHz", _d7),
    Case("claim_bw_min_bound", "AI 编造数值", "accept",
         "「带宽 1kHz 以上」是下限语义，实测 1.0009kHz 合格", _d8),

    # 五、器件/拓扑不存在
    Case("topo_notch_missing", "器件/拓扑不存在", "reject",
         "「工频陷波」→ AI 报 notch_filter，REGISTRY 里没有", _e1),
    Case("topo_lc_lowpass_missing", "器件/拓扑不存在", "reject",
         "AI 报 lc_lowpass，REGISTRY 里只有 rlc_bandpass", _e2),
    Case("topo_current_mirror_missing", "器件/拓扑不存在", "reject",
         "AI 用「电流镜」偏置，工具不支持这个 block", _e3),
    Case("topo_bandpass_misrouted", "器件/拓扑不存在", "reject",
         "需求是带通，AI 给了 rc_lowpass（低通挡不住低频侧）", _e4),
    Case("topo_divider_misrouted", "器件/拓扑不存在", "reject",
         "「分压到 3.3V」被做成 rc_lowpass（模型随机性的真实事故）", _e5),
    Case("topo_sallenkey_ok", "器件/拓扑不存在", "accept",
         "存在的拓扑 + 低通语义一致", _e6),
    Case("topo_bandpass_ok", "器件/拓扑不存在", "accept",
         "带通需求 + rlc_bandpass", _e7),

    # 六、该判 None 却给数
    Case("ac_only_rise_time", "该判 None 却给数", "reject",
         "只跑了 AC 就要 rise_time —— 必须 NaN", _f1),
    Case("ac_only_overshoot", "该判 None 却给数", "reject",
         "只跑了 AC 就要 overshoot_pct —— 必须 NaN", _f2),
    Case("sine_overshoot", "该判 None 却给数", "reject",
         "纯正弦激励要超调 —— 概念不成立，必须 None", _f3),
    Case("sine_settling", "该判 None 却给数", "reject",
         "纯正弦激励要建立时间 —— 必须 None", _f4),
    Case("f3db_no_flat_segment", "该判 None 却给数", "reject",
         "100Hz 低通从 1kHz 起扫，全程下坡 —— f3db 必须 None", _f5),
    Case("step_rise_time", "该判 None 却给数", "accept",
         "真跑了阶跃，rise_time=2.197ms 必须给得出", _f6),
    Case("f3db_good_sweep", "该判 None 却给数", "accept",
         "1Hz 起扫覆盖了平台，f3db 必须给 ~100Hz", _f7),
    Case("step_steady_state", "该判 None 却给数", "accept",
         "真阶跃的稳态值 ~1.0V 必须测得出", _f8),

    # 六·五、电压类目标
    Case("vout_straight_through", "AI 编造数值", "reject",
         "要 12V→3.3V，AI 交了 Vout=12V 的直通电路（等于一根导线）", _k1),
    Case("vout_divider_correct", "AI 编造数值", "accept",
         "正确的 12V→3.3V 分压不该被判失败", _k2),
    Case("vout_ratio_half_off", "AI 编造数值", "reject",
         "分压比错一半（输出 5.17V 而非 3.3V）必须被抓", _k3),
    Case("vout_odd_source_name", "AI 编造数值", "accept",
         "源节点名不规范（src_x）不得导致正确电路被误判", _k4),

    # 七、能力边界
    Case("scope_buck_supply", "能力边界", "reject",
         "要 Buck 开关电源（旧行为：给电阻分压并称达标可直接打样）", _j1),
    Case("scope_transformer", "能力边界", "reject",
         "要变压器隔离（没有耦合电感/磁芯模型）", _j2),
    Case("scope_oscillator", "能力边界", "reject",
         "要 RC 振荡器（需正反馈与巴克豪森判据）", _j3),
    Case("scope_current_source", "能力边界", "reject",
         "要恒流源（关键指标是负载调整率，不是交流响应）", _j4),
    Case("scope_rectifier", "能力边界", "reject",
         "要整流桥（非线性导通角，线性分析给不出）", _j5),
    Case("scope_instrumentation_amp", "能力边界", "reject",
         "要仪用放大器（三运放，不能用单运放差分替代）", _j6),
    Case("scope_divider_downgrade_ok", "能力边界", "accept",
         "「24V 降压到 3.3V」是分压器说法，不是 Buck，不许误杀", _j7),
    Case("scope_stopband_spec_ok", "能力边界", "accept",
         "「阻带衰减 60dB」是低通规格，不是要带阻", _j8),
    Case("scope_current_source_excitation_ok", "能力边界", "accept",
         "「用电流源激励」是分析激励，不是恒流源电路", _j9),
    Case("scope_bandpass_not_bandstop", "能力边界", "accept",
         "正常带通需求不能因为词里带「阻/通」就被拦", _j10),
    Case("scope_notch_now_supported", "能力边界", "accept",
         "50Hz 工频陷波已由 Twin-T 支持，不该再被能力边界拦", _j11),

    # 八、结构上限
    Case("bp_cascade_q125_4stage", "结构上限", "reject",
         "四阶带通 Q=1.25，超每侧 2 级的上限 0.78", _i1),
    Case("bp_cascade_q25_2stage", "结构上限", "reject",
         "二阶带通 Q=2.5，超每侧 1 级的上限 0.50", _i2),
    Case("bp_cascade_q15_6stage", "结构上限", "reject",
         "六阶带通 Q=1.5，超上限 0.98（加阶数救不了）", _i3),
    Case("bp_design_also_refuses", "结构上限", "reject",
         "闸门之外，design() 也必须自己拒（第二道防线）", _i4),
    Case("bp_cascade_q033_ok", "结构上限", "accept",
         "二阶带通 Q=0.33 —— 级联结构做得到", _i5),
    Case("bp_cascade_q050_boundary", "结构上限", "accept",
         "Q=0.50 正好是 2 阶上限，边界合法", _i6),
    Case("bp_cascade_q055_4stage_ok", "结构上限", "accept",
         "四阶带通 Q=0.55，上限 0.78 以内", _i7),
    Case("rlc_bp_q20_not_limited", "结构上限", "accept",
         "RLC 谐振带通 Q=20 本来就能做，别把级联上限错用到它身上", _i8),

    # 八、参数越界
    Case("fc_001hz", "参数越界", "reject",
         "fc=0.01Hz 需要 1F/100MΩ 级元件", _g1),
    Case("fc_1ghz", "参数越界", "reject",
         "fc=1GHz 寄生主导，集总参数模型失效", _g2),
    Case("fc_05_evaluate", "参数越界", "reject",
         "fc=0.5Hz 走 evaluate 入口也必须拦", _g3),
    Case("fc_2ghz_sallenkey", "参数越界", "reject",
         "有源滤波做 2GHz 不工作", _g4),
    Case("fc_005hz_synth", "参数越界", "reject",
         "多级综合滤波 0.05Hz 落不到真实元件", _g5),
    Case("fc_1khz_ok", "参数越界", "accept",
         "fc=1kHz，1kΩ/159nF 标准件", _g6),
    Case("fc_1hz_boundary", "参数越界", "accept",
         "fc=1Hz 正好在判据边界（fc<1.0 才拦）", _g7),
    Case("fc_100khz_ok", "参数越界", "accept",
         "fc=100kHz 集总参数毫无问题", _g8),

    # 八、分压比不可达
    Case("divider_5v_to_10v", "分压比不可达", "reject",
         "5V→10V 用无源分压（要升压）", _h1),
    Case("divider_5v_to_10v_evaluate", "分压比不可达", "reject",
         "同上，走 evaluate 统一入口", _h2),
    Case("divider_5v_to_12v", "分压比不可达", "reject",
         "5V→12V 用一个 5V 电源驱动 12V 继电器", _h3),
    Case("divider_5v_to_5_1v", "分压比不可达", "reject",
         "5V→5.1V 微小升压（最容易被放过）", _h4),
    Case("divider_5v_to_2_5v", "分压比不可达", "accept",
         "5V→2.5V 标准二分压", _h5),
    Case("divider_12v_to_3_3v", "分压比不可达", "accept",
         "12V→3.3V 给 ADC（真实高频需求）", _h6),
    Case("divider_5v_to_5v", "分压比不可达", "accept",
         "5V→5V 比值 1，理论上界", _h7),
    # 六、需求解析 × 越界边界（补「基准自证循环」：原来全是规整句式）
    Case("divider_rout_spec_must_fail", "需求解析", "reject",
         "「5V分压到1.8V，输出阻抗小于100Ω」必须判未达标（实测 2336Ω，超 23 倍）",
         _p_divider_rout),
    Case("divider_power_spec_must_fail", "需求解析", "reject",
         "「功耗小于1mW」必须判未达标（实测 14.2mW，超 14 倍）", _p_divider_power),
    Case("divider_iout_spec_must_fail", "需求解析", "reject",
         "「输出电流至少10mA」必须判未达标（实测 0.5mA，低 20 倍）", _p_divider_iout),
    Case("q_chinese_no_equals_sign", "需求解析", "reject",
         "「品质因数5」不带等号：曾只认 `Q=` 而按 0.707 造（峰化差 14dB）", _p_q_chinese),
    Case("bw_parsed_for_rlc_bandpass", "需求解析", "reject",
         "「RLC带通 带宽500Hz」的 bw 曾被整个丢掉（实测 172Hz 仍判达标）", _p_bw_on_rlc),
    Case("bandwidth_min_not_reversed", "需求解析", "reject",
         "「带宽不小于 20kHz」是下限：子串匹配曾判成上限，交 1kHz 也判成功",
         _p_min_not_reversed),
    Case("cap_tolerance_not_stolen", "需求解析", "reject",
         "「电阻 1% 电容 5%」的 1% 曾被同时挂给电容（成品率虚高 20 点）",
         _p_cap_tol_not_stolen),
    Case("vin_tolerance_not_ideal", "需求解析", "reject",
         "电源容差不得当 0（否则分压器成品率虚高 20~45 点）", _p_vin_tol_counted),
    Case("rlc_bandpass_1k_q5_not_refused", "需求解析", "accept",
         "1kHz/Q=5 的 RLC 带通能做：死写 10nF 曾让 f0 报 1591Hz 并误判「无解」",
         _p_rlc_low_freq_not_refused),
    Case("rc_lowpass_0p1hz_not_broken", "需求解析", "accept",
         "fc=0.1Hz 的 RC 低通能做：死写 100nF 曾报成 1.59Hz（+1491%）",
         _p_rc_extreme_fc_not_broken),
    Case("twin_t_2mhz_keeps_target", "需求解析", "accept",
         "2MHz 陷波能做：design() 曾把用户的 f0 硬夹到 1e6", _p_twin_t_keeps_user_f0),

]
