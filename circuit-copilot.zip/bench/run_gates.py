"""确定性闸门基准 —— 运行器。

跑 `bench/gates_cases.py` 里全部用例，把「拦截率 / 误杀率」如实打出来，
并写 `bench/results_gates.json`（格式见 `bench/CONTRACT.md`）。

    python3 bench/run_gates.py           # 跑全部，表格 + JSON
    python3 bench/run_gates.py -v        # 额外打印每条用例的理由

退出码：
    0  全部达标（该拦的全拦住了 + 一个都没误杀）
    1  有漏网或有误杀（含"用例本身跑挂了"）
    2  用例集/环境有问题（导入失败、用例 id 重复、类别缺项）

## 为什么单独做这一层

闸门的输入可以**手工构造**：把一个"AI 会给出的错误输出"直接喂给闸门函数，
看它抓不抓得住。不调模型 → 毫秒级、完全可复现、谁都能复跑。
代价是只覆盖确定性部分（语义/话术层面的幻觉归 `run_llm.py`）。

## 诚实要求

漏网照实报。`results_gates.json` 里 `caught=false` 的 reject 用例就是漏网，
运行器会把它们单列一节打印出来 —— 那才是这个基准存在的意义。
"""

from __future__ import annotations

import json
import os
import sys
import time
import traceback

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from bench import gates_cases as G  # noqa: E402

OUT_JSON = os.path.join(_HERE, "results_gates.json")


# --------------------------------------------------------------------------
# 跑用例
# --------------------------------------------------------------------------
def run_all(cases: list[G.Case]) -> list[dict]:
    rows: list[dict] = []
    for c in cases:
        t0 = time.perf_counter()
        try:
            caught, detail = c.fn()
        except Exception as e:                     # 用例自己挂了也是"没拦住"
            caught = False
            detail = f"用例执行异常 {type(e).__name__}: {e}"
            traceback.print_exc(limit=3)
        ms = (time.perf_counter() - t0) * 1000.0
        rows.append({
            "id": c.id,
            "category": c.category,
            "expect": c.expect,
            "caught": bool(caught),
            "detail": (detail or "").strip(),
            "_scenario": c.scenario,
            "_ms": ms,
        })
    return rows


# --------------------------------------------------------------------------
# 汇总
# --------------------------------------------------------------------------
def summarize(rows: list[dict], categories: list[str]) -> list[dict]:
    out = []
    for cat in categories:
        rs = [r for r in rows if r["category"] == cat]
        rej = [r for r in rs if r["expect"] == "reject"]
        acc = [r for r in rs if r["expect"] == "accept"]
        hit = sum(1 for r in rej if r["caught"])
        fp = sum(1 for r in acc if r["caught"])
        out.append({
            "category": cat,
            "n_reject": len(rej),
            "hit": hit,
            "recall": (hit / len(rej)) if rej else float("nan"),
            "n_accept": len(acc),
            "false_pos": fp,
            "fpr": (fp / len(acc)) if acc else float("nan"),
        })
    return out


def _pct(x: float) -> str:
    return "—" if x != x else f"{x * 100:5.1f}%"


def print_table(sums: list[dict], rows: list[dict]) -> None:
    total_rej = sum(s["n_reject"] for s in sums)
    total_hit = sum(s["hit"] for s in sums)
    total_acc = sum(s["n_accept"] for s in sums)
    total_fp = sum(s["false_pos"] for s in sums)

    def row(a, b, c, d, e):
        print(f"{a:<18s} {b:>11s} {c:>8s} {d:>13s} {e:>8s}")

    print()
    print("=" * 74)
    print("确定性闸门基准 —— AI 出错时我们抓不抓得住")
    print(f"用例 {len(rows)} 条（该拦 {total_rej} / 不该拦 {total_acc}），"
          f"耗时 {sum(r['_ms'] for r in rows) / 1000.0:.1f}s")
    print("=" * 74)
    row("类别", "拦截/该拦", "拦截率", "误杀/不该拦", "误杀率")
    print("-" * 74)
    for s in sums:
        row(
            s["category"],
            f"{s['hit']}/{s['n_reject']}",
            _pct(s["recall"]),
            f"{s['false_pos']}/{s['n_accept']}",
            _pct(s["fpr"]),
        )
    print("-" * 74)
    recall = total_hit / total_rej if total_rej else float("nan")
    fpr = total_fp / total_acc if total_acc else float("nan")
    row("合计", f"{total_hit}/{total_rej}", _pct(recall),
        f"{total_fp}/{total_acc}", _pct(fpr))
    print("=" * 74)


def print_detail(rows: list[dict], verbose: bool) -> None:
    missed = [r for r in rows if r["expect"] == "reject" and not r["caught"]]
    killed = [r for r in rows if r["expect"] == "accept" and r["caught"]]

    print()
    print(f"【漏网】该拦却没拦住：{len(missed)} 条")
    if not missed:
        print("  无")
    for r in missed:
        print(f"  ✗ {r['id']}（{r['category']}）")
        print(f"    防的场景：{r['_scenario']}")
        print(f"    闸门实际输出：{r['detail'] or '（无理由）'}")

    print()
    print(f"【误杀】不该拦却拦了：{len(killed)} 条")
    if not killed:
        print("  无")
    for r in killed:
        print(f"  ✗ {r['id']}（{r['category']}）")
        print(f"    场景：{r['_scenario']}")
        print(f"    闸门理由：{r['detail'] or '（无理由）'}")

    if verbose:
        print()
        print("【逐条】")
        for r in rows:
            mark = "✓" if (r["caught"] == (r["expect"] == "reject")) else "✗"
            print(f"  {mark} [{r['category']}] {r['id']:<32s} "
                  f"{r['expect']:<6s} caught={str(r['caught']):<5s} "
                  f"{r['_ms']:6.1f}ms  {r['detail'][:110]}")


def write_json(rows: list[dict]) -> None:
    payload = {
        "layer": "gates",
        "cases": [
            {k: r[k] for k in ("id", "category", "expect", "caught", "detail")}
            for r in rows
        ],
    }
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f"\n已写入 {OUT_JSON}（{len(payload['cases'])} 条）")


def main(argv: list[str]) -> int:
    verbose = "-v" in argv or "--verbose" in argv

    # 用例集自检：id 唯一、类别齐全、每类都有该拦与不该拦的对照
    ids = [c.id for c in G.CASES]
    if len(ids) != len(set(ids)):
        print("用例 id 重复", file=sys.stderr)
        return 2
    problems = []
    for cat in G.CATEGORIES:
        rej = [c for c in G.CASES if c.category == cat and c.expect == "reject"]
        acc = [c for c in G.CASES if c.category == cat and c.expect == "accept"]
        if len(rej) < 4 or len(acc) < 2:
            problems.append(f"{cat}: 该拦 {len(rej)} / 不该拦 {len(acc)}（要求 ≥4 / ≥2）")
    for c in G.CASES:
        if c.expect not in ("reject", "accept"):
            problems.append(f"{c.id}: expect={c.expect!r} 非法")
    if problems:
        print("用例集不合格：", file=sys.stderr)
        for p in problems:
            print("  - " + p, file=sys.stderr)
        return 2

    rows = run_all(G.CASES)
    sums = summarize(rows, G.CATEGORIES)
    print_table(sums, rows)
    print_detail(rows, verbose)
    write_json(rows)

    total_rej = sum(s["n_reject"] for s in sums)
    total_hit = sum(s["hit"] for s in sums)
    total_fp = sum(s["false_pos"] for s in sums)
    ok = (total_hit == total_rej) and (total_fp == 0)
    print(f"\n结论：拦截 {total_hit}/{total_rej}，误杀 {total_fp} → "
          f"{'达标（exit 0）' if ok else '未达标（exit 1）'}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
