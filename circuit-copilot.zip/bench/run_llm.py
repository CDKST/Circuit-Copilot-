"""真实大模型端到端基准：运行器。

    python3 bench/run_llm.py                 # 全量（14 条），写 bench/results_llm.json
    python3 bench/run_llm.py --only a1_rc_lowpass_1k   # 先单跑 1 条确认链路
    python3 bench/run_llm.py --stub good     # 干跑自测（不发网络请求，不写正式结果）

## 这一层量什么

和 `run_gates.py`（确定性闸门）不同，这里**真调模型**，跑完整条
`ccl.ai.generate.generate()` 链：模型写代码 → 沙箱 exec → 真跑 ngspice →
`spec_check` 对账 → 错误回喂修 → 再跑。所以每条都花钱、都慢（20~40 秒正常）。

指标（全部取自 `Generation` 的真实字段，不从日志猜）：

| 指标 | 取值来源 |
|---|---|
| 修复轮次 | `len(gen.attempts) - 1`；首轮成功 = 0 轮。`Attempt.stage` 给出卡在哪一步 |
| 一次通过率 | `gen.ok and 修复轮次 == 0` |
| 幻觉拦截数 | `stage == "ok"`（仿真跑通了）但 `error` 非空 —— 即"电路能跑但指标不达标"，正是 `spec_check` 抓的那类 |
| 修不好的如实报告率 | 达不到时 `gen.error` 是否非空 + 代码/正文里有没有 `限制：` 声明 |
| 超时/异常 | 外层 180s 墙钟 + 模型不可达时的降级表现 |

## 为什么需要一个 RecordingLLM 包一层

`generate()` 只保留**抽出来的代码**（`Attempt.source`），模型正文丢了。
而"模型有没有老实说做不到"恰恰写在正文/注释里（prompt 明确要求
`# 限制：...` 写在代码顶部）。所以这里注入一个薄代理：不改 `generate()` 一行，
只把 `available()` / `chat()` 透传并记录原始回复。这是**仪表**，不是第二套判定逻辑。

同时它负责两件运行时的事：

1. **单条 180 秒硬上限**：`generate()` 的 `timeout_s` 只管沙箱 exec，
   `llm.chat` 里的 `timeout=90` 是写死的，`max_repair=2` 最坏能挂 270 秒。
   所以外层用 deadline：超时就抛 `LLMError` 一类异常，让 `generate()` 走它自己的
   「调用模型失败」分支（也就是真实产品会走的那条路），而不是把整批卡死。
2. **记录调用次数与原始文本**，事后能分清"模型不行"和"prompt 不行"。

## 判定口径

`caught` 的语义严格照 CONTRACT：

- A 类（expect=accept）：`caught=True` **只表示真·误杀**（实测按用例判据达标，
  流水线却拒了）。「模型没做出达标设计」是质量失败（a_fail_n），**不算误杀**——
  混在一起会污染误杀率。假成功（报 ok 但不达标）也不是误杀：那是**放行垃圾**，
  记在 fake_success，比误杀更严重。
- B 类（expect=reject）：`caught=True` 表示**真拦住了**（报错 / 明说做不到 / 被闸门判不合格）
- C 类（expect=accept）：`caught=True` 表示**编造且不自知**或崩/超时

B 类另有一个更要紧的字段 `fabricated`（硬凑）：
`ok=True` + 实测不达标 + 一个字没提"做不到"。这是**比漏网更严重**的失败——
用户会拿着它去打样。它单独计数，并在报告里点名。
"""

from __future__ import annotations

import argparse
import json
import math
import os
import queue
import sys
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

BENCH = ROOT / "bench"
if str(BENCH) not in sys.path:
    sys.path.insert(0, str(BENCH))

from llm_cases import CASES, by_id, stats as case_stats  # noqa: E402

OUT_JSON = BENCH / "results_llm.json"
OUT_JSON_STUB = BENCH / "results_llm.stub.json"

#: 单条用例的墙钟上限（秒）。模型调用 + 最多 3 轮修复 + 每轮一次 ngspice。
#: 可用 `--case-timeout` 覆盖（自测超时路径时很有用，默认仍按契约的 180s）。
CASE_TIMEOUT_S = 180.0
#: 单次模型调用的上限。留出余量给 3 轮：40s×3=120s < 180s。
CALL_TIMEOUT_S = 45.0

# 运行时生效值。`main()` 用命令行覆盖，其余地方只读这里，避免全局散落。
_CFG = {"case_timeout": CASE_TIMEOUT_S, "call_timeout": CALL_TIMEOUT_S}
#: 修复轮数上限，与产品默认一致（generate 的 max_repair 默认 2 → 最多 3 轮）
MAX_REPAIR = 2

# 「老实说做不到」的信号词。**只用于事后归类**，不参与产品判定——
# 产品自己的判定走的是 spec_check / feasibility，不是我这里的关键词。
_LIMIT_WORDS = (
    "限制", "做不到", "不可能", "无法实现", "无法达到", "达不到", "无法做到",
    "物理上", "超出", "impossible", "cannot", "can not", "unreachable",
)
# 「我替你定了」的信号词：C 类判"合理默认"的依据（留痕 = 合格）
_ASSUME_WORDS = (
    "假设", "假定", "未指定", "没有指定", "没指定", "未给出", "没给出",
    "默认", "按通用", "取常规", "assumption", "assume", "未说明",
)


# ==========================================================================
# 仪表：记录原始回复 + 单条 deadline
# ==========================================================================
class CaseDeadline(Exception):
    """单条用例超出墙钟预算。故意继承 Exception（不是 BaseException），
    这样 `generate()` 的 `except Exception` 会把它记成「调用模型失败」——
    和真的网络挂掉走同一条降级路径，量到的就是真实产品行为。"""


class RecordingLLM:
    """透传 copilot.llm.LLM，附带记录 + deadline。接口只用得到三样：
    `.available()` `.chat()` `.model`（generate 只用这三样）。"""

    def __init__(self, inner, *, deadline_s: float | None = None,
                 call_timeout_s: float | None = None):
        self.inner = inner
        self.model = getattr(inner, "model", "")
        deadline_s = _CFG["case_timeout"] if deadline_s is None else deadline_s
        self.call_timeout_s = (_CFG["call_timeout"]
                               if call_timeout_s is None else call_timeout_s)
        self.deadline = time.monotonic() + deadline_s
        self.calls: list[dict] = []
        self.replies: list[str] = []

    def available(self) -> bool:
        try:
            return bool(self.inner.available())
        except Exception:
            return False

    #: 这些不是「模型答错了」，是**基础设施在抽风**：429 限流、连接被重置、
    #: 免费端点直接挂住。它们不该被记成模型的失败轮次，否则指标会变成
    #: "网关有多不稳"而不是"模型有多准"。所以在仪表层重试，不进 `Attempt`。
    _TRANSIENT = ("429", "网络错误", "timed out", "Timeout", "Connection", "502", "503", "504")
    RETRY_TRIES = 4
    RETRY_BACKOFF_S = 20.0

    def _transient(self, err: str) -> bool:
        e = str(err or "")
        return any(k in e for k in self._TRANSIENT)

    def chat(self, messages, **kw):
        user = ""
        for m in reversed(messages or []):
            if m.get("role") == "user":
                user = str(m.get("content", ""))
                break
        last = ""
        for attempt in range(1, self.RETRY_TRIES + 1):
            remaining = self.deadline - time.monotonic()
            if remaining <= 1.0:
                raise CaseDeadline(
                    f"单条用例超时（>{_CFG['case_timeout']:.0f}s），最后一次模型调用被中止"
                )
            kw["timeout"] = min(self.call_timeout_s, remaining)
            t0 = time.perf_counter()
            try:
                out = self.inner.chat(messages, **kw)
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                self.calls.append({
                    "ms": round((time.perf_counter() - t0) * 1000, 1),
                    "prompt_chars": len(user), "reply_chars": 0,
                    "error": last, "try": attempt,
                })
                if attempt < self.RETRY_TRIES and self._transient(last):
                    # 退避不能越过本条 deadline，否则会伪造出"超时"
                    wait = min(self.RETRY_BACKOFF_S * attempt,
                               max(0.0, self.deadline - time.monotonic() - 5.0))
                    if wait > 0:
                        time.sleep(wait)
                    continue
                raise
            self.calls.append({
                "ms": round((time.perf_counter() - t0) * 1000, 1),
                "prompt_chars": len(user), "reply_chars": len(out or ""),
                "error": "", "try": attempt,
            })
            self.replies.append(out or "")
            return out
        raise RuntimeError(last or "模型调用失败")


# ==========================================================================
# 干跑自测用的 stub（不联网）。--stub good / cheat / timeout / dead
# ==========================================================================
_STUB_CIRCUITS = {
    "lowpass": """from ccl import Circuit, GND
import math

def build():
    c = Circuit("rc_lowpass")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-9)
    c.expect("fc", "out", 1000, tol=0.05)
    return c
""",
    "highpass": """from ccl import Circuit, GND

def build():
    c = Circuit("rc_highpass")
    c.V("in", GND, ac=1)
    c.C("in", "out", 330e-9)
    c.R("out", GND, 1e3)
    c.expect("fc", "out", 500, tol=0.05)
    return c
""",
    "noninv": """from ccl import Circuit, GND

def build():
    c = Circuit("noninv_amp")
    c.V("src", GND, ac=1)
    c.R("sum", GND, 1e3)
    c.R("out", "sum", 9e3)
    c.OpAmp("src", "sum", "out", gbw=1.3e6)
    c.expect("gain", "out", 10, tol=0.02)
    return c
""",
    "inverting": """from ccl import Circuit, GND

def build():
    c = Circuit("inv_amp")
    c.V("src", GND, ac=1)
    c.R("src", "sum", 1e3)
    c.R("sum", "out", 20e3)
    c.OpAmp(GND, "sum", "out", gbw=1.3e6)
    return c
""",
    "sallenkey": """from ccl import Circuit, GND
import math

def build():
    fc, Q = 10e3, 0.707
    c2 = 10e-9
    c1 = c2 * (2 * Q) ** 2
    r = 1 / (2 * math.pi * fc * math.sqrt(c1 * c2))
    c = Circuit("sallen_key_lp")
    c.V("in", GND, ac=1)
    c.R("in", "n1", r)
    c.R("n1", "n2", r)
    c.C("n1", "out", c1)
    c.C("n2", GND, c2)
    c.OpAmp("n2", "out", "out", gbw=1e6)
    c.expect("fc", "out", fc, tol=0.05)
    return c
""",
    # 真正的无源带通：串联 R-L，C 并联到地。别写成「L 串联 + C 并联」——
    # 那是二阶低通（stub 早先就是这么错的，仿真峰值永远贴在扫频起点）。
    "bandpass": """from ccl import Circuit, GND
import math

def build():
    f0, Q = 100e3, 10.0
    L = 1e-3
    C = 1 / ((2 * math.pi * f0) ** 2 * L)
    R = 2 * math.pi * f0 * L / Q
    c = Circuit("rlc_bandpass")
    c.V("in", GND, ac=1)
    c.R("in", "n1", R)
    c.L("n1", "out", L)
    c.C("out", GND, C)
    return c
""",
    "divider": """from ccl import Circuit, GND

def build():
    c = Circuit("divider")
    c.V("in", GND, ac=1)
    c.R("in", "out", 8.7e3)
    c.R("out", GND, 3.3e3)
    return c
""",
}


def _stub_code(prompt: str, *, cheat: bool) -> str:
    """按关键词挑一段可跑的 stub 代码。cheat=True 时 B 类也不写「限制」。"""
    t = prompt
    hard = any(k in t for k in ("衰减", "100dB", "Q=20", "Q=0.707（要巴特沃斯", "不可能"))
    if "Sallen" in t or "sallen" in t:
        key = "sallenkey"
    elif "带通" in t or "中心频率" in t:
        key = "bandpass"
    elif "高通" in t:
        key = "highpass"
    elif "分压" in t:
        key = "divider"
    elif "反相" in t:
        key = "inverting"
    elif "同相" in t or "放大" in t:
        key = "noninv"
    else:
        key = "lowpass"
    code = _STUB_CIRCUITS[key]
    if hard and not cheat:
        code = ("# 限制：这个指标物理上做不到，下面给的是最接近的结构\n" + code)
    elif hard:
        # cheat 模式：装作做到了，一个字不提——用于验证「硬凑」检测器会不会响
        pass
    elif "做个滤波器" in t or "放大一下信号" in t or "一个分压电路" in t:
        code = "# 未指定具体指标，按通用值取（假设：低通 1kHz / 增益 10 / 5V 分 2.5V）\n" + code
    return "```python\n" + code + "```"


class StubLLM:
    """干跑用的假模型。**只用于自测运行器本身**，结果永不写成正式结果。"""

    def __init__(self, mode: str = "good"):
        self.mode = mode
        self.model = f"stub:{mode}"
        self.n = 0

    def available(self) -> bool:
        return True

    def chat(self, messages, **kw):
        self.n += 1
        if self.mode == "timeout":
            time.sleep(kw.get("timeout", 1.0) + 0.5)
            return ""
        if self.mode == "dead":
            raise RuntimeError("stub: 网关不可达")
        user = ""
        for m in reversed(messages or []):
            if m.get("role") == "user":
                user = str(m.get("content", ""))
                break
        prompt = user.split("需求：")[-1].strip() if "需求：" in user else user
        return _stub_code(prompt, cheat=(self.mode == "cheat"))


# ==========================================================================
# 测量：对返回的电路直接量一次（spec_check 抓不到的那些要求）
# ==========================================================================
def _pick_nodes(circuit, solution) -> tuple[str, str | None]:
    """挑（输出节点, 源节点）。源节点只在分压测量里用得到。"""
    out = None
    src = None
    try:
        names = list(solution.node_names())
    except Exception:
        return "out", None
    cand = [n for n in names if not n.startswith("i(") and n != "in"]
    out = "out" if "out" in names else (cand[-1] if cand else None)
    try:
        for comp in getattr(circuit, "components", []) or []:
            if getattr(comp, "kind", "") == "V":
                nodes = comp.nodes()
                if nodes:
                    src = nodes[0]
                    break
    except Exception:
        pass
    return out or "out", src


def _db_at(solution, node: str, f: float) -> float | None:
    try:
        v = solution.value_at(node, float(f))
        if v is None:
            return None
        mag = abs(v)
        if not mag or not math.isfinite(mag):
            return None
        return 20 * math.log10(mag)
    except Exception:
        return None


def _measure(spec: dict, gen) -> dict:
    """按用例里的 `measure` 直接量一次。返回 {met, got, want}。

    `met` 三态：True/False/None（测不到——仿真没跑通或节点找不到）。
    **测不到不算达标**，也不算不达标；报告里单独说清，不糊过去。
    """
    if not spec:
        return {"met": None, "got": "", "want": ""}
    sol = getattr(gen, "solution", None)
    circ = getattr(gen, "circuit", None)
    if sol is None or circ is None:
        return {"met": None, "got": "无仿真结果", "want": spec.get("kind", "")}

    node, src = _pick_nodes(circ, sol)
    kind = spec.get("kind")

    def out(met, got, want, value=None):
        return {"met": met, "got": got, "want": want, "value": value}

    try:
        if kind == "f3db":
            f3 = sol.f3db(node)
            want = f"{spec['target_hz']:.4g}Hz±{spec['tol'] * 100:.0f}%"
            if not f3:
                return out(False, "找不到 -3dB 点", want)
            return out(abs(f3 - spec["target_hz"]) / spec["target_hz"] <= spec["tol"],
                       f"f3db={f3:.5g}Hz", want, float(f3))

        if kind == "f0":
            xs = list(sol.xaxis(node))
            db = list(sol.db(node))
            if not xs or not db:
                return out(None, "无扫频数据", f"{spec['target_hz']:.4g}Hz")
            f0 = xs[db.index(max(db))]
            want = f"{spec['target_hz']:.4g}Hz±{spec['tol'] * 100:.0f}%"
            return out(abs(f0 - spec["target_hz"]) / spec["target_hz"] <= spec["tol"],
                       f"峰值在 {f0:.5g}Hz", want, float(f0))

        if kind == "gain":
            xs = list(sol.xaxis(node))
            g = abs(sol.value_at(node, xs[0])) if xs else float("nan")
            want = f"{spec['target_lin']:.4g}×±{spec['tol'] * 100:.0f}%"
            if not math.isfinite(g):
                return out(None, "测不到", want)
            return out(abs(g - spec["target_lin"]) / spec["target_lin"] <= spec["tol"],
                       f"增益 {g:.4g}×", want, float(g))

        if kind == "gain_bw":
            xs = list(sol.xaxis(node))
            g = abs(sol.value_at(node, xs[0])) if xs else float("nan")
            f3 = sol.f3db(node)
            want = f"增益≥{spec['min_gain_lin']:.4g}× 且 带宽≥{spec['min_bw_hz']:.4g}Hz"
            got = f"增益 {g:.4g}×，带宽 " + (f"{f3:.4g}Hz" if f3 else "测不到")
            if not math.isfinite(g):
                return out(False, got, want)
            ok = g >= spec["min_gain_lin"] * 0.98 and bool(f3) and f3 >= spec["min_bw_hz"] * 0.98
            return out(ok, got, want)

        if kind == "atten":
            ref = _db_at(sol, node, float(list(sol.xaxis(node))[0]))
            at = _db_at(sol, node, spec["f_hz"])
            want = f"{spec['f_hz']:.4g}Hz 处衰减 ≥{spec['min_atten_db']:.4g}dB"
            if ref is None or at is None:
                return out(False, "测不到该频点", want)
            att = ref - at
            return out(att >= spec["min_atten_db"] * 0.98,
                       f"{spec['f_hz']:.4g}Hz 处衰减 {att:.2f}dB", want)

        if kind == "q_min":
            from ccl.ai import spec_check as SC
            q = SC._measure_q(sol, node)
            want = f"Q≥{spec['min_q']:.4g}"
            if q is None or not math.isfinite(q):
                return out(False, "Q 测不到", want)
            return out(q >= spec["min_q"], f"Q={q:.4g}", want)

        if kind == "fc_q":
            f3 = sol.f3db(node)
            from ccl.ai import spec_check as SC
            q = SC._measure_q(sol, node)
            want = (f"{spec['target_hz']:.4g}Hz±{spec['tol'] * 100:.0f}%，"
                    f"Q={spec['target_q']:.4g}±{spec['q_tol'] * 100:.0f}%")
            got = (f"f3db={f3:.5g}Hz" if f3 else "f3db 测不到") + \
                  (f"，Q={q:.4g}" if q and math.isfinite(q) else "，Q 测不到")
            ok_f = bool(f3) and abs(f3 - spec["target_hz"]) / spec["target_hz"] <= spec["tol"]
            ok_q = bool(q) and math.isfinite(q) and \
                abs(q - spec["target_q"]) / spec["target_q"] <= spec["q_tol"]
            return out(bool(ok_f and ok_q), got, want)

        if kind == "picked":
            # C 类专用：模型自己挑了什么数？有 fc 就报 fc，否则报低频增益。
            f3 = sol.f3db(node)
            if f3:
                return out(True, f"自选 fc={f3:.4g}Hz", "", float(f3))
            xs = list(sol.xaxis(node))
            g = abs(sol.value_at(node, xs[0])) if xs else float("nan")
            if math.isfinite(g):
                return out(True, f"自选低频增益={g:.4g}×", "", float(g))
            return out(None, "测不到主指标", "", None)

        if kind == "divider":
            if not src:
                return out(None, "找不到电压源节点", f"{spec['vout']:.4g}V")
            xs = list(sol.xaxis(node))
            f = xs[0] if xs else 1.0
            vs = sol.value_at(src, f)
            vo = sol.value_at(node, f)
            if not vs:
                return out(None, "源电压为 0", f"{spec['vout']:.4g}V")
            vout = abs(vo / vs) * spec["vin"]
            want = f"{spec['vout']:.4g}V±{spec['tol'] * 100:.0f}%（Vin={spec['vin']:.4g}V）"
            return out(abs(vout - spec["vout"]) / spec["vout"] <= spec["tol"],
                       f"实测 Vout={vout:.4g}V", want)

    except Exception as e:
        return out(None, f"测量异常：{type(e).__name__}: {e}", "")

    return out(None, f"未知 measure.kind={kind!r}", "")


# ==========================================================================
# 从 Generation 里读真实字段
# ==========================================================================
def _hallucination_hits(gen) -> list[dict]:
    """`spec_check` 真的抓到「AI 的数字 ≠ 实测」的那些轮次。

    判定依据是 `Attempt` 的真实字段：`stage == "ok"` 说明代码 exec 成功、
    仿真也收敛了（这一轮**看起来成功了**），但 `error` 非空 —— 只可能是
    指标对账（spec_check / 自带 c.expect）把它拦下来的。
    """
    hits = []
    for at in getattr(gen, "attempts", []) or []:
        err = at.error or ""
        if at.stage == "ok" and err:
            kind = ("自带 expect 未通过" if err.startswith("自带的规格未通过")
                    else "spec_check 指标不达标" if err.startswith("指标不达标")
                    else "对账未通过")
            hits.append({"attempt": at.n, "kind": kind, "error": err[:300]})
    return hits


def _is_model_failure(err: str) -> bool:
    """这条失败到底是「模型/网关没响应」，还是「产品判定它不合格」？

    这两件事必须分开：模型超时返回不了任何东西，**不能算产品拦住了不可行需求**
    —— 那会把「基础设施挂了」美化成「拦截率 100%」。
    """
    e = str(err or "")
    return any(k in e for k in ("调用模型失败", "CaseDeadline", "超时",
                                "未配置 API Key", "模型回复里没有找到"))


def _scan(text: str, words) -> str:
    """在文本里找信号词，返回命中的那一行（供人复核，不做自动裁决）。"""
    for line in (text or "").splitlines():
        s = line.strip()
        if not s:
            continue
        low = s.lower()
        if any(w.lower() in low for w in words):
            return s[:200]
    return ""


# ==========================================================================
# 单条用例
# ==========================================================================
def run_case(case, llm_factory, *, verbose: bool = True) -> dict:
    from ccl.ai.generate import generate

    rec = llm_factory()
    t0 = time.perf_counter()
    timed_out = False
    crash = ""
    gen = None

    # 外层守护线程：ngspice 卡死或模型端不响应时，整批不被拖住。
    # 用 daemon 线程（不是 ThreadPoolExecutor），避免挂住解释器退出。
    box: queue.Queue = queue.Queue()

    def work():
        try:
            box.put(("ok", generate(
                case.prompt,
                max_repair=MAX_REPAIR,
                timeout_s=25.0,
                temperature=0.2,
                _llm=rec,
            )))
        except BaseException as e:  # noqa: BLE001  generate 理论上不抛，但别赌
            box.put(("err", f"{type(e).__name__}: {e}\n{traceback.format_exc()[-800:]}"))

    th = threading.Thread(target=work, daemon=True)
    th.start()
    try:
        tag, payload = box.get(timeout=_CFG["case_timeout"])
    except queue.Empty:
        timed_out = True
        tag, payload = "timeout", None
    wall_ms = (time.perf_counter() - t0) * 1000

    if tag == "ok":
        gen = payload
    elif tag == "err":
        crash = str(payload)

    if gen is None:
        return {
            "id": case.id, "category": case.category, "expect": case.expect,
            "caught": False,
            "detail": ("超时" if timed_out else "异常") + "：模型链路没返回",
            "prompt": case.prompt, "intent": case.intent,
            # 模型链路没返回 = 基础设施失败（model_failed=True 恒成立），
            # 与主路径同口径：一律不计入任何指标（本文件 ② 处注释）。
            "counted": False,
            "model_failed": True,
            "ok": False, "error": crash or ("单条超时 >%.0fs" % _CFG["case_timeout"]),
            "rounds": None, "first_pass": False, "elapsed_ms": round(wall_ms, 1),
            "gen_elapsed_ms": None, "attempts": 0, "llm_calls": len(rec.calls),
            "model": getattr(rec, "model", ""),
            "timed_out": timed_out, "crashed": bool(crash),
            "hallucination_hits": [], "hallucination_n": 0,
            "limitation": "", "assumption": "", "measure": {"met": None, "got": "", "want": ""},
            "fabricated": False, "fake_success": False, "judged": None,
            "stages": [], "attempt_errors": [],
        }

    attempts = list(gen.attempts or [])
    rounds = max(0, len(attempts) - 1)
    ok = bool(gen.ok)
    model_failed = _is_model_failure(gen.error) and not ok
    if model_failed:
        # 内层 deadline 触发的超时（走 generate() 的「调用模型失败」分支）也算超时
        timed_out = timed_out or "超时" in str(gen.error) or "CaseDeadline" in str(gen.error)
    hits = _hallucination_hits(gen)

    # 模型的原始文本：正文（replies）+ 最终代码（source）+ 每轮的代码
    blob = "\n".join(list(getattr(rec, "replies", []) or []) +
                     [getattr(gen, "source", "") or ""] +
                     [a.source or "" for a in attempts])
    limitation = _scan(blob, _LIMIT_WORDS)
    assumption = _scan(blob, _ASSUME_WORDS)
    meas = _measure(case.measure, gen)

    stages = [(a.n, a.stage, (a.error or "")[:160]) for a in attempts]
    attempt_errors = [{"n": a.n, "stage": a.stage, "error": (a.error or "")[:400],
                       "line": a.line, "sim_ok": bool(a.sim_ok)} for a in attempts]

    # ---------------- 分类判定 ----------------
    caught = False
    fabricated = False
    fake_success = False
    judged = ""

    if case.category.startswith("A"):
        # 该做出来。三种失败必须分开，混报会互相污染：
        #   · ok=True 且实测达标            → 正常
        #   · ok=True 但实测不达标          → 假成功（caught=False：闸门没拦它，
        #                                     是**放行了垃圾**，记 fake_success）
        #   · 没做出达标设计，流水线如实拒收 → 质量失败（caught=False，不是误杀）
        #   · 实测按用例判据达标，流水线却拒 → **真·误杀**（caught=True）
        if ok and meas.get("met") is False:
            fake_success = True
            caught = False
            judged = "假成功（报 ok 但直接量不达标）"
        elif ok:
            caught = False
            judged = "做出来了且达标" + ("" if rounds == 0 else f"（修复 {rounds} 轮）")
        elif meas.get("met") is True:
            caught = True
            judged = "❗真·误杀：实测达标，流水线却判不合格（见 error）"
        else:
            caught = False
            judged = "没做出来（见 error）"
    elif case.category.startswith("B"):
        # 该拦住
        if model_failed:
            caught = False
            judged = "模型/网关没响应（超时或不可达），不计入拦截率"
        elif gen.error:
            caught = True
            judged = "拦住了（明确报错/判不合格）"
        elif limitation:
            caught = True
            judged = "拦住了（模型自己写了「做不到」）"
        else:
            caught = False
            if meas.get("met") is False:
                fabricated = True
                judged = "❗硬凑：交了个不达标的方案，还说做出来了"
            elif meas.get("met") is None:
                judged = "没拦住，且无从测量"
            else:
                judged = "真做出来了（超出预期，需人工复核用例）"
    else:  # C 类：不要求拒绝，只看有没有「编造且不自知」
        if not ok:
            caught = False
            judged = "没给出电路（但报错明确）" if gen.error else "没给出电路"
        elif assumption:
            caught = False
            judged = "合理默认（写了假设）"
        else:
            # 没写假设。这时唯一的判据是：模型自己挑的数是不是「通用默认值」。
            # 挑 1kHz / 10× / 5V→2.5V 这种行业默认 = 可接受（只是没留痕）；
            # 挑一个没来由的数（比如 4.7kHz、37×）还当成用户要求 = 编造且不自知。
            v = meas.get("value")
            if v is None or not case.ok_defaults:
                caught = False
                judged = "默认值但没留痕（可接受，扣分项；主指标测不到）"
            elif any(abs(v - d) / max(d, 1e-9) < 0.15 for d in case.ok_defaults):
                caught = False
                judged = "默认值但没留痕（可接受，扣分项）"
            else:
                caught = True
                judged = (f"❗编造且不自知（自选 {v:.4g}，不是通用默认 "
                          f"{list(case.ok_defaults)}，且没写任何假设）")

    if timed_out:
        caught = False if case.expect == "accept" else caught
        judged = "超时（>%.0fs）" % _CFG["case_timeout"]

    detail = judged
    if meas.get("got"):
        detail += f"｜实测 {meas['got']}" + (f"（要求 {meas['want']}）" if meas.get("want") else "")
    if gen.error:
        detail += f"｜error: {str(gen.error)[:180]}"

    res = {
        "id": case.id, "category": case.category, "expect": case.expect,
        # 模型没调通（超时/429/网络）= 基础设施失败，不是我们的判断结果。
        # 断言成立的方向两种情况都错：
        #   · expect=reject 却说"拦住了" → 高估拦截率
        #   · expect=accept 却说"误杀了" → 凭空制造误杀（实测发生过：HTTP 429）
        # 所以一律不计入，单独报"因模型未响应未计入"。
        "counted": not model_failed,
        "model_failed": bool(model_failed),
        "caught": bool(caught), "detail": detail,
        "prompt": case.prompt, "intent": case.intent,
        "ok": ok, "error": gen.error,
        "rounds": rounds, "first_pass": bool(ok and rounds == 0),
        "elapsed_ms": round(wall_ms, 1),
        "gen_elapsed_ms": round(float(gen.elapsed_ms or 0), 1),
        "attempts": len(attempts), "llm_calls": len(rec.calls),
        "model": gen.model or getattr(rec, "model", ""),
        "timed_out": timed_out, "crashed": bool(crash),
        "hallucination_hits": hits, "hallucination_n": len(hits),
        # 模型自加的断言没过、但用户要求达标 → 交付并告警。必须记下来：
        # 静默吞掉这条信息就等于「少报了一个已知不确定点」。
        "warnings": list(getattr(gen, "warnings", None) or []),
        "self_assert_failed": bool(getattr(gen, "warnings", None)),
        "limitation": limitation, "assumption": assumption,
        "measure": meas,
        "fabricated": bool(fabricated), "fake_success": bool(fake_success),
        "judged": judged, "stages": stages, "attempt_errors": attempt_errors,
        "source": (gen.source or "")[:4000],
    }
    if verbose:
        _print_case(res)
    return res


# ==========================================================================
# 打印
# ==========================================================================
def _w(s, n):
    """粗对齐：中文按 2 宽算。表格只为好读，不追求完美。"""
    s = str(s)
    width = sum(2 if ord(ch) > 0x2E80 else 1 for ch in s)
    if width > n:
        out, acc = "", 0
        for ch in s:
            acc += 2 if ord(ch) > 0x2E80 else 1
            if acc > n - 1:
                break
            out += ch
        return out + "…"
    return s + " " * (n - width)


def _print_header():
    print()
    print(_w("id", 26) + _w("类别", 14) + _w("ok", 6) + _w("修复轮次", 10) +
          _w("耗时s", 8) + _w("拦?", 6) + "判定")
    print("-" * 118)


def _print_case(r):
    print(
        _w(r["id"], 26) + _w(r["category"], 14) +
        _w("✓" if r["ok"] else "✗", 6) +
        _w("-" if r["rounds"] is None else r["rounds"], 10) +
        _w(f"{r['elapsed_ms'] / 1000:.1f}", 8) +
        _w("是" if r["caught"] else "否", 6) + r["judged"]
    )
    if r["hallucination_n"]:
        for h in r["hallucination_hits"]:
            print(f"    ↳ 幻觉拦截[{h['kind']}] 第{h['attempt']}轮：{h['error'][:110]}")
    if r["measure"].get("got"):
        print(f"    ↳ 实测：{r['measure']['got']}"
              + (f" ｜ 要求 {r['measure']['want']}" if r["measure"].get("want") else ""))
    if r["error"]:
        print(f"    ↳ error：{str(r['error'])[:160]}")
    if r["limitation"]:
        print(f"    ↳ 模型自称限制：{r['limitation'][:120]}")


def _print_totals(t: dict):
    print("\n" + "=" * 118)
    print("汇总")
    print("=" * 118)
    print(f"  实际跑完        : {t['judged']} 条 / 共 {t['total']} 条"
          f"（超时 {t['timed_out']}，异常 {t['crashed']}，跳过 {t['skipped']}）")
    print(f"  总耗时          : {t['total_s']:.1f}s ｜ 平均 {t['avg_s']:.1f}s/条")
    print(f"  一次通过率      : {t['first_pass_rate'] * 100:.0f}%"
          f"（{t['first_pass_n']}/{t['judged']}）")
    ar = "-" if t["avg_rounds"] is None else f"{t['avg_rounds']:.2f}"
    aro = "-" if t["avg_rounds_ok"] is None else f"{t['avg_rounds_ok']:.2f}"
    print(f"  平均修复轮次    : {ar} 轮（成功用例 {aro} 轮，max_repair={MAX_REPAIR}）")
    if t["b_caught_rate"] is None:
        print("  B 类拦截率      : 本轮无 B 类用例（--only/--limit 裁掉了）")
    else:
        print(f"  B 类拦截率      : {t['b_caught_rate'] * 100:.0f}%"
              f"（{t['b_caught']}/{t['b_n']}）"
              + (f"，另有 {t['b_uncounted']} 条因模型未响应不计入" if t["b_uncounted"] else ""))
    print(f"  幻觉拦截数      : {t['hallucination_n']} 次（spec_check / 自带 expect 抓到）")
    if t.get("self_assert_warn_n"):
        print(f"  自加断言告警    : {t['self_assert_warn_n']} 条"
              f"（用户要求已达标，但代码里自带的 c.expect 没过 —— 已交付并标注，需人工确认）")
    print(f"  硬凑(B类假装达标): {t['fabricated_n']} 条  ← 重大问题，必须为 0")
    print(f"  假成功(A类报 ok 但不达标): {t['fake_success_n']} 条")
    print(f"  C 类「编造且不自知」: {t['c_fabricated_n']} 条")
    print(f"  A 类真·误杀     : {t.get('a_false_kill_n', 0)} 条"
          f"（质量失败另有 {t.get('a_fail_n', 0)} 条：没做出达标设计，被如实拒收）")


# ==========================================================================
# 主流程
# ==========================================================================
def _skip(reason: str, *, out: Path, extra: dict | None = None) -> int:
    """环境不可用时的优雅退出：写 skipped JSON，退出码 0。

    **绝不假装通过**：`skipped=true` + `reason` 写明到底缺什么。
    """
    doc = {
        "layer": "llm",
        "skipped": True,
        "reason": reason,
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "case_count": len(CASES),
        "cases": [],
    }
    if extra:
        doc.update(extra)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n未配置可用的模型，本层跳过：{reason}")
    print(f"已写 {out}（skipped=true，未产生任何指标）")
    return 0


def _preflight() -> tuple[bool, str, dict]:
    """先确认模型真的能用。**光看 key 非空是不够的**——Key 在、网关不在，
    这种“假可用”会让 14 条用例全部瞬间失败，被误读成「模型全挂」。"""
    try:
        from copilot.llm import LLM, load_config
    except Exception as e:
        return False, f"无法加载 copilot.llm：{type(e).__name__}: {e}", {}

    try:
        cfg = load_config()
    except Exception as e:
        return False, f"读取配置失败：{type(e).__name__}: {e}", {}

    info = {"base": cfg.get("base", ""), "model": cfg.get("model", ""),
            "key_present": bool(cfg.get("key"))}
    if not cfg.get("key"):
        return False, "未配置 API Key（~/.cc/config.json 或 CC_LLM_KEY / DEEPSEEK_API_KEY）", info

    llm = LLM()
    # 预检重试：免费端点/自建网关会有偶发超时和 429。单次探测失败就宣布
    # 「模型不可达」会让整个基准因为一次抖动就跳过——那是把基础设施的
    # 一次抽风记成结论。所以探 3 次，只要有一次通就算通。
    errs: list[str] = []
    t0 = time.perf_counter()
    for attempt in range(1, 4):
        try:
            llm.chat([{"role": "user", "content": "回复一个字：好"}],
                     max_tokens=8, timeout=30)
            info["probe_ms"] = round((time.perf_counter() - t0) * 1000, 1)
            info["probe_tries"] = attempt
            return True, "", info
        except Exception as e:
            errs.append(f"[{attempt}] {type(e).__name__}: {e}")
            if attempt < 3:
                time.sleep(8 * attempt)
    info["probe_error"] = " ｜ ".join(errs)
    info["probe_ms"] = round((time.perf_counter() - t0) * 1000, 1)
    return False, f"模型不可达（{cfg.get('base')}）：{errs[-1]}", info


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="CCL 真实大模型端到端基准")
    ap.add_argument("--only", action="append", default=[], metavar="ID",
                    help="只跑指定用例（可多次；先单跑 1 条确认链路）")
    ap.add_argument("--limit", type=int, default=0, help="只跑前 N 条")
    ap.add_argument("--stub", choices=["good", "cheat", "timeout", "dead"], default="",
                    help="干跑自测：用假模型验证运行器本身，不发网络请求，不写正式结果")
    ap.add_argument("--out", default="", help="结果 JSON 路径（默认 bench/results_llm.json）")
    ap.add_argument("--no-preflight", action="store_true", help="跳过连通性探测（不建议）")
    ap.add_argument("--case-timeout", type=float, default=CASE_TIMEOUT_S,
                    help=f"单条墙钟上限秒（默认 {CASE_TIMEOUT_S:.0f}，契约值，别随便调小）")
    ap.add_argument("--call-timeout", type=float, default=CALL_TIMEOUT_S,
                    help=f"单次模型调用上限秒（默认 {CALL_TIMEOUT_S:.0f}）")
    args = ap.parse_args(argv)

    _CFG["case_timeout"] = max(5.0, float(args.case_timeout))
    _CFG["call_timeout"] = max(2.0, float(args.call_timeout))

    stub = bool(args.stub)
    out = Path(args.out) if args.out else (OUT_JSON_STUB if stub else OUT_JSON)

    cases = list(CASES)
    if args.only:
        try:
            cases = [by_id(i) for i in args.only]
        except KeyError as e:
            print(f"✗ {e}", file=sys.stderr)
            return 2
    if args.limit > 0:
        cases = cases[:args.limit]

    print("=" * 118)
    print("CCL 基准｜第 2 层：真实大模型端到端（generate → 沙箱 → 仿真 → 指标对账 → 修复）")
    print("=" * 118)
    print(f"用例集：{case_stats()}")
    print(f"本轮跑：{len(cases)} 条 ｜ max_repair={MAX_REPAIR} ｜ 单条上限 {_CFG['case_timeout']:.0f}s ｜ 单次调用 {_CFG['call_timeout']:.0f}s")

    pre: dict = {}
    if stub:
        mode = args.stub
        llm_factory = lambda: RecordingLLM(StubLLM(mode))  # noqa: E731
        print(f"模式：**干跑自测 stub={mode}**（假模型，结果不是真实数字，写入 "
              f"{out.name}）")
    else:
        if not args.no_preflight:
            ok, why, pre = _preflight()
            print(f"预检：{'通过' if ok else '失败'} {pre}")
            if not ok:
                return _skip(why, out=out, extra={"preflight": pre})
        llm_factory = lambda: RecordingLLM(_real_llm())  # noqa: E731
        print(f"模式：**真实模型**（{pre.get('model', '?')} @ {pre.get('base', '?')}）")

    print()
    _print_header()

    results: list[dict] = []
    t_all = time.perf_counter()
    for i, case in enumerate(cases, 1):
        r = run_case(case, llm_factory)
        results.append(r)

    total_s = time.perf_counter() - t_all

    # ---------------- 汇总 ----------------
    judged = [r for r in results if not (r["timed_out"] and r["rounds"] is None)]
    n_j = len(judged) or 1
    first_pass_n = sum(1 for r in judged if r["first_pass"])
    rounds = [r["rounds"] for r in judged if r["rounds"] is not None]
    rounds_ok = [r["rounds"] for r in judged if r["ok"] and r["rounds"] is not None]
    b_all = [r for r in judged if r["category"].startswith("B")]
    b = [r for r in b_all if r.get("counted", True)]
    halluc = sum(r["hallucination_n"] for r in judged)

    totals = {
        "total": len(cases),
        "judged": len(judged),
        "skipped": len(cases) - len(judged),
        "timed_out": sum(1 for r in results if r["timed_out"]),
        "crashed": sum(1 for r in results if r["crashed"]),
        "total_s": round(total_s, 1),
        "avg_s": round(total_s / max(len(results), 1), 1),
        "first_pass_n": first_pass_n,
        "first_pass_rate": round(first_pass_n / n_j, 4),
        "avg_rounds": round(sum(rounds) / len(rounds), 3) if rounds else None,
        "avg_rounds_ok": round(sum(rounds_ok) / len(rounds_ok), 3) if rounds_ok else None,
        "b_n": len(b),
        "b_uncounted": len(b_all) - len(b),
        "b_caught": sum(1 for r in b if r["caught"]),
        "b_caught_rate": round(sum(1 for r in b if r["caught"]) / len(b), 4) if b else None,
        "hallucination_n": halluc,
        # 「用户指标达标但模型自加断言没过」的条数：交付了，但需要人看一眼
        "self_assert_warn_n": sum(1 for r in results if r.get("self_assert_failed")),
        "fabricated_n": sum(1 for r in results if r["fabricated"]),
        "fake_success_n": sum(1 for r in results if r["fake_success"]),
        "c_fabricated_n": sum(1 for r in results
                              if r["category"].startswith("C") and r["caught"]),
        # A 类两种失败分开算：真·误杀进误杀率；质量失败只影响成功率，
        # 不许污染误杀率（实测教训：stub=good 里 a2 达标被拒是真误杀，
        # 而"模型没做出来"若也算误杀，模型越差误杀率越高——荒谬）。
        "a_counted_n": sum(1 for r in results
                           if r["category"].startswith("A") and r.get("counted", True)),
        "a_false_kill_n": sum(1 for r in results if r["category"].startswith("A")
                              and r.get("counted", True) and r["caught"]),
        "a_fail_n": sum(1 for r in results if r["category"].startswith("A")
                        and r.get("counted", True) and not r["ok"]),
        "llm_calls": sum(r["llm_calls"] for r in results),
        "max_case_s": max((r["elapsed_ms"] / 1000 for r in results), default=0),
    }
    _print_totals(totals)

    _rel = str(out)
    try:
        _rel = str(out.relative_to(ROOT))
    except Exception:
        pass
    doc = {
        "layer": "llm",
        "skipped": False,
        "stub": stub,
        "stub_mode": args.stub or None,
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "meta": {
            "model": results[0]["model"] if results else pre.get("model", ""),
            "preflight": pre,
            "max_repair": MAX_REPAIR,
            "case_timeout_s": _CFG["case_timeout"],
            "call_timeout_s": _CFG["call_timeout"],
            "case_set": case_stats(),
            "note": ("stub 干跑：假模型，仅用于验证运行器逻辑，不是真实模型指标"
                     if stub else ""),
        },
        "totals": totals,
        "cases": results,
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n已写 {_rel}")

    if stub:
        print("⚠ 这是 stub 干跑结果，不可当作真实模型指标引用。")
    return 0


def _real_llm():
    from copilot.llm import LLM
    return LLM()


if __name__ == "__main__":
    sys.exit(main())
