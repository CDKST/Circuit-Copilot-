#!/usr/bin/env python3
"""AI 拦截能力基准：统一入口。

把两层的 JSON 结果汇总成一张表，并施加**底线判定**：

  · 该拦的没拦住  → 失败（漏网）
  · 不该拦的拦了  → 失败（误杀）

只报拦截率是废指标：全部拒绝的系统拦截率 100%，但毫无价值。
所以两个数字必须一起看。

    python3 bench/run_bench.py              # 汇总已有结果
    python3 bench/run_bench.py --run        # 先跑子基准再汇总
    python3 bench/run_bench.py --run-gates  # 只跑确定性闸门层（不烧 token）
"""

from __future__ import annotations

import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

LAYERS = [
    ("gates", "确定性闸门", "results_gates.json", "run_gates.py"),
    ("llm", "真实模型端到端", "results_llm.json", "run_llm.py"),
]

# 底线：这两条不达成就不能对外说"我们有拒绝机制"
TARGET_RECALL = 1.0        # 该拦的必须全拦
TARGET_FP = 0.0            # 一条都不许误杀


# ---------------------------------------------------------------------------
# 统计
# ---------------------------------------------------------------------------

def summarize(cases: list[dict]) -> dict:
    """按类别统计，同时算拦截率与误杀率。

    `counted == False` 的用例**一律不计**：它表示"这次无法判定"
    （典型情况：模型 HTTP 429 / 超时，根本没跑出结果）。
    把这种算成误杀会凭空抹黑自己，算成拦截又会虚报。
    """
    by_cat: dict[str, dict] = {}
    for c in cases:
        if c.get("counted") is False:
            b = by_cat.setdefault(c.get("category") or "未分类",
                                  {"reject_n": 0, "reject_hit": 0,
                                   "accept_n": 0, "accept_hit": 0,
                                   "missed": [], "killed": [], "excluded": 0})
            b.setdefault("excluded", 0)
            b["excluded"] += 1
            continue
        cat = c.get("category") or "未分类"
        b = by_cat.setdefault(cat, {"reject_n": 0, "reject_hit": 0,
                                    "accept_n": 0, "accept_hit": 0,
                                    "missed": [], "killed": [], "excluded": 0})
        if c.get("expect") == "reject":
            b["reject_n"] += 1
            if c.get("caught"):
                b["reject_hit"] += 1
            else:
                b["missed"].append(c)
        else:
            b["accept_n"] += 1
            if c.get("caught"):
                b["accept_hit"] += 1
                b["killed"].append(c)
    return by_cat


def pct(a: float, b: float) -> str:
    if b == 0:
        return "—"
    return f"{a / b * 100:.0f}%"


def print_layer(label: str, cases: list[dict]) -> tuple[int, int, int, int]:
    cats = summarize(cases)
    print(f"\n{'=' * 78}")
    print(f"  {label}（{len(cases)} 条用例）")
    print("=" * 78)
    print(f"  {'类别':<22s} {'拦截':>10s} {'拦截率':>7s} {'误杀':>10s} {'误杀率':>7s}")
    print(f"  {'-' * 22} {'-' * 10} {'-' * 7} {'-' * 10} {'-' * 7}")

    tot = [0, 0, 0, 0]
    for cat in sorted(cats):
        b = cats[cat]
        line = (f"  {cat:<22s} "
                f"{b['reject_hit']:>4d}/{b['reject_n']:<5d} "
                f"{pct(b['reject_hit'], b['reject_n']):>7s} "
                f"{b['accept_hit']:>4d}/{b['accept_n']:<5d} "
                f"{pct(b['accept_hit'], b['accept_n']):>7s}")
        flag = ""
        if b["missed"]:
            flag += " ← 漏网"
        if b["killed"]:
            flag += " ← 误杀"
        print(line + flag)
        tot[0] += b["reject_hit"]
        tot[1] += b["reject_n"]
        tot[2] += b["accept_hit"]
        tot[3] += b["accept_n"]

    print(f"  {'-' * 22} {'-' * 10} {'-' * 7} {'-' * 10} {'-' * 7}")
    print(f"  {'合计':<22s} {tot[0]:>4d}/{tot[1]:<5d} {pct(tot[0], tot[1]):>7s} "
          f"{tot[2]:>4d}/{tot[3]:<5d} {pct(tot[2], tot[3]):>7s}")
    exc = sum(b.get("excluded", 0) for b in cats.values())
    if exc:
        print(f"  另有 {exc} 条因模型未响应 / 无法判定而未计入")

    # 漏网与误杀的明细——这是整份报告最有价值的部分
    for cat in sorted(cats):
        b = cats[cat]
        for c in b["missed"]:
            print(f"\n  ✗ 漏网  [{cat}] {c.get('id')}")
            print(f"          {c.get('detail') or '（闸门没给出理由）'}")
        for c in b["killed"]:
            print(f"\n  ✗ 误杀  [{cat}] {c.get('id')}")
            print(f"          {c.get('detail') or ''}")
    return tuple(tot)


# ---------------------------------------------------------------------------
# 读结果
# ---------------------------------------------------------------------------

def print_llm(d: dict) -> tuple[int, int, int, int]:
    """llm 层的失败模式和闸门层不同，单独汇总。

    直接用运行器算好的 totals（口径最细），只把两件事并入底线：
    拦截率 ← B 类；误杀率 ← A 类「真·误杀」。
    假成功 / 硬凑 / C 类编造是另一种失败——**放行了不该放的**，
    不是「拒了不该拒的」，单独列出，不混进误杀率。
    """
    t = d["totals"]
    cases = d.get("cases") or []
    n_j = t.get("judged", len(cases))
    n_t = t.get("total", len(cases))
    # 不完整的跑（有用例撞超时/异常没判定）不并入底线：
    # B 类只跑到 1 条时，1/1 会把拦截率虚报成 100%。
    incomplete = n_j < n_t
    print(f"\n{'=' * 78}")
    print(f"  真实模型端到端 · llm（{n_j}/{n_t} 条跑完）"
          + ("  ⚠ 不完整跑，仅展示，不并入底线" if incomplete else ""))
    print("=" * 78)
    print(f"  一次通过率    : {(t.get('first_pass_rate') or 0) * 100:.0f}%"
          f"（{t.get('first_pass_n', 0)}/{n_j}）｜"
          f"平均修复 {(t.get('avg_rounds') or 0):.2f} 轮")
    bline = f"  B 类拦截率    : {t.get('b_caught', 0)}/{t.get('b_n', 0)}"
    if t.get("b_caught_rate") is not None:
        bline += f" = {t['b_caught_rate'] * 100:.0f}%"
    if t.get("b_uncounted"):
        bline += f"｜另有 {t['b_uncounted']} 条模型未响应未计入"
    print(bline)
    print(f"  A 类真·误杀   : {t.get('a_false_kill_n', 0)}/{t.get('a_counted_n', 0)}"
          f"｜质量失败（没做出达标设计）: {t.get('a_fail_n', 0)} 条")
    print(f"  假成功        : {t.get('fake_success_n', 0)} 条"
          f"｜硬凑(B类假装达标): {t.get('fabricated_n', 0)} 条")
    print(f"  C 类编造不自知: {t.get('c_fabricated_n', 0)} 条"
          f"｜幻觉拦截: {t.get('hallucination_n', 0)} 次")

    # 坏消息逐条点名——这份报告的价值就在这里
    for c in cases:
        is_b = c.get("category", "").startswith("B")
        bad = ((is_b and not c.get("caught") and c.get("counted", True))
               or (c.get("category", "").startswith("A") and c.get("caught"))
               or c.get("fabricated") or c.get("fake_success")
               or (c.get("category", "").startswith("C")
                   and c.get("caught") and c.get("counted", True)))
        if bad:
            mark = "✗ 漏网" if is_b else "✗ 问题"
            print(f"\n  {mark}  [{c.get('category')}] {c.get('id')} —— {c.get('judged')}")
            det = (c.get("detail") or "")[:220]
            if det:
                print(f"          {det}")
    if incomplete:
        return (0, 0, 0, 0)
    return (t.get("b_caught", 0), t.get("b_n", 0),
            t.get("a_false_kill_n", 0), t.get("a_counted_n", 0))


def load(name: str):
    p = os.path.join(HERE, name)
    if not os.path.isfile(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"  ⚠ {name} 解析失败：{e}")
        return None


def run_sub(script: str, extra: list[str] | None = None) -> int:
    p = os.path.join(HERE, script)
    if not os.path.isfile(p):
        print(f"  · 跳过 {script}（文件不存在，可能还没交付）")
        return 0
    print(f"\n▶ 运行 {script} …")
    r = subprocess.run([sys.executable, p] + (extra or []),
                       cwd=ROOT, text=True)
    return r.returncode


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def main() -> int:
    args = sys.argv[1:]
    do_run = "--run" in args
    only_gates = "--run-gates" in args

    if do_run or only_gates:
        for lid, label, _jf, script in LAYERS:
            if only_gates and lid != "gates":
                continue
            run_sub(script)

    print("\n" + "█" * 78)
    print("  AI 拦截能力基准")
    print("  「AI 出错时，我们抓不抓得住」——把 claims 变成数字")
    print("█" * 78)

    total = [0, 0, 0, 0]
    skipped = []
    for lid, label, jf, _script in LAYERS:
        d = load(jf)
        if d is None:
            skipped.append(label)
            continue
        if d.get("skipped"):
            print(f"\n  · {label}：跳过（{d.get('reason') or '未配置'}）")
            skipped.append(label)
            continue
        if d.get("layer") == "llm" and d.get("totals"):
            if d.get("stub"):
                print(f"\n  · {label}：stub 干跑结果（自我声明），不进指标")
                skipped.append(label)
                continue
            t = print_llm(d)
            for i in range(4):
                total[i] += t[i]
            continue
        cases = d.get("cases") or []
        if not cases:
            skipped.append(label)
            continue
        t = print_layer(f"{label} · {lid}", cases)
        for i in range(4):
            total[i] += t[i]

    print(f"\n{'=' * 78}")
    print("  总合计")
    print("=" * 78)
    print(f"  拦截率：{total[0]}/{total[1]} = {pct(total[0], total[1])}"
          f"   （目标 {TARGET_RECALL * 100:.0f}%）")
    print(f"  误杀率：{total[2]}/{total[3]} = {pct(total[2], total[3])}"
          f"   （目标 {TARGET_FP * 100:.0f}%）")

    if skipped:
        print(f"\n  未参与汇总：{'、'.join(skipped)}")

    # 底线判定
    ok = True
    if total[1] == 0:
        print("\n  ⚠ 没有任何「该拦」用例，基准本身不成立")
        ok = False
    else:
        if total[0] < total[1]:
            print(f"\n  ✗ 有 {total[1] - total[0]} 条该拦的没拦住——"
                  "不能对外说「我们有拒绝机制」")
            ok = False
        if total[2] > 0:
            print(f"\n  ✗ 误杀了 {total[2]} 条合法设计——"
                  "拒绝机制伤到了正常使用")
            ok = False
        if ok:
            print("\n  ✓ 该拦的全拦住了，且没有误杀")

    print("\n  怎么看这份结果：")
    print("   · 拦截率高 + 误杀率 0 → 机制可信")
    print("   · 拦截率高 + 误杀率也高 → 它只是「倾向于拒绝」，不是「判断得准」")
    print("   · 拦截率低 → 闸门有洞，看上面的「漏网」明细")
    print("=" * 78)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
