"""前后端契约测试：界面上显示的东西，字段名必须真的对得上。

## 为什么单独有这一层

这一层抓的是「后端发 A、前端读 B」这类**静默的显示错误**。它们不会让任何
接口返回 500，测试也全绿，但用户在界面上看到的是错的。已经发生过的两次：

1. **指标行的 ✓/✗ 恒为 ✓**
   `serialize()` 发的是 `"ok": True/False`，而 `main.js` 读的是 `sp.passed`
   → `undefined !== false` 恒为真 → **所有指标都显示 ✓**，包括没达标的。
   用户会拿着一个不达标的设计去打样。

2. **基准面板整个失效**
   电脑端给服务端加了 JSON-only 强校验（POST 缺 Content-Type → 415），
   而基准面板的 fetch 只写了 `method: 'POST'` → 面板显示「基准失败」。
   前端另外 5 个 POST 都带了 header，只有这一处漏了。

这两类问题靠接口测试（只验状态码和结构）是抓不到的，必须**核对字段名与请求头**。
"""

from __future__ import annotations

import json
import os

import _harness as H
from _harness import case, contains, is_true, equal

_MAIN_JS = os.path.join(H.ROOT, "web", "ide", "main.js")


def _main_js() -> str:
    with open(_MAIN_JS, encoding="utf-8") as f:
        return f.read()


def _design(text: str, *, use_llm: bool = False) -> dict:
    """跑一次 /api/design 并取出最后一条 result 事件的数据。"""
    import urllib.request

    body = json.dumps({"text": text, "use_llm": use_llm}).encode()
    req = urllib.request.Request(
        H.BASE + "/api/design", data=body,
        headers={"Content-Type": "application/json"}, method="POST")
    raw = urllib.request.urlopen(req, timeout=180).read().decode("utf-8", "replace")
    last = None
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except Exception:
            continue
        if ev.get("type") == "result":
            last = ev.get("data")
    is_true(last is not None, "/api/design 没有返回 result 事件")
    return last




@case(group="契约")
def test_frontend_reads_ok_not_passed():
    """前端必须读 `sp.ok`，不能读不存在的 `sp.passed`。

    这条是死代码级检查：`sp.passed` 在历史版本里导致所有指标恒显示 ✓。
    """
    js = _main_js()
    contains(js, "sp.ok", "main.js 应读取指标行的 ok 字段")
    # ⚠ 精确到自己当年的错法：**指标行**的 pass 判定必须用 ok。
    # 不能简单 grep "sp.passed" —— d.spec 这个对象本身合法地有 passed 字段
    # （表示整份需求是否全部达标），拿它当行判定才是 bug。
    is_true("const pass = sp.passed" not in js,
            "指标行的 ✓/✗ 判定必须用 sp.ok；用 sp.passed 会让所有行恒为 ✓")
    is_true("sp.ok !== false" in js or "sp.ok" in js, "应存在按 ok 判定指标行的代码")


@case(group="契约")
def test_design_rows_have_ok_field_and_a_real_false():
    """一次设计同时验两件事：字段叫 ok、且**真的会出现 False**。

    只验「字段存在」不够——历史上字段读错后永远为 True，指标行恒显示 ✓。
    所以这里故意要一个做不到的凹陷深度（95dB），逼出一个 False。
    （合并成一次设计是为了省时间：每次完整设计在手机上要十几秒。）
    """
    d = _design("设计一个 50Hz 工频陷波器，要求凹陷深度至少 95dB", use_llm=False)
    spec = d.get("spec") or []
    is_true(len(spec) > 0, "设计结果里没有 spec 指标行")
    row = spec[0]
    is_true("ok" in row, f"指标行缺少 ok 字段，实际字段：{sorted(row)}")
    is_true(isinstance(row["ok"], bool), f"ok 应是布尔值，实际 {type(row['ok'])}")
    is_true("passed" in d, "结果里缺少 passed（总体达标）字段")
    flags = [bool(r.get("ok")) for r in spec]
    is_true(any(f is False for f in flags),
            f"要求 95dB 凹陷却没有任何指标判负：{[(r.get('label'), r.get('actual_text')) for r in spec]}")
    is_true(d.get("passed") is False, "有指标不达标时 passed 应为 False")


@case(group="契约")
def test_out_of_scope_is_structured_not_just_a_string():
    """能力边界拒绝必须给出结构化 issues（界面按条渲染「结论/为什么/怎么办」）。

    只给一句 error 字符串的话，手机侧栏里就是一大坨右对齐文字，读不下去。
    """
    d = _design("做一个 Buck 降压电路，输出 5V", use_llm=False)
    issues = d.get("issues") or []
    is_true(len(issues) > 0, "超出能力范围时应返回 issues 列表")
    i = issues[0]
    for field in ("code", "title", "evidence", "suggestion", "severity"):
        is_true(field in i, f"issue 缺少字段 {field}，实际：{sorted(i)}")
    is_true(str(i["code"]).startswith("no_"), f"能力边界类 issue 的 code 应以 no_ 开头，实际 {i['code']}")
    is_true(i["severity"] == "hard", "能力边界应是 hard")


@case(group="契约")
def test_bench_endpoint_requires_json_content_type():
    """服务端对 POST 做 JSON-only 校验：缺 Content-Type 必须 415（安全加固）。"""
    import urllib.error
    import urllib.request

    req = urllib.request.Request(H.BASE + "/api/bench/run", data=b"{}", method="POST")
    code = 0
    try:
        urllib.request.urlopen(req, timeout=30)
        code = 200
    except urllib.error.HTTPError as e:
        code = e.code
    is_true(code == 415, f"缺 Content-Type 时应为 415，实际 {code}")


@case(group="契约")
def test_frontend_sends_json_header_for_bench():
    """前端所有 POST 都必须带 JSON 头——漏一个就会「面板莫名失败」。

    历史事故：基准面板只写了 method:'POST'，被加固后的服务端直接 415，
    界面上显示「基准失败」，而后端其实完全正常。
    """
    js = _main_js()
    # 逐个 POST 调用点检查其后紧跟的片段里是否有 Content-Type
    idx = 0
    checked = 0
    while True:
        idx = js.find("method: 'POST'", idx)
        if idx < 0:
            break
        window = js[idx: idx + 220]
        checked += 1
        is_true("Content-Type" in window,
                f"有一个 POST 调用没带 Content-Type，附近代码：\n{window[:160]}")
        idx += 10
    is_true(checked >= 5, f"只找到 {checked} 个 POST 调用，检查逻辑可能失效")


@case(group="契约")
def test_bench_endpoint_returns_counts():
    """基准面板不写死条数：数字应由接口给，界面只展示。"""
    import urllib.request

    req = urllib.request.Request(
        H.BASE + "/api/bench/run", data=b"{}",
        headers={"Content-Type": "application/json"}, method="POST")
    d = json.loads(urllib.request.urlopen(req, timeout=120).read())
    is_true(d.get("ok") is True, f"基准接口失败：{d.get('error')}")
    cases = (d.get("gates") or {}).get("cases") or []
    is_true(len(cases) >= 60, f"闸门用例过少：{len(cases)}")
    # 界面上不该再写死条数（曾经写死 64，实际已是 83）
    js = _main_js()
    is_true("64 条对抗用例" not in js, "面板文案里还写死着「64 条」，应改为由数据驱动")


@case(group="契约")
def test_block_snippets_match_blocks_registry():
    """代码速查面板的积木名单必须与 ccl.blocks.BLOCKS 完全一致。

    历史问题：积木表加了三块（高通/差分/陷波），面板还是老的 9 块，
    用户在界面上根本看不到新积木，只能靠猜。
    """
    import re
    import sys

    sys.path.insert(0, H.ROOT)
    from ccl.blocks import BLOCKS

    js = _main_js()  # 只要保证文件可读；真正的名单在 snippets.js
    del js
    snip = open(os.path.join(H.ROOT, "web", "ide", "snippets.js"), encoding="utf-8").read()
    i = snip.find("BLOCK_SNIPPETS")
    seg = snip[i:snip.find("};", i)]
    keys = set(re.findall(r"^\s{2}([a-z_0-9]+):", seg, re.M))

    missing = set(BLOCKS) - keys
    extra = keys - set(BLOCKS)
    is_true(not missing, f"速查面板缺少这些积木：{sorted(missing)}")
    is_true(not extra, f"速查面板有 BLOCKS 里不存在的项：{sorted(extra)}")


@case(group="契约")
def test_all_examples_are_runnable():
    """示例列表里的每段代码都必须真能跑出结果。

    examples 文件的注释里写着「必须能真实跑通，改动后要重新跑一遍验证」，
    但一直没有自动化测试——结果加拓扑/改器件后就可能悄悄坏掉。
    """
    import sys

    sys.path.insert(0, os.path.join(H.ROOT, "web"))
    import ccl_examples as E

    bad = []
    for ex in E.EXAMPLES:
        try:
            ns: dict = {}
            exec(compile(ex["code"], f"<{ex['title']}>", "exec"), ns)
            c = ns["build"]()
            a = ex["analysis"]
            k = a["kind"]
            if k == "ac":
                c.ac(a["f_start"], a["f_stop"], a.get("points", 100))
            elif k == "tran":
                c.tran(a["t_step"], a["t_stop"])
            elif k == "dc":
                c.dc(a.get("source", "V1"), a["start"], a["stop"], a["step"])
        except Exception as e:  # noqa: BLE001
            bad.append(f"{ex['title']}: {type(e).__name__}: {e}")
    is_true(not bad, "有示例跑不通：\n  " + "\n  ".join(bad))
    is_true(len(E.EXAMPLES) >= 10, f"示例只剩 {len(E.EXAMPLES)} 个")


@case(group="契约")
def test_notch_example_assertion_passes():
    """陷波示例里那条 expect 必须真的通过——否则示例本身就是个坏示范。"""
    import sys

    sys.path.insert(0, os.path.join(H.ROOT, "web"))
    import ccl_examples as E

    ex = next((x for x in E.EXAMPLES if "陷波" in x["title"]), None)
    is_true(ex is not None, "示例列表里没有陷波示例（新能力在界面上看不见）")
    ns: dict = {}
    exec(compile(ex["code"], "<notch>", "exec"), ns)
    c = ns["build"]()
    rep = c.verify()
    is_true(rep.passed, f"陷波示例的断言没通过：{[str(r) for r in rep.results]}")


@case(group="契约")
def test_run_with_require_checks_original_requirement():
    """带 require 时，`/api/ccl/run` 必须把「需求 vs 实测」对一次账。

    这是补上一个上下文丢失：AI 生成的代码会带着生成时的需求进编辑器，
    但以前点 ▶ 运行时这个上下文就丢了 —— 用户改了元件值，没人再核对
    「还满不满足原需求」，只剩模型自己写的 c.expect（可能有偏）。
    """
    import urllib.request

    correct = (
        "from ccl import Circuit, GND\n\n"
        "def build():\n"
        "    c = Circuit('d')\n"
        "    c.V('in', GND, ac=1)\n"
        "    c.R('in', 'out', 26.4e3)\n"
        "    c.R('out', GND, 10e3)\n"
        "    return c\n"
    )
    straight = correct.replace("26.4e3", "1.0").replace("10e3", "1e9")
    an = {"kind": "ac", "f_start": 1, "f_stop": 1e6, "points": 50}

    def post(code, require=None):
        body = {"code": code, "analysis": an}
        if require:
            body["require"] = require
        req = urllib.request.Request(
            H.BASE + "/api/ccl/run", data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json"}, method="POST")
        return json.loads(urllib.request.urlopen(req, timeout=120).read())

    d_ok = post(correct, "把 12V 分压到 3.3V")
    is_true(d_ok.get("ok"), f"正确分压应能跑通：{d_ok.get('error')}")
    sp = d_ok.get("spec")
    is_true(sp is not None, "带 require 时应返回 spec 对账结果")
    is_true(sp.get("passed") is True, f"12V→3.3V 应判达标，实际 {sp.get('text')}")
    is_true(sp.get("checked") == 1, f"应核对 1 项，实际 {sp.get('checked')}")

    d_bad = post(straight, "把 12V 分压到 3.3V")
    sp2 = d_bad.get("spec") or {}
    is_true(sp2.get("passed") is False,
            f"直通电路（输出 12V）必须判未达标，实际 {sp2.get('text')}")
    is_true(bool(sp2.get("hint")), "未达标时应给出可执行的修复提示")


@case(group="契约")
def test_run_without_require_is_unchanged():
    """不带 require（手写代码）时，绝不能凭空造一个需求来对账。"""
    import urllib.request

    code = (
        "from ccl import Circuit, GND\n\n"
        "def build():\n"
        "    c = Circuit('rc')\n"
        "    c.V('in', GND, ac=1)\n"
        "    c.R('in', 'out', 1.6e3)\n"
        "    c.C('out', GND, 100e-9)\n"
        "    return c\n"
    )
    req = urllib.request.Request(
        H.BASE + "/api/ccl/run",
        data=json.dumps({"code": code,
                         "analysis": {"kind": "ac", "f_start": 1, "f_stop": 1e5, "points": 50}}).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    d = json.loads(urllib.request.urlopen(req, timeout=120).read())
    is_true(d.get("ok"), f"应能跑通：{d.get('error')}")
    is_true(d.get("spec") is None,
            f"没有需求原文时 spec 必须为 null（手写代码不该被凭空对账），实际 {d.get('spec')}")


@case(group="契约")
def test_live_branch_currents_present():
    """`.op` 分析必须带回每个器件的真实电流（可视化全靠它）。

    「让电路动起来」（LED 按电流发光、电阻按功耗发热）不可能靠估算——
    必须从 ngspice 拿到 @dev[i] / @dev[id]。这条钉住那条数据链。
    """
    import urllib.request

    code = (
        "from ccl import Circuit, GND\n\n"
        "def build():\n"
        "    c = Circuit('led')\n"
        "    c.V('vcc', GND, dc=5, ac=0)\n"
        "    c.R('vcc', 'a', 1000)\n"
        "    c.D('a', GND, 'D1N4148')\n"
        "    return c\n"
    )
    req = urllib.request.Request(
        H.BASE + "/api/ccl/run",
        data=json.dumps({"code": code, "analysis": {"kind": "op"}}).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    d = json.loads(urllib.request.urlopen(req, timeout=120).read())
    is_true(d.get("ok"), f"应能跑通：{d.get('error')}")
    live = d.get("live")
    is_true(live is not None, "工作点分析必须返回 live（器件活数据）")
    items = live.get("items") or {}
    is_true("d1" in items and "r1" in items, f"缺少器件数据：{sorted(items)}")

    # 物理核对：I = (5V - Vd)/1k，二极管压降应在 0.4~0.9V 之间
    i_d = items["d1"]["current"]
    i_r = items["r1"]["current"]
    is_true(i_d and i_r, "应取到二极管与电阻的电流")
    is_true(abs(i_d - i_r) / max(i_r, 1e-12) < 0.01,
            f"串联电路两支路电流应相同：d1={i_d}, r1={i_r}")
    v_d = items["d1"]["voltage"] or 0
    is_true(0.4 < v_d < 0.9, f"二极管正向压降应在 0.4~0.9V，实测 {v_d}")
    is_true(abs(i_r * 1000 - (5 - v_d)) / max(i_r * 1000, 1e-9) < 0.02,
            f"电流应满足 (5−Vd)/1k：实测 {i_r*1000:.3f}mA vs 理论 {(5-v_d):.3f}mA")


@case(group="契约")
def test_ac_analysis_has_no_live():
    """交流分析没有瞬时工作点 → live 必须是 None。

    如果这里返回了数据，界面就会用**频域**结果去显示「发光/发热」，
    那是拿错数据编动画——本项目明确不做这种事。
    """
    import urllib.request

    code = (
        "from ccl import Circuit, GND\n\n"
        "def build():\n"
        "    c = Circuit('rc')\n"
        "    c.V('in', GND, ac=1)\n"
        "    c.R('in', 'out', 1.6e3)\n"
        "    c.C('out', GND, 100e-9)\n"
        "    return c\n"
    )
    req = urllib.request.Request(
        H.BASE + "/api/ccl/run",
        data=json.dumps({"code": code,
                         "analysis": {"kind": "ac", "f_start": 1, "f_stop": 1e5, "points": 50}}).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    d = json.loads(urllib.request.urlopen(req, timeout=120).read())
    is_true(d.get("ok"), f"应能跑通：{d.get('error')}")
    is_true(d.get("live") is None, f"ac 分析不该有 live，实际 {d.get('live')}")


@case(group="契约")
def test_switch_states_reports_state_and_apply_separately():
    """★回归：`switch_states` 返回的必须是**状态**，不是「实现方式」。

    事故现场：后端返回 `{"SW1": "source"}`（说明是用控制源强制的），
    前端却把它当状态读，`'source'` 不匹配 on/off 正则 → 一律判成 false
    → 点了开关，仿真是对的（19mA），灯不亮、开关视觉被重置。

    现在必须分开两个字段：
      switch_states → {"SW1": "on"|"off"}   ← 界面据此渲染
      switch_apply  → {"SW1": "source"|"vt"} ← 仅调试
    """
    import urllib.request

    code = (
        "from ccl import Circuit, GND\n\n"
        "def build():\n"
        "    c = Circuit('sw')\n"
        "    c.V('vcc', GND, dc=5)\n"
        "    c.V('ctl', GND, dc=0)\n"
        "    c.R('vcc', 'a', 220)\n"
        "    c.SW('a', 'k', 'ctl')\n"
        "    c.D('k', GND, 'D1N4148')\n"
        "    c.R('k', GND, 100e3)\n"
        "    return c\n"
    )

    def post(state):
        b = {"code": code, "analysis": {"kind": "op"}, "switch_states": {"SW1": state}}
        req = urllib.request.Request(H.BASE + "/api/ccl/run", data=json.dumps(b).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        return json.loads(urllib.request.urlopen(req, timeout=120).read())

    d_on = post("on")
    is_true(d_on.get("ok"), f"应能跑通：{d_on.get('error')}")
    equal(d_on.get("switch_states"), {"SW1": "on"},
             "switch_states 必须是最终状态 on（不能是实现方式 source）")
    is_true("SW1" in (d_on.get("switch_apply") or {}), "应另有 switch_apply 说明实现方式")

    i_on = ((d_on.get("live") or {}).get("items") or {}).get("d1", {}).get("current") or 0
    is_true(i_on > 0.010, f"开关闭合 LED 应导通，实测 {i_on}")

    d_off = post("off")
    equal(d_off.get("switch_states"), {"SW1": "off"}, "switch_states 必须回 off")
    i_off = ((d_off.get("live") or {}).get("items") or {}).get("d1", {}).get("current") or 0
    is_true(i_off < 1e-6, f"开关断开 LED 应几乎无电流，实测 {i_off}")


@case(group="契约")
def test_led_lights_in_static_snapshot():
    """★回归：静态快照路径（op）也必须点亮 LED 符号。

    `applyLive` 里曾有一行 `if (st.kind === 'light') continue;`，把发光交给
    动画帧的 ledAt()。但工作点分析没有动画帧 → **没人点亮它**：
    实测 19mA 流过 LED，界面却是灰的。静态路径必须自己调用 ledAt()。
    """
    import os
    js = _main_js()
    sch = open(os.path.join(H.ROOT, "web", "ide", "schematic.js"),
               encoding="utf-8").read()
    is_true("function applyLive(" in sch, "schematic.js 应有 applyLive")
    is_true("ledAt(g, st)" in sch,
            "applyLive 在 light 类器件上必须调用 ledAt(g, st)（否则静态快照灯不亮）")
    is_true("if (st.kind === 'light') continue" not in sch,
            "不得再用 'continue' 跳过 light 类器件的点亮")


@case(group="契约")
def test_switch_clickable_without_player():
    """★回归：开关点击不能绑在播放器里（op/dc 分析没有播放条也要能点）。

    事故现场：onSwitchClick 定义在 createPlayer 内部，于是「只有瞬态分析
    （有播放条）时开关才能点」，工作点分析下点开关毫无反应。
    现在必须是独立导出的 wireSwitchClicks，面板在无播放条时也绑定它。
    """
    import os
    sch = open(os.path.join(H.ROOT, "web", "ide", "schematic.js"),
               encoding="utf-8").read()
    pan = open(os.path.join(H.ROOT, "web", "ide", "panels.js"),
               encoding="utf-8").read()
    is_true("export function wireSwitchClicks(" in sch,
            "schematic.js 必须导出独立的 wireSwitchClicks")
    is_true("function onSwitchClick(" not in sch,
            "不应再有绑在 createPlayer 内部的 onSwitchClick")
    is_true("wireSwitchClicks" in pan,
            "panels.js 必须在（没有任何播放条的）分支里也绑定开关点击")


@case(group="契约")
def test_net_current_not_summed_over_branches():
    """★回归：`netCurrentSeries()` 不许把网络内所有支路电流加起来（那是 KCL 残差）。

    事故现场：一条导线的电流按「网络内各支路电流之和」算 —— 正确解里这个和
    恒等于 0（基尔霍夫），于是「电流沿导线流动」这个功能事实上是空的：
    5V/220Ω/LED 电路里支路 19.41mA，网络基准却是 2.84e-7A（纯数值噪声，
    还被归一化成满亮），另两个电路内部网络的峰值正好 0.0 → 一条导线都不流动。

    为什么用文本契约而不是调用 JS：这一层是产品接口测试，不起 node；
    真正的**行为**断言在 `tests_ccl/test_schematic.py`
    （`test_net_current_is_single_branch_not_kcl_sum` 等三条，真的调用 JS 函数）。
    两条一起看才算数：文本证明「写法没退回去」，行为证明「算出来的数对」。
    """
    import os
    sch = open(os.path.join(H.ROOT, "web", "ide", "schematic.js"),
               encoding="utf-8").read()

    is_true("export function netCurrentSeries(" in sch,
            "schematic.js 必须导出 netCurrentSeries")

    # ① 求和写法必须不存在（老实现是 `series[k] += -sgn * v;`）
    for bad in ("series[k] +=", "series[k]+="):
        is_true(bad not in sch,
                f"schematic.js 里仍有「把支路电流累加」的写法 {bad!r} —— "
                "一个网络的电流不是各支路之和（那是 KCL 残差，恒为 0）")

    # ② 必须留下「为什么不能求和」的理由（这条注释是防复发的最后一道闸：
    #    后来者看到它才会知道这不是随手写的怪代码）。
    #    接受几种等价说法，免得改一句措辞就误报 —— 断言的是「理由还在」，
    #    不是「照抄某句话」。
    reasons = ("不能把所有支路电流加起来", "KCL 残差", "基尔霍夫",
               "不是各支路之和", "恒等于 0")
    is_true(any(r in sch for r in reasons),
            "schematic.js 里必须保留「为什么不能把支路电流求和」的说明"
            f"（它是 KCL 残差，不是风格偏好）；这些说法一个都没找到：{reasons}")

    # ③ 必须能找到「取单条支路」的实现：按电流绝对值挑一条
    single = ("取本网络上电流绝对值最大的那条支路", "绝对值最大", "bestAmp",
              "某一条支路", "单条支路")
    is_true(any(m in sch for m in single),
            "schematic.js 里必须能找到「取单条支路」的实现"
            f"（例如按 |I| 挑最大的那条）；这些标记一个都没找到：{single}")


@case(group="契约")
def test_run_require_unmeasurable_is_not_pass():
    """★回归：▶ 运行的需求对账里，「测不到」不能算「达标」。

    这一条改的是界面上最容易被误读的显示：`/api/ccl/run` 的 `spec.passed`。
    非严格版 `check_targets` 把「拿不到 solution / 没有可测节点 / 需求没写输入电压」
    一律返回 `[]`，而调用方把 `[]` 读成"全部达标" → 界面显示「原需求核对：全部达标」。
    实测：「输出 3.3V」（没写输入电压）这种需求根本没法还原绝对电压，
    却会在界面上打勾。
    """
    import urllib.request

    div = (
        "from ccl import Circuit, GND\n\n"
        "def build():\n"
        "    c = Circuit('d')\n"
        "    c.V('in', GND, ac=1)\n"
        "    c.R('in', 'out', 26.4e3)\n"
        "    c.R('out', GND, 10e3)\n"
        "    return c\n"
    )

    def post(require):
        body = {"code": div, "require": require,
                "analysis": {"kind": "ac", "f_start": 1, "f_stop": 1e4, "points": 50}}
        req = urllib.request.Request(H.BASE + "/api/ccl/run", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        return json.loads(urllib.request.urlopen(req, timeout=120).read())

    # 写明了输入电压 → 能核对，且 12V→3.3V 是达标的
    d1 = post("把 12V 分压到 3.3V")
    sp1 = d1.get("spec") or {}
    is_true(d1.get("ok"), f"应能跑通：{d1.get('error')}")
    is_true(sp1.get("passed") is True, f"12V→3.3V 应达标，实际 {sp1.get('text')}")

    # 只写输出值、没写输入电压 → **不能**算达标
    d2 = post("输出 3.3V")
    sp2 = d2.get("spec") or {}
    is_true(sp2.get("passed") is False,
            f"没法对账时不能显示达标，实际 passed={sp2.get('passed')} text={sp2.get('text')}")
