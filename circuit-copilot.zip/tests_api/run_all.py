#!/usr/bin/env python3
"""API 层测试入口。

起一个**独立**的测试服务实例（随机端口，不碰开发用的 3081），
跑完即关。所以可以随时跑，不影响正在用的 IDE。

    python3 tests_api/run_all.py
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import _harness as H                                    # noqa: E402

MODULES = ["test_routes", "test_analysis", "test_config", "test_plugins", "test_ui_contract"]


def main() -> int:
    mods = []
    for name in MODULES:
        try:
            mods.append(__import__(name))
        except Exception as e:
            print(f"✗ 无法导入 {name}：{type(e).__name__}: {e}")
            return 2

    print("· 启动测试服务…")
    try:
        base = H.start_server()
    except Exception as e:
        print(f"✗ {e}")
        return 2
    print(f"· 服务就绪：{base}")

    try:
        return H.run(mods)
    finally:
        H.stop_server()
        print("· 测试服务已停止")


if __name__ == "__main__":
    sys.exit(main())
