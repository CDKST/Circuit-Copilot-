"""分析接口：四种分析 + 错误路径。

这一组防的是**"UI 上某个按钮点了没反应/报错"**——全部是过去真实出过的问题：
- dc 分支曾因 `dc_sweep` 未导入而直接 ImportError
- dc 的 sweepVar 没传给前端，十字线读数退化成 `x=3.2V`
- 报错时 line 字段缺失导致不能自动跳行
"""

from __future__ import annotations

from _harness import (case, post_json, is_true, equal, close, contains,
                      RC_LOWPASS, DIVIDER, BROKEN)


def _run(code, analysis):
    return post_json("/api/ccl/run", {"code": code, "analysis": analysis}, timeout=90)


@case(group="分析接口")
def test_ac_lowpass_metrics():
    """AC 分析：RC 低通 1.6k/100n，理论 fc = 1/(2πRC) = 994.7Hz。"""
    st, d = _run(RC_LOWPASS, {"kind": "ac", "f_start": 1, "f_stop": 1e6, "points": 120})
    equal(st, 200, "HTTP 状态")
    is_true(d.get("ok"), f"运行失败：{d.get('error')}")
    a = d["analysis"]
    equal(a["kind"], "ac", "分析类型")
    traces = a["traces"]
    is_true("out" in traces, f"缺少 out 曲线；实际有 {list(traces)}")
    is_true(len(traces["out"]["x"]) > 50, "扫描点数过少")
    # 理论 fc
    close(1 / (2 * 3.141592653589793 * 1.6e3 * 100e-9), 994.7, 0.001, "理论 fc")
    m = a.get("metrics") or {}
    is_true("f3db" in m and m["f3db"] is not None,
            f"缺少 f3db 指标；metrics={m}")
    close(m["f3db"], 994.7, 0.05, "实测 f3db")


@case(group="分析接口")
def test_op_returns_node_voltages():
    """工作点：分压 10V → 5V，逐点核对而不是"跑通了就算"。"""
    code = DIVIDER.replace("dc=0", "dc=10")
    st, d = _run(code, {"kind": "op"})
    is_true(d.get("ok"), f"运行失败：{d.get('error')}")
    a = d["analysis"]
    equal(a["kind"], "op", "分析类型")
    op = a.get("op") or {}
    is_true("out" in op, f"工作点缺少 out；实际 keys={list(op)}")
    close(op["out"], 5.0, 0.01, "分压输出")


@case(group="分析接口")
def test_tran_returns_metrics():
    """瞬态：RC 阶跃 rise_time 应 ≈ 2.197τ；测不到时必须给 null 而不是编数。"""
    code = """from ccl import Circuit, GND

def build():
    c = Circuit("rc_step")
    c.PULSE("in", GND, v1=0, v2=5, pw=50e-3, per=100e-3)
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)
    return c
"""
    st, d = _run(code, {"kind": "tran", "t_step": 1e-6, "t_stop": 5e-3})
    is_true(d.get("ok"), f"运行失败：{d.get('error')}")
    m = d["analysis"].get("metrics") or {}
    is_true("rise_time" in m, f"缺少 rise_time；metrics={list(m)}")
    close(m["rise_time"], 219.7e-6, 0.05, "rise_time（2.197τ）")
    # 没有下降沿时必须是 None，不能是 0 或编造值
    is_true(m.get("fall_time") is None,
            f"只有上升沿却给了 fall_time={m.get('fall_time')}，应判测不到")


@case(group="分析接口")
def test_dc_divider_linear():
    """直流扫描：分压器扫 0→10V 应得 11 点，且每点 Vout=Vin/2。"""
    st, d = _run(DIVIDER, {"kind": "dc", "source": "V1",
                           "dc_start": 0, "dc_stop": 10, "dc_step": 1})
    is_true(d.get("ok"), f"运行失败：{d.get('error')}")
    a = d["analysis"]
    equal(a["kind"], "dc", "分析类型")
    # sweepVar 必须传出去，否则前端十字线读数显示 x=3.2V 而不是 V1=3.2V
    equal(a.get("sweepVar"), "V1", "sweepVar 透传")
    t = a["traces"].get("out")
    is_true(t is not None, f"缺少 out 曲线；实际 {list(a['traces'])}")
    equal(len(t["x"]), 11, "扫描点数")
    for x, y in zip(t["x"], t["y"]):
        close(y, x * 0.5, 0.01, f"Vout@Vin={x}")


@case(group="分析接口")
def test_dc_two_dim_curves():
    """直流扫描第二维：3 段 × 6 点。切段错了会画成一条乱折线且**不报错**。"""
    code = """from ccl import Circuit, GND

def build():
    c = Circuit("summing")
    c.V("x", GND, dc=0)
    c.I("y", GND, dc=0)
    c.R("x", "o", 1e3)
    c.R("y", "o", 1e3)
    return c
"""
    st, d = _run(code, {"kind": "dc", "source": "V1",
                        "dc_start": 0, "dc_stop": 5, "dc_step": 1,
                        "second_source": "I1",
                        "second_start": 0, "second_stop": 1e-3, "second_step": 0.5e-3})
    is_true(d.get("ok"), f"运行失败：{d.get('error')}")
    traces = d["analysis"]["traces"]
    # 有第二维时，同一节点会拆成多条（key 里带 label）
    multi = {k: v for k, v in traces.items() if "@" in k}
    is_true(len(multi) >= 3, f"两维扫描应至少 3 条曲线，实测 {len(multi)}：{list(traces)}")
    for k, v in list(multi.items())[:3]:
        equal(len(v["x"]), 6, f"曲线 {k} 的点数")


@case(group="分析接口")
def test_error_reports_line_number():
    """报错必须带行号 —— 前端靠它自动跳到出错行。没有行号用户要自己找。"""
    st, d = _run(BROKEN, {"kind": "ac"})
    equal(st, 200, "HTTP 状态（业务错误也应是 200 + ok:false）")
    is_true(not d.get("ok"), "坏代码竟然运行成功了")
    is_true(bool(d.get("error")), "缺少 error 字段")
    is_true(isinstance(d.get("line"), int) and d["line"] > 0,
            f"缺少行号（line={d.get('line')!r}），前端无法自动跳转")
    contains(str(d["error"]), "undefined_name", "错误信息应指出出错的名字")


@case(group="分析接口")
def test_empty_code_rejected():
    """空代码要明确拒绝，不要 500 也不要假装成功。"""
    st, d = _run("   ", {"kind": "ac"})
    is_true(st == 400 or not d.get("ok"),
            f"空代码应被拒（status={st}, ok={d.get('ok')}）")


@case(group="分析接口")
def test_tran_serialization_is_not_quadratic():
    """性能护栏：瞬态序列化不能是 O(n²)。

    真实事故：`run_analysis` 曾用 `[sol.value_at(n, t) for t in xs]` 逐点取值，
    而 value_at 每次都在整条波形上插值（O(n)），于是整体变成 O(n²)。
    5023 点 × 3 条波形 = 15069 次 value_at ≈ **21 秒**，
    而仿真本身只要 0.16 秒。界面上每跑一次瞬态就要干等半分钟。

    直接取 `wave.real()` 是毫秒级。这条用例钉住这个量级差异。
    """
    import time
    code = """from ccl import Circuit, GND

def build():
    c = Circuit("rc_perf")
    c.PULSE("in", GND, v1=0, v2=5, pw=50e-3, per=100e-3)
    c.R("in", "out", 1e3)
    c.C("out", GND, 100e-9)
    return c
"""
    t0 = time.time()
    st, d = _run(code, {"kind": "tran", "t_step": 1e-6, "t_stop": 5e-3})
    dt = time.time() - t0
    is_true(d.get("ok"), f"运行失败：{d.get('error')}")
    # 5000 点级别的瞬态，正常应在 1 秒内（含 HTTP 往返）；
    # 给 8 秒上限，既容得下慢设备，也能立刻抓出 O(n²) 回归（那要 20 秒以上）
    is_true(dt < 8.0,
            f"瞬态接口耗时 {dt:.1f}s，超过 8s 上限——序列化可能又变成 O(n²) 了")
    # 波形点数是降采样后的，不能因为快了就丢数据
    tr = d["analysis"]["traces"]
    is_true(len(tr) >= 2, f"波形条数过少：{list(tr)}")
    for k, v in tr.items():
        is_true(len(v["x"]) == len(v["y"]), f"波形 {k} 的 x/y 长度不一致")
        is_true(len(v["x"]) >= 100, f"波形 {k} 只有 {len(v['x'])} 点，降采样过头")
