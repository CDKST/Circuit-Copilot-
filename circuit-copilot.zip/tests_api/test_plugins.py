"""插件系统接口。

防两类问题：
1. **插件写坏拖垮主程序** —— 每个插件的加载必须隔离
2. **路径穿越** —— `/plugins/<id>/../../server.py` 不能读到后端源码
"""

from __future__ import annotations

import json
import os
import sys

from _harness import case, get, get_json, post_json, is_true, equal, contains


@case(group="插件")
def test_plugins_list_shape():
    """清单字段是前端渲染的依据，缺一个就显示不正常。"""
    st, d = get_json("/api/plugins")
    equal(st, 200, "HTTP 状态")
    is_true(d.get("ok"), f"清单读取失败：{d.get('error')}")
    ps = d.get("plugins")
    is_true(isinstance(ps, list), "plugins 应是数组")
    is_true(len(ps) >= 1, "至少要能发现自己带示例插件 common-values")
    for p in ps:
        for k in ("id", "name", "version", "hasUI", "ok", "backend"):
            is_true(k in p, f"插件 {p.get('id')} 缺少字段 {k}")
        is_true(bool(p["id"]), "插件 id 不能为空")


@case(group="插件")
def test_plugin_ui_asset_served():
    """带 UI 的插件，它的 ui.js 必须能被浏览器 import 到。"""
    st, d = get_json("/api/plugins")
    withui = [p for p in d.get("plugins") or [] if p.get("hasUI") and p.get("ok")]
    if not withui:
        return
    p = withui[0]
    st2, body, hdrs = get(f"/plugins/{p['id']}/{p['uiFile']}")
    equal(st2, 200, f"{p['id']} 的 ui.js HTTP 状态")
    is_true(len(body) > 50, "ui.js 内容过短")
    ct = (hdrs.get("Content-Type") or "").lower()
    contains(ct, "javascript", "Content-Type 必须是 JS，否则浏览器拒绝 import")
    js = body.decode("utf-8", "replace")
    contains(js, "activate", "ui.js 必须导出 activate")


@case(group="插件")
def test_plugin_asset_traversal_blocked():
    """插件静态服务必须挡住 ../，否则能读到整个项目源码。"""
    for evil in (
        "/plugins/common-values/../../server.py",
        "/plugins/../../etc/passwd",
        "/plugins/common-values/..%2f..%2fserver.py",
    ):
        st, body, _ = get(evil)
        txt = body.decode("utf-8", "replace")
        leaked = ("import " in txt[:300] and "def " in txt[:800]) or "root:" in txt
        is_true(st != 200 or not leaked, f"{evil} 竟然读到了内容（status={st}）")


@case(group="插件")
def test_install_rejects_bad_id():
    """安装接口的 id 校验必须在服务端，不能只靠前端拦。"""
    for bad in ("Bad_ID", "../evil", "", "a" * 40, "has space"):
        st, d = post_json("/api/plugin/install", {
            "id": bad,
            "plugin_json": json.dumps({"id": bad}),
            "backend_py": "def register(api):\n    pass\n",
        })
        is_true(not d.get("ok"), f"非法 id {bad!r} 竟然安装成功了：{d}")


@case(group="插件")
def test_install_rejects_syntax_error():
    """backend.py 语法错必须在写入前被拒，不能装上一个坏插件。"""
    st, d = post_json("/api/plugin/install", {
        "id": "syntax-test",
        "plugin_json": json.dumps({"id": "syntax-test"}),
        "backend_py": "def register(api)\n    pass\n",     # 故意少冒号
    })
    is_true(not d.get("ok"), f"语法错的插件竟然装上了：{d}")
    contains(str(d.get("error")), "语法", "错误信息应指出是语法问题")


@case(group="插件")
def test_install_refuses_overwrite():
    """已存在的插件目录不许被静默覆盖——用户改过的代码不能被冲掉。"""
    st, d = post_json("/api/plugin/install", {
        "id": "common-values",
        "plugin_json": json.dumps({"id": "common-values"}),
        "backend_py": "def register(api):\n    pass\n",
    })
    is_true(not d.get("ok"), f"竟然覆盖了已有插件：{d}")
    contains(str(d.get("error")), "已存在", "错误信息应说明目录已存在")
    # 原插件必须还在
    st2, body, _ = get("/plugins/common-values/backend.py")
    equal(st2, 200, "原插件 backend.py 应仍然存在")
