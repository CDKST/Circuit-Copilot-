"""AI 配置接口。

重点防一件事：**API Key 明文泄露**。
配置接口把 key 写到磁盘，如果 GET 也把 key 原样吐回来，
任何能访问这个端口的东西（同 WiFi 的另一个 App、误开的网页）
都能拿到 Key。所以这条必须有测试盯着。
"""

from __future__ import annotations

import json
import os
import sys

from _harness import case, get_json, post_json, is_true, equal, contains

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _disk_key() -> str:
    """读磁盘上的真实 key，用于验证接口没把它漏出去。"""
    try:
        sys.path.insert(0, ROOT)
        from copilot.llm import load_config
        cfg = load_config()
        return cfg.get("key") or ""
    except Exception:
        # 退化成直接读文件
        try:
            p = os.path.expanduser("~/.cc/config.json")
            with open(p) as f:
                return json.load(f).get("key") or ""
        except Exception:
            return ""


@case(group="AI 配置")
def test_get_config_shape():
    """GET 必须给 base / model / hasKey / keyMasked 四个字段。"""
    st, d = get_json("/api/config")
    equal(st, 200, "HTTP 状态")
    is_true(d.get("ok"), f"读取失败：{d.get('error')}")
    for k in ("base", "model", "hasKey", "keyMasked"):
        is_true(k in d, f"缺少字段 {k}；实际 keys={list(d.keys())}")


@case(group="AI 配置")
def test_key_never_leaks_plaintext():
    """**关键**：接口返回的任何字段里都不能含完整 Key。"""
    real = _disk_key()
    if not real or len(real) < 12:
        return                                     # 没配 key 就没有泄露风险
    st, d = get_json("/api/config")
    blob = json.dumps(d, ensure_ascii=False)
    is_true(real not in blob,
            "接口返回值里出现了完整的 API Key 明文！这是严重问题")
    # 掩码应是 前6…后4 的形式，且中段被隐藏
    masked = d.get("keyMasked") or ""
    is_true("…" in masked or "*" in masked or "已配置" in masked,
            f"keyMasked 看起来没有做掩码：{masked!r}")
    is_true(len(masked) < len(real), f"掩码长度 {len(masked)} 不短于原文 {len(real)}")


@case(group="AI 配置")
def test_config_post_reflects_in_get():
    """POST 保存后，GET 必须能读到新值（同 base/model）。"""
    st, before = get_json("/api/config")
    old_base = before.get("base") or ""
    old_model = before.get("model") or ""
    if not old_base:
        return                                     # 环境没有配置，跳过语义测试

    # 传相同值：不该破坏现有配置
    st2, d2 = post_json("/api/config", {"base": old_base, "model": old_model, "key": ""})
    is_true(st2 in (200, 500), f"意外的 HTTP 状态 {st2}")
    if d2.get("ok"):
        st3, after = get_json("/api/config")
        equal(after.get("base"), old_base, "base 应保持")
        equal(after.get("model"), old_model, "model 应保持")


@case(group="AI 配置")
def test_empty_key_does_not_erase_existing():
    """留空 Key 表示"不修改"，不能把已配置的 Key 抹掉。"""
    st, before = get_json("/api/config")
    if not before.get("hasKey"):
        return
    masked_before = before.get("keyMasked")
    post_json("/api/config", {"key": ""})          # 留空保存
    st2, after = get_json("/api/config")
    is_true(after.get("hasKey"),
            "留空保存后 Key 丢了——用户只是改个模型名就会把 Key 抹掉，这是严重缺陷")
    equal(after.get("keyMasked"), masked_before, "Key 应保持不变")
