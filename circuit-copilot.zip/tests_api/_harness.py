"""API 层测试脚手架。

与 `tests_ccl/` 的区别：那边测的是**库**（直接 import ccl），
这边测的是**产品**（走真实 HTTP，和浏览器/手机看到的完全一样）。

为什么需要这一层：177 个库测试全绿，但 API 层出过不止一次问题——
dc 分支 ImportError、sweepVar 没传给前端、`/api/config` 只有 POST 没有 GET。
这些都是**手动 curl 发现的，不是测试发现的**。UI 全靠这一层，它必须有护栏。

用法：
    python3 tests_api/run_all.py
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = ""          # 由 run_all.py 在启动服务后填入，如 http://127.0.0.1:3099
SERVER = None

_RESULTS: list[dict] = []


# ---------------------------------------------------------------------------
# 用例注册
# ---------------------------------------------------------------------------

def case(group: str):
    def deco(fn):
        fn._case = True
        fn._group = group
        return fn
    return deco


def is_true(cond, msg=""):
    if not cond:
        raise AssertionError(msg or "断言失败")


def equal(got, want, what=""):
    if got != want:
        raise AssertionError(f"{what}: 期望 {want!r}，实测 {got!r}")


def close(got, want, tol, what=""):
    """相对误差比较。tol 是相对值（0.05 = 5%）。"""
    is_true(isinstance(got, (int, float)),
            f"{what}: 期望数字，实测 {type(got).__name__} {got!r}")
    if want == 0:
        is_true(abs(got) <= tol, f"{what}: 期望 ≈0，实测 {got}")
        return
    rel = abs(got - want) / abs(want)
    is_true(rel <= tol, f"{what}: 期望 {want}，实测 {got}（相对误差 {rel*100:.2f}% > {tol*100:.1f}%）")


def contains(hay, needle, what=""):
    is_true(needle in hay, f"{what}: 输出里找不到 {needle!r}；实际前 200 字符：{str(hay)[:200]}")


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def get(path: str, timeout: int = 30):
    """返回 (status, body_bytes, headers)。不跟随重定向之外的处理。"""
    url = path if path.startswith("http") else BASE + path
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers or {})


def get_json(path: str, timeout: int = 30):
    st, body, _ = get(path, timeout)
    try:
        return st, json.loads(body.decode("utf-8"))
    except Exception:
        return st, {"_raw": body.decode("utf-8", "replace")[:400]}


def post_json(path: str, payload: dict, timeout: int = 120):
    data = json.dumps(payload).encode()
    req = urllib.request.Request(BASE + path, data=data,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode())
        except Exception:
            return e.code, {"_raw": "非 JSON 错误响应"}


# ---------------------------------------------------------------------------
# 常用电路源码
# ---------------------------------------------------------------------------

RC_LOWPASS = """from ccl import Circuit, GND

def build():
    c = Circuit("rc_lowpass")
    c.V("in", GND, ac=1)
    c.R("in", "out", 1.6e3)
    c.C("out", GND, 100e-9)
    return c
"""

DIVIDER = """from ccl import Circuit, GND

def build():
    c = Circuit("divider")
    c.V("in", GND, dc=0)
    c.R("in", "out", 1e3)
    c.R("out", GND, 1e3)
    return c
"""

BROKEN = """from ccl import Circuit, GND

def build():
    c = Circuit("broken")
    c.V("in", GND, ac=1)
    c.R("in", "out", undefined_name)
    return c
"""


# ---------------------------------------------------------------------------
# 服务生命周期
# ---------------------------------------------------------------------------

def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def start_server() -> str:
    """起一个**独立的**测试服务实例（不和开发用的 3081 冲突）。"""
    global SERVER, BASE
    port = _free_port()
    log = os.path.join(ROOT, "out", "test-server.log")
    os.makedirs(os.path.dirname(log), exist_ok=True)
    f = open(log, "w")
    SERVER = subprocess.Popen(
        [sys.executable, os.path.join(ROOT, "web", "server.py"), str(port)],
        cwd=ROOT, stdout=f, stderr=subprocess.STDOUT,
    )
    BASE = f"http://127.0.0.1:{port}"
    # 最多等 25 秒
    for _ in range(250):
        try:
            st, _b, _h = get("/api/health", timeout=2)
            if st == 200:
                return BASE
        except Exception:
            pass
        if SERVER.poll() is not None:
            raise RuntimeError(f"测试服务启动即退出，看日志：{log}\n"
                               + open(log).read()[-1500:])
        time.sleep(0.1)
    raise RuntimeError(f"测试服务 25 秒内未就绪，看日志：{log}")


def stop_server():
    global SERVER
    if SERVER and SERVER.poll() is None:
        SERVER.terminate()
        try:
            SERVER.wait(timeout=6)
        except subprocess.TimeoutExpired:
            SERVER.kill()


# ---------------------------------------------------------------------------
# 执行
# ---------------------------------------------------------------------------

def run(modules: list) -> int:
    t0 = time.time()
    for m in modules:
        for name in sorted(dir(m)):
            fn = getattr(m, name)
            if not (callable(fn) and getattr(fn, "_case", False)):
                continue
            group = getattr(fn, "_group", "")
            s = time.time()
            try:
                fn()
                _RESULT(group, fn.__name__, "ok", (time.time() - s) * 1000, "")
            except AssertionError as e:
                _RESULT(group, fn.__name__, "fail", (time.time() - s) * 1000, str(e))
            except Exception as e:
                _RESULT(group, fn.__name__, "error", (time.time() - s) * 1000,
                        f"{type(e).__name__}: {e}\n" + traceback.format_exc()[-600:])

    ok = sum(1 for r in _RESULTS if r["state"] == "ok")
    bad = len(_RESULTS) - ok

    last = None
    for r in _RESULTS:
        if r["group"] != last:
            print(f"\n── {r['group']} " + "─" * max(4, 56 - len(r["group"])))
            last = r["group"]
        mark = "✅" if r["state"] == "ok" else "❌"
        print(f"  {mark} {r['name']:<48s} {r['ms']:>6.0f}ms")
        if r["state"] != "ok":
            for line in str(r["detail"]).splitlines()[:6]:
                print(f"       {line}")

    print("\n" + "=" * 74)
    print(f"  API 测试汇总：共 {len(_RESULTS)} 项 · 通过 {ok} · 失败 {bad}"
          f" · 耗时 {time.time() - t0:.1f}s")
    print("=" * 74)
    return 0 if bad == 0 else 1


def _RESULT(group, name, state, ms, detail):
    _RESULTS.append({"group": group, "name": name, "state": state,
                     "ms": ms, "detail": detail})
