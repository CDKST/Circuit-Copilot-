"""基础路由：健康检查、目录、静态资源、404。

这一组防的是"页面白屏"类问题：任何一条 GET 返回非 200 或结构变了，
IDE 初始化就会静默失败（前端全是 .catch(() => ({})) 兜底，白屏不报错）。
"""

from __future__ import annotations

from _harness import case, get, get_json, is_true, equal, contains


@case(group="基础路由")
def test_health_shape():
    """健康检查必须有 ngspice 版本与 llm 配置状态——前端启动画面靠它显示引擎。"""
    st, d = get_json("/api/health")
    equal(st, 200, "HTTP 状态")
    for k in ("ngspice", "topologies", "llm_configured", "llm_base", "llm_model"):
        is_true(k in d, f"健康检查缺少字段 {k}；实际 keys={list(d.keys())}")
    is_true(str(d["ngspice"]).strip() != "", "ngspice 版本为空——说明后端没找到仿真器")
    is_true(isinstance(d["topologies"], int) and d["topologies"] > 0,
            f"拓扑数量应为正整数，实测 {d['topologies']!r}")


@case(group="基础路由")
def test_examples_are_runnable():
    """示例列表里每个都自带 code —— 点一下就开标签页，没有 code 就是死链。"""
    st, d = get_json("/api/ccl/example")
    equal(st, 200, "HTTP 状态")
    ex = d.get("examples") or []
    is_true(len(ex) >= 5, f"示例应有至少 5 个，实测 {len(ex)}")
    for e in ex:
        is_true(bool((e.get("title") or "").strip()), f"有示例缺 title：{e.get('id')}")
        is_true(bool((e.get("code") or "").strip()), f"示例 {e.get('title')} 没有 code")
        contains(e["code"], "def build", f"示例 {e.get('title')} 的代码不像 CCL 电路")


@case(group="基础路由")
def test_blocks_list():
    """子电路库列表：前端侧栏「🧩 子电路库」全靠它。"""
    st, d = get_json("/api/ccl/blocks")
    equal(st, 200, "HTTP 状态")
    bl = d.get("blocks") or []
    is_true(len(bl) >= 5, f"子电路块应有至少 5 个，实测 {len(bl)}")
    names = [b.get("name") for b in bl]
    is_true(all(names), f"有块缺 name：{bl[:2]}")


@case(group="基础路由")
def test_ide_html_served():
    """IDE 主页面必须能 serving，且入口脚本与样式都在。"""
    st, body, _ = get("/ide")
    equal(st, 200, "HTTP 状态")
    html = body.decode("utf-8", "replace")
    # index.html 只引用入口；其余模块由 main.js 的 import 链加载（见下一个用例）
    for must in ("main.js", "style.css"):
        contains(html, must, "index.html 应引用 " + must)
    contains(html, "type=\"module\"", "入口脚本必须是 ES module")


@case(group="基础路由")
def test_es_module_graph_resolves():
    """顺着 main.js 的 import 链逐个取模块。

    一个路径写错（少个 s、大小写不对）不会报"模块缺失"，
    只会让整个 IDE 白屏——前端全是 try/catch 兜底，连报错都看不见。
    """
    import re
    seen, queue = set(), ["main.js"]
    while queue:
        name = queue.pop(0)
        if name in seen:
            continue
        seen.add(name)
        st, body, _ = get("/ide/" + name)
        equal(st, 200, f"模块 {name} 取不到 HTTP 状态（import 链断了）")
        src = body.decode("utf-8", "replace")
        for m in re.finditer(r"""from\s+['"]\./([\w.-]+\.js)['"]""", src):
            dep = m.group(1)
            if dep not in seen:
                queue.append(dep)
    # 至少要覆盖到这几个核心模块，否则说明 import 解析规则失效了
    for core in ("main.js", "editor.js", "panels.js", "schematic.js", "plugins.js", "boot.js"):
        is_true(core in seen, f"{core} 不在 import 链里（正则可能失效，需人工确认）")


@case(group="基础路由")
def test_ide_static_assets():
    """所有前端模块都要能取到，且 MIME 是 JS（否则浏览器拒绝执行 ES module）。"""
    for name in ("editor.js", "panels.js", "main.js", "schematic.js",
                 "plugins.js", "boot.js", "commands.js", "snippets.js"):
        st, body, hdrs = get("/ide/" + name)
        equal(st, 200, f"{name} HTTP 状态")
        is_true(len(body) > 500, f"{name} 内容过短（{len(body)} 字节）")
        ct = (hdrs.get("Content-Type") or "").lower()
        contains(ct, "javascript", f"{name} 的 Content-Type")


@case(group="基础路由")
def test_static_traversal_blocked():
    """路径穿越必须被挡——`/ide/../server.py` 不能把后端源码吐出来。"""
    for evil in ("/ide/../server.py", "/ide/..%2fserver.py", "/ide/../ccl/core.py"):
        st, body, _ = get(evil)
        txt = body.decode("utf-8", "replace")
        is_true(st != 200 or "import" not in txt.lower()[:200],
                f"{evil} 竟然返回了源码（status={st}）")


@case(group="基础路由")
def test_unknown_route_404():
    """不存在的路由要 404 且返回 JSON，不要挂起或返回 HTML。"""
    st, d = get_json("/api/definitely-not-here")
    equal(st, 404, "HTTP 状态")
