#!/usr/bin/env python3
"""Circuit Copilot · AI 电路设计副驾

用法：
    python3 main.py "做一个 1kHz 的 RC 低通滤波器"     # 命令行设计
    python3 main.py --serve                            # 启动 Web 界面
    python3 main.py --key sk-xxxx                      # 配置大模型 Key
    python3 main.py --catalog                          # 查看支持的拓扑
    python3 main.py --check                            # 环境自检
"""

from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from copilot import agent, llm, report, topologies as T  # noqa: E402


def cmd_design(text: str, json_out: bool = False):
    s = agent.run(text)
    if json_out:
        print(json.dumps({
            "topology": s.topology, "passed": s.passed, "error": s.error,
            "sims": s.total_sims, "ms": round(s.total_ms),
            "spec": [{"k": r.key, "target": r.target, "actual": r.actual, "ok": r.ok} for r in s.rows],
        }, ensure_ascii=False, indent=2))
    else:
        print(report.markdown(s))


def main(argv: list[str]) -> int:
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0

    if argv[0] == "--serve":
        from web.server import main as serve
        serve(int(argv[1]) if len(argv) > 1 else 3081)
        return 0

    if argv[0] == "--key":
        if len(argv) < 2:
            print("用法: --key sk-xxxx [--base URL] [--model NAME]")
            return 1
        kw = {"key": argv[1]}
        if "--base" in argv:
            kw["base"] = argv[argv.index("--base") + 1]
        if "--model" in argv:
            kw["model"] = argv[argv.index("--model") + 1]
        p = llm.save_config(**kw)
        print(f"已写入 {p}（权限 600）")
        print("自检：", agent.diagnose())
        return 0

    if argv[0] == "--catalog":
        for t in T.catalog():
            print(f"\n▸ {t['name']}  ({t['id']})")
            print(f"  {t['summary']}")
            print(f"  参数: {', '.join(p['name'] for p in t['params'])}")
            print(f"  指标: {', '.join(m['label'] for m in t['metrics'])}")
        return 0

    if argv[0] == "--check":
        print(json.dumps(agent.diagnose(), ensure_ascii=False, indent=2))
        return 0

    text = " ".join(a for a in argv if not a.startswith("--"))
    cmd_design(text, json_out="--json" in argv)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
