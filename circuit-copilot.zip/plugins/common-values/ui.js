/* 示例插件：常用元件值检查（前端贡献）。
 *
 * 演示怎么往 IDE 里加一个侧栏面板。宿主会调用 `activate(api)`，
 * api 只有这几个方法 —— 插件碰不到主程序内部状态：
 *   api.registerSidebarPanel({id, icon, title, render(box)})
 *   api.registerCommand({id, label, hint, run()})
 *   api.log(msg)
 *   api.version / api.pluginId
 */

const E24 = [1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
             3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1];
const E12 = [1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2];

const DECADES = [
  ['', 1],
  ['k', 1e3],
  ['M', 1e6],
];

function fmt(v) {
  for (const [u, s] of [['M', 1e6], ['k', 1e3], ['', 1],
                        ['m', 1e-3], ['µ', 1e-6], ['n', 1e-9], ['p', 1e-12]]) {
    if (Math.abs(v) >= s) return (v / s).toPrecision(4).replace(/\.?0+$/, '') + u;
  }
  return String(v);
}

function seriesTable(name, base, unit) {
  const rows = DECADES.map(([suffix, scale]) => {
    const cells = base.map(b => {
      const v = b * scale;
      return `<td style="padding:1px 3px;color:var(--fg)">${fmt(v)}</td>`;
    }).join('');
    return `<tr><td style="color:var(--fg-dim);padding-right:4px">${suffix || '1'}</td>${cells}</tr>`;
  }).join('');
  return `<div style="margin-top:8px">
    <div style="color:var(--accent-2);font-size:12px;margin-bottom:4px">${name}（${base.length} 档）</div>
    <table style="font-size:10px;border-collapse:collapse;line-height:1.5">${rows}</table>
  </div>`;
}

export function activate(api) {
  api.registerSidebarPanel({
    id: 'plugin-common-values',
    icon: '🔢',
    title: '标准元件值',
    render(box) {
      box.innerHTML = `
        <div style="padding:8px;overflow:auto">
          <div class="sb-sub" style="line-height:1.6">
            设计算出的阻容值大多买不到。这个面板列出标准档位，
            同时<b>插件已在检查里注册了一条规则</b>：运行后若某元件值偏离最近档位
            超过 2%，会在「问题」里给出最接近的可采购值。
          </div>
          ${seriesTable('E24 · 电阻 ±5%', E24, 'Ω')}
          ${seriesTable('E12 · 电容', E12, 'F')}
          <div class="sb-sub" style="margin-top:10px;line-height:1.6">
            来源：<code>plugins/common-values/</code> —— 删掉这个目录，
            规则和面板会一起消失，主程序不受影响。
          </div>
        </div>`;
    },
  });

  api.log('已注册侧栏面板：标准元件值');
}
