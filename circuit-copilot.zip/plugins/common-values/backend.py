"""示例插件：常用元件值检查（后端贡献）。

演示三件事：
1. 怎么往 lint 里加一条**纯静态**检查规则
2. 怎么保证插件自己出错不拖垮主程序（loader 已经 try/except 了）
3. 怎么用 `instance.log()` 给用户看插件做了什么

规则本身是真实有用的：设计师经常算出一个 1.234kΩ，
但实际只能买到 E24 档位里的 1.2k / 1.3k；这个检查会提前提示。
"""

from __future__ import annotations

from ccl.lint import Issue

# E24（±5% 电阻常用）与 E12（电容常用，电容档位更粗）
E24 = [1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
       3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1]
E12 = [1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2]

# 判定容差：落在这个相对误差内就算「买得到」
TOL_STANDARD = 0.02


def _decade_normalize(v: float) -> tuple[float, int]:
    """把任意量级归一化到 [1,10)，返回 (归一化值, 十进制指数)。"""
    if v <= 0:
        return 0.0, 0
    e = 0
    x = v
    while x >= 10:
        x /= 10.0
        e += 1
    while x < 1:
        x *= 10.0
        e -= 1
    return x, e


def _nearest(v: float, series: list[float]) -> float:
    x, e = _decade_normalize(v)
    if x == 0:
        return 0.0
    best = min(series, key=lambda s: abs(s - x))
    return best * (10.0 ** e)


def _fmt(v: float) -> str:
    for unit, scale in (("k", 1e3), ("M", 1e6), ("", 1.0),
                        ("m", 1e-3), ("µ", 1e-6), ("n", 1e-9), ("p", 1e-12)):
        if abs(v) >= scale:
            return f"{v / scale:.4g}{unit}"
    return f"{v:.4g}"


def check_common_values(circuit) -> list[Issue]:
    """R 对照 E24、C 对照 E12；偏得离谱就提醒换成最近的档位。"""
    out: list[Issue] = []
    for c in getattr(circuit, "components", []):
        kind = (getattr(c, "kind", "") or "").upper()
        if kind not in ("R", "C"):
            continue
        try:
            val = float(getattr(c, "value", 0) or 0)
        except (TypeError, ValueError):
            continue
        if val <= 0:
            continue

        series = E24 if kind == "R" else E12
        near = _nearest(val, series)
        if near <= 0:
            continue
        rel = abs(val - near) / near
        if rel <= TOL_STANDARD:
            continue

        name = "电阻" if kind == "R" else "电容"
        out.append(Issue(
            "info",
            f"{c.ref} 的{name}值 {_fmt(val)} 不在标准档位附近",
            f"最接近的{'E24' if kind == 'R' else 'E12'}档位是 {_fmt(near)}"
            f"（差 {rel * 100:.1f}%）。实际采购建议取 {_fmt(near)}；"
            f"若电路对该值敏感，应改用它并重新核对指标。",
            c.ref,
            "plugin.common_values",
        ))
    return out


def register(api):
    api.register_lint_rule(check_common_values)
    api.log("已注册：元件值标准档位检查（R→E24 / C→E12）")
