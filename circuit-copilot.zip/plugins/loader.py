"""插件加载器（后端）。

插件就是一个目录：`plugins/<id>/`，里面有
    plugin.json     必需。清单文件
    backend.py      可选。后端贡献（新检查规则 / 新子电路块）
    ui.js           可选。前端贡献（新面板 / 新命令），由浏览器加载

## 设计原则（和项目其他部分一致）

1. **插件写坏不许拖垮主程序。** 每个插件的激活都在 try/except 里，
   失败只记录到这个插件的 status，主程序照常跑。
2. **清单先校验再加载。** id 必须是 `[a-z0-9-]`，防止路径穿越。
3. **后端插件是可信代码。** Python 在同进程 import，没有任何沙箱。
   这一点在 README 里明确写出来，不假装安全。
"""

from __future__ import annotations

import importlib.util
import json
import os
import re
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PLUGIN_DIR = HERE

ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")

# 加载结果：id -> dict(name, version, description, hasUI, uiFile, backend, error)
REGISTRY: dict[str, dict] = {}
_ACTIVATED = False


class PluginAPI:
    """给后端插件的受限接口。

    只暴露这三个方法 —— 插件拿不到 Circuit 内部结构，也不能改主程序行为，
    只能"追加"能力。
    """

    def __init__(self, pid: str):
        self.id = pid
        self._log: list[str] = []

    def register_lint_rule(self, fn, *, solution: bool = False) -> None:
        """注册一条检查规则。

        - `solution=False`：`fn(circuit) -> list[Issue]`，纯静态检查
        - `solution=True` ：`fn(circuit, solution) -> list[Issue]`，可用工作点

        Issue 用 `ccl.lint.Issue(level, title, detail, ref)` 构造。
        """
        from ccl import lint as L
        if not callable(fn):
            raise TypeError("register_lint_rule 需要可调用对象")
        (L.EXTRA_SOLUTION_RULES if solution else L.EXTRA_RULES).append(fn)
        self._log.append(f"注册检查规则 {getattr(fn, '__name__', '?')}")

    def register_block(self, name: str, factory) -> None:
        """注册一个可复用子电路块（会出现在侧栏「子电路库」里）。"""
        from ccl import blocks as B
        if not callable(factory):
            raise TypeError("register_block 需要可调用对象")
        B.BLOCKS[name] = factory
        self._log.append(f"注册子电路块 {name}")

    def log(self, msg: str) -> None:
        self._log.append(str(msg))


def discover() -> list[dict]:
    """扫描 plugins/ 下的所有插件，返回清单列表（不激活）。"""
    out: list[dict] = []
    try:
        names = sorted(os.listdir(PLUGIN_DIR))
    except OSError:
        return out

    for name in names:
        d = os.path.join(PLUGIN_DIR, name)
        if not os.path.isdir(d) or name.startswith(".") or name == "__pycache__":
            continue
        mf = os.path.join(d, "plugin.json")
        if not os.path.isfile(mf):
            continue
        try:
            with open(mf, encoding="utf-8") as f:
                man = json.load(f)
        except Exception as e:
            out.append({"id": name, "name": name, "version": "?", "error":
                        f"plugin.json 解析失败: {type(e).__name__}: {e}"})
            continue

        pid = (man.get("id") or name).strip()
        item = {
            "id": pid,
            "name": man.get("name") or pid,
            "version": man.get("version") or "0.0.0",
            "description": man.get("description") or "",
            "author": man.get("author") or "",
            "hasUI": bool(man.get("ui")),
            "uiFile": man.get("ui") or "",
            "hasBackend": bool(man.get("backend")),
            "backendFile": man.get("backend") or "",
            "ok": True,
            "error": "",
            "log": [],
        }
        if not ID_RE.match(pid):
            item["ok"] = False
            item["error"] = f"插件 id 非法（只允许 a-z 0-9 -）: {pid!r}"
        elif item["hasUI"] and not _safe_file(d, item["uiFile"]):
            item["ok"] = False
            item["error"] = f"ui 文件不存在: {item['uiFile']}"
        elif item["hasBackend"] and not _safe_file(d, item["backendFile"]):
            item["ok"] = False
            item["error"] = f"backend 文件不存在: {item['backendFile']}"
        out.append(item)
    return out


def _safe_file(dirpath: str, rel: str) -> bool:
    """只允许插件目录内的相对路径，挡住 ../ 穿越。"""
    if not rel or ".." in rel or rel.startswith(("/", "\\")):
        return False
    fp = os.path.join(dirpath, rel)
    base = os.path.abspath(dirpath)
    return os.path.abspath(fp).startswith(base + os.sep) and os.path.isfile(fp)


def activate_all() -> dict[str, dict]:
    """加载并激活所有后端插件。幂等：重复调用只返回已有结果。"""
    global _ACTIVATED
    if _ACTIVATED:
        return REGISTRY

    for item in discover():
        REGISTRY[item["id"]] = item
        if not item.get("ok"):
            continue
        if not item.get("hasBackend"):
            item["log"].append("无后端贡献")
            continue

        d = os.path.join(PLUGIN_DIR, item["id"])
        fp = os.path.join(d, item["backendFile"])
        modname = f"ccl_plugin_{item['id'].replace('-', '_')}"
        try:
            spec = importlib.util.spec_from_file_location(modname, fp)
            if spec is None or spec.loader is None:
                raise ImportError("无法创建模块 spec")
            mod = importlib.util.module_from_spec(spec)
            sys.modules[modname] = mod
            spec.loader.exec_module(mod)          # 顶层异常在这里暴露
            api = PluginAPI(item["id"])
            reg = getattr(mod, "register", None)
            if not callable(reg):
                raise AttributeError("backend.py 必须定义 register(api) 函数")
            reg(api)
            item["log"].extend(api._log)
            item["backend"] = "loaded"
        except Exception as e:
            # 插件失败只影响它自己
            item["ok"] = False
            item["backend"] = "failed"
            item["error"] = f"{type(e).__name__}: {e}"
            traceback.print_exc()

    _ACTIVATED = True
    return REGISTRY


def list_for_api() -> list[dict]:
    """给前端用的清单（不含文件系统细节）。"""
    activate_all()
    return [
        {
            "id": v["id"],
            "name": v.get("name") or v["id"],
            "version": v.get("version") or "0.0.0",
            "description": v.get("description") or "",
            "author": v.get("author") or "",
            "hasUI": bool(v.get("hasUI")) and v.get("ok", True),
            "uiFile": v.get("uiFile") or "",
            "backend": v.get("backend") or ("无" if not v.get("hasBackend") else "?"),
            "ok": bool(v.get("ok", True)),
            "error": v.get("error") or "",
            "log": v.get("log") or [],
        }
        for v in REGISTRY.values()
    ]


def read_asset(pid: str, rel: str) -> tuple[bytes, str] | None:
    """读插件内的静态文件（给浏览器加载 ui.js 用）。返回 (bytes, content_type)。"""
    if not ID_RE.match(pid or ""):
        return None
    d = os.path.join(PLUGIN_DIR, pid)
    if not os.path.isdir(d):
        return None
    if not _safe_file(d, rel):
        return None
    ext = rel.rsplit(".", 1)[-1].lower()
    ctype = {
        "js": "text/javascript; charset=utf-8",
        "mjs": "text/javascript; charset=utf-8",
        "css": "text/css; charset=utf-8",
        "json": "application/json; charset=utf-8",
        "svg": "image/svg+xml",
        "html": "text/html; charset=utf-8",
    }.get(ext, "text/plain; charset=utf-8")
    try:
        with open(os.path.join(d, rel), "rb") as f:
            return f.read(), ctype
    except OSError:
        return None
