# 插件系统

> 一句话：**插件只能"追加"能力，不能改主程序；插件写坏也不许拖垮主程序。**

## 目录结构

```
plugins/
  loader.py                  宿主（后端加载器，主程序自带）
  <你的插件-id>/
    plugin.json              必需。清单
    backend.py               可选。新的检查规则 / 子电路块
    ui.js                    可选。新的侧栏面板 / 命令
```

插件 id 只允许 `a-z 0-9 -`，最长 32 字符。

## `plugin.json`

```json
{
  "id": "common-values",
  "name": "常用元件值检查",
  "version": "1.0.0",
  "description": "一句话说明这个插件干什么",
  "author": "你的名字",
  "backend": "backend.py",
  "ui": "ui.js"
}
```

`backend` / `ui` 都可以省略。省略了对应能力就是"无"。

## 后端：`backend.py`

必须定义 `register(api)`。`api` 只有三个方法：

```python
from ccl.lint import Issue

def check_my_rule(circuit):
    out = []
    for c in circuit.components:
        if 某个条件不满足:
            out.append(Issue(
                "warn",                          # error / warn / info
                "一句话标题",
                "详细说明与建议",
                c.ref,                           # 便于用户定位，可空
                "plugin.my_rule",                # 机器可读 code，用于去重
            ))
    return out

def register(api):
    api.register_lint_rule(check_my_rule)                 # 纯静态
    # api.register_lint_rule(fn2, solution=True)          # 需要工作点：fn2(circuit, solution)
    # api.register_block("my_block", factory)             # 新的子电路块
    api.log("已注册我的规则")
```

**可用对象**：`circuit.components`（每个有 `.ref` / `.kind` / `.value` / `.nodes()` / `.pins`）。
`solution`（仅 `solution=True` 时）里可读 `solution.v(node)` / `solution.value_at()` 等。

### 隔离保证

- 每个规则函数都被 `ccl.lint.lint()` 单独 `try/except` 包住，
  抛异常只会跳过这条规则并打印到 stderr，**不会让整个检查失败**
- `backend.py` 顶层抛异常 → 该插件标记 `backend=failed`，其他插件不受影响

### ⚠️ 诚实说明：后端插件是**可信代码**

Python 在同进程 `import`，**没有任何沙箱**。插件能读写文件、联网、`os.system`。
所以：**只安装你信得过的插件。** 这不是能力不足，而是 Python 生态里
"进程内插件"的固有性质——假装安全比承认不安全更危险。

## 前端：`ui.js`

必须 `export function activate(api)`。`api` 提供：

```js
export function activate(api) {
  api.registerSidebarPanel({
    id: 'my-panel',
    icon: '🔢',
    title: '我的面板',
    render(box) { box.innerHTML = '<div>随便画</div>'; },
  });

  api.registerCommand({
    id: 'do-something',
    label: '我的插件：做点什么',
    hint: '',
    run() { console.log('被点了'); },
  });

  api.log('已激活');
}
```

- `registerSidebarPanel` 会在左侧活动栏加一个按钮，点开渲染你的 `render(box)`
- `registerCommand` 会出现在命令面板（`Ctrl+Shift+P`）里
- 插件**拿不到**主程序的 `S`（状态）、`editor`、`panels` 等内部对象——
  这是刻意的：接口面越小，插件越不容易因为主程序改动而坏

### 隔离保证

- `import()` 失败、`activate()` 抛异常、注册重复 id → 只让**该插件**标记失败
- `render()` 抛异常 → 面板里显示错误信息，IDE 其他部分照常
- 宿主自带的「🔌 插件」面板可以看每个插件的状态、日志与错误

## 自带示例：`common-values`

一个真实有用的插件，同时演示两侧：

- **后端**：注册一条检查规则——电阻对照 E24、电容对照 E12，
  偏离最近档位超过 2% 就在「问题」里提示实际该买哪个值
- **前端**：注册一个「标准元件值」侧栏面板，列出各量级的档位

删掉 `plugins/common-values/` 目录，规则和面板会一起消失，主程序不受影响——
这就是插件系统该有的样子。

## 写一个插件的最短路径

```bash
mkdir -p plugins/my-plugin
cat > plugins/my-plugin/plugin.json <<'EOF'
{"id":"my-plugin","name":"我的插件","version":"0.1.0","backend":"backend.py"}
EOF
cat > plugins/my-plugin/backend.py <<'EOF'
def register(api):
    api.log("hello")
EOF
bash start.sh        # 重启后 GET /api/plugins 就能看到它
```

## 用 AI 生成插件

侧栏 **「🔌 插件」** 面板里有「✦ 用 AI 做一个插件」：写一句需求，AI 生成
`plugin.json` / `backend.py` / `ui.js`，**校验通过后由你点「安装」才落盘**。

### 三道闸门（为什么不直接装）

后端插件是能在本进程跑的 Python，所以：

1. **只生成草稿，不落盘** —— 代码先给你看
2. **落盘前必须过验证**
   - 清单 id 合法
   - `backend.py` 过 `ast.parse`
   - `ui.js` 过 `node --check`（没 node 会标"跳过"，不假装通过）
   - **在独立子进程里真的把每条规则跑一遍**（拿一个带 R/C 的真实小电路 + op 解）
3. **需要你显式点「安装」**，不自动启用

### 第 3 条为什么重要 —— 一条真实的踩坑记录

第一版校验只做了「子进程里调用 `register(api)`」。AI 生成的插件看起来全绿，
装上后运行时才崩：

```
[lint] 插件规则 check_resistor_margin 异常（已跳过）：
       AttributeError: 'float' object has no attribute 'strip'
```

原因是插件把 `comp.value`（是 `float`）当字符串做了 `.strip()`。
**`register()` 阶段完全不碰规则函数体，所以查不出这种 bug。**

隔离机制救了场（只跳过这条规则，主程序没事），但"装上才发现是坏的"仍然不合格。
现在校验会**真的调用每条规则**，这一类 bug 在安装前就会被拒：

```
✗ 规则实际执行  check_resistor_margin: AttributeError: 'float' object has no attribute 'strip'
```

### 装完之后

- 后端规则需要 `bash start.sh` 重启才生效
- 前端面板刷新页面即可
